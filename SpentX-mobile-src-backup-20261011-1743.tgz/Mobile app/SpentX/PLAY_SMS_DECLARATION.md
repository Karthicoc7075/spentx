# Play Console declaration

SpentX requests these Android capabilities. A production Play release needs the matching Play Console declaration for each one. This file is a checklist of what the app asks for. It is not Play policy text.

- `READ_SMS` — read bank SMS already on the device.
- `RECEIVE_SMS` — receive new bank SMS while the app is not open.
- Notification listener — read bank-app notifications when the SMS is not delivered to the app.
- Exact alarms (`SCHEDULE_EXACT_ALARM` and `USE_EXACT_ALARM`) — schedule background processing of the SMS queue.

Play Console declaration is required before a production release that uses these permissions.
