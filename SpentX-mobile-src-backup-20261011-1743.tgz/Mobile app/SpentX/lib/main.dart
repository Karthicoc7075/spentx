import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'core/router/app_router.dart';
import 'core/theme/app_theme.dart';
import 'features/sms/detected/detected_sms_migration.dart';
import 'features/sms/rules/sms_hive_boxes.dart';
import 'features/sms/rules/sms_hive_migration.dart';
import 'features/sms/sms_service.dart';
import 'features/sms/sms_notification.dart';
import 'core/services/notification_click_handler.dart';
import 'core/services/pending_verification_history_service.dart';
import 'core/services/pending_verification_bootstrap.dart';
import 'features/background_detection/notification_service.dart';
import 'features/sms/rules/engine/sms_rule_engine.dart';
import 'features/sms/rules/sms_template_rules_importer.dart';
import 'core/debug/master_debug_log.dart';
import 'core/debug/master_debug_module.dart';
import 'features/sms/detected/sms_detection_pipeline.dart';
import 'features/sms/detected/sms_inbox_catch_up.dart';
import 'features/sms/core/app_foreground_detector.dart';
import 'features/sms/v4/bank_sms_v4_parser.dart';
import 'features/sms/rules/sms_non_transaction_rules_loader.dart';
import 'core/providers/transaction_provider.dart' as model;
import 'core/providers/outing_provider.dart';
import 'core/providers/friend_split_provider.dart';
import 'core/providers/friends_provider.dart';
import 'core/providers/friend_upi_provider.dart';
import 'core/providers/friend_reminder_provider.dart';
import 'core/providers/user_state_provider.dart';
import 'core/providers/category_provider.dart';
import 'core/providers/contributor_provider.dart';
import 'core/providers/budget_provider.dart';
import 'core/providers/plan_provider.dart';
import 'core/providers/investment_provider.dart';
import 'core/providers/dashboard_kpi_provider.dart';
import 'core/providers/daily_snapshot_provider.dart';
import 'features/sms/v4/merchant_learning_service.dart';
import 'features/wealth/data/wealth_provider.dart' show savingsGoalProvider, projectorSettingsProvider;
import 'features/wealth/data/savings_goal_service.dart';
import 'features/investments/data/investment_service.dart';
import 'features/recurring/data/recurring_bill_service.dart';
import 'core/services/app_reset_service.dart';
import 'core/services/auth_service.dart';
import 'core/services/auth_gated_services.dart';
import 'core/sync/realtime_foreground_sync.dart';
import 'core/sync/sync_service.dart';
import 'core/sync/sync_queue.dart';
import 'core/sync/sms_rules_refresh_service.dart';
import 'core/sync/connectivity_sync_listener.dart';
import 'core/services/pin_service.dart';
import 'core/services/auto_detection_native_sync.dart';
import 'features/sms/background/background_sms_scheduler.dart';
import 'core/providers/theme_mode_provider.dart';
import 'core/theme/app_colors.dart';
import 'core/services/api_logger.dart';
import 'data/local/hive_service.dart';

void main() async {
  final widgetsBinding = WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  // Keep the native (pre-engine) branded splash on screen straight through
  // all of this function's init work — removed explicitly once the Dart
  // SplashScreen widget has rendered its first frame (see splash_screen.dart)
  // so there's no blank/default-icon flash before the app appears.
  FlutterNativeSplash.preserve(widgetsBinding: widgetsBinding);

  await Hive.initFlutter();
  // These boxes are independent of each other — opening them concurrently
  // instead of one-at-a-time-await cuts real disk-I/O-bound startup latency.
  await Future.wait([
    SecureHive.openBox('merchant_aliases'),
    SecureHive.openBox('categories'),
    SecureHive.openBox('outings'),
    SecureHive.openBox('friend_splits'),
    SecureHive.openBox('transactions'),
    SecureHive.openBox('settings'),
    SecureHive.openBox('friends'),
    SecureHive.openBox('friend_reminders'),
    SecureHive.openBox('pending_detections'),
    SecureHive.openBox('detected_sms_box'),
    SecureHive.openBox('pending_accounts'),
    SecureHive.openBox('ignored_detections'),
    SecureHive.openBox('budgets'),
    SecureHive.openBox('monthly_plans'),
    SecureHive.openBox('investments'),
    SecureHive.openBox('notification_history'),
    SecureHive.openBox(PendingVerificationHistoryService.boxName),
    SecureHive.openBox('wealth_snapshots'),
    ...SmsHiveBoxes.allRuleBoxes.map(SecureHive.openBox),
  ]);
  await SecureHive.openBox('merchant_rules_box');
  await MerchantLearningService.ensureOpen();

  await MasterDebugLog.startup('Hive Initialized');

  // Supabase Auth — required sign-in. Initializes the client, restores any
  // persisted session, and wires the password-reset deep-link handler.
  // No-op (with an on-screen notice at /auth) until the project keys are
  // pasted into lib/core/config/supabase_config.dart.
  await AuthService.init();
  // Native SMS listeners only trust this flag, not a preference that
  // defaults to on. Arm the account-switch hold first so a restored
  // session cannot sync the previous account's queue.
  AuthService.armAccountSwitchHoldIfNeeded();
  await AutoDetectionNativeSync.setAuthenticated(
    AuthService.isSignedIn && !AuthService.syncHeldForAccountSwitch,
  );
  // Initialize API logging with the current app version
  ApiLogger.setAppVersion('1.0.0+1');
  await SyncQueue.ensureOpen();
  await MasterDebugLog.startup('Supabase Auth Initialized');

  await migrateSmsHiveBoxes();
  await SmsRuleEngine.init();
  await SmsTemplateRulesImporter.seedBundledDefaultsIfEmpty();
  await BankSmsV4Parser.ensureLoaded();
  await SmsNonTransactionRulesLoader.ensureLoaded();
  await MasterDebugLog.startup('Merchant Rules Loaded');
  await migrateLegacyPendingTransactions();
  // Settings initialization
  final settings = Hive.box('settings');
  if (!settings.containsKey(MasterDebugLog.kEnabled)) {
    await settings.put(MasterDebugLog.kEnabled, false);
  }
  if (!settings.containsKey(MasterDebugLog.kToastEnabled)) {
    await settings.put(MasterDebugLog.kToastEnabled, false);
  }
  if (!settings.containsKey(MasterDebugLog.kRetention)) {
    await settings.put(
      MasterDebugLog.kRetention,
      MasterDebugRetention.last500.limit,
    );
  }

  await MasterDebugLog.startup('App Launched');
  // "Automatic SMS Detection" defaults to on for a new install, but a user
  // who turned it off in Settings stays off across launches. syncToNative
  // mirrors the stored value (and the bank allowlist) for the native gates.
  if (!settings.containsKey('auto_detection')) {
    await settings.put('auto_detection', true);
  }
  await AutoDetectionNativeSync.syncToNative();
  if (!settings.containsKey('profile_name')) {
    await settings.put('profile_name', '');
  }

  // Apply dev rotation setting on startup
  final disableRot =
      settings.get('disable_rotation', defaultValue: false) == true;
  if (disableRot) {
    await SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
  }

  // Local notification channel only — displaying a notification is not a
  // protected action and this must be ready before any service can post one.
  // SMS detection, the notification listener, WorkManager jobs and sync are
  // deliberately NOT started here: they belong to AuthGatedServices and only
  // run once a session exists. See Issue 1/4 — a logged-out device must not
  // listen for SMS or even ask for the permission.
  await SmsNotificationService.init((_) {});
  await MasterDebugLog.startup('Notification channel ready');
  await MasterDebugLog.startup('Settings Loaded');
  if (Hive.isBoxOpen('outings')) {
    await MasterDebugLog.startup(
      'Outings Loaded',
      data: {'count': Hive.box('outings').length},
    );
  }

  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
      statusBarBrightness: Brightness.light,
      systemNavigationBarColor: Color(0xFFF8FAFC),
      systemNavigationBarIconBrightness: Brightness.dark,
    ),
  );

  runApp(const ProviderScope(child: SpentXApp()));
}

class SpentXApp extends ConsumerStatefulWidget {
  const SpentXApp({super.key});

  @override
  ConsumerState<SpentXApp> createState() => _SpentXAppState();
}

class _SpentXAppState extends ConsumerState<SpentXApp>
    with WidgetsBindingObserver {
  DateTime? _pausedAt;
  StreamSubscription<dynamic>? _authSub;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    AuthService.clearLocalDataOnSignOut = _clearLocalData;
    MasterDebugLog.startup('Providers Initialized');
    _setupSmsListener();
    _setupNotificationHandler();
    _setupSync();
  }

  /// Disk is already empty. Reload the in-memory copies so the next account
  /// cannot save the previous account back to Hive.
  Future<void> _clearLocalData() async {
    ref.read(savingsGoalProvider.notifier).clearForLogout();
    SavingsGoalService.resetSession();
    InvestmentService.resetSession();
    RecurringBillService.resetSession();
    await AppResetService.wipeLocalData();
    if (!mounted) return;
    ref.read(model.transactionProvider.notifier).reloadFromStorage();
    ref.read(outingProvider.notifier).reloadFromStorage();
    ref.read(friendSplitProvider.notifier).reloadFromStorage();
    ref.read(manualFriendsProvider.notifier).reloadFromStorage();
    ref.read(friendUpiProvider.notifier).reloadFromStorage();
    ref.read(friendReminderProvider.notifier).reloadFromStorage();
    ref.read(userStateProvider.notifier).reloadFromStorage();
    ref.read(categoryProvider.notifier).reloadFromStorage();
    ref.read(contributorProvider.notifier).reloadFromStorage();
    ref.read(budgetProvider.notifier).reloadFromStorage();
    ref.read(planProvider.notifier).reloadFromStorage();
    ref.read(investmentProvider.notifier).reloadFromStorage();
    ref.read(dashboardKpiProvider.notifier).reloadFromStorage();
    ref.read(dailySnapshotProvider.notifier).reloadFromStorage();
    await SmsTemplateRulesImporter.seedBundledDefaultsIfEmpty();
  }

  /// Local-first sync: Hive stays the read layer; this reloads providers
  /// whenever a background pull changed local data, and starts the periodic
  /// push/pull cycle when a session exists.
  void _setupSync() {
    // Prefer reload over invalidate — invalidate recreates notifiers (heavy on low-end).
    // Debounce so bursty pull doesn't thrash the UI thread.
    var dataChangeScheduled = false;
    SyncService.onDataChanged = () {
      if (!mounted || dataChangeScheduled) return;
      dataChangeScheduled = true;
      Future<void>.delayed(const Duration(milliseconds: 400), () {
        dataChangeScheduled = false;
        if (!mounted) return;
        // Accounts/outings must reload too — net worth uses opening balances
        // and unlinked outing cash (same formula as web wealth.ts).
        ref.read(userStateProvider.notifier).reloadFromStorage();
        ref.read(outingProvider.notifier).reloadFromStorage();
        ref.read(friendSplitProvider.notifier).reloadFromStorage();
        ref.read(model.transactionProvider.notifier).reloadFromStorage();
        ref.read(categoryProvider.notifier).reloadFromStorage();
        ref.read(contributorProvider.notifier).reloadFromStorage();
        ref.read(investmentProvider.notifier).reloadFromStorage();
        ref.read(savingsGoalProvider.notifier).reloadFromStorage();
        ref.read(projectorSettingsProvider.notifier).loadSettings();
      });
    };
    SyncService.onPinResetApplied = () {
      // Web reset cleared local PIN — send user to set a new one.
      if (!mounted) return;
      final loc = appRouter.routerDelegate.currentConfiguration.uri.toString();
      if (!loc.startsWith('/pin-setup') && !loc.startsWith('/auth')) {
        appRouter.go('/pin-setup');
      }
    };
    var hadSession = AuthService.isSignedIn;
    var accountRevokedHandled = false;
    SyncService.onAccountRevoked = () {
      // Admin deleted this account server-side. The account is gone
      // permanently, so this matches "Reset App Data" — full sign-out AND
      // wipe (Hive boxes, PIN, SharedPreferences) — not a partial sign-out
      // that would leave financial data sitting on a device whose account
      // no longer exists server-side.
      if (accountRevokedHandled) return;
      accountRevokedHandled = true;
      RealtimeForegroundSync.stop();
      unawaited(() async {
        await AppResetService.resetAll();
        if (!mounted) return;
        appRouter.go('/auth');
      }());
    };
    // Starts sync + SMS + scheduled jobs only when a session exists, and
    // tears them down when it doesn't.
    scheduleSessionSync();

    // React to sign-in / sign-out / token loss without needing a restart.
    _authSub = AuthService.onAuthStateChange((signedIn) {
      if (!mounted) return;
      // A session that dies on its own (refresh rejected, account removed)
      // must clear this phone too. signOut() no-ops if one is already running.
      if (!signedIn && hadSession) {
        unawaited(AuthService.signOut(discardUnsyncedChanges: true));
      }
      hadSession = signedIn;
      unawaited(AuthGatedServices.syncWithSession());
      if (!signedIn) {
        final loc =
            appRouter.routerDelegate.currentConfiguration.uri.toString();
        if (!loc.startsWith('/auth')) appRouter.go('/auth');
        return;
      }
      // A deep link (email confirmation / magic link) can establish a
      // session while the app is sitting on an /auth screen with no
      // explicit navigation call — re-run the router's redirect logic so
      // that "signed in while on /auth" rule above actually fires.
      appRouter.refresh();
    });
  }

  @override
  void dispose() {
    _authSub?.cancel();
    ConnectivitySyncListener.stop();
    RealtimeForegroundSync.stop();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    AppForegroundDetector.onLifecycleChange(state);

    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive) {
      _pausedAt = DateTime.now();
      // SMS drain + offline data push (WorkManager, works with app closed).
      // Only for a signed-in user — nothing is scheduled while logged out.
      if (AuthService.isSignedIn) {
        BackgroundSmsScheduler.enqueueImmediate();
        BackgroundSmsScheduler.enqueueDataSync();
      }
      // No websocket held open in the background — unreliable on Android
      // and drains battery for no benefit while the UI isn't visible.
      RealtimeForegroundSync.stop();
    } else if (state == AppLifecycleState.resumed) {
      // Re-validate and refresh session proactively on every resume.
      unawaited(AuthGatedServices.syncWithSession());
      AuthService.hasValidSession().then((isValid) async {
        if (!mounted || isValid || !AuthService.isConfigured) return;
        if (AuthService.isSignedIn || AuthService.hasLocalUserData()) {
          await AuthService.signOut(discardUnsyncedChanges: true);
        }
        if (!mounted) return;
        final loc =
            appRouter.routerDelegate.currentConfiguration.uri.toString();
        if (!loc.startsWith('/auth')) appRouter.go('/auth?expired=true');
      });
      if (!AuthService.isSignedIn) {
        final loc =
            appRouter.routerDelegate.currentConfiguration.uri.toString();
        if (!loc.startsWith('/auth')) appRouter.go('/auth');
        return;
      }
      RealtimeForegroundSync.start();
      final hasPin = PinService.hasPin;
      final lockEnabled = PinService.lockEnabled;
      final isAuthenticating = PinService.isAuthenticatingBiometrically;

      // Prevent double prompt loop if the user successfully unlocked very recently (within 5 seconds)
      final lastUnlocked = PinService.lastUnlockedAt;
      final secsSinceUnlock =
          lastUnlocked != null
              ? DateTime.now().difference(lastUnlocked).inSeconds
              : 9999;

      if (hasPin && lockEnabled && !isAuthenticating && secsSinceUnlock > 4) {
        final now = DateTime.now();
        final bgSecs =
            _pausedAt != null ? now.difference(_pausedAt!).inSeconds : 999;
        // On any resume from background, require lock screen for security (always re-appear correctly on reopen)
        if (bgSecs >= 0) {
          final currentLoc =
              appRouter.routerDelegate.currentConfiguration.uri.toString();
          // Exclude initial splash screen path '/' to let the app start naturally without skipping splash
          // Note: /auth is excluded — a signed-out user must reach the login
          // screen without a PIN prompt. Resume only re-prompts PIN (never a
          // Supabase re-login); the session refreshes silently.
          if (currentLoc != '/' &&
              !currentLoc.startsWith('/lock') &&
              !currentLoc.startsWith('/splash') &&
              !currentLoc.startsWith('/auth') &&
              !currentLoc.startsWith('/onboarding')) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (mounted) {
                final encoded = Uri.encodeComponent(currentLoc);
                appRouter.go('/lock?redirect=$encoded');
              }
            });
          }
        }
      }
      _pausedAt = null;

      final ctx = rootNavigatorKey.currentContext;
      if (ctx != null && mounted) {
        SmsDetectionPipeline.bindForeground(ref: ref, context: ctx);
      }
      _drainPendingOnResume();
      // Pull-on-foreground (self-throttled) + daily admin-rules refresh.
      SyncService.onForeground();
      SmsRulesRefreshService.refreshIfStale();
    }
  }

  Future<void> _drainPendingOnResume() async {
    if (!AuthGatedServices.canUseProtectedFeatures) return;
    await SmsService.flushPendingQueue();
    await NotificationService.flushPendingPayloads();
    // Throttled (10 min): re-check bank SMS from the last 3 days that never
    // reached detection.
    await SmsInboxCatchUp.runIfDue();
    if (!mounted) return;
    // Background SMS may have auto-added to Hive — refresh in-memory ledger.
    ref.read(model.transactionProvider.notifier).reloadFromStorage();
    ref.invalidate(model.transactionProvider);
    final ctx = rootNavigatorKey.currentContext;
    if (ctx == null || !ctx.mounted) return;
    await PendingVerificationBootstrap.afterUnlock(context: ctx, ref: ref);
  }

  /// Foreground SMS wiring. Every step here is protected: binding the
  /// detection pipeline, requesting SMS permission and showing the pending
  /// verification popup all require a signed-in user (Issue 1 + Issue 2).
  void _setupSmsListener() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!AuthGatedServices.canUseProtectedFeatures) return;
      final ctx = rootNavigatorKey.currentContext;
      if (ctx != null && mounted) {
        SmsDetectionPipeline.bindForeground(ref: ref, context: ctx);
      }
    });

    Future.delayed(const Duration(milliseconds: 800), () async {
      // Permission prompt and startup popup are gated — never shown to a
      // logged-out user. AuthGatedServices.start() owns the permission
      // request itself once a session exists.
      if (!mounted || !AuthGatedServices.canUseProtectedFeatures) return;
      await PendingVerificationBootstrap.processStartupAndShowIfNeeded(
        ref: ref,
      );
    });
  }

  void _setupNotificationHandler() {
    SmsNotificationService.init((payload) {
      NotificationClickHandler.handle(ref: ref, payload: payload);
    });
  }

  @override
  Widget build(BuildContext context) {
    final themeMode = ref.watch(themeModeProvider);
    final platformBrightness = MediaQuery.platformBrightnessOf(context);
    final isDark =
        themeMode == ThemeMode.system
            ? platformBrightness == Brightness.dark
            : themeMode == ThemeMode.dark;
    AppSurface.isDark = isDark;
    final overlay = SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: isDark ? Brightness.light : Brightness.dark,
      statusBarBrightness: isDark ? Brightness.dark : Brightness.light,
      systemNavigationBarColor:
          isDark ? AppColors.darkBg : const Color(0xFFF8FAFC),
      systemNavigationBarIconBrightness:
          isDark ? Brightness.light : Brightness.dark,
    );
    SystemChrome.setSystemUIOverlayStyle(overlay);
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: overlay,
      child: MaterialApp.router(
        title: 'SpentX',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.lightTheme,
        darkTheme: AppTheme.darkTheme,
        // Settings → Preferences → Dark Mode (persisted in SharedPreferences).
        themeMode: themeMode,
        routerConfig: appRouter,
        // Clean single root navigator via go_router's navigatorKey (rootNavigatorKey).
        // This fixes nested Navigator issues that could cause Gralloc/GraphicBuffer/AHardwareBuffer
        // rendering errors and unstable biometric prompts on Android.
      ),
    );
  }
}
