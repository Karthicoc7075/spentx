# SpentX Mobile — Clean Architecture Map

Status: **in progress** (this run: Soft palette + core shell + feature folders)

## Soft UI

| Token | Hex |
|-------|-----|
| bg | `#f8f9fc` |
| ink | `#020617` |
| muted | `#64748b` |
| emerald | `#059669` |

Source: `lib/core/theme/soft_palette.dart` → `spentx_tokens.dart` / `app_colors.dart`.

## Layout

```
lib/
  main.dart
  core/           # shared: theme, router, nav, services, sync, widgets, design
  data/           # legacy local/secure helpers (migrate into features/*/data)
  models/         # legacy shared models (migrate into features/*/domain)
  features/
    <feature>/
      data/       # repositories, local sources, DTOs
      domain/     # entities, repository ports, pure rules
      presentation/  # screens, widgets, feature providers
```

## Main shell

- Route `/home` → `features/home/presentation/main_wrapper.dart`
- Shared Soft bottom nav → `core/navigation/soft_bottom_nav.dart`
- Tab coordination → `core/navigation/main_shell_navigation.dart`
- Router → `core/router/app_router.dart` (auth gate + all product routes kept)

## Product features (keep)

Home, Accounts/Wealth, Transactions, Analytics, Plan, Outings/Groups, SMS,
Budgets, Calendar, Recurring, Investments, Loans, Friends, Notifications,
Settings, Auth/onboarding/PIN, Export.

## Migration rule

Prefer a working app: keep existing presentation screens and core providers;
add domain/data ports incrementally; delete dead duplicates only after callers
move. Do not wipe `lib/` wholesale.

## Providers

Feature Riverpod providers live in `features/<feature>/data/` (e.g. budget, friends,
investment, merchant, outing). `lib/core/providers/` keeps thin re-exports for
backward-compatible imports, plus cross-cutting `category_provider` and
`user_state_provider`.
