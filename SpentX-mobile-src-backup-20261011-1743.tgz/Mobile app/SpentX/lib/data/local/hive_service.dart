import 'dart:convert';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:hive_flutter/hive_flutter.dart';

final hiveServiceProvider = Provider<HiveService>((ref) => HiveService());

/// Opens Hive boxes with a key that lives in the platform keystore
/// (flutter_secure_storage). The key is generated once per install and is
/// never hardcoded.
///
/// Existing plaintext boxes are copied into an encrypted box on first open,
/// then the plaintext file is deleted. Later opens use the cipher directly.
/// Boxes that are already open in this isolate are returned as-is.
class SecureHive {
  SecureHive._();

  static const FlutterSecureStorage _storage = FlutterSecureStorage();
  static const String _keyId = 'hive_encryption_key';
  static HiveAesCipher? _cipher;
  static Future<HiveAesCipher>? _cipherLoading;

  static Future<HiveAesCipher> encryptionCipher() async {
    final cached = _cipher;
    if (cached != null) return cached;
    // All concurrently opened boxes must await the SAME key creation.
    // A failed keystore call is retryable; never cache a failed Future.
    final loading = _cipherLoading ??= _loadCipher();
    try {
      return await loading;
    } finally {
      if (identical(_cipherLoading, loading)) _cipherLoading = null;
    }
  }

  static Future<HiveAesCipher> _loadCipher() async {
    var encoded = await _storage.read(key: _keyId);
    if (encoded == null || encoded.isEmpty) {
      final key = Hive.generateSecureKey();
      encoded = base64UrlEncode(key);
      await _storage.write(key: _keyId, value: encoded);
    }
    final cipher = HiveAesCipher(base64Url.decode(encoded));
    _cipher = cipher;
    return cipher;
  }

  static Future<Box<E>> openBox<E>(String name) async {
    if (Hive.isBoxOpen(name)) return Hive.box<E>(name);
    final cipher = await encryptionCipher();
    try {
      return await Hive.openBox<E>(name, encryptionCipher: cipher);
    } catch (encryptedError) {
      if (Hive.isBoxOpen(name)) {
        await Hive.box(name).close();
      }
      final Box plain;
      try {
        plain = await Hive.openBox(name);
      } catch (_) {
        // Not a legacy plaintext box (missing, or already encrypted with
        // another key). Do not delete it.
        throw encryptedError;
      }
      final data = Map<dynamic, dynamic>.from(plain.toMap());
      await plain.close();
      await Hive.deleteBoxFromDisk(name);
      final enc = await Hive.openBox<E>(name, encryptionCipher: cipher);
      for (final entry in data.entries) {
        await enc.put(entry.key, entry.value);
      }
      return enc;
    }
  }
}

class HiveService {
  bool _isInitialized = false;

  Future<void> init() async {
    if (_isInitialized) return;
    await Hive.initFlutter();
    await SecureHive.openBox('settings');
    await SecureHive.openBox('vault');
    _isInitialized = true;
  }
}
