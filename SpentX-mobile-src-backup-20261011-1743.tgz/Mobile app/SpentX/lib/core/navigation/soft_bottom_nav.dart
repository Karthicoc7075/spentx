import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../theme/soft_palette.dart';
import '../theme/spentx_tokens.dart';

/// Shared Soft UI bottom navigation used by the main shell.
///
/// Tabs: Home · Activity · Analytics · More/Settings, with a center add FAB.
class SoftBottomNav extends StatelessWidget {
  const SoftBottomNav({
    super.key,
    required this.currentIndex,
    required this.onChanged,
    required this.onAdd,
    this.settingsSelected = false,
  });

  final int currentIndex;
  final ValueChanged<int> onChanged;
  final VoidCallback onAdd;

  /// When true, the 4th tab shows Settings instead of More.
  final bool settingsSelected;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final items = [
      (0, LucideIcons.home, 'Home'),
      (1, LucideIcons.receipt, 'Activity'),
      (2, LucideIcons.pieChart, 'Analytics'),
      (
        3,
        settingsSelected ? LucideIcons.settings2 : LucideIcons.layoutGrid,
        settingsSelected ? 'Settings' : 'More',
      ),
    ];

    return Material(
      color: t.card.withValues(alpha: .98),
      child: SafeArea(
        top: false,
        child: Container(
          height: 68,
          decoration: BoxDecoration(
            border: Border(top: BorderSide(color: t.border)),
            boxShadow: const [
              BoxShadow(
                color: Color(0x0F020617),
                blurRadius: 12,
                offset: Offset(0, -3),
              ),
            ],
          ),
          child: Row(
            children: [
              Expanded(child: _item(context, items[0])),
              Expanded(child: _item(context, items[1])),
              SizedBox(
                width: 72,
                child: Center(
                  child: GestureDetector(
                    onTap: onAdd,
                    child: Container(
                      width: 56,
                      height: 56,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: SoftColors.primaryGradient,
                        boxShadow: const [
                          BoxShadow(
                            color: Color(0x40059669),
                            blurRadius: 16,
                            offset: Offset(0, 6),
                          ),
                        ],
                      ),
                      child: Icon(
                        LucideIcons.plus,
                        color: Colors.white,
                        size: 28,
                      ),
                    ),
                  ),
                ),
              ),
              Expanded(child: _item(context, items[2])),
              Expanded(child: _item(context, items[3])),
            ],
          ),
        ),
      ),
    );
  }

  Widget _item(BuildContext context, (int, IconData, String) item) {
    final selected = currentIndex == item.$1;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final color =
        selected
            ? (isDark ? SoftPalette.darkEmerald : SoftColors.control)
            : context.tokens.textSecondary;
    return InkWell(
      onTap: () => onChanged(item.$1),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(item.$2, size: 21, color: color),
          const SizedBox(height: 3),
          Text(
            item.$3,
            style: TextStyle(
              fontSize: 10,
              fontWeight: selected ? FontWeight.w800 : FontWeight.w500,
              color: color,
            ),
          ),
          const SizedBox(height: 3),
          Container(
            width: 5,
            height: 5,
            decoration: BoxDecoration(
              color: selected ? color : Colors.transparent,
              shape: BoxShape.circle,
            ),
          ),
        ],
      ),
    );
  }
}

/// Soft scaffold chrome: Soft bg + optional shared bottom nav.
class SoftShellScaffold extends StatelessWidget {
  const SoftShellScaffold({
    super.key,
    required this.body,
    this.bottomNavigationBar,
    this.floatingActionButton,
    this.extendBody = false,
  });

  final Widget body;
  final Widget? bottomNavigationBar;
  final Widget? floatingActionButton;
  final bool extendBody;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.tokens.background,
      extendBody: extendBody,
      body: body,
      bottomNavigationBar: bottomNavigationBar,
      floatingActionButton: floatingActionButton,
    );
  }
}
