import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

/// Coordinates tab selection inside [MainWrapper] when a pushed route asks
/// to return to a specific shell tab (Home / Activity / Analytics / Settings).
class MainShellNavigation {
  MainShellNavigation._();

  /// Tab indices match MainWrapper: 0 Home, 1 Activity, 2 Analytics, 3 Settings.
  static final ValueNotifier<int?> pendingTab = ValueNotifier<int?>(null);

  static void openTab(BuildContext context, int tab) {
    pendingTab.value = tab.clamp(0, 3);
    // Already inside the shell. go('/home') would rebuild MainWrapper and
    // look like an app restart. Only leave the current route when needed.
    final path = GoRouterState.of(context).uri.path;
    if (path != '/home') {
      context.go('/home');
    }
  }

  static void handleReferenceDestination(BuildContext context, String id) {
    switch (id) {
      case 'home':
        openTab(context, 0);
        break;
      case 'activity':
        openTab(context, 1);
        break;
      case 'analytics':
        openTab(context, 2);
        break;
      case 'settings':
      case 'more':
        openTab(context, 3);
        break;
      case 'accounts':
        context.push('/accounts');
        break;
      case 'plan':
        context.push('/plan');
        break;
      case 'outings':
        context.push('/outings');
        break;
      case 'wealth':
        context.push('/wealth');
        break;
      default:
        openTab(context, 0);
    }
  }
}
