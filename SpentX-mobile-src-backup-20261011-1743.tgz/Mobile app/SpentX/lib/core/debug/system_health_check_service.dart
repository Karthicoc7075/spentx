import 'package:hive_flutter/hive_flutter.dart';

import '../../features/sms/detected/detected_sms_storage.dart';
import '../../features/sms/rules/engine/sms_rule_engine.dart';
import '../../features/sms/rules/sms_hive_boxes.dart';
import 'master_debug_log.dart';
import 'master_debug_module.dart';
import '../../data/local/hive_service.dart';

class HealthCheckItem {
  final String name;
  final bool passed;
  final String detail;

  const HealthCheckItem({
    required this.name,
    required this.passed,
    required this.detail,
  });
}

class SystemHealthCheckReport {
  final List<HealthCheckItem> items;
  final DateTime checkedAt;

  const SystemHealthCheckReport({
    required this.items,
    required this.checkedAt,
  });

  bool get allPassed => items.every((i) => i.passed);
  int get passCount => items.where((i) => i.passed).length;
  int get failCount => items.where((i) => !i.passed).length;
}

/// Verifies core SpentX subsystems for Developer Options health check.
class SystemHealthCheckService {
  SystemHealthCheckService._();

  static Future<SystemHealthCheckReport> run() async {
    final items = <HealthCheckItem>[
      await _checkHiveBoxes(),
      await _checkSmsPipeline(),
      await _checkNotificationService(),
      await _checkMerchantRules(),
      await _checkPendingQueue(),
      await _checkOutingSystem(),
      await _checkAccountBalances(),
    ];

    final report = SystemHealthCheckReport(
      items: items,
      checkedAt: DateTime.now(),
    );

    if (MasterDebugLog.isEnabled) {
      await MasterDebugLog.log(
        level: report.allPassed ? MasterDebugLevel.success : MasterDebugLevel.warning,
        module: MasterDebugModule.system,
        title: 'System Health Check: ${report.allPassed ? 'PASS' : 'FAIL'}',
        message: '${report.passCount}/${items.length} checks passed',
        data: {
          'items': items
              .map((i) => {'name': i.name, 'passed': i.passed, 'detail': i.detail})
              .toList(),
        },
      );
    }

    return report;
  }

  static Future<HealthCheckItem> _checkHiveBoxes() async {
    const required = [
      'settings',
      'transactions',
      'outings',
      'merchant_rules_box',
      'pending_detections',
      'detected_sms_box',
      'notification_history',
      MasterDebugLog.boxName,
    ];
    final missing = <String>[];
    for (final name in required) {
      if (!Hive.isBoxOpen(name)) {
        try {
          await SecureHive.openBox(name);
        } catch (_) {
          missing.add(name);
        }
      }
    }
    for (final name in SmsHiveBoxes.allRuleBoxes) {
      if (!Hive.isBoxOpen(name)) missing.add(name);
    }
    return HealthCheckItem(
      name: 'Hive Boxes',
      passed: missing.isEmpty,
      detail: missing.isEmpty ? 'All core boxes open' : 'Missing: ${missing.join(', ')}',
    );
  }

  static Future<HealthCheckItem> _checkSmsPipeline() async {
    try {
      await SmsRuleEngine.init();
      final blocked = SmsRuleEngine.isBlocked('AD: Get loan now');
      final sample = 'Rs.100 debited from A/c **1234 on 01-01-24 to test@upi';
      final parsed = SmsRuleEngine.parse(sample);
      final ok = parsed != null || blocked;
      return HealthCheckItem(
        name: 'SMS Detection Pipeline',
        passed: ok,
        detail: ok
            ? 'Rule engine initialized; parse/block paths responsive'
            : 'Rule engine failed to respond',
      );
    } catch (e) {
      return HealthCheckItem(
        name: 'SMS Detection Pipeline',
        passed: false,
        detail: e.toString(),
      );
    }
  }

  static Future<HealthCheckItem> _checkNotificationService() async {
    final settingsOpen = Hive.isBoxOpen('settings');
    final historyOpen = Hive.isBoxOpen('notification_history');
    final autoOn = settingsOpen &&
        Hive.box('settings').get('auto_detection', defaultValue: true) == true;
    return HealthCheckItem(
      name: 'Notification Service',
      passed: settingsOpen && historyOpen,
      detail: historyOpen
          ? 'History box ready • auto_detection: ${autoOn ? 'ON' : 'OFF'}'
          : 'notification_history box unavailable',
    );
  }

  static Future<HealthCheckItem> _checkMerchantRules() async {
    if (!Hive.isBoxOpen('merchant_rules_box')) {
      return const HealthCheckItem(
        name: 'Merchant Rules',
        passed: false,
        detail: 'merchant_rules_box not open',
      );
    }
    final box = Hive.box('merchant_rules_box');
    final v4Count =
        Hive.isBoxOpen('merchants_box') ? Hive.box('merchants_box').length : -1;
    return HealthCheckItem(
      name: 'Merchant Rules',
      passed: true,
      detail:
          '${box.length} legacy rules • ${v4Count < 0 ? 'v4 box closed' : '$v4Count v4 merchants'}',
    );
  }

  static Future<HealthCheckItem> _checkPendingQueue() async {
    if (!Hive.isBoxOpen('pending_detections')) {
      return const HealthCheckItem(
        name: 'Pending Queue',
        passed: false,
        detail: 'pending_detections box not open',
      );
    }
    final queue = Hive.box('pending_detections').get('queue', defaultValue: const <dynamic>[]);
    final ids = List<String>.from(queue);
    var valid = 0;
    for (final id in ids) {
      if (DetectedSmsStorage.get(id) != null) valid++;
    }
    // Orphaned ids (queued but missing from detected_sms_box) mean verify
    // popups would silently drop — that is a failure, not a pass.
    final orphans = ids.length - valid;
    return HealthCheckItem(
      name: 'Pending Queue',
      passed: orphans == 0,
      detail: orphans == 0
          ? '${ids.length} queued • all resolvable in detected_sms_box'
          : '$orphans of ${ids.length} queued ids are orphaned (missing from detected_sms_box)',
    );
  }

  static Future<HealthCheckItem> _checkOutingSystem() async {
    if (!Hive.isBoxOpen('outings')) {
      return const HealthCheckItem(
        name: 'Outing System',
        passed: false,
        detail: 'outings box not open',
      );
    }
    final box = Hive.box('outings');
    var active = 0;
    for (final key in box.keys) {
      final raw = box.get(key);
      if (raw is Map && raw['isActive'] == true) active++;
    }
    // The app's invariant is at most ONE active outing — more is a real fault.
    return HealthCheckItem(
      name: 'Outing System',
      passed: active <= 1,
      detail: active <= 1
          ? '${box.length} outings stored • $active active'
          : '$active outings marked active — violates single-active-trip invariant',
    );
  }

  static Future<HealthCheckItem> _checkAccountBalances() async {
    if (!Hive.isBoxOpen('transactions')) {
      return const HealthCheckItem(
        name: 'Account Balances',
        passed: false,
        detail: 'transactions box not open',
      );
    }
    final txs = Hive.box('transactions').get('list', defaultValue: const <dynamic>[]);
    final count = txs is List ? txs.length : 0;
    return HealthCheckItem(
      name: 'Account Balances',
      passed: true,
      detail: '$count transactions in ledger',
    );
  }
}