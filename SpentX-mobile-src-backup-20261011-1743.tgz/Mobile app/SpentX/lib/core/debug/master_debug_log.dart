import 'dart:convert';

import 'package:hive_flutter/hive_flutter.dart';

import 'debug_toast_service.dart';
import 'master_debug_module.dart';
import '../../data/local/hive_service.dart';

/// Single source of truth for internal SpentX debug logging.
/// When [isEnabled] is false: no writes, no toasts, no box access.
class MasterDebugLog {
  MasterDebugLog._();

  static const boxName = 'master_debug_log_box';
  static const entriesKey = 'entries';

  static const kEnabled = 'master_debug_logging';
  static const kToastEnabled = 'debug_toast_messages';
  static const kRetention = 'master_debug_retention';

  static bool _boxReady = false;

  static bool get isEnabled {
    if (!Hive.isBoxOpen('settings')) return false;
    return Hive.box('settings').get(kEnabled, defaultValue: false) == true;
  }

  static bool get isToastEnabled {
    if (!isEnabled) return false;
    if (!Hive.isBoxOpen('settings')) return false;
    return Hive.box('settings').get(kToastEnabled, defaultValue: false) == true;
  }

  static int get retentionLimit {
    if (!Hive.isBoxOpen('settings')) return MasterDebugRetention.last500.limit;
    final v = Hive.box('settings').get(kRetention, defaultValue: 500);
    return v is int ? v : int.tryParse(v.toString()) ?? 500;
  }

  static Future<void> ensureOpen() async {
    if (!Hive.isBoxOpen(boxName)) {
      await SecureHive.openBox<dynamic>(boxName);
    }
    _boxReady = true;
  }

  static Future<void> setEnabled(bool value) async {
    final settings = Hive.box('settings');
    await settings.put(kEnabled, value);
    if (!value) {
      await settings.put(kToastEnabled, false);
    }
  }

  static Future<void> setToastEnabled(bool value) async {
    if (!isEnabled) return;
    await Hive.box('settings').put(kToastEnabled, value);
  }

  static Future<void> setRetention(MasterDebugRetention retention) async {
    await Hive.box('settings').put(kRetention, retention.limit);
    if (isEnabled && _boxReady) {
      await _enforceRetention();
    }
  }

  /// Primary log entry point. No-op when master logging is OFF.
  static Future<void> log({
    required MasterDebugLevel level,
    required MasterDebugModule module,
    required String title,
    String? message,
    Map<String, dynamic>? data,
    String? functionName,
    Object? error,
    StackTrace? stackTrace,
    bool showToast = false,
    String? toastMessage,
  }) async {
    if (!isEnabled) return;

    await ensureOpen();
    final box = Hive.box<dynamic>(boxName);
    final entries = List<dynamic>.from(box.get(entriesKey, defaultValue: []));

    final entry = <String, dynamic>{
      'id': '${DateTime.now().microsecondsSinceEpoch}_${entries.length}',
      'timestamp': DateTime.now().toIso8601String(),
      'level': level.name,
      'module': module.name,
      'title': title,
      'message': message ?? '',
      'dataJson': data != null ? jsonEncode(data) : null,
      if (functionName != null) 'functionName': functionName,
      if (error != null) 'errorMessage': error.toString(),
      if (stackTrace != null) 'stackTrace': stackTrace.toString(),
    };

    entries.insert(0, entry);
    final limit = retentionLimit;
    if (limit > 0 && entries.length > limit) {
      entries.removeRange(limit, entries.length);
    }
    await box.put(entriesKey, entries);

    if (showToast || isToastEnabled) {
      DebugToastService.show(
        message: toastMessage ?? title,
        level: level,
      );
    }
  }

  static Future<void> logError({
    required MasterDebugModule module,
    required String title,
    required Object error,
    StackTrace? stackTrace,
    String? functionName,
    Map<String, dynamic>? data,
  }) {
    return log(
      level: MasterDebugLevel.error,
      module: module,
      title: title,
      message: error.toString(),
      functionName: functionName,
      error: error,
      stackTrace: stackTrace ?? StackTrace.current,
      data: data,
      showToast: true,
    );
  }

  // ── Category helpers ──────────────────────────────────────────────

  static Future<void> startup(String event, {Map<String, dynamic>? data}) => log(
        level: MasterDebugLevel.info,
        module: MasterDebugModule.system,
        title: event,
        data: data,
      );

  static Future<void> sms({
    required String title,
    String? message,
    String? sender,
    String? source,
    String? detectionResult,
    Map<String, dynamic>? extra,
  }) {
    final data = <String, dynamic>{
      if (sender != null) 'sender': sender,
      if (source != null) 'source': source,
      if (detectionResult != null) 'detectionResult': detectionResult,
      ...?extra,
    };
    return log(
      level: MasterDebugLevel.info,
      module: MasterDebugModule.sms,
      title: title,
      message: message,
      data: data.isEmpty ? null : data,
    );
  }

  static Future<void> ruleEngine({
    required String title,
    String? message,
    MasterDebugLevel level = MasterDebugLevel.debug,
    Map<String, dynamic>? data,
  }) =>
      log(level: level, module: MasterDebugModule.ruleEngine, title: title, message: message, data: data);

  static Future<void> merchant({
    required String title,
    String? message,
    MasterDebugLevel level = MasterDebugLevel.info,
    Map<String, dynamic>? data,
    bool showToast = false,
  }) =>
      log(
        level: level,
        module: MasterDebugModule.merchant,
        title: title,
        message: message,
        data: data,
        showToast: showToast,
      );

  static Future<void> notification({
    required String title,
    String? message,
    MasterDebugLevel level = MasterDebugLevel.info,
    Map<String, dynamic>? payload,
    bool showToast = false,
  }) =>
      log(
        level: level,
        module: MasterDebugModule.notification,
        title: title,
        message: message,
        data: payload,
        showToast: showToast,
      );

  static Future<void> queue({
    required String title,
    String? message,
    MasterDebugLevel level = MasterDebugLevel.info,
    String? transactionId,
  }) =>
      log(
        level: level,
        module: MasterDebugModule.queue,
        title: title,
        message: message,
        data: transactionId != null ? {'transactionId': transactionId} : null,
      );

  static Future<void> transaction({
    required String title,
    String? message,
    MasterDebugLevel level = MasterDebugLevel.success,
    Map<String, dynamic>? data,
    bool showToast = false,
  }) =>
      log(
        level: level,
        module: MasterDebugModule.transactions,
        title: title,
        message: message,
        data: data,
        showToast: showToast,
      );

  static Future<void> balance({
    required String title,
    String? accountBefore,
    String? accountAfter,
    double? amountChanged,
    Map<String, dynamic>? extra,
  }) {
    final data = <String, dynamic>{
      if (accountBefore != null) 'accountBefore': accountBefore,
      if (accountAfter != null) 'accountAfter': accountAfter,
      if (amountChanged != null) 'amountChanged': amountChanged,
      ...?extra,
    };
    return log(
      level: MasterDebugLevel.info,
      module: MasterDebugModule.accounts,
      title: title,
      message: accountBefore != null && accountAfter != null
          ? '$accountBefore → $accountAfter'
          : null,
      data: data.isEmpty ? null : data,
      showToast: title.contains('Updated'),
    );
  }

  static Future<void> outing({
    required String title,
    String? message,
    MasterDebugLevel level = MasterDebugLevel.info,
    Map<String, dynamic>? data,
    bool showToast = false,
  }) =>
      log(
        level: level,
        module: MasterDebugModule.outings,
        title: title,
        message: message,
        data: data,
        showToast: showToast,
      );

  static Future<void> duplicate({
    required String title,
    String? referenceId,
    String? skipReason,
    MasterDebugLevel level = MasterDebugLevel.warning,
  }) =>
      log(
        level: level,
        module: MasterDebugModule.transactions,
        title: title,
        message: skipReason,
        data: {
          if (referenceId != null) 'referenceId': referenceId,
          if (skipReason != null) 'skipReason': skipReason,
        },
      );

  // ── Read / export / clear ─────────────────────────────────────────

  static List<MasterDebugLogEntry> readAll() {
    if (!Hive.isBoxOpen(boxName)) return [];
    final box = Hive.box<dynamic>(boxName);
    final entries = List<dynamic>.from(box.get(entriesKey, defaultValue: []));
    return entries.map(MasterDebugLogEntry.fromMap).toList();
  }

  static Future<String> exportAsJson() async {
    final logs = readAll();
    return const JsonEncoder.withIndent('  ').convert(
      logs.map((e) => e.toMap()).toList(),
    );
  }

  static Future<void> clear() async {
    if (!isEnabled) return;
    await ensureOpen();
    await Hive.box<dynamic>(boxName).put(entriesKey, <dynamic>[]);
  }

  static Future<void> _enforceRetention() async {
    if (!Hive.isBoxOpen(boxName)) return;
    final limit = retentionLimit;
    if (limit <= 0) return;
    final box = Hive.box<dynamic>(boxName);
    final entries = List<dynamic>.from(box.get(entriesKey, defaultValue: []));
    if (entries.length > limit) {
      entries.removeRange(limit, entries.length);
      await box.put(entriesKey, entries);
    }
  }
}

class MasterDebugLogEntry {
  final String id;
  final DateTime timestamp;
  final MasterDebugLevel level;
  final MasterDebugModule module;
  final String title;
  final String message;
  final String? dataJson;
  final String? functionName;
  final String? errorMessage;
  final String? stackTrace;

  const MasterDebugLogEntry({
    required this.id,
    required this.timestamp,
    required this.level,
    required this.module,
    required this.title,
    required this.message,
    this.dataJson,
    this.functionName,
    this.errorMessage,
    this.stackTrace,
  });

  factory MasterDebugLogEntry.fromMap(dynamic raw) {
    final m = Map<String, dynamic>.from(raw as Map);
    return MasterDebugLogEntry(
      id: m['id']?.toString() ?? '',
      timestamp: DateTime.tryParse(m['timestamp']?.toString() ?? '') ?? DateTime.now(),
      level: MasterDebugLevel.fromString(m['level']?.toString()),
      module: MasterDebugModule.fromLabel(m['module']?.toString()) ?? MasterDebugModule.system,
      title: m['title']?.toString() ?? '',
      message: m['message']?.toString() ?? '',
      dataJson: m['dataJson']?.toString(),
      functionName: m['functionName']?.toString(),
      errorMessage: m['errorMessage']?.toString(),
      stackTrace: m['stackTrace']?.toString(),
    );
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'timestamp': timestamp.toIso8601String(),
        'level': level.name,
        'module': module.name,
        'title': title,
        'message': message,
        if (dataJson != null) 'dataJson': dataJson,
        if (functionName != null) 'functionName': functionName,
        if (errorMessage != null) 'errorMessage': errorMessage,
        if (stackTrace != null) 'stackTrace': stackTrace,
      };

  String get copyText {
    final buf = StringBuffer()
      ..writeln('[$level] ${module.label} — $title')
      ..writeln(timestamp.toIso8601String());
    if (message.isNotEmpty) buf.writeln(message);
    if (dataJson != null) buf.writeln('Data: $dataJson');
    if (errorMessage != null) buf.writeln('Error: $errorMessage');
    if (stackTrace != null) buf.writeln(stackTrace);
    return buf.toString().trim();
  }

  @override
  bool operator ==(Object other) =>
      other is MasterDebugLogEntry && other.id == id;

  @override
  int get hashCode => id.hashCode;
}