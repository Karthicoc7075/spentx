/// Modules tracked by the Master Debug Log system.
enum MasterDebugModule {
  sms('SMS'),
  ruleEngine('Rule Engine'),
  merchant('Merchant'),
  notification('Notification'),
  queue('Queue'),
  transactions('Transactions'),
  accounts('Accounts'),
  outings('Outings'),
  budgets('Budgets'),
  friends('Friends'),
  investments('Investments'),
  ui('UI'),
  settings('Settings'),
  system('System');

  final String label;
  const MasterDebugModule(this.label);

  static MasterDebugModule? fromLabel(String? value) {
    if (value == null || value.isEmpty) return null;
    for (final m in values) {
      if (m.name == value || m.label == value) return m;
    }
    return null;
  }
}

enum MasterDebugLevel {
  info('INFO'),
  success('SUCCESS'),
  warning('WARNING'),
  error('ERROR'),
  debug('DEBUG');

  final String label;
  const MasterDebugLevel(this.label);

  static MasterDebugLevel fromString(String? value) {
    if (value == null) return MasterDebugLevel.info;
    return values.firstWhere(
      (l) => l.name == value.toLowerCase() || l.label == value.toUpperCase(),
      orElse: () => MasterDebugLevel.info,
    );
  }
}

/// Log retention presets stored in settings.
enum MasterDebugRetention {
  last100(100),
  last500(500),
  last1000(1000),
  unlimited(-1);

  final int limit;
  const MasterDebugRetention(this.limit);

  String get displayLabel {
    if (this == MasterDebugRetention.unlimited) return 'Unlimited';
    return 'Last $limit logs';
  }

  static MasterDebugRetention fromLimit(int? value) {
    return values.firstWhere(
      (r) => r.limit == value,
      orElse: () => MasterDebugRetention.last500,
    );
  }
}