import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../router/app_router.dart';
import 'master_debug_module.dart';

/// Real-time debug toasts — only shown when Master Debug Logging + Debug Toasts are ON.
class DebugToastService {
  DebugToastService._();

  static const kEnabled = 'master_debug_logging';
  static const kToastEnabled = 'debug_toast_messages';

  static OverlayEntry? _currentEntry;

  static bool get _shouldShow {
    if (!Hive.isBoxOpen('settings')) return false;
    final settings = Hive.box('settings');
    if (settings.get(kEnabled, defaultValue: false) != true) return false;
    return settings.get(kToastEnabled, defaultValue: false) == true;
  }

  static void show({
    required String message,
    required MasterDebugLevel level,
  }) {
    if (!_shouldShow) return;

    final context = rootNavigatorKey.currentContext;
    if (context == null) return;

    _currentEntry?.remove();
    _currentEntry = null;

    final overlay = Overlay.maybeOf(context);
    if (overlay == null) return;

    final isSuccess = level == MasterDebugLevel.success;
    final isError = level == MasterDebugLevel.error || level == MasterDebugLevel.warning;

    String prefix;
    Color bg;
    if (isSuccess) {
      prefix = '✔ ';
      bg = const Color(0xFF064E3B);
    } else if (isError) {
      prefix = '❌ ';
      bg = const Color(0xFF7F1D1D);
    } else {
      prefix = 'ℹ ';
      bg = const Color(0xFF1E3A5F);
    }

    late OverlayEntry entry;
    entry = OverlayEntry(
      builder: (ctx) => Positioned(
        bottom: 96,
        left: 16,
        right: 16,
        child: Material(
          color: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: bg.withValues(alpha: 0.95),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.white12),
            ),
            child: Text(
              '$prefix$message',
              style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w500),
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ),
      ),
    );

    _currentEntry = entry;
    overlay.insert(entry);

    Future.delayed(const Duration(seconds: 3), () {
      if (_currentEntry == entry) {
        entry.remove();
        _currentEntry = null;
      }
    });
  }
}