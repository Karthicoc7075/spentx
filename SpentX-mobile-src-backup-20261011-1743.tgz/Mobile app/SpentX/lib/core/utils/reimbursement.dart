import '../providers/transaction_provider.dart';

/// Splitting a period's rows into genuine income, actual spending, and money
/// friends returned for expenses you had already paid.
///
/// A friend paying you back is not earnings and not a new expense — it reduces
/// what shared spending cost you. Both the Activity summary and Analysis read
/// their figures from here so the two cannot describe the same period
/// differently.
///
/// Nothing here mutates a transaction. The ledger keeps the original ₹1,200
/// and the ₹800 return as separate rows; only these derived totals net.
class ReimbursementTotals {
  /// Every real expense, before anything is netted off.
  final double grossSpend;

  /// Genuine income — salary and the like. Never includes a reimbursement.
  final double income;

  /// Returns that were actually applied against spending.
  final double applied;

  /// Returns that could NOT be applied because the expense they relate to
  /// does not cover them — a friend sending back more than their share, or a
  /// return whose original expense falls outside this period.
  ///
  /// Deliberately NOT folded into [applied]: doing so would let one trip's
  /// over-return silently erase unrelated spending elsewhere in the period.
  /// Surfaced so it can be reported rather than absorbed.
  final double excess;

  const ReimbursementTotals({
    required this.grossSpend,
    required this.income,
    required this.applied,
    required this.excess,
  });

  /// What the period actually cost you. Never negative.
  double get netSpend => (grossSpend - applied).clamp(0.0, double.infinity);

  /// Everything friends sent back, whether or not it could be applied.
  double get totalReturned => applied + excess;
}

double _sum(Iterable<Transaction> txs) =>
    txs.fold(0.0, (sum, t) => sum + t.amount);

/// True for rows that move money without earning or spending it — a manual
/// account-to-account transfer, and ATM/CDM rows (bank → cash), which are
/// transfers with a fixed destination.
bool _isMoneyMovement(Transaction tx) =>
    tx.isTransfer || tx.category.trim().toLowerCase() == 'transfer';

/// Splits [txs] into income, gross spend, and applied/excess reimbursement.
///
/// Returns are matched to the expense they belong to before being applied:
///
///  * a return carrying an `outingId` can only reduce THAT trip's spending in
///    this period — the durable relationship the ledger already stores;
///  * a return with no trip link can only reduce non-trip spending.
///
/// Capping per relationship is what stops a ₹2,000 return against a ₹1,200
/// trip from eating ₹800 of unrelated groceries. Whatever cannot be applied
/// becomes [ReimbursementTotals.excess].
ReimbursementTotals computeReimbursementTotals(Iterable<Transaction> txs) {
  final rows = txs.where((t) => !_isMoneyMovement(t)).toList();

  double income = 0;
  final expenseByOuting = <String?, double>{};
  final returnByOuting = <String?, double>{};

  for (final tx in rows) {
    final cat = tx.category.trim().toLowerCase();
    if (cat == 'opening balance') continue;

    final outingKey = (tx.outingId?.trim().isNotEmpty ?? false)
        ? tx.outingId!.trim()
        : null;

    if (tx.isFriendReturn) {
      returnByOuting[outingKey] = (returnByOuting[outingKey] ?? 0) + tx.amount;
    } else if (tx.isExpense) {
      expenseByOuting[outingKey] = (expenseByOuting[outingKey] ?? 0) + tx.amount;
    } else {
      income += tx.amount;
    }
  }

  final grossSpend = _sum(rows.where((t) =>
      t.isExpense &&
      t.category.trim().toLowerCase() != 'opening balance'));

  double applied = 0;
  double excess = 0;
  returnByOuting.forEach((outingKey, returned) {
    final available = expenseByOuting[outingKey] ?? 0;
    final usable = returned <= available ? returned : available;
    applied += usable;
    excess += returned - usable;
  });

  return ReimbursementTotals(
    grossSpend: grossSpend,
    income: income,
    applied: applied,
    excess: excess,
  );
}

/// Pending is NOT computed here.
///
/// "What friends still owe" is a property of the split, not of the period's
/// totals: it is each member's share minus what that member has actually
/// returned. `OutingExpense.pendingAmountForMember` and
/// `Outing.pendingFromFriendsExcluding` already implement exactly that, per
/// member and clamped, so nothing in this file restates it.
///
/// Note it is measured against the friends' SHARE, not the full bill — on a
/// ₹1,200 expense split evenly with two friends, ₹800 returned leaves ₹0
/// pending even though ₹400 of the bill was always yours to pay.
