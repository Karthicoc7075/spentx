import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers/outing_provider.dart';
import '../providers/transaction_provider.dart';

/// When an outing is deleted:
///  - hide the outing AND every transaction linked to it immediately
///  - the server-side cascade_delete_outing RPC soft-deletes the same rows
///    (outing + transactions + outing_expenses + settlements) atomically, so
///    everything is fully restorable from Settings > Deleted Outings
///
/// Matches web's soft-delete cascade (deleting an outing hides its spends everywhere).
Future<void> cascadeDeleteOuting(WidgetRef ref, String outingId) async {
  final txNotifier = ref.read(transactionProvider.notifier);
  final txs = List<Transaction>.from(ref.read(transactionProvider));
  final outings = ref.read(outingProvider);

  Outing? targetOuting;
  for (final o in outings) {
    if (o.id == outingId) {
      targetOuting = o;
      break;
    }
  }
  final linkedTxIds = <String>{};
  if (targetOuting != null) {
    for (final exp in targetOuting.expenses) {
      if (exp.transactionId != null && exp.transactionId!.isNotEmpty) {
        linkedTxIds.add(exp.transactionId!);
      }
    }
  }

  for (final tx in txs) {
    if (tx.outingId == outingId || linkedTxIds.contains(tx.id)) {
      txNotifier.removeTransaction(tx.id);
    }
  }

  await ref.read(outingProvider.notifier).deleteOuting(outingId);
}
