import '../providers/outing_provider.dart';
import '../providers/transaction_provider.dart';

/// Which outings a normal transaction may be linked to.
///
/// One place for the rule so the "Add to outing" picker and anything that
/// later needs to validate a link cannot drift apart. Lives here rather than
/// on either model because it needs both, and `outing_provider` cannot import
/// `transaction_provider` (that direction is already taken).
///
/// Nothing here mutates a transaction. Linking sets `outingId` and nothing
/// else — amount, category, purpose, merchant, friend-split data and every
/// other field are untouched, and in particular a transaction's purpose is
/// never rewritten to match the trip it joins.

/// Default purpose for a row that carries none. Matches the Activity screen's
/// `_purposeOf`, so a transaction with a blank purpose is treated the same way
/// everywhere instead of matching nothing.
const String kDefaultPurpose = 'Personal';

String _effectivePurpose(String? raw) {
  final value = (raw ?? '').trim();
  return value.isEmpty ? kDefaultPurpose : value;
}

/// Whether a freshly detected SMS row is the kind of money movement an active
/// trip may adopt *by itself*, before there is a [Transaction] to judge.
///
/// Only a plain expense qualifies:
///
///  * Income is money coming in — a trip records what it cost, not what you
///    earned while it ran.
///  * A transfer moves your own money between your own accounts. ATM
///    withdrawals and cash deposits are exactly that (see
///    `Transaction.isAtmTransfer`): the cash is still yours, and it is the
///    spend you make with it that belongs to the trip.
///
/// The single deliberate exception is a friend paying you back *for this
/// trip*. That credit carries the trip's id so it can net against what the
/// trip cost you — see `outing_return_netting_test.dart` — which is what
/// [isFriendReturn] opts back in. It is not income being added as trip spend;
/// no outing expense is ever built from it.
///
/// A detected row cannot be divided yet, so the Friend Split / Purpose Split /
/// Category Split half of the rules only applies once a real transaction
/// exists — [outingAcceptsTransaction] covers that.
bool outingAcceptsDetection({
  required bool isExpense,
  required bool isTransfer,
  bool isFriendReturn = false,
}) {
  if (isTransfer) return false;
  if (isExpense) return true;
  return isFriendReturn;
}

/// Whether [outing] is a valid destination for [tx].
///
/// Two independent conditions:
///
///  1. The transaction must be undivided — see [Transaction.isSimpleTransaction].
///  2. Purposes must agree, but *only when the outing configures one*. An
///     outing with a blank purpose imposes no constraint, so it accepts any
///     eligible transaction.
bool outingAcceptsTransaction(Outing outing, Transaction tx) {
  if (!tx.isSimpleTransaction) return false;

  final outingPurpose = outing.purpose.trim();
  if (outingPurpose.isEmpty) return true;

  return _effectivePurpose(tx.purpose).toLowerCase() ==
      outingPurpose.toLowerCase();
}

/// The outings [tx] may be added to, preserving the caller's ordering.
///
/// Each outing is judged on its own purpose, so with several trips open the
/// picker offers exactly the ones that match — never a mix the user has to
/// discover is invalid by selecting it.
List<Outing> outingsAcceptingTransaction(
  List<Outing> outings,
  Transaction tx,
) {
  if (!tx.isSimpleTransaction) return const [];
  return outings.where((o) => outingAcceptsTransaction(o, tx)).toList();
}
