import '../../models/transaction.dart';
import 'outing_totals.dart';
import 'budget_spend.dart';

class _MonthBucket {
  final Map<String, double> category = {};
  final Map<String, Map<String, double>> categoryByPurpose = {};
  double income = 0;
  final Map<String, double> incomeByPurpose = {};
  double creditAlerts = 0;
  final Map<String, double> creditAlertsByPurpose = {};
}

/// One pass over the ledger, reused until the transaction list or the
/// calendar day changes. Home, budgets, and plan were each walking the
/// full list again on every rebuild.
class LedgerMonthIndex {
  LedgerMonthIndex._(this.mtdIncome, this.mtdExpense, this.mtdInvested, this._months);

  static List<Transaction>? _source;
  static String? _day;
  static LedgerMonthIndex? _cached;

  final double mtdIncome;
  final double mtdExpense;
  final double mtdInvested;
  final Map<String, _MonthBucket> _months;

  static LedgerMonthIndex of(List<Transaction> txs) {
    final now = DateTime.now();
    final day = '${now.year}-${now.month}-${now.day}';
    if (identical(_source, txs) && _day == day && _cached != null) {
      return _cached!;
    }
    final built = _build(txs, now);
    _source = txs;
    _day = day;
    _cached = built;
    return built;
  }

  static bool _investment(String category) {
    switch (category) {
      case 'investment':
      case 'investments':
      case 'stocks':
      case 'sip':
      case 'mutual fund':
      case 'mutual funds':
        return true;
      default:
        return false;
    }
  }

  static LedgerMonthIndex _build(List<Transaction> txs, DateTime now) {
    final start = DateTime(now.year, now.month, 1);
    final end = DateTime(now.year, now.month, now.day, 23, 59, 59);
    final months = <String, _MonthBucket>{};
    var mtdIncome = 0.0;
    var mtdExpense = 0.0;
    var mtdInvested = 0.0;

    for (final tx in txs) {
      if (tx.isPendingVerification) continue;
      final month = '${tx.date.year}-${tx.date.month}';
      final bucket = months.putIfAbsent(month, _MonthBucket.new);
      final purposeRaw = (tx.purpose ?? 'Personal').trim().toLowerCase();
      final purpose = purposeRaw.isEmpty ? 'personal' : purposeRaw;
      final inMtd = !tx.date.isBefore(start) && !tx.date.isAfter(end);
      final cat = tx.category.trim().toLowerCase();

      if (inMtd && _investment(cat)) {
        mtdInvested += tx.amount;
      } else if (inMtd &&
          tx.isExpense &&
          !tx.isTransfer &&
          !isOutingRollupTransaction(tx)) {
        mtdExpense += tx.amount;
      } else if (inMtd &&
          !tx.isExpense &&
          !tx.isTransfer &&
          !tx.isFriendReturn) {
        mtdIncome += tx.amount;
      }

      if (!tx.isExpense && !tx.isTransfer && !tx.isFriendReturn) {
        bucket.income += tx.amount;
        bucket.incomeByPurpose[purpose] =
            (bucket.incomeByPurpose[purpose] ?? 0) + tx.amount;
        if (tx.isAutoDetected && !tx.isSplitExpense) {
          bucket.creditAlerts += tx.amount;
          bucket.creditAlertsByPurpose[purpose] =
              (bucket.creditAlertsByPurpose[purpose] ?? 0) + tx.amount;
        }
      }

      if (!countsAsBudgetSpend(tx)) continue;
      void addSlice(String name, double amount, String slicePurpose) {
        final key = name.trim().toLowerCase();
        if (key.isEmpty || amount == 0) return;
        final purposeKey = slicePurpose.trim().toLowerCase();
        final scoped = purposeKey.isEmpty ? 'personal' : purposeKey;
        bucket.category[key] = (bucket.category[key] ?? 0) + amount;
        final byPurpose = bucket.categoryByPurpose.putIfAbsent(
          scoped,
          () => {},
        );
        byPurpose[key] = (byPurpose[key] ?? 0) + amount;
      }

      if (tx.isSplitExpense && tx.splits.isNotEmpty) {
        for (final slice in tx.splits) {
          final slicePurpose =
              slice.purposeId.trim().isEmpty ? purpose : slice.purposeId;
          addSlice(slice.categoryId, slice.amount, slicePurpose);
        }
      } else {
        addSlice(tx.category, tx.amount, purpose);
      }
    }

    return LedgerMonthIndex._(mtdIncome, mtdExpense, mtdInvested, months);
  }

  static String normalizeMonthKey(String month) {
    final parts = month.split('-');
    if (parts.length < 2) return month.trim();
    final year = int.tryParse(parts[0]);
    final mon = int.tryParse(parts[1]);
    if (year == null || mon == null) return month.trim();
    return '$year-$mon';
  }

  _MonthBucket? _bucket(String month) => _months[normalizeMonthKey(month)];

  /// Null, blank, or "all" means every purpose. Personal is its own purpose.
  bool _allPurposes(String? purposeName) {
    final purpose = purposeName?.trim().toLowerCase();
    return purpose == null || purpose.isEmpty || purpose == 'all';
  }

  bool _unscoped(String? purposeName) {
    final purpose = purposeName?.trim().toLowerCase();
    return _allPurposes(purposeName) || purpose == 'personal';
  }

  String _purposeKey(String? purposeName) {
    final purpose = (purposeName ?? '').trim().toLowerCase();
    return purpose.isEmpty ? 'personal' : purpose;
  }

  double categorySpend(String month, String category, {String? purposeName}) {
    final bucket = _bucket(month);
    if (bucket == null) return 0;
    final want = category.trim().toLowerCase();
    if (want.isEmpty) return 0;
    if (_allPurposes(purposeName)) return bucket.category[want] ?? 0;
    return bucket.categoryByPurpose[_purposeKey(purposeName)]?[want] ?? 0;
  }

  /// Every category this purpose spent in [month], including ones with no limit.
  /// Keys are lowercase category names.
  Map<String, double> categoryTotalsForPurpose(
    String month, {
    String? purposeName,
  }) {
    final bucket = _bucket(month);
    if (bucket == null) return const {};
    if (_allPurposes(purposeName)) {
      return Map<String, double>.from(bucket.category);
    }
    return Map<String, double>.from(
      bucket.categoryByPurpose[_purposeKey(purposeName)] ?? const {},
    );
  }

  double incomeFor(String month, {String? purposeName}) {
    final bucket = _bucket(month);
    if (bucket == null) return 0;
    if (_unscoped(purposeName)) return bucket.income;
    return bucket.incomeByPurpose[purposeName!.trim().toLowerCase()] ?? 0;
  }

  double creditAlertsFor(String month, {String? purposeName}) {
    final bucket = _bucket(month);
    if (bucket == null) return 0;
    final want = (purposeName ?? 'Personal').trim().toLowerCase();
    if (want.isEmpty || want == 'all') return bucket.creditAlerts;
    return bucket.creditAlertsByPurpose[want] ?? 0;
  }
}
