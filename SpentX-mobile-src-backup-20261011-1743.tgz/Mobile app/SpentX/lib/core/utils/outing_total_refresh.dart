import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../providers/outing_provider.dart';
import '../providers/transaction_provider.dart';
import '../providers/user_state_provider.dart';
import '../sync/sync_service.dart';
import 'outing_totals.dart';

/// Call after **every** outing expense add / update / delete / unlink so:
///  1. Local UI totals stay correct (banner, lists)
///  2. The web "Outing total · …" ledger row is rewritten with the real sum
///  3. Server `outings.total_spent` is updated on next push
void refreshOutingTotalSpent(Ref ref, String outingId) {
  final outing = ref
      .read(outingProvider)
      .where((o) => o.id == outingId)
      .firstOrNull;
  if (outing == null) return;

  final txs = List<Transaction>.from(ref.read(transactionProvider));
  final total = computeOutingTotalSpend(outing, txs);
  final txNotifier = ref.read(transactionProvider.notifier);

  final rollups = txs
      .where((t) => t.outingId == outingId && isOutingRollupTransaction(t))
      .toList()
    ..sort((a, b) => b.date.compareTo(a.date));

  final keep = rollups.isEmpty ? null : rollups.first;
  // Drop duplicates.
  for (var i = 1; i < rollups.length; i++) {
    txNotifier.removeTransaction(rollups[i].id);
  }

  if (total <= 0.009) {
    if (keep != null) {
      txNotifier.removeTransaction(keep.id);
    }
    _persistOutingTotalSpent(outingId, 0);
    return;
  }

  final accounts = ref.read(userStateProvider).accounts;
  final defaultAccount = accounts.where((a) => a.isCash).firstOrNull?.name ??
      accounts.where((a) => a.isActive).firstOrNull?.name ??
      'Cash';
  final category = outing.expenses.isNotEmpty
      ? outing.expenses.first.category
      : 'Travel';
  final latestDate = outing.expenses.isEmpty
      ? DateTime.now()
      : outing.expenses
          .map((e) => e.date)
          .reduce((a, b) => a.isAfter(b) ? a : b);

  // Same shape as web buildOutingRollupDraft — note prefix + merchant=outing name.
  // Tag outing-rollup is stamped on push via TransactionMap when note matches.
  final note = 'Outing total · ${outing.title}';
  final merchant = outing.title;

  if (keep != null) {
    final updated = keep.copyWith(
      merchant: merchant,
      amount: total,
      category: category,
      account: keep.account.isNotEmpty ? keep.account : defaultAccount,
      date: latestDate,
      note: note,
      outingId: outingId,
      purpose: outing.purpose,
      time: 'Trip total',
    );
    // Avoid applyOutingAutoLink side-effects; direct state write via update.
    txNotifier.updateTransaction(updated);
  } else {
    final rollup = Transaction(
      merchant: merchant,
      category: category,
      account: defaultAccount,
      paymentType: 'Online',
      time: 'Trip total',
      amount: total,
      isExpense: true,
      date: latestDate,
      purpose: outing.purpose,
      outingId: outingId,
      note: note,
    );
    // Don't auto-link again — already has outingId.
    txNotifier.addTransaction(rollup, applyOutingAutoLink: false);
  }

  _persistOutingTotalSpent(outingId, total);
}

/// Stamp totalSpent into the Hive outing row so the next server push includes it.
void _persistOutingTotalSpent(String outingId, double total) {
  if (!Hive.isBoxOpen('outings')) return;
  final box = Hive.box('outings');
  final raw = box.get(outingId);
  if (raw is! Map) return;
  final map = Map<String, dynamic>.from(raw);
  map['totalSpent'] = total;
  box.put(outingId, map);
  SyncService.queueOutingUpsert(map);
}

/// Refresh every outing that references [transactionId] (after unlink/delete).
void refreshOutingsForTransaction(Ref ref, String? transactionId, {String? outingId}) {
  final ids = <String>{};
  if (outingId != null && outingId.isNotEmpty) ids.add(outingId);
  if (transactionId != null) {
    for (final o in ref.read(outingProvider)) {
      if (o.expenses.any((e) => e.transactionId == transactionId)) {
        ids.add(o.id);
      }
    }
  }
  for (final id in ids) {
    refreshOutingTotalSpent(ref, id);
  }
}
