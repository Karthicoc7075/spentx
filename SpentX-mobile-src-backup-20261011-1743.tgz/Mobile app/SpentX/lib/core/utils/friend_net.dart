/// Running balance with one friend.
///
/// [splitSigned] uses the friend-split engine: positive means you owe them,
/// negative means they owe you. The result uses the other sign: positive
/// means they owe you.
class FriendRunningBalance {
  final double theyOweYou;
  final double youOweThem;

  const FriendRunningBalance({
    required this.theyOweYou,
    required this.youOweThem,
  });

  double get net => theyOweYou - youOweThem;
}

FriendRunningBalance friendRunningBalance({
  required double outingTheyOwe,
  required double outingYouOwe,
  required double splitSigned,
}) {
  final they = outingTheyOwe + (splitSigned < -0.01 ? -splitSigned : 0);
  final you = outingYouOwe + (splitSigned > 0.01 ? splitSigned : 0);
  return FriendRunningBalance(theyOweYou: they, youOweThem: you);
}
