import '../../models/transaction.dart';
import 'outing_totals.dart';

/// Real category spend for budgets and plans.
///
/// Skips pending rows, transfers, and display-only outing rollups (those
/// already equal the trip total). Category splits count the matching slice,
/// not the whole parent amount.
bool countsAsBudgetSpend(Transaction tx) {
  if (tx.isPendingVerification) return false;
  if (!tx.isExpense || tx.isTransfer) return false;
  if (isOutingRollupTransaction(tx)) return false;
  return true;
}

double amountForBudgetCategory(Transaction tx, String category) {
  if (!countsAsBudgetSpend(tx)) return 0;
  final want = category.trim().toLowerCase();
  if (want.isEmpty) return 0;
  if (tx.isSplitExpense && tx.splits.isNotEmpty) {
    var sum = 0.0;
    var matched = false;
    for (final slice in tx.splits) {
      if (slice.categoryId.trim().toLowerCase() != want) continue;
      sum += slice.amount;
      matched = true;
    }
    if (matched && sum > tx.amount) sum = tx.amount;
    return matched ? sum : 0;
  }
  if (tx.category.trim().toLowerCase() != want) return 0;
  return tx.amount;
}

/// Blank purpose is Personal. Used so a Personal plan does not absorb
/// another purpose, and a blank outing line still belongs to Personal.
String budgetPurposeKey(String? name) {
  final n = (name ?? '').trim().toLowerCase();
  return n.isEmpty ? 'personal' : n;
}

/// Plan months are `yyyy-MM`. Ledger dates compare on year and month only.
bool spendInPlanMonth(DateTime date, String month) {
  final parts = month.split('-');
  if (parts.length < 2) return false;
  final year = int.tryParse(parts[0]);
  final mon = int.tryParse(parts[1]);
  if (year == null || mon == null) return false;
  return date.year == year && date.month == mon;
}

/// One outing expense that may not already be a counted ledger row.
class PurposeOutingSpend {
  final String category;
  final double amount;
  final DateTime date;
  final String purpose;
  final String? transactionId;
  final bool isCancelled;

  const PurposeOutingSpend({
    required this.category,
    required this.amount,
    required this.date,
    required this.purpose,
    this.transactionId,
    this.isCancelled = false,
  });
}

/// Category spend for a plan, excluding every transaction linked to an outing.
/// Outing expenses are rendered separately as one aggregate row, so their
/// category names never leak into the category cards.
Map<String, double> purposeCategorySpendTotals({
  required Iterable<Transaction> transactions,
  required String month,
  required String? purposeName,
  Set<String> excludedTransactionIds = const {},
}) {
  final totals = <String, double>{};
  final want = budgetPurposeKey(purposeName);
  void add(String category, double amount) {
    final key = category.trim().toLowerCase();
    if (key.isEmpty || amount == 0) return;
    totals[key] = (totals[key] ?? 0) + amount;
  }

  for (final tx in transactions) {
    if (!spendInPlanMonth(tx.date, month) || !countsAsBudgetSpend(tx)) continue;
    // Outing-linked ledger rows are included by [purposeOutingTotal] instead.
    if (tx.outingId?.trim().isNotEmpty ??
        false || excludedTransactionIds.contains(tx.id)) {
      continue;
    }
    if (tx.isSplitExpense && tx.splits.isNotEmpty) {
      for (final slice in tx.splits) {
        final slicePurpose =
            slice.purposeId.trim().isEmpty ? tx.purpose : slice.purposeId;
        if (budgetPurposeKey(slicePurpose) == want) {
          add(slice.categoryId, slice.amount);
        }
      }
    } else if (budgetPurposeKey(tx.purpose) == want) {
      add(tx.category, tx.amount);
    }
  }
  return totals;
}

/// Gross outing spend for one plan purpose and month.
///
/// An outing expense linked to a ledger transaction is counted from the
/// expense row; an unlinked outing transaction is counted from the ledger.
/// This keeps the total exactly once while keeping outing categories out of
/// the category cards.
double purposeOutingTotal({
  required Iterable<Transaction> transactions,
  required Iterable<PurposeOutingSpend> outings,
  required String month,
  required String? purposeName,
}) {
  final want = budgetPurposeKey(purposeName);
  final txById = <String, Transaction>{
    for (final tx in transactions) tx.id: tx,
  };
  final linkedIds = <String>{
    for (final line in outings)
      if ((line.transactionId ?? '').trim().isNotEmpty)
        line.transactionId!.trim(),
  };
  var total = 0.0;

  for (final line in outings) {
    if (line.isCancelled || !spendInPlanMonth(line.date, month)) continue;
    if (budgetPurposeKey(line.purpose) != want || line.amount == 0) continue;
    final linked = txById[(line.transactionId ?? '').trim()];
    // Prefer a valid linked ledger row, even for older rows that do not
    // carry outing_id. The category helper excludes that row by id.
    if (linked != null && countsAsBudgetSpend(linked)) {
      if (spendInPlanMonth(linked.date, month)) {
        total += linked.amount;
      }
      continue;
    }
    total += line.amount;
  }

  for (final tx in transactions) {
    if (!spendInPlanMonth(tx.date, month) || !countsAsBudgetSpend(tx)) continue;
    if (tx.outingId?.trim().isEmpty ?? true) continue;
    if (linkedIds.contains(tx.id)) continue;
    if (budgetPurposeKey(tx.purpose) != want) continue;
    total += tx.amount;
  }
  return total;
}

/// Ledger category totals for one purpose, plus outing expenses that are
/// not already counted as a real ledger spend (rollup rows are not counted,
/// so the trip's own category lines still show).
Map<String, double> purposeSpendTotals({
  required Map<String, double> ledgerTotals,
  required Iterable<PurposeOutingSpend> outings,
  required String month,
  required String? purposeName,
  required Set<String> countedLedgerIds,
}) {
  final totals = Map<String, double>.from(ledgerTotals);
  final want = budgetPurposeKey(purposeName);
  for (final line in outings) {
    if (!spendInPlanMonth(line.date, month)) continue;
    if (budgetPurposeKey(line.purpose) != want) continue;
    final linked = (line.transactionId ?? '').trim();
    if (linked.isNotEmpty && countedLedgerIds.contains(linked)) continue;
    final key = line.category.trim().toLowerCase();
    if (key.isEmpty || line.amount == 0) continue;
    totals[key] = (totals[key] ?? 0) + line.amount;
  }
  return totals;
}
