import 'package:flutter/services.dart';

/// Parses a typed money amount ("1,250.50"). Returns null unless it is a
/// finite number > 0 — rejects NaN, Infinity, negatives and junk.
double? parsePositiveAmount(String? raw) {
  final v = double.tryParse((raw ?? '').trim().replaceAll(',', ''));
  if (v == null || !v.isFinite || v <= 0) return null;
  return v;
}

/// Digits, commas and a dot only (blocks "Infinity", "NaN", "-", "e").
final TextInputFormatter amountInputFormatter =
    FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]'));
