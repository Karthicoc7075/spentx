import '../../models/transaction.dart';
import '../providers/outing_provider.dart';

/// True for web/mobile display-only "Outing total · …" ledger rows.
/// These must never be added into trip spend (they already equal the total).
///
/// Detection (must match web `isOutingRollupTransaction`):
///  - note/description starts with "Outing total"
///  - note starts with "Your share of "
///  - Hive map may carry isOutingRollup / tags (synced from web tag)
///  - legacy: note == merchant + outing linked
bool isOutingRollupTransaction(Transaction tx) {
  if (!tx.isExpense) return false;
  final cat = tx.category.trim().toLowerCase();
  if (cat == 'settlements' || cat == 'transfer') return false;

  final note = tx.note.trim().toLowerCase();
  if (note.startsWith('outing total')) return true;
  if (note.startsWith('your share of ')) return true;

  // time field used as a local marker on mobile-created rollups
  if (tx.time.trim().toLowerCase() == 'trip total') return true;

  // Legacy web rollups: note equaled merchant (outing name) + outing linked.
  if (tx.outingId != null &&
      tx.outingId!.isNotEmpty &&
      tx.note.trim().isNotEmpty &&
      tx.note.trim() == tx.merchant.trim()) {
    return true;
  }
  return false;
}

/// Canonical trip spend — same rules as web `computeOutingRollupAmount`:
///   sum(outing_expenses) + sum(ledger expenses for outing that are not
///   rollups and not already linked via expense.transactionId)
///
/// Do **not** use autoSum(all outingId txs) + manualSum(unlinked expenses):
/// that double-counts when a web rollup row exists (2000 → 4000 / 3000).
double computeOutingTotalSpend(
  Outing outing,
  List<Transaction> ledgerTransactions,
) {
  final fromExpenses =
      outing.expenses.fold<double>(0, (sum, e) => sum + e.amount);

  final linkedLedgerIds = outing.expenses
      .map((e) => e.transactionId)
      .whereType<String>()
      .where((id) => id.isNotEmpty)
      .toSet();

  final fromLedger = ledgerTransactions.fold<double>(0, (sum, tx) {
    if (tx.outingId != outing.id) return sum;
    if (!tx.isExpense) return sum;
    if (isOutingRollupTransaction(tx)) return sum;
    if (linkedLedgerIds.contains(tx.id)) return sum;
    return sum + tx.amount;
  });

  return fromExpenses + fromLedger;
}
