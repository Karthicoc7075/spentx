import 'package:intl/intl.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../theme/soft_palette.dart';
import '../providers/transaction_provider.dart';
import '../../features/sms/v4/merchant_display_resolver.dart';

/// Formatting helpers for transaction list/detail UI.
abstract final class TransactionDisplayUtils {
  /// User-facing merchant title for list/detail screens.
  /// Shows saved friendly name when verified; raw SMS payee only when unlinked.
  static String merchantTitle(Transaction tx) =>
      MerchantDisplayResolver.titleFor(tx);

  /// Title / Itemization display precedence for list cards.
  ///
  /// Line 1 must be the transaction's own name, never the category:
  ///   1. saved title, when it is not just the category name
  ///   2. merchant, when it is not just the category name
  ///   3. raw SMS payee
  ///   4. learned/resolved merchant title (transfers keep the ATM label)
  /// A learned merchant record whose title was saved as the category used to
  /// win via [merchantTitle] and hide the real merchant. Category is only
  /// used when title, merchant, and payee are all empty.
  /// 2+ items still attach an "{n} Items" label; they do not replace the name.
  static ({String primary, String? itemsLabel}) displayTitle(Transaction tx) {
    return (
      primary: listHeadline(tx),
      itemsLabel: tx.isItemized ? '${tx.items.length} Items' : null,
    );
  }

  /// User-facing name for a transaction card. Never the category when a
  /// title, merchant, or payee exists.
  static String listHeadline(Transaction tx) {
    if (tx.isFriendReturn) {
      final m = tx.merchant.trim();
      final mLower = m.toLowerCase();
      final isGeneric = m.isEmpty ||
          mLower == 'friend returns' ||
          mLower == 'friend return' ||
          mLower == 'unknown' ||
          mLower == 'transaction';
      if (!isGeneric) {
        return m.startsWith('From ') ? m : 'From $m';
      }
      final note = tx.note.trim();
      if (note.isNotEmpty &&
          note.toLowerCase() != 'friend returns' &&
          note.toLowerCase() != 'friend return') {
        return note;
      }
      return 'Friend Repayment';
    }

    final blocked = tx.categoryNames
        .map((c) => c.trim().toLowerCase())
        .where((c) => c.isNotEmpty)
        .toSet();
    final single = tx.category.trim().toLowerCase();
    if (single.isNotEmpty) blocked.add(single);

    bool isCategoryName(String value) {
      final v = value.trim().toLowerCase();
      return v.isEmpty || blocked.contains(v);
    }

    final title = (tx.title ?? '').trim();
    if (title.isNotEmpty && !isCategoryName(title)) return title;

    final merchant = tx.merchant.trim();
    if (merchant.isNotEmpty && !isCategoryName(merchant)) return merchant;

    final payee = MerchantDisplayResolver.rawPayeeFor(tx).trim();
    if (payee.isNotEmpty &&
        payee.toLowerCase() != 'unknown' &&
        !isCategoryName(payee)) {
      return payee;
    }

    final resolved = merchantTitle(tx).trim();
    if (resolved.isNotEmpty &&
        resolved.toLowerCase() != 'unknown' &&
        !isCategoryName(resolved)) {
      return resolved;
    }

    if (title.isNotEmpty) return title;
    if (merchant.isNotEmpty) return merchant;
    if (payee.isNotEmpty && payee.toLowerCase() != 'unknown') return payee;
    if (resolved.isNotEmpty && resolved.toLowerCase() != 'unknown') {
      return resolved;
    }
    return 'Transaction';
  }

  /// List/subtitle date — uses actual [date], not legacy [time] strings like "Just now".
  static String formatListDateTime(DateTime date, {String? legacyTime}) {
    final now = DateTime.now();
    final local = date.toLocal();
    final today = DateTime(now.year, now.month, now.day);
    final txDay = DateTime(local.year, local.month, local.day);
    final yesterday = today.subtract(const Duration(days: 1));

    if (txDay == today) {
      return DateFormat('h:mm a').format(local);
    }
    if (txDay == yesterday) {
      return 'Yesterday, ${DateFormat('h:mm a').format(local)}';
    }
    if (local.year == now.year) {
      return DateFormat('dd MMM, h:mm a').format(local);
    }
    return DateFormat('dd MMM yyyy, h:mm a').format(local);
  }

  static String formatDetailDateTime(DateTime date) {
    return DateFormat('dd MMM yyyy, hh:mm a').format(date.toLocal());
  }

  /// Purpose type chip is hidden for transfers (same as add-transaction flow).
  static bool shouldShowPurposeType({
    required bool isTransfer,
    int purposeTypeCount = 2,
  }) {
    if (isTransfer) return false;
    return purposeTypeCount >= 1;
  }

  static IconData purposeTypeIcon(String purpose) {
    final p = purpose.trim().toLowerCase();
    switch (p) {
      case 'personal':
        return LucideIcons.user;
      case 'family':
        return LucideIcons.home;
      case 'business':
      case 'work':
        return LucideIcons.briefcase;
      case 'investment':
        return LucideIcons.trendingUp;
      default:
        return LucideIcons.layers;
    }
  }

  /// Formats category or purpose names list for compact card display.
  /// Shows the first item truncated to 12 chars + '...' if longer than 15 chars (e.g. "Home Improve..."),
  /// followed by "+N" if multiple items exist (e.g. "Personal +1", "Food +2").
  static String summariseNames(Iterable<String> names, {int maxLen = 12}) {
    final list = names.map((n) => n.trim()).where((n) => n.isNotEmpty).toList();
    if (list.isEmpty) return '';

    String first = list.first;
    if (first.length > 15) {
      first = '${first.substring(0, maxLen)}...';
    }

    final count = list.length;
    if (count > 1) {
      return '$first +${count - 1}';
    }
    return first;
  }

  static Color purposeTypeColor(String purpose) {
    final p = purpose.trim().toLowerCase();
    switch (p) {
      case 'personal':
        return AppColors.upi;
      case 'family':
        return AppColors.homeAccount;
      case 'business':
      case 'work':
        return SoftPalette.muted;
      default:
        return AppColors.upi;
    }
  }
}
