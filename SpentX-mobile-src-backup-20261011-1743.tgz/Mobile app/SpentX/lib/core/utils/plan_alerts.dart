/// Plan alerts for the mobile app. Pure Dart so it can be checked without
/// Flutter. Mirrors the website rules for burn rate and the daily safe limit,
/// plus a week-of-month share for each planned category.
class PlanSpend {
  final double amount;
  final String category;
  final DateTime date;

  const PlanSpend({
    required this.amount,
    required this.category,
    required this.date,
  });
}

class PlanCategoryBudget {
  final String category;
  final double planned;

  const PlanCategoryBudget({required this.category, required this.planned});
}

class PlanAlert {
  final String id;
  final String type;
  final String title;
  final String body;

  const PlanAlert({
    required this.id,
    required this.type,
    required this.title,
    required this.body,
  });
}

String _inr(double value) => '₹${value.round()}';

String _monthKey(DateTime date) =>
    '${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}';

bool _sameDay(DateTime a, DateTime b) =>
    a.year == b.year && a.month == b.month && a.day == b.day;

/// Alerts for [now]'s month. [savedDailyLimit] is the plan's own daily safe
/// limit. When it is missing, the limit is the budget still left before today,
/// spread across the days left including today.
List<PlanAlert> buildPlanAlerts({
  required double plannedTotal,
  required double? savedDailyLimit,
  required List<PlanCategoryBudget> allocations,
  required List<PlanSpend> spends,
  required DateTime now,
}) {
  if (plannedTotal <= 0) return const [];

  final month = _monthKey(now);
  final daysInMonth = DateTime(now.year, now.month + 1, 0).day;
  final day = now.day;

  final monthSpends = spends.where((s) => _monthKey(s.date) == month).toList();
  final monthSpent = monthSpends.fold<double>(0, (s, e) => s + e.amount);
  final todaySpent = monthSpends
      .where((s) => _sameDay(s.date, now))
      .fold<double>(0, (s, e) => s + e.amount);
  final spentBeforeToday = monthSpent - todaySpent;

  final alerts = <PlanAlert>[];

  final daysLeft = (daysInMonth - day + 1).clamp(1, daysInMonth);
  final explicit = savedDailyLimit ?? 0;
  final dailyLimit = explicit > 0
      ? explicit
      : (plannedTotal - spentBeforeToday).clamp(0, plannedTotal) / daysLeft;
  if (todaySpent > dailyLimit + 0.5 && dailyLimit > 0) {
    final over = todaySpent - dailyLimit;
    alerts.add(
      PlanAlert(
        id: 'daily-limit-${_monthKey(now)}-${day.toString().padLeft(2, '0')}',
        type: 'daily-limit',
        title: 'Daily limit exceeded',
        body:
            'Today\'s spending ${_inr(todaySpent)} is over the safe limit of ${_inr(dailyLimit)} by ${_inr(over)}.',
      ),
    );
  }

  if (day <= (daysInMonth / 2).ceil() && monthSpent > plannedTotal * 0.5) {
    final projected = (monthSpent / day) * daysInMonth;
    final overshoot = (projected - plannedTotal).clamp(0, double.infinity);
    final pct = ((monthSpent / plannedTotal) * 100).round();
    alerts.add(
      PlanAlert(
        id: 'burn-rate-$month',
        type: 'burn-rate',
        title: 'High burn rate',
        body:
            'You have used $pct% of this month\'s plan in $day days.${overshoot > 0 ? ' At this pace you finish ${_inr(overshoot.toDouble())} over plan.' : ''}',
      ),
    );
  }

  final weeks = ((daysInMonth - 1) ~/ 7) + 1;
  final week = (((day - 1) ~/ 7) + 1).clamp(1, weeks);
  for (final allocation in allocations) {
    if (allocation.planned <= 0) continue;
    final spent = monthSpends
        .where(
          (s) => s.category.toLowerCase() == allocation.category.toLowerCase(),
        )
        .fold<double>(0, (s, e) => s + e.amount);
    final allowance = allocation.planned * week / weeks;
    if (spent > allowance + 0.5) {
      alerts.add(
        PlanAlert(
          id: 'weekly-share-${allocation.category}-$month-w$week',
          type: 'weekly-share',
          title: '${allocation.category} is ahead of this week',
          body:
              '${allocation.category} has used ${_inr(spent)} of a ${_inr(allowance)} share for week $week of $weeks.',
        ),
      );
    }
  }

  return alerts;
}
