// Pure UPI VPA helpers — no Flutter imports, so they can be covered by the
// project's plain `dart run` test scripts.

/// True when [value] looks like a real UPI VPA (`name@handle`).
///
/// Guards what gets stored as a friend's UPI id. Credit SMS parsing often
/// yields a name fragment ("CLEARING", "SALARY") rather than a VPA, and once
/// such a fragment lands in a friend's UPI list, every unrelated sender
/// carrying the same word matches that friend.
bool isRealUpiVpa(String value) {
  final v = value.trim();
  if (v.isEmpty || v.contains(RegExp(r'\s'))) return false;
  final at = v.indexOf('@');
  return at > 0 && at < v.length - 1 && v.indexOf('@', at + 1) == -1;
}
