/// Routing rules for the signed-out half of auth.
///
/// Extracted from `app_router.dart`'s `redirect` so the decision can be
/// asserted on directly — the bug these encode was invisible while the rule
/// lived inline, because it only surfaced on the *next* sign-out.
library;

/// Whether a signed-out user must be held on `/auth/verify-email` rather than
/// being allowed to reach Welcome/login.
///
/// [pendingEmail] is the address a signup is awaiting confirmation for
/// (persisted at signup so an app kill/reopen resumes on the verify screen).
/// [lastSignedInEmail] is the account that has already completed a sign-in on
/// this device — `''` when nobody ever has.
///
/// The pending flag used to be the whole rule, and nothing on the happy path
/// ever cleared it: it is written at signup and was only deleted by the
/// verify screen's "change email" button. Confirming the address — in the
/// app, in a browser, or on the web app — left it behind. While signed in the
/// router's "signed in on an /auth route" rule masked it, so it stayed
/// invisible until the session ended; from then on every route, including the
/// `/auth?expired=true` that sign-out navigates to, was rewritten to
/// "verify your email" for an address verified long ago.
///
/// A completed sign-in for that same address is proof of confirmation —
/// Supabase does not issue a session for an unconfirmed email when the
/// project has "Confirm email" on — so it outranks the leftover flag.
bool shouldHoldForEmailVerification({
  required String? pendingEmail,
  required String lastSignedInEmail,
}) {
  final pending = pendingEmail?.trim().toLowerCase() ?? '';
  if (pending.isEmpty) return false;
  if (lastSignedInEmail.trim().toLowerCase() == pending) return false;
  return true;
}


/// Where the router should send the user, or null to stay.
///
/// [setupCompleted] is the cached mirror of `public.users.setup_completed`
/// (true = accounts + purpose saved). Null means this session has not read
/// the server yet — do not guess, let splash resolve it.
///
/// [verifiedAwaitingLogin] is set when the email-confirm link created a
/// session. That session must not enter the app; the verify screen tells
/// them to sign in.
String? authRedirect({
  required String loc,
  required bool signedIn,
  required String? pendingEmail,
  required String lastSignedInEmail,
  bool verifiedAwaitingLogin = false,
  bool? setupCompleted,
  bool permissionsPromptPending = false,
  bool pinLock = false,
}) {
  final path = loc.split('?').first;

  if (verifiedAwaitingLogin) {
    if (path == '/auth/verify-email') return null;
    return '/auth/verify-email?verified=1';
  }

  final isAuthRoute = path == '/auth' || path.startsWith('/auth/');
  final isOnboarding = path == '/onboarding';
  final isSetupExempt = path == '/' ||
      path == '/auth/reset-password' ||
      path == '/auth/callback' ||
      isOnboarding;

  // Accounts + purpose are not done. The app is closed until onboarding
  // writes users.setup_completed = true.
  if (signedIn && setupCompleted == false && !isSetupExempt) {
    return '/onboarding';
  }

  // Setup is saved, but the one-time permission ask has not been shown.
  if (signedIn &&
      setupCompleted == true &&
      permissionsPromptPending &&
      !isOnboarding &&
      path != '/' &&
      path != '/auth/reset-password' &&
      path != '/auth/callback') {
    return '/onboarding?resume=permissions';
  }

  // Finished users must not be stuck on the wizard.
  if (signedIn &&
      setupCompleted == true &&
      isOnboarding &&
      !permissionsPromptPending) {
    return pinLock ? '/lock' : '/home';
  }

  if (signedIn &&
      isAuthRoute &&
      path != '/auth/reset-password' &&
      path != '/auth/callback') {
    return '/';
  }

  if (path != '/' &&
      path != '/auth/verify-email' &&
      path != '/auth/callback' &&
      !signedIn &&
      shouldHoldForEmailVerification(
        pendingEmail: pendingEmail,
        lastSignedInEmail: lastSignedInEmail,
      )) {
    return '/auth/verify-email';
  }

  final isExempt = path == '/' || path.startsWith('/auth');
  if (!signedIn && !isExempt) return '/auth';
  return null;
}
