/// Pure bank-identification helpers — no Flutter imports, so they can be
/// covered by the project's plain `dart run` test scripts.
///
/// Used to build the "only detect SMS from banks the user actually added"
/// allowlist. Dart resolves each saved account down to a match token and a
/// last-4; the native listener only has to test whether a message contains one
/// of those, so the keyword list below never has to be mirrored in Kotlin.
library;

/// Bank identifiers that appear in Indian bank SMS.
///
/// Ambiguous short names are spelled out as multi-word entries ('yes bank',
/// not 'yes') because these are matched against free text.
const kKnownBankKeywords = <String>[
  'hdfc',
  'icici',
  'sbi',
  'axis',
  'kotak',
  'indusind',
  'idfc',
  'idbi',
  'pnb',
  'canara',
  'federal bank',
  'yes bank',
  'rbl',
  'bandhan',
  'ujjivan',
  'au small',
  'standard chartered',
  'citibank',
  'hsbc',
  'dbs',
  'bank of baroda',
  'bank of india',
  'union bank',
  'indian bank',
  'uco bank',
  'paytm',
  'airtel payments',
];

/// Words that are never a useful match token on their own.
const _genericTokens = <String>{
  'bank',
  'account',
  'acc',
  'a/c',
  'savings',
  'saving',
  'current',
  'salary',
  'card',
  'credit',
  'debit',
  'main',
  'my',
  'personal',
  'joint',
  'primary',
};

bool _containsWord(String haystack, String needle) {
  final pattern = RegExp(
    '(?<![a-z0-9])${RegExp.escape(needle)}(?![a-z0-9])',
    caseSensitive: false,
  );
  return pattern.hasMatch(haystack);
}

/// Every bank this app recognises: canonical key -> phrases that name it in
/// free text (SMS bodies and saved account names).
///
/// The canonical key is what the allowlist stores and what discovery keys use,
/// so existing keys ('hdfc', 'sbi', 'bank of india', ...) are kept unchanged.
///
/// Full names matter: "State Bank of India" used to resolve to 'bank of india'
/// (a different bank), "Punjab National Bank" to the generic word 'national',
/// "City Union Bank" to 'union bank' and "South Indian Bank" to 'indian bank'.
/// [resolveBankKey] now picks the earliest, longest phrase, so the full name
/// always beats the shorter bank name hidden inside it.
const kBankAliases = <String, List<String>>{
  'sbi': ['state bank of india', 'state bank', 'sbi', 'yono'],
  'hdfc': ['hdfc bank', 'hdfc'],
  'icici': ['icici bank', 'icici'],
  'axis': ['axis bank', 'axis'],
  'kotak': ['kotak mahindra bank', 'kotak mahindra', 'kotak bank', 'kotak'],
  'indusind': ['indusind bank', 'indusind'],
  'idfc': ['idfc first bank', 'idfc first', 'idfc'],
  'idbi': ['idbi bank', 'idbi'],
  'pnb': ['punjab national bank', 'punjab national', 'pnb'],
  'canara': ['canara bank', 'canara'],
  'federal bank': ['federal bank'],
  'yes bank': ['yes bank'],
  'rbl': ['rbl bank', 'rbl'],
  'bandhan': ['bandhan bank', 'bandhan'],
  'ujjivan': ['ujjivan small finance bank', 'ujjivan'],
  'au small': ['au small finance bank', 'au small', 'au bank'],
  'equitas': ['equitas small finance bank', 'equitas'],
  'standard chartered': ['standard chartered'],
  'citibank': ['citibank', 'citi bank'],
  'hsbc': ['hsbc'],
  'dbs': ['dbs bank', 'dbs'],
  'iob': ['indian overseas bank', 'indian overseas', 'iob'],
  'central bank of india': ['central bank of india', 'central bank', 'cent bank'],
  'city union bank': ['city union bank', 'city union', 'cub'],
  'south indian bank': ['south indian bank', 'sib'],
  'karur vysya': ['karur vysya bank', 'karur vysya', 'kvb'],
  'tamilnad mercantile': ['tamilnad mercantile bank', 'tamilnad mercantile', 'tmb'],
  'karnataka bank': ['karnataka bank'],
  'bank of maharashtra': ['bank of maharashtra', 'mahabank'],
  'punjab & sind': ['punjab & sind bank', 'punjab and sind bank', 'punjab & sind'],
  'j&k bank': ['jammu & kashmir bank', 'jammu and kashmir bank', 'j&k bank', 'jk bank'],
  'csb bank': ['csb bank'],
  'dcb bank': ['dcb bank'],
  'dhanlaxmi': ['dhanlaxmi bank', 'dhanlaxmi'],
  'esaf': ['esaf small finance bank', 'esaf'],
  'jana': ['jana small finance bank'],
  'suryoday': ['suryoday small finance bank', 'suryoday'],
  'nainital': ['nainital bank'],
  'fino': ['fino payments bank', 'fino'],
  'ippb': ['india post payments bank', 'ippb'],
  'jio payments': ['jio payments bank'],
  'bank of baroda': ['bank of baroda', 'baroda', 'bob'],
  'union bank': ['union bank of india', 'union bank'],
  'bank of india': ['bank of india', 'boi'],
  'indian bank': ['indian bank'],
  'uco bank': ['uco bank', 'uco'],
  'paytm': ['paytm payments bank', 'paytm'],
  'airtel payments': ['airtel payments bank', 'airtel payments'],
};

/// Bank label used in parsed transactions, matching the `bank` field of
/// `assets/sms/bank_sms_templates_v4.json` so template and corrected results
/// agree.
const kBankDisplayNames = <String, String>{
  'sbi': 'SBI',
  'hdfc': 'HDFC',
  'icici': 'ICICI',
  'axis': 'Axis',
  'kotak': 'Kotak',
  'indusind': 'IndusInd',
  'idfc': 'IDFC',
  'idbi': 'IDBI',
  'pnb': 'PNB',
  'canara': 'Canara',
  'federal bank': 'FederalBank',
  'yes bank': 'YES',
  'rbl': 'RBL',
  'bandhan': 'Bandhan',
  'ujjivan': 'UjjivanSmallFinanceBank',
  'au small': 'AUSmallFinanceBank',
  'equitas': 'EquitasSmallFinanceBank',
  'standard chartered': 'StandardChartered',
  'citibank': 'Citibank',
  'hsbc': 'HSBC',
  'dbs': 'DBS',
  'iob': 'IOB',
  'central bank of india': 'CentralBank',
  'city union bank': 'CityUnionBank',
  'south indian bank': 'SouthIndianBank',
  'karur vysya': 'KarurVysyaBank',
  'tamilnad mercantile': 'TamilnadMercantileBank',
  'karnataka bank': 'KarnatakaBank',
  'bank of maharashtra': 'BankOfMaharashtra',
  'punjab & sind': 'PunjabAndSindBank',
  'j&k bank': 'JammuKashmirBank',
  'csb bank': 'CSBBank',
  'dcb bank': 'DCBBank',
  'dhanlaxmi': 'DhanlaxmiBank',
  'esaf': 'ESAFSmallFinanceBank',
  'jana': 'JanaSmallFinanceBank',
  'suryoday': 'SuryodaySmallFinanceBank',
  'nainital': 'NainitalBank',
  'fino': 'FinoPaymentsBank',
  'ippb': 'IndiaPostPaymentsBank',
  'jio payments': 'JioPaymentsBank',
  'bank of baroda': 'BOB',
  'union bank': 'UnionBank',
  'bank of india': 'BankOfIndia',
  'indian bank': 'IndianBank',
  'uco bank': 'UCOBank',
  'paytm': 'PaytmPaymentsBank',
  'airtel payments': 'AirtelPaymentsBank',
};

/// DLT sender-header codes (the 6-letter part of "AX-HDFCBK-S") -> bank key.
/// Checked as prefixes, longest first. Taken from the v4 template catalog's
/// `senderIDs` plus the common live variants (ICICIT, SBIUPI, ATMSBI, ...).
const kBankSenderCodes = <String, String>{
  'HDFCBK': 'hdfc', 'HDFCBN': 'hdfc', 'HDFC': 'hdfc',
  'ICICIB': 'icici', 'ICICIT': 'icici', 'ICICIO': 'icici', 'ICICI': 'icici',
  'SBIINB': 'sbi', 'SBIPSG': 'sbi', 'SBIUPI': 'sbi', 'SBIBNK': 'sbi',
  'SBICRD': 'sbi', 'SBMSMS': 'sbi', 'CBSSBI': 'sbi', 'ATMSBI': 'sbi',
  'SBGMBS': 'sbi', 'SBYONO': 'sbi', 'SBIOTP': 'sbi', 'SBI': 'sbi',
  'AXISBK': 'axis', 'AXISBN': 'axis', 'AXISMR': 'axis', 'AXIS': 'axis',
  'KOTAKB': 'kotak', 'KOTAK': 'kotak', 'KMBL': 'kotak',
  'INDUSB': 'indusind', 'INDUSL': 'indusind',
  'IDFCFB': 'idfc', 'IDFCBK': 'idfc', 'IDFCSM': 'idfc', 'IDFC': 'idfc',
  'IDBIBN': 'idbi', 'IDBIBK': 'idbi', 'IDBI': 'idbi',
  'PNBSMS': 'pnb', 'PNBINB': 'pnb', 'PNB': 'pnb',
  'CANBNK': 'canara', 'CANABN': 'canara', 'CNRBNK': 'canara',
  'FEDBNK': 'federal bank', 'FEDBKN': 'federal bank', 'FEDFIB': 'federal bank',
  'YESBNK': 'yes bank', 'YESBKA': 'yes bank',
  'RBLBNK': 'rbl', 'RBLSMS': 'rbl',
  'BDNSMS': 'bandhan', 'BANDHN': 'bandhan',
  'UJVBNK': 'ujjivan', 'UJVSMS': 'ujjivan',
  'AUSFBN': 'au small', 'AUSFBK': 'au small', 'AUBANK': 'au small',
  'EQSFBN': 'equitas', 'EQTBNK': 'equitas',
  'SCBANK': 'standard chartered', 'STANCB': 'standard chartered',
  'CITIBK': 'citibank', 'CITIBA': 'citibank',
  'HSBCIN': 'hsbc', 'HSBC': 'hsbc',
  'DBSBNK': 'dbs', 'DBSIND': 'dbs',
  'IOBSMS': 'iob', 'IOBBKS': 'iob', 'IOBCHN': 'iob', 'IOBBNK': 'iob',
  'CBISMS': 'central bank of india', 'CENTBK': 'central bank of india',
  'CUBBNK': 'city union bank', 'CUBSMS': 'city union bank', 'CUBANK': 'city union bank',
  'SIBSMS': 'south indian bank', 'SIBBNK': 'south indian bank',
  'KVBBNK': 'karur vysya', 'KVBSMS': 'karur vysya', 'KVBANK': 'karur vysya',
  'TMBBNK': 'tamilnad mercantile', 'TMBSMS': 'tamilnad mercantile', 'TMBANK': 'tamilnad mercantile',
  'KTKBNK': 'karnataka bank', 'KTKSMS': 'karnataka bank',
  'BOMBNK': 'bank of maharashtra', 'BOMSMS': 'bank of maharashtra', 'MAHABK': 'bank of maharashtra',
  'PSBSMS': 'punjab & sind', 'PSBBNK': 'punjab & sind',
  'JKBBNK': 'j&k bank', 'JKBSMS': 'j&k bank',
  'CSBBKS': 'csb bank', 'CSBBNK': 'csb bank',
  'DCBBNK': 'dcb bank', 'DCBSMS': 'dcb bank',
  'DLBBNK': 'dhanlaxmi', 'DLBSMS': 'dhanlaxmi',
  'ESAFBK': 'esaf', 'ESAFSM': 'esaf',
  'JANABN': 'jana', 'JANASF': 'jana',
  'SRYDAY': 'suryoday', 'SRYSMS': 'suryoday',
  'NBLBNK': 'nainital', 'NBLSMS': 'nainital',
  'FINOSM': 'fino', 'FINOBK': 'fino',
  'IPPBSM': 'ippb', 'IPPBNK': 'ippb',
  'JIOPBK': 'jio payments',
  'BOBTXN': 'bank of baroda', 'BOBSMS': 'bank of baroda', 'BOBCRD': 'bank of baroda',
  'UBISMS': 'union bank', 'UNIONB': 'union bank', 'UBOI': 'union bank',
  'BOISBN': 'bank of india', 'BOISMS': 'bank of india', 'BOIIND': 'bank of india',
  'INDBNK': 'indian bank', 'INDBKS': 'indian bank',
  'UCOBSM': 'uco bank', 'UCOBNK': 'uco bank',
  'PAYTMB': 'paytm', 'PYTMBK': 'paytm',
  'AIRBNK': 'airtel payments', 'APBSMS': 'airtel payments',
};

/// Bank key for an SMS sender address such as `AX-HDFCBK-S`, `VM-SBIUPI`,
/// `JD-ICICIT-T` or `HDFCBK`. Returns '' for phone numbers and unknown
/// headers.
String bankKeyForSender(String? sender) {
  if (sender == null) return '';
  final upper = sender.trim().toUpperCase();
  if (upper.isEmpty) return '';
  // Phone numbers are never bank headers.
  if (RegExp(r'^\+?[0-9 ]+$').hasMatch(upper)) return '';
  final parts = upper
      .split(RegExp(r'[^A-Z0-9&]+'))
      .where((p) => p.isNotEmpty)
      .toList();
  // Prefer the long middle segment ("HDFCBK"), never the 2-letter operator
  // prefix ("AX") or the 1-letter DLT suffix ("S"/"T"/"P"/"G").
  final candidates = [
    ...parts.where((p) => p.length >= 4),
    if (parts.length == 1) parts.first,
  ];
  final codes = kBankSenderCodes.keys.toList()
    ..sort((a, b) => b.length.compareTo(a.length));
  for (final part in candidates) {
    for (final code in codes) {
      if (part.startsWith(code)) return kBankSenderCodes[code]!;
    }
  }
  return '';
}

/// Removes UPI handles, e-mail addresses and links before looking for a bank
/// name. Otherwise "swiggy@icici" or "rajesh@okaxis" named the payee's PSP as
/// the account's bank.
String _stripHandles(String text) => text
    .replaceAll(RegExp(r'https?://\S+', caseSensitive: false), ' ')
    .replaceAll(RegExp(r'\S+@\S+'), ' ')
    .replaceAll(RegExp(r'\b[a-z0-9.-]+\.(?:com|in|io|co)\S*', caseSensitive: false), ' ');

class _BankHit {
  final String key;
  final int start;
  final int length;
  const _BankHit(this.key, this.start, this.length);
}

List<_BankHit> _bankHits(String text) {
  final lower = _stripHandles(text.toLowerCase());
  final hits = <_BankHit>[];
  kBankAliases.forEach((key, aliases) {
    for (final alias in aliases) {
      final re = RegExp(
        '(?<![a-z0-9])${RegExp.escape(alias)}(?![a-z0-9])',
        caseSensitive: false,
      );
      for (final m in re.allMatches(lower)) {
        hits.add(_BankHit(key, m.start, m.end - m.start));
      }
    }
  });
  // Earliest first; at the same spot the longer phrase wins.
  hits.sort((a, b) {
    final byStart = a.start.compareTo(b.start);
    return byStart != 0 ? byStart : b.length.compareTo(a.length);
  });
  // Drop hits that sit inside an earlier, longer one ("bank of india" inside
  // "state bank of india").
  final kept = <_BankHit>[];
  var coveredUntil = -1;
  for (final h in hits) {
    if (h.start < coveredUntil) continue;
    kept.add(h);
    coveredUntil = h.start + h.length;
  }
  return kept;
}

/// Every bank key named in [text] (handles and links ignored).
Set<String> bankKeysInText(String text) =>
    _bankHits(text).map((h) => h.key).toSet();

/// The canonical bank keyword found in [text], or '' when none matches.
String resolveBankKey(String text) {
  final hits = _bankHits(text);
  return hits.isEmpty ? '' : hits.first.key;
}

/// Bank key for a parsed bank label ("SBI", "IndianBank", "Kotak Mahindra
/// Bank"), or '' when unknown.
String bankKeyForLabel(String label) {
  final trimmed = label.trim();
  if (trimmed.isEmpty) return '';
  final lower = trimmed.toLowerCase();
  for (final e in kBankDisplayNames.entries) {
    if (e.value.toLowerCase() == lower) return e.key;
  }
  if (kBankAliases.containsKey(lower)) return lower;
  return resolveBankKey(trimmed);
}

/// Display label for a bank key, or '' when unknown.
String bankDisplayName(String key) => kBankDisplayNames[key] ?? '';

/// All phrases that name [token] in free text. A token that is not a known
/// bank key (a custom account word like "slice") is its own only phrase.
List<String> bankAliasesFor(String token) =>
    kBankAliases[token] ?? <String>[token];

/// The token used to recognise [accountName] inside an SMS.
///
/// Prefers a known bank keyword. Falls back to the longest non-generic word in
/// the account name so custom names ("Bandhan Salary", "Slice") still match.
/// Returns '' when nothing usable remains — such an account contributes only
/// its last-4.
String bankTokenForAccountName(String accountName) {
  final resolved = resolveBankKey(accountName);
  if (resolved.isNotEmpty) return resolved;

  final words = accountName
      .toLowerCase()
      .split(RegExp(r'[^a-z0-9]+'))
      .where((w) => w.length >= 3 && !_genericTokens.contains(w))
      .toList();
  if (words.isEmpty) return '';

  words.sort((a, b) => b.length.compareTo(a.length));
  return words.first;
}

/// True when [message] mentions one of [tokens] or one of [last4s].
///
/// This is the allowlist test: a message that names none of the user's banks
/// and carries none of their account numbers is not theirs to detect. Mirrored
/// in `SpentXDetectionPrefs.kt` for the native notification listener.
bool messageMatchesAllowedBank(
  String message, {
  required List<String> tokens,
  required List<String> last4s,
  String? sender,
}) {
  if (message.isEmpty) return false;
  final lower = message.toLowerCase();

  // A bank sender header ("AX-HDFCBK-S") is the strongest signal there is:
  // only that bank can send under it.
  final senderKey = bankKeyForSender(sender);
  if (senderKey.isNotEmpty && tokens.contains(senderKey)) return true;

  final keysInText = bankKeysInText(message);
  for (final token in tokens) {
    if (token.isEmpty) continue;
    if (kBankAliases.containsKey(token)) {
      if (keysInText.contains(token)) return true;
    } else if (_containsWord(lower, token)) {
      // Custom account word ("slice") — plain word match.
      return true;
    }
  }

  for (final last4 in last4s) {
    if (last4.length < 3) continue;
    // Only in an account/card context — a bare "0034" could be anything.
    final pattern = RegExp(
      r'(?:x|\*|a/c|ac|acct|account|card|no\.?)\s*[x*]*\s*' +
          RegExp.escape(last4) +
          r'(?![0-9])',
      caseSensitive: false,
    );
    if (pattern.hasMatch(lower)) return true;
  }

  return false;
}

// ─────────────────────────────────────────────────────────────────────────
// ACCOUNT DISCOVERY
//
// The allowlist above answers "is this message the user's?". These answer
// "which account is it about?" — used to propose an account the user has not
// added yet (see docs/ACCOUNT_DISCOVERY.md). Kept here, pure, so the whole
// decision is covered by `dart run test/bank_allowlist_test.dart`.
// ─────────────────────────────────────────────────────────────────────────

/// Wallet senders that issue their own SMS. A wallet's own message suggests a
/// Wallet account; a bank SMS that merely mentions UPI does not.
const _kWalletTokens = <String>[
  'paytm',
  'phonepe',
  'amazon pay',
  'mobikwik',
  'freecharge',
  'airtel payments',
];

/// The bank keyword named anywhere in [message], or '' when none.
///
/// Companion to [bankTokenForAccountName]: that one reads a saved account
/// name, this one reads raw SMS text. Same keyword list, so a message and the
/// account it belongs to always resolve to the same token.
String bankTokenForMessage(String message) => resolveBankKey(message);

/// Last-4 digits carried by [message] **in an account or card context**, or
/// '' when the message names none.
///
/// Deliberately context-anchored, exactly like the allowlist's own last-4
/// test: a bare `0034` in an OTP or an offer code is not an account number,
/// and treating it as one is how junk accounts get proposed.
String extractAccountLast4(String message) {
  // Word alternatives need a left boundary ("ac" must not fire inside
  // "tax"); a bare mask ("XX1234", "*0034") must touch the digits. "ending"
  // covers "Debit Card ending 1234".
  final match = RegExp(
    r'(?:(?<![a-z])(?:a/c|acct|account|ac|card|no\.?|ending(?:\s+with)?)'
    r'\s*(?:no\.?)?\s*[:.]?\s*[x*]*\s*|[x*]+)(\d{3,4})(?![0-9])',
    caseSensitive: false,
  ).firstMatch(message);
  return match?.group(1) ?? '';
}

/// Account type suggested by the wording of [message] — one of the
/// [AccountModel] type strings: `Credit`, `Wallet` or `Bank`.
///
/// Bank is the default on purpose. A bare "card" is NOT read as a credit card:
/// debit-card POS messages say "card" too, and inventing a second, credit-typed
/// account for a debit card the user already has is precisely the wrong-account
/// error this feature exists to prevent. Only explicit credit wording promotes
/// the guess, and the user confirms it either way.
String inferAccountTypeFromMessage(String message) {
  final lower = message.toLowerCase();

  const creditMarkers = [
    'credit card',
    'creditcard',
    'cc bill',
    'card ending',
    'statement is generated',
    'total amount due',
    'min amount due',
    'minimum amount due',
  ];
  if (creditMarkers.any(lower.contains)) return 'Credit';
  if (RegExp(r'(?<![a-z])cc(?![a-z])').hasMatch(lower) &&
      lower.contains('card')) {
    return 'Credit';
  }

  final token = resolveBankKey(lower);
  if (token.isNotEmpty && _kWalletTokens.contains(token)) return 'Wallet';
  if (_kWalletTokens.any((w) => _containsWord(lower, w)) &&
      lower.contains('wallet')) {
    return 'Wallet';
  }

  return 'Bank';
}

/// Available balance quoted by [message], or null when it names none.
///
/// A *hint* for the discovery UI only. It is never written into an account's
/// opening balance: the balance on the latest SMS is not the balance the
/// ledger should start from, and treating it as one is what makes
/// silent-create apps report a net worth that was never true.
double? extractAvailableBalance(String message) {
  final match = RegExp(
    r'(?:avl(?:\.|able)?\s*(?:bal|balance)|available\s*(?:bal|balance)|'
    r'a/c\s*bal(?:ance)?|bal(?:ance)?)\s*(?:is|:|of)?\s*'
    r'(?:rs\.?|inr|₹)\s*([0-9,]+(?:\.[0-9]{1,2})?)',
    caseSensitive: false,
  ).firstMatch(message);
  if (match == null) return null;
  return double.tryParse(match.group(1)!.replaceAll(',', ''));
}

/// Stable key for one discovered account: `<bankToken>_<last4>`.
///
/// Deterministic, so re-seeing the same account updates the existing
/// suggestion instead of stacking a new one, and so an ignore recorded once
/// keeps matching for the life of the install.
String pendingAccountKey({required String bankToken, required String last4}) =>
    '${bankToken.trim().toLowerCase()}_${last4.trim()}';

/// Whether [message] describes an account the user has **not** added, and is
/// therefore worth proposing.
///
/// Requires BOTH a recognisable bank and a context-anchored last-4: a message
/// naming only a bank could be about an account they already have, and one
/// with no last-4 at all can never be told apart from another account at the
/// same bank. Callers must still confirm the message actually parsed as a
/// transaction before proposing anything.
///
/// [tokensWithoutLast4] are banks the user added but left the last-4 blank on
/// — onboarding allows that. Their SMS carries a last-4 the app has no saved
/// copy of, so it would otherwise look like a brand-new account forever. When
/// the bank matches one of those, the message is assumed to be theirs and no
/// suggestion is made; the alternative is nagging a user about the account
/// they just typed in.
bool isDiscoverableAccountMessage(
  String message, {
  required List<String> knownLast4s,
  required List<String> tokensWithoutLast4,
  required List<String> ignoredKeys,
}) {
  if (message.trim().isEmpty) return false;

  final token = bankTokenForMessage(message);
  if (token.isEmpty) return false;

  final last4 = extractAccountLast4(message);
  if (last4.length < 3) return false;

  // Already the user's — the ordinary allowlist path owns this message.
  if (knownLast4s.any((k) => k.trim() == last4)) return false;

  // Their bank, but they never recorded which account. Ambiguous, so silent.
  if (tokensWithoutLast4.contains(token)) return false;

  return !ignoredKeys.contains(
    pendingAccountKey(bankToken: token, last4: last4),
  );
}
