import '../../models/transaction.dart';
import '../providers/outing_provider.dart';

/// This-month (or any Activity date window) cashflow for one purpose.
///
/// Same rules as Activity's summary card in `transactions_screen.dart`:
/// [_matchingSplits] / [_scopedAmount], [_excludedFromCashflow], and the
/// outing grouping inside [_getFilteredTransactions]. Net is income minus
/// expense. Rollover is not included here — use [activityPurposeBreakdown].
///
/// Not applied here, because the Accounts "By purpose" chips are not the
/// Activity filter sheet: category, spend type, contributor, friend, and
/// account filters stay on All, and outing privacy mode is ignored.
class ActivityPurposeCashflow {
  final double income;
  final double expense;

  const ActivityPurposeCashflow({
    required this.income,
    required this.expense,
  });

  double get net => income - expense;
}

/// This-month purpose cashflow plus previous-month leftover (not chained).
///
/// Same Activity rules as [activityPurposeCashflow]. Net matches Activity:
/// income + rollover − spent.
class ActivityPurposeBreakdown {
  final double income;
  final double expense;
  final double rollover;

  const ActivityPurposeBreakdown({
    required this.income,
    required this.expense,
    required this.rollover,
  });

  /// income + rollover − spent
  double get net => income + rollover - expense;
}

String _canonicalPurpose(String p) {
  final t = p.trim();
  if (t.isEmpty) return 'Personal';
  final lower = t.toLowerCase();
  if (lower == 'personal') return 'Personal';
  if (lower == 'family' || lower == 'home') return 'Family';
  if (lower == 'office' || lower == 'work') return 'Office';
  return t;
}

bool _purposeMatches(String candidate, String target) {
  final c = _canonicalPurpose(candidate).toLowerCase();
  final t = _canonicalPurpose(target).toLowerCase();
  if (c == t) return true;
  if ((c == 'family' || c == 'home') && (t == 'family' || t == 'home')) {
    return true;
  }
  return false;
}

/// Blank purpose follows the row, then Personal. Same as Activity [_purposeOf].
String activityPurposeOf(Transaction tx) {
  final purpose = tx.purpose?.trim();
  if (purpose == null || purpose.isEmpty) {
    if (tx.splits.isNotEmpty) {
      return _splitPurpose(tx, tx.splits.first.purposeId);
    }
    return 'Personal';
  }
  return _canonicalPurpose(purpose);
}

String _splitPurpose(Transaction tx, String raw) {
  final slice = raw.trim();
  if (slice.isEmpty) return activityPurposeOf(tx);
  return _canonicalPurpose(slice);
}

/// Sum of slices whose purpose matches [purposeLower]. Category is not
/// filtered (Activity's default category is All). `0` means the row would
/// be hidden by [_matchingSplits].
double activityMatchedPurposeAmount(Transaction tx, String purposeLower) {
  if (!tx.isSplitExpense) {
    if (!_purposeMatches(activityPurposeOf(tx), purposeLower)) return 0;
    return tx.amount;
  }
  var sum = 0.0;
  for (final split in tx.splits) {
    if (_purposeMatches(_splitPurpose(tx, split.purposeId), purposeLower)) {
      sum += split.amount;
    }
  }
  return sum;
}

/// Transfers, opening balance, and friend returns. Same as
/// [_excludedFromCashflow].
bool activityExcludedFromCashflow(Transaction tx) {
  if (tx.isTransfer) return true;
  final category = tx.category.trim().toLowerCase();
  if (category == 'transfer' || category == 'opening balance') return true;
  if (tx.isFriendReturn) return true;
  return false;
}

bool _excludedFlags({
  required bool isTransfer,
  required String category,
  required bool isFriendReturn,
}) {
  if (isTransfer) return true;
  final cat = category.trim().toLowerCase();
  if (cat == 'transfer' || cat == 'opening balance') return true;
  if (isFriendReturn) return true;
  return false;
}

/// Activity's local outing-rollup check (not the stricter shared helper).
bool _isActivityOutingRollup(Transaction tx) {
  final note = tx.note.trim().toLowerCase();
  if (note.startsWith('outing total') || note.startsWith('your share of ')) {
    return true;
  }
  if (tx.time.trim().toLowerCase() == 'trip total') return true;
  if (tx.outingId != null &&
      tx.outingId!.isNotEmpty &&
      tx.note.trim().isNotEmpty &&
      tx.note.trim() == tx.merchant.trim()) {
    return true;
  }
  return false;
}

bool _inRange(DateTime date, DateTime start, DateTime end) {
  if (date.isBefore(start)) return false;
  if (date.isAfter(end.add(const Duration(days: 1)))) return false;
  return true;
}

class _OutingBucket {
  double slice = 0;
  bool isExpense = true;
  bool isTransfer = false;
  String category = '';
  bool isFriendReturn = false;
  bool seeded = false;

  void add(Transaction tx, double amount) {
    slice += amount;
    if (seeded) return;
    isExpense = tx.isExpense;
    isTransfer = tx.isTransfer;
    category = tx.category;
    isFriendReturn = tx.isFriendReturn;
    seeded = true;
  }
}

/// [rangeStart] / [rangeEnd] are inclusive calendar days, matching Activity's
/// `DateTimeRange` test (`end + 1 day`). Pass this month's first and last day
/// for the Accounts chips — that is Activity's default scope.
ActivityPurposeCashflow activityPurposeCashflow({
  required List<Transaction> transactions,
  required List<Outing> outings,
  required String purpose,
  required DateTime rangeStart,
  required DateTime rangeEnd,
}) {
  final purposeLower = purpose.trim().toLowerCase();
  final rows = <Transaction>[...transactions];

  // Unlinked trip cash is added as its own expense, purpose Personal, the
  // same way Activity builds the ledger before filtering.
  for (final outing in outings) {
    for (final expense in outing.expenses) {
      if (expense.transactionId != null) continue;
      rows.add(
        Transaction(
          id: expense.id,
          merchant: '${outing.title}: ${expense.title}',
          category: expense.category,
          account: expense.accountId ?? 'Default',
          time: 'Trip',
          amount: expense.amount,
          isExpense: true,
          date: expense.date,
          purpose: 'Personal',
          outingId: outing.id,
          note: '',
        ),
      );
    }
  }

  final buckets = <String, _OutingBucket>{};
  final returnsByOuting = <String, double>{};
  var income = 0.0;
  var expenseTotal = 0.0;

  for (final tx in rows) {
    if (!_inRange(tx.date, rangeStart, rangeEnd)) continue;
    final matched = activityMatchedPurposeAmount(tx, purposeLower);
    if (matched == 0) continue;

    if (tx.isFriendReturn) {
      final outingId = tx.outingId;
      if (outingId != null && outingId.isNotEmpty) {
        // Activity subtracts the whole return row once the row passed the
        // purpose filter, not only the matching slice.
        returnsByOuting[outingId] =
            (returnsByOuting[outingId] ?? 0) + tx.amount;
      }
      continue;
    }

    if (tx.outingId != null && tx.outingId!.isNotEmpty && tx.isExpense) {
      if (_isActivityOutingRollup(tx)) continue;
      buckets.putIfAbsent(tx.outingId!, () => _OutingBucket()).add(tx, matched);
      continue;
    }

    if (activityExcludedFromCashflow(tx)) continue;
    if (tx.isExpense) {
      expenseTotal += matched;
    } else {
      income += matched;
    }
  }

  for (final entry in buckets.entries) {
    final bucket = entry.value;
    final returned = returnsByOuting[entry.key] ?? 0;
    final netSlice = returned > 0
        ? (bucket.slice - returned).clamp(0.0, double.infinity)
        : bucket.slice;
    if (!bucket.isExpense) continue;
    if (_excludedFlags(
      isTransfer: bucket.isTransfer,
      category: bucket.category,
      isFriendReturn: bucket.isFriendReturn,
    )) {
      continue;
    }
    expenseTotal += netSlice;
  }

  return ActivityPurposeCashflow(income: income, expense: expenseTotal);
}

/// This-month income/spent for [purpose], plus that purpose's previous-month
/// leftover only (not chained). [monthStart] is the first day of the month.
ActivityPurposeBreakdown activityPurposeBreakdown({
  required List<Transaction> transactions,
  required List<Outing> outings,
  required String purpose,
  required DateTime monthStart,
}) {
  final start = DateTime(monthStart.year, monthStart.month, 1);
  final end = DateTime(monthStart.year, monthStart.month + 1, 0);
  final prevStart = DateTime(monthStart.year, monthStart.month - 1, 1);
  final prevEnd = DateTime(monthStart.year, monthStart.month, 0);

  final current = activityPurposeCashflow(
    transactions: transactions,
    outings: outings,
    purpose: purpose,
    rangeStart: start,
    rangeEnd: end,
  );
  final previous = activityPurposeCashflow(
    transactions: transactions,
    outings: outings,
    purpose: purpose,
    rangeStart: prevStart,
    rangeEnd: prevEnd,
  );

  // Same threshold as Activity [_previousMonthRollover].
  var rollover = previous.net;
  if (rollover.abs() < 0.5) rollover = 0;

  return ActivityPurposeBreakdown(
    income: current.income,
    expense: current.expense,
    rollover: rollover,
  );
}
