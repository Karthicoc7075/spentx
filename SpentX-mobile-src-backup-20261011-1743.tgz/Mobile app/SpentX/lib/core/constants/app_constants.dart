abstract final class AppConstants {
  // ── Spacing ────────────────────────────────────────────
  static const double xs = 4;
  static const double sm = 8;
  static const double md = 12;
  static const double lg = 16;
  static const double xl = 20;
  static const double xxl = 24;
  static const double xxxl = 32;
  static const double huge = 40;
  static const double massive = 48;

  // ── Border Radius ──────────────────────────────────────
  static const double radiusSm = 8;
  static const double radiusMd = 12;
  static const double radiusLg = 16;
  static const double radiusXl = 20;
  static const double radiusXxl = 24;
  static const double radiusRound = 32;
  static const double radiusSheet = 28;

  // ── Animation Durations ────────────────────────────────
  static const Duration fast = Duration(milliseconds: 150);
  static const Duration normal = Duration(milliseconds: 250);
  static const Duration slow = Duration(milliseconds: 400);
  static const Duration splash = Duration(milliseconds: 1500);
  static const Duration counter = Duration(milliseconds: 800);
  static const Duration page = Duration(milliseconds: 350);

  // ── Screen Padding ─────────────────────────────────────
  static const double screenPadding = 20;
  static const double cardPadding = 20;
  static const double sheetPadding = 24;

  // ── Icon Sizes ─────────────────────────────────────────
  static const double iconSm = 16;
  static const double iconMd = 20;
  static const double iconLg = 24;
  static const double iconXl = 28;

  // ── Currency ───────────────────────────────────────────
  static const String currency = '₹';
}
