import 'package:flutter/material.dart';
import 'app_colors.dart';
import 'app_fonts.dart';

abstract final class AppTextStyles {
  // ── Amounts (bold, iOS finance style) ──────────────────
  static TextStyle amountLarge(BuildContext context) => AppFonts.text(
    fontSize: 32,
    fontWeight: FontWeight.w700,
    letterSpacing: -1,
    color: Theme.of(context).colorScheme.onSurface,
  );

  static TextStyle amountMedium(BuildContext context) => AppFonts.text(
    fontSize: 28,
    fontWeight: FontWeight.w700,
    letterSpacing: -1.2,
    color: Theme.of(context).colorScheme.onSurface,
  );

  static TextStyle amountSmall(BuildContext context) => AppFonts.text(
    fontSize: 18,
    fontWeight: FontWeight.w700,
    letterSpacing: -0.4,
    color: Theme.of(context).colorScheme.onSurface,
  );

  static TextStyle amountDecimal(BuildContext context) => AppFonts.text(
    fontSize: 20,
    fontWeight: FontWeight.w600,
    color: Theme.of(context).brightness == Brightness.dark
        ? AppColors.darkTextSecondary
        : AppColors.lightTextSecondary,
  );

  // ── Section Labels ─────────────────────────────────────
  static TextStyle sectionLabel(BuildContext context) => AppFonts.text(
    fontSize: 11,
    fontWeight: FontWeight.w700,
    letterSpacing: 1.1,
    color: Theme.of(context).brightness == Brightness.dark
        ? AppColors.darkTextSecondary
        : AppColors.lightTextSecondary,
  );

  static TextStyle chipLabel(BuildContext context) => AppFonts.text(
    fontSize: 12,
    fontWeight: FontWeight.w600,
    color: Theme.of(context).colorScheme.onSurface,
  );

  // ── Merchant / Item Names ──────────────────────────────
  static TextStyle merchantName(BuildContext context) => AppFonts.text(
    fontSize: 15,
    fontWeight: FontWeight.w600,
    color: Theme.of(context).colorScheme.onSurface,
  );

  static TextStyle subtitle(BuildContext context) => AppFonts.text(
    fontSize: 12,
    fontWeight: FontWeight.w500,
    color: Theme.of(context).brightness == Brightness.dark
        ? AppColors.darkTextSecondary
        : AppColors.lightTextSecondary,
  );

  // ── Utility ────────────────────────────────────────────
  static TextStyle badge(Color color) => AppFonts.text(
    fontSize: 10,
    fontWeight: FontWeight.w700,
    letterSpacing: 0.4,
    color: color,
  );
}
