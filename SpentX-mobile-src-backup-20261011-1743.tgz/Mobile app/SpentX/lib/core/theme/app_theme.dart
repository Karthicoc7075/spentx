import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_colors.dart';
import 'app_fonts.dart';
import 'soft_palette.dart';
import 'spentx_tokens.dart';

class AppTheme {
  AppTheme._();

  // ── Dark Theme ─────────────────────────────────────────
  static ThemeData get darkTheme {
    final baseTextTheme = _textTheme(Brightness.dark);
    return _applyColorRule(ThemeData(
      extensions: const [SpentXColors.dark],
      useMaterial3: true,
      brightness: Brightness.dark,
      fontFamily: AppFonts.fontFamily,
      scaffoldBackgroundColor: AppColors.darkBg,
      primaryColor: AppColors.primary,
      canvasColor: AppColors.darkBg,
      colorScheme: const ColorScheme.dark(
        primary: AppColors.primary,
        secondary: AppColors.primaryLight,
        surface: AppColors.darkSurface,
        error: AppColors.expense,
        onPrimary: AppColors.onPrimary,
        onSecondary: AppColors.onPrimary,
        onSurface: AppColors.darkTextPrimary,
        outline: AppColors.darkBorder,
        surfaceContainerHighest: AppColors.darkElevated,
      ),
      textTheme: baseTextTheme,
      primaryTextTheme: baseTextTheme,
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.darkBg,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        systemOverlayStyle: SystemUiOverlayStyle.light,
        titleTextStyle: AppFonts.text(
          color: AppColors.darkTextPrimary,
          fontSize: 18,
          fontWeight: FontWeight.w700,
          letterSpacing: -0.3,
        ),
        iconTheme: const IconThemeData(color: AppColors.darkTextSecondary, size: 22),
      ),
      cardTheme: CardThemeData(
        color: AppColors.darkCard,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: AppRadius.cardR,
          side: const BorderSide(color: AppColors.darkBorder, width: AppBorders.hairline),
        ),
        margin: EdgeInsets.zero,
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: AppColors.darkSurface,
        selectedItemColor: AppColors.primary,
        unselectedItemColor: AppColors.darkTextTertiary,
        type: BottomNavigationBarType.fixed,
        elevation: 0,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primary,
          foregroundColor: AppColors.onPrimary,
          elevation: 0,
          padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 24),
          shape: RoundedRectangleBorder(borderRadius: AppRadius.tileR),
          textStyle: AppFonts.text(fontSize: 15, fontWeight: FontWeight.w700),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: AppColors.darkTextPrimary,
          side: const BorderSide(color: AppColors.darkBorder, width: 1),
          padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 24),
          shape: RoundedRectangleBorder(borderRadius: AppRadius.tileR),
          textStyle: AppFonts.text(fontSize: 15, fontWeight: FontWeight.w600),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: AppColors.primaryLight,
          textStyle: AppFonts.text(fontSize: 14, fontWeight: FontWeight.w700),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.darkElevated,
        border: OutlineInputBorder(
          borderRadius: AppRadius.tileR,
          borderSide: const BorderSide(color: AppColors.darkBorder, width: AppBorders.hairline),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: AppRadius.tileR,
          borderSide: const BorderSide(color: AppColors.darkBorder, width: AppBorders.hairline),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: AppRadius.tileR,
          borderSide: const BorderSide(color: AppColors.primary, width: AppBorders.focus),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 15),
        hintStyle: AppFonts.text(
          color: AppColors.darkTextTertiary,
          fontSize: 14,
          fontWeight: FontWeight.w400,
        ),
      ),
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: AppColors.darkCard,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(AppRadius.card)),
        ),
        showDragHandle: false,
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: AppColors.darkCard,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: AppRadius.cardR),
      ),
      dividerTheme: const DividerThemeData(
        color: AppColors.darkDivider,
        thickness: AppBorders.hairline,
        space: 0,
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: AppColors.darkCard,
        contentTextStyle: AppFonts.text(
          color: AppColors.darkTextPrimary,
          fontSize: 14,
          fontWeight: FontWeight.w600,
        ),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: AppRadius.tileR),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) return Colors.white;
          return AppColors.darkTextTertiary;
        }),
        trackColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return AppColors.primary;
          }
          return AppColors.darkElevated;
        }),
        trackOutlineColor: WidgetStateProperty.all(Colors.transparent),
      ),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: AppColors.primary,
        foregroundColor: AppColors.onPrimary,
        elevation: 4,
        shape: CircleBorder(),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: AppColors.darkElevated,
        selectedColor: AppColors.primary.withValues(alpha: 0.2),
        labelStyle: AppFonts.text(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.darkTextPrimary),
        secondaryLabelStyle: AppFonts.text(
          fontSize: 12,
          fontWeight: FontWeight.w600,
          color: AppColors.primaryLight,
        ),
        side: const BorderSide(color: AppColors.darkBorder, width: AppBorders.hairline),
        shape: RoundedRectangleBorder(borderRadius: AppRadius.pillR),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      ),
      tabBarTheme: TabBarThemeData(
        labelColor: AppColors.primary,
        unselectedLabelColor: AppColors.darkTextSecondary,
        indicatorColor: AppColors.primary,
        labelStyle: AppFonts.text(fontSize: 14, fontWeight: FontWeight.w700),
        unselectedLabelStyle: AppFonts.text(fontSize: 14, fontWeight: FontWeight.w500),
      ),
    ));
  }

  // ── Light Theme ────────────────────────────────────────
  static ThemeData get lightTheme {
    final baseTextTheme = _textTheme(Brightness.light);
    return _applyColorRule(ThemeData(
      extensions: const [SpentXColors.light],
      useMaterial3: true,
      brightness: Brightness.light,
      fontFamily: AppFonts.fontFamily,
      scaffoldBackgroundColor: AppColors.lightBg,
      primaryColor: AppColors.primary,
      canvasColor: AppColors.lightBg,
      colorScheme: const ColorScheme.light(
        primary: AppColors.primary,
        secondary: AppColors.primaryLight,
        surface: AppColors.lightSurface,
        error: AppColors.expense,
        onPrimary: AppColors.onPrimary,
        onSecondary: AppColors.onPrimary,
        onSurface: AppColors.lightTextPrimary,
        outline: AppColors.lightBorder,
        surfaceContainerHighest: AppColors.lightElevated,
      ),
      textTheme: baseTextTheme,
      primaryTextTheme: baseTextTheme,
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.lightBg,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        systemOverlayStyle: SystemUiOverlayStyle.dark,
        titleTextStyle: AppFonts.text(
          color: AppColors.lightTextPrimary,
          fontSize: 18,
          fontWeight: FontWeight.w700,
          letterSpacing: -0.3,
        ),
        iconTheme: const IconThemeData(color: AppColors.lightTextSecondary, size: 22),
      ),
      // Elevation 0, matching dark. Separation now comes from the surface ramp
      // (page ground sits below the white card) and the hairline, exactly as
      // it does in dark mode, instead of from a drop shadow that dark mode has
      // no equivalent of. Opt-in lift still exists via `SxCard(elevated: true)`.
      cardTheme: CardThemeData(
        color: AppColors.lightCard,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: AppRadius.cardR,
          side: const BorderSide(color: AppColors.lightBorder, width: AppBorders.hairline),
        ),
        margin: EdgeInsets.zero,
        surfaceTintColor: Colors.transparent,
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: AppColors.lightSurface,
        selectedItemColor: AppColors.primary,
        unselectedItemColor: AppColors.lightTextTertiary,
        type: BottomNavigationBarType.fixed,
        elevation: 0,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primary,
          foregroundColor: AppColors.onPrimary,
          elevation: 0,
          padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 24),
          shape: RoundedRectangleBorder(borderRadius: AppRadius.tileR),
          textStyle: AppFonts.text(fontSize: 15, fontWeight: FontWeight.w700),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: AppColors.lightTextPrimary,
          side: const BorderSide(color: AppColors.lightBorder, width: AppBorders.hairline),
          padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 24),
          shape: RoundedRectangleBorder(borderRadius: AppRadius.tileR),
          textStyle: AppFonts.text(fontSize: 15, fontWeight: FontWeight.w600),
        ),
      ),
      // Light mode had no textButtonTheme at all, so text buttons fell back to
      // Material defaults (14px w400, ColorScheme.primary) while dark mode's
      // were 14px w700 — the same button rendered at two different weights
      // depending on theme.
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: AppColors.primary,
          textStyle: AppFonts.text(fontSize: 14, fontWeight: FontWeight.w700),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.lightElevated,
        border: OutlineInputBorder(
          borderRadius: AppRadius.tileR,
          borderSide: const BorderSide(color: AppColors.lightBorder, width: AppBorders.hairline),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: AppRadius.tileR,
          borderSide: const BorderSide(color: AppColors.lightBorder, width: AppBorders.hairline),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: AppRadius.tileR,
          borderSide: const BorderSide(color: AppColors.primary, width: AppBorders.focus),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 15),
        hintStyle: AppFonts.text(
          color: AppColors.lightTextTertiary,
          fontSize: 14,
          fontWeight: FontWeight.w400,
        ),
      ),
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: AppColors.lightSurface,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(AppRadius.card)),
        ),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: AppColors.lightSurface,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: AppRadius.cardR),
      ),
      dividerTheme: const DividerThemeData(
        color: AppColors.lightDivider,
        thickness: AppBorders.hairline,
        space: 0,
      ),
      // Card-coloured with primary ink, same as dark. It used to invert to a
      // near-black slab with white text, which is the one component that
      // looked like a different design between the two themes.
      snackBarTheme: SnackBarThemeData(
        backgroundColor: AppColors.lightCard,
        contentTextStyle: AppFonts.text(
          color: AppColors.lightTextPrimary,
          fontSize: 14,
          fontWeight: FontWeight.w600,
        ),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: AppRadius.tileR),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) return Colors.white;
          return AppColors.lightTextTertiary;
        }),
        trackColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return AppColors.primary;
          }
          return AppColors.lightElevated;
        }),
        trackOutlineColor: WidgetStateProperty.all(Colors.transparent),
      ),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: AppColors.primary,
        foregroundColor: AppColors.onPrimary,
        elevation: 3,
        shape: CircleBorder(),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: AppColors.lightElevated,
        selectedColor: AppColors.primary.withValues(alpha: 0.12),
        labelStyle: AppFonts.text(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.lightTextPrimary),
        secondaryLabelStyle: AppFonts.text(
          fontSize: 12,
          fontWeight: FontWeight.w600,
          color: AppColors.primary,
        ),
        side: const BorderSide(color: AppColors.lightBorder, width: AppBorders.hairline),
        shape: RoundedRectangleBorder(borderRadius: AppRadius.pillR),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      ),
      tabBarTheme: TabBarThemeData(
        labelColor: AppColors.primary,
        unselectedLabelColor: AppColors.lightTextSecondary,
        indicatorColor: AppColors.primary,
        labelStyle: AppFonts.text(fontSize: 14, fontWeight: FontWeight.w700),
        unselectedLabelStyle: AppFonts.text(fontSize: 14, fontWeight: FontWeight.w500),
      ),
    ));
  }

  // ── One colour rule (SoftColors) ──────────────────────
  /// Defaults so un-styled widgets follow the app colour rule: solid
  /// #047857 for on/selected small controls (grey when off), gradient
  /// Elevated/Filled buttons (backgroundBuilder), solid #047857 FAB,
  /// outlined secondary buttons.
  static ThemeData _applyColorRule(ThemeData t) {
    final dark = t.brightness == Brightness.dark;
    const on = SoftColors.control;
    final offTrack = dark ? SoftColors.trackOffDark : SoftColors.trackOffLight;
    final offControl =
        dark ? SoftColors.controlOffDark : SoftColors.controlOffLight;
    final secondaryBg = dark ? SoftColors.darkCard : Colors.white;
    final secondaryFg = dark ? Colors.white : SoftColors.ink;
    final outline = dark ? SoftColors.darkOutline : SoftColors.outline;

    WidgetStateProperty<Color?> onOff(Color onColor, Color offColor) =>
        WidgetStateProperty.resolveWith(
          (s) => s.contains(WidgetState.selected) ? onColor : offColor,
        );
    WidgetStateProperty<Color?> solid(Color c) =>
        WidgetStateProperty.resolveWith(
          (s) => s.contains(WidgetState.disabled) ? c.withValues(alpha: 0.4) : c,
        );

    return t.copyWith(
      switchTheme: SwitchThemeData(
        thumbColor: const WidgetStatePropertyAll(Colors.white),
        trackColor: onOff(on, offTrack),
        trackOutlineColor: const WidgetStatePropertyAll(Colors.transparent),
      ),
      checkboxTheme: CheckboxThemeData(
        fillColor: onOff(on, Colors.transparent),
        checkColor: const WidgetStatePropertyAll(Colors.white),
        side: BorderSide(color: offControl, width: 1.5),
      ),
      radioTheme: RadioThemeData(fillColor: onOff(on, offControl)),
      sliderTheme: SliderThemeData(
        activeTrackColor: on,
        inactiveTrackColor: offTrack,
        thumbColor: on,
        overlayColor: on.withValues(alpha: 0.12),
        valueIndicatorColor: on,
      ),
      progressIndicatorTheme: ProgressIndicatorThemeData(
        color: on,
        linearTrackColor: offTrack,
      ),
      chipTheme: t.chipTheme.copyWith(
        selectedColor: on,
        // White label on the solid selected fill; theme ink otherwise.
        labelStyle: (t.chipTheme.labelStyle ?? const TextStyle()).copyWith(
          color: WidgetStateColor.resolveWith(
            (s) =>
                s.contains(WidgetState.selected)
                    ? Colors.white
                    : (t.chipTheme.labelStyle?.color ?? secondaryFg),
          ),
        ),
        checkmarkColor: Colors.white,
        secondaryLabelStyle: (t.chipTheme.secondaryLabelStyle ??
                const TextStyle(fontSize: 12, fontWeight: FontWeight.w600))
            .copyWith(color: Colors.white),
      ),
      segmentedButtonTheme: SegmentedButtonThemeData(
        style: ButtonStyle(
          backgroundColor: onOff(on, secondaryBg),
          foregroundColor: onOff(Colors.white, secondaryFg),
          iconColor: onOff(Colors.white, secondaryFg),
          side: WidgetStatePropertyAll(BorderSide(color: outline)),
        ),
      ),
      // Primary buttons paint the shared gradient by default.
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: t.elevatedButtonTheme.style!.copyWith(
          backgroundColor: solid(on),
          foregroundColor: const WidgetStatePropertyAll(Colors.white),
          backgroundBuilder: SoftColors.gradientBackground,
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: ButtonStyle(
          backgroundBuilder: SoftColors.gradientBackground,
          backgroundColor: solid(on),
          foregroundColor: const WidgetStatePropertyAll(Colors.white),
          elevation: const WidgetStatePropertyAll(0),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: t.outlinedButtonTheme.style!.copyWith(
          backgroundColor: WidgetStatePropertyAll(secondaryBg),
          foregroundColor: WidgetStatePropertyAll(secondaryFg),
          side: WidgetStatePropertyAll(BorderSide(color: outline)),
        ),
      ),
      floatingActionButtonTheme: t.floatingActionButtonTheme.copyWith(
        backgroundColor: on,
        foregroundColor: Colors.white,
      ),
    );
  }

  // ── Text Theme Builder ────────────────────────────────
  static TextTheme _textTheme(Brightness brightness) {
    final isLight = brightness == Brightness.light;
    final primary = isLight ? AppColors.lightTextPrimary : AppColors.darkTextPrimary;
    final secondary = isLight ? AppColors.lightTextSecondary : AppColors.darkTextSecondary;

    return TextTheme(
      displayLarge: AppFonts.text(
        color: primary, fontWeight: FontWeight.w700, fontSize: 32, letterSpacing: -1,
      ),
      displayMedium: AppFonts.text(
        color: primary, fontWeight: FontWeight.w700, fontSize: 28, letterSpacing: -0.6,
      ),
      displaySmall: AppFonts.text(
        color: primary, fontWeight: FontWeight.w700, fontSize: 24, letterSpacing: -0.5,
      ),
      headlineMedium: AppFonts.text(
        color: primary, fontWeight: FontWeight.w700, fontSize: 20, letterSpacing: -0.3,
      ),
      headlineSmall: AppFonts.text(
        color: primary, fontWeight: FontWeight.w700, fontSize: 18, letterSpacing: -0.2,
      ),
      titleLarge: AppFonts.text(
        color: primary, fontWeight: FontWeight.w700, fontSize: 17, letterSpacing: -0.2,
      ),
      titleMedium: AppFonts.text(
        color: primary, fontWeight: FontWeight.w600, fontSize: 15,
      ),
      bodyLarge: AppFonts.text(
        color: primary, fontSize: 16, fontWeight: FontWeight.w500, height: 1.45,
      ),
      bodyMedium: AppFonts.text(
        color: secondary, fontSize: 14, fontWeight: FontWeight.w500, height: 1.45,
      ),
      bodySmall: AppFonts.text(
        color: secondary, fontSize: 12, fontWeight: FontWeight.w500, height: 1.4,
      ),
      labelLarge: AppFonts.text(
        color: primary, fontWeight: FontWeight.w700, fontSize: 14,
      ),
      labelMedium: AppFonts.text(
        color: secondary, fontWeight: FontWeight.w600, fontSize: 12,
      ),
      labelSmall: AppFonts.text(
        color: secondary, fontWeight: FontWeight.w600, fontSize: 11, letterSpacing: 0.6,
      ),
    );
  }

  // ── Convenience Helpers ────────────────────────────────
  static Color cardColor(BuildContext context) {
    return Theme.of(context).brightness == Brightness.dark
        ? AppColors.darkCard
        : AppColors.lightCard;
  }

  static Color elevatedColor(BuildContext context) {
    return Theme.of(context).brightness == Brightness.dark
        ? AppColors.darkElevated
        : AppColors.lightElevated;
  }

  static Color borderColor(BuildContext context) {
    return Theme.of(context).brightness == Brightness.dark
        ? AppColors.darkBorder
        : AppColors.lightBorder;
  }

  static Color textPrimary(BuildContext context) {
    return Theme.of(context).colorScheme.onSurface;
  }

  static Color textSecondary(BuildContext context) {
    return Theme.of(context).brightness == Brightness.dark
        ? AppColors.darkTextSecondary
        : AppColors.lightTextSecondary;
  }

  static Color textTertiary(BuildContext context) {
    return Theme.of(context).brightness == Brightness.dark
        ? AppColors.darkTextTertiary
        : AppColors.lightTextTertiary;
  }

  static Color scaffoldBg(BuildContext context) {
    return Theme.of(context).scaffoldBackgroundColor;
  }
}
