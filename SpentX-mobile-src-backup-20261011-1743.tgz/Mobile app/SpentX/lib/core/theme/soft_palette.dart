import 'package:flutter/material.dart';

/// Soft UI palette — light-first SpentX surfaces.
///
/// Spec (this rewrite):
/// - bg `#eef2f6`
/// - ink `#0F172A`
/// - muted `#475569`
/// - emerald `#047857`
///
/// Dark mode keeps structural tokens aligned; only surfaces/ink flip.
abstract final class SoftPalette {
  // ── Light (canonical Soft) ─────────────────────────────
  static const bg = Color(0xFFEEF2F6);
  static const surface = Color(0xFFFFFFFF);
  static const surfaceVariant = Color(0xFFFAFBFD);
  static const card = Color(0xFFFFFFFF);
  static const border = Color(0xFFE2E8F0);
  static const divider = Color(0xFFEEF2F7);

  static const ink = Color(0xFF0F172A); // colour rule title ink
  static const muted = Color(0xFF475569);
  static const faint = Color(0xFF94A3B8);

  static const emerald = Color(0xFF047857);
  static const emeraldSoft = Color(0xFFECFDF5);
  static const onEmerald = Color(0xFFFFFFFF);
  static const mint = Color(0xFF10B981);
  static const mintDark = Color(0xFF047857);

  static const positive = Color(0xFF047857);
  static const negative = Color(0xFFDC2626);
  static const negativeSoft = Color(0xFFFEE2E2);
  static const warning = Color(0xFFB45309);
  static const warningSoft = Color(0xFFFEF3C7);

  // ── Dark (structure-matched) ───────────────────────────
  static const darkBg = Color(0xFF09090B);
  static const darkSurface = Color(0xFF18181B);
  static const darkSurfaceVariant = Color(0xFF121214);
  static const darkCard = Color(0xFF18181B);
  static const darkBorder = Color(0xFF27272A);
  static const darkDivider = Color(0xFF27272A);
  static const darkInk = Color(0xFFFFFFFF);
  static const darkMuted = Color(0xFF94A3B8);
  static const darkFaint = Color(0xFF71717A);
  static const darkEmerald = Color(0xFF34D399);
  static const darkEmeraldSoft = Color(0xFF06281E);
  static const darkOnEmerald = Color(0xFF04140E);
}


/// Dark-mode branches for screens that still hardcode light SoftPalette.
/// Light mode returns the same constants as before.
extension SoftPaletteTheme on BuildContext {
  bool get softDark => Theme.of(this).brightness == Brightness.dark;

  Color get softBg => softDark ? SoftPalette.darkBg : SoftPalette.bg;
  Color get softSurface =>
      softDark ? SoftPalette.darkSurface : SoftPalette.surface;
  Color get softSurfaceVariant =>
      softDark ? SoftPalette.darkSurfaceVariant : SoftPalette.surfaceVariant;
  Color get softCard => softDark ? SoftPalette.darkCard : SoftPalette.card;
  Color get softBorder =>
      softDark ? SoftPalette.darkBorder : SoftPalette.border;
  Color get softDivider =>
      softDark ? SoftPalette.darkDivider : SoftPalette.divider;
  Color get softInk => softDark ? SoftPalette.darkInk : SoftPalette.ink;
  Color get softMuted => softDark ? SoftPalette.darkMuted : SoftPalette.muted;
  Color get softFaint => softDark ? SoftPalette.darkFaint : SoftPalette.faint;
  Color get softEmerald =>
      softDark ? SoftPalette.darkEmerald : SoftPalette.emerald;
  Color get softEmeraldSoft =>
      softDark ? SoftPalette.darkEmeraldSoft : SoftPalette.emeraldSoft;
}

/// ONE colour rule for every mobile page (buttons, controls, text).
///
/// - Primary buttons + bottom-bar "+": [primaryGradient] (the Add
///   transaction form's Save button gradient), white text, both themes.
/// - Secondary buttons: white / #18181B with ink text and a light outline.
/// - Small controls (switch, checkbox, radio, selected chip, segmented,
///   slider, progress): solid [control] when on, grey when off. No gradient.
/// - Text: [ink] titles, [slate] secondary. Money colours stay semantic
///   (green income / [danger] spending, errors, delete).
///
/// WCAG: white on #047857 is ~5.5:1; white on every gradient stop
/// (#006C49 / #059669 / #005236) is >= 3.8:1 (bold 14px+ button text).
abstract final class SoftColors {
  static const gradientStart = Color(0xFF006C49);
  static const gradientMid = Color(0xFF059669);
  static const gradientEnd = Color(0xFF005236);
  static const primaryGradientColors = [gradientStart, gradientMid, gradientEnd];
  static const primaryGradient = LinearGradient(colors: primaryGradientColors);

  /// Solid accent for small controls when on/selected.
  static const control = Color(0xFF047857);
  static const onControl = Colors.white;
  static const controlOffLight = Color(0xFFCBD5E1);
  static const controlOffDark = Color(0xFF52525B);
  static const trackOffLight = Color(0xFFE2E8F0);
  static const trackOffDark = Color(0xFF3F3F46);

  static const ink = Color(0xFF0F172A);
  static const slate = Color(0xFF64748B);
  static const outline = Color(0xFFE2E8F0);
  static const darkCard = Color(0xFF18181B);
  static const darkOutline = Color(0xFF3F3F46);
  static const danger = Color(0xFFE11D48);

  static bool _dark(BuildContext c) =>
      Theme.of(c).brightness == Brightness.dark;
  static Color controlOff(BuildContext c) =>
      _dark(c) ? controlOffDark : controlOffLight;
  static Color trackOff(BuildContext c) =>
      _dark(c) ? trackOffDark : trackOffLight;
  static Color secondaryBg(BuildContext c) => _dark(c) ? darkCard : Colors.white;
  static Color secondaryFg(BuildContext c) => _dark(c) ? Colors.white : ink;
  static Color secondaryOutline(BuildContext c) =>
      _dark(c) ? darkOutline : outline;
  static Color title(BuildContext c) => _dark(c) ? Colors.white : ink;
  static Color secondaryText(BuildContext c) =>
      _dark(c) ? SoftPalette.darkMuted : slate;

  /// ButtonStyle.backgroundBuilder painting [primaryGradient] (faded when
  /// disabled). The button clips it to its shape (Clip.antiAlias).
  static Widget gradientBackground(
    BuildContext context,
    Set<WidgetState> states,
    Widget? child,
  ) {
    final disabled = states.contains(WidgetState.disabled);
    return DecoratedBox(
      decoration: BoxDecoration(
        gradient:
            disabled
                ? LinearGradient(
                  colors: [
                    for (final c in primaryGradientColors)
                      c.withValues(alpha: 0.45),
                  ],
                )
                : primaryGradient,
      ),
      child: child,
    );
  }

  /// Opt-out of the theme gradient for buttons that keep their own solid
  /// colour on purpose (destructive red, white-on-banner, custom painted).
  static Widget plainBackground(
    BuildContext context,
    Set<WidgetState> states,
    Widget? child,
  ) => child ?? const SizedBox.shrink();

  /// Switch colours (white thumb, solid green track on, grey off).
  static WidgetStateProperty<Color?> switchThumb(BuildContext c) =>
      WidgetStateProperty.resolveWith(
        (s) => s.contains(WidgetState.selected) ? onControl : Colors.white,
      );
  static WidgetStateProperty<Color?> switchTrack(BuildContext c) =>
      WidgetStateProperty.resolveWith(
        (s) => s.contains(WidgetState.selected) ? control : trackOff(c),
      );
}
