import 'dart:io' show Platform;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Typography for SpentX.
///
/// Plus Jakarta Sans is the only app typeface, on every platform.
///
/// Defaults lean **bold** so the UI reads like a modern iOS finance app.
abstract final class AppFonts {
  /// True when we should use the platform San Francisco stack.
  static bool get useSystemSf =>
      !kIsWeb && (Platform.isIOS || Platform.isMacOS);

  /// Theme-level font family. Plus Jakarta Sans is the only app typeface.
  static String? get fontFamily => GoogleFonts.plusJakartaSans().fontFamily;

  /// Primary text style. Defaults to semi-bold (w600) for a stronger iOS look.
  static TextStyle text({
    double? fontSize,
    FontWeight? fontWeight,
    Color? color,
    double? letterSpacing,
    double? height,
    TextDecoration? decoration,
    FontStyle? fontStyle,
    TextBaseline? textBaseline,
    double? wordSpacing,
    List<FontFeature>? fontFeatures,
  }) {
    final weight = fontWeight ?? FontWeight.w600;

    return GoogleFonts.plusJakartaSans(
      fontSize: fontSize,
      fontWeight: weight,
      color: color,
      letterSpacing: letterSpacing,
      height: height,
      decoration: decoration,
      fontStyle: fontStyle,
      textBaseline: textBaseline,
      wordSpacing: wordSpacing,
      fontFeatures: fontFeatures,
    );
  }

  /// Large titles / brand wordmarks (bold).
  static TextStyle title({
    double fontSize = 28,
    FontWeight fontWeight = FontWeight.w700,
    Color? color,
    double letterSpacing = -0.8,
    double? height,
  }) => text(
    fontSize: fontSize,
    fontWeight: fontWeight,
    color: color,
    letterSpacing: letterSpacing,
    height: height,
  );

  /// Body copy (semi-bold by default for a denser iOS feel).
  static TextStyle body({
    double fontSize = 15,
    FontWeight fontWeight = FontWeight.w500,
    Color? color,
    double? letterSpacing,
    double height = 1.4,
  }) => text(
    fontSize: fontSize,
    fontWeight: fontWeight,
    color: color,
    letterSpacing: letterSpacing,
    height: height,
  );

  /// Captions / labels.
  static TextStyle label({
    double fontSize = 12,
    FontWeight fontWeight = FontWeight.w600,
    Color? color,
    double letterSpacing = 0.2,
  }) => text(
    fontSize: fontSize,
    fontWeight: fontWeight,
    color: color,
    letterSpacing: letterSpacing,
  );
}
