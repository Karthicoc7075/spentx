import 'dart:math' as math;

import 'package:flutter/material.dart';

/// SpentX Design System — "Premium Minimal Fintech / Modular Card UI".
///
/// **Compatibility shim.** The source of truth is
/// `spentx_tokens.dart` (`SpentXColors`, read via `context.tokens`). These
/// flat constants remain only because ~4,900 call sites still reference them
/// during the migration; their *values* have been repointed at the new
/// palette, so unmigrated screens pick up the new look for free.
///
/// Because these are `const` they cannot vary by brightness. Where the spec
/// defines different light/dark values (primary, expense), the constant holds
/// the value that stays legible on *both* grounds and the theme-aware exact
/// value lives in [SpentXColors]. Migrate to `context.tokens` for precision.
abstract final class AppColors {
  // ── Brand accent ────────────────────────────────────────
  /// Primary brand dark green, accompanied by vibrant mint and mint dark accents.
  static const primary = Color(0xFF059669);
  static const primaryLight = Color(0xFF10B981);
  static const primaryDark = Color(0xFF047857);
  static const primarySurface = Color(0xFF06281E);

  /// Ink for text/icons sitting on [primary].
  static const onPrimary = Color(0xFFFFFFFF);

  // ── Semantic accents (amount text / strokes) ───────────
  /// Income / positive amounts.
  static const income = Color(0xFF059669);

  /// Expense / negative amounts — clean modern fintech red.
  static const expense = Color(0xFFDC2626);
  static const warning = Color(0xFFB45309);
  static const info = Color(0xFF3B82F6);

  // ── Semantic tint pairs (tint bg + dark on-tint text) ──
  static const incomeTint = Color(0xFFE8FAF4);
  static const onIncomeTint = Color(0xFF065F46);
  static const expenseTint = Color(0xFFFEE2E2);
  static const onExpenseTint = Color(0xFF991B1B);

  // ── Neutral & Category tint pairs ──────────────────────
  static const tintOrange = Color(0xFFFFEDD5);
  static const onTintOrange = Color(0xFFC2410C);
  static const tintGreen = Color(0xFFE8FAF4);
  static const onTintGreen = Color(0xFF065F46);
  static const tintBlue = Color(0xFFDBEAFE);
  static const onTintBlue = Color(0xFF1D4ED8);
  static const tintIndigo = Color(0xFFE0E7FF);
  static const onTintIndigo = Color(0xFF4338CA);
  static const tintPurple = Color(0xFFEDE9FE);
  static const onTintPurple = Color(0xFF6D28D9);
  static const tintPink = Color(0xFFFCE7F3);
  static const onTintPink = Color(0xFFBE185D);
  static const tintAmber = Color(0xFFFEF3C7);
  static const onTintAmber = Color(0xFFB45309);

  /// Dark ink for text/icons on any pastel tint.
  static const onPastel = Color(0xFF020617);

  /// Maps a tint background to its paired dark on-tint shade.
  static Color onTint(Color tint) {
    if (tint == incomeTint) return onIncomeTint;
    if (tint == expenseTint) return onExpenseTint;
    if (tint == tintOrange) return onTintOrange;
    if (tint == tintGreen) return onTintGreen;
    if (tint == tintBlue) return onTintBlue;
    if (tint == tintIndigo) return onTintIndigo;
    if (tint == tintPurple) return onTintPurple;
    if (tint == tintPink) return onTintPink;
    if (tint == tintAmber) return onTintAmber;
    return onPastel;
  }

  /// Readable ink for text/icons sitting on a **saturated accent fill**.
  static Color onAccent(Color fill) {
    return _contrast(onPrimary, fill) >=
            _contrast(const Color(0xFFFFFFFF), fill)
        ? onPrimary
        : const Color(0xFFFFFFFF);
  }

  static double _relativeLuminance(Color c) {
    double channel(double v) =>
        v <= 0.03928
            ? v / 12.92
            : math.pow((v + 0.055) / 1.055, 2.4).toDouble();
    return 0.2126 * channel(c.r) +
        0.7152 * channel(c.g) +
        0.0722 * channel(c.b);
  }

  static double _contrast(Color a, Color b) {
    final la = _relativeLuminance(a);
    final lb = _relativeLuminance(b);
    final hi = la > lb ? la : lb;
    final lo = la > lb ? lb : la;
    return (hi + 0.05) / (lo + 0.05);
  }

  // ── Fintech brand colors ───────────────────────────────
  static const mint = Color(0xFF10B981);
  static const mintDark = Color(0xFF047857);
  static const mintLight = Color(0xFFECFDF5);
  static const mintSubtle = Color(0xFFECFDF5);
  static const charcoal = Color(0xFF020617);
  static const slateBg = Color(0xFFEEF2F6);
  static const cardBorder = Color(0xFFE9EEF0);

  // ── Legacy aliases ──────────────────────────────────────
  static const incomeBg = incomeTint;
  static const expenseBg = expenseTint;
  static const warningBg = tintAmber;
  static const infoBg = tintBlue;
  static const blush = expenseTint;
  static const butter = tintAmber;
  static const sky = tintBlue;

  // ── Account Types ──────────────────────────────────────
  static const ownAccount = Color(0xFF10B981);
  static const homeAccount = Color(0xFFF59E0B);
  static const upi = Color(0xFF8B5CF6);
  static const autoDetected = Color(0xFF3B82F6);

  // ── Category tints ─────────────────────────────────────
  static const food = tintOrange;
  static const shopping = tintAmber;
  static const transport = tintIndigo;
  static const entertainment = tintPurple;
  static const bills = tintGreen;
  static const health = tintPink;
  static const education = tintBlue;
  static const salary = tintGreen;
  static const investment = tintAmber;
  static const rent = tintPurple;

  // ── Dark mode ───────────────────────────────────────────
  static const darkBg = Color(0xFF09090B);
  static const darkSurface = Color(0xFF18181B);
  static const darkCard = Color(0xFF18181B);
  static const darkElevated = Color(0xFF121214);
  static const darkBorder = Color(0xFF27272A);
  static const darkDivider = Color(0xFF27272A);
  static const darkTextPrimary = Color(0xFFFFFFFF);
  static const darkTextSecondary = Color(0xFF94A3B8);
  static const darkTextTertiary = Color(0xFF71717A);

  // ── Light mode ──────────────────────────────────────────
  static const lightBg = Color(0xFFEEF2F6);
  static const lightSurface = Color(0xFFFFFFFF);
  static const lightCard = Color(0xFFFFFFFF);
  static const lightElevated = Color(0xFFFAFBFD);
  static const lightBorder = Color(0xFFE2E8F0);
  static const lightDivider = Color(0xFFEEF2F7);
  static const lightTextPrimary = Color(0xFF0F172A);
  static const lightTextSecondary = Color(0xFF475569);
  static const lightTextTertiary = Color(0xFF94A3B8);
}

/// Brightness-aware surface tokens for screens that don't thread
/// `isDark` through every widget.
/// Static, context-free surface accessors. Kept for the ~1,000 call sites
/// that read colour outside a build context; prefer `context.tokens`, which
/// is driven by the real theme instead of this mutable flag.
class AppSurface {
  static bool isDark = false;
  static Color get bg => isDark ? AppColors.darkBg : AppColors.lightBg;
  static Color get card => isDark ? AppColors.darkCard : AppColors.lightCard;
  static Color get elevated =>
      isDark ? AppColors.darkElevated : AppColors.lightElevated;
  static Color get border =>
      isDark ? AppColors.darkBorder : AppColors.lightBorder;
  static Color get divider =>
      isDark ? AppColors.darkDivider : AppColors.lightDivider;
  static Color get surface =>
      isDark ? AppColors.darkSurface : AppColors.lightSurface;
  static Color get text =>
      isDark ? AppColors.darkTextPrimary : AppColors.lightTextPrimary;
  static Color get subText =>
      isDark ? AppColors.darkTextSecondary : AppColors.lightTextSecondary;
  static Color get faint =>
      isDark ? AppColors.darkTextTertiary : AppColors.lightTextTertiary;
}
