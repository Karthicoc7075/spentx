import 'package:flutter/material.dart';

import 'app_fonts.dart';
import 'soft_palette.dart';

/// SpentX Design System — "Premium Minimal Fintech / Modular Card UI".
///
/// This is the single source of truth for colour in the app. Components must
/// read tokens from here (`context.tokens`) and must never hardcode a hex
/// value or branch on `isDark` themselves — that branching is what makes a
/// codebase drift into two different-looking UIs. One design, two themes:
/// only surface/border/text values change between modes, never the layout,
/// the hierarchy, the spacing, or the accent.
@immutable
class SpentXColors extends ThemeExtension<SpentXColors> {
  const SpentXColors({
    required this.background,
    required this.surface,
    required this.surfaceVariant,
    required this.card,
    required this.border,
    required this.divider,
    required this.primary,
    required this.primarySoft,
    required this.onPrimary,
    required this.textPrimary,
    required this.textSecondary,
    required this.textDisabled,
    required this.positive,
    required this.negative,
    required this.negativeSoft,
    required this.warning,
    required this.warningSoft,
    required this.scrim,
    required this.disabled,
    required this.pressed,
    this.mint = SoftPalette.mint,
    this.mintLight = SoftPalette.emeraldSoft,
  });

  /// Screen background — the furthest-back layer.
  final Color background;

  /// Raised chrome that is not a card (app bars, sheets, nav bars).
  final Color surface;

  /// Recessed fill for inputs and inner tiles sitting on a [card].
  final Color surfaceVariant;

  /// The primary structural unit of this design system.
  final Color card;

  /// 1px hairline around a container. Structure comes from borders, not shadows.
  final Color border;

  /// Rule *inside* a container (list separators, metric dividers).
  final Color divider;

  /// Brand green. Reserved for CTAs, active states, progress fills.
  final Color primary;

  /// Low-saturation green wash for badges/icon tints.
  final Color primarySoft;

  /// Ink used on top of [primary].
  final Color onPrimary;

  final Color textPrimary;
  final Color textSecondary;

  /// Muted/tertiary ink — placeholders, timestamps, inactive nav labels.
  final Color textDisabled;

  /// Positive money and success states.
  final Color positive;

  /// Negative money — restrained, never the same weight as the accent.
  final Color negative;

  /// Soft red wash behind expense badges.
  final Color negativeSoft;

  /// Caution states.
  final Color warning;

  /// Soft amber wash pairing with [warning].
  final Color warningSoft;

  /// Modal scrim behind sheets and dialogs.
  final Color scrim;

  /// Disabled fill.
  final Color disabled;

  /// Overlay tint for pressed/hovered states.
  final Color pressed;

  /// Vibrant mint accent.
  final Color mint;

  /// Ultra-soft mint background wash.
  final Color mintLight;

  // ── Aliases & Convenience Getters ──────────────────────────
  Color get field => surfaceVariant;
  Color get success => positive;
  Color get error => negative;
  Color get primaryContainer => primarySoft;
  Color get mintDark => const Color(0xFF00A868);
  Color get charcoal => const Color(0xFF0F172A);
  Color get slateBg => background;
  Color get cardBorder => border;

  /// Dark mode fintech palette.
  static const dark = SpentXColors(
    background: SoftPalette.darkBg,
    surface: SoftPalette.darkSurface,
    surfaceVariant: SoftPalette.darkSurfaceVariant,
    card: SoftPalette.darkCard,
    border: SoftPalette.darkBorder,
    divider: SoftPalette.darkDivider,
    primary: SoftPalette.darkEmerald,
    primarySoft: SoftPalette.darkEmeraldSoft,
    onPrimary: SoftPalette.darkOnEmerald,
    textPrimary: SoftPalette.darkInk,
    textSecondary: SoftPalette.darkMuted,
    textDisabled: SoftPalette.darkFaint,
    positive: SoftPalette.darkEmerald,
    negative: Color(0xFFEF4444),
    negativeSoft: Color(0xFF3A1C1F),
    warning: Color(0xFFF59E0B),
    warningSoft: Color(0xFF3A2A0D),
    scrim: Color(0xCC000000),
    disabled: Color(0xFF3F3F46),
    pressed: Color(0x14FFFFFF),
    mint: SoftPalette.darkEmerald,
    mintLight: SoftPalette.darkEmeraldSoft,
  );

  /// Clean, modern fintech light palette matching the uploaded HTML and reference designs.
  static const light = SpentXColors(
    background: SoftPalette.bg,
    surface: SoftPalette.surface,
    surfaceVariant: SoftPalette.surfaceVariant,
    card: SoftPalette.card,
    border: SoftPalette.border,
    divider: SoftPalette.divider,
    primary: SoftPalette.emerald,
    primarySoft: SoftPalette.emeraldSoft,
    onPrimary: SoftPalette.onEmerald,
    textPrimary: SoftPalette.ink,
    textSecondary: SoftPalette.muted,
    textDisabled: SoftPalette.faint,
    positive: SoftPalette.positive,
    negative: SoftPalette.negative,
    negativeSoft: SoftPalette.negativeSoft,
    warning: SoftPalette.warning,
    warningSoft: SoftPalette.warningSoft,
    scrim: Color(0x66000000),
    disabled: Color(0xFFCBD5E1),
    pressed: Color(0x0D000000),
    mint: SoftPalette.mint,
    mintLight: SoftPalette.emeraldSoft,
  );

  /// Signed-amount colour. The one place the +/- colour rule is decided, so
  /// no screen has to re-derive it (and get it wrong for transfers).
  Color amount({required bool isNegative}) => isNegative ? negative : positive;

  @override
  SpentXColors copyWith({
    Color? background,
    Color? surface,
    Color? surfaceVariant,
    Color? card,
    Color? border,
    Color? divider,
    Color? primary,
    Color? primarySoft,
    Color? onPrimary,
    Color? textPrimary,
    Color? textSecondary,
    Color? textDisabled,
    Color? positive,
    Color? negative,
    Color? negativeSoft,
    Color? warning,
    Color? warningSoft,
    Color? scrim,
    Color? disabled,
    Color? pressed,
    Color? mint,
    Color? mintLight,
  }) {
    return SpentXColors(
      background: background ?? this.background,
      surface: surface ?? this.surface,
      surfaceVariant: surfaceVariant ?? this.surfaceVariant,
      card: card ?? this.card,
      border: border ?? this.border,
      divider: divider ?? this.divider,
      primary: primary ?? this.primary,
      primarySoft: primarySoft ?? this.primarySoft,
      onPrimary: onPrimary ?? this.onPrimary,
      textPrimary: textPrimary ?? this.textPrimary,
      textSecondary: textSecondary ?? this.textSecondary,
      textDisabled: textDisabled ?? this.textDisabled,
      positive: positive ?? this.positive,
      negative: negative ?? this.negative,
      negativeSoft: negativeSoft ?? this.negativeSoft,
      warning: warning ?? this.warning,
      warningSoft: warningSoft ?? this.warningSoft,
      scrim: scrim ?? this.scrim,
      disabled: disabled ?? this.disabled,
      pressed: pressed ?? this.pressed,
      mint: mint ?? this.mint,
      mintLight: mintLight ?? this.mintLight,
    );
  }

  @override
  SpentXColors lerp(ThemeExtension<SpentXColors>? other, double t) {
    if (other is! SpentXColors) return this;
    return SpentXColors(
      background: Color.lerp(background, other.background, t)!,
      surface: Color.lerp(surface, other.surface, t)!,
      surfaceVariant: Color.lerp(surfaceVariant, other.surfaceVariant, t)!,
      card: Color.lerp(card, other.card, t)!,
      border: Color.lerp(border, other.border, t)!,
      divider: Color.lerp(divider, other.divider, t)!,
      primary: Color.lerp(primary, other.primary, t)!,
      primarySoft: Color.lerp(primarySoft, other.primarySoft, t)!,
      onPrimary: Color.lerp(onPrimary, other.onPrimary, t)!,
      textPrimary: Color.lerp(textPrimary, other.textPrimary, t)!,
      textSecondary: Color.lerp(textSecondary, other.textSecondary, t)!,
      textDisabled: Color.lerp(textDisabled, other.textDisabled, t)!,
      positive: Color.lerp(positive, other.positive, t)!,
      negative: Color.lerp(negative, other.negative, t)!,
      negativeSoft: Color.lerp(negativeSoft, other.negativeSoft, t)!,
      warning: Color.lerp(warning, other.warning, t)!,
      warningSoft: Color.lerp(warningSoft, other.warningSoft, t)!,
      scrim: Color.lerp(scrim, other.scrim, t)!,
      disabled: Color.lerp(disabled, other.disabled, t)!,
      pressed: Color.lerp(pressed, other.pressed, t)!,
      mint: Color.lerp(mint, other.mint, t)!,
      mintLight: Color.lerp(mintLight, other.mintLight, t)!,
    );
  }
}

/// Corner radii. Soft Soft Neo-Fintech (r~24 cards, rounded-full pills).
abstract final class AppRadius {
  static const card = 24.0;
  static const tile = 16.0;
  static const input = 14.0;
  static const button = 14.0;
  static const iconButton = 12.0;
  static const pill = 999.0;

  static const cardR = BorderRadius.all(Radius.circular(card));
  static const tileR = BorderRadius.all(Radius.circular(tile));
  static const inputR = BorderRadius.all(Radius.circular(input));
  static const buttonR = BorderRadius.all(Radius.circular(button));
  static const iconButtonR = BorderRadius.all(Radius.circular(iconButton));
  static const pillR = BorderRadius.all(Radius.circular(pill));
}

/// Curated fintech shadows for cards, bento components, and floating buttons.
abstract final class AppShadows {
  /// Subtle elevation for cards and tiles.
  static const subtle = [
    BoxShadow(
      color: Color(0x0F050D1A),
      blurRadius: 24,
      offset: Offset(0, 8),
    ),
  ];

  /// Rich elevation for Bento / featured containers.
  static const bento = [
    BoxShadow(
      color: Color(0x0F0F172A),
      blurRadius: 24,
      offset: Offset(0, 8),
      spreadRadius: -6,
    ),
    BoxShadow(
      color: Color(0x050F172A),
      blurRadius: 6,
      offset: Offset(0, 2),
      spreadRadius: -1,
    ),
  ];

  /// Glowing brand emerald shadow for Hero Bento card.
  static const heroGlow = [
    BoxShadow(
      color: Color(0x3810B981),
      blurRadius: 36,
      offset: Offset(0, 18),
      spreadRadius: -12,
    ),
    BoxShadow(
      color: Color(0x0F0F172A),
      blurRadius: 16,
      offset: Offset(0, 4),
      spreadRadius: -2,
    ),
  ];

  /// Glowing action shadow for Floating Action Button.
  static const floatingBtn = [
    BoxShadow(
      color: Color(0x8000D084),
      blurRadius: 24,
      offset: Offset(0, 10),
      spreadRadius: -4,
    ),
  ];

  /// Soft elevation for bottom bar.
  static const bar = [
    BoxShadow(
      color: Color(0x0A0F172A),
      blurRadius: 20,
      offset: Offset(0, -4),
      spreadRadius: 0,
    ),
  ];
}

/// Stroke widths. One hairline weight for the whole app: the `Sx*` primitives
/// already drew every border at 1.0 while `ThemeData` drew cards, inputs,
/// chips and dividers at 0.8, so a Material card and an [AppRadius]-built card
/// sitting side by side had visibly different edges.
abstract final class AppBorders {
  /// The only border width in the design system.
  static const hairline = 1.0;

  /// Emphasised edge — focused inputs, active selection rings.
  static const focus = 1.5;
}

/// 4-based spacing scale. Use these instead of arbitrary numbers so vertical
/// rhythm stays consistent across screens.
abstract final class AppSpacing {
  static const xxs = 4.0;
  static const xs = 8.0;
  static const sm = 12.0;
  static const md = 16.0;
  static const lg = 20.0;
  static const xl = 24.0;
  static const xxl = 32.0;

  /// Screen horizontal padding.
  static const screenH = 20.0;

  /// Default inner padding for a card.
  static const cardPad = 20.0;

  /// Vertical gap between card-level sections.
  static const sectionGap = 20.0;
}

/// Type scale. Sizes/weights are fixed by the design system; colour is passed
/// in from tokens by the caller.
abstract final class AppType {
  static TextStyle display(Color c) => AppFonts.text(
    fontSize: 32,
    fontWeight: FontWeight.w700,
    color: c,
    letterSpacing: -0.8,
    height: 1.1,
  );

  static TextStyle title(Color c) => AppFonts.text(
    fontSize: 24,
    fontWeight: FontWeight.w700,
    color: c,
    letterSpacing: -0.5,
    height: 1.15,
  );

  static TextStyle section(Color c) => AppFonts.text(
    fontSize: 18,
    fontWeight: FontWeight.w600,
    color: c,
    letterSpacing: -0.2,
    height: 1.2,
  );

  static TextStyle body(Color c) => AppFonts.text(
    fontSize: 15,
    fontWeight: FontWeight.w400,
    color: c,
    height: 1.4,
  );

  static TextStyle label(Color c) => AppFonts.text(
    fontSize: 13,
    fontWeight: FontWeight.w500,
    color: c,
    height: 1.3,
  );

  static TextStyle caption(Color c) => AppFonts.text(
    fontSize: 12,
    fontWeight: FontWeight.w400,
    color: c,
    height: 1.3,
  );

  /// Money. Tabular figures so digits don't shift width as values animate or
  /// change, and the heaviest weight on screen — financial figures are the
  /// reason the user opened the app.
  static TextStyle money(
    Color c, {
    double size = 15,
    FontWeight weight = FontWeight.w700,
  }) => AppFonts.text(
    fontSize: size,
    fontWeight: weight,
    color: c,
    letterSpacing: -0.3,
    height: 1.1,
    fontFeatures: const [FontFeature.tabularFigures()],
  );
}

extension SpentXThemeX on BuildContext {
  /// The active colour tokens. Falls back to the dark palette if the
  /// extension is somehow missing so a widget can never crash on a null token.
  SpentXColors get tokens =>
      Theme.of(this).extension<SpentXColors>() ?? SpentXColors.dark;

  bool get isDarkMode => Theme.of(this).brightness == Brightness.dark;
}
