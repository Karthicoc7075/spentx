import 'package:hive_flutter/hive_flutter.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/local/hive_service.dart';

class PendingVerificationRecord {
  final String transactionId;
  final DateTime createdAt;
  final bool notificationShown;
  final String status; // pending | verified | ignored
  final double amount;
  final String merchant;
  final String bank;
  final String type;

  const PendingVerificationRecord({
    required this.transactionId,
    required this.createdAt,
    required this.notificationShown,
    required this.status,
    required this.amount,
    required this.merchant,
    required this.bank,
    required this.type,
  });

  Map<String, dynamic> toMap() => {
        'transactionId': transactionId,
        'createdAt': createdAt.toIso8601String(),
        'notificationShown': notificationShown,
        'status': status,
        'amount': amount,
        'merchant': merchant,
        'bank': bank,
        'type': type,
      };

  factory PendingVerificationRecord.fromMap(Map<dynamic, dynamic> m) {
    return PendingVerificationRecord(
      transactionId: m['transactionId']?.toString() ?? '',
      createdAt: DateTime.tryParse(m['createdAt']?.toString() ?? '') ?? DateTime.now(),
      notificationShown: m['notificationShown'] == true,
      status: m['status']?.toString() ?? 'pending',
      amount: (m['amount'] as num? ?? 0).toDouble(),
      merchant: m['merchant']?.toString() ?? '',
      bank: m['bank']?.toString() ?? '',
      type: m['type']?.toString() ?? 'debit',
    );
  }
}

class PendingVerificationHistoryService {
  static const boxName = 'pending_verification_history';
  static const _listKey = 'items';

  static Box get _box => Hive.box(boxName);

  static Future<void> ensureOpen() async {
    if (!Hive.isBoxOpen(boxName)) {
      await SecureHive.openBox(boxName);
    }
  }

  static List<PendingVerificationRecord> all() {
    if (!Hive.isBoxOpen(boxName)) return [];
    final raw = _box.get(_listKey, defaultValue: <dynamic>[]) as List;
    return raw
        .map((e) => PendingVerificationRecord.fromMap(Map<dynamic, dynamic>.from(e as Map)))
        .toList();
  }

  static List<PendingVerificationRecord> pending() =>
      all().where((r) => r.status == 'pending').toList();

  static List<PendingVerificationRecord> verified() =>
      all().where((r) => r.status == 'verified').toList();

  static Future<void> recordPending({
    required String transactionId,
    required double amount,
    required String merchant,
    required String bank,
    required String type,
    bool notificationShown = true,
  }) async {
    await ensureOpen();
    final items = all();
    final idx = items.indexWhere((r) => r.transactionId == transactionId);
    final record = PendingVerificationRecord(
      transactionId: transactionId,
      createdAt: idx >= 0 ? items[idx].createdAt : DateTime.now(),
      notificationShown: notificationShown,
      status: 'pending',
      amount: amount,
      merchant: merchant,
      bank: bank,
      type: type,
    );
    final list = items.map((r) => r.toMap()).toList();
    if (idx >= 0) {
      list[idx] = record.toMap();
    } else {
      list.insert(0, record.toMap());
    }
    await _box.put(_listKey, list);
  }

  static Future<void> markVerified(String transactionId) async {
    await _updateStatus(transactionId, 'verified');
  }

  static Future<void> markIgnored(String transactionId) async {
    await _updateStatus(transactionId, 'ignored');
  }

  static Future<void> _updateStatus(String transactionId, String status) async {
    await ensureOpen();
    final items = all();
    final list = items.map((r) {
      if (r.transactionId == transactionId) {
        return r.copyWith(status: status).toMap();
      }
      return r.toMap();
    }).toList();
    await _box.put(_listKey, list);
  }
}

extension _PendingVerificationRecordCopy on PendingVerificationRecord {
  PendingVerificationRecord copyWith({String? status, bool? notificationShown}) {
    return PendingVerificationRecord(
      transactionId: transactionId,
      createdAt: createdAt,
      notificationShown: notificationShown ?? this.notificationShown,
      status: status ?? this.status,
      amount: amount,
      merchant: merchant,
      bank: bank,
      type: type,
    );
  }
}

final pendingVerificationHistoryProvider =
    Provider<List<PendingVerificationRecord>>((ref) {
  return PendingVerificationHistoryService.all();
});