import 'package:flutter/services.dart';

class NotificationPermissionService {
  static const MethodChannel _permissionsChannel = MethodChannel('com.spentx.app/permissions');

  static Future<bool> isNotificationListenerEnabled() async {
    try {
      final bool? isEnabled = await _permissionsChannel.invokeMethod('isNotificationListenerEnabled');
      return isEnabled ?? false;
    } catch (e) {
      return false;
    }
  }

  static Future<void> openNotificationListenerSettings() async {
    try {
      await _permissionsChannel.invokeMethod('openNotificationListenerSettings');
    } catch (e) {
      // Handle error
    }
  }
}
