import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:local_auth/local_auth.dart';

/// Stores and verifies app PIN in Hive settings (hashed with salt).
///
/// The PIN is **device-local only** — never pushed to Supabase. When the user
/// forgets it, web Settings → Security writes `users.app_pin_reset_at` and
/// [applyRemotePinResetIfNeeded] clears the local hash so they can set a new PIN.
class PinService {
  static bool isAuthenticatingBiometrically = false;
  static DateTime? lastUnlockedAt;
  static const _pinHashKey = 'pin_hash';
  static const _pinSaltKey = 'pin_salt';
  static const _pinSetAtKey = 'pin_set_at';
  static const _pinLengthKey = 'pin_length';
  static const _lastAppliedResetKey = 'last_applied_pin_reset_at';
  static const _failCountKey = 'pin_fail_count';
  static const _lockoutUntilKey = 'pin_lockout_until';
  static const forcePinSetupKey = 'force_pin_setup';

  /// Failed PIN attempts before a short lockout. The PIN itself is never stored.
  static const maxAttempts = 5;
  static const lockoutDuration = Duration(seconds: 30);
  static const _kdfIterations = 20000;

  /// Lengths a PIN may be set to. Existing installs from before this option
  /// existed are implicitly 4 (see [pinLength] default).
  static const allowedPinLengths = [4, 6];

  static Box get _settings => Hive.box('settings');

  /// PBKDF2-HMAC-SHA256. Old installs stored base64(salt::pin), which is
  /// reversible. [verifyPin] upgrades that form after the next correct entry.
  static String _hash(String pin, String salt) {
    final bytes = _pbkdf2Sha256(
      password: utf8.encode(pin),
      salt: utf8.encode(salt),
      iterations: _kdfIterations,
      length: 32,
    );
    return 'pbkdf2\$$_kdfIterations\$${base64Url.encode(bytes)}';
  }

  static String _legacyHash(String pin, String salt) {
    return base64Url.encode(utf8.encode('$salt::$pin'));
  }

  static bool _matches(String stored, String pin, String salt) {
    if (stored.startsWith('pbkdf2\$')) {
      return _constantTimeEquals(stored, _hash(pin, salt));
    }
    return _constantTimeEquals(stored, _legacyHash(pin, salt));
  }

  static bool _constantTimeEquals(String a, String b) {
    final ab = utf8.encode(a);
    final bb = utf8.encode(b);
    var diff = ab.length ^ bb.length;
    final n = ab.length < bb.length ? ab.length : bb.length;
    for (var i = 0; i < n; i++) {
      diff |= ab[i] ^ bb[i];
    }
    return diff == 0;
  }

  static Uint8List _pbkdf2Sha256({
    required List<int> password,
    required List<int> salt,
    required int iterations,
    required int length,
  }) {
    final hmac = Hmac(sha256, password);
    final blockCount = (length / 32).ceil();
    final out = BytesBuilder(copy: false);
    for (var blockIndex = 1; blockIndex <= blockCount; blockIndex++) {
      final seed = Uint8List(salt.length + 4);
      seed.setRange(0, salt.length, salt);
      final data = ByteData(4)..setUint32(0, blockIndex);
      seed.setRange(salt.length, seed.length, data.buffer.asUint8List());
      var u = Uint8List.fromList(hmac.convert(seed).bytes);
      final t = Uint8List.fromList(u);
      for (var i = 1; i < iterations; i++) {
        u = Uint8List.fromList(hmac.convert(u).bytes);
        for (var j = 0; j < t.length; j++) {
          t[j] ^= u[j];
        }
      }
      out.add(t);
    }
    return Uint8List.fromList(out.toBytes().sublist(0, length));
  }

  static Future<void> setPin(String pin) async {
    if (!allowedPinLengths.contains(pin.length)) return;
    final random = Random.secure();
    final saltBytes = List<int>.generate(32, (_) => random.nextInt(256));
    final salt = base64Url.encode(saltBytes);
    await _settings.put(_pinSaltKey, salt);
    await _settings.put(_pinHashKey, _hash(pin, salt));
    await _settings.put('has_pin', true);
    await _settings.put(_pinSetAtKey, DateTime.now().toUtc().toIso8601String());
    await _settings.put(_pinLengthKey, pin.length);
    await _settings.put(forcePinSetupKey, false);
    // Default to enabling lock screen when a PIN is set. Fingerprint is only
    // enabled if the device actually supports biometrics (see
    // enableFingerprintIfSupported) — never force-enabled blindly.
    await _settings.put('lock_screen_enabled', true);
    await enableFingerprintIfSupported();
  }

  /// Digits in the currently-set PIN — 4 unless the user chose 6 at setup.
  static int get pinLength => (_settings.get(_pinLengthKey) as int?) ?? 4;

  static Duration get lockoutRemaining {
    final raw = _settings.get(_lockoutUntilKey)?.toString();
    if (raw == null || raw.isEmpty) return Duration.zero;
    final until = DateTime.tryParse(raw);
    if (until == null) return Duration.zero;
    final left = until.difference(DateTime.now());
    if (left.isNegative) return Duration.zero;
    return left;
  }

  static bool get isLockedOut => lockoutRemaining > Duration.zero;

  static void _registerFailure() {
    if (isLockedOut) return;
    final count = (_settings.get(_failCountKey) as int?) ?? 0;
    final next = count + 1;
    if (next >= maxAttempts) {
      _settings.put(_failCountKey, 0);
      _settings.put(
        _lockoutUntilKey,
        DateTime.now().add(lockoutDuration).toIso8601String(),
      );
    } else {
      _settings.put(_failCountKey, next);
    }
  }

  static void _registerSuccess() {
    _settings.put(_failCountKey, 0);
    _settings.delete(_lockoutUntilKey);
  }

  static bool verifyPin(String pin) {
    if (isLockedOut) return false;
    if (pin.length != pinLength) return false;
    final salt = _settings.get(_pinSaltKey)?.toString();
    final stored = _settings.get(_pinHashKey)?.toString();
    if (salt == null || stored == null) return false;
    if (!_matches(stored, pin, salt)) {
      _registerFailure();
      return false;
    }
    if (!stored.startsWith('pbkdf2\$')) {
      // Upgrade the reversible legacy encoding. The PIN is not logged.
      _settings.put(_pinHashKey, _hash(pin, salt));
    }
    _registerSuccess();
    return true;
  }

  static Future<void> clearPin() async {
    await _settings.delete(_pinHashKey);
    await _settings.delete(_pinSaltKey);
    await _settings.delete(_pinSetAtKey);
    await _settings.delete(_pinLengthKey);
    await _settings.delete(_failCountKey);
    await _settings.delete(_lockoutUntilKey);
    await _settings.put('has_pin', false);
  }

  static bool get hasPin => _settings.get('has_pin', defaultValue: false) == true;

  static bool get forcePinSetup =>
      _settings.get(forcePinSetupKey, defaultValue: false) == true;

  static bool get lockEnabled =>
      _settings.get('lock_screen_enabled', defaultValue: true) == true;

  /// Applies a web-requested PIN reset. Remote value is only a timestamp —
  /// never a PIN. Returns true when local PIN was cleared and setup is required.
  static Future<bool> applyRemotePinResetIfNeeded(String? remoteResetAtIso) async {
    if (remoteResetAtIso == null || remoteResetAtIso.trim().isEmpty) {
      return false;
    }
    final remote = DateTime.tryParse(remoteResetAtIso.trim());
    if (remote == null) return false;

    final appliedRaw = _settings.get(_lastAppliedResetKey)?.toString();
    final appliedAt =
        appliedRaw != null ? DateTime.tryParse(appliedRaw) : null;
    if (appliedAt != null && !remote.isAfter(appliedAt)) {
      return false;
    }

    // User already set a new PIN after this reset request → mark applied only.
    final pinSetRaw = _settings.get(_pinSetAtKey)?.toString();
    final pinSetAt = pinSetRaw != null ? DateTime.tryParse(pinSetRaw) : null;
    if (pinSetAt != null && !remote.isAfter(pinSetAt)) {
      await _settings.put(_lastAppliedResetKey, remote.toUtc().toIso8601String());
      return false;
    }

    await clearPin();
    await _settings.put('lock_screen_enabled', false);
    await _settings.put(forcePinSetupKey, true);
    await _settings.put(_lastAppliedResetKey, remote.toUtc().toIso8601String());
    return true;
  }

  static Future<void> enableFingerprint() async {
    await _settings.put('fingerprint_enabled', true);
  }

  /// Whether this device reports biometric hardware/enrollment support —
  /// used to decide whether the Setup Wizard's biometric step shows at all.
  static Future<bool> isBiometricSupported() async {
    try {
      final localAuth = LocalAuthentication();
      return await localAuth.canCheckBiometrics ||
          await localAuth.isDeviceSupported();
    } catch (_) {
      return false;
    }
  }

  /// Enables fingerprint unlock only when the device reports biometric
  /// support; otherwise leaves it disabled. Safe to call from any flow.
  static Future<bool> enableFingerprintIfSupported() async {
    var supported = false;
    try {
      final localAuth = LocalAuthentication();
      supported = await localAuth.canCheckBiometrics ||
          await localAuth.isDeviceSupported();
    } catch (_) {
      supported = false;
    }
    await _settings.put('fingerprint_enabled', supported);
    return supported;
  }

  static bool get fingerprintEnabled =>
      _settings.get('fingerprint_enabled', defaultValue: false) == true;

  static Future<void> disableFingerprint() async {
    await _settings.put('fingerprint_enabled', false);
  }
}
