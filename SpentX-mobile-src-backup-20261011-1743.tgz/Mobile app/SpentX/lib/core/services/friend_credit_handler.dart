import '../providers/friend_upi_provider.dart';
import '../utils/upi_vpa.dart';
import '../providers/friends_provider.dart';
import '../providers/merchant_provider.dart';
import 'merchant_rule_service.dart';
import 'friend_repayment_matcher.dart';

/// Links credits to friends (UPI + merchant) and auto-repayment rules.
class FriendCreditHandler {
  FriendCreditHandler._();

  /// Category for money a friend pays back.
  ///
  /// Must stay 'Friend Returns' — that is the name in
  /// `global_settings.default_categories` (web migration
  /// 20260752_friend_returns_category.sql), in [categoryProvider]'s income
  /// list, and what the Transactions screen's Repayment filter compares
  /// against (`cat == 'friend returns'`). The old 'Repayment' string matched
  /// none of them, so SMS-detected repayments fell out of that filter and out
  /// of the web summary strip.
  static const String repaymentCategory = 'Friend Returns';

  static String merchantLabel(String friendName) => 'From $friendName';

  static String? matchFriendName({
    required dynamic ref,
    required String merchant,
    required String upiId,
    String? rawIdentifier,
  }) {
    return FriendRepaymentMatcher.resolveFriendName(
      ref: ref,
      merchant: merchant,
      upiId: upiId,
      rawIdentifier: rawIdentifier,
    );
  }

  /// Links a real UPI VPA to [friendName] so their next credit auto-matches.
  ///
  /// Only genuine VPAs are stored. Callers used to fall back to the parsed
  /// merchant identifier, which for credits is often a name fragment
  /// ("CLEARING", "SALARY") — once that lands in the friend's UPI list every
  /// unrelated sender carrying the same word matches that friend.
  static void linkFriendUpi(dynamic ref, String friendName, String upi) {
    if (!isRealUpiVpa(upi)) return;
    ref.read(friendUpiProvider.notifier).addUpi(friendName, upi);
  }

  static void learnFriendCreditRule({
    required dynamic ref,
    required String friendName,
    required String upiId,
    String? rawIdentifier,
  }) {
    final key = upiId.isNotEmpty
        ? upiId
        : (rawIdentifier?.isNotEmpty == true ? rawIdentifier! : friendName);
    MerchantRuleService.learnRule(
      identifier: key,
      displayName: merchantLabel(friendName),
      // Own category (not the generic "Other Income") so friend repayments
      // can still be called out separately in summaries.
      category: 'Friend Returns',
      purposeType: 'Personal',
      transactionType: 'credit',
    );
    ref.read(merchantProvider.notifier).learnRule(
      identifier: key,
      name: merchantLabel(friendName),
      // Own category (not the generic "Other Income") so friend repayments
      // can still be called out separately in summaries.
      category: 'Friend Returns',
      accountType: 'Personal',
      transactionType: 'credit',
    );
  }

  static List<String> friendNamesForPicker(dynamic ref) {
    final names = <String>{};
    for (final f in ref.read(friendsProvider)) {
      if (f.name.toLowerCase() != 'you') names.add(f.name);
    }
    for (final f in ref.read(manualFriendsProvider)) {
      if (f.name.toLowerCase() != 'you') names.add(f.name);
    }
    final list = names.toList()..sort(
          (a, b) => a.toLowerCase().compareTo(b.toLowerCase()),
        );
    return list;
  }
}