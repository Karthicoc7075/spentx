import 'package:hive_flutter/hive_flutter.dart';

import '../../models/pending_account.dart';
import '../utils/bank_keywords.dart';
import '../../data/local/hive_service.dart';

/// Store and update accounts inferred from SMS, without ever creating one.
///
/// Hive-only and synchronous, deliberately: every SMS entry path funnels
/// through here — including the WorkManager isolate, where there is no
/// Riverpod container and no UI — so this must work with nothing but an open
/// box. See docs/ACCOUNT_DISCOVERY.md.
class AccountDiscoveryService {
  AccountDiscoveryService._();

  static const boxName = 'pending_accounts';

  static bool get _ready => Hive.isBoxOpen(boxName);
  static Box get _box => Hive.box(boxName);

  static Future<void> ensureOpen() async {
    if (!_ready) await SecureHive.openBox(boxName);
  }

  /// Every discovered account, newest activity first.
  static List<PendingAccount> getAll() {
    if (!_ready) return const [];
    final out = <PendingAccount>[];
    for (final raw in _box.values) {
      if (raw is! Map) continue;
      try {
        out.add(PendingAccount.fromJson(Map<dynamic, dynamic>.from(raw)));
      } catch (_) {}
    }
    out.sort((a, b) => b.lastSeen.compareTo(a.lastSeen));
    return out;
  }

  /// Only what the user still has to decide on — strongest evidence first, so
  /// the account they obviously own sits above a single forwarded message.
  static List<PendingAccount> suggestions() {
    final list = getAll().where((p) => p.isSuggested).toList();
    list.sort((a, b) {
      final byHits = b.hitCount.compareTo(a.hitCount);
      return byHits != 0 ? byHits : b.lastSeen.compareTo(a.lastSeen);
    });
    return list;
  }

  static PendingAccount? get(String id) {
    if (!_ready) return null;
    final raw = _box.get(id);
    if (raw is! Map) return null;
    try {
      return PendingAccount.fromJson(Map<dynamic, dynamic>.from(raw));
    } catch (_) {
      return null;
    }
  }

  /// Keys that must never be proposed again — ignored **and** converted.
  ///
  /// Converted counts because the real account's last-4 only silences the
  /// message once [AutoDetectionNativeSync] has mirrored it; until then the
  /// same SMS would otherwise be proposed a second time.
  static List<String> resolvedKeys() {
    if (!_ready) return const [];
    return getAll()
        .where((p) => !p.isSuggested)
        .map((p) => p.id)
        .toList(growable: false);
  }

  /// Record (or update) the account behind [rawMessage].
  ///
  /// Call only for a message that already parsed as a real transaction — that
  /// is what keeps OTPs, promos and data alerts out of the suggestion list.
  /// Returns the row, or null when the message names no proposable account.
  ///
  /// Never writes an [AccountModel]; never writes a transaction.
  static PendingAccount? record({
    required String rawMessage,
    String? sampleSmsId,
    DateTime? seenAt,
  }) {
    if (!_ready) return null;

    final bankToken = bankTokenForMessage(rawMessage);
    if (bankToken.isEmpty) return null;

    final last4 = extractAccountLast4(rawMessage);
    if (last4.length < 3) return null;

    final id = pendingAccountKey(bankToken: bankToken, last4: last4);
    final now = seenAt ?? DateTime.now();
    final balance = extractAvailableBalance(rawMessage);
    final existing = get(id);

    // Decided already — count the sighting but never resurrect the prompt.
    if (existing != null && !existing.isSuggested) {
      final bumped = existing.copyWith(
        hitCount: existing.hitCount + 1,
        lastSeen: now,
      );
      _box.put(id, bumped.toJson());
      return bumped;
    }

    if (existing != null) {
      final updated = existing.copyWith(
        hitCount: existing.hitCount + 1,
        lastSeen: now,
        // Type only ever gets firmer: once a message says "credit card", a
        // later ambiguous one must not quietly demote it back to Bank.
        suggestedType: existing.suggestedType == 'Bank'
            ? inferAccountTypeFromMessage(rawMessage)
            : existing.suggestedType,
        lastSeenBalance: balance ?? existing.lastSeenBalance,
        lastSeenBalanceAt: balance != null ? now : existing.lastSeenBalanceAt,
        sampleSmsId: sampleSmsId ?? existing.sampleSmsId,
      );
      _box.put(id, updated.toJson());
      return updated;
    }

    final created = PendingAccount(
      id: id,
      bankToken: bankToken,
      displayBank: _displayName(bankToken),
      last4: last4,
      suggestedType: inferAccountTypeFromMessage(rawMessage),
      lastSeenBalance: balance,
      lastSeenBalanceAt: balance != null ? now : null,
      sampleSmsId: sampleSmsId ?? '',
      hitCount: 1,
      firstSeen: now,
      lastSeen: now,
    );
    _box.put(id, created.toJson());
    return created;
  }

  /// User said no. The row stays — it IS the ignore list.
  static void ignore(String id) => _setStatus(id, PendingAccountStatus.ignored);

  /// User turned it into a real account.
  static void markConverted(String id) =>
      _setStatus(id, PendingAccountStatus.converted);

  /// Undo an ignore, for the "ignored accounts" list in discovery.
  static void restore(String id) =>
      _setStatus(id, PendingAccountStatus.suggested);

  static void _setStatus(String id, PendingAccountStatus status) {
    final existing = get(id);
    if (existing == null) return;
    _box.put(id, existing.copyWith(status: status).toJson());
  }

  /// Drop suggestions whose last-4 now belongs to a real account — the user
  /// added it by hand instead of tapping the suggestion.
  static void reconcileAgainstAccounts(List<String> accountLast4s) {
    if (!_ready || accountLast4s.isEmpty) return;
    final owned = accountLast4s.map((e) => e.trim()).toSet();
    for (final pending in getAll()) {
      if (pending.isSuggested && owned.contains(pending.last4)) {
        markConverted(pending.id);
      }
    }
  }

  static void clearAll() {
    if (_ready) _box.clear();
  }

  /// Title-cased bank label for the UI. The token is a match key, not a name.
  static String _displayName(String token) {
    const overrides = {
      'hdfc': 'HDFC Bank',
      'icici': 'ICICI Bank',
      'sbi': 'SBI',
      'axis': 'Axis Bank',
      'kotak': 'Kotak',
      'idfc': 'IDFC First',
      'idbi': 'IDBI Bank',
      'pnb': 'Punjab National Bank',
      'rbl': 'RBL Bank',
      'dbs': 'DBS Bank',
      'hsbc': 'HSBC',
      'au small': 'AU Small Finance',
      'yes bank': 'Yes Bank',
      'uco bank': 'UCO Bank',
      'airtel payments': 'Airtel Payments Bank',
    };
    final hit = overrides[token];
    if (hit != null) return hit;
    return token
        .split(' ')
        .where((w) => w.isNotEmpty)
        .map((w) => '${w[0].toUpperCase()}${w.substring(1)}')
        .join(' ');
  }
}
