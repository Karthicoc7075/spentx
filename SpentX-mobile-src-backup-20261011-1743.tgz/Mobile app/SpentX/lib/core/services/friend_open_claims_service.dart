import '../providers/friend_split_provider.dart';
import '../providers/outing_provider.dart';
import '../../models/friend_split.dart';
import '../../models/friend_open_claim.dart';

export '../../models/friend_open_claim.dart';

/// Builds "who owes you what" for one friend, and applies repayments against
/// the exact claims the user picked.
///
/// The allocation maths lives in [FriendClaimMath] (pure, unit-tested); this
/// class is the provider-facing half — reading the two stores that hold
/// balances, and writing settlements back.
///
/// Deliberately replaces the old behaviour in `FriendRepaymentMatcher`, which
/// drained pending shares greedily across every outing until the credit
/// amount ran out — a ₹600 credit against a ₹500 debt silently ate ₹100 from
/// an unrelated trip.
class FriendOpenClaimsService {
  FriendOpenClaimsService._();

  /// Re-exported so callers have one import for the whole feature.
  static const double matchTolerance = FriendClaimMath.matchTolerance;
  static const double _settledEpsilon = FriendClaimMath.settledEpsilon;

  static double totalOutstanding(List<FriendOpenClaim> claims) =>
      FriendClaimMath.totalOutstanding(claims);

  static Set<String> preselect(List<FriendOpenClaim> claims, double amount) =>
      FriendClaimMath.preselect(claims, amount);

  static Map<String, double> allocate(
    List<FriendOpenClaim> selected,
    double amount,
  ) =>
      FriendClaimMath.allocate(selected, amount);

  static double unallocated(List<FriendOpenClaim> selected, double amount) =>
      FriendClaimMath.unallocated(selected, amount);

  /// Every open claim for [friendName], oldest first (FIFO allocation order).
  ///
  /// Reads **both** balance stores. The old matcher only looked at outings, so
  /// a Friend Split could never be auto-settled at all.
  ///
  /// Only expenses **you paid** produce a claim — if the friend paid the bill
  /// they don't owe you for it, so an incoming credit can't be settling it.
  static List<FriendOpenClaim> claimsForFriend(
    dynamic ref,
    String friendName,
  ) {
    final target = friendName.trim().toLowerCase();
    if (target.isEmpty || target == 'you') return const [];

    final claims = <FriendOpenClaim>[
      ..._outingClaims(ref, target),
      ..._friendSplitClaims(ref, target),
    ];

    claims.sort((a, b) => a.incurredAt.compareTo(b.incurredAt));
    return claims;
  }

  static List<FriendOpenClaim> _outingClaims(dynamic ref, String target) {
    final result = <FriendOpenClaim>[];

    for (final outing in ref.read(outingProvider) as List<Outing>) {
      final youId = outing.youMemberId;
      if (youId == null) continue;

      final friendMember = outing.members
          .where((m) => m.name.trim().toLowerCase() == target)
          .firstOrNull;
      if (friendMember == null) continue;

      for (final expense in outing.expenses) {
        // A bill the friend paid isn't money they owe you.
        if (!expense.isPaidByYou(youId)) continue;
        if (!expense.memberIds.contains(friendMember.id)) continue;

        final pending = expense.pendingAmountForMember(friendMember.id);
        if (pending < _settledEpsilon) continue;

        result.add(
          FriendOpenClaim(
            source: FriendClaimSource.outing,
            outingId: outing.id,
            expenseId: expense.id,
            splitId: '',
            referenceName: '${outing.title} · ${expense.title}',
            friendName: friendMember.name,
            friendMemberId: friendMember.id,
            youMemberId: youId,
            outstanding: pending,
            incurredAt: expense.date,
          ),
        );
      }
    }

    return result;
  }

  static List<FriendOpenClaim> _friendSplitClaims(dynamic ref, String target) {
    final result = <FriendOpenClaim>[];

    for (final split in ref.read(friendSplitProvider) as List<FriendSplit>) {
      if (!split.isActive) continue;

      final youId = split.youMemberId;
      if (youId == null) continue;
      // Same rule as outings — only bills you paid create a claim.
      if (split.paidByMemberId != youId) continue;

      final friendMember = split.members
          .where((m) => m.name.trim().toLowerCase() == target)
          .firstOrNull;
      if (friendMember == null) continue;

      final pending = split.pendingAmountForMember(friendMember.id);
      if (pending < _settledEpsilon) continue;

      result.add(
        FriendOpenClaim(
          source: FriendClaimSource.friendSplit,
          outingId: '',
          expenseId: '',
          splitId: split.id,
          referenceName: split.description,
          friendName: friendMember.name,
          friendMemberId: friendMember.id,
          youMemberId: youId,
          outstanding: pending,
          incurredAt: split.date,
        ),
      );
    }

    return result;
  }

  /// Writes settlement rows for exactly [allocation], nothing more.
  /// Returns how many claims were settled.
  static int applySettlements(
    dynamic ref, {
    required List<FriendOpenClaim> claims,
    required Map<String, double> allocation,
    required String mode,
    String? note,
  }) {
    var applied = 0;

    for (final claim in claims) {
      final amount = allocation[claim.id];
      if (amount == null || amount < _settledEpsilon) continue;

      switch (claim.source) {
        case FriendClaimSource.outing:
          ref.read(outingProvider.notifier).recordMemberSettlement(
                claim.outingId,
                claim.expenseId,
                claim.friendMemberId,
                amount: amount,
                mode: mode,
              );
          applied++;
          break;

        case FriendClaimSource.friendSplit:
          final split = (ref.read(friendSplitProvider) as List<FriendSplit>)
              .where((s) => s.id == claim.splitId)
              .firstOrNull;
          if (split == null) break;
          ref.read(friendSplitProvider.notifier).recordSettlement(
                split,
                fromMemberId: claim.friendMemberId,
                toMemberId: claim.youMemberId,
                amount: amount,
                note: note,
              );
          applied++;
          break;
      }
    }

    return applied;
  }
}
