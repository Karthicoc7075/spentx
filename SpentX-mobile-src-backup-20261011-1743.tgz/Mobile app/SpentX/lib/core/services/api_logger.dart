import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Lightweight API request logger for the mobile app.
///
/// Logs every Supabase API call to the `user_api_logs` table via the
/// `log_mobile_api_call` RPC (SECURITY DEFINER — bypasses RLS insert block
/// while ensuring the caller can only attribute logs to themselves).
/// Failures are silently swallowed — logging must never break the app.
class ApiLogger {
  ApiLogger._();

  static String get _platform => Platform.isAndroid ? 'android' : 'ios';

  static String? _cachedVersion;

  /// Set the app version from package_info_plus during app startup.
  static void setAppVersion(String version) {
    _cachedVersion = version;
  }

  /// Log a successful API call. Fire-and-forget.
  static void logSuccess({
    required String apiType,
    required String apiName,
    String? method,
    int? statusCode,
    int? durationMs,
    int? requestSizeBytes,
    int? responseSizeBytes,
  }) {
    _log(
      apiType: apiType,
      apiName: apiName,
      method: method,
      status: 'success',
      statusCode: statusCode,
      durationMs: durationMs,
      requestSizeBytes: requestSizeBytes,
      responseSizeBytes: responseSizeBytes,
    );
  }

  /// Log a failed API call. Fire-and-forget.
  static void logError({
    required String apiType,
    required String apiName,
    String? method,
    int? statusCode,
    int? durationMs,
    String? errorMessage,
  }) {
    _log(
      apiType: apiType,
      apiName: apiName,
      method: method,
      status: 'error',
      statusCode: statusCode,
      durationMs: durationMs,
      errorMessage: errorMessage,
    );
  }

  /// Wrap a Supabase query with automatic timing and logging.
  ///
  /// Usage:
  /// ```dart
  /// final data = await ApiLogger.track(
  ///   apiType: 'rest_select',
  ///   apiName: 'transactions',
  ///   method: 'GET',
  ///   action: () => supabase.from('transactions').select(),
  /// );
  /// ```
  static Future<T> track<T>({
    required String apiType,
    required String apiName,
    String? method,
    required Future<T> Function() action,
  }) async {
    final stopwatch = Stopwatch()..start();
    try {
      final result = await action();
      stopwatch.stop();
      logSuccess(
        apiType: apiType,
        apiName: apiName,
        method: method,
        statusCode: 200,
        durationMs: stopwatch.elapsedMilliseconds,
      );
      return result;
    } catch (e) {
      stopwatch.stop();
      logError(
        apiType: apiType,
        apiName: apiName,
        method: method,
        statusCode: 500,
        durationMs: stopwatch.elapsedMilliseconds,
        errorMessage: e.toString().length > 500
            ? e.toString().substring(0, 500)
            : e.toString(),
      );
      rethrow;
    }
  }

  static void _log({
    required String apiType,
    required String apiName,
    String? method,
    required String status,
    int? statusCode,
    int? durationMs,
    int? requestSizeBytes,
    int? responseSizeBytes,
    String? errorMessage,
  }) {
    // Fire-and-forget — never await, never throw
    Future(() async {
      try {
        final user = Supabase.instance.client.auth.currentUser;
        if (user == null) return; // Can't log without a user

        await Supabase.instance.client.rpc('log_mobile_api_call', params: {
          'p_api_type': apiType,
          'p_api_name': apiName.length > 200
              ? apiName.substring(0, 200)
              : apiName,
          'p_method': method,
          'p_status': status,
          'p_status_code': statusCode,
          'p_error_message': errorMessage,
          'p_duration_ms': durationMs,
          'p_request_size_bytes': requestSizeBytes,
          'p_response_size_bytes': responseSizeBytes,
          'p_platform': _platform,
          'p_app_version': _cachedVersion,
        });
      } catch (e) {
        debugPrint('ApiLogger: failed to log API call: $e');
      }
    });
  }
}
