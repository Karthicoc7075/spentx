import 'dart:async';

import 'package:hive_flutter/hive_flutter.dart';
import '../models/merchant_rule.dart';
import '../../features/sms/detected/sms_atm_helper.dart';
import '../../features/sms/detected/sms_detection_debug_log.dart';
import '../debug/master_debug_log.dart';
import '../debug/master_debug_module.dart';
import 'merchant_identifier_resolver.dart';
import 'auto_detection_native_sync.dart';

/// Hive-backed merchant rule persistence and lookup — single source of truth.
class MerchantRuleService {
  static const _boxName = 'merchant_rules_box';

  static final RegExp _upiPattern = RegExp(
    r'[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+',
    caseSensitive: false,
  );

  static String normalizeIdentifier(String id) => id.trim().toLowerCase();

  static bool looksLikeUpi(String value) => _upiPattern.hasMatch(value.trim());

  static bool looksLikePhone(String value) {
    final digits = value.replaceAll(RegExp(r'\D'), '');
    return digits.length >= 10 && digits.length <= 13;
  }

  static String? extractUpiFromMessage(String message) {
    final m = _upiPattern.firstMatch(message);
    return m?.group(0)?.trim();
  }

  /// Build case-insensitive lookup keys — ONLY UPI ID, Phone Number, Account Identifier or raw ID-like.
  /// Never use displayName / last saved / last verified merchant name for lookup.
  /// Correct flow: 1) extract identifier 2) normalize 3) lookup rule 4) apply display ONLY on match.
  static Set<String> buildLookupCandidates({
    required String upiId,
    required String rawIdentifier,
    required String displayName,
    String? rawMessage,
  }) {
    // Stable keys only — never the user-edited display name used as lookup.
    return MerchantIdentifierResolver.lookupCandidates(
      upiId: upiId,
      rawIdentifier: rawIdentifier,
      parsedName: displayName,
      rawMessage: rawMessage,
    );
  }



  static Box get _box => Hive.box(_boxName);

  /// Serializes [_upsert] calls so two near-simultaneous learn events for the
  /// same identifier (e.g. bulk SMS backlog scan on first run) can't both
  /// read "no existing rule" before either write lands — which is exactly
  /// how duplicate rows with the same normalized identifier got created.
  static Future<void> _lock = Future.value();

  /// Removes rows that share the same normalized identifier, keeping only
  /// the most recently used one. Fixes duplicates already stored on a
  /// device from before the race above was closed. Safe to call repeatedly
  /// (e.g. every time the merchant list loads).
  static Future<void> dedupe() async {
    if (!Hive.isBoxOpen(_boxName)) return;
    final byNorm = <String, MerchantRule>{};
    final toDelete = <String>[];

    for (final raw in _box.values) {
      final rule = MerchantRule.fromMap(Map<dynamic, dynamic>.from(raw));
      final key = normalizeIdentifier(
        rule.normalizedIdentifierKey.isNotEmpty
            ? rule.normalizedIdentifierKey
            : rule.identifier,
      );
      if (key.isEmpty) continue;
      final current = byNorm[key];
      if (current == null) {
        byNorm[key] = rule;
      } else if (rule.lastUsedAt.isAfter(current.lastUsedAt)) {
        toDelete.add(current.id);
        byNorm[key] = rule;
      } else {
        toDelete.add(rule.id);
      }
    }

    if (toDelete.isEmpty) return;
    for (final id in toDelete) {
      await _box.delete(id);
    }
    await AutoDetectionNativeSync.syncToNative();
  }

  static String _learnTransactionType(String identifier, String transactionType) {
    if (looksLikeUpi(identifier) || looksLikePhone(identifier)) return 'any';
    return transactionType;
  }

  /// Lookup before any pending verification. Case-insensitive exact match on normalized id.
  /// UPI / phone rules with transactionType=any match both debit and credit.
  static MerchantRule? findRule({
    required String upiId,
    required String rawIdentifier,
    required String displayName,
    String? rawMessage,
    required String transactionType,
    bool logResult = true,
    String? sourceLabel,
  }) {
    if (!Hive.isBoxOpen(_boxName)) return null;

    final candidates = buildLookupCandidates(
      upiId: upiId,
      rawIdentifier: rawIdentifier,
      displayName: displayName,
      rawMessage: rawMessage,
    );
    if (candidates.isEmpty) return null;

    for (final raw in _box.values) {
      final rule = MerchantRule.fromMap(Map<dynamic, dynamic>.from(raw));
      final rNorm = normalizeIdentifier(rule.normalizedIdentifierKey);
      final rId = normalizeIdentifier(rule.identifier);
      if (rNorm.isEmpty && rId.isEmpty) continue;

      final idMatches = candidates.contains(rNorm) ||
          candidates.contains(rId) ||
          (looksLikeUpi(rule.identifier) &&
              candidates.contains(normalizeIdentifier(rule.identifier)));

      if (!idMatches) continue;

      final ruleIsPortable = looksLikeUpi(rule.identifier) ||
          looksLikeUpi(rule.normalizedIdentifierKey) ||
          looksLikePhone(rule.identifier) ||
          rule.transactionType == 'any';

      final typeOk = rule.transactionType.isEmpty ||
          rule.transactionType == 'any' ||
          rule.transactionType == transactionType ||
          ruleIsPortable;

      if (!typeOk) continue;

      if (logResult) {
        final identifier = upiId.isNotEmpty
            ? upiId
            : (rawIdentifier.isNotEmpty ? rawIdentifier : displayName);
        SmsDetectionDebugLog.log(
          level: SmsDebugLogLevel.success,
          message: 'Merchant Lookup: FOUND',
          source: sourceLabel,
          detail:
              'Identifier: $identifier\nMatched Rule: ${rule.displayName}\nVerification: SKIPPED\nReason: Known Merchant',
        );
        MasterDebugLog.merchant(
          title: 'Merchant Match Found',
          message: rule.displayName,
          level: MasterDebugLevel.success,
          data: {
            'identifier': identifier,
            'displayName': rule.displayName,
            'ruleApplied': rule.identifier,
          },
        );
      }
      return rule;
    }

    if (logResult) {
      final identifier = upiId.isNotEmpty
          ? upiId
          : (rawIdentifier.isNotEmpty ? rawIdentifier : displayName);
      // When no rule matches by identifier, caller should use the parsed title (not any last saved).
      SmsDetectionDebugLog.log(
        level: SmsDebugLogLevel.info,
        message: 'Merchant Lookup: NOT FOUND',
        source: sourceLabel,
        detail: 'Identifier: $identifier\nUsing Parsed Title: ${displayName.isNotEmpty && displayName.toLowerCase() != 'unknown' ? displayName : identifier}',
      );
      MasterDebugLog.merchant(
        title: 'No Merchant Rule Found',
        message: 'Verification Required',
        level: MasterDebugLevel.warning,
        data: {'identifier': identifier},
      );
    }
    return null;
  }

  static MerchantRule? findAtmRule({
    required String bank,
    String? accountLast4,
    String transactionType = 'transfer',
    bool isCashDeposit = false,
  }) {
    if (!Hive.isBoxOpen(_boxName)) return null;
    final key = SmsAtmHelper.ruleIdentifier(
      bank: bank,
      accountLast4: accountLast4,
      isCashDeposit: isCashDeposit,
    );
    return findRule(
      upiId: '',
      rawIdentifier: key,
      displayName: isCashDeposit
          ? SmsAtmHelper.cashDepositDisplayName
          : SmsAtmHelper.defaultDisplayName,
      transactionType: transactionType,
      logResult: false,
    );
  }

  static Future<void> learnAtmRule({
    required String bank,
    String? accountLast4,
    required String displayName,
    required String category,
    required String purposeType,
    String transactionType = 'transfer',
    bool isCashDeposit = false,
  }) async {
    final identifier = SmsAtmHelper.ruleIdentifier(
      bank: bank,
      accountLast4: accountLast4,
      isCashDeposit: isCashDeposit,
    );
    await _upsert(
      identifier: identifier,
      displayName: displayName,
      category: category,
      purposeType: purposeType,
      transactionType: transactionType,
    );
  }

  static Future<void> learnRule({
    required String identifier,
    required String displayName,
    required String category,
    required String purposeType,
    String transactionType = 'debit',
  }) async {
    await _upsert(
      identifier: identifier,
      displayName: displayName,
      category: category,
      purposeType: purposeType,
      transactionType: _learnTransactionType(identifier, transactionType),
    );
  }

  static Future<void> _upsert({
    required String identifier,
    required String displayName,
    required String category,
    required String purposeType,
    required String transactionType,
  }) async {
    // Chain onto the previous call so the read-check-write below can never
    // interleave with another _upsert for a different identifier that's
    // racing it (both would otherwise see "no existing" and double-insert).
    final previous = _lock;
    final completer = Completer<void>();
    _lock = completer.future;
    await previous;
    try {
      await _doUpsert(
        identifier: identifier,
        displayName: displayName,
        category: category,
        purposeType: purposeType,
        transactionType: transactionType,
      );
    } finally {
      completer.complete();
    }
  }

  static Future<void> _doUpsert({
    required String identifier,
    required String displayName,
    required String category,
    required String purposeType,
    required String transactionType,
  }) async {
    if (!Hive.isBoxOpen(_boxName)) return;
    final trimmed = identifier.trim();
    if (trimmed.isEmpty) return;

    final norm = normalizeIdentifier(trimmed);
    final effectiveType = _learnTransactionType(trimmed, transactionType);

    MerchantRule? existing;
    for (final raw in _box.values) {
      final rule = MerchantRule.fromMap(Map<dynamic, dynamic>.from(raw));
      if (normalizeIdentifier(rule.normalizedIdentifierKey) == norm ||
          normalizeIdentifier(rule.identifier) == norm) {
        existing = rule;
        break;
      }
    }

    if (existing != null) {
      await _box.put(
        existing.id,
        existing
            .copyWith(
              identifier: trimmed,
              normalizedIdentifierKey: norm,
              displayName: displayName,
              defaultCategory: category,
              defaultPurposeType: purposeType,
              transactionType: effectiveType,
              lastUsedAt: DateTime.now(),
            )
            .toMap(),
      );
    } else {
      final id = DateTime.now().millisecondsSinceEpoch.toString();
      await _box.put(
        id,
        MerchantRule(
          id: id,
          identifier: trimmed,
          normalizedIdentifierKey: norm,
          displayName: displayName,
          defaultPurposeType: purposeType,
          defaultCategory: category,
          transactionType: effectiveType,
          lastUsedAt: DateTime.now(),
        ).toMap(),
      );
    }
    await AutoDetectionNativeSync.syncToNative();
  }
}