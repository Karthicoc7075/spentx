import 'package:flutter_contacts/flutter_contacts.dart';

class DeviceContact {
  final String displayName;
  final String? phone;

  const DeviceContact({required this.displayName, this.phone});
}

class ContactsService {
  static Future<bool> requestPermission() async {
    final status =
        await FlutterContacts.permissions.request(PermissionType.read);
    return status == PermissionStatus.granted ||
        status == PermissionStatus.limited;
  }

  static Future<bool> hasPermission() async {
    return FlutterContacts.permissions.has(PermissionType.read);
  }

  static Future<List<DeviceContact>> loadContacts() async {
    if (!await hasPermission()) {
      final granted = await requestPermission();
      if (!granted) return [];
    }

    final raw = await FlutterContacts.getAll(
      properties: {ContactProperty.phone},
    );
    final List<DeviceContact> result = [];
    final seen = <String>{};

    for (final c in raw) {
      final name = (c.displayName ?? '').trim();
      if (name.isEmpty) continue;

      String? phone;
      if (c.phones.isNotEmpty) {
        phone = _normalizePhone(c.phones.first.number);
      }

      final key = '${name.toLowerCase()}_${phone ?? ''}';
      if (seen.contains(key)) continue;
      seen.add(key);

      result.add(DeviceContact(displayName: name, phone: phone));
    }

    result.sort(
      (a, b) => a.displayName.toLowerCase().compareTo(b.displayName.toLowerCase()),
    );
    return result;
  }

  static String? _normalizePhone(String raw) {
    final digits = raw.replaceAll(RegExp(r'[^\d+]'), '').trim();
    if (digits.isEmpty) return null;
    return digits;
  }
}