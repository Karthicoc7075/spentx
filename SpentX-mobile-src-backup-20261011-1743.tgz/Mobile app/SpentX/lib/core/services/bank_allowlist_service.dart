import 'package:hive_flutter/hive_flutter.dart';
import '../utils/bank_keywords.dart';
import 'account_discovery_service.dart';

/// What the allowlist decided about one message.
///
/// This used to be a bool, and that was the bug: a message from a bank the
/// user had not added was rejected and dropped silently, so someone who added
/// their savings account but forgot their credit card never saw those spends
/// and was never told why. [discovery] is the third answer — not mine, but
/// worth asking about (see docs/ACCOUNT_DISCOVERY.md).
enum AllowResult {
  /// Names one of the user's banks or account numbers. Detect normally.
  allowed,

  /// Bank-shaped, carries a last-4 the user has no account for, and has not
  /// been ignored. Parse it, but propose the account instead of booking a
  /// transaction against an account that does not exist.
  discovery,

  /// Not the user's, and not worth asking about — a bank they ignored, or a
  /// message naming no bank at all.
  blocked,
}

/// "Only detect SMS from banks the user actually added" — plus, now, "and
/// offer to add the ones they clearly have but never entered."
///
/// The native notification listener enforces the same gate via a
/// SharedPreferences mirror (`SpentXDetectionPrefs.isMessageFromAllowedBank`).
///
/// Reads accounts straight out of Hive rather than a provider so it works from
/// background isolates, where there is no Riverpod container.
class BankAllowlistService {
  BankAllowlistService._();

  /// True when [message] names one of the user's banks or account numbers.
  ///
  /// Back-compatible bool view of [evaluate] — `true` only for
  /// [AllowResult.allowed], so existing callers keep their exact behaviour and
  /// a discovery candidate never slips into the normal transaction path.
  static bool allows(String message, {String? sender}) =>
      evaluate(message, sender: sender) == AllowResult.allowed;

  /// Full three-way decision.
  ///
  /// Fail-safe, unchanged from the bool version:
  /// * settings box unavailable (background isolate started early) → allowed,
  ///   the Dart filters downstream still apply
  /// * no accounts configured yet → allowed, so a new user still sees detection
  /// * accounts configured but none is a bank (cash only) → falls through to
  ///   discovery/blocked rather than detecting against no account
  ///
  /// [sender] is the SMS sender header ("AX-HDFCBK-S"). When it maps to one
  /// of the user's banks the message is theirs even if the body never names
  /// the bank.
  static AllowResult evaluate(String message, {String? sender}) {
    if (message.trim().isEmpty) return AllowResult.blocked;
    if (!Hive.isBoxOpen('settings')) return AllowResult.allowed;

    final raw = Hive.box('settings').get('onboardingAccounts');
    if (raw is! List || raw.isEmpty) return AllowResult.allowed;

    final banks = collectAllowlistBanks(raw);

    // Nothing parseable at all — treat as unconfigured rather than locking the
    // user out of detection.
    if (!banks.sawAccount) return AllowResult.allowed;

    final matched = messageMatchesAllowedBank(
      message,
      tokens: banks.tokens.toList(),
      last4s: banks.last4s.toList(),
      sender: sender,
    );
    if (matched) return AllowResult.allowed;

    final discoverable = isDiscoverableAccountMessage(
      message,
      knownLast4s: banks.last4s.toList(),
      tokensWithoutLast4: banks.tokensWithoutLast4.toList(),
      ignoredKeys: AccountDiscoveryService.resolvedKeys(),
    );

    return discoverable ? AllowResult.discovery : AllowResult.blocked;
  }

  /// The user's bank tokens and last-4s, from the Hive account list.
  ///
  /// Inactive accounts are skipped — except when NO bank account is active.
  /// A bad dedupe once flagged every real bank inactive, and the allowlist
  /// then rejected every bank SMS without a trace. With no active bank at all
  /// there is nothing better to match against, so the inactive ones are used
  /// rather than silently dropping all detection.
  static AllowlistBanks collectAllowlistBanks(List raw) {
    AllowlistBanks build({required bool includeInactive}) {
      final out = AllowlistBanks();
      for (final entry in raw) {
        if (entry is! Map) continue;
        out.sawAccount = true;
        final type = (entry['type'] ?? '').toString().toLowerCase();
        if (type == 'cash') continue;
        if (!includeInactive && entry['isActive'] == false) continue;
        if (entry['isDeleted'] == true) continue;

        final token = bankTokenForAccountName((entry['name'] ?? '').toString());
        final last4 = (entry['last4Digits'] ?? '').toString().trim();

        if (token.isNotEmpty) out.tokens.add(token);
        if (last4.length >= 3) {
          out.last4s.add(last4);
        } else if (token.isNotEmpty) {
          // Bank added, account number left blank — its SMS carries a last-4
          // we have no copy of, so it must not be mistaken for a new account.
          out.tokensWithoutLast4.add(token);
        }
      }
      return out;
    }

    final active = build(includeInactive: false);
    if (active.tokens.isNotEmpty || active.last4s.isNotEmpty) return active;
    final withInactive = build(includeInactive: true);
    if (withInactive.tokens.isNotEmpty || withInactive.last4s.isNotEmpty) {
      withInactive.usedInactiveFallback = true;
      return withInactive;
    }
    return active;
  }
}

/// Result of [BankAllowlistService.collectAllowlistBanks].
class AllowlistBanks {
  final Set<String> tokens = <String>{};
  final Set<String> last4s = <String>{};
  final Set<String> tokensWithoutLast4 = <String>{};
  bool sawAccount = false;
  bool usedInactiveFallback = false;
}
