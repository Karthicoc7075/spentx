import 'package:hive_flutter/hive_flutter.dart';

import '../utils/plan_alerts.dart';
import 'notification_history_service.dart';
import '../../models/transaction.dart';

/// Writes the three plan alerts into notification history, once per alert id.
///
/// Reads the current month from the `monthly_plans` box directly so the
/// transaction save path does not import the plan provider.
class PlanAlertService {
  static Future<void> check({
    required List<Transaction> transactions,
    DateTime? now,
  }) async {
    final clock = now ?? DateTime.now();
    final plan = _currentPlan(clock);
    if (plan == null) return;

    final spends = <PlanSpend>[];
    for (final tx in transactions) {
      if (!tx.isExpense || tx.isTransfer || tx.isPendingVerification) continue;
      final note = tx.note.trim().toLowerCase();
      if (note.startsWith('outing total') || note.startsWith('your share of ')) {
        continue;
      }
      final category = tx.category.trim().toLowerCase();
      if (_skippedCategory(category)) continue;

      if (tx.isSplitExpense) {
        var added = false;
        for (final slice in tx.splits) {
          if (slice.amount <= 0) continue;
          final name = slice.categoryId.trim();
          if (name.isEmpty || _skippedCategory(name.toLowerCase())) continue;
          spends.add(
            PlanSpend(amount: slice.amount, category: name, date: tx.date),
          );
          added = true;
        }
        if (added) continue;
      }

      spends.add(
        PlanSpend(amount: tx.amount, category: tx.category, date: tx.date),
      );
    }

    final alerts = buildPlanAlerts(
      plannedTotal: plan.planned,
      savedDailyLimit: plan.daily,
      allocations: plan.allocations,
      spends: spends,
      now: clock,
    );
    await publish(alerts);
  }

  static bool _skippedCategory(String category) {
    return category == 'settlements' ||
        category == 'settlement' ||
        category == 'transfer' ||
        category == 'opening balance' ||
        category == 'friend returns';
  }

  static ({
    double planned,
    double? daily,
    List<PlanCategoryBudget> allocations,
  })? _currentPlan(DateTime clock) {
    if (!Hive.isBoxOpen('monthly_plans')) return null;
    final month =
        '${clock.year.toString().padLeft(4, '0')}-${clock.month.toString().padLeft(2, '0')}';
    final raw = Hive.box('monthly_plans').get('list', defaultValue: <dynamic>[]);
    if (raw is! List) return null;

    for (final item in raw) {
      if (item is! Map) continue;
      final map = Map<dynamic, dynamic>.from(item);
      if (map['month']?.toString() != month) continue;

      final allocations = <PlanCategoryBudget>[];
      final rawAlloc = map['allocations'];
      if (rawAlloc is List) {
        for (final entry in rawAlloc) {
          if (entry is! Map) continue;
          final row = Map<dynamic, dynamic>.from(entry);
          final category = (row['category'] ?? '').toString().trim();
          final planned = (row['plannedAmount'] as num? ??
                  row['planned_amount'] as num? ??
                  0)
              .toDouble();
          if (category.isEmpty || planned <= 0) continue;
          allocations.add(
            PlanCategoryBudget(category: category, planned: planned),
          );
        }
      }
      final plannedTotal =
          allocations.fold<double>(0, (sum, row) => sum + row.planned);
      if (plannedTotal <= 0) return null;
      final daily = (map['dailySafeLimit'] as num? ?? map['daily_safe_limit'] as num?)
          ?.toDouble();
      return (planned: plannedTotal, daily: daily, allocations: allocations);
    }
    return null;
  }

  static Future<void> publish(List<PlanAlert> alerts) async {
    if (!Hive.isBoxOpen('settings')) return;
    final box = Hive.box('settings');
    for (final alert in alerts) {
      final key = 'plan_alert_fired_${alert.id}';
      if (box.get(key) == true) continue;
      final added = await NotificationHistoryService.add(
        title: alert.title,
        body: alert.body,
        type: alert.type,
      );
      if (added) await box.put(key, true);
    }
  }
}
