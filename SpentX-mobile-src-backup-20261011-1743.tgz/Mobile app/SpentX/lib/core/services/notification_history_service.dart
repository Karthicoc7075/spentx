import 'package:hive_flutter/hive_flutter.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/local/hive_service.dart';

class AppNotificationRecord {
  final String id;
  final String title;
  final String body;
  final String type;
  final DateTime createdAt;
  final bool isRead;

  AppNotificationRecord({
    required this.id,
    required this.title,
    required this.body,
    required this.type,
    required this.createdAt,
    this.isRead = false,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'body': body,
        'type': type,
        'createdAt': createdAt.toIso8601String(),
        'isRead': isRead,
      };

  factory AppNotificationRecord.fromMap(Map<String, dynamic> m) {
    return AppNotificationRecord(
      id: m['id']?.toString() ?? '',
      title: m['title']?.toString() ?? '',
      body: m['body']?.toString() ?? '',
      type: m['type']?.toString() ?? 'general',
      createdAt: DateTime.tryParse(m['createdAt']?.toString() ?? '') ?? DateTime.now(),
      isRead: m['isRead'] == true,
    );
  }
}

/// Persistent in-app notification history (separate from system notifications).
class NotificationHistoryService {
  static const boxName = 'notification_history';
  static const _listKey = 'items';
  static const maxItems = 200;
  static const maxDailyNonSmsNotifications = 8;

  static Box get _box => Hive.box(boxName);

  static Future<void> ensureOpen() async {
    if (!Hive.isBoxOpen(boxName)) {
      await SecureHive.openBox(boxName);
    }
  }

  static bool canAddNotificationToday(String type) {
    // Exclude SMS detection notifications from daily limit
    if (type == 'sms' || type == 'sms_detection' || type == 'transaction_detection') {
      return true;
    }
    final todayStr = DateTime.now().toIso8601String().substring(0, 10);
    final todayNonSmsCount = all().where((r) {
      final isToday = r.createdAt.toIso8601String().substring(0, 10) == todayStr;
      final isNonSms = r.type != 'sms' && r.type != 'sms_detection' && r.type != 'transaction_detection';
      return isToday && isNonSms;
    }).length;

    return todayNonSmsCount < maxDailyNonSmsNotifications;
  }

  static Future<bool> add({
    required String title,
    required String body,
    String type = 'general',
  }) async {
    await ensureOpen();
    if (!canAddNotificationToday(type)) {
      return false; // Dropped to avoid notification spam (max 5-10 per day)
    }
    // One SMS can be announced by the native listener and again by Flutter.
    // Keep the transaction; skip a second history row for the same message.
    if (type == 'sms_pending' || type == 'sms_auto') {
      final cutoff = DateTime.now().subtract(const Duration(minutes: 2));
      final duplicate = all().take(8).any(
            (r) =>
                r.type == type &&
                r.body == body &&
                r.createdAt.isAfter(cutoff),
          );
      if (duplicate) return false;
    }
    final record = AppNotificationRecord(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      title: title,
      body: body,
      type: type,
      createdAt: DateTime.now(),
    );
    final raw = _box.get(_listKey, defaultValue: <dynamic>[]) as List;
    final list = raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
    list.insert(0, record.toMap());
    if (list.length > maxItems) {
      list.removeRange(maxItems, list.length);
    }
    await _box.put(_listKey, list);
    return true;
  }

  static List<AppNotificationRecord> all() {
    if (!Hive.isBoxOpen(boxName)) return [];
    final raw = _box.get(_listKey, defaultValue: <dynamic>[]) as List;
    return raw
        .map((e) => AppNotificationRecord.fromMap(Map<String, dynamic>.from(e as Map)))
        .toList();
  }

  static Future<void> markAllRead() async {
    await ensureOpen();
    final items = all().map((r) => r.copyWith(isRead: true).toMap()).toList();
    await _box.put(_listKey, items);
  }

  static Future<void> clear() async {
    await ensureOpen();
    await _box.put(_listKey, <dynamic>[]);
  }
}

extension _AppNotificationCopy on AppNotificationRecord {
  AppNotificationRecord copyWith({bool? isRead}) {
    return AppNotificationRecord(
      id: id,
      title: title,
      body: body,
      type: type,
      createdAt: createdAt,
      isRead: isRead ?? this.isRead,
    );
  }
}

final notificationHistoryProvider = Provider<List<AppNotificationRecord>>((ref) {
  return NotificationHistoryService.all();
});

final hasUnreadNotificationsProvider = Provider<bool>((ref) {
  final records = ref.watch(notificationHistoryProvider);
  return records.any((r) => !r.isRead);
});