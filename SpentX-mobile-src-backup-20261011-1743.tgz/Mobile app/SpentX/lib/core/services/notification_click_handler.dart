import 'dart:async';
import 'dart:convert';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../router/app_router.dart' show appRouter;
import '../../features/sms/detected/detected_sms_storage.dart';
import '../../features/sms/detected/pending_verification_presenter.dart';
import '../../features/sms/core/sms_pending_service.dart';
import '../providers/transaction_provider.dart' as model;
import '../debug/master_debug_log.dart';

/// Routes notification taps by exact [transactionId] — Hive source of truth.
class NotificationClickHandler {
  NotificationClickHandler._();

  static void handle({
    required WidgetRef ref,
    required String payload,
  }) {
    if (payload.isEmpty) return;

    String? txId;
    bool isPendingPayload = false;
    try {
      if (payload.startsWith('{')) {
        final json = jsonDecode(payload) as Map<String, dynamic>;
        txId = json['transactionId']?.toString();
        final p = json['pending'];
        isPendingPayload = p == true || p?.toString().toLowerCase() == 'true';
      }
    } catch (_) {}

    if (txId != null && txId.isNotEmpty) {
      MasterDebugLog.notification(
        title: 'Notification Clicked',
        message: txId,
        payload: {'transactionId': txId, 'pending': isPendingPayload},
      );
      _openExactTransaction(ref: ref, transactionId: txId, isPendingPayload: isPendingPayload);
      return;
    }

    ref.read(openPendingVerificationOnHomeProvider.notifier).state = true;
    appRouter.go('/home');
  }

  static void _openExactTransaction({
    required WidgetRef ref,
    required String transactionId,
    required bool isPendingPayload,
  }) {
    final inDetectedBox = DetectedSmsStorage.get(transactionId) != null;
    final inQueue = Hive.isBoxOpen('pending_detections') &&
        (Hive.box('pending_detections').get('queue', defaultValue: const <dynamic>[]) as List)
            .contains(transactionId);

    if (inDetectedBox || inQueue || isPendingPayload) {
      DetectedSmsStorage.markPopupOpened(transactionId);
      unawaited(SmsPendingService.storeNotificationTapTarget(transactionId));
      PendingVerificationPresenter.requestShow(ref, targetTransactionId: transactionId);
      appRouter.go('/home');
      return;
    }

    final txs = ref.read(model.transactionProvider);
    final tx = txs.where((t) => t.id == transactionId).firstOrNull;
    if (tx != null) {
      if (tx.isPendingVerification) {
        DetectedSmsStorage.markPopupOpened(transactionId);
        unawaited(SmsPendingService.storeNotificationTapTarget(transactionId));
        PendingVerificationPresenter.requestShow(ref, targetTransactionId: transactionId);
        appRouter.go('/home');
      } else {
        appRouter.go('/transaction/$transactionId');
      }
      return;
    }

    ref.read(openPendingVerificationOnHomeProvider.notifier).state = true;
    appRouter.go('/home');
  }
}