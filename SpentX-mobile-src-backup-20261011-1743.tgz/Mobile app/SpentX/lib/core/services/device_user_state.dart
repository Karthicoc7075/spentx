import 'package:hive_flutter/hive_flutter.dart';

import '../../data/local/hive_service.dart';
import '../sync/durable_collection.dart';

/// Small encrypted per-user store that survives the logout wipe (it is not
/// in AppResetService's box list). Only "Reset app data" clears it.
///
/// Holds, keyed by user id:
///  * the first time SMS detection ran for that user on this phone, so the
///    3-day inbox catch-up still works after a re-login;
///  * outbox changes that could not upload because the server table does not
///    exist yet (migration not run), so logout never loses them and the same
///    user gets them back on next sign-in.
/// Nothing here is ever shown to, or restored for, a different account.
class DeviceUserState {
  DeviceUserState._();

  static const boxName = 'device_user_state';

  static Future<Box> _open() => SecureHive.openBox(boxName);

  static String _smsKey(String uid) => 'sms_activity_started_at:$uid';
  static String _parkKey(String area, String uid) => 'parked:$area:$uid';

  static Future<DateTime?> smsActivityStart(String uid) async {
    try {
      final box = await _open();
      return DateTime.tryParse(box.get(_smsKey(uid))?.toString() ?? '');
    } catch (_) {
      return null;
    }
  }

  /// Keeps the earliest start ever seen for [uid].
  static Future<void> rememberSmsActivityStart(String uid, DateTime at) async {
    try {
      final box = await _open();
      final existing = DateTime.tryParse(box.get(_smsKey(uid))?.toString() ?? '');
      if (existing != null && !at.isBefore(existing)) return;
      await box.put(_smsKey(uid), at.toIso8601String());
    } catch (_) {}
  }

  /// Copies [store]'s unsynced changes aside before a wipe.
  static Future<void> park(String area, String uid, DurableCollection store) async {
    final raw = store.exportRaw();
    if (raw == null) return;
    final hasWork = ((raw['pending'] as Map?)?.isNotEmpty ?? false) ||
        ((raw['failed'] as Map?)?.isNotEmpty ?? false);
    if (!hasWork) return;
    try {
      final box = await _open();
      await box.put(_parkKey(area, uid), raw);
    } catch (_) {}
  }

  /// Re-queues changes parked for [uid] into [store] (once).
  static Future<void> restoreParked(String area, String uid, DurableCollection store) async {
    try {
      final box = await _open();
      final raw = box.get(_parkKey(area, uid));
      if (raw is! Map) return;
      await store.mergeParked(Map<String, dynamic>.from(raw));
      await box.delete(_parkKey(area, uid));
    } catch (_) {}
  }

  /// Full app reset only.
  static Future<void> clearAll() async {
    try {
      final box = await _open();
      await box.clear();
    } catch (_) {}
  }
}
