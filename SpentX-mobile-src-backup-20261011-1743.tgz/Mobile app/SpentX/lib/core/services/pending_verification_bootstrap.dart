import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../features/background_detection/notification_service.dart';
import '../../core/providers/transaction_provider.dart' as model;
import '../../features/sms/detected/auto_rule_engine.dart';
import '../../features/sms/detected/detection_queue.dart';
import '../../features/sms/detected/pending_verification_presenter.dart';
import '../../features/sms/core/sms_pending_service.dart';

/// Drains native pending payloads and signals verify popup — does not present directly.
class PendingVerificationBootstrap {
  PendingVerificationBootstrap._();

  static Future<void> processStartupAndShowIfNeeded({
    required WidgetRef ref,
    BuildContext? context,
  }) async {
    await _prepare(ref);
    final target = await _resolveShowTarget(ref);
    if (target == null) return;
    await _signalOrPresent(
      ref: ref,
      context: (context != null && context.mounted) ? context : null,
      targetTransactionId: target,
    );
  }

  static Future<void> afterUnlock({
    required BuildContext context,
    required WidgetRef ref,
  }) async {
    if (PendingVerificationPresenter.popupAlreadyOpen) return;

    await _prepare(ref);
    final target = await _resolveShowTarget(ref);
    if (target == null) return;
    await _signalOrPresent(
      ref: ref,
      context: context.mounted ? context : null,
      targetTransactionId: target,
    );
  }

  /// Notification tap survives cold start via Hive; otherwise show oldest pending.
  static Future<String?> _resolveShowTarget(WidgetRef ref) async {
    final tappedId = SmsPendingService.consumeNotificationTapTarget();
    if (tappedId != null && tappedId.isNotEmpty) return tappedId;

    final openFromNative = await NotificationService.shouldOpenPendingQueue();
    if (openFromNative) {
      final awaiting = SmsPendingService.listAwaitingVerification();
      if (awaiting.isNotEmpty) return awaiting.first.id;
    }

    final pending = SmsPendingService.listAwaitingVerification();
    if (pending.isEmpty) return null;

    return ref.read(openPendingVerificationForTxProvider) ?? pending.first.id;
  }

  /// Present directly when [context] is ready; otherwise signal providers (pre-mount).
  static Future<void> _signalOrPresent({
    required WidgetRef ref,
    BuildContext? context,
    required String targetTransactionId,
  }) async {
    PendingVerificationPresenter.requestShow(ref, targetTransactionId: targetTransactionId);
    if (context != null && context.mounted && !PendingVerificationPresenter.popupAlreadyOpen) {
      await PendingVerificationPresenter.processQueueIfNeeded(
        context: context,
        ref: ref,
        targetTransactionId: targetTransactionId,
      );
    }
  }

  static Future<void> _prepare(WidgetRef ref) async {
    _refreshTransactions(ref);
    await AutoRuleEngine.flushDeferredAutoAdds(ref: ref);
    await NotificationService.processAllPendingPayloads(ref: ref);
    SmsPendingService.reconcile();
    ref.read(detectionQueueProvider.notifier).refresh();
  }

  static void _refreshTransactions(WidgetRef ref) {
    ref.read(model.transactionProvider.notifier).reloadFromStorage();
    ref.invalidate(model.transactionProvider);
  }
}