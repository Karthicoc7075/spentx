import 'dart:async';

import 'package:flutter/widgets.dart';
import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../../features/background_detection/notification_service.dart';
import '../../features/sms/background/background_sms_scheduler.dart';
import '../../features/sms/detected/sms_inbox_catch_up.dart';
import '../../features/sms/sms_service.dart';
import '../../features/transactions/data/sms_receiver_service.dart';
import '../debug/master_debug_log.dart';
import '../sync/connectivity_sync_listener.dart';
import '../sync/realtime_foreground_sync.dart';
import '../sync/sms_rules_refresh_service.dart';
import '../sync/sync_service.dart';
import 'auth_service.dart';
import 'auto_detection_native_sync.dart';

/// Every background service that may only run for a signed-in user:
/// SMS detection, notification listening, background sync, API sync and the
/// WorkManager jobs.
///
/// Nothing here may be started from `main()`. A logged-out device must not
/// listen for SMS, must not hold a realtime socket, must not schedule jobs,
/// and must never be asked for SMS permission — the permission prompt itself
/// is a protected action, since it only makes sense once there's an account to
/// attach detected spends to.
class AuthGatedServices {
  AuthGatedServices._();

  static bool _running = false;

  /// True once [start] has run for the current session.
  static bool get isRunning => _running;

  /// Starts the protected services. Safe to call repeatedly — it no-ops while
  /// already running, and refuses to start at all without a valid session.
  static Future<void> start() async {
    if (_running) return;
    if (AuthService.syncHeldForAccountSwitch) {
      await MasterDebugLog.startup(
        'Protected services NOT started — account switch pending',
      );
      return;
    }
    if (!AuthService.isSignedIn) {
      await MasterDebugLog.startup(
        'Protected services NOT started — no session',
      );
      return;
    }
    _running = true;
    // Respect the user's "Automatic SMS Detection" choice. Only a device that
    // has never stored one gets the default (on).
    final settings = Hive.box('settings');
    if (!settings.containsKey('auto_detection')) {
      await settings.put('auto_detection', true);
    }
    await AutoDetectionNativeSync.setAuthenticated(true);
    await AutoDetectionNativeSync.syncToNative();

    // These receivers and WorkManager jobs are implemented by Android only.
    if (!kIsWeb && defaultTargetPlatform == TargetPlatform.android) {
      await SmsService.ensureActivityStartTime();
      SmsService.init();
      await SmsService.requestPermissions();
      await SmsReceiverService.startListening();
      NotificationService.startListening();
      await BackgroundSmsScheduler.initialize(isDebug: false);
      // Pick up bank SMS from the last 3 days that never reached detection.
      unawaited(SmsInboxCatchUp.runIfDue());
    }

    // Sync.
    await SyncService.start();
    ConnectivitySyncListener.start();
    RealtimeForegroundSync.start();
    SmsRulesRefreshService.refreshIfStale();

    await MasterDebugLog.startup('Protected services started (authenticated)');
  }

  /// Stops everything [start] began. Called on sign-out and whenever session
  /// validation fails.
  static Future<void> stop() async {
    await AutoDetectionNativeSync.setAuthenticated(false);
    // Always cancel sync timers and reset sync state on logout.
    SyncService.resetSyncState();
    if (!_running) return;
    _running = false;

    RealtimeForegroundSync.stop();
    ConnectivitySyncListener.stop();
    await BackgroundSmsScheduler.cancelAll();
    await SmsReceiverService.stopListening();
    NotificationService.stopListening();

    await MasterDebugLog.startup('Protected services stopped (signed out)');
  }

  /// Re-checks the session and starts or stops accordingly. Call on app start,
  /// on resume, and after any auth state change.
  static Future<void> syncWithSession() async {
    if (AuthService.isSignedIn) {
      AuthService.armAccountSwitchHoldIfNeeded();
    }
    if (AuthService.isSignedIn && !AuthService.syncHeldForAccountSwitch) {
      await start();
    } else {
      // Stop even if start never ran, so a previous account's timer cannot
      // push this device's queue onto the account that just signed in.
      await stop();
    }
  }

  /// Guard for anything that touches protected data or shows a transaction
  /// popup. Returns false (and tears services down) when there's no session.
  static bool get canUseProtectedFeatures {
    if (AuthService.isSignedIn) return true;
    if (_running) unawaited(stop());
    return false;
  }
}

/// Convenience for widgets that must not render protected content.
bool get isAuthenticatedSession => AuthService.isSignedIn;

/// Debounced helper so lifecycle callbacks don't hammer [AuthGatedServices].
void scheduleSessionSync() {
  WidgetsBinding.instance.addPostFrameCallback((_) {
    unawaited(AuthGatedServices.syncWithSession());
  });
}
