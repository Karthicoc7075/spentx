import 'package:hive_flutter/hive_flutter.dart';
import 'notification_history_service.dart';

/// Budget threshold alerts — no Riverpod dependency (avoids circular imports).
class BudgetAlertService {
  static Future<void> checkAfterExpense({
    required String category,
    required List<Map<String, dynamic>> budgets,
    required double Function(String category) monthlySpent,
  }) async {
    final now = DateTime.now();
    for (final raw in budgets) {
      final budgetCategory = raw['category']?.toString() ?? '';
      if (budgetCategory.toLowerCase() != category.toLowerCase()) continue;

      final limit = (raw['limit'] as num?)?.toDouble() ?? 0;
      if (limit <= 0) continue;

      final notify80 = raw['notifyAt80'] != false;
      final notify100 = raw['notifyAt100'] != false;
      final id = raw['id']?.toString() ?? budgetCategory;
      final spent = monthlySpent(budgetCategory);
      final pct = spent / limit;

      final alertKey = 'budget_alert_${id}_${now.year}_${now.month}';
      final fired = Hive.box('settings').get(alertKey, defaultValue: <String>[]) as List;
      final firedList = List<String>.from(fired);

      if (notify100 && pct >= 1.0 && !firedList.contains('100')) {
        firedList.add('100');
        await NotificationHistoryService.add(
          title: 'Budget exceeded',
          body: '$budgetCategory: ₹${spent.toInt()} / ₹${limit.toInt()} limit',
          type: 'budget',
        );
      } else if (notify80 && pct >= 0.8 && pct < 1.0 && !firedList.contains('80')) {
        firedList.add('80');
        await NotificationHistoryService.add(
          title: 'Budget warning (80%)',
          body: '$budgetCategory: ₹${spent.toInt()} of ₹${limit.toInt()} used',
          type: 'budget',
        );
      }
      await Hive.box('settings').put(alertKey, firedList);
    }
  }
}