import '../providers/outing_provider.dart';

/// Builds [OutingExpense] rows for SMS/auto transactions linked to a trip.
class OutingTransactionSync {
  /// All outing members when the trip has friends; otherwise solo (you only).
  static ({SplitType splitType, List<String> memberIds}) defaultSplit(Outing outing) {
    final friends = outing.members.where((m) => m.name.toLowerCase() != 'you').toList();
    if (friends.isEmpty) {
      return (splitType: SplitType.solo, memberIds: ['you']);
    }
    final memberIds = [
      for (final m in outing.members)
        m.name.toLowerCase() == 'you' ? 'you' : m.id,
    ];
    return (splitType: SplitType.equally, memberIds: memberIds);
  }

  static OutingExpense buildExpense({
    required Outing outing,
    required String transactionId,
    required String title,
    required double amount,
    required String category,
    required DateTime date,
    required String paymentMode,
    required String? accountId,
    String purpose = 'Personal',
    OutingExpense? existing,
    SplitType? splitType,
    List<String>? memberIds,
    String? paidByMemberId,
    Map<String, double>? customSplitAmounts,
  }) {
    final defaults = defaultSplit(outing);
    final youId = outing.members
        .where((m) => m.name.toLowerCase() == 'you')
        .firstOrNull
        ?.id;
    final payer = paidByMemberId ??
        existing?.paidByMemberId ??
        youId ??
        'you';
    return OutingExpense(
      id: existing?.id,
      title: title,
      amount: amount,
      category: category,
      date: date,
      paymentMode: paymentMode,
      accountId: accountId,
      purpose: purpose,
      paidByMemberId: payer,
      transactionId: transactionId,
      splitType: splitType ?? existing?.splitType ?? defaults.splitType,
      memberIds: memberIds ?? existing?.memberIds ?? defaults.memberIds,
      settledMemberIds: existing?.settledMemberIds ?? const [],
      settledModes: existing?.settledModes ?? const {},
      settlementPayments: existing?.settlementPayments ?? const {},
      customSplitAmounts: customSplitAmounts ?? existing?.customSplitAmounts,
    );
  }

  static String splitSummary(Outing outing, OutingExpense expense) {
    if (expense.splitType == SplitType.solo || expense.memberIds.length <= 1) {
      return 'Solo — only you';
    }
    final names = <String>[];
    for (final mId in expense.memberIds) {
      if (mId == 'you') {
        names.add('You');
        continue;
      }
      final m = outing.members.where((m) => m.id == mId).firstOrNull;
      names.add(m?.name ?? 'Friend');
    }
    return 'Split (${expense.memberIds.length}): ${names.join(', ')}';
  }
}