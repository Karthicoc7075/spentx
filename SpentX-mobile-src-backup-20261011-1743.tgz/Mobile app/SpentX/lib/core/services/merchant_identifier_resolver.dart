import '../../features/sms_parser/models/transaction_parsed.dart';
import '../../features/sms/v4/payee_extractor.dart';
import '../../features/sms/v4/payee_normalizer.dart';
import '../models/merchant_rule.dart';
import 'merchant_rule_service.dart';

/// Resolves stable merchant lookup keys (UPI / phone / parsed id) separately from
/// human-readable transaction titles. Rule matching uses [stableKey] only;
/// [displayTitle] is what users see until they rename and save a rule.
class MerchantIdentifierResolver {
  MerchantIdentifierResolver._();

  static const _genericNoise = {
    'clearing',
    'credited',
    'deposited',
    'received',
    'balance',
    'avl',
    'available',
    'unknown',
    'tpt',
    'neft',
    'imps',
    'rtgs',
    'transfer',
    'info',
    'ref',
    'xx',
    'account',
    'bank',
    'a/c',
  };

  static bool isGeneric(String value) {
    final l = value.trim().toLowerCase();
    if (l.isEmpty || l == 'unknown') return true;
    return _genericNoise.contains(l);
  }

  static String? _firstUpi(String? upiId, String? rawMessage) {
    final direct = upiId?.trim();
    if (direct != null && direct.isNotEmpty) return direct;
    if (rawMessage == null || rawMessage.isEmpty) return null;
    return MerchantRuleService.extractUpiFromMessage(rawMessage);
  }

  static String? _meaningfulId(String? value) {
    final v = value?.trim();
    if (v == null || v.isEmpty || isGeneric(v)) return null;
    return v;
  }

  /// Primary lookup key — unique per UPI / phone / parsed merchant id.
  static String stableKey({
    String? upiId,
    String? rawIdentifier,
    String? parsedName,
    String? rawMessage,
  }) {
    final upi = _firstUpi(upiId, rawMessage);
    if (upi != null && upi.isNotEmpty) return upi;

    final raw = _meaningfulId(rawIdentifier);
    if (raw != null) return raw;

    final name = _meaningfulId(parsedName);
    if (name != null) return name;

    if (rawMessage != null && rawMessage.isNotEmpty) {
      final payee = PayeeExtractor.extract(rawMessage);
      if (payee != null && PayeeNormalizer.isMeaningful(payee)) return payee;
    }

    return '';
  }

  /// Parsed title from SMS before any saved merchant rule is applied.
  static String parsedTitle({
    required String rawMessage,
    TransactionParsed? parsed,
  }) {
    final upi = _firstUpi(parsed?.upiId, rawMessage);
    if (upi != null && upi.isNotEmpty) return upi;

    if (rawMessage.isNotEmpty) {
      final payee = PayeeExtractor.extract(rawMessage);
      if (payee != null && PayeeNormalizer.isMeaningful(payee)) return payee;
    }

    final parsedName = _meaningfulId(parsed?.name);
    if (parsedName != null) return parsedName;

    final rawId = _meaningfulId(parsed?.rawIdentifier);
    if (rawId != null) return rawId;

    return 'Unknown';
  }

  /// Final transaction title: saved rule name when identifier matches, else parsed SMS title.
  static String displayTitle({
    required String rawMessage,
    TransactionParsed? parsed,
    MerchantRule? matchedRule,
    String? upiId,
    String? rawIdentifier,
  }) {
    if (matchedRule != null) return matchedRule.displayName;
    return parsedTitle(rawMessage: rawMessage, parsed: parsed);
  }

  /// Keys used for Hive merchant rule lookup.
  static Set<String> lookupCandidates({
    String? upiId,
    String? rawIdentifier,
    String? parsedName,
    String? rawMessage,
  }) {
    final keys = <String>{};
    void add(String? value) {
      final v = value?.trim();
      if (v == null || v.isEmpty || isGeneric(v)) return;
      keys.add(MerchantRuleService.normalizeIdentifier(v));
      if (MerchantRuleService.looksLikeUpi(v)) {
        keys.add(MerchantRuleService.normalizeIdentifier(v));
      }
      final digits = v.replaceAll(RegExp(r'\D'), '');
      if (digits.length >= 10) keys.add(digits);
    }

    add(_firstUpi(upiId, rawMessage));
    add(rawIdentifier);
    if (rawMessage != null && rawMessage.isNotEmpty) {
      add(PayeeExtractor.extract(rawMessage));
    }
    return keys;
  }
}