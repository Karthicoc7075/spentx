import 'package:hive_flutter/hive_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../features/sms/rules/sms_hive_boxes.dart';
import 'auth_service.dart';
import 'device_user_state.dart';
import 'pin_service.dart';
import 'notification_history_service.dart';
import 'pending_verification_history_service.dart';
import 'auto_detection_native_sync.dart';
import '../sync/sync_service.dart';
import '../../data/local/hive_service.dart';

/// Clears all app data and restores defaults for a fresh start.
/// Data is only erased on explicit user action (Erase/Reset); normal app close does nothing.
class AppResetService {
  /// Full "Reset App Data": wipes everything AND signs the Supabase session
  /// out — equivalent to a fresh install; next open lands at /auth.
  static Future<void> resetAll() async {
    // Flush any offline-queued writes to Supabase FIRST, while the current
    // session is still the account that owns them — otherwise unsynced
    // transactions/edits made offline are deleted with the local wipe below
    // and never reach the database. Best-effort: if offline, this simply
    // times out/fails and those items are lost same as before (unavoidable
    // without a network connection), but it never makes things worse.
    try {
      await SyncService.pushPending().timeout(const Duration(seconds: 10));
    } catch (_) {}

    // Sign out (clears the persisted session deliberately — a reset
    // that leaves you logged in to a cloud account with empty local data
    // would be a confusing half-state).
    // signOut wipes local data when the app shell is up. Wipe again here so
    // a reset still empties the phone if that hook is not registered yet.
    await AuthService.signOut(discardUnsyncedChanges: true);
    await _wipeLocalData();
    // A full reset is a fresh install: also forget per-user device state
    // (SMS first-use time, changes parked across logout).
    await DeviceUserState.clearAll();
  }

  /// Account-switch wipe: erases all local data but KEEPS the current
  /// Supabase session (used when a different account signs in on a device
  /// with a previous account's local data and chooses "Erase & start fresh").
  static Future<void> resetLocalDataKeepSession() async {
    String? refreshToken;
    try {
      refreshToken =
          Supabase.instance.client.auth.currentSession?.refreshToken;
    } catch (_) {}

    await _wipeLocalData();

    // SharedPreferences.clear() above also removed the persisted Supabase
    // session — restore it from the refresh token so the new user stays
    // signed in.
    if (refreshToken != null && refreshToken.isNotEmpty) {
      try {
        await Supabase.instance.client.auth.setSession(refreshToken);
      } catch (_) {}
    }
    AuthService.rememberCurrentUser();
  }

  /// Empties Hive and SharedPreferences. Safe to call more than once.
  static Future<void> wipeLocalData() => _wipeLocalData();

  static Future<void> _wipeLocalData() async {
    final boxNames = <String>{
      'merchant_aliases',
      'categories',
      'outings',
      'transactions',
      'friends',
      'friend_splits',
      'friend_reminders',
      'pending_accounts',
      'monthly_plans',
      'wealth_snapshots',
      'merchants_box',
      'merchant_rules_box',
      'pending_detections',
      'detected_sms_box',
      'ignored_detections',
      'budgets',
      'investments',
      'vault',
      NotificationHistoryService.boxName,
      PendingVerificationHistoryService.boxName,
      'settings',
      'user',
      'processed_sms_box',
      'user_state',
      ...SmsHiveBoxes.allRuleBoxes,
      SmsHiveBoxes.legacyBlockRules,
      SmsHiveBoxes.legacyRegexRules,
      SmsHiveBoxes.legacyTemplateRules,
      'master_debug_log_box',
      'sync_queue',
    };

    for (final name in boxNames) {
      try {
        if (Hive.isBoxOpen(name)) {
          await Hive.box(name).clear();
        } else {
          // open briefly just to clear then close (ensures wipe even if lazy)
          final box = await SecureHive.openBox(name);
          await box.clear();
          await box.close();
        }
      } catch (_) {}
    }

    // (known list + explicit open/clear covers all app data for complete erase)

    // Re-open minimal settings and seed first-time flags (so popup appears on reopen)
    final settings = await SecureHive.openBox('settings');
    await settings.clear();
    await settings.put('has_seen_onboarding', false);
    await settings.put('isFirstTimeUser', true);
    await settings.put('auto_detection', true);
    await AutoDetectionNativeSync.syncToNative();
    await settings.put('lock_screen_enabled', true);
    // do not restore profile etc.

    await PinService.clearPin();

    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    SyncService.resetSyncState();
  }
}
