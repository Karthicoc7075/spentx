import 'dart:async';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/supabase_config.dart';
import '../router/app_router.dart';
import '../sync/supabase_schema_map.dart';
import 'auth_gated_services.dart';
import 'sign_out_guard.dart';
import '../../features/wealth/data/savings_goal_service.dart';
import '../../features/investments/data/investment_service.dart';
import '../../features/wealth/data/snapshot_outbox.dart';
import '../../features/recurring/data/recurring_bill_service.dart';
import '../sync/sync_service.dart';
import '../sync/sync_queue.dart';
import '../../features/wealth/data/projector_service.dart';

/// Thin wrapper around Supabase Auth for the required signup/login flow.
///
/// Sign-in is REQUIRED to use the app (see splash gate + router redirect).
/// PIN remains a second, local lock layered on top of the Supabase session —
/// the session itself persists silently across app resumes via Supabase's
/// normal token refresh; only PIN is re-prompted on resume.
class AuthService {
  AuthService._();

  static bool _initialized = false;
  static const FlutterSecureStorage _secureStorage = FlutterSecureStorage();

  /// True while [signIn] is in flight. The confirm-link listener must not
  /// treat that session as "verified, now log in".
  static bool passwordSignInInProgress = false;

  /// Email-confirm link created a session. Stay on the verify screen and
  /// require an explicit sign-in. Not a substitute for [setup_completed].
  static bool verifiedAwaitingLogin = false;
  static bool _handoffRunning = false;
  static const verifiedAwaitingLoginKey = 'verified_awaiting_login_email';

  /// Hive mirror of "show the post-setup permission ask once".
  /// Explicit true only — missing means existing users are not nagged.
  static const permissionsPromptPendingKey = 'permissions_prompt_pending';

  /// Hive settings key remembering which Supabase user last used this device.
  /// Used to detect the "different account signs in over existing local data"
  /// edge case so the user gets an explicit keep-or-erase choice.
  static const lastUserIdKey = 'last_auth_user_id';
  static const lastUserEmailKey = 'last_auth_user_email';
  static const accountCreatedAtDateKey = 'account_created_at_date';

  /// Secure storage keys for 1-year token validity requirement.
  static const authTokenKey = 'auth_token';
  static const authTokenCreatedAtKey = 'auth_token_created_at';

  /// Set from the app shell. Runs before the session is dropped so Hive and
  /// in-memory providers are empty before the next account signs in.
  static Future<void> Function()? clearLocalDataOnSignOut;

  static bool _signingOut = false;

  static SupabaseClient get _client => Supabase.instance.client;

  static bool get isConfigured => SupabaseConfig.isConfigured;

  /// Initializes Supabase and wires the password-recovery deep-link handler.
  /// Safe no-op when the project keys haven't been pasted in yet — the app
  /// then routes to /auth which shows a configuration notice.
  static Future<void> init() async {
    if (_initialized || !isConfigured) return;
    await Supabase.initialize(
      url: SupabaseConfig.url,
      publishableKey: SupabaseConfig.anonKey,
      authOptions: const FlutterAuthClientOptions(
        authFlowType: AuthFlowType.pkce,
        // Persist + auto-refresh so login survives restarts; only signOut clears.
        autoRefreshToken: true,
      ),
    );
    _initialized = true;
    _restoreVerifiedAwaitingLogin();

    // supabase_flutter consumes the spentx://reset-password deep link itself
    // (app_links) and emits passwordRecovery once the recovery session is set.
    _client.auth.onAuthStateChange.listen((data) {
      if (data.event == AuthChangeEvent.passwordRecovery) {
        appRouter.go('/auth/reset-password');
        if (data.session != null) clearPendingVerificationEmail();
        return;
      }
      if (data.session == null) return;
      // Confirm link: a session arrived for an address that has never
      // completed a password sign-in on this device. Do not enter the app.
      // A restored session for someone who already signed in just clears
      // a leftover pending flag — it must not sign them out.
      final pending = pendingVerificationEmail;
      final alreadyUsedHere = previousAccountEmail().trim().toLowerCase() ==
          (pending ?? '').trim().toLowerCase();
      if (!passwordSignInInProgress &&
          pending != null &&
          pending.isNotEmpty &&
          !alreadyUsedHere) {
        markVerifiedAwaitingLogin(pending);
        clearPendingVerificationEmail();
        unawaited(handoffVerifiedEmailToLogin());
        return;
      }
      // A real sign-in (or a restored session) ends the pending signup.
      clearPendingVerificationEmail();
    });
  }

  static void _restoreVerifiedAwaitingLogin() {
    if (!Hive.isBoxOpen('settings')) return;
    final v = Hive.box('settings').get(verifiedAwaitingLoginKey);
    verifiedAwaitingLogin = v is String && v.trim().isNotEmpty;
  }

  static void markVerifiedAwaitingLogin(String email) {
    verifiedAwaitingLogin = true;
    if (Hive.isBoxOpen('settings')) {
      Hive.box('settings').put(verifiedAwaitingLoginKey, email.trim());
    }
  }

  static void clearVerifiedAwaitingLogin() {
    verifiedAwaitingLogin = false;
    _handoffRunning = false;
    if (Hive.isBoxOpen('settings')) {
      Hive.box('settings').delete(verifiedAwaitingLoginKey);
    }
  }

  /// Drops the confirm-link session and returns to the verify screen so the
  /// user signs in themselves. Idempotent.
  static Future<void> handoffVerifiedEmailToLogin() async {
    if (_handoffRunning) return;
    _handoffRunning = true;
    final box = Hive.isBoxOpen('settings') ? Hive.box('settings') : null;
    final saved = box?.get(verifiedAwaitingLoginKey);
    final email = (saved is String && saved.trim().isNotEmpty)
        ? saved.trim()
        : (pendingVerificationEmail ?? '');
    markVerifiedAwaitingLogin(email.isEmpty ? 'verified' : email);
    clearPendingVerificationEmail();
    try {
      if (isSignedIn) {
        // Session only. A full sign-out wipes this phone, and the confirm
        // link must not erase a previous account's ledger before login.
        await signOutSessionOnly();
      }
    } catch (_) {}
    markVerifiedAwaitingLogin(email.isEmpty ? 'verified' : email);
    try {
      appRouter.go('/auth/verify-email?verified=1');
    } catch (_) {}
  }

  static Session? get session {
    if (!isConfigured) return null;
    try {
      return _client.auth.currentSession;
    } catch (_) {
      return null;
    }
  }

  static bool get isSignedIn => session != null;

  /// Set while a different account still has to choose Keep or Erase.
  /// Sync must not run until this is cleared, or the previous account's
  /// queued writes would be pushed to the new account.
  static const accountSwitchHoldKey = 'account_switch_sync_hold';

  static bool get syncHeldForAccountSwitch {
    if (!Hive.isBoxOpen('settings')) return false;
    return Hive.box('settings').get(accountSwitchHoldKey) == true;
  }

  /// Arms the hold when this sign-in is not the account that owns the data
  /// already on the device. Clears any stale hold when account is not different.
  static void armAccountSwitchHoldIfNeeded() {
    if (!Hive.isBoxOpen('settings')) return;
    if (!isDifferentAccountWithLocalData()) {
      if (syncHeldForAccountSwitch) {
        Hive.box('settings').delete(accountSwitchHoldKey);
      }
      return;
    }
    Hive.box('settings').put(accountSwitchHoldKey, true);
  }

  static Future<void> releaseAccountSwitchHold() async {
    if (!Hive.isBoxOpen('settings')) return;
    await Hive.box('settings').delete(accountSwitchHoldKey);
  }


  /// Notifies on every sign-in / sign-out / token refresh, with the resulting
  /// signed-in state. Used to start and stop protected background services.
  static StreamSubscription<AuthState>? onAuthStateChange(
    void Function(bool signedIn) listener,
  ) {
    if (!isConfigured) return null;
    return _client.auth.onAuthStateChange.listen((data) {
      switch (data.event) {
        case AuthChangeEvent.signedIn:
        case AuthChangeEvent.tokenRefreshed:
        case AuthChangeEvent.userUpdated:
        case AuthChangeEvent.initialSession:
          listener(data.session != null);
          break;
        case AuthChangeEvent.signedOut:
          listener(false);
          break;
        default:
          break;
      }
    });
  }

  /// True when a usable session exists — used as the gate before loading any
  /// protected screen or starting a background service.
  ///
  /// A cold start after being backgrounded/killed overnight almost always
  /// finds the access token expired (1hr default lifetime) — this proactively
  /// refreshes it rather than trusting the stale cached session object, so
  /// splash decides on current truth, not an hours-old snapshot.
  static Future<bool> hasValidSession() async {
    if (!isConfigured) return false;
    final current = session;
    if (current == null) return false;
    // An expired access token is only usable if it can still be refreshed.
    if (current.isExpired) {
      try {
        final refreshed = await _client.auth
            .refreshSession()
            .timeout(const Duration(seconds: 10));
        if (refreshed.session != null) {
          await saveTokenInfo(updateCreatedAt: false);
          return true;
        }
        return false;
      } on AuthException catch (e) {
        // Network blips are retryable and must not log the user out.
        // Every other auth error (invalid/used/revoked refresh token, etc.)
        // means this session is not valid. Do not keep treating it as signed in.
        if (e is AuthRetryableFetchException) return true;
        try {
          await signOutSessionOnly();
        } catch (_) {}
        return false;
      } catch (_) {
        // Network failure or timeout at cold start (radio/WiFi not up yet,
        // DNS not ready) — keep cached session and retry when online.
        return true;
      }
    }
    return true;
  }

  /// Checks if the stored auth token exists and is within the 1-year (365 days) validity period.
  static Future<bool> isTokenValid() async {
    if (!isConfigured) return false;
    // Proactively refresh an expired session instead of trusting a possibly
    // hours-stale in-memory session object (see hasValidSession).
    if (!await hasValidSession()) return false;

    try {
      final createdAtStr = await _secureStorage.read(key: authTokenCreatedAtKey);
      if (createdAtStr == null) {
        // First initialization or migration: save current timestamp and token
        await saveTokenInfo();
        return true;
      }

      final createdAtMillis = int.tryParse(createdAtStr);
      if (createdAtMillis == null) {
        await saveTokenInfo();
        return true;
      }

      final createdAt = DateTime.fromMillisecondsSinceEpoch(createdAtMillis);
      final age = DateTime.now().difference(createdAt);

      // Token validity is 1 year (365 days).
      if (age.inDays > 365) {
        // Token has expired after 1 year. Force sign out.
        await signOut(discardUnsyncedChanges: true);
        return false;
      }

      return true;
    } catch (_) {
      // Fallback: if secure storage read fails, fall back to active session check
      return isSignedIn;
    }
  }

  /// Securely stores current auth token and creation timestamp.
  static Future<void> saveTokenInfo({bool updateCreatedAt = true}) async {
    final sess = session;
    if (sess != null) {
      final token = sess.accessToken;
      await _secureStorage.write(key: authTokenKey, value: token);
      if (updateCreatedAt) {
        final existingCreatedAt = await _secureStorage.read(key: authTokenCreatedAtKey);
        if (existingCreatedAt == null) {
          final nowMillis = DateTime.now().millisecondsSinceEpoch.toString();
          await _secureStorage.write(key: authTokenCreatedAtKey, value: nowMillis);
        }
      }
    }
  }

  static String? get currentUserId {
    if (!isConfigured) return null;
    try {
      return _client.auth.currentUser?.id;
    } catch (_) {
      return null;
    }
  }

  /// When the signed-in account was created (server time), if known.
  static DateTime? get currentUserCreatedAt {
    if (!isConfigured) return null;
    try {
      return DateTime.tryParse(_client.auth.currentUser?.createdAt ?? '');
    } catch (_) {
      return null;
    }
  }

  static String? get currentUserEmail {
    if (!isConfigured) return null;
    try {
      return _client.auth.currentUser?.email;
    } catch (_) {
      return null;
    }
  }

  /// This account's last successful sign-in, per Supabase's own record on
  /// the user — authoritative (server-set on every password/OTP/magic-link
  /// sign-in), so there's no separate local timestamp to keep in sync.
  static DateTime? get lastSignInAt {
    final raw = isConfigured ? _client.auth.currentUser?.lastSignInAt : null;
    if (raw == null) return null;
    return DateTime.tryParse(raw);
  }

  /// Display name from auth user_metadata (name / full_name), if set.
  static String? get currentUserDisplayName {
    if (!isConfigured || !_initialized) return null;
    final user = _client.auth.currentUser;
    if (user == null) return null;
    final meta = user.userMetadata;
    if (meta == null) return null;
    final name = (meta['name'] ?? meta['full_name'] ?? meta['display_name'])
        ?.toString()
        .trim();
    if (name != null && name.isNotEmpty) return name;
    return null;
  }

  /// Calendar date (UTC yyyy-MM-dd) when this account was created.
  /// Daily snapshots strictly begin from this date forward. Historical
  /// or backfilled transactions before this date never generate snapshots.
  static String? get accountCreatedDateKey {
    final raw =
        (isConfigured && _initialized) ? _client.auth.currentUser?.createdAt : null;
    if (raw != null && raw.length >= 10) {
      final key = raw.substring(0, 10);
      if (Hive.isBoxOpen('settings')) {
        Hive.box('settings').put(accountCreatedAtDateKey, key);
      }
      return key;
    }
    if (Hive.isBoxOpen('settings')) {
      final cached = Hive.box('settings').get(accountCreatedAtDateKey);
      if (cached is String && cached.isNotEmpty) return cached;
    }
    return null;
  }

  static Future<AuthResponse> signUp({
    required String email,
    required String password,
    String? name,
    String? phone,
  }) async {
    final trimmedName = name?.trim();
    final trimmedPhone = phone?.trim();
    final data = <String, dynamic>{};
    if (trimmedName != null && trimmedName.isNotEmpty) {
      data['name'] = trimmedName;
      data['full_name'] = trimmedName;
    }
    if (trimmedPhone != null && trimmedPhone.isNotEmpty) {
      data['phone'] = trimmedPhone;
    }
    final res = await _client.auth.signUp(
      email: email,
      password: password,
      data: data.isNotEmpty ? data : null,
      emailRedirectTo: SupabaseConfig.emailConfirmRedirect,
    );
    // Supabase often returns 200 with an empty identities list (and no error)
    // when the email is already registered, to avoid leaking account existence.
    // Surface a clear message instead of treating it as a successful signup.
    final identities = res.user?.identities;
    if (res.user != null && identities != null && identities.isEmpty) {
      throw const AuthException(
        'An account with this email already exists.',
        statusCode: '409',
        code: 'user_already_exists',
      );
    }
    if (res.session == null) {
      // Project has "Confirm email" enabled — no session until the user taps
      // the link in that email. Remember the address so a closed/reopened
      // app routes back to the "verify your email" screen instead of
      // login/home.
      savePendingVerificationEmail(email);
    } else {
      _rememberUser();
      await saveTokenInfo();
    }
    return res;
  }

  /// True when [signUp] returned no session — the project has email
  /// confirmation enabled and this account needs to confirm via the emailed
  /// link before it's usable. False means the account is already signed in.
  static bool needsEmailVerification(AuthResponse res) => res.session == null;

  /// Settings-box key: email awaiting link-confirmation after signup.
  static const pendingVerificationEmailKey = 'pending_verification_email';

  /// Email address with a signup in progress but not yet confirmed, if any.
  /// Persists across app restarts/kills so the router can send the user back
  /// to the "verify your email" screen instead of login or home.
  static String? get pendingVerificationEmail {
    if (!Hive.isBoxOpen('settings')) return null;
    final email = Hive.box('settings').get(pendingVerificationEmailKey);
    return (email is String && email.isNotEmpty) ? email : null;
  }

  static void savePendingVerificationEmail(String email) {
    if (Hive.isBoxOpen('settings')) {
      Hive.box('settings').put(pendingVerificationEmailKey, email);
    }
  }

  static void clearPendingVerificationEmail() {
    if (Hive.isBoxOpen('settings')) {
      Hive.box('settings').delete(pendingVerificationEmailKey);
    }
  }

  /// Re-sends the signup confirmation email to [email].
  static Future<void> resendConfirmationEmail(String email) {
    return _client.auth.resend(
      type: OtpType.signup,
      email: email,
      emailRedirectTo: SupabaseConfig.emailConfirmRedirect,
    );
  }

  static Future<AuthResponse> signIn({
    required String email,
    required String password,
  }) async {
    // Caller decides when to _rememberUser() — the account-switch check needs
    // the PREVIOUS user id still readable right after sign-in.
    passwordSignInInProgress = true;
    try {
      final res = await _client.auth.signInWithPassword(
        email: email,
        password: password,
      );
      clearVerifiedAwaitingLogin();
      clearPendingVerificationEmail();
      await saveTokenInfo();
      return res;
    } finally {
      passwordSignInInProgress = false;
    }
  }

  static Future<bool> signInWithGoogle() async {
    if (!isConfigured) return false;
    return _client.auth.signInWithOAuth(
      OAuthProvider.google,
      redirectTo: SupabaseConfig.emailConfirmRedirect,
    );
  }

  static Future<bool> signInWithApple() async {
    if (!isConfigured) return false;
    return _client.auth.signInWithOAuth(
      OAuthProvider.apple,
      redirectTo: SupabaseConfig.emailConfirmRedirect,
    );
  }

  static Future<void> sendPasswordReset(String email) {
    return _client.auth.resetPasswordForEmail(
      email,
      redirectTo: SupabaseConfig.resetPasswordRedirect,
    );
  }

  static Future<void> updatePassword(String newPassword) {
    return _client.auth.updateUser(UserAttributes(password: newPassword));
  }

  /// Drops the Supabase session without wiping Hive. Used when an email
  /// confirm link signs the user in and they still have to log in themselves.
  static Future<void> signOutSessionOnly() async {
    if (!isConfigured) return;
    try {
      await AuthGatedServices.stop();
    } catch (_) {}
    try {
      await _client.auth.signOut(scope: SignOutScope.local);
    } catch (_) {}
    try {
      await _secureStorage.delete(key: authTokenKey);
      await _secureStorage.delete(key: authTokenCreatedAtKey);
    } catch (_) {}
  }

  /// Normal logout may erase this device only after local writes are uploaded.
  /// Explicit reset and revoked/expired sessions use the destructive path.
  static Future<void> signOut({bool discardUnsyncedChanges = false}) async {
    if (_signingOut) return;
    _signingOut = true;
    try {
      if (!discardUnsyncedChanges) {
        await requireSyncedChanges(
          hasPending: () => !SyncQueue.isEmpty ||
              ProjectorService.hasPendingChanges ||
              SavingsGoalService.hasPendingChanges ||
              InvestmentService.hasPendingChanges ||
              SnapshotOutbox.hasPendingChanges ||
              RecurringBillService.hasPendingChanges,
          flush: () async {
            await SyncService.pushPending();
            if (ProjectorService.hasPendingChanges) await ProjectorService.flushPending();
            if (SavingsGoalService.hasPendingChanges) await SavingsGoalService.flushPending();
            if (InvestmentService.hasPendingChanges) await InvestmentService.flushPending();
            if (SnapshotOutbox.hasPendingChanges) await SnapshotOutbox.flushPending();
            if (RecurringBillService.hasPendingChanges) await RecurringBillService.flushPending();
          },
        );
      }
      if (isConfigured) {
        // Stop SMS detection, sync and scheduled jobs BEFORE dropping the
        // session, so nothing fires against a half-torn-down auth state.
        await AuthGatedServices.stop();
      }
      if (!discardUnsyncedChanges) {
        try {
          await SyncService.waitForIdle().timeout(const Duration(seconds: 15));
          // A receiver or edit may have queued a write while services stopped.
          await requireSyncedChanges(
            hasPending: () => !SyncQueue.isEmpty ||
                ProjectorService.hasPendingChanges ||
                SavingsGoalService.hasPendingChanges ||
                InvestmentService.hasPendingChanges ||
                SnapshotOutbox.hasPendingChanges ||
                RecurringBillService.hasPendingChanges,
            flush: () async {
              await SyncService.pushPending();
              if (ProjectorService.hasPendingChanges) await ProjectorService.flushPending();
              if (SavingsGoalService.hasPendingChanges) await SavingsGoalService.flushPending();
              if (InvestmentService.hasPendingChanges) await InvestmentService.flushPending();
              if (SnapshotOutbox.hasPendingChanges) await SnapshotOutbox.flushPending();
              if (RecurringBillService.hasPendingChanges) await RecurringBillService.flushPending();
            },
          );
        } catch (_) {
          if (isSignedIn) {
            try { await AuthGatedServices.start(); } catch (_) {}
          }
          throw const UnsyncedChangesException();
        }
      }
      // Changes the server cannot take yet (investments / goals migration not
      // run) are set aside for this same user before the wipe, so logout
      // neither blocks on them nor loses them.
      final parkUid = currentUserId;
      if (parkUid != null) {
        try {
          await InvestmentService.parkUnsynced(parkUid);
          await SavingsGoalService.parkUnsynced(parkUid);
        } catch (_) {}
      }
      // Manual sign-out, the 1-year expiry, and a dead session all land here.
      // Wipe this phone first so the next account cannot read the last one.
      try {
        await clearLocalDataOnSignOut?.call();
      } catch (_) {}
      if (!isConfigured) return;
      try {
        // Local scope, stated explicitly (it is also gotrue-dart's default,
        // unlike supabase-js where it is 'global'): drop THIS device's session
        // only. A global sign-out revokes every refresh token the account
        // holds, which would surface on web as an unexplained auto-logout.
        await _client.auth.signOut(scope: SignOutScope.local);
      } catch (_) {
        // Even if the network call fails, the local session is cleared.
      }
      try {
        await _secureStorage.delete(key: authTokenKey);
        await _secureStorage.delete(key: authTokenCreatedAtKey);
      } catch (_) {}
      try {
        await releaseAccountSwitchHold();
      } catch (_) {}
    } finally {
      _signingOut = false;
    }
  }

  /// Records the signed-in user as this device's known account.
  static void _rememberUser() => rememberCurrentUser();

  static void rememberCurrentUser() {
    final id = currentUserId;
    if (id == null || !Hive.isBoxOpen('settings')) return;
    final box = Hive.box('settings');

    // Onboarding state belongs to the account, not the device. These two
    // flags cache a *specific* account's answer, and `settings` deliberately
    // survives sign-out — so when a different id signs in they must be
    // dropped, or the new account inherits the previous one's routing. That
    // is exactly how a freshly re-created account (same email, new id, after
    // an admin delete) could land straight on Home having never onboarded:
    // the server said "not set up", but a stale local `true` answered first
    // whenever the server check could not complete.
    final previousId = box.get(lastUserIdKey)?.toString();
    if (previousId != null && previousId != id) {
      box.delete(accountHasDataKey);
      box.delete('has_seen_onboarding');
      box.delete(accountCreatedAtDateKey);
    }

    box.put(lastUserIdKey, id);
    box.put(lastUserEmailKey, currentUserEmail ?? '');
    final rawCreatedAt =
        isConfigured ? _client.auth.currentUser?.createdAt : null;
    if (rawCreatedAt != null && rawCreatedAt.length >= 10) {
      box.put(accountCreatedAtDateKey, rawCreatedAt.substring(0, 10));
    }
    saveTokenInfo();
  }

  /// Whether this device holds any of the *user's own* content locally.
  ///
  /// Sign-out wipes Hive. This still catches a sign-in on a device that kept
  /// data from an older build, or a switch that never went through sign-out.
  ///
  /// It used to look at `transactions` alone, which missed every other kind of
  /// content: a device carrying only friends, a trip, a budget or a holding
  /// reported "no local data", so the keep-or-erase prompt never appeared and
  /// the previous person's records silently became the new account's. Friends
  /// are the most visible case — [friendsProvider] derives its list from the
  /// manual friends box *plus* outing members *plus* friend-split members, so
  /// all three are checked here.
  static bool hasLocalUserData() {
    /// Boxes that keep everything under one 'list'-style key.
    bool listHasRows(String box, String key) {
      if (!Hive.isBoxOpen(box)) return false;
      final value = Hive.box(box).get(key);
      return value is List && value.isNotEmpty;
    }

    /// Boxes that write one entry per entity id.
    bool boxHasEntries(String box) =>
        Hive.isBoxOpen(box) && Hive.box(box).isNotEmpty;

    return listHasRows('transactions', 'list') ||
        listHasRows('friends', 'list') ||
        listHasRows('budgets', 'list') ||
        listHasRows('investments', 'holdings') ||
        boxHasEntries('outings') ||
        boxHasEntries('friend_splits');
  }

  /// Plain-language inventory of what is on this device, e.g.
  /// "1 friend, 2 trips". Empty when there is nothing.
  ///
  /// The keep-or-erase prompt used to describe the data only in the abstract
  /// ("transactions, accounts and settings"), so someone who had never
  /// knowingly added anything could not tell what they were being asked to
  /// keep — which is exactly how a stray friend from a previous session ends
  /// up quietly adopted into a brand-new account.
  static String localDataSummary() {
    int listCount(String box, String key) {
      if (!Hive.isBoxOpen(box)) return 0;
      final value = Hive.box(box).get(key);
      return value is List ? value.length : 0;
    }

    int entryCount(String box) =>
        Hive.isBoxOpen(box) ? Hive.box(box).length : 0;

    String plural(int n, String one, String many) =>
        '$n ${n == 1 ? one : many}';

    final parts = <String>[];
    void add(int n, String one, String many) {
      if (n > 0) parts.add(plural(n, one, many));
    }

    add(listCount('transactions', 'list'), 'transaction', 'transactions');
    add(listCount('friends', 'list'), 'friend', 'friends');
    add(entryCount('outings'), 'trip', 'trips');
    add(entryCount('friend_splits'), 'split', 'splits');
    add(listCount('budgets', 'list'), 'budget', 'budgets');
    add(listCount('investments', 'holdings'), 'holding', 'holdings');

    return parts.join(', ');
  }

  /// True when signing in should prompt before adopting the data already on
  /// this device — the caller must surface an explicit keep-or-erase choice
  /// (never silently merge or wipe).
  ///
  /// Two situations qualify:
  ///
  ///  * a **different** account signed in here before, or
  ///  * **no** account is on record but user content exists anyway — the app
  ///    is usable before the first sign-in, and a device can be handed over or
  ///    reinstalled over, so "nobody signed in yet" is not proof the data
  ///    belongs to whoever is signing in now. This case previously returned
  ///    false and adopted the data with no prompt at all.
  static bool isDifferentAccountWithLocalData() {
    if (!Hive.isBoxOpen('settings')) return false;
    final box = Hive.box('settings');
    final previousId = box.get(lastUserIdKey)?.toString();
    final newId = currentUserId;
    if (newId == null) return false;
    if (previousId != null && previousId == newId) return false;

    if (previousId == null) {
      // If there is no previous account recorded, but this user is signed in,
      // the existing local data belongs to this user. Adopt it immediately.
      box.put(lastUserIdKey, newId);
      box.put(lastUserEmailKey, currentUserEmail ?? '');
      return false;
    }

    final hasOnboarded =
        box.get('has_seen_onboarding', defaultValue: false) == true;
    return hasOnboarded || hasLocalUserData();
  }

  /// Email of the account that previously used this device (for the
  /// account-switch dialog copy).
  static String previousAccountEmail() {
    if (!Hive.isBoxOpen('settings')) return '';
    return Hive.box('settings').get(lastUserEmailKey, defaultValue: '').toString();
  }

  // ───────────── Server-side onboarding gate (accountHasExistingData) ─────
  //
  // Whether onboarding runs must depend on whether the ACCOUNT already has
  // data on the server — NOT on this device's local has_seen_onboarding flag.
  // A returning user on a new phone/reinstall must never be treated as new.

  /// Local fast-path cache. Trusted ONLY once it's been resolved to `true`
  /// for this device; a fresh login always re-verifies against the server.
  static const accountHasDataKey = 'account_has_data';

  /// SERVER CHECK: has this account finished first-run setup?
  ///
  /// Reads the single explicit flag `users.setup_completed`, which web writes
  /// through the same `complete_account_setup` RPC — so completing setup on
  /// either platform is seen by the other, and a reinstall never re-runs it.
  ///
  /// This replaces a row-counting heuristic that could not work. Every signup
  /// is seeded by `handle_new_user` (purposes, accounts, a contributor, a
  /// budget template), so "the account has data" is true the instant it
  /// exists; the old code compensated with thresholds like "more than 1
  /// active purpose ⇒ already onboarded", which silently inverted when
  /// 20260724_default_family_purpose.sql began seeding Family alongside
  /// Personal. From that migration on, every brand-new account reported two
  /// purposes and mobile skipped onboarding entirely.
  ///
  /// A missing row means `handle_new_user` has not landed yet on a very fresh
  /// signup — reported as "not completed", because wrongly skipping setup is
  /// the direction the user cannot recover from.
  static Future<bool> isAccountSetupCompleted() async {
    final db = Supabase.instance.client;
    final uid = currentUserId;
    if (uid == null) return false;

    final row = await db
        .from(SupaTables.users)
        .select('setup_completed')
        .eq('id', uid)
        .maybeSingle();

    if (row == null) return false;
    return row['setup_completed'] == true;
  }

  /// Records first-run setup as finished for this account.
  ///
  /// Shares the `complete_account_setup` RPC with web rather than updating the
  /// column directly, so the flag can only move forward and only on the
  /// caller's own row.
  static Future<void> markAccountSetupCompleted() async {
    if (!isConfigured || !isSignedIn) return;
    try {
      await Supabase.instance.client.rpc('complete_account_setup');
    } catch (_) {
      // Offline: the local flag below still routes this device correctly, and
      // the next fresh login re-reads the server value.
    }
    markAccountHasData();
  }

  /// Resolves "does this account have data?" using the cache when it's safe:
  /// • [freshLogin] (explicit sign-in, not a restored session) → ALWAYS asks
  ///   the server; a locally-cached `false` is never trusted across devices.
  /// • Session-restore path → a cached `true` is trusted (no network
  ///   round-trip on every cold start); anything else re-checks the server.
  /// Returns null when the server couldn't be reached and no trustworthy
  /// cache exists (caller decides how to degrade).
  static Future<bool?> resolveAccountHasData({required bool freshLogin}) async {
    final settings = Hive.isBoxOpen('settings') ? Hive.box('settings') : null;
    final cached = settings?.get(accountHasDataKey);

    if (!freshLogin && cached == true) return true;

    try {
      final result = await isAccountSetupCompleted();
      settings?.put(accountHasDataKey, result);
      return result;
    } catch (_) {
      if (cached is bool) return cached;
      return null; // offline with no cache
    }
  }

  /// Marks the account as having data (call when onboarding completes or the
  /// first real record is created) so later opens use the fast path.
  static void markAccountHasData() {
    if (Hive.isBoxOpen('settings')) {
      Hive.box('settings').put(accountHasDataKey, true);
    }
  }

  /// Forced-logout safety net for admin-deleted accounts.
  ///
  /// Mobile has no server-push channel (no Realtime, no FCM) — this is the
  /// bounded-delay fallback: a lightweight round-trip that re-validates the
  /// current session against the Auth server (equivalent to the JS client's
  /// `getUser()` — this actually calls Supabase, it does not just read the
  /// locally cached/refreshed JWT, so it WILL detect a server-side account
  /// deletion). Called from the top of [SyncService.fullSync] (which the
  /// 30-min periodic timer and onForeground() both funnel through), so a
  /// deleted account is signed out within, worst case, ~30 minutes if the
  /// app is only ever backgrounded, or immediately on the next app resume /
  /// connectivity-regain-triggered sync — never "whenever the token
  /// naturally expires."
  ///
  /// Returns false if the account no longer exists (or the check itself
  /// fails in a way that indicates the session is dead — an auth error, not
  /// just a network timeout). Callers should treat `false` as "sign out and
  /// wipe now"; a plain network failure (no connectivity at all) must NOT
  /// trigger this, so only AuthException is treated as revocation — anything
  /// else (timeout, DNS failure) is assumed to be connectivity, not deletion.
  static Future<bool> verifyAccountStillExists() async {
    if (!isConfigured || !isSignedIn) return true;
    try {
      final current = session;
      if (current != null && current.isExpired) {
        try {
          final refreshed = await _client.auth
              .refreshSession()
              .timeout(const Duration(seconds: 10));
          if (refreshed.session == null) return false;
        } on AuthException catch (e) {
          final code = (e.code ?? '').toLowerCase();
          final msg = e.message.toLowerCase();
          if (code == 'refresh_token_not_found' ||
              code == 'invalid_grant' ||
              msg.contains('invalid refresh token') ||
              msg.contains('refresh token not found') ||
              msg.contains('already used')) {
            return false;
          }
          return true;
        } catch (_) {
          return true;
        }
      }

      try {
        final response = await _client.auth.getUser().timeout(
              const Duration(seconds: 8),
            );
        return response.user != null;
      } on AuthException catch (e) {
        final code = (e.code ?? '').toLowerCase();
        final msg = e.message.toLowerCase();
        if (code == 'user_not_found' ||
            msg.contains('user not found') ||
            msg.contains('user_not_found')) {
          return false;
        }
        return true;
      } catch (_) {
        return true;
      }
    } catch (_) {
      return true;
    }
  }


  /// True when [error] means the account exists but the email is not confirmed.
  static bool isEmailNotConfirmedError(Object error) {
    if (error is AuthException) {
      final code = (error.code ?? '').toLowerCase();
      final message = error.message.toLowerCase();
      return code == 'email_not_confirmed' ||
          message.contains('email not confirmed');
    }
    return error.toString().toLowerCase().contains('email not confirmed');
  }

  /// Waits briefly for a session to appear (PKCE email-confirm / OAuth).
  ///
  /// Used by splash when a pending verification email exists so a cold-start
  /// from `spentx://auth/callback` does not race ahead of getSessionFromUrl
  /// and bounce the user to "session expired".
  static Future<bool> waitForSession({
    Duration timeout = const Duration(seconds: 4),
  }) async {
    if (!isConfigured) return false;
    if (session != null) return hasValidSession();

    final completer = Completer<bool>();
    StreamSubscription<AuthState>? sub;
    Timer? timer;

    void finish(bool value) {
      if (completer.isCompleted) return;
      timer?.cancel();
      sub?.cancel();
      completer.complete(value);
    }

    timer = Timer(timeout, () => finish(session != null));
    sub = _client.auth.onAuthStateChange.listen((data) {
      if (data.session != null) finish(true);
    });

    // Session may have landed between the null check and the listener.
    if (session != null) finish(true);

    return completer.future;
  }

  /// Extracts a human-readable message from Supabase/auth errors so the user
  /// sees the real reason ("Invalid login credentials", "User already
  /// registered"), not a generic failure.
  static String friendlyError(Object error) {
    if (error is AuthException) {
      final code = (error.code ?? '').toLowerCase();
      final message = error.message.toLowerCase();
      if (code == 'user_already_exists' ||
          message.contains('already registered') ||
          message.contains('already exists') ||
          message.contains('user already')) {
        return 'An account with this email already exists.';
      }
      if (code == 'invalid_credentials' ||
          message.contains('invalid login credentials')) {
        return 'Incorrect email or password.';
      }
      if (code == 'email_not_confirmed' ||
          message.contains('email not confirmed')) {
        return 'Confirm your email first. Check your inbox for the verification link.';
      }
      if (code == 'weak_password' || message.contains('weak password')) {
        return 'Password must be at least 8 characters.';
      }
      if (code == 'over_email_send_rate_limit' ||
          message.contains('email rate limit exceeded')) {
        return 'Too many emails sent to this address recently. Wait a few minutes, then try Resend.';
      }
      if (message.contains('error sending') ||
          message.contains('smtp') ||
          code == 'unexpected_failure') {
        // The account itself is fine — this is the mail server failing to
        // dispatch, which on Supabase's built-in (non-custom-SMTP) sender
        // usually means its very low sending quota is exhausted, not a
        // problem with the address the user typed.
        return 'Could not send the verification email right now — this is '
            'usually temporary. Wait a few minutes and try Resend, or use '
            '"Change Email" to try a different address.';
      }
      return error.message;
    }
    final s = error.toString();
    final lower = s.toLowerCase();
    if (lower.contains('already registered') ||
        lower.contains('already exists') ||
        lower.contains('user already')) {
      return 'An account with this email already exists.';
    }
    return s.length > 140 ? '${s.substring(0, 140)}…' : s;
  }
}
