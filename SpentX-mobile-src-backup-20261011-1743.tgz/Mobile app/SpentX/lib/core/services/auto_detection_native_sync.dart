import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/merchant_rule.dart';
import '../utils/bank_keywords.dart';
import 'account_discovery_service.dart';
import 'bank_allowlist_service.dart';
import '../../data/local/hive_service.dart';

/// Mirrors Hive [auto_detection] to SharedPreferences so native Android code
/// (notification listener, SMS receiver) can respect the same setting.
class AutoDetectionNativeSync {
  static const _prefKey = 'auto_detection';

  /// Real session flag. Native listeners must not treat a missing key as
  /// "detection on". Login sets this; logout clears it.
  static const sessionPrefKey = 'spentx_user_authenticated';
  static const MethodChannel _permissions =
      MethodChannel('com.spentx.app/permissions');

  static Future<void> setAuthenticated(bool authenticated) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(sessionPrefKey, authenticated);
    if (!authenticated) {
      await prefs.remove('native_sms_queue');
      await prefs.remove('native_tx_queue');
      try {
        await _permissions.invokeMethod('clearSecureQueues');
      } catch (_) {
        // Engine not up. Native listeners also clear when the flag is false.
      }
    }
  }

  static Future<bool> isAuthenticated() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(sessionPrefKey) ?? false;
  }

  /// Key holding the banks the user has actually added, as
  /// `{"tokens":[...],"last4":[...]}`.
  ///
  /// Absent = never synced (fresh install) and native allows everything, so a
  /// new user still sees detection. Present-but-empty = the user has no bank
  /// accounts, so no bank SMS is theirs and native rejects all.
  static const allowedBanksKey = 'allowed_banks_json';

  static Future<void> syncToNative() async {
    final enabled =
        Hive.box('settings').get('auto_detection', defaultValue: true) == true;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_prefKey, enabled);

    // The bank allowlist goes first, and each mirror is isolated. Previously a
    // throw inside syncMerchantsToNative() skipped the allowlist write
    // entirely, leaving the key absent — which native reads as "never synced"
    // and allows every bank through. A failure in one mirror must not silently
    // disable the other.
    try {
      await syncAllowedBanksToNative();
    } catch (e) {
      debugPrint('Bank allowlist sync failed: $e');
    }
    try {
      await syncMerchantsToNative();
    } catch (e) {
      debugPrint('Merchant mirror sync failed: $e');
    }
  }

  /// Mirrors the user's saved bank accounts to SharedPreferences so the native
  /// notification listener can drop SMS from banks they never added.
  ///
  /// Dart resolves each account to a match token here, so the bank keyword
  /// list in [bankTokenForAccountName] never has to be duplicated in Kotlin.
  static Future<void> syncAllowedBanksToNative() async {
    final raw = Hive.box('settings').get('onboardingAccounts');
    final banks = BankAllowlistService.collectAllowlistBanks(
      raw is List ? raw : const [],
    );
    // Native matches plain phrases, so hand it every phrase that names each
    // bank ("sbi", "state bank", ...), not just the canonical key.
    final tokens = <String>{
      for (final t in banks.tokens) ...bankAliasesFor(t),
    };
    final last4s = banks.last4s;
    final tokensWithoutLast4 = banks.tokensWithoutLast4;
    if (raw is List && raw.isNotEmpty && tokens.isEmpty && last4s.isEmpty) {
      debugPrint('Bank allowlist is EMPTY — native will drop every bank SMS');
    }

    // Accounts the user declined, so the native listener stops forwarding
    // them for discovery. Read from Hive rather than passed in, so any caller
    // that re-syncs the allowlist keeps the ignore list current too.
    final ignored = AccountDiscoveryService.resolvedKeys();

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      allowedBanksKey,
      jsonEncode({
        'tokens': tokens.toList(),
        'last4': last4s.toList(),
        'tokensWithoutLast4': tokensWithoutLast4.toList(),
        'ignored': ignored,
      }),
    );
  }

  static Future<void> syncMerchantsToNative() async {
    if (!Hive.isBoxOpen('merchant_rules_box')) {
      await SecureHive.openBox('merchant_rules_box');
    }
    final box = Hive.box('merchant_rules_box');
    final List<Map<String, dynamic>> rulesList = [];
    for (final raw in box.values) {
      try {
        final rule = MerchantRule.fromMap(Map<dynamic, dynamic>.from(raw));
        rulesList.add({
          'identifier': rule.identifier,
          'normalizedIdentifierKey': rule.normalizedIdentifierKey,
          'displayName': rule.displayName,
          'transactionType': rule.transactionType,
        });
      } catch (_) {}
    }
    final jsonStr = jsonEncode(rulesList);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('known_merchants_json', jsonStr);
  }

  static Future<bool> readEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    if (prefs.containsKey(_prefKey)) {
      return prefs.getBool(_prefKey) ?? true;
    }
    return Hive.box('settings').get('auto_detection', defaultValue: true) == true;
  }
}