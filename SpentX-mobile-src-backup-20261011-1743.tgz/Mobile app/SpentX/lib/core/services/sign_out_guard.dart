class UnsyncedChangesException implements Exception {
  const UnsyncedChangesException();

  @override
  String toString() =>
      'Some changes are still saved only on this phone. '
      'Connect to the internet and try signing out again. Your data has been kept.';
}

/// Never let a best-effort/timeout sync turn into permission to erase data.
Future<void> requireSyncedChanges({
  required bool Function() hasPending,
  required Future<void> Function() flush,
}) async {
  if (!hasPending()) return;
  try {
    await flush().timeout(const Duration(seconds: 15));
  } catch (_) {
    throw const UnsyncedChangesException();
  }
  if (hasPending()) throw const UnsyncedChangesException();
}
