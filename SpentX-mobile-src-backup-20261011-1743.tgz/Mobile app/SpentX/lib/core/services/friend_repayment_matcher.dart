import 'package:hive_flutter/hive_flutter.dart';
import '../providers/friend_upi_provider.dart';
import '../providers/friends_provider.dart' show friendsProvider, manualFriendsProvider;
import '../providers/outing_provider.dart';
import '../providers/settlement_feedback_provider.dart';
import '../providers/transaction_provider.dart';
import 'friend_open_claims_service.dart';

/// Matches UPI credits/debits to friends and auto-settles trip splits.
class FriendRepaymentMatcher {
  FriendRepaymentMatcher._();

  static const double _amountTolerance = 1.0;

  /// Guard: transactions whose settlement has already been applied.
  /// Without this, every app restart re-runs the ledger through the matcher
  /// and the same repayment keeps draining additional pending shares.
  static const _settledTxKey = 'friend_settled_tx_ids';

  static bool _alreadyApplied(String txId) {
    if (txId.isEmpty || !Hive.isBoxOpen('settings')) return false;
    final list = Hive.box('settings')
        .get(_settledTxKey, defaultValue: const <dynamic>[]) as List;
    return list.contains(txId);
  }

  /// Claims a transaction so the automatic path leaves it alone.
  ///
  /// The verify popup calls this before saving: once the user has been shown
  /// the pending list and made a choice, that choice is authoritative and
  /// auto-settlement must not also run (it would double-apply, and it would
  /// override a deliberate "not a repayment").
  static void markHandledExternally(String txId) => _markApplied(txId);

  /// Unmarks a transaction when it is deleted, so the repayment matcher
  /// can match incoming credits again.
  static void unmarkApplied(String txId) {
    if (txId.isEmpty || !Hive.isBoxOpen('settings')) return;
    final box = Hive.box('settings');
    final list = List<String>.from(
        box.get(_settledTxKey, defaultValue: const <dynamic>[]) as List);
    if (list.remove(txId)) {
      box.put(_settledTxKey, list);
    }
  }

  static void _markApplied(String txId) {
    if (txId.isEmpty || !Hive.isBoxOpen('settings')) return;
    final box = Hive.box('settings');
    final list = List<String>.from(
        box.get(_settledTxKey, defaultValue: const <dynamic>[]) as List);
    if (!list.contains(txId)) {
      list.add(txId);
      while (list.length > 1000) {
        list.removeAt(0);
      }
      box.put(_settledTxKey, list);
    }
  }

  static String? resolveFriendName({
    required dynamic ref,
    required String merchant,
    required String upiId,
    String? rawIdentifier,
  }) {
    final upiLinks = ref.read(friendUpiProvider);
    final normalizedUpi = FriendUpiNotifier.normalizeUpi(upiId);
    final idKey = FriendUpiNotifier.normalizeUpi(rawIdentifier ?? '');

    // Exact identifier equality only. Two-way `contains` used to match here,
    // so `ravi@ybl` claimed every credit from `ravikumar@ybl` — a wrong friend
    // silently settled against a real balance.
    if (normalizedUpi.isNotEmpty || idKey.isNotEmpty) {
      for (final entry in upiLinks.entries) {
        for (final linked in entry.value) {
          if (linked.isEmpty) continue;
          if (normalizedUpi.isNotEmpty && normalizedUpi == linked) {
            return _nameFromKey(ref, entry.key);
          }
          if (idKey.isNotEmpty && idKey == linked) {
            return _nameFromKey(ref, entry.key);
          }
        }
      }
    }

    final m = merchant.toLowerCase();
    for (final entry in upiLinks.entries) {
      final name = _nameFromKey(ref, entry.key);
      if (name == null) continue;
      final n = name.toLowerCase();
      if (_merchantMentionsFriend(m, n)) return name;
    }

    for (final entry in upiLinks.entries) {
      final name = _nameFromKey(ref, entry.key);
      if (name != null && _merchantMentionsFriend(m, name.toLowerCase())) {
        return name;
      }
    }

    // Name-only match for saved / trip friends (after UPI links checked).
    for (final f in ref.read(friendsProvider)) {
      if (f.name.toLowerCase() == 'you') continue;
      if (_merchantMentionsFriend(m, f.name.toLowerCase())) return f.name;
    }

    return null;
  }

  static String? _nameFromKey(dynamic ref, String key) {
    for (final f in ref.read(manualFriendsProvider)) {
      if (FriendUpiNotifier.friendKey(f.name) == key) return f.name;
    }
    for (final o in ref.read(outingProvider)) {
      for (final m in o.members) {
        if (FriendUpiNotifier.friendKey(m.name) == key) return m.name;
      }
    }
    return null;
  }

  /// Words that mark a payer as a business rather than a person. A name-only
  /// match against any of these is refused outright — this is what stops
  /// friend "Raj" claiming "RAJ TRAVELS" and friend "Rajesh" claiming a
  /// "RAJESH KUMAR ENTERPRISES" salary credit.
  static const _corporateMarkers = {
    'ltd', 'pvt', 'limited', 'llp', 'inc', 'corp', 'company', 'co',
    'enterprises', 'enterprise', 'solutions', 'technologies', 'technology',
    'services', 'industries', 'traders', 'trading', 'travels', 'stores',
    'store', 'mart', 'bank', 'finance', 'insurance', 'loan', 'salary',
    'payroll', 'refund', 'cashback', 'reversal', 'interest', 'dividend',
  };

  static Set<String> _tokens(String value) => value
      .toLowerCase()
      .split(RegExp(r'[^a-z0-9]+'))
      .where((t) => t.isNotEmpty)
      .toSet();

  /// Whole-token name match, not substring.
  ///
  /// The old version used `contains(' $friend ')` and friends, which matched
  /// any payer string that happened to embed the name. Now every token of the
  /// friend's name must appear as a complete token in the payer string, the
  /// payer must not look corporate, and a single-token friend name (the
  /// riskiest case) additionally requires a short, personal-looking payer.
  static bool _merchantMentionsFriend(String merchantLower, String friendLower) {
    if (friendLower.isEmpty) return false;

    final friendTokens = _tokens(friendLower);
    if (friendTokens.isEmpty) return false;

    final merchantTokens = _tokens(merchantLower);
    if (merchantTokens.isEmpty) return false;
    if (merchantTokens.any(_corporateMarkers.contains)) return false;
    if (!friendTokens.every(merchantTokens.contains)) return false;

    if (friendTokens.length == 1) {
      // "From Ravi" / "Ravi Kumar" are fine; a long merchant string that
      // merely contains the name is not.
      final extra = merchantTokens.difference(friendTokens).length;
      if (extra > 2) return false;
    }

    return true;
  }

  /// Credit (money in) → friend repaid you → settle what they actually owe.
  ///
  /// Two hard rules, both of which the previous implementation broke:
  ///
  /// 1. **Identity decides, amount never does.** No identified friend means no
  ///    settlement, however well the amount happens to line up.
  /// 2. **Only an unambiguous allocation is applied automatically.** The credit
  ///    must exactly clear one open claim, or exactly clear all of them. Any
  ///    other shape (₹400 against ₹500, ₹600 against ₹500, two claims that
  ///    could each explain it) is left for the user to resolve in the verify
  ///    popup. It used to drain pending shares greedily across every outing
  ///    until the amount ran out, which quietly settled unrelated trips.
  static bool trySettleCredit(dynamic ref, Transaction tx) {
    if (tx.isExpense || tx.isTransfer || tx.amount <= 0) return false;
    if (_alreadyApplied(tx.id)) return false;

    final friendName = resolveFriendName(
      ref: ref,
      merchant: tx.merchant,
      upiId: tx.upiId,
      rawIdentifier: tx.rawIdentifier,
    );
    if (friendName == null) return false;

    final claims = FriendOpenClaimsService.claimsForFriend(ref, friendName);
    if (claims.isEmpty) return false;

    final preselected = FriendOpenClaimsService.preselect(claims, tx.amount);
    if (preselected.isEmpty) return false;

    final selected =
        claims.where((c) => preselected.contains(c.id)).toList();
    final allocation =
        FriendOpenClaimsService.allocate(selected, tx.amount);
    final applied = FriendOpenClaimsService.applySettlements(
      ref,
      claims: selected,
      allocation: allocation,
      mode: _modeLabel(tx),
      note: 'tx:${tx.id}',
    );

    if (applied > 0) _markApplied(tx.id);
    return applied > 0;
  }

  /// Debit (money out) → you paid friend your share → settle your member on splits.
  static bool trySettleDebitToFriend(dynamic ref, Transaction tx) {
    if (!tx.isExpense || tx.isTransfer || tx.amount <= 0) return false;
    if (_alreadyApplied(tx.id)) return false;

    final friendName = resolveFriendName(
      ref: ref,
      merchant: tx.merchant,
      upiId: tx.upiId,
      rawIdentifier: tx.rawIdentifier,
    );
    if (friendName == null) return false;

    final ok = _applySettlement(
      ref: ref,
      friendName: friendName,
      amount: tx.amount,
      mode: _modeLabel(tx),
      memberToSettle: 'you',
      outingIdHint: tx.outingId,
      settleSelf: true,
    );
    if (ok) {
      _markApplied(tx.id);
      try {
        ref.read(settlementFeedbackProvider.notifier).state =
            'Sent ₹${tx.amount.toInt()} to $friendName — your share updated';
      } catch (_) {}
    }
    return ok;
  }

  static bool trySettleCreditWithFeedback(dynamic ref, Transaction tx) {
    final friendName = resolveFriendName(
      ref: ref,
      merchant: tx.merchant,
      upiId: tx.upiId,
      rawIdentifier: tx.rawIdentifier,
    );
    if (friendName == null) return false;
    final ok = trySettleCredit(ref, tx);
    if (ok) {
      try {
        ref.read(settlementFeedbackProvider.notifier).state =
            '₹${tx.amount.toInt()} from $friendName — trip balance updated';
      } catch (_) {}
    }
    return ok;
  }

  static String _modeLabel(Transaction tx) {
    if (tx.upiId.isNotEmpty) return 'UPI';
    return tx.paymentType.isNotEmpty ? tx.paymentType : 'Online';
  }

  static bool _applySettlement({
    required dynamic ref,
    required String friendName,
    required double amount,
    required String mode,
    required String memberToSettle,
    String? outingIdHint,
    bool settleSelf = false,
  }) {
    final outings = ref.read(outingProvider);
    var remaining = amount;
    var any = false;

    final ordered = [...outings];
    if (outingIdHint != null) {
      ordered.sort((a, b) {
        if (a.id == outingIdHint) return -1;
        if (b.id == outingIdHint) return 1;
        return b.endDate.compareTo(a.endDate);
      });
    } else {
      ordered.sort((a, b) => b.endDate.compareTo(a.endDate));
    }

    final notifier = ref.read(outingProvider.notifier);

    for (final outing in ordered) {
      final friendMember = outing.members
          .where((m) => m.name.toLowerCase() == friendName.toLowerCase())
          .firstOrNull;
      if (friendMember == null) continue;

      final youMember = outing.members
          .where((m) => m.name.toLowerCase() == 'you')
          .firstOrNull;
      final targetId = settleSelf ? (youMember?.id ?? 'you') : friendMember.id;

      for (final expense in outing.expenses) {
        if (remaining < _amountTolerance) break;
        if (!expense.memberIds.contains(targetId)) continue;
        final pending = expense.pendingAmountForMember(targetId);
        if (pending < _amountTolerance) continue;

        final apply = remaining < pending ? remaining : pending;
        if (apply < _amountTolerance) continue;

        notifier.recordMemberSettlement(
          outing.id,
          expense.id,
          targetId,
          amount: apply,
          mode: mode,
        );
        remaining -= apply;
        any = true;
      }
    }

    return any;
  }

}