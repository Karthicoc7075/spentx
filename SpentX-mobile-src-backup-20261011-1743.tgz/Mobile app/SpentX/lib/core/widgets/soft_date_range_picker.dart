import 'package:flutter/material.dart';
import '../theme/soft_palette.dart';
import 'package:intl/intl.dart';

import '../theme/spentx_tokens.dart';

/// Opens the app-styled date range picker used by Activity and Analytics.
///
/// This intentionally uses a bottom sheet instead of Flutter's full-screen
/// date-range route. The sheet is dismissible, so tapping the dark scrim
/// outside it closes the picker without changing the current range.
Future<DateTimeRange?> showSoftDateRangePicker({
  required BuildContext context,
  required DateTime firstDate,
  required DateTime lastDate,
  DateTimeRange? initialDateRange,
}) {
  return showModalBottomSheet<DateTimeRange>(
    context: context,
    isScrollControlled: true,
    isDismissible: true,
    enableDrag: true,
    backgroundColor: Colors.transparent,
    barrierColor: Colors.black.withValues(alpha: 0.58),
    builder:
        (_) => _SoftDateRangePicker(
          firstDate: _day(firstDate),
          lastDate: _day(lastDate),
          initialDateRange: initialDateRange,
        ),
  );
}

DateTime _day(DateTime value) => DateTime(value.year, value.month, value.day);

class _SoftDateRangePicker extends StatefulWidget {
  const _SoftDateRangePicker({
    required this.firstDate,
    required this.lastDate,
    this.initialDateRange,
  });

  final DateTime firstDate;
  final DateTime lastDate;
  final DateTimeRange? initialDateRange;

  @override
  State<_SoftDateRangePicker> createState() => _SoftDateRangePickerState();
}

class _SoftDateRangePickerState extends State<_SoftDateRangePicker> {
  late DateTime _start;
  late DateTime _end;
  bool _editingStart = true;

  @override
  void initState() {
    super.initState();
    final initial = widget.initialDateRange;
    var start = _day(initial?.start ?? widget.lastDate);
    var end = _day(initial?.end ?? widget.lastDate);
    if (start.isBefore(widget.firstDate)) start = widget.firstDate;
    if (end.isBefore(start)) end = start;
    if (end.isAfter(widget.lastDate)) end = widget.lastDate;
    _start = start;
    _end = end;
  }

  Future<void> _pickStart() async {
    final t = context.tokens;
    final picked = await showDatePicker(
      context: context,
      firstDate: widget.firstDate,
      lastDate: _end.isBefore(widget.lastDate) ? _end : widget.lastDate,
      initialDate: _start,
      builder:
          (context, child) => Theme(
            data: Theme.of(context).copyWith(
              colorScheme: Theme.of(context).colorScheme.copyWith(
                primary: t.primary,
                onPrimary: t.onPrimary,
              ),
            ),
            child: child!,
          ),
    );
    if (!mounted || picked == null) return;
    setState(() {
      _start = _day(picked);
      if (_end.isBefore(_start)) _end = _start;
      _editingStart = false;
    });
  }

  Future<void> _pickEnd() async {
    final t = context.tokens;
    final picked = await showDatePicker(
      context: context,
      firstDate: _start,
      lastDate: widget.lastDate,
      initialDate: _end,
      builder:
          (context, child) => Theme(
            data: Theme.of(context).copyWith(
              colorScheme: Theme.of(context).colorScheme.copyWith(
                primary: t.primary,
                onPrimary: t.onPrimary,
              ),
            ),
            child: child!,
          ),
    );
    if (!mounted || picked == null) return;
    setState(() {
      _end = _day(picked);
      _editingStart = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final bottom = MediaQuery.viewInsetsOf(context).bottom;
    return SafeArea(
      top: false,
      child: Padding(
        padding: EdgeInsets.only(bottom: bottom),
        child: Container(
          padding: const EdgeInsets.fromLTRB(20, 10, 20, 20),
          decoration: BoxDecoration(
            color: t.card,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
            border: Border.all(color: t.border),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: t.border,
                    borderRadius: BorderRadius.circular(999),
                  ),
                ),
              ),
              const SizedBox(height: 18),
              Text(
                'Custom date range',
                style: TextStyle(
                  color: t.textPrimary,
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 5),
              Text(
                'Choose a start and end date',
                style: TextStyle(color: t.textSecondary, fontSize: 13),
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(
                    child: _DateField(
                      label: 'Start date',
                      value: _start,
                      selected: _editingStart,
                      onTap: () {
                        setState(() => _editingStart = true);
                        _pickStart();
                      },
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _DateField(
                      label: 'End date',
                      value: _end,
                      selected: !_editingStart,
                      onTap: () {
                        setState(() => _editingStart = false);
                        _pickEnd();
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.of(context).pop(),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: t.textPrimary,
                        side: BorderSide(color: t.border),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                      child: const Text('Cancel'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton(
                      onPressed:
                          () => Navigator.of(
                            context,
                          ).pop(DateTimeRange(start: _start, end: _end)),
                      style: FilledButton.styleFrom(
                        backgroundColor: SoftColors.control,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                      child: const Text('Apply range'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DateField extends StatelessWidget {
  const _DateField({
    required this.label,
    required this.value,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final DateTime value;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(
          color: t.field,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: selected ? t.primary : t.border,
            width: selected ? 1.5 : 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: TextStyle(
                color: t.textSecondary,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                Icon(Icons.calendar_today_outlined, size: 15, color: t.primary),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    DateFormat('d MMM yyyy').format(value),
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: t.textPrimary,
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
