import 'package:flutter/material.dart';

import '../theme/soft_palette.dart';

/// Primary action button: the shared green gradient ([SoftColors.primaryGradient])
/// with white text, same in light and dark mode.
class SoftGradientButton extends StatelessWidget {
  const SoftGradientButton({
    super.key,
    required this.onPressed,
    this.label,
    this.child,
    this.icon,
    this.height = 52,
    this.expand = true,
    this.loading = false,
    this.borderRadius,
    this.padding = const EdgeInsets.symmetric(horizontal: 18),
    this.shadow = true,
  }) : assert(label != null || child != null);

  final VoidCallback? onPressed;
  final String? label;
  final Widget? child;
  final IconData? icon;
  final double height;
  final bool expand;
  final bool loading;

  /// Defaults to a stadium (pill) shape.
  final BorderRadius? borderRadius;
  final EdgeInsetsGeometry padding;
  final bool shadow;

  static const _shadow = [
    BoxShadow(color: Color(0x33047857), blurRadius: 16, offset: Offset(0, 6)),
  ];

  @override
  Widget build(BuildContext context) {
    final enabled = onPressed != null && !loading;
    final radius = borderRadius ?? BorderRadius.circular(999);
    final content =
        loading
            ? const SizedBox(
              width: 18,
              height: 18,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: Colors.white,
              ),
            )
            : child ??
                Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (icon != null) ...[
                      Icon(icon, size: 16, color: Colors.white),
                      const SizedBox(width: 8),
                    ],
                    Flexible(
                      child: Text(
                        label!,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                );
    return SizedBox(
      height: height,
      width: expand ? double.infinity : null,
      child: Opacity(
        opacity: enabled || loading ? 1 : 0.5,
        child: DecoratedBox(
          decoration: BoxDecoration(
            borderRadius: radius,
            gradient: SoftColors.primaryGradient,
            boxShadow:
                shadow &&
                        enabled &&
                        Theme.of(context).brightness == Brightness.light
                    ? _shadow
                    : null,
          ),
          child: Material(
            color: Colors.transparent,
            borderRadius: radius,
            child: InkWell(
              onTap: enabled ? onPressed : null,
              borderRadius: radius,
              child: Padding(
                padding: padding,
                child: IconTheme.merge(
                  data: const IconThemeData(color: Colors.white),
                  child: DefaultTextStyle.merge(
                    style: const TextStyle(color: Colors.white),
                    child: Center(widthFactor: 1, child: content),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Secondary action button: white (dark: #18181B) with ink (dark: white)
/// text and a light outline. [destructive] uses the danger red text.
class SoftOutlineButton extends StatelessWidget {
  const SoftOutlineButton({
    super.key,
    required this.onPressed,
    this.label,
    this.child,
    this.icon,
    this.height = 52,
    this.expand = true,
    this.destructive = false,
    this.loading = false,
    this.borderRadius,
    this.padding = const EdgeInsets.symmetric(horizontal: 18),
  }) : assert(label != null || child != null);

  final VoidCallback? onPressed;
  final String? label;
  final Widget? child;
  final IconData? icon;
  final double height;
  final bool expand;
  final bool destructive;
  final bool loading;
  final BorderRadius? borderRadius;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    final fg =
        destructive ? SoftColors.danger : SoftColors.secondaryFg(context);
    final radius = borderRadius ?? BorderRadius.circular(999);
    final content =
        loading
            ? SizedBox(
              width: 18,
              height: 18,
              child: CircularProgressIndicator(strokeWidth: 2, color: fg),
            )
            : child ??
                Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (icon != null) ...[
                      Icon(icon, size: 16, color: fg),
                      const SizedBox(width: 8),
                    ],
                    Flexible(
                      child: Text(
                        label!,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: fg,
                        ),
                      ),
                    ),
                  ],
                );
    return SizedBox(
      height: height,
      width: expand ? double.infinity : null,
      child: OutlinedButton(
        onPressed: loading ? null : onPressed,
        style: OutlinedButton.styleFrom(
          backgroundColor: SoftColors.secondaryBg(context),
          foregroundColor: fg,
          disabledForegroundColor: fg.withValues(alpha: 0.5),
          side: BorderSide(color: SoftColors.secondaryOutline(context)),
          padding: padding,
          minimumSize: Size(0, height),
          shape: RoundedRectangleBorder(borderRadius: radius),
          elevation: 0,
        ),
        child: content,
      ),
    );
  }
}
