import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../theme/app_colors.dart';
import '../theme/spentx_tokens.dart';
import '../theme/soft_palette.dart';
import 'category_icon.dart';
import '../utils/transaction_display_utils.dart';
import 'animated_tap_card.dart';
import '../providers/private_mode_provider.dart';

class TransactionTile extends ConsumerStatefulWidget {
  final String merchant;
  final String category;
  final String account;
  final String paymentType;
  final String date;
  final double amount;
  final bool isExpense, isAutoDetected, isTransfer;
  final String? outingName;
  final double? outingTotal;
  final int? outingDay;
  final int? outingMemberCount;
  final int? expenseCount;
  final DateTime? outingStart;
  final DateTime? outingEnd;
  final bool isOutingCompleted;
  final bool showChevron;
  final VoidCallback? onTap;
  final VoidCallback? onDismissed;
  final String? splitBadge;
  final Color? splitBadgeTint;

  /// "{n} Items" indicator — shown alongside [splitBadge], not instead of it.
  final String? itemsLabel;
  final String? activeFilter;
  final String? purpose;
  final double? filterMatchAmount;
  final double? filterTotalAmount;
  final String bankName;
  final String accountLast4;

  /// Destination account name for a transfer row (`tx.transferTo`). Empty
  /// for non-transfer rows.
  final String transferTo;
  final String? overrideSubtitle;

  /// Info text for friend return cards (e.g. '1 of 3 returns').
  final String? returnInfo;

  /// Optional dropdown content widget (e.g. friend return breakdown).
  final Widget? dropdownChild;
  final bool defaultExpanded;
  final VoidCallback? onDropdownToggle;

  /// Soft Soft list: flat row inside a parent card (no extra border/shadow).
  final bool softListRow;

  const TransactionTile({
    super.key,
    required this.merchant,
    required this.category,
    required this.account,
    required this.paymentType,
    required this.date,
    required this.amount,
    this.isExpense = true,
    this.isAutoDetected = false,
    this.isTransfer = false,
    this.outingName,
    this.outingTotal,
    this.outingDay,
    this.outingMemberCount,
    this.expenseCount,
    this.outingStart,
    this.outingEnd,
    this.isOutingCompleted = false,
    this.showChevron = false,
    this.onTap,
    this.onDismissed,
    this.splitBadge,
    this.splitBadgeTint,
    this.itemsLabel,
    this.activeFilter,
    this.purpose,
    this.filterMatchAmount,
    this.filterTotalAmount,
    this.bankName = '',
    this.accountLast4 = '',
    this.transferTo = '',
    this.overrideSubtitle,
    this.returnInfo,
    this.dropdownChild,
    this.defaultExpanded = false,
    this.onDropdownToggle,
    this.softListRow = false,
  });

  @override
  ConsumerState<TransactionTile> createState() => _TransactionTileState();
}

class _TransactionTileState extends ConsumerState<TransactionTile> {
  bool _isRevealed = false;
  late bool _isDropdownExpanded;

  @override
  void initState() {
    super.initState();
    _isDropdownExpanded = widget.defaultExpanded;
  }

  String _formatAmount(double value) {
    final intPart = value.truncate();
    final str = intPart.toString();
    if (str.length <= 3) return str;
    final lastThree = str.substring(str.length - 3);
    String remaining = str.substring(0, str.length - 3);
    final reg = RegExp(r'\B(?=(\d{2})+(?!\d))');
    remaining = remaining.replaceAllMapped(reg, (m) => '${m[0]},');
    return '$remaining,$lastThree';
  }

  @override
  Widget build(BuildContext context) {
    final isPrivate = ref.watch(privateModeProvider);
    final isDark = context.isDarkMode;
    final isFriendReturnCard = widget.splitBadge == 'Friend Return';
    final isOutingCard =
        !isFriendReturnCard &&
        (widget.outingTotal != null ||
            widget.outingName != null ||
            widget.splitBadge == 'Outing' ||
            widget.expenseCount != null ||
            widget.category == 'Trip' ||
            widget.category == 'Outing');

    final CategoryData catData =
        isOutingCard
            ? const CategoryData(
              LucideIcons.map,
              SoftPalette.emeraldSoft,
              'Trip',
            )
            : isFriendReturnCard
            ? const CategoryData(
              LucideIcons.userCheck,
              AppColors.tintGreen,
              'Friend Return',
            )
            : CategoryIcon.resolve(widget.category);

    final displayCategory = TransactionDisplayUtils.summariseNames(
      widget.category.split(RegExp(r'[,·]\s*')),
    );
    final rightCategoryText = isOutingCard ? 'Trip' : displayCategory;
    final displayPurpose =
        (widget.purpose != null && widget.purpose!.trim().isNotEmpty)
            ? TransactionDisplayUtils.summariseNames(
              widget.purpose!.split(RegExp(r'[,·]\s*')),
            )
            : null;

    final shouldMask = isPrivate && !_isRevealed;

    final prefix =
        (widget.isTransfer || widget.category == 'Transfer')
            ? ''
            : (widget.isExpense ? '-₹' : '+₹');
    final amountText =
        shouldMask
            ? PrivateModeService.mask
            : '$prefix${_formatAmount(widget.amount)}';

    final amountColor =
        (widget.isTransfer || widget.category == 'Transfer')
            ? context.tokens.textPrimary
            : context.tokens.amount(isNegative: widget.isExpense);

    Widget tile = GestureDetector(
      // Long-press to reveal in private mode
      onLongPressStart:
          isPrivate
              ? (_) {
                HapticFeedback.mediumImpact();
                setState(() => _isRevealed = true);
              }
              : null,
      onLongPressEnd:
          isPrivate ? (_) => setState(() => _isRevealed = false) : null,
      onLongPressCancel:
          isPrivate ? () => setState(() => _isRevealed = false) : null,
      child: AnimatedTapCard(
        onTap: widget.onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.md,
            vertical: AppSpacing.sm + 2,
          ),
          decoration: BoxDecoration(
            color:
                widget.softListRow ? Colors.transparent : context.tokens.card,
            borderRadius: AppRadius.tileR,
            border:
                widget.softListRow
                    ? null
                    : Border.all(
                      color:
                          widget.isAutoDetected
                              ? SoftPalette.emerald.withValues(alpha: 0.4)
                              : context.tokens.border.withValues(
                                alpha: isDark ? 1 : 0.55,
                              ),
                      width: isDark ? 1 : 0.5,
                    ),
            boxShadow:
                (isDark || widget.softListRow) ? null : AppShadows.subtle,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // ── Left: Category Icon ──
                  // Soft Soft list: rounded square icon well (not circle).
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color:
                          isDark
                              ? SoftPalette.darkEmeraldSoft
                              : SoftPalette.emeraldSoft,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      catData.icon,
                      color: isDark ? SoftPalette.darkEmerald : SoftPalette.emerald,
                      size: 19,
                    ),
                  ),
                  const SizedBox(width: AppSpacing.sm),

                  // ── Middle: Merchant + Subtitle ──
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          children: [
                            Flexible(
                              child: Text(
                                widget.merchant,
                                style: AppType.body(
                                  context.tokens.textPrimary,
                                ).copyWith(fontWeight: FontWeight.w600),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            if (widget.splitBadge != null &&
                                widget.splitBadgeTint != null) ...[
                              const SizedBox(width: 6),
                              GestureDetector(
                                behavior: HitTestBehavior.opaque,
                                onTap:
                                    widget.dropdownChild != null
                                        ? () {
                                          HapticFeedback.lightImpact();
                                          setState(
                                            () =>
                                                _isDropdownExpanded =
                                                    !_isDropdownExpanded,
                                          );
                                          widget.onDropdownToggle?.call();
                                        }
                                        : null,
                                child: _Badge(
                                  label: widget.splitBadge!,
                                  tint: widget.splitBadgeTint!,
                                ),
                              ),
                            ],
                            if (widget.dropdownChild != null) ...[
                              const SizedBox(width: 4),
                              GestureDetector(
                                behavior: HitTestBehavior.opaque,
                                onTap: () {
                                  HapticFeedback.lightImpact();
                                  setState(
                                    () =>
                                        _isDropdownExpanded =
                                            !_isDropdownExpanded,
                                  );
                                  widget.onDropdownToggle?.call();
                                },
                                child: Container(
                                  padding: const EdgeInsets.all(3),
                                  decoration: BoxDecoration(
                                    color: (widget.splitBadgeTint ??
                                            SoftPalette.emeraldSoft)
                                        .withValues(alpha: 0.18),
                                    shape: BoxShape.circle,
                                  ),
                                  child: Icon(
                                    _isDropdownExpanded
                                        ? LucideIcons.chevronUp
                                        : LucideIcons.chevronDown,
                                    size: 12,
                                    color:
                                        widget.splitBadgeTint != null
                                            ? AppColors.onTint(
                                              widget.splitBadgeTint!,
                                            )
                                            : SoftPalette.mintDark,
                                  ),
                                ),
                              ),
                            ],
                            if (widget.itemsLabel != null) ...[
                              const SizedBox(width: 6),
                              _Badge(
                                label: widget.itemsLabel!,
                                tint: context.tokens.field,
                                ink: context.tokens.textSecondary,
                              ),
                            ],
                          ],
                        ),
                        const SizedBox(height: 3),
                        Text(
                          widget.overrideSubtitle ??
                              (((widget.isTransfer ||
                                          widget.category == 'Transfer') &&
                                      widget.transferTo.isNotEmpty)
                                  ? '${widget.account} → ${widget.transferTo}${isOutingCard ? '' : ' · ${widget.date}'}'
                                  : [
                                    if (widget.bankName.isNotEmpty)
                                      widget.bankName
                                    else if (widget.accountLast4.isNotEmpty)
                                      '*${widget.accountLast4}'
                                    else
                                      widget.account,
                                    if (displayPurpose != null &&
                                        displayPurpose.isNotEmpty)
                                      displayPurpose,
                                    if (!isOutingCard) widget.date,
                                  ].join(' · ')),
                          style: TextStyle(
                            color: context.tokens.textSecondary,
                            fontSize: 12,
                            fontWeight: FontWeight.w400,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: AppSpacing.sm),

                  // ── Right: Amount + Category ──
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          if (isPrivate && !_isRevealed) ...[
                            Icon(
                              LucideIcons.eyeOff,
                              size: 11,
                              color: context.tokens.textSecondary,
                            ),
                            const SizedBox(width: 4),
                          ],
                          AnimatedSwitcher(
                            duration: const Duration(milliseconds: 150),
                            child: Text(
                              amountText,
                              key: ValueKey(amountText),
                              style: AppType.money(
                                shouldMask
                                    ? context.tokens.textSecondary
                                    : amountColor,
                                size: 15,
                              ).copyWith(letterSpacing: shouldMask ? 2 : -0.3),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 3),
                      if (widget.outingTotal != null && !shouldMask) ...[
                        Text(
                          '₹${_formatAmount(widget.outingTotal!)}',
                          style: TextStyle(
                            color: context.tokens.textSecondary,
                            fontSize: 12,
                            fontWeight: FontWeight.w400,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 2),
                      ],
                      if (widget.returnInfo != null) ...[
                        Text(
                          widget.returnInfo!,
                          style: TextStyle(
                            color: AppColors.tintGreen,
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 2),
                      ],
                      if (rightCategoryText.isNotEmpty) ...[
                        Text(
                          rightCategoryText,
                          style: TextStyle(
                            color: context.tokens.textSecondary,
                            fontSize: 12,
                            fontWeight: FontWeight.w400,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ],
                  ),
                  if (widget.showChevron) ...[
                    const SizedBox(width: AppSpacing.xs),
                    Icon(
                      LucideIcons.chevronRight,
                      size: 14,
                      color: context.tokens.textSecondary,
                    ),
                  ],
                ],
              ),
              if (widget.dropdownChild != null)
                AnimatedCrossFade(
                  firstChild: const SizedBox.shrink(),
                  secondChild: widget.dropdownChild!,
                  crossFadeState:
                      _isDropdownExpanded
                          ? CrossFadeState.showSecond
                          : CrossFadeState.showFirst,
                  duration: const Duration(milliseconds: 200),
                ),
            ],
          ),
        ),
      ),
    );

    if (widget.onDismissed != null) {
      tile = Dismissible(
        key: Key('${widget.merchant}${widget.amount}${widget.date}'),
        direction: DismissDirection.endToStart,
        onDismissed: (_) => widget.onDismissed?.call(),
        background: Container(
          padding: const EdgeInsets.only(right: AppSpacing.xl),
          decoration: BoxDecoration(
            color: AppColors.expense,
            // Must track the tile's own radius, or the red backdrop pokes out
            // at the corners mid-swipe.
            borderRadius: AppRadius.tileR,
          ),
          alignment: Alignment.centerRight,
          child: const Icon(LucideIcons.trash2, color: Colors.white, size: 20),
        ),
        child: tile,
      );
    }

    return tile;
  }
}

/// Purpose badge — tint-pair pill (Personal = purple, Family = amber),
/// solid pastel fill with dark on-tint text + dot, legible in both modes.
class _Badge extends StatelessWidget {
  final String label;
  final Color tint;

  /// Explicit ink, for fills that aren't one of the pastel tints. Without it
  /// [AppColors.onTint] falls through to its dark default, which disappears
  /// against a dark-mode surface colour.
  final Color? ink;

  const _Badge({required this.label, required this.tint, this.ink});

  @override
  Widget build(BuildContext context) {
    final ink = this.ink ?? AppColors.onTint(tint);
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.xs,
        vertical: 3,
      ),
      decoration: BoxDecoration(color: tint, borderRadius: AppRadius.pillR),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 5,
            height: 5,
            decoration: BoxDecoration(color: ink, shape: BoxShape.circle),
          ),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(
              color: ink,
              fontSize: 11,
              fontWeight: FontWeight.w500,
              letterSpacing: 0.2,
            ),
          ),
        ],
      ),
    );
  }
}
