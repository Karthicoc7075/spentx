import 'package:flutter/material.dart';

import '../navigation/main_shell_navigation.dart';
import '../theme/spentx_tokens.dart';
import '../theme/soft_palette.dart';

/// Shared visual primitives used by the mobile reference screens.
///
/// The data screens remain responsible for their content and actions. These
/// small primitives keep the repeated emerald hero treatment, soft surface
/// cards, and bottom-navigation geometry in one place.
class SxGreenHero extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final BorderRadius borderRadius;

  const SxGreenHero({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(20),
    this.borderRadius = const BorderRadius.all(Radius.circular(24)),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          // Soft Soft liquid hero (matches SoftHomeTone)
          colors: [Color(0xFF06281E), Color(0xFF041C15), Color(0xFF01140E)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: borderRadius,
        border: Border.all(color: SoftColors.control.withValues(alpha: .28)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x3506483B),
            blurRadius: 22,
            offset: Offset(0, 12),
          ),
        ],
      ),
      child: child,
    );
  }
}

class SxSoftCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color? color;
  final BorderRadius borderRadius;

  const SxSoftCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.color,
    this.borderRadius = const BorderRadius.all(Radius.circular(24)),
  });

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: color ?? t.card,
        borderRadius: borderRadius,
        border: Border.all(
          color:
              isDark
                  ? SoftPalette.darkBorder.withValues(alpha: 0.55)
                  : SoftPalette.border.withValues(alpha: 0.55),
          width: isDark ? 1 : 0.5,
        ),
        boxShadow: isDark ? null : AppShadows.subtle,
      ),
      child: child,
    );
  }
}

/// Circular Soft Soft icon button (white card on #f8f9fc, soft shadow).
/// Used for back / close / edit chrome to match Transaction details.
class SoftCircleIconButton extends StatelessWidget {
  const SoftCircleIconButton({
    super.key,
    required this.icon,
    required this.onPressed,
    this.tooltip,
    this.size = 40,
    this.iconSize = 18,
  });

  final IconData icon;
  final VoidCallback onPressed;
  final String? tooltip;
  final double size;
  final double iconSize;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final card = isDark ? SoftPalette.darkCard : SoftPalette.card;
    final ink = isDark ? SoftPalette.darkInk : SoftPalette.ink;
    final btn = Material(
      color: card,
      shape: const CircleBorder(),
      elevation: 0,
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onPressed,
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: card,
            boxShadow:
                isDark
                    ? null
                    : const [
                      BoxShadow(
                        color: Color(0x0F050D1A),
                        blurRadius: 16,
                        offset: Offset(0, 4),
                      ),
                    ],
            border:
                isDark
                    ? Border.all(
                      color: SoftPalette.darkBorder.withValues(alpha: 0.6),
                    )
                    : null,
          ),
          child: Icon(icon, size: iconSize, color: ink),
        ),
      ),
    );
    if (tooltip == null) return btn;
    return Tooltip(message: tooltip!, child: btn);
  }
}

/// Soft Soft page header: circular back, centered title, optional trailing.
class SoftPageHeader extends StatelessWidget {
  const SoftPageHeader({
    super.key,
    required this.title,
    this.onBack,
    this.trailing,
    this.subtitle,
  });

  final String title;
  final VoidCallback? onBack;
  final Widget? trailing;
  final String? subtitle;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final ink = isDark ? SoftPalette.darkInk : SoftPalette.ink;
    final muted = isDark ? SoftPalette.darkMuted : SoftPalette.muted;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: SizedBox(
        height: subtitle == null ? 44 : 56,
        child: Stack(
          alignment: Alignment.center,
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  title,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.3,
                    color: ink,
                  ),
                ),
                if (subtitle != null) ...[
                  const SizedBox(height: 2),
                  Text(
                    subtitle!,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      color: muted,
                    ),
                  ),
                ],
              ],
            ),
            Align(
              alignment: Alignment.centerLeft,
              child: SoftCircleIconButton(
                icon: Icons.arrow_back_ios_new_rounded,
                tooltip: 'Back',
                onPressed: onBack ?? () => Navigator.maybePop(context),
              ),
            ),
            if (trailing != null)
              Align(alignment: Alignment.centerRight, child: trailing!),
          ],
        ),
      ),
    );
  }
}

class SxPill extends StatelessWidget {
  final Widget child;
  final Color color;
  final Color textColor;
  final EdgeInsetsGeometry padding;
  final BorderSide? side;

  const SxPill({
    super.key,
    required this.child,
    required this.color,
    this.textColor = Colors.white,
    this.padding = const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    this.side,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(999),
        border: side == null ? null : Border.fromBorderSide(side!),
      ),
      child: DefaultTextStyle.merge(
        style: TextStyle(
          color: textColor,
          fontSize: 11,
          fontWeight: FontWeight.w700,
        ),
        child: child,
      ),
    );
  }
}

class SxReferenceBottomBar extends StatelessWidget {
  final String active;
  final bool planMode;
  final VoidCallback? onAdd;
  final ValueChanged<String>? onSelect;

  const SxReferenceBottomBar({
    super.key,
    required this.active,
    this.planMode = false,
    this.onAdd,
    this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    // Soft Soft bottom nav parity with SoftBottomNav (icons + labels, emerald selected).
    final items = [
      ('home', Icons.home_outlined, 'Home'),
      ('activity', Icons.receipt_long_outlined, 'Activity'),
      (
        planMode ? 'plan' : 'analytics',
        planMode
            ? Icons.receipt_long_outlined
            : Icons.pie_chart_outline_rounded,
        planMode ? 'Plan' : 'Analytics',
      ),
      ('accounts', Icons.savings_outlined, 'Accounts'),
    ];
    final selectedColor = isDark ? SoftPalette.darkEmerald : SoftColors.control;
    return Material(
      color: t.card.withValues(alpha: .98),
      child: SafeArea(
        top: false,
        child: Container(
          height: 68,
          decoration: BoxDecoration(
            border: Border(top: BorderSide(color: t.border)),
            boxShadow: const [
              BoxShadow(
                color: Color(0x0F020617),
                blurRadius: 12,
                offset: Offset(0, -3),
              ),
            ],
          ),
          child: Row(
            children: [
              Expanded(child: _barItem(context, items[0], selectedColor)),
              Expanded(child: _barItem(context, items[1], selectedColor)),
              SizedBox(
                width: 72,
                child: Center(
                  child: GestureDetector(
                    onTap: onAdd,
                    child: Container(
                      width: 56,
                      height: 56,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: SoftColors.primaryGradient,
                        boxShadow: const [
                          BoxShadow(
                            color: Color(0x40059669),
                            blurRadius: 16,
                            offset: Offset(0, 6),
                          ),
                        ],
                      ),
                      child: Icon(
                        Icons.add_rounded,
                        color: Colors.white,
                        size: 28,
                      ),
                    ),
                  ),
                ),
              ),
              Expanded(child: _barItem(context, items[2], selectedColor)),
              Expanded(child: _barItem(context, items[3], selectedColor)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _barItem(
    BuildContext context,
    (String, IconData, String) item,
    Color selectedColor,
  ) {
    final selected = active == item.$1;
    final color = selected ? selectedColor : context.tokens.textSecondary;
    return InkWell(
      onTap: () {
        if (onSelect != null) {
          onSelect!(item.$1);
          return;
        }
        if (selected) return;
        MainShellNavigation.handleReferenceDestination(context, item.$1);
      },
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(item.$2, size: 21, color: color),
          const SizedBox(height: 3),
          Text(
            item.$3,
            style: TextStyle(
              fontSize: 10,
              fontWeight: selected ? FontWeight.w800 : FontWeight.w500,
              color: color,
            ),
          ),
          const SizedBox(height: 3),
          Container(
            width: 5,
            height: 5,
            decoration: BoxDecoration(
              color: selected ? selectedColor : Colors.transparent,
              shape: BoxShape.circle,
            ),
          ),
        ],
      ),
    );
  }
}
