import 'dart:async';
import 'package:flutter/material.dart';
import '../config/developer_config.dart';

/// A transparent wrapper that transforms screens into a retro hacker command-line terminal theme
/// when [kDeveloperTerminalUI] is enabled. If [kDeveloperTerminalUI] is disabled, returns [child] unchanged.
class TerminalWrapper extends StatefulWidget {
  final String screenName;
  final List<String> components;
  final Widget child;

  const TerminalWrapper({
    super.key,
    required this.screenName,
    this.components = const [],
    required this.child,
  });

  @override
  State<TerminalWrapper> createState() => _TerminalWrapperState();
}

class _TerminalWrapperState extends State<TerminalWrapper> {
  bool _cursorVisible = true;
  Timer? _cursorTimer;

  @override
  void initState() {
    super.initState();
    if (kDeveloperTerminalUI) {
      _cursorTimer = Timer.periodic(const Duration(milliseconds: 500), (_) {
        if (mounted) {
          setState(() => _cursorVisible = !_cursorVisible);
        }
      });
    }
  }

  @override
  void dispose() {
    _cursorTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!kDeveloperTerminalUI) {
      return widget.child;
    }

    final defaultComponents = switch (widget.screenName) {
      'HomeScreen' || 'Home' => [
          'NetWorthCard',
          'BankCard',
          'CashCard',
          'QuickActions',
          'RecentTransactions'
        ],
      'Activity' || 'Transactions' => [
          'SearchBar',
          'FilterChips',
          'TransactionCard 1',
          'TransactionCard 2',
          'TransactionCard 3'
        ],
      'Analysis' || 'Analytics' => [
          'SpendingChart',
          'CategoryChart',
          'MonthlyTrend',
          'TopCategories'
        ],
      'Settings' => [
          'Appearance',
          'Notifications',
          'Categories',
          'Security',
          'Backup'
        ],
      'AddExpenseForm' || 'AddTransactionSheet' => [
          'Merchant',
          'Amount',
          'Category',
          'Purpose',
          'Date',
          'Notes',
          'SaveButton'
        ],
      _ => widget.components,
    };

    return Theme(
      data: Theme.of(context).copyWith(
        scaffoldBackgroundColor: TerminalColors.bg,
        canvasColor: TerminalColors.bg,
        cardColor: TerminalColors.bg,
        colorScheme: const ColorScheme.dark(
          surface: TerminalColors.bg,
          primary: TerminalColors.green,
          onSurface: TerminalColors.green,
        ),
        textTheme: Theme.of(context).textTheme.apply(
              fontFamily: 'monospace',
              bodyColor: TerminalColors.green,
              displayColor: TerminalColors.green,
            ),
      ),
      child: Scaffold(
        backgroundColor: TerminalColors.bg,
        body: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ── Terminal Header Log Box ──
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                margin: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: TerminalColors.border, width: 1),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '> Loading ${widget.screenName}...',
                      style: const TextStyle(
                        fontFamily: 'monospace',
                        color: TerminalColors.green,
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    ...defaultComponents.map((comp) => Padding(
                          padding: const EdgeInsets.only(bottom: 2),
                          child: Row(
                            children: [
                              const Text(
                                '✔ ',
                                style: TextStyle(
                                  fontFamily: 'monospace',
                                  color: TerminalColors.green,
                                  fontSize: 13,
                                ),
                              ),
                              Text(
                                comp,
                                style: const TextStyle(
                                  fontFamily: 'monospace',
                                  color: TerminalColors.textMuted,
                                  fontSize: 13,
                                ),
                              ),
                            ],
                          ),
                        )),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const Text(
                          'Ready... ',
                          style: TextStyle(
                            fontFamily: 'monospace',
                            color: TerminalColors.green,
                            fontSize: 13,
                          ),
                        ),
                        Text(
                          _cursorVisible ? '_' : ' ',
                          style: const TextStyle(
                            fontFamily: 'monospace',
                            color: TerminalColors.green,
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              // ── Actual Underlying Interactive Screen ──
              Expanded(
                child: widget.child,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
