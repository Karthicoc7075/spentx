import 'package:flutter/material.dart';

import '../design/sx_primitives.dart';
import '../theme/spentx_tokens.dart';

/// **Deprecated alias — use [SxCard] directly in new code.**
///
/// Despite the name there is no glassmorphism here (and the design system
/// forbids it). This now delegates straight to [SxCard] so its 18 remaining
/// importers inherit the design system's card treatment — one radius, one
/// hairline border, no shadow in dark — instead of drifting on their own.
@Deprecated('Use SxCard from core/design/sx_primitives.dart')
class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets? padding;
  final BorderRadius? borderRadius;
  final Color? borderColor;
  final Color? backgroundColor;
  final VoidCallback? onTap;

  const GlassCard({
    super.key,
    required this.child,
    this.padding,
    this.borderRadius,
    this.borderColor,
    this.backgroundColor,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return SxCard(
      onTap: onTap,
      color: backgroundColor,
      borderColor: borderColor,
      padding: padding ?? const EdgeInsets.all(AppSpacing.cardPad),
      elevated: true,
      child: child,
    );
  }
}
