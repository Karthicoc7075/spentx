import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../theme/app_colors.dart';

class CategoryData {
  /// Tint background for the icon container (pastel).
  final Color color;
  final IconData icon;
  final String label;

  const CategoryData(this.icon, this.color, this.label);

  /// Dark on-tint shade — use for the icon glyph, labels, and any
  /// stroke/progress usage where the pastel tint would be illegible.
  Color get onColor => AppColors.onTint(color);
}

abstract final class CategoryIcon {
  static const Map<String, CategoryData> _map = {
    'food': CategoryData(LucideIcons.utensils, AppColors.tintPink, 'Food'),
    'food & dining': CategoryData(
      LucideIcons.utensils,
      AppColors.tintPink,
      'Food & Dining',
    ),
    'food and dining': CategoryData(
      LucideIcons.utensils,
      AppColors.tintPink,
      'Food & Dining',
    ),
    'dining': CategoryData(LucideIcons.utensils, AppColors.tintPink, 'Dining'),
    'groceries': CategoryData(
      LucideIcons.shoppingCart,
      AppColors.tintPurple,
      'Groceries',
    ),
    'shopping': CategoryData(
      LucideIcons.shoppingBag,
      AppColors.tintAmber,
      'Shopping',
    ),
    'transport': CategoryData(LucideIcons.car, AppColors.tintBlue, 'Transport'),
    'transportation': CategoryData(
      LucideIcons.car,
      AppColors.tintBlue,
      'Transportation',
    ),
    'fuel': CategoryData(LucideIcons.fuel, AppColors.tintAmber, 'Fuel'),
    'entertainment': CategoryData(
      LucideIcons.film,
      AppColors.tintPurple,
      'Entertainment',
    ),
    'bills': CategoryData(LucideIcons.receipt, AppColors.tintGreen, 'Bills'),
    'bills & utilities': CategoryData(
      LucideIcons.receipt,
      AppColors.tintGreen,
      'Bills & Utilities',
    ),
    'utilities': CategoryData(
      LucideIcons.receipt,
      AppColors.tintGreen,
      'Utilities',
    ),
    'recharge': CategoryData(
      LucideIcons.smartphone,
      AppColors.tintGreen,
      'Recharge',
    ),
    'health': CategoryData(LucideIcons.heart, AppColors.tintPink, 'Health'),
    'healthcare': CategoryData(
      LucideIcons.heart,
      AppColors.tintPink,
      'Healthcare',
    ),
    'education': CategoryData(
      LucideIcons.graduationCap,
      AppColors.tintBlue,
      'Education',
    ),
    'salary': CategoryData(
      LucideIcons.briefcase,
      AppColors.tintGreen,
      'Salary',
    ),
    'freelance': CategoryData(
      LucideIcons.laptop,
      AppColors.tintGreen,
      'Freelance',
    ),
    'investment': CategoryData(
      LucideIcons.trendingUp,
      AppColors.tintAmber,
      'Investment',
    ),
    'investments': CategoryData(
      LucideIcons.trendingUp,
      AppColors.tintAmber,
      'Investments',
    ),
    'rent': CategoryData(LucideIcons.home, AppColors.tintPurple, 'Rent'),
    'emi': CategoryData(LucideIcons.landmark, AppColors.tintPurple, 'EMI'),
    'transfer': CategoryData(
      LucideIcons.arrowRightLeft,
      AppColors.tintBlue,
      'Transfer',
    ),
    'upi': CategoryData(LucideIcons.smartphone, AppColors.tintPurple, 'UPI'),
    'subscription': CategoryData(
      LucideIcons.repeat,
      AppColors.tintPurple,
      'Subscription',
    ),
    'travel': CategoryData(LucideIcons.plane, AppColors.tintBlue, 'Travel'),
    'trip': CategoryData(LucideIcons.map, AppColors.tintBlue, 'Trip'),
    'outings': CategoryData(LucideIcons.mapPin, AppColors.tintGreen, 'Outings'),
    'hotel stay': CategoryData(
      LucideIcons.hotel,
      AppColors.tintBlue,
      'Hotel Stay',
    ),
    'flight': CategoryData(LucideIcons.plane, AppColors.tintBlue, 'Flight'),
    'sightseeing': CategoryData(
      LucideIcons.camera,
      AppColors.tintBlue,
      'Sightseeing',
    ),
    'gift': CategoryData(LucideIcons.gift, AppColors.tintAmber, 'Gift'),
    'gifts': CategoryData(LucideIcons.gift, AppColors.tintAmber, 'Gifts'),
    'misc': CategoryData(
      LucideIcons.moreHorizontal,
      AppColors.tintPurple,
      'Misc',
    ),
    'miscellaneous': CategoryData(
      LucideIcons.moreHorizontal,
      AppColors.tintPurple,
      'Miscellaneous',
    ),
    'other': CategoryData(
      LucideIcons.moreHorizontal,
      AppColors.tintPurple,
      'Other',
    ),
  };

  static CategoryData resolve(String category) {
    final raw = category.trim();
    if (raw.isEmpty) {
      return const CategoryData(
        LucideIcons.circle,
        AppColors.tintPurple,
        'Other',
      );
    }
    final key = raw.toLowerCase();
    final exact = _map[key];
    if (exact != null) {
      // Keep the user's real category name as the chip label.
      return CategoryData(exact.icon, exact.color, raw);
    }

    // Fuzzy match: "Food & Dining" → food, "EMI Payment" → emi, etc.
    for (final entry in _map.entries) {
      if (key.contains(entry.key) || entry.key.contains(key)) {
        return CategoryData(entry.value.icon, entry.value.color, raw);
      }
    }

    // Unknown category — still show the real name (not always "Other").
    return CategoryData(LucideIcons.tag, AppColors.tintPurple, raw);
  }

  static List<String> get allCategories => _map.keys.toList();

  static List<CategoryData> get allData => _map.values.toList();
}

/// Icon well colors for a ledger row.
///
/// Uses the hex already saved on the category. When nothing is stored,
/// falls back to the type color: expense rose, income emerald, transfer blue.
class CategoryTone {
  const CategoryTone(this.bg, this.fg, this.border);
  final Color bg;
  final Color fg;
  final Color border;
}

abstract final class CategoryToneLookup {
  static Color? parseHex(String? raw) {
    if (raw == null) return null;
    var hex = raw.trim();
    if (hex.isEmpty) return null;
    if (hex.startsWith('#')) hex = hex.substring(1);
    if (hex.length == 6) hex = 'FF$hex';
    if (hex.length != 8) return null;
    final value = int.tryParse(hex, radix: 16);
    if (value == null) return null;
    return Color(value);
  }

  static CategoryTone resolve({
    String? storedHex,
    required bool isExpense,
    required bool isTransfer,
    bool isDark = false,
  }) {
    final stored = parseHex(storedHex);
    if (stored != null) {
      return CategoryTone(
        stored.withValues(alpha: isDark ? 0.22 : 0.14),
        stored,
        stored.withValues(alpha: isDark ? 0.45 : 0.35),
      );
    }
    if (isTransfer) {
      const fg = Color(0xFF1D4ED8);
      return CategoryTone(
        isDark ? fg.withValues(alpha: 0.22) : const Color(0xFFDBEAFE),
        fg,
        isDark ? fg.withValues(alpha: 0.45) : const Color(0xFFBFDBFE),
      );
    }
    if (!isExpense) {
      const fg = Color(0xFF059669);
      return CategoryTone(
        isDark ? fg.withValues(alpha: 0.22) : const Color(0xFFECFDF5),
        fg,
        isDark ? fg.withValues(alpha: 0.45) : const Color(0xFFA7F3D0),
      );
    }
    const fg = Color(0xFFE11D48);
    return CategoryTone(
      isDark ? fg.withValues(alpha: 0.22) : const Color(0xFFFFF1F2),
      fg,
      isDark ? fg.withValues(alpha: 0.45) : const Color(0xFFFECDD3),
    );
  }
}
