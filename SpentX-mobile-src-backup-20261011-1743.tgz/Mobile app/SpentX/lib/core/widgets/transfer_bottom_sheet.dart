import 'package:flutter/material.dart';
import '../theme/spentx_tokens.dart';
import '../theme/soft_palette.dart';
import 'reference_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../theme/app_colors.dart';
import '../providers/transaction_provider.dart' as model;
import '../providers/user_state_provider.dart';

class TransferBottomSheet extends ConsumerStatefulWidget {
  const TransferBottomSheet({super.key});

  @override
  ConsumerState<TransferBottomSheet> createState() =>
      _TransferBottomSheetState();
}

class _TransferBottomSheetState extends ConsumerState<TransferBottomSheet> {
  final _formKey = GlobalKey<FormState>();
  final _amountController = TextEditingController();

  String? _fromAccount;
  String? _toAccount;

  String _formatMoney(double value) {
    final rounded = value.round().toString();
    if (rounded.length <= 3) return rounded;
    final lastThree = rounded.substring(rounded.length - 3);
    final rest = rounded.substring(0, rounded.length - 3);
    final grouped = rest.replaceAllMapped(
      RegExp(r'\B(?=(\d{2})+(?!\d))'),
      (match) => ',',
    );
    return '$grouped,$lastThree';
  }

  double _fromBalance() {
    final account = _fromAccount;
    if (account == null || account.isEmpty) return 0;
    return ref
        .read(model.transactionProvider.notifier)
        .getFullAccountBalance(account);
  }

  @override
  void dispose() {
    _amountController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final errorStyle = TextStyle(
      color: Colors.red.shade400,
      fontSize: 12,
      fontWeight: FontWeight.w500,
    );
    final fromBalance = _fromBalance();

    final accounts =
        ref.watch(userStateProvider).accounts.map((e) => e.name).toList();
    if (accounts.isEmpty) accounts.add('Cash'); // Fallback

    if (_fromAccount == null && accounts.isNotEmpty) {
      _fromAccount = accounts.first;
    }
    if (_toAccount == null && accounts.length > 1) _toAccount = accounts[1];
    if (_toAccount == null && accounts.isNotEmpty) _toAccount = accounts.first;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Form(
        key: _formKey,
        autovalidateMode: AutovalidateMode.onUserInteraction,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'Transfer Money',
                    style: TextStyle(
                      color: SoftPalette.ink,
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                SoftCircleIconButton(
                  icon: Icons.close_rounded,
                  tooltip: 'Close',
                  onPressed: () => Navigator.maybePop(context),
                ),
              ],
            ),
            const SizedBox(height: 24),

            // Amount
            TextFormField(
              controller: _amountController,
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
              ),
              style: const TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 32,
                letterSpacing: -1,
              ),
              validator: (v) {
                final amount =
                    double.tryParse((v ?? '').replaceAll(',', '')) ?? 0;
                if (amount <= 0) return 'Enter amount';
                if (amount > _fromBalance()) {
                  return 'Insufficient balance in $_fromAccount. Available ₹${_formatMoney(_fromBalance())}';
                }
                return null;
              },
              onChanged: (v) => _formKey.currentState?.validate(),
              decoration: InputDecoration(
                prefixText: '₹ ',
                hintText: '0',
                helperText:
                    _fromAccount == null
                        ? null
                        : 'Available in $_fromAccount: ₹${_formatMoney(fromBalance)}',
                errorStyle: errorStyle,
                filled: true,
                fillColor: context.tokens.field,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: BorderSide.none,
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: const BorderSide(
                    color: SoftPalette.emerald,
                    width: 1.5,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 32),

            // From Account
            _SectionLabel(label: 'FROM ACCOUNT', isDark: isDark),
            const SizedBox(height: 12),
            FormField<String>(
              initialValue: _fromAccount,
              builder:
                  (state) => Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children:
                        accounts.map((acc) {
                          final selected = _fromAccount == acc;
                          return _ChoiceChip(
                            label: acc,
                            isSelected: selected,
                            onTap: () {
                              setState(() => _fromAccount = acc);
                              _formKey.currentState?.validate();
                            },
                          );
                        }).toList(),
                  ),
            ),
            const SizedBox(height: 24),

            // To Account
            _SectionLabel(label: 'TO ACCOUNT', isDark: isDark),
            const SizedBox(height: 12),
            FormField<String>(
              initialValue: _toAccount,
              validator:
                  (v) =>
                      _toAccount == _fromAccount
                          ? 'Please select a different destination account.'
                          : null,
              builder:
                  (state) => Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children:
                            accounts.map((acc) {
                              final selected = _toAccount == acc;
                              return _ChoiceChip(
                                label: acc,
                                isSelected: selected,
                                onTap: () {
                                  setState(() => _toAccount = acc);
                                  state.didChange(acc);
                                },
                                hasError: state.hasError && acc == _toAccount,
                              );
                            }).toList(),
                      ),
                      if (state.hasError) ...[
                        const SizedBox(height: 8),
                        Text(state.errorText!, style: errorStyle),
                      ],
                    ],
                  ),
            ),
            const SizedBox(height: 40),

            Container(
              width: double.infinity,
              height: 58,
              decoration: BoxDecoration(
                gradient: SoftColors.primaryGradient,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.primary.withValues(alpha: 0.3),
                    blurRadius: 15,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    final amount = double.parse(
                      _amountController.text.replaceAll(',', ''),
                    );

                    // Belt-and-suspenders: never move money past what the form
                    // validator already checked — re-verify right here so a
                    // transfer can never go through over the source balance,
                    // regardless of any validation-timing edge case.
                    final available = _fromBalance();
                    if (amount > available) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            'Insufficient balance in $_fromAccount. Available ₹${_formatMoney(available)}',
                          ),
                          backgroundColor: Colors.red.shade400,
                        ),
                      );
                      return;
                    }

                    final fromIsCash = _fromAccount == 'Cash';
                    final toIsCash = _toAccount == 'Cash';
                    final transferType =
                        fromIsCash && !toIsCash
                            ? 'cash_to_bank'
                            : !fromIsCash && toIsCash
                            ? 'bank_to_cash'
                            : 'bank_to_bank';
                    final toAccountId =
                        ref
                            .read(userStateProvider)
                            .accounts
                            .where((a) => a.name == _toAccount)
                            .map((a) => a.id)
                            .firstOrNull;

                    // Single row, matching the new Supabase transfer shape
                    // (account = FROM/debit leg, transferTo/toAccountId = TO
                    // side). transferType being non-null is what the balance
                    // engine (getAccountBalance) uses to credit the destination
                    // side of a new-style transfer without double-counting a
                    // legacy two-row one.
                    final tx = model.Transaction(
                      merchant: 'TR $_fromAccount to $_toAccount',
                      category: 'Transfer',
                      account: _fromAccount!,
                      paymentType: fromIsCash ? 'Cash' : 'Online',
                      time: 'Just now',
                      amount: amount,
                      isExpense: true,
                      isTransfer: true,
                      transferTo: _toAccount,
                      toAccountId: toAccountId,
                      transferType: transferType,
                      date: DateTime.now(),
                      note: '',
                    );
                    ref
                        .read(model.transactionProvider.notifier)
                        .addTransaction(tx);

                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          'Transfer Successful: ₹${amount.toInt()}',
                        ),
                      ),
                    );
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundBuilder: SoftColors.plainBackground,
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                // Dark ink on brand-green gradient (design-system on-pastel).
                child: const Text(
                  'CONFIRM TRANSFER',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    letterSpacing: 1,
                    color: AppColors.onPastel,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ChoiceChip extends StatelessWidget {
  final String label;
  final bool isSelected;
  final bool hasError;
  final VoidCallback onTap;
  const _ChoiceChip({
    required this.label,
    required this.isSelected,
    required this.onTap,
    this.hasError = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color:
              isSelected
                  ? AppColors.primary.withValues(alpha: 0.12)
                  : (context.tokens.field),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color:
                isSelected
                    ? AppColors.primary
                    : (hasError ? Colors.red.shade400 : Colors.transparent),
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 13,
            fontWeight: isSelected ? FontWeight.w500 : FontWeight.w400,
            color:
                isSelected ? AppColors.primary : (context.tokens.textSecondary),
          ),
        ),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String label;
  final bool isDark;
  const _SectionLabel({required this.label, required this.isDark});

  @override
  Widget build(BuildContext context) {
    return Text(
      label,
      style: TextStyle(
        fontSize: 11,
        fontWeight: FontWeight.w500,
        letterSpacing: 1.2,
        color: context.tokens.textSecondary,
      ),
    );
  }
}
