import 'package:flutter/material.dart';
import '../theme/app_fonts.dart';

class AnimatedCounter extends StatefulWidget {
  final double value;
  final String prefix;
  final String suffix;
  final TextStyle? style;
  final TextStyle? decimalStyle;
  final Duration duration;
  final int decimalPlaces;

  const AnimatedCounter({
    super.key,
    required this.value,
    this.prefix = '₹',
    this.suffix = '',
    this.style,
    this.decimalStyle,
    this.duration = const Duration(milliseconds: 800),
    this.decimalPlaces = 0,
  });

  @override
  State<AnimatedCounter> createState() => _AnimatedCounterState();
}

class _AnimatedCounterState extends State<AnimatedCounter>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  double _oldValue = 0;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(duration: widget.duration, vsync: this);
    _animation = Tween<double>(begin: 0, end: widget.value).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic),
    );
    _controller.forward();
  }

  @override
  void didUpdateWidget(AnimatedCounter oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.value != widget.value) {
      _oldValue = oldWidget.value;
      _animation = Tween<double>(begin: _oldValue, end: widget.value).animate(
        CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic),
      );
      _controller
        ..reset()
        ..forward();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  String _formatNumber(double value) {
    // Indian numbering system
    final intPart = value.truncate();
    final str = intPart.toString();
    if (str.length <= 3) return str;

    final lastThree = str.substring(str.length - 3);
    String remaining = str.substring(0, str.length - 3);
    final RegExp reg = RegExp(r'\B(?=(\d{2})+(?!\d))');
    remaining = remaining.replaceAllMapped(reg, (m) => '${m[0]},');
    return '$remaining,$lastThree';
  }

  @override
  Widget build(BuildContext context) {
    final defaultStyle = AppFonts.text(
      fontSize: 34,
      fontWeight: FontWeight.w500,
      letterSpacing: -1.5,
      color: Theme.of(context).colorScheme.onSurface,
    );

    return AnimatedBuilder(
      animation: _animation,
      builder: (context, _) {
        final val = _animation.value;
        final formatted = _formatNumber(val);
        final decimal = widget.decimalPlaces > 0
            ? '.${(val % 1).toStringAsFixed(widget.decimalPlaces).split('.').last}'
            : '';

        return Row(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.baseline,
          textBaseline: TextBaseline.alphabetic,
          children: [
            Text(
              '${widget.prefix}$formatted',
              style: widget.style ?? defaultStyle,
            ),
            if (decimal.isNotEmpty)
              Text(
                decimal,
                style: widget.decimalStyle ??
                    (widget.style ?? defaultStyle).copyWith(
                      fontSize: ((widget.style ?? defaultStyle).fontSize ?? 34) * 0.6,
                      fontWeight: FontWeight.w500,
                      color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.5),
                    ),
              ),
            if (widget.suffix.isNotEmpty)
              Text(widget.suffix, style: widget.style ?? defaultStyle),
          ],
        );
      },
    );
  }
}
