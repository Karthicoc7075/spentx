import 'package:flutter/material.dart';

import '../design/sx_primitives.dart';

/// **Deprecated alias — use [SxSectionHeader] directly in new code.**
///
/// Delegates to the design-system header so title size, weight, and the
/// trailing action's 44px tap target stay consistent everywhere.
@Deprecated('Use SxSectionHeader from core/design/sx_primitives.dart')
class SectionHeader extends StatelessWidget {
  final String title;
  final String? actionLabel;
  final VoidCallback? onAction;

  const SectionHeader({
    super.key,
    required this.title,
    this.actionLabel,
    this.onAction,
  });

  @override
  Widget build(BuildContext context) {
    return SxSectionHeader(
      title: title,
      actionLabel: actionLabel,
      onAction: onAction,
    );
  }
}
