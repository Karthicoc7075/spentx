import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/animation_provider.dart';

/// A wrapper widget that adds micro-scale press feedback (0.97 scale on touch down, 1.0 on release)
/// for cards, action buttons, and list tiles across the app. Respects animation settings.
class AnimatedTapCard extends ConsumerStatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  final double scaleDown;
  final Duration duration;

  const AnimatedTapCard({
    super.key,
    required this.child,
    this.onTap,
    this.onLongPress,
    this.scaleDown = 0.97,
    this.duration = const Duration(milliseconds: 120),
  });

  @override
  ConsumerState<AnimatedTapCard> createState() => _AnimatedTapCardState();
}

class _AnimatedTapCardState extends ConsumerState<AnimatedTapCard> {
  bool _isPressed = false;

  void _onTapDown(TapDownDetails _) {
    if (widget.onTap == null && widget.onLongPress == null) return;
    final animState = ref.read(animationSettingsProvider);
    if (!animState.isAnimated) return;
    setState(() => _isPressed = true);
  }

  void _onTapUp(TapUpDetails _) {
    if (_isPressed) {
      setState(() => _isPressed = false);
    }
  }

  void _onTapCancel() {
    if (_isPressed) {
      setState(() => _isPressed = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final animState = ref.watch(animationSettingsProvider);
    final isAnimated = animState.isAnimated;

    return GestureDetector(
      onTapDown: isAnimated ? _onTapDown : null,
      onTapUp: isAnimated ? _onTapUp : null,
      onTapCancel: isAnimated ? _onTapCancel : null,
      onTap: widget.onTap,
      onLongPress: widget.onLongPress,
      behavior: HitTestBehavior.opaque,
      child: AnimatedScale(
        scale: (_isPressed && isAnimated) ? widget.scaleDown : 1.0,
        duration: animState.getDuration(widget.duration),
        curve: animState.getCurve(Curves.easeOutCubic),
        child: widget.child,
      ),
    );
  }
}
