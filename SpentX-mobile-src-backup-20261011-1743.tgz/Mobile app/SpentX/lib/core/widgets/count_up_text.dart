import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/animation_provider.dart';

/// Animated Count-Up Text widget (e.g. ₹25,430 → ₹26,150) that smoothly
/// interpolates numbers over 400-600ms. Respects user animation preferences.
class CountUpText extends ConsumerStatefulWidget {
  final double targetValue;
  final String prefix;
  final String suffix;
  final TextStyle? style;

  const CountUpText({
    super.key,
    required this.targetValue,
    this.prefix = '₹',
    this.suffix = '',
    this.style,
  });

  @override
  ConsumerState<CountUpText> createState() => _CountUpTextState();
}

class _CountUpTextState extends ConsumerState<CountUpText>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  double _oldValue = 0;

  @override
  void initState() {
    super.initState();
    _oldValue = widget.targetValue;
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _animation = Tween<double>(begin: widget.targetValue, end: widget.targetValue)
        .animate(_controller);
  }

  @override
  void didUpdateWidget(CountUpText oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.targetValue != widget.targetValue) {
      final animState = ref.read(animationSettingsProvider);
      if (!animState.isAnimated) {
        _oldValue = widget.targetValue;
        return;
      }

      _oldValue = oldWidget.targetValue;
      final duration = animState.getDuration(const Duration(milliseconds: 500));
      _controller.duration = duration;

      _animation = Tween<double>(
        begin: _oldValue,
        end: widget.targetValue,
      ).animate(
        CurvedAnimation(
          parent: _controller,
          curve: animState.getCurve(Curves.easeOutCubic),
        ),
      );

      _controller.forward(from: 0);
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  String _formatIndian(int value) {
    final str = value.toString();
    if (str.length <= 3) return str;
    final lastThree = str.substring(str.length - 3);
    String remaining = str.substring(0, str.length - 3);
    final reg = RegExp(r'\B(?=(\d{2})+(?!\d))');
    remaining = remaining.replaceAllMapped(reg, (m) => '${m[0]},');
    return '$remaining,$lastThree';
  }

  @override
  Widget build(BuildContext context) {
    final animState = ref.watch(animationSettingsProvider);

    if (!animState.isAnimated) {
      final formatted = _formatIndian(widget.targetValue.toInt());
      return Text(
        '${widget.prefix}$formatted${widget.suffix}',
        style: widget.style,
      );
    }

    return AnimatedBuilder(
      animation: _animation,
      builder: (context, child) {
        final current = _animation.value.toInt();
        final formatted = _formatIndian(current);
        return Text(
          '${widget.prefix}$formatted${widget.suffix}',
          style: widget.style,
        );
      },
    );
  }
}
