import 'package:flutter/material.dart';
import '../theme/spentx_tokens.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../theme/app_colors.dart';

class GroupSummaryTile extends StatelessWidget {
  final String title;
  final int count;
  final double totalAmount;
  final String accountType;
  final VoidCallback onTap;

  const GroupSummaryTile({
    super.key,
    required this.title,
    required this.count,
    required this.totalAmount,
    required this.accountType,
    required this.onTap,
  });

  String _formatAmount(double value) {
    final intPart = value.truncate();
    final str = intPart.toString();
    if (str.length <= 3) return str;
    final lastThree = str.substring(str.length - 3);
    String remaining = str.substring(0, str.length - 3);
    final reg = RegExp(r'\B(?=(\d{2})+(?!\d))');
    remaining = remaining.replaceAllMapped(reg, (m) => '${m[0]},');
    return '$remaining,$lastThree';
  }

  @override
  Widget build(BuildContext context) {
    final color = accountType == 'Home' ? AppColors.homeAccount : AppColors.ownAccount;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: context.tokens.card,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: color.withValues(alpha: 0.1), width: 1),
        ),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(LucideIcons.briefcase, color: color, size: 20),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontWeight: FontWeight.w500,
                      fontSize: 16,
                      color: Theme.of(context).colorScheme.onSurface,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '$count expenses • $accountType',
                    style: TextStyle(
                      color: context.tokens.textSecondary,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  '₹${_formatAmount(totalAmount)}',
                  style: TextStyle(
                    fontWeight: FontWeight.w500,
                    fontSize: 16,
                    color: Theme.of(context).colorScheme.onSurface,
                  ),
                ),
                const SizedBox(height: 4),
                Icon(LucideIcons.chevronRight, size: 16, color: context.tokens.textSecondary),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
