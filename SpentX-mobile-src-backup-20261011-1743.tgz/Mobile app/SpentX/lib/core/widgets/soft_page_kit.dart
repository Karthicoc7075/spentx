import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../theme/soft_palette.dart';
import 'soft_buttons.dart';

export 'soft_buttons.dart';

/// Shared soft UI kit for secondary pages (Detected SMS, Friends, Friend
/// details, Outings, Outing form, Notification preferences) so they match the
/// Home / Activity look: canvas #F8F9FC, white radius-24 cards with a soft
/// shadow and no borders, ink #0F172A titles, slate #64748B secondary text.
/// Dark mode: #18181B cards with the existing SoftPalette dark tokens.
abstract final class SoftKit {
  static const canvasLight = Color(0xFFF8F9FC);
  static const inkLight = Color(0xFF0F172A);
  static const slateLight = Color(0xFF64748B);
  static const primaryGreen = SoftColors.control;
  /// Accent for focus rings / cursors / small controls (was #10B981).
  static const plusGreen = SoftColors.control;
  static const radius = 24.0;

  static const shadow = [
    BoxShadow(color: Color(0x0F050D1A), blurRadius: 24, offset: Offset(0, 8)),
  ];

  static bool dark(BuildContext c) => Theme.of(c).brightness == Brightness.dark;
  static Color canvas(BuildContext c) => dark(c) ? SoftPalette.darkBg : canvasLight;
  static Color card(BuildContext c) => dark(c) ? SoftPalette.darkCard : Colors.white;
  static Color ink(BuildContext c) => dark(c) ? SoftPalette.darkInk : inkLight;
  static Color slate(BuildContext c) => dark(c) ? SoftPalette.darkMuted : slateLight;
  static Color faint(BuildContext c) => dark(c) ? SoftPalette.darkFaint : SoftPalette.faint;
  static Color divider(BuildContext c) =>
      dark(c) ? SoftPalette.darkDivider : const Color(0xFFF1F5F9);
  static Color field(BuildContext c) =>
      dark(c) ? SoftPalette.darkBg : const Color(0xFFF8FAFC);
  static Color fieldBorder(BuildContext c) =>
      dark(c) ? const Color(0xFF3F3F46) : const Color(0xFFE2E8F0);
  static Color primary(BuildContext c) => primaryGreen;
  static Color positive(BuildContext c) =>
      dark(c) ? SoftPalette.darkEmerald : SoftPalette.positive;
  static Color negative(BuildContext c) =>
      dark(c) ? const Color(0xFFF87171) : SoftPalette.negative;
  static Color softTint(BuildContext c) =>
      dark(c) ? SoftPalette.darkEmeraldSoft : SoftPalette.emeraldSoft;
  static List<BoxShadow>? cardShadow(BuildContext c) => dark(c) ? null : shadow;

  static TextStyle text(
    BuildContext c,
    double size,
    FontWeight weight,
    Color color, {
    double? letterSpacing,
    double? height,
  }) => TextStyle(
    fontSize: size,
    fontWeight: weight,
    color: color,
    letterSpacing: letterSpacing,
    height: height,
  );

  /// Same field style as the Plan form / edit sheet.
  static InputDecoration input(
    BuildContext c, {
    String? label,
    String? hint,
    String? prefix,
    Widget? prefixIcon,
    Widget? suffixIcon,
    String? errorText,
  }) {
    final r = BorderRadius.circular(16);
    final side = BorderSide(color: fieldBorder(c));
    return InputDecoration(
      labelText: label,
      hintText: hint,
      errorText: errorText,
      prefixText: prefix,
      prefixIcon: prefixIcon,
      suffixIcon: suffixIcon,
      labelStyle: text(c, 13, FontWeight.w600, slate(c)),
      hintStyle: text(c, 13, FontWeight.w500, faint(c)),
      prefixStyle: text(c, 15, FontWeight.w700, ink(c)),
      filled: true,
      fillColor: field(c),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      border: OutlineInputBorder(borderRadius: r, borderSide: side),
      enabledBorder: OutlineInputBorder(borderRadius: r, borderSide: side),
      focusedBorder: OutlineInputBorder(
        borderRadius: r,
        borderSide: const BorderSide(color: plusGreen, width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: r,
        borderSide: BorderSide(color: negative(c)),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: r,
        borderSide: BorderSide(color: negative(c), width: 1.5),
      ),
    );
  }
}

/// White (dark: #18181B) radius-24 card, soft shadow, no border.
class SoftKitCard extends StatelessWidget {
  const SoftKitCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.margin,
    this.onTap,
    this.onLongPress,
    this.radius = SoftKit.radius,
    this.color,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final EdgeInsetsGeometry? margin;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  final double radius;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final br = BorderRadius.circular(radius);
    return Container(
      margin: margin,
      decoration: BoxDecoration(
        color: color ?? SoftKit.card(context),
        borderRadius: br,
        boxShadow: SoftKit.cardShadow(context),
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: br,
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          onLongPress: onLongPress,
          borderRadius: br,
          child: Padding(padding: padding, child: child),
        ),
      ),
    );
  }
}

/// One button for every page: primary = green #047857 / white text,
/// secondary = white (dark: card) / ink text. Pill radius, no outline.
class SoftKitButton extends StatelessWidget {
  const SoftKitButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.primary = true,
    this.icon,
    this.height = 48,
    this.expand = true,
    this.destructive = false,
    this.loading = false,
  });

  const SoftKitButton.secondary({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.height = 48,
    this.expand = true,
    this.destructive = false,
    this.loading = false,
  }) : primary = false;

  final String label;
  final VoidCallback? onPressed;
  final bool primary;
  final IconData? icon;
  final double height;
  final bool expand;
  final bool destructive;
  final bool loading;

  @override
  Widget build(BuildContext context) {
    // One button rule app-wide: gradient primary, outlined secondary.
    if (primary) {
      return SoftGradientButton(
        label: label,
        icon: icon,
        onPressed: onPressed,
        height: height,
        expand: expand,
        loading: loading,
      );
    }
    return SoftOutlineButton(
      label: label,
      icon: icon,
      onPressed: onPressed,
      height: height,
      expand: expand,
      destructive: destructive,
      loading: loading,
    );
  }
}

/// Round 40px card button used in headers (same as Home's bell button).
class SoftKitCircleButton extends StatelessWidget {
  const SoftKitCircleButton({
    super.key,
    required this.icon,
    required this.onPressed,
    this.tooltip,
  });

  final IconData icon;
  final VoidCallback? onPressed;
  final String? tooltip;

  @override
  Widget build(BuildContext context) {
    final btn = Material(
      color: SoftKit.card(context),
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onPressed,
        child: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            boxShadow: SoftKit.cardShadow(context),
          ),
          child: Icon(icon, size: 17, color: SoftKit.ink(context)),
        ),
      ),
    );
    return tooltip == null ? btn : Tooltip(message: tooltip!, child: btn);
  }
}

/// Header row in the Home style: 22/w700 ink title, 12.5 slate subtitle,
/// optional back button and round action buttons on the right.
class SoftKitHeader extends StatelessWidget {
  const SoftKitHeader({
    super.key,
    required this.title,
    this.subtitle,
    this.onBack,
    this.actions = const [],
    this.padding = const EdgeInsets.fromLTRB(16, 8, 16, 8),
  });

  final String title;
  final String? subtitle;
  final VoidCallback? onBack;
  final List<Widget> actions;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: padding,
      child: Row(
        children: [
          if (onBack != null) ...[
            SoftKitCircleButton(
              icon: LucideIcons.chevronLeft,
              tooltip: 'Back',
              onPressed: onBack,
            ),
            const SizedBox(width: 12),
          ],
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: SoftKit.text(
                    context,
                    22,
                    FontWeight.w700,
                    SoftKit.ink(context),
                    letterSpacing: -0.4,
                    height: 1.15,
                  ),
                ),
                if (subtitle != null) ...[
                  const SizedBox(height: 2),
                  Text(
                    subtitle!,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: SoftKit.text(
                      context,
                      12.5,
                      FontWeight.w500,
                      SoftKit.slate(context),
                    ),
                  ),
                ],
              ],
            ),
          ),
          for (final a in actions) ...[const SizedBox(width: 8), a],
        ],
      ),
    );
  }
}

/// Small uppercase section label with an optional count.
class SoftKitSectionLabel extends StatelessWidget {
  const SoftKitSectionLabel(this.title, {super.key, this.count, this.trailing});

  final String title;
  final int? count;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 18, 4, 10),
      child: Row(
        children: [
          Text(
            title.toUpperCase(),
            style: SoftKit.text(
              context,
              11,
              FontWeight.w700,
              SoftKit.slate(context),
              letterSpacing: 1.1,
            ),
          ),
          if (count != null) ...[
            const SizedBox(width: 8),
            Text(
              '$count',
              style: SoftKit.text(context, 11, FontWeight.w700, SoftKit.faint(context)),
            ),
          ],
          const Spacer(),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}

/// Centered empty state: soft tinted icon, title, message, optional action.
class SoftKitEmptyState extends StatelessWidget {
  const SoftKitEmptyState({
    super.key,
    required this.icon,
    required this.title,
    this.message,
    this.action,
  });

  final IconData icon;
  final String title;
  final String? message;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: SoftKit.card(context),
              shape: BoxShape.circle,
              boxShadow: SoftKit.cardShadow(context),
            ),
            child: Icon(icon, size: 26, color: SoftKit.slate(context)),
          ),
          const SizedBox(height: 16),
          Text(
            title,
            textAlign: TextAlign.center,
            style: SoftKit.text(context, 16, FontWeight.w700, SoftKit.ink(context)),
          ),
          if (message != null) ...[
            const SizedBox(height: 6),
            Text(
              message!,
              textAlign: TextAlign.center,
              style: SoftKit.text(context, 13, FontWeight.w500, SoftKit.slate(context)),
            ),
          ],
          if (action != null) ...[const SizedBox(height: 18), action!],
        ],
      ),
    );
  }
}

/// One switch style for the app's soft pages: white thumb, solid #047857
/// track when on, grey track when off, no outline.
class SoftKitSwitch extends StatelessWidget {
  const SoftKitSwitch({super.key, required this.value, required this.onChanged});

  final bool value;
  final ValueChanged<bool>? onChanged;

  @override
  Widget build(BuildContext context) {
    return Switch(
      value: value,
      onChanged: onChanged,
      thumbColor: SoftColors.switchThumb(context),
      trackColor: SoftColors.switchTrack(context),
      trackOutlineColor: const WidgetStatePropertyAll(Colors.transparent),
    );
  }
}

/// Search box in a soft card (no border).
class SoftKitSearchField extends StatelessWidget {
  const SoftKitSearchField({
    super.key,
    this.controller,
    this.onChanged,
    this.hint = 'Search',
  });

  final TextEditingController? controller;
  final ValueChanged<String>? onChanged;
  final String hint;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: SoftKit.card(context),
        borderRadius: BorderRadius.circular(18),
        boxShadow: SoftKit.cardShadow(context),
      ),
      child: TextField(
        controller: controller,
        onChanged: onChanged,
        style: SoftKit.text(context, 14, FontWeight.w600, SoftKit.ink(context)),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: SoftKit.text(context, 14, FontWeight.w500, SoftKit.faint(context)),
          prefixIcon: Icon(LucideIcons.search, size: 18, color: SoftKit.slate(context)),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 14),
        ),
      ),
    );
  }
}

/// Inset divider used between rows inside one card (Activity day-card style).
class SoftKitInsetDivider extends StatelessWidget {
  const SoftKitInsetDivider({super.key, this.indent = 56, this.endIndent = 0});

  final double indent;
  final double endIndent;

  @override
  Widget build(BuildContext context) => Divider(
    height: 1,
    thickness: 1,
    indent: indent,
    endIndent: endIndent,
    color: SoftKit.divider(context),
  );
}

/// Circle avatar with initials (soft emerald tint).
class SoftKitAvatar extends StatelessWidget {
  const SoftKitAvatar({super.key, required this.name, this.size = 44});

  final String name;
  final double size;

  @override
  Widget build(BuildContext context) {
    final parts = name.trim().split(RegExp(r'\s+')).where((p) => p.isNotEmpty).toList();
    final initials =
        parts.isEmpty
            ? '?'
            : (parts.length == 1
                    ? parts.first.substring(0, 1)
                    : '${parts.first[0]}${parts.last[0]}')
                .toUpperCase();
    final dark = SoftKit.dark(context);
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(color: SoftKit.softTint(context), shape: BoxShape.circle),
      alignment: Alignment.center,
      child: Text(
        initials,
        style: SoftKit.text(
          context,
          size * 0.32,
          FontWeight.w700,
          dark ? const Color(0xFF6EE7B7) : SoftPalette.mintDark,
        ),
      ),
    );
  }
}
