import 'package:flutter/material.dart';
import '../theme/spentx_tokens.dart';
import '../theme/soft_palette.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../theme/app_colors.dart';
import '../providers/category_provider.dart';

enum CategoryType { expense, income }

/// A fully self-contained category chip selector.
/// Reads from and writes to the global [categoryProvider].
///
/// Usage:
/// ```dart
/// CategorySelector(
///   type: CategoryType.expense,
///   selected: _selectedCat,
///   onChanged: (cat) => setState(() => _selectedCat = cat),
/// )
/// ```
class CategorySelector extends ConsumerWidget {
  final CategoryType type;
  final String selected;
  final ValueChanged<String> onChanged;

  const CategorySelector({
    super.key,
    required this.type,
    required this.selected,
    required this.onChanged,
  });

  void _showAddDialog(BuildContext context, WidgetRef ref) {
    final controller = TextEditingController();
    String? errorText;

    showDialog(
      context: context,
      builder:
          (ctx) => StatefulBuilder(
            builder: (ctx, setDialogState) {
              return AlertDialog(
                backgroundColor: ctx.softSurface,
                surfaceTintColor: Colors.transparent,
                elevation: 10,
                shadowColor: const Color(0x1A0F172A),
                insetPadding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 24,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(24),
                ),
                titlePadding: const EdgeInsets.fromLTRB(24, 24, 24, 8),
                contentPadding: const EdgeInsets.fromLTRB(24, 0, 24, 8),
                actionsPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                title: Text(
                  type == CategoryType.expense
                      ? 'New Expense Category'
                      : 'New Income Category',
                  style: TextStyle(
                    color: ctx.softInk,
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -0.2,
                  ),
                ),
                content: TextField(
                  controller: controller,
                  autofocus: true,
                  textCapitalization: TextCapitalization.words,
                  style: TextStyle(color: ctx.softInk, fontSize: 15),
                  onChanged: (_) {
                    if (errorText != null)
                      setDialogState(() => errorText = null);
                  },
                  decoration: InputDecoration(
                    hintText: 'Category name',
                    hintStyle: TextStyle(
                      color: ctx.softFaint,
                      fontSize: 15,
                    ),
                    errorText: errorText,
                    errorStyle: const TextStyle(
                      color: SoftPalette.negative,
                      fontSize: 12,
                    ),
                    filled: true,
                    fillColor: ctx.softSurfaceVariant,
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 14,
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: ctx.softBorder),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: ctx.softBorder),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(
                        color: ctx.softEmerald,
                        width: 1.5,
                      ),
                    ),
                    errorBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: const BorderSide(color: SoftPalette.negative),
                    ),
                    focusedErrorBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: const BorderSide(
                        color: SoftPalette.negative,
                        width: 1.5,
                      ),
                    ),
                  ),
                ),
                actions: [
                  TextButton(
                    style: TextButton.styleFrom(
                      foregroundColor: ctx.softMuted,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                      textStyle: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    onPressed: () => Navigator.pop(ctx),
                    child: const Text('Cancel'),
                  ),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: SoftColors.control,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 18,
                        vertical: 12,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                      textStyle: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    onPressed: () {
                      final name = controller.text.trim();
                      if (name.isEmpty) {
                        setDialogState(
                          () => errorText = 'Name cannot be empty',
                        );
                        return;
                      }
                      final cats =
                          type == CategoryType.expense
                              ? ref.read(categoryProvider).expense
                              : ref.read(categoryProvider).income;
                      if (cats.any(
                        (c) => c.toLowerCase() == name.toLowerCase(),
                      )) {
                        setDialogState(
                          () => errorText = 'Category already exists',
                        );
                        return;
                      }
                      if (type == CategoryType.expense) {
                        ref
                            .read(categoryProvider.notifier)
                            .addExpenseCategory(name);
                      } else {
                        ref
                            .read(categoryProvider.notifier)
                            .addIncomeCategory(name);
                      }
                      onChanged(name); // auto-select the new category
                      Navigator.pop(ctx);
                    },
                    child: const Text('Save'),
                  ),
                ],
              );
            },
          ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final catState = ref.watch(categoryProvider);
    final categories =
        type == CategoryType.expense ? catState.expense : catState.income;
    final tint =
        type == CategoryType.expense
            ? AppColors.expenseTint
            : AppColors.incomeTint;
    final onTintColor =
        type == CategoryType.expense
            ? AppColors.onExpenseTint
            : AppColors.onIncomeTint;

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        ...categories.map((cat) {
          final isSelected = selected == cat;
          return GestureDetector(
            onTap: () => onChanged(cat),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
              decoration: BoxDecoration(
                color: isSelected ? tint : (context.tokens.field),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                cat,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: isSelected ? FontWeight.w500 : FontWeight.w400,
                  color:
                      isSelected ? onTintColor : (context.tokens.textSecondary),
                ),
              ),
            ),
          );
        }),
        GestureDetector(
          onTap: () => _showAddDialog(context, ref),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
            decoration: BoxDecoration(
              color: AppColors.primary.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppColors.primary.withValues(alpha: 0.2),
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.add_rounded, size: 14, color: AppColors.primary),
                const SizedBox(width: 5),
                Text(
                  'Add Category',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                    color: AppColors.primary,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

