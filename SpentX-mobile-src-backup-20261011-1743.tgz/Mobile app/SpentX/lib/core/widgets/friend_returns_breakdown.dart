import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../theme/app_colors.dart';
import '../theme/spentx_tokens.dart';

class FriendReturnsBreakdown extends StatelessWidget {
  final List<({String friendName, double amount})> returnedRows;
  final List<({String friendName, double amount})> pendingRows;

  const FriendReturnsBreakdown({
    super.key,
    required this.returnedRows,
    required this.pendingRows,
  });

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final fmt = NumberFormat.currency(
      locale: 'en_IN',
      symbol: '₹',
      decimalDigits: 0,
    );

    return Container(
      margin: const EdgeInsets.only(top: AppSpacing.sm),
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: t.field.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: t.border.withValues(alpha: 0.6),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          for (final ret in returnedRows) ...[
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(
                children: [
                  Container(
                    width: 26,
                    height: 26,
                    decoration: BoxDecoration(
                      color: AppColors.tintBlue.withValues(alpha: 0.15),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      LucideIcons.undo2,
                      size: 13,
                      color: AppColors.tintBlue,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      '${ret.friendName} returned',
                      style: AppType.body(t.textPrimary).copyWith(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  Text(
                    fmt.format(ret.amount),
                    style: AppType.money(AppColors.tintBlue, size: 14),
                  ),
                ],
              ),
            ),
          ],
          for (final pen in pendingRows) ...[
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(
                children: [
                  Container(
                    width: 26,
                    height: 26,
                    decoration: BoxDecoration(
                      color: const Color(0xFFF59E0B).withValues(alpha: 0.15),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      LucideIcons.clock,
                      size: 13,
                      color: Color(0xFFF59E0B),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      '${pen.friendName} pending',
                      style: AppType.body(t.textPrimary).copyWith(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  Text(
                    fmt.format(pen.amount),
                    style: AppType.money(const Color(0xFFF59E0B), size: 14),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}
