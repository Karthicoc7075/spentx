import 'sync_tables.dart';

/// Local-first sync hook shared by every table.
///
/// Wired tables (see [wired]):
///   1. UI reads Hive only. Writes hit Hive first.
///   2. [SyncQueue] appends `{id, table, action, payload, updated_at}`.
///   3. [SyncService.pushPending] sends that outbox in dependency order,
///      then `updated_at` ascending.
///   4. [SyncService] pulls rows whose `updated_at` is newer than [cursorKey].
///   5. [SyncConflict.remoteIsNewer] decides the row. A queued local edit
///      wins until the server clock is strictly newer.
///
/// Soft delete sets `deleted_at` only when [SyncTableSpec.hasDeletedAt].
/// Merchants, plans, and outing categories have no `deleted_at`; those
/// deletes stay hard deletes and are reconciled by the full pull.
///
/// Not delta-wired: child rows that live inside a parent document
/// (`transaction_splits`, `transaction_items`, `outing_expenses`,
/// `settlements`, `friend_settlements`). Their `updated_at` columns are
/// added by migration 20261003 so a later cursor can see them. Wealth
/// snapshots write Supabase directly and are not in this outbox.
class LocalSyncEngine {
  LocalSyncEngine._();

  /// Settings-box cursor shared by every delta-wired table.
  static const cursorKey = 'sync_money_delta_cursor';

  static List<SyncTableSpec> get wired =>
      SyncTables.all.where((t) => t.deltaWired).toList(growable: false);

  static List<SyncTableSpec> get notWired =>
      SyncTables.all.where((t) => !t.deltaWired).toList(growable: false);
}
