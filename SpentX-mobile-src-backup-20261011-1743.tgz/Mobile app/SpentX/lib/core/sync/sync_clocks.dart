import 'package:hive_flutter/hive_flutter.dart';

/// Per-row local `updated_at` clocks, keyed `table::localId` in the settings
/// box. Kept off the transaction/account models so Hive JSON stays compatible.
class SyncClocks {
  SyncClocks._();

  static const storageKey = 'sync_row_clocks';

  static String key(String table, String localId) => '$table::$localId';

  static Map<String, String> _read() {
    if (!Hive.isBoxOpen('settings')) return {};
    final raw = Hive.box('settings').get(storageKey);
    if (raw is! Map) return {};
    return raw.map((k, v) => MapEntry(k.toString(), v.toString()));
  }

  static String? get(String table, String localId) {
    if (localId.isEmpty) return null;
    final map = _read();
    final direct = map[key(table, localId)];
    if (direct != null && direct.isNotEmpty) return direct;
    if (table != 'accounts') return null;
    final target = key(table, localId).toLowerCase();
    for (final entry in map.entries) {
      if (entry.key.toLowerCase() == target && entry.value.isNotEmpty) {
        return entry.value;
      }
    }
    return null;
  }

  static void stamp(String table, String localId, String iso) {
    if (!Hive.isBoxOpen('settings') || localId.isEmpty || iso.isEmpty) return;
    final map = _read();
    map[key(table, localId)] = iso;
    Hive.box('settings').put(storageKey, map);
  }
}
