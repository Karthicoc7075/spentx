/// Read a complete, id-ordered result before allowing callers to reconcile or
/// advance a cursor. Continue until an empty page, even if the server applies a
/// lower row cap than the requested limit. Errors never return a partial list.
Future<List<Map<String, dynamic>>> readAllPages(
  Future<List<Map<String, dynamic>>> Function(String? afterId, int limit) fetch,
) async {
  final rows = <Map<String, dynamic>>[];
  String? afterId;
  while (true) {
    final page = await fetch(afterId, 500);
    if (page.isEmpty) return rows;
    final next = page.last['id']?.toString();
    if (next == null || next.isEmpty || next == afterId) {
      throw StateError('Paginated sync did not advance its record cursor');
    }
    rows.addAll(page);
    afterId = next;
  }
}
