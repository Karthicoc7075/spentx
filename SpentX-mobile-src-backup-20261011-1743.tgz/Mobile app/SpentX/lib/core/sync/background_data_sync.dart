import 'package:hive_flutter/hive_flutter.dart';

import '../services/auth_service.dart';
import 'sync_queue.dart';
import 'sync_service.dart';
import '../../data/local/hive_service.dart';

/// Headless sync when the app UI is closed / backgrounded (WorkManager).
///
/// 1. Push offline queue (new/edited/deleted local → server)
/// 2. Pull + reconcile (~1 month window):
///    - server delete → remove local
///    - server new/update → upsert local
///    - drop local older than window
///
/// Never stores “wrong” stale rows that the server no longer has.
class BackgroundDataSync {
  BackgroundDataSync._();

  static Future<bool> pushPendingIfPossible() async {
    return runFullBackgroundSync();
  }

  static Future<bool> runFullBackgroundSync() async {
    try {
      await Hive.initFlutter();
      await SyncQueue.ensureOpen();

      await AuthService.init();
      if (!AuthService.isSignedIn) return true;

      for (final name in [
        'settings',
        'transactions',
        'outings',
        'friends',
        'merchants_box',
        'merchant_rules_box',
      ]) {
        if (!Hive.isBoxOpen(name)) {
          await SecureHive.openBox(name);
        }
      }

      // Push offline first, then pull reconcile (deletes + window prune).
      await SyncService.fullSync();
      return true;
    } catch (_) {
      return true;
    }
  }
}
