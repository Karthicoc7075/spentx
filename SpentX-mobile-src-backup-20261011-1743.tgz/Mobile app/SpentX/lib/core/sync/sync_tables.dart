/// Supabase tables the phone and the web app already share.
///
/// [entity] strings match [SyncEntity]. [deltaWired] is true only for tables
/// whose pull uses `updated_at` as a cursor inside SyncService. Other tables
/// stay on the existing full pull until a branch is added there.
class SyncTableSpec {
  const SyncTableSpec({
    required this.table,
    required this.entity,
    required this.hasUpdatedAt,
    required this.hasDeletedAt,
    required this.deltaWired,
  });

  final String table;
  final String entity;
  final bool hasUpdatedAt;
  final bool hasDeletedAt;

  /// Incremental `updated_at` pull is implemented for this table.
  final bool deltaWired;
}

class SyncTables {
  SyncTables._();

  static const accounts = SyncTableSpec(
    table: 'accounts',
    entity: 'account',
    hasUpdatedAt: true,
    hasDeletedAt: true,
    deltaWired: true,
  );

  static const transactions = SyncTableSpec(
    table: 'transactions',
    entity: 'transaction',
    hasUpdatedAt: true,
    // deleted_at + is_active: migration 20260736. Push falls back to a hard
    // delete if production has not applied that migration.
    hasDeletedAt: true,
    deltaWired: true,
  );

  static const purposes = SyncTableSpec(
    table: 'purposes',
    entity: 'purpose',
    // updated_at: migration 20261003_sync_cursor_columns.sql (not applied here).
    hasUpdatedAt: true,
    hasDeletedAt: true,
    deltaWired: true,
  );

  static const categories = SyncTableSpec(
    table: 'categories',
    entity: 'category',
    hasUpdatedAt: true,
    hasDeletedAt: true,
    deltaWired: true,
  );

  static const contributors = SyncTableSpec(
    table: 'contributors',
    entity: 'contributor',
    hasUpdatedAt: true,
    hasDeletedAt: true,
    deltaWired: true,
  );

  static const friends = SyncTableSpec(
    table: 'friends',
    entity: 'friend',
    hasUpdatedAt: true,
    hasDeletedAt: true,
    deltaWired: true,
  );

  static const friendDeletes = SyncTableSpec(
    table: 'friends',
    entity: 'friend_delete',
    hasUpdatedAt: true,
    hasDeletedAt: true,
    deltaWired: true,
  );

  static const outings = SyncTableSpec(
    table: 'outings',
    entity: 'outing',
    hasUpdatedAt: true,
    hasDeletedAt: true,
    deltaWired: true,
  );

  static const friendSplits = SyncTableSpec(
    table: 'friend_splits',
    entity: 'friend_split',
    hasUpdatedAt: true,
    hasDeletedAt: true,
    deltaWired: true,
  );

  static const userMerchants = SyncTableSpec(
    table: 'user_merchants',
    entity: 'user_merchant',
    hasUpdatedAt: true,
    hasDeletedAt: false,
    deltaWired: true,
  );

  static const users = SyncTableSpec(
    table: 'users',
    entity: 'user_settings',
    hasUpdatedAt: true,
    hasDeletedAt: false,
    deltaWired: true,
  );

  static const monthlyPlans = SyncTableSpec(
    table: 'monthly_plans',
    entity: 'monthly_plan',
    hasUpdatedAt: true,
    hasDeletedAt: false,
    deltaWired: true,
  );

  static const outingCategories = SyncTableSpec(
    table: 'outing_categories',
    entity: 'outing_category',
    hasUpdatedAt: true,
    hasDeletedAt: false,
    deltaWired: true,
  );

  static const all = <SyncTableSpec>[
    accounts,
    transactions,
    purposes,
    categories,
    contributors,
    friends,
    friendDeletes,
    outings,
    friendSplits,
    userMerchants,
    users,
    monthlyPlans,
    outingCategories,
  ];

  static String? tableForEntity(String entity) {
    for (final spec in all) {
      if (spec.entity == entity) return spec.table;
    }
    return null;
  }

  static SyncTableSpec? specForEntity(String entity) {
    for (final spec in all) {
      if (spec.entity == entity) return spec;
    }
    return null;
  }
}
