import 'dart:async';

import 'package:supabase_flutter/supabase_flutter.dart';

import '../../features/settings/data/purpose_share_service.dart';
import '../services/auth_service.dart';
import 'sync_service.dart';

/// Lightweight security broadcast listener.
///
/// Keeps ONLY the Admin Security Force-Disconnect channel open (`user-status:$uid`).
/// All normal financial synchronization (transactions, accounts, budgets) runs
/// reliably over standard HTTPS via [SyncService] without heavy database CDC sockets.
///
/// If an Admin blocks or deletes this user in the Admin Panel, this channel
/// receives the broadcast kill-signal and immediately kicks the user out of the app.
class RealtimeForegroundSync {
  RealtimeForegroundSync._();

  static RealtimeChannel? _securityChannel;
  static RealtimeChannel? _transactionsChannel;
  static RealtimeChannel? _userSyncChannel;
  static final List<RealtimeChannel> _wealthChannels = [];

  static bool get _active => _securityChannel != null;

  /// Debounce timer for rapid Postgres changes (Section 2: 300-500ms batching)
  static Timer? _debounceTimer;

  /// Starts the security and live transactions sync channel while the app is active in foreground.
  static void start() {
    if (_active || !AuthService.isConfigured || !AuthService.isSignedIn) {
      return;
    }
    final uid = AuthService.currentUserId;
    if (uid == null) return;

    final client = Supabase.instance.client;
    final epoch = DateTime.now().millisecondsSinceEpoch;

    _securityChannel = client
        .channel('user-status:$uid:$epoch')
        .onBroadcast(
          event: 'revoked',
          callback: (payload) async {
            // Admin blocked or deleted this user — force logout immediately
            try {
              await AuthService.signOut(discardUnsyncedChanges: true);
            } catch (_) {}
          },
        )
        .subscribe();

    // Fast broadcast sync channel (direct sub-100ms WebSocket relay from Web)
    _userSyncChannel = client
        .channel('user-sync:$uid')
        .onBroadcast(
          event: 'transaction-changed',
          callback: (payload) {
            final map = payload;
            // Filter self-broadcasts from this mobile device
            if (map['source'] == 'mobile') return;
            final op = map['op']?.toString() ?? '';
            final id = map['id']?.toString() ?? '';

            if (id.isNotEmpty) {
              // Instant targeted single-record sync (<200ms)
              unawaited(SyncService.applySingleTransactionChange(op: op, id: id));
            } else {
              _handleRemoteChange(uid);
            }
          },
        )
        .onBroadcast(
          event: 'outing-changed',
          callback: (payload) {
            final map = payload;
            if (map['source'] == 'mobile') return;
            unawaited(SyncService.syncOutingsLive(uid));
          },
        )
        .onBroadcast(
          event: 'friend-changed',
          callback: (payload) {
            final map = payload;
            if (map['source'] == 'mobile') return;
            unawaited(SyncService.syncFriendsLive(uid));
          },
        )
        .onBroadcast(
          event: 'plan-changed',
          callback: (payload) {
            final map = payload;
            if (map['source'] == 'mobile') return;
            unawaited(SyncService.syncPlansLive(uid));
          },
        )
        .onBroadcast(
          event: 'account-changed',
          callback: (payload) {
            final map = payload;
            if (map['source'] == 'mobile') return;
            unawaited(SyncService.syncAccountsLive(uid));
          },
        )
        .onBroadcast(
          event: 'investment-changed',
          callback: (payload) {
            final map = payload;
            if (map['source'] == 'mobile') return;
            unawaited(SyncService.syncInvestmentsLive(uid));
          },
        )
        .onBroadcast(
          event: 'share-updated',
          callback: (payload) {
            PurposeShareService.notifySharesChanged();
          },
        )
        .subscribe();

    // Listen for transactions & splits in real time while the mobile app is open
    _transactionsChannel = client
        .channel('public:transactions:$uid:$epoch')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'transactions',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'user_id',
            value: uid,
          ),
          callback: (payload) {
            final eventType = payload.eventType;
            final record = payload.newRecord;
            final oldRecord = payload.oldRecord;
            final txId = (record['id'] ?? oldRecord['id'])?.toString() ?? '';

            if (txId.isNotEmpty) {
              if (eventType == PostgresChangeEvent.delete ||
                  record['is_active'] == false ||
                  record['deleted_at'] != null) {
                unawaited(SyncService.applySingleTransactionChange(
                  op: 'delete',
                  id: txId,
                ));
              } else {
                unawaited(SyncService.applySingleTransactionChange(
                  op: eventType == PostgresChangeEvent.insert ? 'insert' : 'update',
                  id: txId,
                  serverRow: record.isNotEmpty ? record : null,
                ));
              }
            } else {
              _handleRemoteChange(uid);
            }
          },
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'transaction_splits',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'user_id',
            value: uid,
          ),
          callback: (payload) {
            final record = payload.newRecord;
            final oldRecord = payload.oldRecord;
            final txId = (record['transaction_id'] ?? oldRecord['transaction_id'])?.toString() ?? '';
            if (txId.isNotEmpty) {
              unawaited(SyncService.applySingleTransactionChange(
                op: 'update',
                id: txId,
              ));
            } else {
              _handleRemoteChange(uid);
            }
          },
        )
        .subscribe();

    // Wealth tables each get their OWN channel. Realtime rejects a whole
    // channel when one table in it is missing (e.g. `investments` before its
    // migration runs), which must never stop live transaction updates.
    for (final table in const ['savings_goals', 'investments', 'projector_settings']) {
      _wealthChannels.add(
        client
            .channel('public:$table:$uid:$epoch')
            .onPostgresChanges(
              event: PostgresChangeEvent.all,
              schema: 'public',
              table: table,
              filter: PostgresChangeFilter(
                type: PostgresChangeFilterType.eq,
                column: 'user_id',
                value: uid,
              ),
              callback: (payload) {
                unawaited(SyncService.syncInvestmentsLive(uid));
              },
            )
            .subscribe(),
      );
    }
  }

  static void _handleRemoteChange(String uid) {
    // Debounce rapid events by 150ms before pulling changes
    _debounceTimer?.cancel();
    _debounceTimer = Timer(const Duration(milliseconds: 150), () {
      unawaited(SyncService.syncTransactionsLive(uid).then((_) {
        // Run fullSync non-blocking in background to catch secondary tables
        unawaited(SyncService.fullSync());
      }));
    });
  }

  /// Tears down the security and transactions channel on pause/background or sign-out.
  static void stop() {
    _debounceTimer?.cancel();
    _debounceTimer = null;
    if (_securityChannel != null) {
      final ch = _securityChannel!;
      _securityChannel = null;
      unawaited(Supabase.instance.client.removeChannel(ch));
    }
    if (_userSyncChannel != null) {
      final ch = _userSyncChannel!;
      _userSyncChannel = null;
      unawaited(Supabase.instance.client.removeChannel(ch));
    }
    if (_transactionsChannel != null) {
      final ch = _transactionsChannel!;
      _transactionsChannel = null;
      unawaited(Supabase.instance.client.removeChannel(ch));
    }
    for (final ch in List<RealtimeChannel>.from(_wealthChannels)) {
      unawaited(Supabase.instance.client.removeChannel(ch));
    }
    _wealthChannels.clear();
  }
}

