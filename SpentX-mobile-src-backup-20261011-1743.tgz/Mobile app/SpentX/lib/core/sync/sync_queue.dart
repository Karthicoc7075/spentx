import 'package:hive_flutter/hive_flutter.dart';

import 'sync_clocks.dart';
import 'sync_tables.dart';
import '../../data/local/hive_service.dart';

/// Logical entity kinds the sync queue understands.
class SyncEntity {
  SyncEntity._();
  static const transaction = 'transaction';
  static const account = 'account';
  static const purpose = 'purpose';
  static const outing = 'outing';
  static const friend = 'friend';
  static const friendDelete = 'friend_delete';
  static const userSettings = 'user_settings';
  /// Per-user verified SMS merchant (auto-add after first verify).
  static const userMerchant = 'user_merchant';
  static const contributor = 'contributor';
  static const category = 'category';
  static const monthlyPlan = 'monthly_plan';
  /// User outing type picker (Trip / Other / custom).
  static const outingCategory = 'outing_category';
  /// A one-off shared expense between friends — standalone, never an outing.
  static const friendSplit = 'friend_split';
}

class SyncOp {
  SyncOp._();
  static const upsert = 'upsert';
  static const delete = 'delete';
}

/// Hive-backed queue of pending local writes headed for Supabase.
/// Local-first: every user-data write lands in Hive instantly, then an entry
/// is appended here; SyncService drains it when online. Entries survive app
/// restarts. Admin rule tables NEVER go through this queue (pull-only).
class SyncQueue {
  SyncQueue._();

  static const boxName = 'sync_queue';
  static const _key = 'items';

  static Future<void> ensureOpen() async {
    if (!Hive.isBoxOpen(boxName)) {
      await SecureHive.openBox(boxName);
    }
  }

  static Box get _box => Hive.box(boxName);

  static List<Map<String, dynamic>> items() {
    if (!Hive.isBoxOpen(boxName)) return [];
    final raw = _box.get(_key, defaultValue: const <dynamic>[]) as List;
    return raw
        .whereType<Map>()
        .map((e) => Map<String, dynamic>.from(e))
        .toList();
  }

  static void _write(List<Map<String, dynamic>> list) {
    if (!Hive.isBoxOpen(boxName)) return;
    _box.put(_key, list);
  }


  /// Outbox row. Same entity+localId coalesces to the newest write.
  ///
  /// Stored fields: `id`, `table`, `action` (alias of `op`), `payload`,
  /// `updated_at`. `entity`, `op`, `localId`, and `at` stay so existing
  /// push code keeps working.
  static Map<String, dynamic> buildEntry({
    required String entity,
    required String op,
    required String localId,
    Map<String, dynamic>? payload,
    String? table,
    String? updatedAt,
  }) {
    final at = (updatedAt == null || updatedAt.isEmpty)
        ? DateTime.now().toUtc().toIso8601String()
        : updatedAt;
    final resolvedTable = (table == null || table.isEmpty)
        ? SyncTables.tableForEntity(entity)
        : table;
    final storedPayload = payload == null
        ? null
        : Map<String, dynamic>.from(payload);
    if (storedPayload != null) {
      storedPayload.putIfAbsent('updatedAt', () => at);
    }
    return {
      'id': DateTime.now().microsecondsSinceEpoch.toString(),
      'entity': entity,
      'op': op,
      'action': op,
      'localId': localId,
      if (resolvedTable != null) 'table': resolvedTable,
      if (storedPayload != null) 'payload': storedPayload,
      'at': at,
      'updated_at': at,
      'attempts': 0,
    };
  }

  static void recordAttempt(String queueEntryId) {
    if (!Hive.isBoxOpen(boxName)) return;
    final list = items();
    final idx = list.indexWhere((e) => e['id']?.toString() == queueEntryId);
    if (idx >= 0) {
      final currentAttempts = (list[idx]['attempts'] as num?)?.toInt() ?? 0;
      list[idx]['attempts'] = currentAttempts + 1;
      _write(list);
    }
  }

  /// Enqueues an operation. For upserts of the same entity+localId, the
  /// newest payload replaces the older queued one (last write wins locally).
  /// A delete supersedes any queued upsert for the same record.
  static void enqueue({
    required String entity,
    required String op,
    required String localId,
    Map<String, dynamic>? payload,
    String? table,
    String? updatedAt,
  }) {
    if (!Hive.isBoxOpen(boxName)) return;
    final list = items();
    list.removeWhere((e) => e['entity'] == entity && e['localId'] == localId);
    final entry = buildEntry(
      entity: entity,
      op: op,
      localId: localId,
      payload: payload,
      table: table,
      updatedAt: updatedAt,
    );
    list.add(entry);
    _write(list);
    final resolvedTable = entry['table']?.toString();
    final stamped = entry['updated_at']?.toString();
    if (resolvedTable != null && stamped != null) {
      SyncClocks.stamp(resolvedTable, localId, stamped);
    }
  }

  /// Drops every queued op for this row (remote edit won the conflict).
  static void drop(String entity, String localId) {
    if (!Hive.isBoxOpen(boxName) || localId.isEmpty) return;
    final list = items()..removeWhere((e) {
      if (e['entity'] != entity) return false;
      final queued = e['localId']?.toString() ?? '';
      if (queued == localId) return true;
      if (entity == SyncEntity.account &&
          queued.toLowerCase() == localId.toLowerCase()) {
        return true;
      }
      return false;
    });
    _write(list);
  }

  /// Queue localId for a pending op, matching local or remote id.
  static String? pendingLocalId(
    String entity, {
    String? localId,
    String? remoteId,
  }) {
    for (final e in items()) {
      if (e['entity'] != entity) continue;
      final queued = e['localId']?.toString() ?? '';
      if (localId != null && localId.isNotEmpty && queued == localId) {
        return queued;
      }
      final payload = e['payload'] is Map
          ? Map<String, dynamic>.from(e['payload'] as Map)
          : const <String, dynamic>{};
      final queuedRemote = payload['remoteId']?.toString() ?? '';
      if (remoteId != null &&
          remoteId.isNotEmpty &&
          (queuedRemote == remoteId || queued == remoteId)) {
        return queued;
      }
    }
    return null;
  }

  static void remove(String queueEntryId) {
    final list = items()..removeWhere((e) => e['id'] == queueEntryId);
    _write(list);
  }

  /// True when a local record has a pending (not-yet-pushed) op — pull merges
  /// must not overwrite such records with remote state.
  static bool hasPending(String entity, String localId) {
    return items()
        .any((e) => e['entity'] == entity && e['localId'] == localId);
  }

  static bool hasPendingOp(String entity, String localId, String op) {
    return items().any(
      (e) =>
          e['entity'] == entity &&
          e['localId'] == localId &&
          e['op']?.toString() == op,
    );
  }

  /// Pending offline delete for this entity (by localId or remoteId in payload).
  static bool hasPendingDelete(
    String entity, {
    String? localId,
    String? remoteId,
  }) {
    for (final e in items()) {
      if (e['entity'] != entity) continue;
      if (e['op']?.toString() != SyncOp.delete) continue;
      final qLocal = e['localId']?.toString() ?? '';
      if (localId != null && localId.isNotEmpty && qLocal == localId) {
        return true;
      }
      final payload = e['payload'] is Map
          ? Map<String, dynamic>.from(e['payload'] as Map)
          : const <String, dynamic>{};
      final qRemote = payload['remoteId']?.toString() ?? '';
      if (remoteId != null &&
          remoteId.isNotEmpty &&
          (qRemote == remoteId || qLocal == remoteId)) {
        return true;
      }
    }
    return false;
  }

  static bool get isEmpty => items().isEmpty;
  static int get length => items().length;
}
