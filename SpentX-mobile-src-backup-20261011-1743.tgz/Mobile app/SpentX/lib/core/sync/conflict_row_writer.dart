import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// What to do with one queued local row once the server copy is known.
enum ConflictDecision { insert, update, skip }

/// Writes one outbox row to a Supabase table that has `id`, `user_id`,
/// `updated_at` (server-touched) and `deleted_at` (soft delete) columns.
///
/// Rules (shared by savings goals and investments):
///  * Deletes are soft deletes (`deletePatch`), never `DELETE`.
///  * A row already deleted on the server is never resurrected by an older
///    local edit — the deletion wins and the edit is dropped.
///  * Each local edit remembers the server `updated_at` it started from
///    ([baseKey]) and when it was made ([editedKey]). If the server row was
///    changed since, the newer of the two edits wins.
class ConflictRowWriter {
  ConflictRowWriter._();

  /// Server `updated_at` the local edit was based on (null for new rows).
  static const baseKey = '_base_updated_at';

  /// UTC time the local edit was made.
  static const editedKey = '_edited_at';

  /// Local-only bookkeeping keys start with `_` and are never uploaded.
  static Map<String, dynamic> stripLocal(Map<String, dynamic> row) => {
    for (final e in row.entries)
      if (!e.key.startsWith('_')) e.key: e.value,
  };

  /// Adds edit bookkeeping to a row about to be staged.
  static Map<String, dynamic> stampEdit(
    Map<String, dynamic> row, {
    String? baseUpdatedAt,
    DateTime? now,
  }) => {
    ...row,
    baseKey: baseUpdatedAt,
    // Server-clock time, so a phone whose clock is wrong cannot make an old
    // edit look newer (or a new edit look older) than the server row.
    editedKey: (now ?? ServerClock.now()).toUtc().toIso8601String(),
  };

  static DateTime? _parse(Object? v) =>
      v == null ? null : DateTime.tryParse(v.toString())?.toUtc();

  /// Pure decision so it can be unit tested without a network.
  static ConflictDecision decide({
    required Map<String, dynamic>? server,
    required Map<String, dynamic> local,
  }) {
    if (server == null) return ConflictDecision.insert;
    if (server['deleted_at'] != null) return ConflictDecision.skip;
    final serverUpdated = _parse(server['updated_at']);
    final base = _parse(local[baseKey]);
    if (base == null || serverUpdated == null) return ConflictDecision.update;
    if (serverUpdated.microsecondsSinceEpoch == base.microsecondsSinceEpoch) {
      return ConflictDecision.update;
    }
    final edited = _parse(local[editedKey]);
    if (edited != null && serverUpdated.isAfter(edited)) {
      return ConflictDecision.skip;
    }
    return ConflictDecision.update;
  }

  /// [payload] builds the columns to send; `isInsert` lets callers include
  /// insert-only columns (e.g. an initial saved amount).
  static Future<ConflictDecision> write(
    SupabaseClient db, {
    required String table,
    required String uid,
    required String id,
    required Map<String, dynamic>? row,
    required Map<String, dynamic> deletePatch,
    required Map<String, dynamic> Function(Map<String, dynamic> row, bool isInsert)
    payload,
  }) async {
    final server = await db
        .from(table)
        .select('id, updated_at, deleted_at')
        .eq('user_id', uid)
        .eq('id', id)
        .maybeSingle();
    if (row == null) {
      if (server == null || server['deleted_at'] != null) {
        return ConflictDecision.skip;
      }
      await db.from(table).update(deletePatch).eq('user_id', uid).eq('id', id);
      return ConflictDecision.update;
    }
    final decision = decide(server: server, local: row);
    switch (decision) {
      case ConflictDecision.insert:
        final sentAt = DateTime.now();
        final inserted = await db.from(table).insert({
          ...payload(row, true),
          'id': id,
          'user_id': uid,
        }).select('updated_at').maybeSingle();
        ServerClock.learn(inserted?['updated_at'], sentAt, DateTime.now());
        break;
      case ConflictDecision.update:
        final values = Map<String, dynamic>.from(payload(row, false))
          ..remove('id')
          ..remove('user_id')
          ..remove('created_at');
        final sentAt = DateTime.now();
        final updated = await db
            .from(table)
            .update(values)
            .eq('user_id', uid)
            .eq('id', id)
            .select('updated_at')
            .maybeSingle();
        ServerClock.learn(updated?['updated_at'], sentAt, DateTime.now());
        break;
      case ConflictDecision.skip:
        break;
    }
    return decision;
  }
}

/// Estimated offset between this phone's clock and the database clock,
/// learnt from the server `updated_at` returned by our own writes (the
/// server sets it to its `now()`). Persisted so it survives restarts.
class ServerClock {
  ServerClock._();

  static const _key = 'server_clock_skew_ms';
  static int? _skewMs;

  static int get skewMs {
    final cached = _skewMs;
    if (cached != null) return cached;
    if (!Hive.isBoxOpen('settings')) return 0;
    final raw = Hive.box('settings').get(_key);
    return _skewMs = raw is int ? raw : 0;
  }

  /// Current time on the server's clock (best estimate).
  static DateTime now() =>
      DateTime.now().toUtc().add(Duration(milliseconds: skewMs));

  static void learn(Object? serverUpdatedAt, DateTime sentAt, DateTime receivedAt) {
    final server = serverUpdatedAt == null
        ? null
        : DateTime.tryParse(serverUpdatedAt.toString())?.toUtc();
    if (server == null) return;
    final roundTrip = receivedAt.difference(sentAt).inMilliseconds;
    if (roundTrip < 0 || roundTrip > 5000) return; // too noisy to trust
    final mid = sentAt.toUtc().add(Duration(milliseconds: roundTrip ~/ 2));
    final skew = server.difference(mid).inMilliseconds;
    // Under ~2 s is just network jitter.
    final next = skew.abs() < 2000 ? 0 : skew;
    _skewMs = next;
    if (Hive.isBoxOpen('settings')) {
      Hive.box('settings').put(_key, next);
    }
  }

  @visibleForTesting
  static void resetForTest([int? skewMs]) => _skewMs = skewMs;
}
