import 'package:hive_flutter/hive_flutter.dart';
import 'package:uuid/uuid.dart';

/// ─────────────────────────────────────────────────────────────────────────
/// SCHEMA MAP — built against the REAL web schema
/// (docs/DATABASE_SCHEMA.md + supabase/migrations/init.sql in the web repo).
///
/// Key structural facts honored here:
///  • transactions: `total_amount`, `type` ('income'|'expense'),
///    `payment_method`, `account_id` (uuid FK → accounts), `entry_source`,
///    `month_key`; NO purpose/category columns — money math lives on
///    `transaction_splits` (purpose_id uuid FK, category_id = NAME text).
///  • accounts: `type` lowercase ('bank'|'cash'|...), `last4`,
///    `opening_balance`, soft-delete via `is_active`.
///  • purposes: uuid rows; mobile purpose strings resolve by NAME.
///  • outings: `status` ('active'|'completed'), `auto_add_mode`, `type`,
///    members jsonb objects ({id,name,upiId,isCurrentUser}); `is_active` is
///    SOFT DELETE, not "trip is running".
///  • outing_expenses: `description`, `category_id`, `expense_date`,
///    `split_type` TEXT, `splits` jsonb, `linked_transaction_id`.
///  • settlements: outing-level from/to member rows (`settled_date`,
///    `is_partial`); mobile's per-expense payments carry the expense id in
///    `note` ("exp:&lt;id&gt;") so they round-trip.
///  • users: `private_mode`, `default_account_id` (uuid).
///  • sms rule tables: flat snake_case columns → converted to the camelCase
///    maps the local engines expect; rows with is_active=false are skipped.
/// ─────────────────────────────────────────────────────────────────────────
class SupaTables {
  SupaTables._();
  static const transactions = 'transactions';
  static const transactionSplits = 'transaction_splits';
  static const transactionItems = 'transaction_items';
  static const accounts = 'accounts';
  static const purposes = 'purposes';
  static const outings = 'outings';
  static const outingExpenses = 'outing_expenses';
  static const outingCategories = 'outing_categories';
  static const settlements = 'settlements';
  static const friendSplits = 'friend_splits';
  static const friendSettlements = 'friend_settlements';
  static const friends = 'friends';
  static const users = 'users';
  static const smsTemplateRules = 'sms_template_rules';
  static const smsDetectionRules = 'sms_detection_rules';
  static const smsBlockRules = 'sms_block_rules';

  /// Per-user verified SMS merchants (auto-add after first verify).
  static const userMerchants = 'user_merchants';
  static const contributors = 'contributors';
  static const categories = 'categories';
  static const globalSettings = 'global_settings';
  static const monthlyPlans = 'monthly_plans';

  /// Daily Snapshot (Wealth History) feature.
  static const netWorthHistory = 'net_worth_history';
  static const accountBalanceHistory = 'account_balance_history';
}

/// Deterministic remote-id helpers — uid-scoped: idempotent across devices,
/// collision-safe across users.
class SyncIds {
  SyncIds._();
  static const _uuid = Uuid();
  static final _uuidRe = RegExp(
    r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$',
  );

  static bool isUuid(String v) => _uuidRe.hasMatch(v);

  static String forTransaction(String uid, String localId) =>
      isUuid(localId)
          ? localId
          : _uuid.v5(Namespace.url.value, 'spentx:$uid:tx:$localId');

  static String forSplit(String uid, String remoteTxId) =>
      _uuid.v5(Namespace.url.value, 'spentx:$uid:split:$remoteTxId');

  /// One id per row of a real multi-row Split Expense — distinct from
  /// [forSplit] (the single-split id, kept stable for existing data) so a
  /// transaction never collides between its old single-row id and a new
  /// multi-row id at the same index.
  static String forSplitRow(String uid, String remoteTxId, int index) =>
      _uuid.v5(Namespace.url.value, 'spentx:$uid:splitrow:$remoteTxId:$index');

  /// One id per purchased line item row — independent of [forSplitRow].
  static String forItemRow(String uid, String remoteTxId, int index) =>
      _uuid.v5(Namespace.url.value, 'spentx:$uid:itemrow:$remoteTxId:$index');

  static String forFriend(String uid, String name) => _uuid.v5(
    Namespace.url.value,
    'spentx:$uid:friend:${name.trim().toLowerCase()}',
  );

  static String forAccount(String uid, String name) => _uuid.v5(
    Namespace.url.value,
    'spentx:$uid:acc:${name.trim().toLowerCase()}',
  );

  static String forPurpose(String uid, String name) => _uuid.v5(
    Namespace.url.value,
    'spentx:$uid:purpose:${name.trim().toLowerCase()}',
  );

  static String forExpense(String uid, String localId) =>
      isUuid(localId)
          ? localId
          : _uuid.v5(Namespace.url.value, 'spentx:$uid:exp:$localId');

  static String forFriendSplit(String uid, String localId) =>
      isUuid(localId)
          ? localId
          : _uuid.v5(Namespace.url.value, 'spentx:$uid:friendsplit:$localId');

  static String forFriendSettlement(String uid, String localId) =>
      isUuid(localId)
          ? localId
          : _uuid.v5(Namespace.url.value, 'spentx:$uid:friendsettle:$localId');

  static String forSettlement(
    String uid,
    String expenseId,
    String memberId,
    int index,
  ) => _uuid.v5(
    Namespace.url.value,
    'spentx:$uid:settle:$expenseId:$memberId:$index',
  );

  /// Deterministic id from normalized payee so reinstall/upsert is stable.
  static String forMerchant(String uid, String normalizedPayee) => _uuid.v5(
    Namespace.url.value,
    'spentx:$uid:merchant:${normalizedPayee.trim().toLowerCase()}',
  );

  static String forContributor(String uid, String name) => _uuid.v5(
    Namespace.url.value,
    'spentx:$uid:contributor:${name.trim().toLowerCase()}',
  );

  static String forCategory(String uid, String name, String type) => _uuid.v5(
    Namespace.url.value,
    'spentx:$uid:cat:${type.trim().toLowerCase()}:${name.trim().toLowerCase()}',
  );

  static String forPlan(String uid, String month, String purposeName) =>
      _uuid.v5(
        Namespace.url.value,
        'spentx:$uid:plan:$month:${purposeName.trim().toLowerCase()}',
      );

  /// One row per user/day — deterministic so a same-day upsert never
  /// creates a duplicate, with no "does today exist yet" round trip needed.
  static String forNetWorthSnapshot(String uid, String date) =>
      _uuid.v5(Namespace.url.value, 'spentx:$uid:networth:$date');

  /// One row per account/day.
  static String forAccountSnapshot(
    String uid,
    String remoteAccountId,
    String date,
  ) => _uuid.v5(
    Namespace.url.value,
    'spentx:$uid:balhist:$remoteAccountId:$date',
  );
}

/// net_worth_history — Daily Snapshot feature. One row per user/day.
class NetWorthHistoryMap {
  NetWorthHistoryMap._();
  static const id = 'id';
  static const userId = 'user_id';
  static const date = 'snapshot_date';
  static const cashBalance = 'cash_balance';
  static const bankBalance = 'bank_balance';
  static const walletBalance = 'wallet_balance';
  static const investmentValue = 'investment_value';
  static const netWorth = 'net_worth';

  static Map<String, dynamic> toRemote(
    String uid,
    String date, {
    required double cash,
    required double bank,
    required double wallet,
    required double investment,
    required double total,
  }) => {
    id: SyncIds.forNetWorthSnapshot(uid, date),
    userId: uid,
    date: date,
    cashBalance: cash,
    bankBalance: bank,
    walletBalance: wallet,
    investmentValue: investment,
    netWorth: total,
  };

  static Map<String, dynamic> toLocal(Map<String, dynamic> row) => {
    'id': row[id]?.toString(),
    'date': row[date]?.toString() ?? '',
    'cashBalance': (row[cashBalance] as num? ?? 0).toDouble(),
    'bankBalance': (row[bankBalance] as num? ?? 0).toDouble(),
    'walletBalance': (row[walletBalance] as num? ?? 0).toDouble(),
    'investmentValue': (row[investmentValue] as num? ?? 0).toDouble(),
    'netWorth': (row[netWorth] as num? ?? 0).toDouble(),
  };
}

/// account_balance_history — one row per account/day, independent of
/// net_worth_history so a per-account trend/comparison can be shown.
class AccountBalanceHistoryMap {
  AccountBalanceHistoryMap._();
  static const id = 'id';
  static const userId = 'user_id';
  static const accountId = 'account_id';
  static const balance = 'balance';
  static const date = 'snapshot_date';
  static const monthKey = 'month_key';

  static Map<String, dynamic> toRemote(
    String uid,
    String remoteAccountId,
    String date,
    double balanceValue,
  ) => {
    id: SyncIds.forAccountSnapshot(uid, remoteAccountId, date),
    userId: uid,
    accountId: remoteAccountId,
    balance: balanceValue,
    date: date,
    monthKey: date.substring(0, 7),
  };

  static Map<String, dynamic> toLocal(Map<String, dynamic> row) => {
    'id': row[id]?.toString(),
    'accountId': row[accountId]?.toString() ?? '',
    'balance': (row[balance] as num? ?? 0).toDouble(),
    'date': row[date]?.toString() ?? '',
  };
}

/// Name→remote-uuid resolution caches for accounts and purposes.
/// Populated by the pull (authoritative web rows win); extended on push when
/// the mobile app creates a name the server doesn't have yet.
class RemoteIdCache {
  RemoteIdCache._();
  static const accountsKey = 'remote_account_ids';
  static const purposesKey = 'remote_purpose_ids';
  static const contributorsKey = 'remote_contributor_ids';

  static final Map<String, Map<String, String>> _memFallback = {};

  static Map<String, String> _read(String key) {
    if (!Hive.isBoxOpen('settings')) return _memFallback[key] ?? {};
    final raw = Hive.box('settings').get(key);
    if (raw is! Map) return _memFallback[key] ?? {};
    final map = raw.map((k, v) => MapEntry(k.toString(), v.toString()));
    _memFallback[key] = map;
    return map;
  }

  static void _write(String key, Map<String, String> map) {
    _memFallback[key] = Map.from(map);
    if (Hive.isBoxOpen('settings')) Hive.box('settings').put(key, map);
  }

  static String? accountId(String name) =>
      _read(accountsKey)[name.trim().toLowerCase()];
  static String? purposeId(String name) =>
      _read(purposesKey)[name.trim().toLowerCase()];
  static String? contributorId(String name) =>
      _read(contributorsKey)[name.trim().toLowerCase()];

  static String? accountName(String id) {
    for (final e in _read(accountsKey).entries) {
      if (e.value == id) return e.key;
    }
    return null;
  }

  static final _uuidRegex = RegExp(
    r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$',
  );

  static String? purposeName(String id) {
    final trimmed = id.trim();
    if (trimmed.isEmpty) return null;
    final map = _read(purposesKey);
    for (final e in map.entries) {
      if (e.key.toLowerCase() == trimmed.toLowerCase()) return e.key;
    }
    for (final e in map.entries) {
      if (e.value.toLowerCase() == trimmed.toLowerCase()) return e.key;
    }
    if (!_uuidRegex.hasMatch(trimmed)) {
      return trimmed;
    }
    return null;
  }

  static String? contributorName(String id) {
    if (id.isEmpty) return null;
    for (final e in _read(contributorsKey).entries) {
      if (e.value == id) return e.key;
    }
    return null;
  }

  static void putAccount(String name, String id) {
    final m = _read(accountsKey);
    m[name.trim().toLowerCase()] = id;
    _write(accountsKey, m);
  }

  static void putPurpose(String name, String id) {
    final m = _read(purposesKey);
    m[name.trim().toLowerCase()] = id;
    _write(purposesKey, m);
  }

  static void putContributor(String name, String id) {
    final m = _read(contributorsKey);
    m[name.trim().toLowerCase()] = id;
    _write(contributorsKey, m);
  }

  static void replaceAccounts(Map<String, String> byLowerName) =>
      _write(accountsKey, byLowerName);
  static void replacePurposes(Map<String, String> byLowerName) =>
      _write(purposesKey, byLowerName);
  static void replaceContributors(Map<String, String> byLowerName) =>
      _write(contributorsKey, byLowerName);
}

/// contributors table map.
class ContributorMap {
  ContributorMap._();
  static const id = 'id';
  static const userId = 'user_id';
  static const name = 'name';
  static const isDefault = 'is_default';
  static const canDelete = 'can_delete';
  static const isActive = 'is_active';

  static Map<String, dynamic> toRemote(Map<String, dynamic> local, String uid) {
    final remoteId =
        SyncIds.isUuid(local['id']?.toString() ?? '')
            ? local['id'].toString()
            : SyncIds.forContributor(uid, (local['name'] ?? '').toString());
    return {
      id: remoteId,
      userId: uid,
      name: local['name'] ?? 'Me',
      isDefault: local['isDefault'] == true,
      canDelete: local['canDelete'] != false,
      isActive: local['isActive'] != false,
    };
  }

  static Map<String, dynamic> toLocal(Map<String, dynamic> row) {
    return {
      'id': row[id]?.toString() ?? '',
      'name': row[name] ?? 'Me',
      'isDefault': row[isDefault] == true,
      'canDelete': row[canDelete] != false,
      'isActive': row[isActive] != false,
    };
  }
}

/// categories table map (user custom).
class CategoryMap {
  CategoryMap._();
  static const id = 'id';
  static const userId = 'user_id';
  static const name = 'name';
  static const type = 'type';
  static const color = 'color';
  static const icon = 'icon';
  static const isActive = 'is_active';
  static const canDelete = 'can_delete';

  static Map<String, dynamic> toRemote(
    String uid, {
    required String name,
    required String type,
    String? id,
  }) {
    final remoteId =
        (id != null && SyncIds.isUuid(id))
            ? id
            : SyncIds.forCategory(uid, name, type);
    return {
      CategoryMap.id: remoteId,
      userId: uid,
      CategoryMap.name: name,
      CategoryMap.type: type,
      color: type == 'income' ? '#10b981' : '#f97316',
      icon: 'tag',
      isActive: true,
      canDelete: true,
    };
  }
}

/// transactions + transaction_splits.
class TransactionMap {
  TransactionMap._();
  static const id = 'id';
  static const userId = 'user_id';
  static const accountId = 'account_id';
  static const merchant = 'merchant';
  static const totalAmount = 'total_amount';
  static const type = 'type'; // income | expense
  static const paymentMethod = 'payment_method';
  static const source = 'source'; // manual | mobile | bank-sync | import
  static const entrySource =
      'entry_source'; // manual | mobile-manual | sms-auto-detected
  static const date = 'transaction_date';
  static const monthKey = 'month_key';
  static const description = 'description';
  static const note = 'note';

  /// Single custom display title (migration 20260749) — independent of
  /// Split Expense, purely descriptive.
  static const title = 'title';
  static const hasItems = 'has_items';
  static const reference = 'reference';
  static const referenceId = 'reference_id';

  /// First-class merchant identifier columns (migration 20260733).
  static const upi = 'upi';
  static const rawIdentifier = 'raw_identifier';
  static const status = 'status';
  static const hasSplits = 'has_splits';
  static const tags = 'tags';
  static const outingId = 'outing_id';

  /// New-style single-row transfer columns (migration 20260755). Null on
  /// expense/income rows and on legacy tag-encoded transfers.
  static const toAccountId = 'to_account_id';
  static const transferType =
      'transfer_type'; // bank_to_bank | bank_to_cash | cash_to_bank
  /// Soft-delete flag (migration 20260736) — false when hidden by an outing
  /// cascade delete, restorable via the restore_deleted_outing RPC.
  static const isActive = 'is_active';

  /// India (UTC+05:30, no DST) calendar month of the transaction, the same
  /// rule as the website and public.spentx_ist_month_key(): 00:30 IST on the
  /// 1st belongs to the new month, not the old one.
  static String monthKeyFor(String isoDate) {
    final utc = DateTime.tryParse(isoDate)?.toUtc() ?? DateTime.now().toUtc();
    final d = utc.add(const Duration(hours: 5, minutes: 30));
    return '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}';
  }

  static bool _looksLikeOutingRollup(Map<String, dynamic> local) {
    final note = (local['note'] ?? '').toString().trim().toLowerCase();
    if (note.startsWith('outing total')) return true;
    if (note.startsWith('your share of ')) return true;
    final tags = local['tags'];
    if (tags is List &&
        tags.map((e) => e.toString()).contains('outing-rollup')) {
      return true;
    }
    return false;
  }

  static bool _looksLikeTransfer(Map<String, dynamic> local) {
    if (local['isTransfer'] == true) return true;
    final cat = (local['category'] ?? '').toString().trim().toLowerCase();
    if (cat == 'transfer' || cat == 'settlements') return true;
    final merchant = (local['merchant'] ?? '').toString().trim().toLowerCase();
    if (merchant.startsWith('transfer to ') ||
        merchant.startsWith('transfer from ') ||
        (merchant.startsWith('tr ') && merchant.contains(' to '))) {
      return true;
    }
    return false;
  }

  /// Local Hive json → remote transactions row.
  /// [remoteAccountId] must be resolved (name → uuid) by the caller.
  /// Web has no transfer concept — transfer legs carry `transfer` tags so
  /// they round-trip and can be excluded from web analytics by tag.
  /// Prefer stored [remoteId] (after first sync) so offline update/delete hit
  /// the same Supabase row as the original push.
  static String remoteTransactionId(Map<String, dynamic> local, String uid) {
    final remote = local['remoteId']?.toString().trim() ?? '';
    if (remote.isNotEmpty) return remote;
    return SyncIds.forTransaction(uid, local['id'].toString());
  }

  static Map<String, dynamic> toRemote(
    Map<String, dynamic> local,
    String uid,
    String remoteAccountId, {

    /// Resolved destination account id — required for a new-style transfer
    /// (local['transferType'] != null), unused otherwise.
    String? remoteToAccountId,
  }) {
    final remoteTxId = remoteTransactionId(local, uid);
    final isExpense = local['isExpense'] ?? true;
    final isTransfer = _looksLikeTransfer(local);
    final isRollup = _looksLikeOutingRollup(local);
    // New-style single-row transfer: real type/to_account_id/transfer_type
    // columns replace the legacy tag-encoding entirely for this row.
    final newTransferType = local['transferType']?.toString();
    final isNewTransfer = newTransferType != null && newTransferType.isNotEmpty;
    final dateIso =
        local['date']?.toString() ?? DateTime.now().toIso8601String();
    final existingTags = <String>[
      if (local['tags'] is List)
        ...(local['tags'] as List).map((e) => e.toString()),
    ];
    final isGroup =
        (local['isGroup'] == true) ||
        ((local['groupCount'] as num? ?? 0) > 0) ||
        existingTags.contains('friend_split');
    final groupCount = (local['groupCount'] as num? ?? 0).toInt();

    final tagSet = <String>{
      ...existingTags,
      if (isGroup) 'friend_split',
      if (isGroup && groupCount > 0) 'group_count:$groupCount',
      // Legacy tag-encoding only — a new-style transfer uses the real
      // type='transfer'/to_account_id/transfer_type columns instead, so no
      // client needs to sniff tags for it going forward.
      if (isTransfer && !isNewTransfer) 'transfer',
      if (isTransfer &&
          !isNewTransfer &&
          (local['transferTo'] ?? '').toString().trim().isNotEmpty)
        'transfer_to:${local['transferTo']}',
      if (isRollup) 'outing-rollup',
      if ((local['bankName'] ?? '').toString().isNotEmpty)
        'bank:${local['bankName']}',
      if ((local['accountLast4'] ?? '').toString().isNotEmpty)
        'last4:${local['accountLast4']}',
      if ((local['upiId'] ?? '').toString().isNotEmpty) 'upi:${local['upiId']}',
    };
    // Prefer local status when set (do not force completed over pending).
    final statusRaw = (local['status'] ?? 'completed').toString().trim();
    final statusSafe =
        const {'completed', 'pending', 'failed', 'refunded'}.contains(statusRaw)
            ? statusRaw
            : 'completed';
    final payRaw =
        (local['paymentType'] ?? local['paymentMethod'] ?? 'Online').toString();
    final paymentMethodOut = payRaw.toLowerCase() == 'cash' ? 'Cash' : 'UPI';
    // Merchant identifier: separate genuine UPI ID, raw identifier, and reference ID.
    final upiCandidate = (local['upiId'] ?? '').toString().trim();
    final rawCandidate = (local['rawIdentifier'] ?? '').toString().trim();
    final refCandidate =
        (local['referenceId'] ?? local['reference'] ?? '').toString().trim();

    // Only assign genuine UPI address to upi column (not bank UTRs or reference numbers).
    final realUpi = upiCandidate.isNotEmpty
        ? upiCandidate
        : (rawCandidate.contains('@') ? rawCandidate : null);

    final realRaw = rawCandidate.isNotEmpty
        ? rawCandidate
        : (upiCandidate.isNotEmpty ? upiCandidate : null);

    return {
      id: remoteTxId,
      userId: uid,
      accountId: remoteAccountId,
      merchant: local['merchant'] ?? '',
      totalAmount: (local['amount'] as num? ?? 0).toDouble(),
      type: isNewTransfer ? 'transfer' : (isExpense ? 'expense' : 'income'),
      if (isNewTransfer) toAccountId: remoteToAccountId,
      if (isNewTransfer) transferType: newTransferType,
      paymentMethod: paymentMethodOut,
      // Keep source mobile only on create-ish paths; prefer existing if set.
      source: (local['source'] ?? 'mobile').toString(),
      entrySource:
          (local['entrySource']?.toString().isNotEmpty == true)
              ? local['entrySource']
              : ((local['isAutoDetected'] ?? false)
                  ? 'sms-auto-detected'
                  : 'mobile-manual'),
      date: dateIso,
      monthKey: monthKeyFor(dateIso),
      description: local['description'] ?? '',
      note: local['note'] ?? '',
      reference: refCandidate.isNotEmpty ? refCandidate : (local['reference'] ?? ''),
      referenceId: refCandidate.isNotEmpty ? refCandidate : null,
      // First-class columns (not only tags).
      upi: (realUpi != null && realUpi.isNotEmpty) ? realUpi : null,
      rawIdentifier: (realRaw != null && realRaw.isNotEmpty) ? realRaw : null,
      status: statusSafe,
      hasSplits: ((local['splits'] as List?)?.length ?? 0) > 1,
      tags: tagSet.toList(),
      outingId: local['outingId'],
      title:
          (local['title']?.toString().trim().isNotEmpty ?? false)
              ? local['title']
              : null,
      hasItems: ((local['items'] as List?)?.length ?? 0) > 0,
      if ((local['updatedAt'] ?? '').toString().isNotEmpty)
        'updated_at': local['updatedAt'],
    };
  }

  /// A purchased line item row. Pass [rowIndex]/[rowName]/[rowCategory]/
  /// [rowAmount] for each row of the local `items` list — independent of
  /// [splitToRemote]; never interacts with split allocation math.
  static Map<String, dynamic> itemToRemote(
    Map<String, dynamic> local,
    String uid, {
    required int rowIndex,
    required String rowName,
    String? rowCategory,
    required double rowAmount,
  }) {
    final remoteTxId = remoteTransactionId(local, uid);
    return {
      'id': SyncIds.forItemRow(uid, remoteTxId, rowIndex),
      'transaction_id': remoteTxId,
      'user_id': uid,
      'name': rowName,
      'category_id': rowCategory,
      'amount': rowAmount,
      'position': rowIndex,
    };
  }

  /// A `transaction_splits` row. Pass [rowIndex] (and [rowCategory]/
  /// [rowAmount]) when pushing one row of a real multi-row Split Expense —
  /// omit them for the legacy single-split case (id stays stable via
  /// [SyncIds.forSplit]). [remoteContributorId] — income contributor uuid
  /// when known.
  static Map<String, dynamic> splitToRemote(
    Map<String, dynamic> local,
    String uid,
    String remotePurposeId, {
    String? remoteContributorId,
    int? rowIndex,
    String? rowCategory,
    double? rowAmount,
  }) {
    final remoteTxId = remoteTransactionId(local, uid);
    final isTransfer = _looksLikeTransfer(local);
    // Web uses Settlements for transfers; keep Transfer as alias both sides accept.
    final category =
        isTransfer
            ? 'Settlements'
            : (rowCategory ?? (local['category'] ?? 'Other').toString());
    return {
      'id':
          rowIndex != null
              ? SyncIds.forSplitRow(uid, remoteTxId, rowIndex)
              : SyncIds.forSplit(uid, remoteTxId),
      'transaction_id': remoteTxId,
      'user_id': uid,
      'purpose_id': remotePurposeId,
      'category_id': category, // name-keyed on web
      'outing_id': local['outingId'],
      'contributor_id': remoteContributorId,
      'amount': rowAmount ?? (local['amount'] as num? ?? 0).toDouble(),
      'note': local['note'] ?? '',
    };
  }

  /// Remote row (+ primary split) → local Hive json.
  static Map<String, dynamic> toLocal(
    Map<String, dynamic> row,
    Map<String, dynamic>? split, {
    int splitCount = 1,

    /// Every split row for this transaction. A Split Expense keeps all of
    /// them so the list can show all categories/purposes, same as web.
    List<Map<String, dynamic>> allSplits = const [],

    /// Every item row for this transaction — independent of [allSplits].
    List<Map<String, dynamic>> allItems = const [],
  }) {
    final tagList =
        (row[tags] is List)
            ? (row[tags] as List).map((e) => e.toString()).toList()
            : <String>[];
    String tagValue(String prefix) {
      for (final t in tagList) {
        if (t.startsWith('$prefix:')) return t.substring(prefix.length + 1);
      }
      return '';
    }

    final catFromSplit = (split?['category_id'] ?? '').toString();
    final catLower = catFromSplit.toLowerCase();
    final merchantStr = (row[merchant] ?? '').toString();
    final merchantLower = merchantStr.toLowerCase();
    // New-style single-row transfer (real type='transfer' + to_account_id +
    // transfer_type columns, migration 20260755) — takes priority over the
    // legacy tag/category sniffing below, which stays for historical rows.
    final remoteTransferType = (row[transferType] ?? '').toString();
    final isNewTransfer = (row[type]?.toString() ?? '') == 'transfer';
    final isTransfer =
        isNewTransfer ||
        tagList.contains('transfer') ||
        tagList.any((t) => t.startsWith('transfer_to:')) ||
        catLower == 'transfer' ||
        catLower == 'settlements' ||
        merchantLower.startsWith('transfer to ') ||
        merchantLower.startsWith('transfer from ') ||
        (merchantLower.startsWith('tr ') && merchantLower.contains(' to '));

    String? transferTo =
        isNewTransfer
            ? RemoteIdCache.accountName(row[toAccountId]?.toString() ?? '')
            : tagValue('transfer_to');
    if ((transferTo == null || transferTo.isEmpty) &&
        isTransfer &&
        !isNewTransfer) {
      // Parse web-style "Transfer to X" / mobile "TR A to B"
      final m = RegExp(
        r'(?:transfer to| to )\s*(.+)$',
        caseSensitive: false,
      ).firstMatch(merchantStr);
      if (m != null) transferTo = m.group(1)?.trim() ?? '';
    }

    final accountName = RemoteIdCache.accountName(
      row[accountId]?.toString() ?? '',
    );
    final purposeName =
        split != null
            ? RemoteIdCache.purposeName(split['purpose_id']?.toString() ?? '')
            : null;

    // Preserve real account casing from server cache (avoid Hdfc vs HDFC).
    final accountOut =
        (accountName != null && accountName.isNotEmpty) ? accountName : 'Cash';

    final isRollup =
        tagList.contains('outing-rollup') ||
        (row[note] ?? '').toString().trim().toLowerCase().startsWith(
          'outing total',
        ) ||
        (row[description] ?? '').toString().trim().toLowerCase().startsWith(
          'outing total',
        );

    // Merchant identifier: columns first, then upi: tag, then reference_id.
    final upiCol = (row[upi] ?? '').toString().trim();
    final rawCol = (row[rawIdentifier] ?? '').toString().trim();
    final upiFromTag = tagValue('upi');
    final refId = (row[referenceId] ?? row[reference] ?? '').toString().trim();
    final merchantIdentifier =
        upiCol.isNotEmpty
            ? upiCol
            : (rawCol.isNotEmpty
                ? rawCol
                : (upiFromTag.isNotEmpty
                    ? upiFromTag
                    : (refId.isNotEmpty ? refId : '')));

    // Only a genuine multi-row split is a "Split Expense".
    final isExplicitMultiSplit = row[hasSplits] == true;
    final totalParentAmount = (row[totalAmount] as num? ?? 0).toDouble();
    final splitsSum = allSplits.fold<double>(
      0.0,
      (acc, s) => acc + ((s['amount'] as num?)?.toDouble() ?? 0.0),
    );
    final splitsValid =
        isExplicitMultiSplit &&
        allSplits.length > 1 &&
        (totalParentAmount <= 0 || splitsSum <= totalParentAmount * 1.05);

    final splitRows =
        splitsValid
            ? allSplits
                .map(
                  (s) => {
                    'categoryId': (s['category_id'] ?? '').toString(),
                    'purposeId':
                        RemoteIdCache.purposeName(
                          s['purpose_id']?.toString() ?? '',
                        ) ??
                        (s['purpose_id']?.toString() ?? ''),
                    'amount': (s['amount'] as num? ?? 0).toDouble(),
                  },
                )
                .toList()
            : const <Map<String, dynamic>>[];

    final itemRows =
        allItems
            .map(
              (i) => {
                'name': (i['name'] ?? '').toString(),
                'categoryId': (i['category_id'] ?? '').toString(),
                'amount': (i['amount'] as num? ?? 0).toDouble(),
              },
            )
            .toList();

    final rowIdStr = (row[id] ?? '').toString();
    bool isGroup =
        tagList.contains('friend_split') ||
        tagList.any((t) => t.startsWith('group_count:')) ||
        row['is_group'] == true ||
        row['isGroup'] == true;

    int groupCount =
        int.tryParse(tagValue('group_count')) ??
        (row['group_count'] as num? ?? row['groupCount'] as num? ?? 0).toInt();

    if (!isGroup && Hive.isBoxOpen('friend_splits')) {
      try {
        final box = Hive.box('friend_splits');
        for (final key in box.keys) {
          final val = box.get(key);
          if (val is Map) {
            final linkedTxId =
                (val['transactionId'] ?? val['transaction_id'] ?? '')
                    .toString();
            if (linkedTxId == rowIdStr || key.toString() == rowIdStr) {
              isGroup = true;
              final members = val['members'];
              if (members is List && members.isNotEmpty) {
                groupCount = members.length;
              }
              break;
            }
          }
        }
      } catch (_) {}
    }

    if (isGroup && groupCount <= 0) groupCount = 2;

    return {
      'id': row[id].toString(),
      'remoteId': row[id].toString(),
      'splits': splitRows,
      'merchant': merchantStr,
      'category':
          isTransfer
              ? 'Transfer'
              : (catFromSplit.isNotEmpty ? catFromSplit : 'Other'),
      'account': accountOut,
      'purpose': purposeName,
      'time': 'Synced',
      'amount': (row[totalAmount] as num? ?? 0).toDouble(),
      // The account_id side of a transfer is always the debit/from leg.
      'isExpense':
          isNewTransfer || (row[type]?.toString() ?? 'expense') == 'expense',
      'isTransfer': isTransfer,
      'transferTo':
          (transferTo == null || transferTo.isEmpty) ? null : transferTo,
      if (isNewTransfer) 'toAccountId': row[toAccountId]?.toString(),
      if (isNewTransfer && remoteTransferType.isNotEmpty)
        'transferType': remoteTransferType,
      'isAutoDetected':
          (row[entrySource]?.toString() ?? '') == 'sms-auto-detected',
      'isGroup': isGroup,
      'groupCount': groupCount,
      'paymentType':
          (row[paymentMethod]?.toString() ?? 'UPI') == 'Cash'
              ? 'Cash'
              : 'Online',
      'date': row[date] ?? DateTime.now().toIso8601String(),
      'bankName': tagValue('bank'),
      'accountLast4': tagValue('last4'),
      'referenceId': refId.isNotEmpty ? refId : merchantIdentifier,
      'upiId': merchantIdentifier,
      'rawIdentifier':
          merchantIdentifier.isNotEmpty ? merchantIdentifier : null,
      'rawMessage': '',
      'note': row[note] ?? '',
      'description': row[description] ?? '',
      'status': row[status] ?? 'completed',
      'source': row[source],
      'entrySource': row[entrySource],
      'tags': tagList,
      'outingId': row[outingId],
      'isAutoLinked': row[outingId] != null,
      'isPendingVerification': false,
      'isMerchantMapped': true,
      // Protect multi-split web rows from being collapsed on next mobile push.
      'hasMultiSplits': splitsValid,
      'title':
          row[title]?.toString().trim().isNotEmpty == true ? row[title] : null,
      'items': itemRows,
      'contributorSource':
          split != null
              ? RemoteIdCache.contributorName(
                split['contributor_id']?.toString() ?? '',
              )
              : null,
      if (isRollup) 'isOutingRollup': true,
    };
  }
}

/// accounts — web `type` is lowercase; system Cash has can_delete=false.
class AccountMap {
  AccountMap._();
  static const id = 'id';
  static const userId = 'user_id';
  static const name = 'name';
  static const type = 'type'; // bank | cash | wallet | credit
  static const last4 = 'last4';
  static const openingBalance = 'opening_balance';
  static const isActive = 'is_active';

  /// Web stores lowercase; mobile UI historically used Title Case.
  /// Must preserve credit/wallet — collapsing them to Bank breaks net worth
  /// (web subtracts credit as debt; mobile must do the same).
  static String toLocalType(String? remoteOrLocal) {
    switch ((remoteOrLocal ?? 'bank').toString().trim().toLowerCase()) {
      case 'cash':
        return 'Cash';
      case 'wallet':
        return 'Wallet';
      case 'credit':
        return 'Credit';
      default:
        return 'Bank';
    }
  }

  static String toRemoteType(String? localOrRemote) {
    switch ((localOrRemote ?? 'bank').toString().trim().toLowerCase()) {
      case 'cash':
        return 'cash';
      case 'wallet':
        return 'wallet';
      case 'credit':
        return 'credit';
      default:
        return 'bank';
    }
  }

  static const openingBalanceDate = 'opening_balance_date';
  static const isDefault = 'is_default';

  static Map<String, dynamic> toRemote(
    Map<String, dynamic> local,
    String uid,
    String remoteId,
  ) {
    final dateRaw = local['openingBalanceDate']?.toString().trim();
    return {
      id: remoteId,
      userId: uid,
      name: local['name'],
      type: toRemoteType(local['type']?.toString()),
      last4: local['last4Digits'] ?? local['last4'] ?? '',
      openingBalance: (local['openingBalance'] as num? ?? 0).toDouble(),
      if (dateRaw != null && dateRaw.isNotEmpty)
        openingBalanceDate:
            dateRaw.length >= 10 ? dateRaw.substring(0, 10) : dateRaw,
      isActive: local['isActive'] != false,
      isDefault: local['isDefault'] == true,
      if ((local['updatedAt'] ?? '').toString().isNotEmpty)
        'updated_at': local['updatedAt'],
    };
  }

  static Map<String, dynamic> toLocal(Map<String, dynamic> row) => {
    'id': row[id].toString(),
    'name': row[name] ?? '',
    'type': toLocalType(row[type]?.toString()),
    'last4Digits': row[last4] ?? '',
    'openingBalance': (row[openingBalance] as num? ?? 0).toDouble(),
    'openingBalanceDate': row[openingBalanceDate]?.toString(),
    'isActive': row[isActive] != false,
    'isDefault': row[isDefault] == true,
  };
}

/// outings — web semantics: status = running-state, is_active = soft delete.
class OutingMap {
  OutingMap._();
  static const id = 'id';
  static const userId = 'user_id';
  static const title = 'title';
  static const type = 'type';
  static const location = 'location';
  static const startDate = 'start_date';
  static const endDate = 'end_date';
  static const members = 'members';
  static const status = 'status';
  static const autoAddMode = 'auto_add_mode';
  static const isActive = 'is_active';
  static const totalSpent = 'total_spent';
  static const purposeId = 'purpose_id';

  static Map<String, dynamic> toRemote(Map<String, dynamic> local, String uid) {
    final localMembers =
        (local['members'] as List? ?? [])
            .whereType<Map>()
            .map((m) => Map<String, dynamic>.from(m))
            .toList();
    // Prefer explicit totalSpent; else sum embedded expenses.
    double spent = (local['totalSpent'] as num?)?.toDouble() ?? 0;
    if (spent <= 0) {
      final expenses = (local['expenses'] as List? ?? []);
      for (final e in expenses) {
        if (e is Map) {
          spent += (e['amount'] as num? ?? 0).toDouble();
        }
      }
    }
    // Web `is_active` means "not deleted". Mobile `isActive` means the trip
    // is still open. A completed or archived trip must stay is_active on
    // the server, or the next pull treats it as deleted and drops it.
    final localStatus =
        (local['status'] ?? '').toString().trim().toLowerCase();
    final deleted = local['deletedAt'] != null || localStatus == 'cancelled';
    final statusOut =
        deleted
            ? 'cancelled'
            : (localStatus == 'archived'
                ? 'archived'
                : (localStatus == 'completed' || local['isActive'] == false
                    ? 'completed'
                    : 'active'));
    // `created_by` is NOT NULL on web — missing it fails every outing upsert.
    return {
      id: local['id'],
      userId: uid,
      'created_by': uid,
      title: local['title'] ?? '',
      type: local['category'] ?? 'Trip',
      location: local['location'],
      'budget': local['budget'],
      startDate: local['startDate'] ?? DateTime.now().toIso8601String(),
      endDate: local['endDate'],
      status: statusOut,
      // Per-outing toggle removed; keep true so date-range linking works.
      autoAddMode: local['isAutoMode'] != false,
      isActive: !deleted,
      totalSpent: spent,
      members:
          localMembers
              .map(
                (m) => {
                  'id': m['id'],
                  'name': m['name'],
                  'isCurrentUser':
                      (m['name'] ?? '').toString().toLowerCase() == 'you' ||
                      m['isCurrentUser'] == true,
                  if (m['upiId'] != null) 'upiId': m['upiId'],
                  if (m['friendId'] != null) 'friendId': m['friendId'],
                },
              )
              .toList(),
    };
  }

  static Map<String, dynamic> toLocalShell(Map<String, dynamic> row) {
    final remoteMembers =
        (row[members] as List? ?? [])
            .whereType<Map>()
            .map((m) => Map<String, dynamic>.from(m))
            .toList();
    var remoteStatus = (row[status]?.toString() ?? '').trim().toLowerCase();
    if (remoteStatus.isEmpty) remoteStatus = 'completed';
    final softActive = row[isActive] != false;
    return {
      'id': row[id].toString(),
      'title': row[title] ?? '',
      'category': row[type] ?? 'Trip',
      'location': row[location],
      'budget': row['budget'],
      'startDate': row[startDate] ?? DateTime.now().toIso8601String(),
      'endDate': row[endDate] ?? DateTime.now().toIso8601String(),
      // Running trip only when status=active AND not soft-deleted.
      'isActive': softActive && remoteStatus == 'active',
      'status': remoteStatus,
      'isAutoMode': row[autoAddMode] != false,
      'totalSpent': (row[totalSpent] as num?)?.toDouble() ?? 0,
      'purpose':
          RemoteIdCache.purposeName(row[purposeId]?.toString() ?? '') ??
          'Personal',
      // Mobile identifies "you" by name — force it for isCurrentUser rows.
      'members':
          remoteMembers
              .map(
                (m) => {
                  'id': m['id'],
                  'name':
                      (m['isCurrentUser'] == true) ? 'You' : (m['name'] ?? ''),
                  'isCurrentUser': m['isCurrentUser'] == true,
                  if (m['upiId'] != null) 'upiId': m['upiId'],
                  if (m['friendId'] != null) 'friendId': m['friendId'],
                },
              )
              .toList(),
      'expenses': <dynamic>[],
    };
  }
}

/// outing_expenses — web column names differ substantially from mobile.
class OutingExpenseMap {
  OutingExpenseMap._();
  static const id = 'id';
  static const userId = 'user_id';
  static const outingId = 'outing_id';
  static const description = 'description';
  static const amount = 'amount';
  static const categoryId = 'category_id';
  static const date = 'expense_date';
  static const paidByMemberId = 'paid_by_member_id';
  static const splitType = 'split_type'; // equally | solo | custom | ...
  static const splits = 'splits'; // [{memberId, amount}]
  static const source = 'source';
  static const linkedTransactionId = 'linked_transaction_id';
  static const accountName = 'account_name';
  static const paymentMode = 'payment_mode';

  static Map<String, dynamic> toRemote(
    Map<String, dynamic> local,
    String uid,
    String outing,
  ) {
    final memberIds =
        (local['memberIds'] as List? ?? []).map((e) => e.toString()).toList();
    final amt = (local['amount'] as num? ?? 0).toDouble();
    final share = memberIds.isEmpty ? amt : amt / memberIds.length;
    final txId = local['transactionId']?.toString().trim();
    final hasLink = txId != null && txId.isNotEmpty;
    // paid_by_member_id is NOT NULL — default to "you" when missing.
    final payer =
        (local['paidByMemberId']?.toString().trim().isNotEmpty == true)
            ? local['paidByMemberId'].toString()
            : 'you';
    final localAccount = local['accountId']?.toString().trim();
    final localPayMode = local['paymentMode']?.toString().trim();
    final preservedSplitType =
        local['remoteSplitType']?.toString().trim().toLowerCase();
    final preservedSplits =
        (local['remoteSplits'] is List)
            ? (local['remoteSplits'] as List)
                .whereType<Map>()
                .map((e) => Map<String, dynamic>.from(e))
                .toList()
            : null;
    // Mobile-authored custom split — takes priority over any preserved
    // foreign (web) split, since the user just edited it on this device.
    final localCustomSplits = local['customSplitAmounts'];
    final localCustomSplitsMap =
        localCustomSplits is Map
            ? Map<String, dynamic>.from(localCustomSplits)
            : null;
    final localSplitTypeRaw = local['splitType'];
    final isLocalCustomSplit =
        (localSplitTypeRaw == 2 || localSplitTypeRaw == 'custom') &&
        localCustomSplitsMap != null &&
        localCustomSplitsMap.isNotEmpty;
    final splitTypeOut = () {
      if (isLocalCustomSplit) return 'custom';
      if (preservedSplitType != null &&
          const {
            'custom',
            'percentage',
            'shares',
          }.contains(preservedSplitType)) {
        return preservedSplitType;
      }
      final raw = local['splitType'];
      if (raw is String) {
        final s = raw.toLowerCase();
        if (const {
          'equally',
          'solo',
          'custom',
          'percentage',
          'shares',
        }.contains(s)) {
          return s;
        }
      }
      if (raw == 2) return 'custom'; // SplitType.custom.index
      return (raw == 1 || raw == '1') ? 'equally' : 'solo';
    }();
    final splitsOut =
        isLocalCustomSplit
            ? localCustomSplitsMap.entries
                .map(
                  (e) => {
                    'memberId': e.key,
                    'amount': (e.value as num).toDouble(),
                  },
                )
                .toList()
            : (preservedSplits != null &&
                preservedSplits.isNotEmpty &&
                const {'custom', 'percentage', 'shares'}.contains(splitTypeOut))
            ? preservedSplits
            : memberIds.map((m) => {'memberId': m, 'amount': share}).toList();
    return {
      id: SyncIds.forExpense(uid, local['id'].toString()),
      userId: uid,
      outingId: outing,
      description:
          (local['title'] ?? local['description'] ?? 'Expense').toString(),
      amount: amt,
      categoryId: local['category'] ?? 'Other',
      date: local['date'] ?? DateTime.now().toIso8601String(),
      paidByMemberId: payer,
      splitType: splitTypeOut,
      splits: splitsOut,
      source: hasLink ? 'bank-detected' : 'manual',
      // Prefer stored remoteId when present (same row the tx push used).
      linkedTransactionId:
          !hasLink
              ? null
              : (SyncIds.isUuid(txId)
                  ? txId
                  : SyncIds.forTransaction(uid, txId)),
      // Account the user selected when logging the trip expense.
      if (localAccount != null && localAccount.isNotEmpty)
        accountName: localAccount,
      if (localPayMode != null && localPayMode.isNotEmpty)
        paymentMode: localPayMode,
    };
  }

  static Map<String, dynamic> toLocal(Map<String, dynamic> row) {
    final rawSplits =
        (row[splits] as List? ?? [])
            .whereType<Map>()
            .map((s) => Map<String, dynamic>.from(s))
            .toList();
    final splitList =
        rawSplits
            .map((s) => s['memberId']?.toString() ?? '')
            .where((s) => s.isNotEmpty)
            .toList();
    final accName = row[accountName]?.toString();
    final payMode = row[paymentMode]?.toString();
    final remoteSplit = (row[splitType]?.toString() ?? 'solo').toLowerCase();
    // Real per-member amounts for a custom split — mobile can now author and
    // display these exactly, not just round-trip them opaquely.
    final customSplitAmounts =
        remoteSplit == 'custom'
            ? {
              for (final s in rawSplits)
                if (s['memberId'] != null)
                  s['memberId'].toString():
                      (s['amount'] as num? ?? 0).toDouble(),
            }
            : null;
    return {
      'id': row[id].toString(),
      'title': row[description] ?? '',
      'amount': (row[amount] as num? ?? 0).toDouble(),
      'category': row[categoryId] ?? 'Other',
      'date': row[date] ?? DateTime.now().toIso8601String(),
      'paymentMode': (payMode != null && payMode.isNotEmpty) ? payMode : 'Cash',
      'memberIds': splitList,
      'settledMemberIds': <String>[],
      'splitType': () {
        if (remoteSplit == 'equally') return 1;
        if (remoteSplit == 'custom') return 2;
        return 0;
      }(),
      'remoteSplitType': remoteSplit,
      'remoteSplits': rawSplits,
      if (customSplitAmounts != null && customSplitAmounts.isNotEmpty)
        'customSplitAmounts': customSplitAmounts,
      'transactionId': row[linkedTransactionId]?.toString(),
      // Mobile stores account display name in accountId.
      'accountId': (accName != null && accName.isNotEmpty) ? accName : null,
      'purpose': 'Personal',
      'paidByMemberId': row[paidByMemberId]?.toString(),
      'settledModes': <String, dynamic>{},
      'settlementPayments': <String, dynamic>{},
    };
  }
}

/// settlements — web rows are outing-level member→member. Mobile's
/// per-expense payments embed the expense remote id in `note` ("exp:&lt;id&gt;")
/// so they can be re-attached on pull; web-created rows without that marker
/// are applied FIFO against the member's pending shares.
class SettlementMap {
  SettlementMap._();
  static const id = 'id';
  static const userId = 'user_id';
  static const outingId = 'outing_id';
  static const fromMemberId = 'from_member_id';
  static const toMemberId = 'to_member_id';
  static const amount = 'amount';
  static const isPartial = 'is_partial';
  static const settledDate = 'settled_date';
  static const note = 'note';

  static String expenseNote(String remoteExpenseId) => 'exp:$remoteExpenseId';

  static String? expenseIdFromNote(String? noteVal) {
    if (noteVal == null || !noteVal.startsWith('exp:')) return null;
    final v = noteVal.substring(4).trim();
    return v.isEmpty ? null : v;
  }

  static Map<String, dynamic> toRemote({
    required String uid,
    required String outing,
    required String remoteExpenseId,
    required String payerMemberId, // expense's paid_by (receiver of repayment)
    required String member, // member paying back
    required int index,
    required Map<String, dynamic> payment,
  }) => {
    id: SyncIds.forSettlement(uid, remoteExpenseId, member, index),
    userId: uid,
    outingId: outing,
    fromMemberId: member,
    toMemberId: payerMemberId,
    amount: (payment['amount'] as num? ?? 0).toDouble(),
    isPartial: true,
    settledDate: payment['date'] ?? DateTime.now().toIso8601String(),
    note: expenseNote(remoteExpenseId),
  };
}

/// friend_splits / friend_settlements — a one-off shared expense between
/// friends, standalone (no outing/outing_expenses/settlements row). Mirrors
/// the web app's schema exactly (supabase/migrations/20260746_friend_splits.sql
/// in the companion web repo) so a Friend Split created on either platform is
/// visible on the other.
class FriendSplitMap {
  FriendSplitMap._();

  static Map<String, dynamic> toRemote(
    Map<String, dynamic> local,
    String uid,
    String remoteTransactionId,
  ) {
    final remoteId = SyncIds.forFriendSplit(uid, local['id'].toString());
    return {
      'id': remoteId,
      'user_id': uid,
      'transaction_id': remoteTransactionId,
      'description': local['description'] ?? '',
      'amount': (local['amount'] as num? ?? 0).toDouble(),
      'category_id': local['category'] ?? 'Other',
      'split_date': local['date'] ?? DateTime.now().toIso8601String(),
      'members': local['members'] ?? const [],
      'paid_by_member_id': local['paidByMemberId'] ?? 'you',
      'split_type': local['splitType'] ?? 'equally',
      'splits': local['splits'] ?? const [],
      'account_name': local['accountName'],
      'payment_mode': local['paymentMode'],
      'note': local['note'],
      'is_active': local['isActive'] ?? true,
      'updated_at': DateTime.now().toIso8601String(),
    };
  }

  static Map<String, dynamic> toLocal(Map<String, dynamic> row) => {
    'id': (row['id'] ?? '').toString(),
    'transactionId': (row['transaction_id'] ?? '').toString(),
    'description': row['description'] ?? '',
    'amount': (row['amount'] as num? ?? 0).toDouble(),
    'category': row['category_id'] ?? 'Other',
    'date': row['split_date'] ?? DateTime.now().toIso8601String(),
    'members': row['members'] ?? const [],
    'paidByMemberId': row['paid_by_member_id'] ?? 'you',
    'splitType': row['split_type'] ?? 'equally',
    'splits': row['splits'] ?? const [],
    'accountName': row['account_name'],
    'paymentMode': row['payment_mode'],
    'note': row['note'],
    'isActive': row['is_active'] ?? true,
  };
}

class FriendSettlementMap {
  FriendSettlementMap._();

  static Map<String, dynamic> toRemote(
    Map<String, dynamic> local,
    String uid,
    String remoteFriendSplitId,
  ) {
    final remoteId = SyncIds.forFriendSettlement(uid, local['id'].toString());
    return {
      'id': remoteId,
      'user_id': uid,
      'friend_split_id': remoteFriendSplitId,
      'from_member_id': local['fromMemberId'] ?? '',
      'to_member_id': local['toMemberId'] ?? '',
      'amount': (local['amount'] as num? ?? 0).toDouble(),
      'is_partial': false,
      'settled_date': local['date'] ?? DateTime.now().toIso8601String(),
      'note': local['note'],
    };
  }

  static Map<String, dynamic> toLocal(Map<String, dynamic> row) => {
    'id': (row['id'] ?? '').toString(),
    'fromMemberId': row['from_member_id'] ?? '',
    'toMemberId': row['to_member_id'] ?? '',
    'amount': (row['amount'] as num? ?? 0).toDouble(),
    'date': row['settled_date'] ?? DateTime.now().toIso8601String(),
    'note': row['note'],
  };
}

/// friends — full column set matching web saveFriend.
class FriendMap {
  FriendMap._();
  static const id = 'id';
  static const userId = 'user_id';
  static const name = 'name';
  static const phone = 'phone';
  static const email = 'email';
  static const upi = 'upi';
  static const upiIds = 'upi_ids';
  static const notes = 'notes';
  static const isActive = 'is_active';

  static Map<String, dynamic> toRemote(Map<String, dynamic> local, String uid) {
    final nameStr = (local['name'] ?? '').toString();
    final remoteId =
        SyncIds.isUuid(local['id']?.toString() ?? '')
            ? local['id'].toString()
            : SyncIds.forFriend(uid, nameStr);
    final upiRaw = (local['upiId'] ?? local['upi'] ?? '').toString().trim();
    final upiList = <String>[
      if (local['upiIds'] is List)
        ...(local['upiIds'] as List)
            .map((e) => e.toString().trim())
            .where((e) => e.isNotEmpty),
      if (upiRaw.isNotEmpty) upiRaw,
    ];
    return {
      id: remoteId,
      userId: uid,
      name: nameStr,
      phone: local['phone'],
      email: local['email'],
      upi:
          upiRaw.isNotEmpty
              ? upiRaw
              : (upiList.isNotEmpty ? upiList.first : null),
      upiIds: upiList.toSet().toList(),
      notes: local['notes'],
      isActive: local['isActive'] != false,
    };
  }

  static Map<String, dynamic> toLocal(Map<String, dynamic> row) => {
    'id': row[id]?.toString() ?? '',
    'name': row[name] ?? '',
    'phone': row[phone],
    'email': row[email],
    'upiId': row[upi],
    'upi': row[upi],
    'upiIds':
        row[upiIds] is List
            ? (row[upiIds] as List).map((e) => e.toString()).toList()
            : <String>[],
    'notes': row[notes],
    'isActive': row[isActive] != false,
  };
}

/// users — the genuinely-shared settings subset only.
/// PIN hash/biometrics/SMS toggle/debug flags are local-only and must never be here.
/// [appPinResetAt] is a server signal only (timestamp) — not the PIN value.
class UserRowMap {
  UserRowMap._();
  static const id = 'id';
  static const name = 'name';
  static const email = 'email';
  static const privateMode = 'private_mode';
  static const defaultAccountId = 'default_account_id';
  static const appPinResetAt = 'app_pin_reset_at';
}

/// purposes — mobile purpose strings ↔ web purpose rows, resolved by name.
class PurposeMap {
  PurposeMap._();
  static const id = 'id';
  static const userId = 'user_id';
  static const name = 'name';
  static const color = 'color';
  static const isDefault = 'is_default';
  static const canDelete = 'can_delete';
  static const isActive = 'is_active';

  static Map<String, dynamic> toRemote(String purposeName, String uid) {
    final purposeNameValue =
        purposeName.trim().isEmpty ? 'Personal' : purposeName.trim();
    final isPersonal = purposeNameValue.toLowerCase() == 'personal';
    // `color` is NOT NULL on web — omitting it makes every purpose create fail
    // and then blocks transaction_splits (purpose_id FK).
    return {
      id: SyncIds.forPurpose(uid, purposeNameValue),
      userId: uid,
      name: purposeNameValue,
      color: isPersonal ? '#57BE93' : '#8B84D7',
      isDefault: isPersonal,
      canDelete: !isPersonal,
      isActive: true,
    };
  }
}

/// Admin rule tables → the camelCase maps the local Hive rule boxes /
/// engines expect (SmsTemplateRule / SmsRule / BlockRule .fromMap).
class RuleTableMap {
  RuleTableMap._();

  static bool isRowActive(Map<String, dynamic> row) =>
      row['is_active'] != false;

  static Map<String, dynamic> templateToLocal(Map<String, dynamic> r) => {
    'id': r['id']?.toString() ?? '',
    'bankName': r['bank_name'] ?? '',
    'bankNameExact': r['bank_name'] ?? '',
    'type': r['type'] ?? 'debit',
    'mode': r['mode'] ?? 'unknown',
    'templatePattern': r['template_pattern'] ?? '',
    'extractionMap':
        r['extraction_map'] is Map
            ? Map<String, dynamic>.from(r['extraction_map'] as Map)
            : <String, dynamic>{},
    'exactTaggedValues': <String, dynamic>{},
    'keywords':
        r['keywords'] is List
            ? (r['keywords'] as List).map((e) => e.toString()).toList()
            : <String>[],
    'sampleMessage': r['sample_message'] ?? '',
    'similarityThreshold':
        (r['similarity_threshold'] as num?)?.toDouble() ?? 0.65,
    'structuralParts': <String>[],
    // Admin-synced defaults (user-trained rules keep isManual=true).
    'isManual': false,
    'fromAdmin': true,
  };

  static Map<String, dynamic> detectionToLocal(Map<String, dynamic> r) => {
    'id': r['id']?.toString() ?? '',
    'matchPattern': r['match_pattern'] ?? '',
    'containsKeywords':
        r['contains_keywords'] is List
            ? (r['contains_keywords'] as List).map((e) => e.toString()).toList()
            : <String>[],
    'excludeKeywords':
        r['exclude_keywords'] is List
            ? (r['exclude_keywords'] as List).map((e) => e.toString()).toList()
            : <String>[],
    'amountPattern': r['amount_pattern'] ?? '',
    'namePattern': r['name_pattern'] ?? '',
    'datePattern': r['date_pattern'] ?? '',
    'refPattern': r['ref_pattern'] ?? '',
    'accountPattern': r['account_pattern'] ?? '',
    'upiPattern': r['upi_pattern'] ?? '',
    'type': r['type'] ?? 'Debit',
    'mode': r['mode'] ?? 'UPI',
    'bankName': r['bank_name'] ?? '',
    'sampleMessage': r['sample_message'] ?? '',
    'isManual': false,
    'fromAdmin': true,
  };

  static Map<String, dynamic> blockToLocal(Map<String, dynamic> r) => {
    'id': r['id']?.toString() ?? '',
    'name': r['name'],
    'keywords':
        r['keywords'] is List
            ? (r['keywords'] as List).map((e) => e.toString()).toList()
            : <String>[],
    'pattern': r['pattern'],
    'similarityThreshold':
        (r['similarity_threshold'] as num?)?.toDouble() ?? 0.8,
    'sampleMessage': r['sample_message'] ?? '',
    'createdAt':
        r['created_at']?.toString() ?? DateTime.now().toIso8601String(),
    'fromAdmin': true,
  };
}

/// user_merchants — per-user verified SMS payees (not global admin rules).
class UserMerchantMap {
  UserMerchantMap._();
  static const id = 'id';
  static const userId = 'user_id';
  static const payee = 'payee';
  static const normalizedPayee = 'normalized_payee';
  static const title = 'title';
  static const purpose = 'purpose';
  static const category = 'category';
  static const isAutoApply = 'is_auto_apply';
  static const verifiedAt = 'verified_at';
  static const updatedAt = 'updated_at';

  static Map<String, dynamic> toRemote(Map<String, dynamic> local, String uid) {
    final norm =
        (local['normalizedPayee'] ?? local['payee'] ?? '')
            .toString()
            .trim()
            .toLowerCase();
    final remoteId =
        SyncIds.isUuid(local['id']?.toString() ?? '')
            ? local['id'].toString()
            : SyncIds.forMerchant(uid, norm);
    return {
      id: remoteId,
      userId: uid,
      payee: local['payee'] ?? '',
      normalizedPayee: norm,
      title: local['title'] ?? local['payee'] ?? '',
      purpose:
          (local['purpose']?.toString().isNotEmpty == true)
              ? local['purpose']
              : 'Personal',
      category: local['category'] ?? 'Other',
      isAutoApply: local['isAutoApply'] != false,
      verifiedAt: local['verifiedAt'] ?? DateTime.now().toIso8601String(),
      updatedAt: DateTime.now().toIso8601String(),
    };
  }

  static Map<String, dynamic> toLocal(Map<String, dynamic> row) => {
    'id': row[id]?.toString() ?? '',
    'payee': row[payee] ?? '',
    'normalizedPayee': row[normalizedPayee] ?? row[payee] ?? '',
    'title': row[title] ?? '',
    'purpose': row[purpose] ?? 'Personal',
    'category': row[category] ?? 'Other',
    'verifiedAt':
        row[verifiedAt]?.toString() ?? DateTime.now().toIso8601String(),
    'isAutoApply': row[isAutoApply] != false,
  };
}
