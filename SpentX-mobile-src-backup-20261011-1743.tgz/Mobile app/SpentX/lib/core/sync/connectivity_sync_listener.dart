import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart';

import 'sync_service.dart';

/// When the device comes back online, drain the local sync queue immediately
/// (even if the user is mid-session and not waiting for the periodic timer).
class ConnectivitySyncListener {
  ConnectivitySyncListener._();

  static StreamSubscription<List<ConnectivityResult>>? _sub;
  static bool _wasOffline = false;
  static DateTime? _lastOnlineKick;

  static void start() {
    _sub?.cancel();
    _sub = Connectivity().onConnectivityChanged.listen((results) {
      final online = results.any((r) =>
          r == ConnectivityResult.mobile ||
          r == ConnectivityResult.wifi ||
          r == ConnectivityResult.ethernet ||
          r == ConnectivityResult.vpn);
      if (online) {
        // Debounce flaky radios (saves battery on budget phones).
        final now = DateTime.now();
        if (_lastOnlineKick != null &&
            now.difference(_lastOnlineKick!).inSeconds < 20) {
          return;
        }
        _lastOnlineKick = now;
        if (_wasOffline) {
          unawaited(SyncService.fullSync());
        } else {
          // Still push pending even if we never saw offline in this session.
          unawaited(SyncService.pushPending());
        }
        _wasOffline = false;
      } else {
        _wasOffline = true;
      }
    });
  }

  static void stop() {
    _sub?.cancel();
    _sub = null;
  }
}
