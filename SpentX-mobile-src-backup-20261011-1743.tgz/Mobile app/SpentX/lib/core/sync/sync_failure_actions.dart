import 'package:hive_flutter/hive_flutter.dart';

import '../../features/investments/data/investment_service.dart';
import '../../features/recurring/data/recurring_bill_service.dart';
import '../../features/wealth/data/savings_goal_service.dart';
import '../../features/wealth/data/snapshot_outbox.dart';
import 'durable_collection.dart';
import 'sync_failure_log.dart';

/// Settings → "Changes that could not sync" actions.
class SyncFailureActions {
  SyncFailureActions._();

  static const _boxes = ['settings', InvestmentService.boxName];

  static Iterable<DurableCollection> _collectionsWithFailures() sync* {
    for (final name in _boxes) {
      if (!Hive.isBoxOpen(name)) continue;
      final box = Hive.box(name);
      for (final key in box.keys) {
        final v = box.get(key);
        if (v is Map && v['failed'] is Map && (v['failed'] as Map).isNotEmpty) {
          yield DurableCollection(box, key.toString());
        }
      }
    }
  }

  /// Re-queues every parked change and runs the outboxes once.
  static Future<void> retryAll() async {
    for (final c in _collectionsWithFailures().toList()) {
      await c.retryFailed();
    }
    await SyncFailureLog.clear();
    Future<void> attempt(Future<void> Function() f) async {
      try {
        await f();
      } catch (_) {}
    }

    await attempt(InvestmentService.flushPending);
    await attempt(SavingsGoalService.flushPending);
    await attempt(RecurringBillService.flushPending);
    await attempt(SnapshotOutbox.flushPending);
  }
}
