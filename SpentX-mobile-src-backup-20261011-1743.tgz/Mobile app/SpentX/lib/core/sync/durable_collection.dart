import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';

import 'sync_error_kind.dart';
import 'sync_failure_log.dart';

/// Owner-scoped outbox for goals and manual bills. Cache and operations are
/// persisted together; an upload failure never discards the local change.
///
/// A change the server rejects permanently (constraint, foreign key,
/// permission — see [SyncErrors.classify]) is moved to `failed` instead of
/// blocking every later change and logout. It stays on the phone, is listed
/// in [SyncFailureLog], and can be retried with [retryFailed].
class DurableCollection {
  DurableCollection(this.box, this.key, {String? area}) : area = area ?? key.split(':').first;
  final Box box;
  final String key;

  /// Label used in the visible failed-sync list.
  final String area;

  Map<String, dynamic> get _state {
    final raw = box.get(key);
    return raw is Map ? Map<String, dynamic>.from(raw) : {};
  }

  List<Map<String, dynamic>> get rows =>
      ((_state['rows'] as List?) ?? [])
          .map((row) => Map<String, dynamic>.from(row as Map))
          .toList();
  Map<String, dynamic> get _pending =>
      Map<String, dynamic>.from((_state['pending'] as Map?) ?? {});
  Map<String, dynamic> get _failed =>
      Map<String, dynamic>.from((_state['failed'] as Map?) ?? {});
  bool get hasPending => _pending.isNotEmpty;
  bool get initialized => box.containsKey(key);

  /// Changes parked after a permanent server rejection.
  int get failedCount => _failed.length;

  Future<void> _save(
    List<Map<String, dynamic>> rows,
    Map<String, dynamic> pending, [
    Map<String, dynamic>? failed,
  ]) {
    final f = failed ?? _failed;
    return box.put(key, {
      'rows': rows,
      'pending': pending,
      if (f.isNotEmpty) 'failed': f,
    });
  }

  Future<void> importRows(
    List<Map<String, dynamic>> initial, {
    bool upload = false,
  }) async {
    if (initialized) return;
    await box.put(key, {
      'rows': initial,
      'pending': {
        if (upload)
          for (final row in initial)
            row['id'].toString(): {'version': const Uuid().v4(), 'row': row},
      },
    });
  }

  /// Updates the visible copy of one row WITHOUT queuing an upload. Used for
  /// optimistic server-side effects (e.g. a goal deposit applied by an RPC
  /// that is queued separately). The next pull replaces it with the server row.
  Future<void> putLocalRow(String id, Map<String, dynamic> row) {
    final next = rows;
    final idx = next.indexWhere((item) => item['id'].toString() == id);
    if (idx < 0) return Future.value();
    next[idx] = row;
    return _save(next, _pending);
  }

  /// Moves rows staged by another owner (for example edits made while signed
  /// out) into this collection as pending uploads, then removes the source.
  Future<void> adoptFrom(DurableCollection other) async {
    if (!other.initialized || (other.key == key && identical(other.box, box))) return;
    final otherRows = other.rows;
    final otherPending = other._pending;
    if (otherRows.isEmpty && otherPending.isEmpty) {
      await other.box.delete(other.key);
      return;
    }
    final mine = rows;
    final pending = _pending;
    for (final row in otherRows) {
      final id = row['id'].toString();
      mine.removeWhere((item) => item['id'].toString() == id);
      mine.add(row);
      pending[id] = {'version': const Uuid().v4(), 'row': row};
    }
    for (final entry in otherPending.entries) {
      final op = Map<String, dynamic>.from(entry.value as Map);
      if (op['row'] == null) {
        mine.removeWhere((item) => item['id'].toString() == entry.key);
        pending[entry.key] = {'version': const Uuid().v4(), 'row': null};
      }
    }
    await _save(mine, pending);
    await other.box.delete(other.key);
  }

  Future<void> stage(String id, Map<String, dynamic>? row) {
    final next = rows..removeWhere((item) => item['id'].toString() == id);
    if (row != null) next.add(row);
    final failed = _failed..remove(id);
    return _save(next, {
      ..._pending,
      id: {'version': const Uuid().v4(), 'row': row},
    }, failed);
  }

  /// Puts every parked change back in the upload queue.
  Future<void> retryFailed() async {
    final failed = _failed;
    if (failed.isEmpty) return;
    final pending = _pending;
    for (final entry in failed.entries) {
      final op = Map<String, dynamic>.from(entry.value as Map);
      pending.putIfAbsent(
        entry.key,
        () => {'version': const Uuid().v4(), 'row': op['row']},
      );
      await SyncFailureLog.remove(area, entry.key);
    }
    await _save(rows, pending, {});
  }

  /// Raw persisted state (rows, pending, failed) for [mergeParked].
  Map<String, dynamic>? exportRaw() => initialized ? _state : null;

  /// Brings back changes parked before a logout wipe (same owner only).
  /// Pending/failed changes are re-queued; local edits made since win.
  Future<void> mergeParked(Map<String, dynamic> raw) async {
    final parkedPending = Map<String, dynamic>.from((raw['pending'] as Map?) ?? {});
    final parkedFailed = Map<String, dynamic>.from((raw['failed'] as Map?) ?? {});
    final parkedRows = ((raw['rows'] as List?) ?? [])
        .map((r) => Map<String, dynamic>.from(r as Map))
        .toList();
    final mine = rows;
    final pending = _pending;
    void requeue(String id, Object? opRaw) {
      if (pending.containsKey(id)) return;
      final op = opRaw is Map ? Map<String, dynamic>.from(opRaw) : <String, dynamic>{};
      final row = op['row'] is Map ? Map<String, dynamic>.from(op['row'] as Map) : null;
      pending[id] = {'version': const Uuid().v4(), 'row': row};
      mine.removeWhere((item) => item['id'].toString() == id);
      if (row != null) mine.add(row);
    }

    for (final e in parkedPending.entries) {
      requeue(e.key, e.value);
    }
    for (final e in parkedFailed.entries) {
      requeue(e.key, e.value);
    }
    for (final row in parkedRows) {
      final id = row['id']?.toString();
      if (id == null || mine.any((item) => item['id'].toString() == id)) continue;
      mine.add(row);
    }
    await _save(mine, pending);
  }

  /// The caller serializes network sync. Newer local edits survive older
  /// acknowledgements, and pending edits/deletes take precedence over pulls.
  Future<void> synchronize({
    required Future<void> Function(String id, Map<String, dynamic>? row) write,
    required Future<List<Map<String, dynamic>>> Function() read,
    required bool Function() isCurrent,
    Future<void> Function()? afterWrites,
  }) async {
    while (hasPending && isCurrent()) {
      final entry = _pending.entries.first;
      final op = Map<String, dynamic>.from(entry.value as Map);
      final raw = op['row'];
      try {
        await write(
          entry.key,
          raw is Map ? Map<String, dynamic>.from(raw) : null,
        );
      } catch (e) {
        if (SyncErrors.classify(e) != SyncErrorKind.permanent) rethrow;
        if (!isCurrent()) return;
        // Park it: never retried automatically, never blocks the queue.
        final pending = _pending;
        final failed = _failed;
        if ((pending[entry.key] as Map?)?['version'] == op['version']) {
          pending.remove(entry.key);
          failed[entry.key] = {
            'version': op['version'],
            'row': raw,
            'error': SyncErrors.describe(e),
            'at': DateTime.now().toUtc().toIso8601String(),
          };
        }
        await _save(rows, pending, failed);
        await SyncFailureLog.add(SyncFailureNote(
          area: area,
          id: entry.key,
          reason: SyncErrors.describe(e),
          at: DateTime.now(),
        ));
        continue;
      }
      if (!isCurrent()) return;
      final pending = _pending;
      if ((pending[entry.key] as Map?)?['version'] == op['version']) {
        pending.remove(entry.key);
      }
      await _save(rows, pending);
    }
    if (!isCurrent()) return;
    if (afterWrites != null) {
      await afterWrites();
      if (!isCurrent()) return;
    }
    final remote = await read();
    if (!isCurrent()) return;
    final pending = _pending;
    final merged = {for (final row in remote) row['id'].toString(): row};
    for (final entry in pending.entries) {
      final row = (entry.value as Map)['row'];
      if (row == null) {
        merged.remove(entry.key);
      } else {
        merged[entry.key] = Map<String, dynamic>.from(row as Map);
      }
    }
    await _save(merged.values.toList(), pending);
  }
}
