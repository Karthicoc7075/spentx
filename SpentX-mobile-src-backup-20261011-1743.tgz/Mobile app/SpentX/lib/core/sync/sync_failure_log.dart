import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';

/// One change the server rejected permanently (parked, not retried).
class SyncFailureNote {
  const SyncFailureNote({
    required this.area,
    required this.id,
    required this.reason,
    required this.at,
  });

  final String area;
  final String id;
  final String reason;
  final DateTime at;

  Map<String, dynamic> toMap() => {
    'area': area,
    'id': id,
    'reason': reason,
    'at': at.toIso8601String(),
  };

  static SyncFailureNote? fromMap(Object? raw) {
    if (raw is! Map) return null;
    return SyncFailureNote(
      area: raw['area']?.toString() ?? 'Sync',
      id: raw['id']?.toString() ?? '',
      reason: raw['reason']?.toString() ?? '',
      at: DateTime.tryParse(raw['at']?.toString() ?? '') ?? DateTime.now(),
    );
  }
}

/// Visible list of changes that could not sync. Shown in Settings so a
/// rejected row never fails silently. Stored in the settings box (wiped on
/// logout together with the outbox it describes).
class SyncFailureLog {
  SyncFailureLog._();

  static const _key = 'sync_failure_notes_v1';
  static const _max = 50;
  static final ValueNotifier<int> revision = ValueNotifier<int>(0);

  static Box? get _box => Hive.isBoxOpen('settings') ? Hive.box('settings') : null;

  static List<SyncFailureNote> get notes {
    final raw = _box?.get(_key);
    if (raw is! List) return const [];
    return raw.map(SyncFailureNote.fromMap).whereType<SyncFailureNote>().toList();
  }

  static Future<void> add(SyncFailureNote note) async {
    final box = _box;
    if (box == null) return;
    final next = [
      note,
      ...notes.where((n) => !(n.area == note.area && n.id == note.id)),
    ].take(_max).map((n) => n.toMap()).toList();
    await box.put(_key, next);
    revision.value++;
  }

  static Future<void> remove(String area, String id) async {
    final box = _box;
    if (box == null) return;
    await box.put(
      _key,
      notes.where((n) => !(n.area == area && n.id == id)).map((n) => n.toMap()).toList(),
    );
    revision.value++;
  }

  static Future<void> clear() async {
    await _box?.delete(_key);
    revision.value++;
  }
}
