import 'package:hive_flutter/hive_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../features/sms/rules/engine/sms_rule_engine.dart';
import '../../features/sms/rules/sms_hive_boxes.dart';
import '../../features/sms/v4/bank_sms_v4_parser.dart';
import '../services/auth_service.dart';
import 'supabase_schema_map.dart';
import '../../data/local/hive_service.dart';

/// PULL-ONLY refresh of admin-managed SMS detection rules.
///
/// sms_template_rules / sms_detection_rules / sms_block_rules are edited by
/// an admin on the backend (admin-write-only RLS; authenticated users may
/// read). The mobile app ONLY fetches and re-caches them into Hive — this is
/// a one-way refresh path, completely separate from the bidirectional
/// user-data sync queue. Nothing here ever writes to those tables.
///
/// Merchant rules remain a separate, genuinely user-owned mobile concept and
/// are NOT touched by this service.
class SmsRulesRefreshService {
  SmsRulesRefreshService._();

  static const _lastRefreshKey = 'sms_rules_last_refresh_at';
  static bool _running = false;

  static SupabaseClient get _db => Supabase.instance.client;

  static DateTime? lastRefreshedAt() {
    if (!Hive.isBoxOpen('settings')) return null;
    final raw = Hive.box('settings').get(_lastRefreshKey)?.toString();
    return raw == null ? null : DateTime.tryParse(raw);
  }

  /// Automatic daily refresh — cheap to call on startup/foreground.
  static Future<void> refreshIfStale() async {
    final last = lastRefreshedAt();
    if (last != null && DateTime.now().difference(last).inHours < 24) return;
    await refreshNow();
  }

  /// Manual refresh (Developer Options action). Returns a per-table count
  /// summary, or null when signed out / offline / failed.
  static Future<Map<String, int>?> refreshNow() async {
    if (_running || !AuthService.isConfigured || !AuthService.isSignedIn) {
      return null;
    }
    _running = true;
    try {
      final counts = <String, int>{};
      counts['templates'] = await _refreshTable(
        SupaTables.smsTemplateRules,
        SmsHiveBoxes.templateRules,
        RuleTableMap.templateToLocal,
      );
      counts['detection'] = await _refreshTable(
        SupaTables.smsDetectionRules,
        SmsHiveBoxes.regexRules,
        RuleTableMap.detectionToLocal,
      );
      counts['block'] = await _refreshTable(
        SupaTables.smsBlockRules,
        SmsHiveBoxes.blockRules,
        RuleTableMap.blockToLocal,
      );

      // Re-initialize the engines so a mid-session refresh takes effect
      // immediately — same init path the app runs at startup, no restart.
      await SmsRuleEngine.init();
      await BankSmsV4Parser.ensureLoaded();

      if (Hive.isBoxOpen('settings')) {
        Hive.box('settings')
            .put(_lastRefreshKey, DateTime.now().toIso8601String());
      }
      return counts;
    } catch (_) {
      return null;
    } finally {
      _running = false;
    }
  }

  /// Full refresh from the authoritative admin tables.
  ///
  /// • Replaces previous **admin-synced** rows (`fromAdmin: true` / non-manual)
  /// • Keeps **user-trained** rules on this device (`isManual: true`)
  /// • Inactive server rows are dropped so admin delete/disable works
  /// • Failed fetch never wipes local data
  static Future<int> _refreshTable(
    String table,
    String boxName,
    Map<String, dynamic> Function(Map<String, dynamic> row) convert,
  ) async {
    final rows = await _db.from(table).select();

    if (!Hive.isBoxOpen(boxName)) {
      await SecureHive.openBox(boxName);
    }
    final box = Hive.box(boxName);

    // Preserve user-trained / local-only rules.
    final keep = <String, Map<String, dynamic>>{};
    for (final key in box.keys) {
      final raw = box.get(key);
      if (raw is! Map) continue;
      final m = Map<String, dynamic>.from(raw);
      final isManual = m['isManual'] == true;
      final fromAdmin = m['fromAdmin'] == true;
      // Keep manual user rules; also keep legacy local rows that were never
      // tagged fromAdmin (bundled seeds / old trainings).
      if (isManual || !fromAdmin) {
        // But if this id is also on the server as an active admin rule, the
        // server copy wins below (same id).
        keep[key.toString()] = m;
      }
    }

    await box.clear();

    // Restore kept local first.
    for (final e in keep.entries) {
      await box.put(e.key, e.value);
    }

    var stored = 0;
    for (final r in rows) {
      final row = Map<String, dynamic>.from(r);
      if (!RuleTableMap.isRowActive(row)) {
        // Admin disabled or soft-removed: ensure local admin copy is gone.
        final id = row['id']?.toString() ?? '';
        if (id.isNotEmpty) {
          final existing = box.get(id);
          if (existing is Map &&
              Map<String, dynamic>.from(existing)['fromAdmin'] == true) {
            await box.delete(id);
          }
        }
        continue;
      }
      final payload = convert(row);
      final id = payload['id']?.toString() ?? '';
      if (id.isEmpty) continue;
      // Server admin rule wins for that id (even over a previous local copy).
      await box.put(id, payload);
      stored++;
    }
    return stored;
  }
}
