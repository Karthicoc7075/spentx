/// Newer `updated_at` wins. Equal timestamps keep the local row so a pull
/// does not rewrite Hive when nothing changed.
class SyncConflict {
  SyncConflict._();

  static DateTime? parse(String? raw) {
    if (raw == null || raw.isEmpty) return null;
    return DateTime.tryParse(raw)?.toUtc();
  }

  /// True when the server row is strictly newer than the local clock.
  ///
  /// No local clock and a real remote clock → remote wins (first pull, or a
  /// web edit the phone has never stamped). No remote clock → local wins.
  static bool remoteIsNewer(String? localUpdatedAt, String? remoteUpdatedAt) {
    final remote = parse(remoteUpdatedAt);
    if (remote == null) return false;
    final local = parse(localUpdatedAt);
    if (local == null) return true;
    return remote.isAfter(local);
  }
}
