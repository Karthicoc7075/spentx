import 'package:supabase_flutter/supabase_flutter.dart';

/// How a failed upload should be treated by an outbox.
enum SyncErrorKind {
  /// Network, timeout, expired session, rate limit: retry later.
  transient,

  /// The server table / column / RPC does not exist yet (migration not run).
  /// Keep the change, retry later, but never block logout over it.
  schemaMissing,

  /// The server will never accept this row as it is (constraint, foreign key,
  /// permission, bad value). Park it so it stops blocking everything behind it.
  permanent,
}

class SyncErrors {
  SyncErrors._();

  static const _schemaMissingCodes = {
    '42P01', // undefined_table
    '42703', // undefined_column
    '42883', // undefined_function
    'PGRST202', // function not found in schema cache
    'PGRST204', // column not found in schema cache
    'PGRST205', // table not found in schema cache
  };

  static const _transientCodes = {
    'PGRST301', // JWT expired / invalid
    'PGRST302',
    '40001', // serialization failure
    '40P01', // deadlock
    '53300', // too many connections
    '57014', // statement timeout
  };

  static SyncErrorKind classify(Object error) {
    if (error is! PostgrestException) return SyncErrorKind.transient;
    final code = (error.code ?? '').toUpperCase();
    final message = error.message.toLowerCase();
    if (_schemaMissingCodes.contains(code) ||
        message.contains('could not find the table') ||
        message.contains('could not find the function') ||
        (message.contains('does not exist') &&
            (message.contains('relation') || message.contains('function')))) {
      return SyncErrorKind.schemaMissing;
    }
    if (_transientCodes.contains(code)) return SyncErrorKind.transient;
    if (code.startsWith('08') || code.startsWith('53') || code.startsWith('57')) {
      return SyncErrorKind.transient;
    }
    if (code.startsWith('22') || // data exception (bad value, overdraw)
        code.startsWith('23') || // integrity: check, FK, unique, not null
        code == '42501' || // RLS / permission denied
        code.startsWith('P0') || // raise exception in RPC (e.g. goal not found)
        code.startsWith('PGRST1')) {
      // PGRST1xx: malformed request
      return SyncErrorKind.permanent;
    }
    return SyncErrorKind.transient;
  }

  /// Short, user-readable reason for a parked change.
  static String describe(Object error) {
    if (error is PostgrestException) {
      final code = error.code == null ? '' : ' (${error.code})';
      final msg = error.message.trim();
      return '${msg.length > 160 ? '${msg.substring(0, 160)}…' : msg}$code';
    }
    final text = error.toString();
    return text.length > 160 ? '${text.substring(0, 160)}…' : text;
  }
}

/// Tables whose migration is not on the server yet, learnt from the last
/// failed sync this app session. Cleared on the next successful sync.
class SyncSchemaStatus {
  SyncSchemaStatus._();

  static final Set<String> _missing = {};

  static bool isMissing(String table) => _missing.contains(table);
  static void markMissing(String table) => _missing.add(table);
  static void markPresent(String table) => _missing.remove(table);
  static void reset() => _missing.clear();
}
