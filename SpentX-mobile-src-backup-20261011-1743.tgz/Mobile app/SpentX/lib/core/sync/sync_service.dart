import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../features/sms/background/background_sms_scheduler.dart';
import '../services/auth_service.dart';
import '../services/auto_detection_native_sync.dart';
import '../services/pin_service.dart';
import 'local_sync_engine.dart';
import 'supabase_schema_map.dart';
import 'sync_clocks.dart';
import 'sync_conflict.dart';
import 'sync_queue.dart';
import 'paged_query.dart';
import 'sync_tables.dart';
import '../services/api_logger.dart';
import '../../data/local/hive_service.dart';
import '../../features/wealth/data/savings_goal_service.dart';
import '../../features/investments/data/investment_service.dart';
import '../../features/wealth/data/snapshot_outbox.dart';
import '../../features/recurring/data/recurring_bill_service.dart';
import '../../features/wealth/data/projector_service.dart';

/// Local-first sync orchestrator — built against the REAL web schema.
///
/// • Hive is ALWAYS the read layer the UI renders from.
/// • Offline writes: Hive first → [SyncQueue] → [pushPending] to Supabase.
/// • Online pull: server is source of truth for the rolling ~1 month window.
///   - Server deletes → remove local (unless still pending offline write)
///   - Local older than window → prune (keeps device light)
///   - Never keep “wrong” stale rows that the server no longer has
/// • Pull never overwrites a row whose local updated_at is newer.
///   A queued edit wins until the server clock is strictly newer.
class SyncService {
  SyncService._();

  /// Settings-box key: earliest date "Load older" has extended the local cache back to.
  static const _extendedCacheSinceKey = 'tx_cache_extended_since';

  static void Function()? onDataChanged;

  /// True once the FIRST [fullSync] attempt in this app session has finished
  /// (success or failure) — used to gate Home's "preparing your data" loading
  /// state so a signed-in user with no local cache yet (fresh login on a new
  /// device) never sees a flash of ₹0 / empty lists before real data lands.
  /// A returning user with existing Hive data never trips this — Home reads
  /// the cache immediately regardless, this only covers the empty-cache case.
  static final ValueNotifier<bool> firstSyncDone = ValueNotifier(false);

  /// Fired when web requested a mobile PIN reset and local PIN was cleared.
  static void Function()? onPinResetApplied;

  /// Fired when [AuthService.verifyAccountStillExists] confirms the signed-in
  /// account no longer exists server-side (admin deleted it). Wired in
  /// main.dart to AppResetService.resetAll() — full sign-out + local wipe —
  /// rather than imported directly here, to avoid a circular import
  /// (AppResetService already imports SyncService for pushPending()).
  static void Function()? onAccountRevoked;

  static bool _revocationCheckInFlight = false;

  static Timer? _periodic;
  static bool _syncing = false;
  static Completer<void>? _syncCompleter;
  static DateTime? _lastPullAt;

  static SupabaseClient get _db => Supabase.instance.client;

  static Future<List<Map<String, dynamic>>> _selectAll(
    PostgrestFilterBuilder<List<Map<String, dynamic>>> Function() query,
  ) => readAllPages((afterId, limit) async {
    var filtered = query();
    if (afterId != null) filtered = filtered.gt('id', afterId);
    return await filtered.order('id').limit(limit);
  });

  static bool get _ready => AuthService.isConfigured && AuthService.isSignedIn;

  static Future<void> start() async {
    if (AuthService.syncHeldForAccountSwitch) return;
    if (!_ready) return;
    await SyncQueue.ensureOpen();
    _periodic?.cancel();
    // Low-end / battery: sync every 30 min (was 15). Push still runs on connect.
    _periodic = Timer.periodic(const Duration(minutes: 30), (_) {
      unawaited(fullSync());
    });
    if (hasNoLocalCache) {
      // Nothing to paint yet anyway (fresh login, no prior Hive data) — Home
      // shows a "preparing your data" state until this resolves, so there's
      // no UI benefit to deferring; waiting would only delay real data.
      unawaited(fullSync());
      return;
    }
    // Returning session with cached data already on screen — defer so the
    // cached UI paints first, then this quietly refreshes it.
    Future<void>.delayed(const Duration(seconds: 3), () {
      if (_ready) unawaited(fullSync());
    });
  }

  static void stop() {
    _periodic?.cancel();
    _periodic = null;
  }

  /// Resets sync state on logout or local data wipe so next login requires initial sync.
  static void resetSyncState() {
    stop();
    _syncCompleter = null;
    _pushInFlight = null;
    _lastFullSyncAt = null;
    firstSyncDone.value = false;
  }

  /// Let already-started work finish before a normal logout erases its boxes.
  static Future<void> waitForIdle() async {
    await _syncCompleter?.future;
    await _pushInFlight;
  }

  static Future<void> onForeground() async {
    if (!_ready) return;
    // Skip full pull if we synced within 15 seconds, otherwise pull latest web changes
    if (_lastPullAt != null &&
        DateTime.now().difference(_lastPullAt!).inSeconds < 15) {
      unawaited(pushPending());
      return;
    }
    await fullSync();
  }

  static DateTime? _lastFullSyncAt;

  /// Full push + pull of all cloud data into Hive.
  ///
  /// [force] — user-initiated (Home pull-to-refresh). Skips the 45s throttle
  /// and always notifies listeners so UI reloads even when server data is
  /// unchanged.
  static Future<void> fullSync({bool force = false}) async {
    if (AuthService.syncHeldForAccountSwitch) return;
    if (!_ready) return;

    // Wait for an in-flight cycle so force refresh still runs after it.
    if (_syncing) {
      if (!force) return;
      await _syncCompleter?.future.timeout(
        const Duration(seconds: 15),
        onTimeout: () {},
      );
      if (_syncing) return;
    }

    // Throttle background/auto sync only — never block a manual refresh.
    if (!force &&
        _lastFullSyncAt != null &&
        DateTime.now().difference(_lastFullSyncAt!).inSeconds < 45) {
      unawaited(pushPending());
      return;
    }

    // Ensure the access token is current BEFORE the pull/push calls below —
    // a stale token here (e.g. right after resuming from an hour+ in the
    // background) would otherwise make every request in this cycle fail on
    // its own, independent of the revocation check just below.
    await AuthService.hasValidSession();

    if (!_revocationCheckInFlight) {
      _revocationCheckInFlight = true;
      unawaited(
        AuthService.verifyAccountStillExists()
            .then((stillExists) {
              _revocationCheckInFlight = false;
              if (!stillExists) onAccountRevoked?.call();
            })
            .catchError((_) {
              _revocationCheckInFlight = false;
            }),
      );
    }

    _syncCompleter = Completer<void>();
    _syncing = true;
    _lastFullSyncAt = DateTime.now();
    final syncStopwatch = Stopwatch()..start();
    try {
      // Reference data first: pushes need account/purpose uuids resolved.
      await _pullAccountsAndPurposes(AuthService.currentUserId!);
      await pushPending();
      await pullAll(forceNotify: force);
      syncStopwatch.stop();
      ApiLogger.logSuccess(
        apiType: 'rpc',
        apiName: 'fullSync',
        method: force ? 'force' : 'auto',
        durationMs: syncStopwatch.elapsedMilliseconds,
      );
    } catch (e) {
      syncStopwatch.stop();
      ApiLogger.logError(
        apiType: 'rpc',
        apiName: 'fullSync',
        method: force ? 'force' : 'auto',
        durationMs: syncStopwatch.elapsedMilliseconds,
        errorMessage: e.toString(),
      );
      // Offline or server error — queue stays intact, next cycle retries.
      // Still notify on manual refresh so local Hive state rebinds to UI.
      if (force) onDataChanged?.call();
    } finally {
      _syncing = false;
      firstSyncDone.value = true;
      if (!(_syncCompleter?.isCompleted ?? true)) {
        _syncCompleter?.complete();
      }
    }
  }

  /// Tombstone guard: prevents locally deleted transactions from being re-added
  /// to Hive if a server pull arrives before Supabase delete completes.
  static final Map<String, DateTime> _recentlyDeletedTxIds = {};

  static void recordLocalDelete(String id) {
    if (id.isEmpty) return;
    _recentlyDeletedTxIds[id] = DateTime.now();
    final cutoff = DateTime.now().subtract(const Duration(seconds: 60));
    _recentlyDeletedTxIds.removeWhere((_, time) => time.isBefore(cutoff));
  }

  static bool isRecentlyDeletedLocally(String id) {
    if (id.isEmpty) return false;
    final time = _recentlyDeletedTxIds[id];
    if (time == null) return false;
    if (DateTime.now().difference(time).inSeconds > 60) {
      _recentlyDeletedTxIds.remove(id);
      return false;
    }
    return true;
  }

  /// Fast targeted single-transaction sync (<100ms) without 15-table sequential pull.
  static Future<void> applySingleTransactionChange({
    required String op,
    required String id,
    Map<String, dynamic>? serverRow,
  }) async {
    if (!_ready || id.isEmpty) return;

    if (op == 'delete') {
      recordLocalDelete(id);
      final changed = _removeLocalTransaction(id);
      if (changed) onDataChanged?.call();
      return;
    }

    if (isRecentlyDeletedLocally(id)) return;

    final uid = AuthService.currentUserId!;
    try {
      final Map<String, dynamic>? row =
          serverRow != null && serverRow.isNotEmpty
              ? serverRow
              : await _db
                  .from(SupaTables.transactions)
                  .select()
                  .eq('id', id)
                  .eq('user_id', uid)
                  .maybeSingle();

      if (row == null) return;
      if (row[TransactionMap.isActive] == false || row['deleted_at'] != null) {
        final changed = _removeLocalTransaction(id);
        if (changed) onDataChanged?.call();
        return;
      }

      final splitRows = await _db
          .from(SupaTables.transactionSplits)
          .select()
          .eq('transaction_id', id)
          .eq('user_id', uid);

      final splitsList =
          (splitRows as List)
              .map((s) => Map<String, dynamic>.from(s as Map))
              .toList();

      if (!Hive.isBoxOpen('transactions')) return;
      final box = Hive.box('transactions');
      final List<dynamic> raw = box.get('list', defaultValue: []);
      final local =
          raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();

      final mapped = TransactionMap.toLocal(
        row,
        splitsList.isNotEmpty ? splitsList.first : null,
        splitCount: splitsList.isNotEmpty ? splitsList.length : 1,
        allSplits: splitsList,
      );

      final existingIndex = local.indexWhere((t) {
        final lid = t['id']?.toString() ?? '';
        final rid = t['remoteId']?.toString() ?? '';
        return lid == id || rid == id;
      });

      if (existingIndex >= 0) {
        mapped['id'] = local[existingIndex]['id'];
        local[existingIndex] = mapped;
      } else {
        local.insert(0, mapped);
      }

      local.sort(
        (a, b) => (b['date'] ?? '').toString().compareTo(
          (a['date'] ?? '').toString(),
        ),
      );
      box.put('list', local);
      onDataChanged?.call();
    } catch (_) {
      unawaited(syncTransactionsLive(uid));
    }
  }

  static bool _removeLocalTransaction(String id) {
    if (!Hive.isBoxOpen('transactions')) return false;
    final box = Hive.box('transactions');
    final List<dynamic> raw = box.get('list', defaultValue: []);
    final before = raw.length;
    final local =
        raw.where((t) {
          if (t is! Map) return true;
          final lid = t['id']?.toString() ?? '';
          final rid = t['remoteId']?.toString() ?? '';
          return lid != id && rid != id;
        }).toList();
    if (local.length != before) {
      box.put('list', local);
      return true;
    }
    return false;
  }

  /// Fast targeted sync for real-time transaction updates from Web (under 150ms).
  /// Pulls the latest 30 transactions only (never full historical table or pagination).
  static Future<void> syncTransactionsLive(String uid) async {
    if (!_ready || AuthService.syncHeldForAccountSwitch) return;
    try {
      final rows = await _db
          .from(SupaTables.transactions)
          .select()
          .eq(TransactionMap.userId, uid)
          .eq(TransactionMap.isActive, true)
          .order('updated_at', ascending: false)
          .limit(30);

      final changed = await _mergeTransactionRows(
        rows,
        uid,
        reconcileWindow: false,
        honorDeletes: false,
      );
      if (changed) {
        onDataChanged?.call();
      }
    } catch (_) {}
  }

  /// Fast targeted sync for real-time outing updates from Web (<200ms).
  static Future<void> syncOutingsLive(String uid) async {
    if (!_ready || AuthService.syncHeldForAccountSwitch) return;
    try {
      final changedOutings = await _pullOutings(uid);
      final changedCats = await _pullOutingCategories(uid);
      if (changedOutings || changedCats) {
        onDataChanged?.call();
      }
    } catch (_) {}
  }

  /// Fast targeted sync for real-time friend/split updates from Web (<200ms).
  static Future<void> syncFriendsLive(String uid) async {
    if (!_ready || AuthService.syncHeldForAccountSwitch) return;
    try {
      final changedFriends = await _pullFriends(uid);
      final changedSplits = await _pullFriendSplits(uid);
      if (changedFriends || changedSplits) {
        onDataChanged?.call();
      }
    } catch (_) {}
  }

  /// Fast targeted sync for real-time monthly plan updates from Web (<200ms).
  static Future<void> syncPlansLive(String uid) async {
    if (!_ready || AuthService.syncHeldForAccountSwitch) return;
    try {
      final changed = await _pullMonthlyPlans(uid);
      if (changed) {
        onDataChanged?.call();
      }
    } catch (_) {}
  }

  /// Fast targeted sync for real-time account updates from Web (<200ms).
  static Future<void> syncAccountsLive(String uid) async {
    if (!_ready || AuthService.syncHeldForAccountSwitch) return;
    try {
      final changed = await _pullAccountsAndPurposes(uid);
      if (changed) {
        onDataChanged?.call();
      }
    } catch (_) {}
  }

  /// Fast targeted sync for real-time investment/savings updates from Web (<200ms).
  static Future<void> syncInvestmentsLive(String uid) async {
    if (!_ready || AuthService.syncHeldForAccountSwitch) return;
    try {
      await ProjectorService.fetchSettings();
      await SavingsGoalService.fetchSavingsGoals();
      await InvestmentService.fetch();
      onDataChanged?.call();
    } catch (_) {}
  }

  static void broadcastEntitySync(
    String uid, {
    required String event,
    required String op,
    String? id,
  }) {
    try {
      _db
          .channel('user-sync:$uid')
          .sendBroadcastMessage(
            event: event,
            payload: {
              'op': op,
              if (id != null) 'id': id,
              'source': 'mobile',
              'time': DateTime.now().millisecondsSinceEpoch,
            },
          );
    } catch (_) {}
  }

  static void _broadcastTransactionSync(
    String uid, {
    required String op,
    required String id,
  }) {
    broadcastEntitySync(uid, event: 'transaction-changed', op: op, id: id);
  }

  /// True when there's nothing meaningful in the local cache yet — a fresh
  /// login on a device with no prior Hive data for this (or any) account.
  /// Accounts live in settings['onboardingAccounts'], not a dedicated box
  /// (see [_pullAccountsAndPurposes]) — mirror that storage shape here.
  static bool get hasNoLocalCache {
    if (!Hive.isBoxOpen('transactions') || !Hive.isBoxOpen('settings')) {
      return true;
    }
    final txCount =
        (Hive.box('transactions').get('list', defaultValue: const []) as List)
            .length;
    final accounts =
        Hive.box('settings').get('onboardingAccounts', defaultValue: const [])
            as List;
    return txCount == 0 && accounts.isEmpty;
  }

  // ───────────────────────────── PUSH ─────────────────────────────

  /// Last push error (settings) so Developer Options / debug can show why
  /// mobile → server writes are stuck.
  static const lastPushErrorKey = 'sync_last_push_error';
  static const lastPushAtKey = 'sync_last_push_at';
  static const lastPushOkKey = 'sync_last_push_ok';

  /// Dependency order: accounts/purposes before txs; outings before tx
  /// outing_id links; outings after txs when expenses link transactions —
  /// we push outings before txs, and expense links fall back if tx missing.
  static int _pushPriority(Map<String, dynamic> entry) {
    switch (entry['entity']?.toString()) {
      case SyncEntity.account:
      case SyncEntity.purpose:
        return 0;
      case SyncEntity.contributor:
      case SyncEntity.category:
      case SyncEntity.outingCategory:
        return 1;
      case SyncEntity.friend:
      case SyncEntity.friendDelete:
      case SyncEntity.userMerchant:
      case SyncEntity.userSettings:
        return 2;
      case SyncEntity.outing:
        return 3;
      case SyncEntity.transaction:
        return 4;
      // FK to transactions.id — must push after the transaction lands.
      case SyncEntity.friendSplit:
        return 5;
      case SyncEntity.monthlyPlan:
        return 6;
      default:
        return 9;
    }
  }

  static void _recordPushResult({String? error, String? entity}) {
    if (!Hive.isBoxOpen('settings')) return;
    final box = Hive.box('settings');
    box.put(lastPushAtKey, DateTime.now().toIso8601String());
    if (error == null) {
      box.put(lastPushOkKey, true);
      box.put(lastPushErrorKey, null);
    } else {
      box.put(lastPushOkKey, false);
      box.put(
        lastPushErrorKey,
        '${entity ?? '?'}: ${error.length > 400 ? error.substring(0, 400) : error}',
      );
    }
  }

  static Future<void>? _pushInFlight;
  static bool _pushNeedsRerun = false;

  static Future<void> pushPending() async {
    if (_pushInFlight != null) {
      _pushNeedsRerun = true;
      await _pushInFlight;
      return;
    }
    final completer = Completer<void>();
    _pushInFlight = completer.future;
    try {
      do {
        _pushNeedsRerun = false;
        await _pushPending();
      } while (_pushNeedsRerun);
      if (!completer.isCompleted) {
        completer.complete();
      }
    } catch (e, st) {
      if (!completer.isCompleted) {
        completer.completeError(e, st);
      }
      rethrow;
    } finally {
      _pushInFlight = null;
    }
  }

  static Future<void> _pushPending() async {
    if (AuthService.syncHeldForAccountSwitch) return;
    if (!_ready) return;
    final uid = AuthService.currentUserId!;
    final items =
        SyncQueue.items()..sort((a, b) {
          final p = _pushPriority(a).compareTo(_pushPriority(b));
          if (p != 0) return p;
          // FIFO by outbox updated_at within the same dependency group.
          final ua = (a['updated_at'] ?? a['at'] ?? '').toString();
          final ub = (b['updated_at'] ?? b['at'] ?? '').toString();
          return ua.compareTo(ub);
        });

    var anySuccess = false;
    String? lastError;
    String? lastEntity;

    for (final entry in items) {
      if (AuthService.syncHeldForAccountSwitch ||
          AuthService.currentUserId != uid)
        return;
      final entity = entry['entity']?.toString();
      final entryId = entry['id']?.toString() ?? '';
      try {
        await _pushEntry(entry, uid);
        SyncQueue.remove(entryId);
        anySuccess = true;
      } catch (e) {
        lastError = e.toString();
        lastEntity = entity;
        SyncQueue.recordAttempt(entryId);
        // Network, authorization, and validation errors all remain durable.
        // A later retry or edit can recover the write; never evict user data.
      }
    }

    if (anySuccess && lastError == null) {
      _recordPushResult();
    } else if (lastError != null) {
      _recordPushResult(error: lastError, entity: lastEntity);
    } else if (items.isEmpty) {
      _recordPushResult();
    }
  }

  /// After a successful upsert, store remoteId on the Hive row so offline
  /// update/delete always target the same server id.
  static void _stampLocalTransactionRemoteId(String localId, String remoteId) {
    if (!Hive.isBoxOpen('transactions') || remoteId.isEmpty) return;
    final box = Hive.box('transactions');
    final List<dynamic> raw = box.get('list', defaultValue: []);
    var changed = false;
    final next =
        raw.map((e) {
          final m = Map<String, dynamic>.from(e as Map);
          if (m['id']?.toString() == localId) {
            if (m['remoteId']?.toString() != remoteId) {
              m['remoteId'] = remoteId;
              changed = true;
            }
          }
          return m;
        }).toList();
    if (changed) box.put('list', next);
  }

  /// Resolves (creating remotely if needed) the accounts.id for a local
  /// account name — transactions.account_id is a NOT NULL FK.
  ///
  /// IMPORTANT: web seed accounts use random UUIDs. Always look up by name
  /// before inserting a deterministic id, or we create orphan/dupe accounts
  /// and break net-worth parity.
  static Future<String> _resolveRemoteAccountId(
    String uid,
    String accountName,
  ) async {
    final name = accountName.trim().isEmpty ? 'Cash' : accountName.trim();
    final cached = RemoteIdCache.accountId(name);
    if (cached != null) return cached;

    // Case-insensitive name match against active server rows.
    try {
      final rows = await _db
          .from(SupaTables.accounts)
          .select('${AccountMap.id},${AccountMap.name}')
          .eq(AccountMap.userId, uid)
          .eq(AccountMap.isActive, true);
      final target = name.toLowerCase();
      for (final r in rows) {
        final n = (r[AccountMap.name] ?? '').toString();
        if (n.trim().toLowerCase() == target) {
          final id = r[AccountMap.id].toString();
          RemoteIdCache.putAccount(name, id);
          // Also cache under server casing for later pulls.
          if (n != name) RemoteIdCache.putAccount(n, id);
          return id;
        }
      }
    } catch (_) {
      // Fall through to create.
    }

    final newId = SyncIds.forAccount(uid, name);
    final isCash = name.toLowerCase() == 'cash';
    await _db.from(SupaTables.accounts).upsert({
      AccountMap.id: newId,
      AccountMap.userId: uid,
      AccountMap.name: name,
      AccountMap.type: isCash ? 'cash' : 'bank',
      AccountMap.openingBalance: 0,
      AccountMap.isActive: true,
    });
    RemoteIdCache.putAccount(name, newId);
    return newId;
  }

  static Future<String> _resolveRemotePurposeId(
    String uid,
    String purposeName,
  ) async {
    final name = purposeName.trim().isEmpty ? 'Personal' : purposeName.trim();
    final cached = RemoteIdCache.purposeId(name);
    if (cached != null) return cached;

    // Prefer existing web row (random UUID from bootstrap) over inventing one.
    try {
      final rows = await _db
          .from(SupaTables.purposes)
          .select('${PurposeMap.id},${PurposeMap.name}')
          .eq(PurposeMap.userId, uid)
          .eq(PurposeMap.isActive, true);
      final target = name.toLowerCase();
      for (final r in rows) {
        final n = (r[PurposeMap.name] ?? '').toString();
        if (n.trim().toLowerCase() == target) {
          final id = r[PurposeMap.id].toString();
          RemoteIdCache.putPurpose(name, id);
          if (n != name) RemoteIdCache.putPurpose(n, id);
          return id;
        }
      }
    } catch (_) {}

    final remote = PurposeMap.toRemote(name, uid);
    await _db.from(SupaTables.purposes).upsert(remote);
    final newId = remote[PurposeMap.id].toString();
    RemoteIdCache.putPurpose(name, newId);
    return newId;
  }

  static Future<void> _pushEntry(Map<String, dynamic> entry, String uid) async {
    final entity = entry['entity']?.toString();
    final op = entry['op']?.toString();
    final localId = entry['localId']?.toString() ?? '';
    final payload =
        entry['payload'] is Map
            ? Map<String, dynamic>.from(entry['payload'] as Map)
            : <String, dynamic>{};

    switch (entity) {
      case SyncEntity.transaction:
        if (op == SyncOp.delete) {
          // Prefer remoteId from queue payload (set at delete time) so offline
          // deletes hit the same Supabase row as the original create/update.
          final remoteId =
              (payload['remoteId']?.toString().trim().isNotEmpty == true)
                  ? payload['remoteId'].toString()
                  : SyncIds.forTransaction(uid, localId);
          final deletedAt =
              (entry['updated_at'] ?? DateTime.now().toUtc().toIso8601String())
                  .toString();
          try {
            // Soft delete when 20260736 columns exist. Web and phone both
            // hide rows with is_active = false / deleted_at set.
            await _db
                .from(SupaTables.transactions)
                .update({
                  TransactionMap.isActive: false,
                  'deleted_at': deletedAt,
                })
                .eq(TransactionMap.id, remoteId)
                .eq(TransactionMap.userId, uid);
          } catch (e) {
            if (!_isMissingColumn(e.toString())) rethrow;
            await _db
                .from(SupaTables.transactionSplits)
                .delete()
                .eq('transaction_id', remoteId)
                .eq('user_id', uid);
            await _db
                .from(SupaTables.transactions)
                .delete()
                .eq(TransactionMap.id, remoteId)
                .eq(TransactionMap.userId, uid);
          }
          _broadcastTransactionSync(uid, op: 'delete', id: remoteId);
        } else {
          final accountId = await _resolveRemoteAccountId(
            uid,
            (payload['account'] ?? 'Cash').toString(),
          );
          final purposeId = await _resolveRemotePurposeId(
            uid,
            (payload['purpose'] ?? 'Personal').toString(),
          );
          final isExpense = payload['isExpense'] ?? true;
          final contributorId =
              isExpense == true
                  ? null
                  : await _resolveRemoteContributorId(
                    uid,
                    payload['contributorSource']?.toString(),
                  );
          final localTransferType = payload['transferType']?.toString();
          final isNewTransfer =
              localTransferType != null && localTransferType.isNotEmpty;
          final remoteToAccountId =
              isNewTransfer
                  ? await _resolveRemoteAccountId(
                    uid,
                    (payload['transferTo'] ?? '').toString(),
                  )
                  : null;
          final remoteRow = TransactionMap.toRemote(
            payload,
            uid,
            accountId,
            remoteToAccountId: remoteToAccountId,
          );
          final remoteTxId = remoteRow[TransactionMap.id].toString();
          await _upsertTransactionWithOutingFallback(remoteRow);

          // A transfer has no purpose/category/splits — the web create_transfer
          // RPC deliberately writes zero transaction_splits rows for it (see
          // supabase/migrations/20260755_transfer_transactions.sql), so mobile
          // must not push one either.
          if (isNewTransfer) {
            _stampLocalTransactionRemoteId(localId, remoteTxId);
            break;
          }

          // Real multi-row Split Expense created/edited on mobile — push every
          // row and prune any remote row no longer present locally. This is
          // the authoritative case: mobile just wrote these rows, so it owns
          // them (unlike the single-row branch below, which must be careful
          // not to clobber a multi-split authored by web).
          final localSplits =
              (payload['splits'] as List?)?.whereType<Map>().toList() ??
              const [];
          if (localSplits.length > 1) {
            final keepIds = <String>[];
            for (var i = 0; i < localSplits.length; i++) {
              final row = Map<String, dynamic>.from(localSplits[i]);
              final rowPurposeId = await _resolveRemotePurposeId(
                uid,
                (row['purposeId'] ?? 'Personal').toString(),
              );
              final remoteSplit = TransactionMap.splitToRemote(
                payload,
                uid,
                rowPurposeId,
                remoteContributorId: contributorId,
                rowIndex: i,
                rowCategory: row['categoryId']?.toString(),
                rowAmount: (row['amount'] as num?)?.toDouble(),
              );
              await _db.from(SupaTables.transactionSplits).upsert(remoteSplit);
              keepIds.add(remoteSplit['id'].toString());
            }
            await _deleteMissingChildren(
              table: SupaTables.transactionSplits,
              parentCol: 'transaction_id',
              parentId: remoteTxId,
              uid: uid,
              keepIds: keepIds,
            );
          } else {
            // Never collapse a multi-split web expense to a single split when
            // mobile only holds one purpose/category (BUG-SP-01).
            var remoteSplitCount = 0;
            try {
              final existing = await _db
                  .from(SupaTables.transactionSplits)
                  .select('id')
                  .eq('transaction_id', remoteTxId)
                  .eq('user_id', uid);
              remoteSplitCount = existing.length;
            } catch (_) {}

            if (remoteSplitCount > 1) {
              // Leave web-authored split rows intact; parent total_amount
              // already updated above.
            } else {
              await _db
                  .from(SupaTables.transactionSplits)
                  .upsert(
                    TransactionMap.splitToRemote(
                      payload,
                      uid,
                      purposeId,
                      remoteContributorId: contributorId,
                    ),
                  );
            }
          }

          // Items (Title / Itemization) — independent of splits, mobile is
          // always authoritative for its own local item rows.
          final localItems =
              (payload['items'] as List?)?.whereType<Map>().toList() ??
              const [];
          final itemKeepIds = <String>[];
          for (var i = 0; i < localItems.length; i++) {
            final row = Map<String, dynamic>.from(localItems[i]);
            final name = (row['name'] ?? '').toString().trim();
            final itemAmount = (row['amount'] as num?)?.toDouble() ?? 0;
            if (name.isEmpty || itemAmount <= 0) continue;
            final remoteItem = TransactionMap.itemToRemote(
              payload,
              uid,
              rowIndex: i,
              rowName: name,
              rowCategory: row['categoryId']?.toString(),
              rowAmount: itemAmount,
            );
            await _db.from(SupaTables.transactionItems).upsert(remoteItem);
            itemKeepIds.add(remoteItem['id'].toString());
          }
          await _deleteMissingChildren(
            table: SupaTables.transactionItems,
            parentCol: 'transaction_id',
            parentId: remoteTxId,
            uid: uid,
            keepIds: itemKeepIds,
          );

          // Remember remote id locally so later offline update/delete is exact.
          _stampLocalTransactionRemoteId(localId, remoteTxId);
          _broadcastTransactionSync(uid, op: 'upsert', id: remoteTxId);
        }
        break;

      case SyncEntity.account:
        if (op == SyncOp.delete) {
          // Soft delete (transactions FK is RESTRICT — hard delete would fail
          // for any account with history). deleted_at is on accounts in init.sql.
          final deletedAt =
              (entry['updated_at'] ?? DateTime.now().toUtc().toIso8601String())
                  .toString();
          final payload =
              entry['payload'] is Map
                  ? Map<String, dynamic>.from(entry['payload'] as Map)
                  : <String, dynamic>{};
          final targetId =
              payload['id']?.toString() ??
              (localId.contains('-') && localId.length >= 32 ? localId : null);
          final name = (payload['name'] ?? localId).toString();
          final onlyIfNoOthers = payload['onlyIfNoOthers'] == true;

          try {
            if (targetId != null && targetId.isNotEmpty) {
              await _db
                  .from(SupaTables.accounts)
                  .update({AccountMap.isActive: false, 'deleted_at': deletedAt})
                  .eq(AccountMap.userId, uid)
                  .eq(AccountMap.id, targetId);
            } else if (!onlyIfNoOthers) {
              await _db
                  .from(SupaTables.accounts)
                  .update({AccountMap.isActive: false, 'deleted_at': deletedAt})
                  .eq(AccountMap.userId, uid)
                  .eq(AccountMap.name, name);
            }
          } catch (e) {
            if (!_isMissingColumn(e.toString())) rethrow;
            if (targetId != null && targetId.isNotEmpty) {
              await _db
                  .from(SupaTables.accounts)
                  .update({AccountMap.isActive: false})
                  .eq(AccountMap.userId, uid)
                  .eq(AccountMap.id, targetId);
            } else if (!onlyIfNoOthers) {
              await _db
                  .from(SupaTables.accounts)
                  .update({AccountMap.isActive: false})
                  .eq(AccountMap.userId, uid)
                  .eq(AccountMap.name, name);
            }
          }
          broadcastEntitySync(
            uid,
            event: 'account-changed',
            op: 'delete',
            id: targetId,
          );
        } else {
          final name = (payload['name'] ?? localId).toString();
          // Look up web UUID by name first (bootstrap uses random ids).
          final remoteId = await _resolveRemoteAccountId(uid, name);
          await _db
              .from(SupaTables.accounts)
              .upsert(AccountMap.toRemote(payload, uid, remoteId));
          RemoteIdCache.putAccount(name, remoteId);
          broadcastEntitySync(
            uid,
            event: 'account-changed',
            op: 'upsert',
            id: remoteId,
          );
        }
        break;

      case SyncEntity.outing:
        if (op == SyncOp.delete) {
          // Soft-deletes the outing AND its transactions/outing_expenses/
          // settlements atomically, fully restorable via [restoreOuting].
          await _db.rpc(
            'cascade_delete_outing',
            params: {'p_outing_id': localId, 'p_user_id': uid},
          );
          broadcastEntitySync(
            uid,
            event: 'outing-changed',
            op: 'delete',
            id: localId,
          );
        } else {
          await _pushOutingDocument(payload, uid);
          broadcastEntitySync(
            uid,
            event: 'outing-changed',
            op: 'upsert',
            id: localId,
          );
        }
        break;

      case SyncEntity.friendSplit:
        if (op == SyncOp.delete) {
          // Soft delete. friend_splits.deleted_at already exists. Hard delete
          // remains the fallback so a database without that column still drops
          // the row (and cascades friend_settlements). The linked transaction
          // is never touched.
          final remoteId = SyncIds.forFriendSplit(uid, localId);
          final deletedAt =
              (entry['updated_at'] ?? DateTime.now().toUtc().toIso8601String())
                  .toString();
          try {
            await _db
                .from(SupaTables.friendSplits)
                .update({'is_active': false, 'deleted_at': deletedAt})
                .eq('id', remoteId)
                .eq('user_id', uid);
          } catch (e) {
            if (!_isMissingColumn(e.toString())) rethrow;
            await _db
                .from(SupaTables.friendSplits)
                .delete()
                .eq('id', remoteId)
                .eq('user_id', uid);
          }
          broadcastEntitySync(
            uid,
            event: 'friend-changed',
            op: 'delete',
            id: localId,
          );
        } else {
          await _pushFriendSplitDocument(payload, uid);
          broadcastEntitySync(
            uid,
            event: 'friend-changed',
            op: 'upsert',
            id: localId,
          );
        }
        break;

      case SyncEntity.friend:
        await _db
            .from(SupaTables.friends)
            .upsert(FriendMap.toRemote(payload, uid));
        broadcastEntitySync(
          uid,
          event: 'friend-changed',
          op: 'upsert',
          id: localId,
        );
        break;

      case SyncEntity.friendDelete:
        final deletedAt =
            (entry['updated_at'] ?? DateTime.now().toUtc().toIso8601String())
                .toString();
        // Friends made on the web have random ids, not the name-derived id
        // the phone computes, so also match this user's friend by name
        // (case-insensitive, exact). Either way only this user's row changes.
        final friendNamePattern = localId
            .replaceAll(r'\', r'\\')
            .replaceAll('%', r'\%')
            .replaceAll('_', r'\_');
        // Prefer the stored server id: a renamed friend keeps the id derived
        // from its OLD name, so deriving from this name could hit another row.
        final storedFriendId = payload['id']?.toString() ?? '';
        final friendRowId =
            SyncIds.isUuid(storedFriendId)
                ? storedFriendId
                : SyncIds.forFriend(uid, localId);
        Future<void> softDeleteFriend(Map<String, dynamic> patch) async {
          await _db
              .from(SupaTables.friends)
              .update(patch)
              .eq(FriendMap.id, friendRowId)
              .eq(FriendMap.userId, uid);
          await _db
              .from(SupaTables.friends)
              .update(patch)
              .eq(FriendMap.userId, uid)
              .eq(FriendMap.isActive, true)
              .ilike(FriendMap.name, friendNamePattern);
        }
        try {
          await softDeleteFriend({
            FriendMap.isActive: false,
            'deleted_at': deletedAt,
          });
        } catch (e) {
          if (!_isMissingColumn(e.toString())) rethrow;
          await softDeleteFriend({FriendMap.isActive: false});
        }
        broadcastEntitySync(
          uid,
          event: 'friend-changed',
          op: 'delete',
          id: localId,
        );
        break;

      case SyncEntity.purpose:
        final deletedAt =
            (entry['updated_at'] ?? DateTime.now().toUtc().toIso8601String())
                .toString();
        if (op == SyncOp.delete) {
          try {
            await _db
                .from(SupaTables.purposes)
                .update({PurposeMap.isActive: false, 'deleted_at': deletedAt})
                .eq(PurposeMap.userId, uid)
                .eq(PurposeMap.name, localId);
          } catch (e) {
            if (!_isMissingColumn(e.toString())) rethrow;
            await _db
                .from(SupaTables.purposes)
                .update({PurposeMap.isActive: false})
                .eq(PurposeMap.userId, uid)
                .eq(PurposeMap.name, localId);
          }
        } else {
          final remote = PurposeMap.toRemote(
            (payload['name'] ?? localId).toString(),
            uid,
          );
          await _db.from(SupaTables.purposes).upsert(remote);
          RemoteIdCache.putPurpose(
            (payload['name'] ?? localId).toString(),
            remote[PurposeMap.id].toString(),
          );
        }
        break;

      case SyncEntity.userSettings:
        final update = <String, dynamic>{};
        if (payload.containsKey('private_mode')) {
          update[UserRowMap.privateMode] = payload['private_mode'];
        }
        if (payload.containsKey('default_account')) {
          final accName = payload['default_account']?.toString();
          if (accName != null && accName.isNotEmpty) {
            update[UserRowMap.defaultAccountId] = await _resolveRemoteAccountId(
              uid,
              accName,
            );
          }
        }
        if (update.isNotEmpty) {
          await _db
              .from(SupaTables.users)
              .update(update)
              .eq(UserRowMap.id, uid);
        }
        break;

      case SyncEntity.userMerchant:
        if (op == SyncOp.delete) {
          final norm =
              (payload['normalizedPayee'] ?? localId)
                  .toString()
                  .trim()
                  .toLowerCase();
          final remoteId =
              SyncIds.isUuid(localId)
                  ? localId
                  : SyncIds.forMerchant(uid, norm.isNotEmpty ? norm : localId);
          await _db
              .from(SupaTables.userMerchants)
              .delete()
              .eq(UserMerchantMap.id, remoteId)
              .eq(UserMerchantMap.userId, uid);
        } else {
          await _db
              .from(SupaTables.userMerchants)
              .upsert(UserMerchantMap.toRemote(payload, uid));
        }
        break;

      case SyncEntity.contributor:
        if (op == SyncOp.delete) {
          final remoteId =
              SyncIds.isUuid(localId)
                  ? localId
                  : SyncIds.forContributor(
                    uid,
                    (payload['name'] ?? localId).toString(),
                  );
          final deletedAt =
              (entry['updated_at'] ?? DateTime.now().toUtc().toIso8601String())
                  .toString();
          try {
            await _db
                .from(SupaTables.contributors)
                .update({
                  ContributorMap.isActive: false,
                  'deleted_at': deletedAt,
                })
                .eq(ContributorMap.id, remoteId)
                .eq(ContributorMap.userId, uid);
          } catch (e) {
            if (!_isMissingColumn(e.toString())) rethrow;
            await _db
                .from(SupaTables.contributors)
                .update({ContributorMap.isActive: false})
                .eq(ContributorMap.id, remoteId)
                .eq(ContributorMap.userId, uid);
          }
        } else {
          final remote = ContributorMap.toRemote(payload, uid);
          await _db.from(SupaTables.contributors).upsert(remote);
          final name = (payload['name'] ?? '').toString();
          if (name.isNotEmpty) {
            RemoteIdCache.putContributor(
              name,
              remote[ContributorMap.id].toString(),
            );
          }
        }
        break;

      case SyncEntity.category:
        if (op == SyncOp.upsert) {
          final name = (payload['name'] ?? '').toString();
          final type = (payload['type'] ?? 'expense').toString();
          if (name.isEmpty) break;
          final remote = CategoryMap.toRemote(uid, name: name, type: type);
          await _db.from(SupaTables.categories).upsert(remote);
        }
        break;

      case SyncEntity.outingCategory:
        if (op == SyncOp.upsert) {
          final name = (payload['name'] ?? localId).toString().trim();
          if (name.isEmpty) break;
          // Insert; unique (user_id, lower(name)) prevents dups.
          try {
            await _db.from(SupaTables.outingCategories).insert({
              'user_id': uid,
              'name': name,
              'sort_order': payload['sort_order'] ?? 50,
              'is_system': false,
            });
          } catch (_) {
            // Already exists — ignore
          }
        }
        break;

      case SyncEntity.monthlyPlan:
        if (op == SyncOp.delete) {
          await _deleteMonthlyPlan(payload, localId, uid);
          broadcastEntitySync(
            uid,
            event: 'plan-changed',
            op: 'delete',
            id: localId,
          );
        } else {
          await _pushMonthlyPlan(payload, uid, localId: localId);
          broadcastEntitySync(
            uid,
            event: 'plan-changed',
            op: 'upsert',
            id: localId,
          );
        }
        break;
    }
  }

  static Future<void> _deleteMonthlyPlan(
    Map<String, dynamic> payload,
    String localId,
    String uid,
  ) async {
    final remoteId = await _resolveMonthlyPlanRemoteId(
      uid: uid,
      localId: localId,
      payload: payload,
    );
    if (remoteId.isEmpty) return;
    await _db
        .from(SupaTables.monthlyPlans)
        .delete()
        .eq('id', remoteId)
        .eq('user_id', uid);
  }

  static Future<String> _resolveMonthlyPlanRemoteId({
    required String uid,
    required String localId,
    required Map<String, dynamic> payload,
  }) async {
    final fromPayload = (payload['remoteId'] ?? payload['id'] ?? '').toString();
    if (SyncIds.isUuid(fromPayload)) return fromPayload;
    if (SyncIds.isUuid(localId)) return localId;

    final month = (payload['month'] ?? '').toString();
    final purposeName = (payload['purposeName'] ?? 'Personal').toString();
    if (month.isNotEmpty) {
      final deterministic = SyncIds.forPlan(uid, month, purposeName);
      // Prefer an existing server row for this month+purpose over inventing
      // a second primary key that would miss the delete/upsert target.
      try {
        final purposeId = await _resolveRemotePurposeId(uid, purposeName);
        final rows = await _db
            .from(SupaTables.monthlyPlans)
            .select('id')
            .eq('user_id', uid)
            .eq('month', month)
            .eq('purpose_id', purposeId)
            .limit(1);
        if (rows.isNotEmpty) {
          final id = rows.first['id']?.toString() ?? '';
          if (SyncIds.isUuid(id)) return id;
        }
      } catch (_) {}
      return deterministic;
    }
    return fromPayload.isNotEmpty ? fromPayload : localId;
  }

  static void _stampLocalPlanRemoteId(String localId, String remoteId) {
    if (!Hive.isBoxOpen('monthly_plans') ||
        localId.isEmpty ||
        remoteId.isEmpty) {
      return;
    }
    final box = Hive.box('monthly_plans');
    final raw = box.get('list', defaultValue: <dynamic>[]);
    if (raw is! List) return;
    var changed = false;
    final now = DateTime.now().toUtc().toIso8601String();
    final next = <Map<String, dynamic>>[];
    for (final e in raw) {
      if (e is! Map) continue;
      final m = Map<String, dynamic>.from(e);
      if (m['id']?.toString() == localId) {
        if (m['remoteId']?.toString() != remoteId) {
          m['remoteId'] = remoteId;
          changed = true;
        }
        m['updatedAt'] = m['updatedAt'] ?? now;
        m['updated_at'] = m['updated_at'] ?? now;
      }
      next.add(m);
    }
    if (changed) box.put('list', next);
  }

  static Future<void> _pushMonthlyPlan(
    Map<String, dynamic> local,
    String uid, {
    String? localId,
  }) async {
    final month = (local['month'] ?? '').toString();
    if (month.isEmpty) return;
    final purposeName = (local['purposeName'] ?? 'Personal').toString();
    final purposeId = await _resolveRemotePurposeId(uid, purposeName);
    final resolvedLocalId = (localId ?? local['id'] ?? '').toString();
    var remoteId = await _resolveMonthlyPlanRemoteId(
      uid: uid,
      localId: resolvedLocalId,
      payload: local,
    );

    final allocs = <Map<String, dynamic>>[];
    var allocTotal = 0.0;
    final rawAlloc = local['allocations'];
    if (rawAlloc is List) {
      for (final e in rawAlloc) {
        if (e is! Map) continue;
        final m = Map<String, dynamic>.from(e);
        final category = (m['category'] ?? 'Other').toString();
        final id = m['id']?.toString() ?? '';
        if (id == '_spentx_plan_meta' || category == '_spentx_plan_meta') {
          continue;
        }
        final planned =
            (m['plannedAmount'] as num? ?? m['planned_amount'] as num? ?? 0)
                .toDouble();
        allocTotal += planned;
        allocs.add({
          'id': id,
          'category': category,
          'plannedAmount': planned,
          if (m['color'] != null) 'color': m['color'],
          if (m['rollover'] != null) 'rollover': m['rollover'],
        });
      }
    }
    allocs.add({
      'id': '_spentx_plan_meta',
      'category': '_spentx_plan_meta',
      'plannedAmount': 0,
      'bufferAmount': (local['bufferAmount'] as num?)?.toDouble() ?? 0,
      'bufferChoice': (local['bufferChoice'] ?? 'buffer').toString(),
      'createdAt': local['createdAt'],
    });

    // DB trigger rejects allocations > expected_income. Raise income just
    // enough for the write so offline plans still land on the server.
    var expected =
        (local['expectedIncome'] as num? ??
                local['expected_income'] as num? ??
                0)
            .toDouble();
    if (expected < allocTotal) expected = allocTotal;

    final updatedAt =
        (local['updatedAt'] ??
                local['updated_at'] ??
                DateTime.now().toUtc().toIso8601String())
            .toString();

    await _db.from(SupaTables.monthlyPlans).upsert({
      'id': remoteId,
      'user_id': uid,
      'month': month,
      'title': local['title'],
      'purpose_id': purposeId,
      'expected_income': expected,
      'allocations': allocs,
      'budget_set_at': updatedAt,
      'daily_safe_limit': local['dailySafeLimit'] ?? local['daily_safe_limit'],
      'savings_target': local['savingsTarget'] ?? local['savings_target'],
      'is_budget_locked':
          local['isBudgetLocked'] == true || local['is_budget_locked'] == true,
      'updated_at': updatedAt,
    });
    _stampLocalPlanRemoteId(resolvedLocalId, remoteId);
    _stampMoneyClock(SyncTables.monthlyPlans.table, resolvedLocalId, updatedAt);
    if (remoteId != resolvedLocalId) {
      _stampMoneyClock(SyncTables.monthlyPlans.table, remoteId, updatedAt);
    }
  }

  /// Upsert transaction; if outing_id FK fails (outing not on server yet),
  /// retry without outing_id so the money row still lands on the web app.
  static Future<void> _upsertTransactionWithOutingFallback(
    Map<String, dynamic> remoteRow,
  ) async {
    try {
      await _db.from(SupaTables.transactions).upsert(remoteRow);
    } catch (e) {
      final hasOuting =
          (remoteRow[TransactionMap.outingId] ?? '')
              .toString()
              .trim()
              .isNotEmpty;
      if (!hasOuting) rethrow;
      final retry = Map<String, dynamic>.from(remoteRow);
      retry[TransactionMap.outingId] = null;
      await _db.from(SupaTables.transactions).upsert(retry);
      // Keep original map id for stamping; outing link can re-attach later.
      remoteRow[TransactionMap.outingId] = null;
    }
  }

  static Future<void> _pushOutingDocument(
    Map<String, dynamic> outingJson,
    String uid,
  ) async {
    final outingId = outingJson['id'].toString();
    final outingRow = OutingMap.toRemote(outingJson, uid);
    // Outing Purpose auto-applies to its rollup + auto-linked transactions,
    // so the user isn't asked to pick one per-transaction while it's open.
    outingRow[OutingMap.purposeId] = await _resolveRemotePurposeId(
      uid,
      (outingJson['purpose'] ?? 'Personal').toString(),
    );
    await _db.from(SupaTables.outings).upsert(outingRow);

    final expenses =
        (outingJson['expenses'] as List? ?? [])
            .whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e))
            .toList();

    final expenseIds = <String>[];
    final settlementIds = <String>[];
    for (final e in expenses) {
      final remoteExpId = SyncIds.forExpense(uid, e['id'].toString());
      expenseIds.add(remoteExpId);
      final expenseRow = OutingExpenseMap.toRemote(e, uid, outingId);
      try {
        await _db.from(SupaTables.outingExpenses).upsert(expenseRow);
      } catch (err) {
        // A unique-violation on (user_id, linked_transaction_id) means
        // another client (web's auto-add, or this device on a retry)
        // already created the canonical expense row for this transaction —
        // do NOT retry as an unlinked manual row, that would just create a
        // second row for the same real spend and double the outing total.
        // Drop this push; the next outings pull adopts the existing row.
        final isLinkUniqueViolation =
            err is PostgrestException &&
            err.code == '23505' &&
            (err.message.contains('outing_expenses_user_linked_tx_uidx'));
        if (isLinkUniqueViolation) continue;

        // Otherwise assume linked_transaction_id points at a tx not pushed
        // yet (FK violation) — drop the link and retry as manual so the
        // expense itself isn't lost.
        final retry = Map<String, dynamic>.from(expenseRow);
        retry[OutingExpenseMap.linkedTransactionId] = null;
        retry[OutingExpenseMap.source] = 'manual';
        await _db.from(SupaTables.outingExpenses).upsert(retry);
      }

      final payerId = e['paidByMemberId']?.toString() ?? 'you';
      final payments = e['settlementPayments'];
      if (payments is Map) {
        for (final memberEntry in payments.entries) {
          final memberId = memberEntry.key.toString();
          final list = (memberEntry.value as List? ?? []);
          for (var i = 0; i < list.length; i++) {
            final p = Map<String, dynamic>.from(list[i] as Map);
            final row = SettlementMap.toRemote(
              uid: uid,
              outing: outingId,
              remoteExpenseId: remoteExpId,
              payerMemberId: payerId,
              member: memberId,
              index: i,
              payment: p,
            );
            settlementIds.add(row[SettlementMap.id].toString());
            await _db.from(SupaTables.settlements).upsert(row);
          }
        }
      }
    }

    // Prune remote children removed locally — but ONLY mobile-authored
    // settlements (note starts with exp:); web-created ones are left alone.
    await _deleteMissingChildren(
      table: SupaTables.outingExpenses,
      parentCol: OutingExpenseMap.outingId,
      parentId: outingId,
      uid: uid,
      keepIds: expenseIds,
    );
    var q = _db
        .from(SupaTables.settlements)
        .delete()
        .eq(SettlementMap.outingId, outingId)
        .eq(SettlementMap.userId, uid)
        .like(SettlementMap.note, 'exp:%');
    if (settlementIds.isNotEmpty) {
      q = q.not('id', 'in', '(${settlementIds.join(',')})');
    }
    await q;
  }

  /// Upsert a Friend Split + its settlements. The linked transaction is
  /// pushed separately (as an ordinary [SyncEntity.transaction]) — this only
  /// pushes the roster/shares/repayments describing who-owes-whom for it.
  static Future<void> _pushFriendSplitDocument(
    Map<String, dynamic> friendSplitJson,
    String uid,
  ) async {
    final localId = friendSplitJson['id'].toString();
    final remoteId = SyncIds.forFriendSplit(uid, localId);
    final remoteTxId = SyncIds.forTransaction(
      uid,
      (friendSplitJson['transactionId'] ?? '').toString(),
    );

    // FK to transactions.id — if the transaction hasn't synced yet this
    // throws and the queue entry is retried next cycle, after the
    // transaction (pushed first — see _pushPriority) has landed.
    final row = FriendSplitMap.toRemote(friendSplitJson, uid, remoteTxId);
    await _db
        .from(SupaTables.friendSplits)
        .upsert(row, onConflict: 'transaction_id');

    final settlements =
        (friendSplitJson['settlements'] as List? ?? const [])
            .whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e))
            .toList();
    final keepIds = <String>[];
    for (final s in settlements) {
      final settleRow = FriendSettlementMap.toRemote(s, uid, remoteId);
      await _db.from(SupaTables.friendSettlements).upsert(settleRow);
      keepIds.add(settleRow['id'].toString());
    }
    await _deleteMissingChildren(
      table: SupaTables.friendSettlements,
      parentCol: 'friend_split_id',
      parentId: remoteId,
      uid: uid,
      keepIds: keepIds,
    );
  }

  static Future<void> _deleteMissingChildren({
    required String table,
    required String parentCol,
    required String parentId,
    required String uid,
    required List<String> keepIds,
  }) async {
    var query = _db
        .from(table)
        .delete()
        .eq(parentCol, parentId)
        .eq('user_id', uid);
    if (keepIds.isNotEmpty) {
      query = query.not('id', 'in', '(${keepIds.join(',')})');
    }
    await query;
  }

  // ───────────────────────────── PULL ─────────────────────────────

  static Future<void> pullAll({bool forceNotify = false}) async {
    if (!_ready) return;
    final uid = AuthService.currentUserId!;
    var changed = false;
    // Cursor is the start of this pull, so a web write during the pull is
    // still gt(cursor) on the next cycle instead of being skipped.
    final nextCursor = DateTime.now().toUtc().subtract(
      const Duration(seconds: 2),
    );

    changed = await _pullAccountsAndPurposes(uid) || changed;
    changed = await _pullCategories(uid) || changed;
    changed = await _pullContributors(uid) || changed;
    changed = await _pullMonthlyPlans(uid) || changed;
    // Merchants before transactions so SMS auto-add works after reinstall.
    changed = await _pullUserMerchants(uid) || changed;
    changed = await _pullTransactionsWindow(uid) || changed;
    changed = await _pullMoneyDelta(uid, nextCursor: nextCursor) || changed;
    changed = await _pullOutings(uid) || changed;
    changed = await _pullOutingCategories(uid) || changed;
    changed = await _pullFriendSplits(uid) || changed;
    changed = await _pullFriends(uid) || changed;
    changed = await _pullUserSettings(uid) || changed;

    try {
      final beforeGoals =
          SavingsGoalService.cachedGoals().map((g) => g.toMap()).toString();
      await SavingsGoalService.fetchSavingsGoals();
      changed =
          beforeGoals !=
              SavingsGoalService.cachedGoals()
                  .map((g) => g.toMap())
                  .toString() ||
          changed;
      await RecurringBillService.sync();
      await ProjectorService.fetchSettings();
      final previousHoldings = InvestmentService.cachedRows().toString();
      await InvestmentService.fetch();
      changed =
          InvestmentService.cachedRows().toString() != previousHoldings ||
          changed;
      await SnapshotOutbox.flushPending();
    } catch (_) {}

    _lastPullAt = DateTime.now();
    // forceNotify: Home pull-to-refresh always reloads providers from Hive.
    if (changed || forceNotify) onDataChanged?.call();
  }

  /// Restore per-user verified merchants (Hive merchants_box) from Supabase.
  static Future<bool> _pullUserMerchants(String uid) async {
    try {
      final rows = await _db
          .from(SupaTables.userMerchants)
          .select()
          .eq(UserMerchantMap.userId, uid);

      if (!Hive.isBoxOpen('merchants_box')) {
        await SecureHive.openBox('merchants_box');
      }
      final box = Hive.box('merchants_box');

      // Keep local-only merchants still waiting to push.
      final keepLocal = <String, Map<String, dynamic>>{};
      for (final key in box.keys) {
        final raw = box.get(key);
        if (raw is! Map) continue;
        final m = Map<String, dynamic>.from(raw);
        final localId = m['id']?.toString() ?? key.toString();
        final norm = (m['normalizedPayee'] ?? '').toString();
        if (SyncQueue.hasPending(SyncEntity.userMerchant, localId) ||
            SyncQueue.hasPending(SyncEntity.userMerchant, norm)) {
          keepLocal[key.toString()] = m;
        }
      }

      final serverByNorm = <String, Map<String, dynamic>>{};
      for (final r in rows) {
        final row = Map<String, dynamic>.from(r as Map);
        final local = UserMerchantMap.toLocal(row);
        final norm = (local['normalizedPayee'] ?? '').toString();
        if (norm.isEmpty) continue;
        final remoteAt = row['updated_at']?.toString();
        final id = local['id']?.toString() ?? '';
        if (_keepAnyLocal(
          table: SyncTables.userMerchants.table,
          entity: SyncEntity.userMerchant,
          localIds: [id, norm],
          remoteUpdatedAt: remoteAt,
        )) {
          continue;
        }
        serverByNorm[norm] = local;
        _stampMoneyClock(SyncTables.userMerchants.table, id, remoteAt);
        _stampMoneyClock(SyncTables.userMerchants.table, norm, remoteAt);
      }
      keepLocal.removeWhere((key, m) {
        final norm = (m['normalizedPayee'] ?? '').toString();
        return serverByNorm.containsKey(norm);
      });

      await box.clear();
      for (final e in keepLocal.entries) {
        await box.put(e.key, e.value);
      }
      for (final e in serverByNorm.entries) {
        final id = e.value['id']?.toString() ?? e.key;
        await box.put(id, e.value);
      }

      // Mirror into legacy merchant_rules_box so older auto-detect paths work
      // after reinstall (without re-enqueueing cloud upserts).
      try {
        if (!Hive.isBoxOpen('merchant_rules_box')) {
          await SecureHive.openBox('merchant_rules_box');
        }
        final legacy = Hive.box('merchant_rules_box');
        for (final m in serverByNorm.values) {
          final norm = (m['normalizedPayee'] ?? '').toString();
          if (norm.isEmpty) continue;
          final ruleId = 'sync_$norm';
          await legacy.put(ruleId, {
            'id': ruleId,
            'identifier': norm,
            'normalizedIdentifierKey': norm,
            'displayName': m['title'] ?? m['payee'] ?? norm,
            'defaultCategory': m['category'] ?? 'Other',
            'defaultPurposeType': m['purpose'] ?? 'Personal',
            'transactionType': 'any',
            'createdAt': m['verifiedAt'] ?? DateTime.now().toIso8601String(),
          });
        }
      } catch (_) {}

      return rows.isNotEmpty || keepLocal.isNotEmpty;
    } catch (_) {
      // Table may not exist until migration applied.
      return false;
    }
  }

  /// Accounts + purposes: authoritative name↔uuid caches for everything else,
  /// plus the local accounts/purposes lists in settings.
  static Future<bool> _pullAccountsAndPurposes(String uid) async {
    var changed = false;

    // Do not filter is_active here. A dedupe pass set is_active=false on real
    // banks (no deleted_at) and the next active-only pull then erased them
    // from Hive. deleted_at is the only user delete. Inactive rows without it
    // are restored below.
    final accountRows = await _selectAll(
      () => _db.from(SupaTables.accounts).select().eq(AccountMap.userId, uid),
    );
    final byName = <String, String>{};
    final localAccounts = <Map<String, dynamic>>[];
    final rawLocalMaps = <Map<String, dynamic>>[];
    if (Hive.isBoxOpen('settings')) {
      final rawExisting = Hive.box('settings').get('onboardingAccounts') ?? [];
      if (rawExisting is List) {
        for (final e in rawExisting) {
          if (e is Map) rawLocalMaps.add(Map<String, dynamic>.from(e));
        }
      }
    }
    Map<String, dynamic>? existingNamed(String name) {
      final target = name.toLowerCase();
      for (final m in rawLocalMaps) {
        if ((m['name'] ?? '').toString().toLowerCase() == target) return m;
      }
      return null;
    }

    final seenPullIds = <String>{};
    final seenPullNames = <String>{};
    final explicitlyDeletedNames = <String>{};
    final reactivateIds = <String>[];

    for (final r in accountRows) {
      final row = Map<String, dynamic>.from(r as Map);
      final name = (row[AccountMap.name] ?? '').toString().trim();
      if (name.isEmpty) continue;
      final nameKey = name.toLowerCase();
      final rowId = (row[AccountMap.id] ?? '').toString();
      final remoteAt = row['updated_at']?.toString();

      final pendingDelete =
          SyncQueue.hasPendingDelete(SyncEntity.account, localId: name) ||
          SyncQueue.hasPendingDelete(
            SyncEntity.account,
            localId: rowId,
            remoteId: rowId,
          );
      if (pendingDelete) {
        explicitlyDeletedNames.add(nameKey);
        continue;
      }

      // Real delete. is_active=false alone is NOT one — that flag was also
      // set by the duplicate cleaner, which never wrote deleted_at.
      if (row['deleted_at'] != null) {
        explicitlyDeletedNames.add(nameKey);
        _stampMoneyClock(SyncTables.accounts.table, name, remoteAt);
        continue;
      }

      final restore = _isBugHiddenAccount(row);
      if (rowId.isNotEmpty && seenPullIds.contains(rowId)) continue;
      // Same display name: show one. Do not deactivate the other server row.
      if (seenPullNames.contains(nameKey)) continue;
      if (rowId.isNotEmpty) seenPullIds.add(rowId);
      seenPullNames.add(nameKey);

      byName[nameKey] = rowId;
      final existing = existingNamed(name);
      // Newer local clock (or a queued edit with no clock yet) beats the server.
      // A bug-hidden row must come back even when a local clock exists.
      if (!restore &&
          existing != null &&
          _keepLocalMoney(
            table: SyncTables.accounts.table,
            entity: SyncEntity.account,
            localId: name,
            remoteUpdatedAt: remoteAt,
          )) {
        localAccounts.add(existing);
        continue;
      }
      final mapped = AccountMap.toLocal(row);
      if (restore) {
        mapped['isActive'] = true;
        if (rowId.isNotEmpty) reactivateIds.add(rowId);
      }
      localAccounts.add(mapped);
      _stampMoneyClock(SyncTables.accounts.table, name, remoteAt);
    }
    RemoteIdCache.replaceAccounts(byName);

    for (final dupId in reactivateIds) {
      try {
        await _db
            .from(SupaTables.accounts)
            .update({AccountMap.isActive: true})
            .eq(AccountMap.userId, uid)
            .eq(AccountMap.id, dupId);
      } catch (e) {
        debugPrint('Account restore failed: $e');
      }
    }

    if (Hive.isBoxOpen('settings')) {
      final settings = Hive.box('settings');
      // Server active accounts win; keep only offline-pending creates.
      final List<dynamic> rawLocal = settings.get('onboardingAccounts') ?? [];
      final serverNames =
          localAccounts.map((a) => a['name'].toString().toLowerCase()).toSet();
      for (final e in rawLocal) {
        final m = Map<String, dynamic>.from(e as Map);
        final n = (m['name'] ?? '').toString();
        if (n.isEmpty) continue;
        final key = n.toLowerCase();
        if (serverNames.contains(key)) continue;
        // Only a real delete (deleted_at / queued delete) removes a local bank.
        // An active-only server list must not wipe accounts that are still here.
        if (explicitlyDeletedNames.contains(key)) continue;
        localAccounts.add(m);
      }
      if (localAccounts.isEmpty && rawLocal.isNotEmpty) {
        // Refuse to replace a non-empty phone list with nothing.
        return changed;
      }
      // Same account name only. Last-4 must not drop a different bank.
      final dedupedLocal = <Map<String, dynamic>>[];
      final dedupNames = <String>{};
      for (final acc in localAccounts) {
        final n = (acc['name'] ?? '').toString().trim().toLowerCase();
        if (n.isEmpty) continue;
        if (dedupNames.contains(n)) continue;
        dedupNames.add(n);
        dedupedLocal.add(acc);
      }
      localAccounts
        ..clear()
        ..addAll(dedupedLocal);

      localAccounts.sort((a, b) {
        final aCash = (a['type']?.toString().toLowerCase() == 'cash') ? 0 : 1;
        final bCash = (b['type']?.toString().toLowerCase() == 'cash') ? 0 : 1;
        return aCash.compareTo(bCash);
      });
      if (rawLocal.toString() != localAccounts.toString()) {
        settings.put('onboardingAccounts', localAccounts);
        changed = true;
        // An account added on the web reaches this device only through this
        // pull, and the native SMS gate reads a SharedPreferences mirror
        // rather than Hive — so writing the box alone leaves the notification
        // listener on the previous bank list until the next app launch
        // re-runs syncToNative(). On a fresh install that previous list is
        // the empty one main() wrote before any account existed, which
        // rejects *every* bank SMS, so the newly pulled bank stays
        // undetected for the rest of the session. Mirrors what
        // UserStateNotifier does for accounts edited on the phone.
        //
        // Isolated: a failed mirror must not fail the pull — native simply
        // keeps the old list one more cycle, exactly as before.
        try {
          await AutoDetectionNativeSync.syncAllowedBanksToNative();
        } catch (e) {
          debugPrint('Bank allowlist mirror failed after account pull: $e');
        }
      }
    }

    try {
      final purposeRows = await _db
          .from(SupaTables.purposes)
          .select()
          .eq(PurposeMap.userId, uid)
          .eq(PurposeMap.isActive, true);
      if (purposeRows.isNotEmpty) {
        final byName = <String, String>{};
        final names = <String>[];
        for (final r in purposeRows) {
          final row = Map<String, dynamic>.from(r as Map);
          final name = (row[PurposeMap.name] ?? '').toString();
          if (name.isEmpty) continue;
          byName[name.toLowerCase()] = row[PurposeMap.id].toString();
          names.add(name);
        }
        RemoteIdCache.replacePurposes(byName);

        if (Hive.isBoxOpen('settings')) {
          final settings = Hive.box('settings');
          final current = List<String>.from(
            settings.get('purposeTypes', defaultValue: <String>[]) ?? [],
          );
          // Keep a purpose that is still queued and not on the server yet.
          for (final n in current) {
            final exists = names.any((s) => s.toLowerCase() == n.toLowerCase());
            if (!exists && SyncQueue.hasPending(SyncEntity.purpose, n)) {
              names.add(n);
            }
          }
          if (names.toString() != current.toString()) {
            settings.put('purposeTypes', names);
            changed = true;
          }
        }
      }
    } catch (_) {}

    return changed;
  }

  static Future<bool> _pullTransactionsWindow(String uid) async {
    final rows = await _selectAll(
      () => _db
          .from(SupaTables.transactions)
          .select()
          .eq(TransactionMap.userId, uid)
          .eq(TransactionMap.isActive, true),
    );
    // Reconcile with server rows — honors server deletes and preserves all months.
    return _mergeTransactionRows(
      rows,
      uid,
      reconcileWindow: true,
      honorDeletes: true,
    );
  }

  /// On-demand fetch of an OLDER range. Returns rows fetched or null offline.
  /// Does not prune the main window (additive history only).
  static Future<int?> fetchTransactionRange({
    required DateTime from,
    required DateTime to,
  }) async {
    if (!_ready) return null;
    try {
      final uid = AuthService.currentUserId!;
      await _pullAccountsAndPurposes(uid);
      final rows = await _selectAll(
        () => _db
            .from(SupaTables.transactions)
            .select()
            .eq(TransactionMap.userId, uid)
            .eq(TransactionMap.isActive, true)
            .gte(TransactionMap.date, from.toIso8601String())
            .lt(TransactionMap.date, to.toIso8601String()),
      );
      final changed = await _mergeTransactionRows(
        rows,
        uid,
        reconcileWindow: false,
      );
      // Remember how far back this device's cache now goes, so the next
      // periodic/foreground reconcile pull (35-day window) doesn't prune
      // this history right back out.
      if (Hive.isBoxOpen('settings')) {
        final settings = Hive.box('settings');
        final existing = DateTime.tryParse(
          settings.get(_extendedCacheSinceKey) as String? ?? '',
        );
        if (existing == null || from.isBefore(existing)) {
          await settings.put(_extendedCacheSinceKey, from.toIso8601String());
        }
      }
      if (changed) onDataChanged?.call();
      return (rows as List).length;
    } catch (_) {
      return null;
    }
  }

  /// Merges remote transaction rows into Hive.
  ///
  /// When [reconcileWindow] is true (normal pull):
  /// 1. Upsert every server row in the window
  /// 2. Drop local rows older than [windowDays] (1‑month local cache)
  /// 3. Drop local rows inside the window that are missing on the server
  ///    (web/server delete) — except offline-pending or SMS-pending verify
  static Future<bool> _mergeTransactionRows(
    dynamic rows,
    String uid, {
    required bool reconcileWindow,
    bool honorDeletes = false,
  }) async {
    if (!Hive.isBoxOpen('transactions')) return false;
    final list = rows is List ? rows : const <dynamic>[];

    final splitByTx = <String, Map<String, dynamic>>{};
    final splitCountByTx = <String, int>{};
    // All split rows per transaction — a Split Expense shows every
    // category/purpose in the list, not just the first.
    final allSplitsByTx = <String, List<Map<String, dynamic>>>{};
    // All item rows per transaction — independent of splits.
    final allItemsByTx = <String, List<Map<String, dynamic>>>{};
    if (list.isNotEmpty) {
      final txIds = list
          .map((r) => (r as Map)['id'].toString())
          .toList(growable: false);
      try {
        for (var i = 0; i < txIds.length; i += 100) {
          final chunk = txIds.sublist(
            i,
            i + 100 > txIds.length ? txIds.length : i + 100,
          );
          final splitRows = await _selectAll(
            () => _db
                .from(SupaTables.transactionSplits)
                .select()
                .eq('user_id', uid)
                .inFilter('transaction_id', chunk),
          );
          for (final s in splitRows) {
            final row = Map<String, dynamic>.from(s as Map);
            final txId = row['transaction_id'].toString();
            splitCountByTx[txId] = (splitCountByTx[txId] ?? 0) + 1;
            // First split drives the single-category fallback; the full
            // list drives Split Expense display.
            splitByTx.putIfAbsent(txId, () => row);
            (allSplitsByTx[txId] ??= <Map<String, dynamic>>[]).add(row);
          }
          final itemRows = await _selectAll(
            () => _db
                .from(SupaTables.transactionItems)
                .select()
                .eq('user_id', uid)
                .inFilter('transaction_id', chunk),
          );
          itemRows.sort(
            (a, b) => ((a['position'] as num?) ?? 0).compareTo(
              (b['position'] as num?) ?? 0,
            ),
          );
          for (final s in itemRows) {
            final row = Map<String, dynamic>.from(s as Map);
            final txId = row['transaction_id'].toString();
            (allItemsByTx[txId] ??= <Map<String, dynamic>>[]).add(row);
          }
        }
      } catch (_) {}
    }

    final box = Hive.box('transactions');
    final List<dynamic> raw = box.get('list', defaultValue: []);
    final local = raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();

    Map<String, int> buildRemoteIndex(List<Map<String, dynamic>> rows) {
      final map = <String, int>{};
      for (var i = 0; i < rows.length; i++) {
        final l = rows[i];
        final rid =
            l['remoteId']?.toString() ??
            SyncIds.forTransaction(uid, l['id'].toString());
        map[rid] = i;
      }
      return map;
    }

    var byRemoteId = buildRemoteIndex(local);
    final serverRemoteIds = <String>{};
    var changed = false;

    for (final r in list) {
      if (r is! Map) continue;
      final row = Map<String, dynamic>.from(r);
      final remoteId = row['id'].toString();
      final remoteUpdatedAt = row['updated_at']?.toString();
      final inactive =
          row[TransactionMap.isActive] == false || row['deleted_at'] != null;
      if (inactive) {
        if (!honorDeletes) continue;
        final idx = byRemoteId[remoteId];
        if (idx == null) continue;
        final localId = local[idx]['id'].toString();
        if (_keepLocalMoney(
          table: SyncTables.transactions.table,
          entity: SyncEntity.transaction,
          localId: localId,
          remoteUpdatedAt: remoteUpdatedAt,
        )) {
          continue;
        }
        local.removeAt(idx);
        byRemoteId = buildRemoteIndex(local);
        changed = true;
        _stampMoneyClock(
          SyncTables.transactions.table,
          localId,
          remoteUpdatedAt,
        );
        continue;
      }
      serverRemoteIds.add(remoteId);

      // Offline delete not yet pushed — keep it off device unless the server
      // copy is strictly newer.
      if (SyncQueue.hasPendingDelete(
        SyncEntity.transaction,
        localId: remoteId,
        remoteId: remoteId,
      )) {
        final queuedId =
            SyncQueue.pendingLocalId(
              SyncEntity.transaction,
              localId: remoteId,
              remoteId: remoteId,
            ) ??
            remoteId;
        if (_keepLocalMoney(
          table: SyncTables.transactions.table,
          entity: SyncEntity.transaction,
          localId: queuedId,
          remoteUpdatedAt: remoteUpdatedAt,
        )) {
          final idx = byRemoteId[remoteId];
          if (idx != null) {
            local.removeAt(idx);
            byRemoteId = buildRemoteIndex(local);
            changed = true;
          }
          continue;
        }
      }

      final localIdx = byRemoteId[remoteId];
      final mapped = TransactionMap.toLocal(
        row,
        splitByTx[remoteId],
        splitCount: splitCountByTx[remoteId] ?? 1,
        allSplits: allSplitsByTx[remoteId] ?? const [],
        allItems: allItemsByTx[remoteId] ?? const [],
      );

      if (localIdx == null) {
        if (isRecentlyDeletedLocally(remoteId)) {
          continue;
        }
        local.add(mapped);
        byRemoteId = buildRemoteIndex(local);
        changed = true;
        _stampMoneyClock(
          SyncTables.transactions.table,
          mapped['id'].toString(),
          remoteUpdatedAt,
        );
        continue;
      }
      final existing = local[localIdx];
      final localId = existing['id'].toString();
      if (SyncQueue.hasPendingDelete(
        SyncEntity.transaction,
        localId: localId,
        remoteId: remoteId,
      )) {
        if (_keepLocalMoney(
          table: SyncTables.transactions.table,
          entity: SyncEntity.transaction,
          localId: localId,
          remoteUpdatedAt: remoteUpdatedAt,
        )) {
          local.removeAt(localIdx);
          byRemoteId = buildRemoteIndex(local);
          changed = true;
          continue;
        }
      }
      // Local clock or a queued edit with no clock yet beats an older server row.
      if (_keepLocalMoney(
        table: SyncTables.transactions.table,
        entity: SyncEntity.transaction,
        localId: localId,
        remoteUpdatedAt: remoteUpdatedAt,
      )) {
        continue;
      }
      mapped['id'] = localId;
      mapped['remoteId'] = remoteId;
      mapped['isPendingVerification'] =
          existing['isPendingVerification'] ?? false;
      if (existing['isGroup'] == true) {
        mapped['isGroup'] = true;
        mapped['groupCount'] =
            existing['groupCount'] ?? mapped['groupCount'] ?? 2;
      }
      if ((mapped['rawMessage'] as String? ?? '').isEmpty) {
        mapped['rawMessage'] = existing['rawMessage'] ?? '';
      }
      if ((mapped['description'] as String? ?? '').isEmpty &&
          (existing['description'] as String? ?? '').isNotEmpty) {
        mapped['description'] = existing['description'];
      }
      final existingSplits = existing['splits'] as List?;
      final mappedSplits = mapped['splits'] as List?;
      if ((mappedSplits == null || mappedSplits.isEmpty) &&
          (existingSplits != null && existingSplits.length > 1)) {
        mapped['splits'] = existingSplits;
      }
      final existingItems = existing['items'] as List?;
      final mappedItems = mapped['items'] as List?;
      if ((mappedItems == null || mappedItems.isEmpty) &&
          (existingItems != null && existingItems.isNotEmpty)) {
        mapped['items'] = existingItems;
      }
      if (mapped.toString() != existing.toString()) {
        local[localIdx] = mapped;
        changed = true;
      }
      _stampMoneyClock(SyncTables.transactions.table, localId, remoteUpdatedAt);
    }

    if (reconcileWindow) {
      final before = local.length;
      local.removeWhere((tx) {
        final localId = tx['id']?.toString() ?? '';
        if (localId.isEmpty) return true;
        final rid =
            tx['remoteId']?.toString() ?? SyncIds.forTransaction(uid, localId);

        // Offline delete → must not stay on device.
        if (SyncQueue.hasPendingDelete(
          SyncEntity.transaction,
          localId: localId,
          remoteId: rid,
        )) {
          return true;
        }
        // Offline add/update not pushed yet → keep.
        if (SyncQueue.hasPending(SyncEntity.transaction, localId)) {
          return false;
        }
        if (tx['isPendingVerification'] == true) return false;

        // Server deleted (or never had) this row → drop local.
        if (!serverRemoteIds.contains(rid)) {
          return true;
        }
        return false;
      });
      if (local.length != before) changed = true;
    }

    if (changed) {
      local.sort(
        (a, b) => (b['date'] ?? '').toString().compareTo(
          (a['date'] ?? '').toString(),
        ),
      );
      box.put('list', local);
    }
    return changed;
  }

  static Future<bool> _pullOutings(String uid, {Set<String>? onlyIds}) async {
    if (!Hive.isBoxOpen('outings')) return false;

    // Include rows whose is_active was cleared by an older app build when a
    // trip was only completed. A real delete also sets deleted_at.
    // [onlyIds] is the updated_at delta: merge just those trips, do not prune
    // the rest of the local box.
    var outingQuery = _db
        .from(SupaTables.outings)
        .select()
        .eq(OutingMap.userId, uid);
    var expenseQuery = _db
        .from(SupaTables.outingExpenses)
        .select()
        .eq(OutingExpenseMap.userId, uid);
    var settlementQuery = _db
        .from(SupaTables.settlements)
        .select()
        .eq(SettlementMap.userId, uid);
    if (onlyIds != null) {
      if (onlyIds.isEmpty) return false;
      final idList = onlyIds.toList();
      outingQuery = outingQuery.inFilter(OutingMap.id, idList);
      expenseQuery = expenseQuery.inFilter(OutingExpenseMap.outingId, idList);
      settlementQuery = settlementQuery.inFilter('outing_id', idList);
    }
    final outingRows = await outingQuery;
    final list = outingRows;
    final expenseRows = await expenseQuery;
    final settlementRows = await settlementQuery;

    final expensesByOuting = <String, List<Map<String, dynamic>>>{};
    for (final r in expenseRows) {
      final row = Map<String, dynamic>.from(r as Map);
      if (row['is_active'] == false || row['deleted_at'] != null) continue;
      expensesByOuting
          .putIfAbsent(row[OutingExpenseMap.outingId].toString(), () => [])
          .add(row);
    }
    final settlementsByOuting = <String, List<Map<String, dynamic>>>{};
    for (final r in settlementRows) {
      final row = Map<String, dynamic>.from(r as Map);
      if (row['is_active'] == false || row['deleted_at'] != null) continue;
      settlementsByOuting
          .putIfAbsent(row[SettlementMap.outingId].toString(), () => [])
          .add(row);
    }

    final box = Hive.box('outings');
    final serverIds = <String>{};
    var changed = false;

    for (final r in list) {
      final row = Map<String, dynamic>.from(r as Map);
      final outingId = row[OutingMap.id].toString();
      // Quick splits are hidden friend bills, not trips. Real deletes set
      // deleted_at. Leave both out of the phone list.
      final remoteAt = row['updated_at']?.toString();
      final reallyDeleted =
          row[OutingMap.isActive] == false && row['deleted_at'] != null;
      if (row['is_quick_split'] == true) continue;
      if (reallyDeleted) {
        if (!_keepLocalMoney(
          table: SyncTables.outings.table,
          entity: SyncEntity.outing,
          localId: outingId,
          remoteUpdatedAt: remoteAt,
        )) {
          if (box.containsKey(outingId)) {
            await box.delete(outingId);
            changed = true;
          }
          _stampMoneyClock(SyncTables.outings.table, outingId, remoteAt);
        }
        continue;
      }

      serverIds.add(outingId);
      if (_keepLocalMoney(
        table: SyncTables.outings.table,
        entity: SyncEntity.outing,
        localId: outingId,
        remoteUpdatedAt: remoteAt,
      )) {
        continue;
      }

      final doc = OutingMap.toLocalShell(row);
      final expenses = <Map<String, dynamic>>[];
      final expByRemoteId = <String, Map<String, dynamic>>{};
      for (final e
          in expensesByOuting[outingId] ?? const <Map<String, dynamic>>[]) {
        final exp = OutingExpenseMap.toLocal(e);
        expByRemoteId[e[OutingExpenseMap.id].toString()] = exp;
        expenses.add(exp);
      }

      final unlinked = <Map<String, dynamic>>[];
      for (final s
          in settlementsByOuting[outingId] ?? const <Map<String, dynamic>>[]) {
        final expId = SettlementMap.expenseIdFromNote(
          s[SettlementMap.note]?.toString(),
        );
        final member = s[SettlementMap.fromMemberId]?.toString() ?? '';
        final payment = {
          'amount': (s[SettlementMap.amount] as num? ?? 0).toDouble(),
          'mode': 'Online',
          'date':
              s[SettlementMap.settledDate] ?? DateTime.now().toIso8601String(),
        };
        final target = expId != null ? expByRemoteId[expId] : null;
        if (target != null && member.isNotEmpty) {
          final payments = target['settlementPayments'] as Map<String, dynamic>;
          (payments.putIfAbsent(member, () => <Map<String, dynamic>>[]) as List)
              .add(payment);
        } else {
          unlinked.add({'member': member, ...payment});
        }
      }
      for (final u in unlinked) {
        var remaining = (u['amount'] as num).toDouble();
        final member = u['member'].toString();
        if (member.isEmpty) continue;
        for (final exp in expenses) {
          if (remaining <= 0.01) break;
          final memberIds =
              (exp['memberIds'] as List).map((e) => e.toString()).toList();
          if (!memberIds.contains(member)) continue;
          final share =
              memberIds.isEmpty
                  ? 0.0
                  : (exp['amount'] as num).toDouble() / memberIds.length;
          final payments = exp['settlementPayments'] as Map<String, dynamic>;
          final already = ((payments[member] as List?) ?? []).fold(
            0.0,
            (s, p) => s + ((p as Map)['amount'] as num).toDouble(),
          );
          final pending = share - already;
          if (pending <= 0.01) continue;
          final apply = remaining < pending ? remaining : pending;
          (payments.putIfAbsent(member, () => <Map<String, dynamic>>[]) as List)
              .add({'amount': apply, 'mode': u['mode'], 'date': u['date']});
          remaining -= apply;
        }
      }

      doc['expenses'] = expenses;
      final existing = box.get(outingId);
      if (existing == null || existing.toString() != doc.toString()) {
        box.put(outingId, doc);
        changed = true;
      }
      _stampMoneyClock(SyncTables.outings.table, outingId, remoteAt);

      // Older builds set is_active false when a trip was only completed.
      // Web hides those rows. Put the flag back without rewriting expenses.
      final remoteStatus =
          (row[OutingMap.status] ?? '').toString().trim().toLowerCase();
      final hiddenByOldComplete =
          row[OutingMap.isActive] == false &&
          row['deleted_at'] == null &&
          remoteStatus != 'cancelled';
      if (hiddenByOldComplete) {
        try {
          await _db
              .from(SupaTables.outings)
              .update({OutingMap.isActive: true})
              .eq(OutingMap.id, outingId)
              .eq(OutingMap.userId, uid);
        } catch (e) {
          debugPrint('Outing visibility repair skipped for $outingId: $e');
        }
      }
    }

    // Server deleted / soft-deleted outing → remove local (unless offline pending).
    // A delta merge must not drop trips that were not in this batch.
    if (onlyIds != null) return changed;
    final localKeys = box.keys.map((k) => k.toString()).toList();
    for (final key in localKeys) {
      if (key == 'list') continue;
      if (serverIds.contains(key)) continue;
      if (SyncQueue.hasPending(SyncEntity.outing, key)) continue;
      await box.delete(key);
      changed = true;
    }
    return changed;
  }

  static Future<bool> _pullFriends(String uid) async {
    if (!Hive.isBoxOpen('friends')) return false;
    final rows = await _db
        .from(SupaTables.friends)
        .select()
        .eq(FriendMap.userId, uid)
        .eq(FriendMap.isActive, true);
    final list = rows;

    final box = Hive.box('friends');
    final List<dynamic> raw = box.get('list', defaultValue: []);
    final previous =
        raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();

    // Server-active friends are source of truth; keep only offline-pending
    // creates that are not on the server yet.
    final previousByName = <String, Map<String, dynamic>>{};
    for (final f in previous) {
      final name = (f['name'] ?? '').toString().trim();
      if (name.isEmpty) continue;
      previousByName[name.toLowerCase()] = f;
    }
    final renamingIds = _pendingFriendRenameIds(previous);

    final serverByName = <String, Map<String, dynamic>>{};
    for (final r in list) {
      final row = Map<String, dynamic>.from(r as Map);
      final name = (row[FriendMap.name] ?? '').toString().trim();
      if (name.isEmpty) continue;
      if (_isStaleRenamedFriend(renamingIds, row, name)) continue;
      final remoteAt = row['updated_at']?.toString();
      final prev = previousByName[name.toLowerCase()];
      if (prev != null &&
          _keepLocalMoney(
            table: SyncTables.friends.table,
            entity: SyncEntity.friend,
            localId: name,
            remoteUpdatedAt: remoteAt,
          )) {
        serverByName[name.toLowerCase()] = prev;
        continue;
      }
      if (SyncQueue.hasPending(SyncEntity.friendDelete, name) &&
          _keepLocalMoney(
            table: SyncTables.friends.table,
            entity: SyncEntity.friendDelete,
            localId: name,
            remoteUpdatedAt: remoteAt,
          )) {
        continue;
      }
      serverByName[name.toLowerCase()] = FriendMap.toLocal(row);
      _stampMoneyClock(SyncTables.friends.table, name, remoteAt);
    }

    final next = <Map<String, dynamic>>[...serverByName.values];
    for (final f in previous) {
      final name = (f['name'] ?? '').toString().trim();
      if (name.isEmpty) continue;
      final key = name.toLowerCase();
      if (serverByName.containsKey(key)) continue;
      if (SyncQueue.hasPending(SyncEntity.friend, name)) {
        next.add(f);
      }
      // else: deleted on server (or inactive) → drop from local
    }

    if (next.toString() != previous.toString()) {
      box.put('list', next);
      return true;
    }
    return false;
  }

  /// Global default categories + user custom → Hive categories box.
  static Future<bool> _pullCategories(String uid) async {
    try {
      final expense = <String>[];
      final income = <String>[];
      final seenE = <String>{};
      final seenI = <String>{};
      final colors = <String, String>{};

      void addName(String name, String type, [String? color]) {
        final n = name.trim();
        if (n.isEmpty) return;
        final key = n.toLowerCase();
        if (type == 'income') {
          if (!seenI.contains(key)) {
            seenI.add(key);
            income.add(n);
          }
        } else {
          if (!seenE.contains(key)) {
            seenE.add(key);
            expense.add(n);
          }
        }
        final hex = color?.trim() ?? '';
        if (hex.isNotEmpty) colors[key] = hex;
      }

      // Admin global defaults (same source as web Settings categories).
      try {
        final gs =
            await _db
                .from(SupaTables.globalSettings)
                .select('default_categories')
                .eq('id', 'app')
                .maybeSingle();
        final list = gs?['default_categories'];
        if (list is List) {
          for (final item in list) {
            if (item is! Map) continue;
            final name = (item['name'] ?? '').toString();
            final type = (item['type'] ?? 'expense').toString().toLowerCase();
            addName(
              name,
              type == 'income' ? 'income' : 'expense',
              (item['color'] ?? '').toString(),
            );
          }
        }
      } catch (_) {}

      // User custom categories.
      final rows = await _db
          .from(SupaTables.categories)
          .select()
          .eq(CategoryMap.userId, uid)
          .eq(CategoryMap.isActive, true);
      for (final r in rows) {
        final row = Map<String, dynamic>.from(r);
        final name = (row[CategoryMap.name] ?? '').toString();
        final type =
            (row[CategoryMap.type] ?? 'expense').toString().toLowerCase();
        addName(
          name,
          type == 'income' ? 'income' : 'expense',
          (row[CategoryMap.color] ?? '').toString(),
        );
      }

      if (!Hive.isBoxOpen('categories')) {
        await SecureHive.openBox('categories');
      }
      final box = Hive.box('categories');
      void keepPending(String type, List<String> target, Set<String> seen) {
        final raw = box.get(type);
        if (raw is! List) return;
        for (final item in raw) {
          final n = item.toString().trim();
          if (n.isEmpty || seen.contains(n.toLowerCase())) continue;
          if (SyncQueue.hasPending(SyncEntity.category, '${type}_$n')) {
            target.add(n);
            seen.add(n.toLowerCase());
          }
        }
      }

      keepPending('expense', expense, seenE);
      keepPending('income', income, seenI);
      if (expense.isEmpty && income.isEmpty) return false;
      box.put('expense', expense);
      box.put('income', income);
      box.put('colors', colors);
      return true;
    } catch (_) {
      return false;
    }
  }

  /// Pull contributors; always keep default Me.
  static Future<bool> _pullContributors(String uid) async {
    try {
      final rows = await _db
          .from(SupaTables.contributors)
          .select()
          .eq(ContributorMap.userId, uid)
          .eq(ContributorMap.isActive, true);

      final byName = <String, String>{};
      final local = <Map<String, dynamic>>[];
      final previous = <String, Map<String, dynamic>>{};
      if (Hive.isBoxOpen('settings')) {
        final rawPrev = Hive.box('settings').get('contributors');
        if (rawPrev is List) {
          for (final e in rawPrev) {
            if (e is! Map) continue;
            final m = Map<String, dynamic>.from(e);
            final n = (m['name'] ?? '').toString().toLowerCase();
            if (n.isNotEmpty) previous[n] = m;
          }
        }
      }
      for (final r in rows) {
        final row = Map<String, dynamic>.from(r as Map);
        final mapped = ContributorMap.toLocal(row);
        final name = (mapped['name'] ?? '').toString();
        final id = (mapped['id'] ?? '').toString();
        if (name.isEmpty || id.isEmpty) continue;
        byName[name.toLowerCase()] = id;
        final prev = previous[name.toLowerCase()];
        final remoteAt = row['updated_at']?.toString();
        if (prev != null &&
            _keepLocalMoney(
              table: SyncTables.contributors.table,
              entity: SyncEntity.contributor,
              localId: (prev['id'] ?? id).toString(),
              remoteUpdatedAt: remoteAt,
            )) {
          local.add(prev);
          continue;
        }
        local.add(mapped);
        _stampMoneyClock(SyncTables.contributors.table, id, remoteAt);
      }
      RemoteIdCache.replaceContributors(byName);

      if (!Hive.isBoxOpen('settings')) return local.isNotEmpty;
      final settings = Hive.box('settings');
      // Keep pending offline creates not yet on server.
      final rawLocal = settings.get('contributors');
      if (rawLocal is List) {
        final serverNames =
            local
                .map((c) => (c['name'] ?? '').toString().toLowerCase())
                .toSet();
        for (final e in rawLocal) {
          if (e is! Map) continue;
          final m = Map<String, dynamic>.from(e);
          final n = (m['name'] ?? '').toString();
          final id = (m['id'] ?? '').toString();
          if (n.isEmpty) continue;
          if (!serverNames.contains(n.toLowerCase()) &&
              SyncQueue.hasPending(SyncEntity.contributor, id)) {
            local.add(m);
          }
        }
      }

      // Ensure Me exists.
      final hasMe = local.any(
        (c) =>
            c['isDefault'] == true ||
            (c['name'] ?? '').toString().toLowerCase() == 'me',
      );
      if (!hasMe) {
        local.insert(0, {
          'id': SyncIds.forContributor(uid, 'Me'),
          'name': 'Me',
          'isDefault': true,
          'canDelete': false,
          'isActive': true,
        });
      } else {
        for (var i = 0; i < local.length; i++) {
          final n = (local[i]['name'] ?? '').toString().toLowerCase();
          if (local[i]['isDefault'] == true || n == 'me') {
            local[i] = {
              ...local[i],
              'isDefault': true,
              'canDelete': false,
              'isActive': true,
            };
          }
        }
      }

      settings.put('contributors', local);
      return true;
    } catch (_) {
      return false;
    }
  }

  static Future<String?> _resolveRemoteContributorId(
    String uid,
    String? name,
  ) async {
    if (name == null || name.trim().isEmpty) return null;
    final cached = RemoteIdCache.contributorId(name);
    if (cached != null) return cached;
    try {
      final rows = await _db
          .from(SupaTables.contributors)
          .select()
          .eq(ContributorMap.userId, uid)
          .eq(ContributorMap.isActive, true)
          .ilike(ContributorMap.name, name.trim());
      if (rows.isNotEmpty) {
        final row = Map<String, dynamic>.from(rows.first as Map);
        final id = row[ContributorMap.id].toString();
        RemoteIdCache.putContributor(name, id);
        return id;
      }
    } catch (_) {}
    // Create Me / custom on the fly so income splits stay linked.
    final remoteId = SyncIds.forContributor(uid, name.trim());
    try {
      await _db.from(SupaTables.contributors).upsert({
        ContributorMap.id: remoteId,
        ContributorMap.userId: uid,
        ContributorMap.name: name.trim(),
        ContributorMap.isDefault: name.trim().toLowerCase() == 'me',
        ContributorMap.canDelete: name.trim().toLowerCase() != 'me',
        ContributorMap.isActive: true,
      });
      RemoteIdCache.putContributor(name, remoteId);
      return remoteId;
    } catch (_) {
      return null;
    }
  }

  static Future<bool> _pullUserSettings(String uid) async {
    final rows = await _db
        .from(SupaTables.users)
        .select()
        .eq(UserRowMap.id, uid)
        .limit(1);
    if (rows.isEmpty || !Hive.isBoxOpen('settings')) {
      return false;
    }
    final row = Map<String, dynamic>.from(rows.first as Map);
    final settings = Hive.box('settings');
    var changed = false;
    final remoteAt = row['updated_at']?.toString();
    final keepLocal = _keepLocalMoney(
      table: SyncTables.users.table,
      entity: SyncEntity.userSettings,
      localId: uid,
      remoteUpdatedAt: remoteAt,
    );
    if (!keepLocal) {
      if (row.containsKey(UserRowMap.privateMode)) {
        final remote = row[UserRowMap.privateMode] == true;
        if (settings.get('private_mode', defaultValue: false) != remote) {
          settings.put('private_mode', remote);
          changed = true;
        }
      }
      // Profile name from users.name (unless user edited locally).
      final remoteName = row[UserRowMap.name]?.toString().trim();
      if (remoteName != null &&
          remoteName.isNotEmpty &&
          settings.get('profile_name_user_set') != true) {
        if (settings.get('profile_name')?.toString() != remoteName) {
          settings.put('profile_name', remoteName);
          changed = true;
        }
      }
      final defAccId = row[UserRowMap.defaultAccountId]?.toString();
      if (defAccId != null && defAccId.isNotEmpty) {
        final name = RemoteIdCache.accountName(defAccId);
        if (name != null &&
            settings.get('default_account')?.toString() != name) {
          settings.put('default_account', name);
          changed = true;
        }
      }
      _stampMoneyClock(SyncTables.users.table, uid, remoteAt);
    }

    // Web "Reset mobile app PIN" — timestamp only; clear local PIN if needed.
    final resetAt = row[UserRowMap.appPinResetAt]?.toString();
    final pinCleared = await PinService.applyRemotePinResetIfNeeded(resetAt);
    if (pinCleared) {
      changed = true;
      onPinResetApplied?.call();
    }
    return changed;
  }

  /// Lightweight check used from splash / lock "Forgot PIN" without full sync.
  static Future<bool> checkAndApplyPinReset() async {
    if (!_ready) return false;
    try {
      final uid = AuthService.currentUserId!;
      final rows = await _db
          .from(SupaTables.users)
          .select(UserRowMap.appPinResetAt)
          .eq(UserRowMap.id, uid)
          .limit(1);
      if (rows.isEmpty) return false;
      final row = Map<String, dynamic>.from(rows.first as Map);
      final cleared = await PinService.applyRemotePinResetIfNeeded(
        row[UserRowMap.appPinResetAt]?.toString(),
      );
      if (cleared) onPinResetApplied?.call();
      return cleared;
    } catch (_) {
      return false;
    }
  }

  // ─────────────────────── enqueue convenience API ───────────────────────

  static void _kickPush() {
    unawaited(pushPending());
    // If offline / app about to close, WorkManager will push when network is up.
    unawaited(BackgroundSmsScheduler.enqueueDataSync());
  }

  static void queuePurposeUpsert(String name) {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return;
    SyncQueue.enqueue(
      entity: SyncEntity.purpose,
      op: SyncOp.upsert,
      localId: trimmed,
      payload: {'name': trimmed},
    );
    _kickPush();
  }

  static void queuePurposeDelete(String name) {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return;
    SyncQueue.enqueue(
      entity: SyncEntity.purpose,
      op: SyncOp.delete,
      localId: trimmed,
      payload: {'name': trimmed},
    );
    _kickPush();
  }

  static void queueTransactionUpsert(Map<String, dynamic> localJson) {
    final localId = localJson['id'].toString();
    // Ensure remoteId is in the payload for a correct offline→server upsert.
    final payload = Map<String, dynamic>.from(localJson);
    if ((payload['remoteId']?.toString() ?? '').isEmpty) {
      final uid = AuthService.currentUserId;
      if (uid != null) {
        payload['remoteId'] = SyncIds.forTransaction(uid, localId);
      }
    }
    SyncQueue.enqueue(
      entity: SyncEntity.transaction,
      op: SyncOp.upsert,
      localId: localId,
      payload: payload,
    );
    _kickPush();
  }

  /// Offline or online delete — queued until server confirms.
  /// Pass [remoteId] when known so the delete hits the correct Supabase row.
  static void queueTransactionDelete(String localId, {String? remoteId}) {
    recordLocalDelete(localId);
    if (remoteId != null && remoteId.trim().isNotEmpty) {
      recordLocalDelete(remoteId.trim());
    }
    final uid = AuthService.currentUserId;
    final resolvedRemote =
        (remoteId != null && remoteId.trim().isNotEmpty)
            ? remoteId.trim()
            : (uid != null ? SyncIds.forTransaction(uid, localId) : localId);
    recordLocalDelete(resolvedRemote);
    SyncQueue.enqueue(
      entity: SyncEntity.transaction,
      op: SyncOp.delete,
      localId: localId,
      payload: {'remoteId': resolvedRemote, 'id': localId},
    );
    unawaited(pushPending());
  }

  static void queueAccountUpsert(Map<String, dynamic> accountJson) {
    SyncQueue.enqueue(
      entity: SyncEntity.account,
      op: SyncOp.upsert,
      localId: accountJson['name'].toString(),
      payload: accountJson,
    );
    _kickPush();
  }

  static void queueAccountDelete(
    String accountName, {
    String? accountId,
    bool onlyIfNoOthers = false,
  }) {
    SyncQueue.enqueue(
      entity: SyncEntity.account,
      op: SyncOp.delete,
      localId:
          accountId != null && accountId.isNotEmpty ? accountId : accountName,
      payload: {
        'name': accountName,
        if (accountId != null && accountId.isNotEmpty) 'id': accountId,
        'onlyIfNoOthers': onlyIfNoOthers,
      },
    );
    unawaited(pushPending());
  }

  static void queueOutingUpsert(Map<String, dynamic> outingJson) {
    SyncQueue.enqueue(
      entity: SyncEntity.outing,
      op: SyncOp.upsert,
      localId: outingJson['id'].toString(),
      payload: outingJson,
    );
    _kickPush();
  }

  static void queueOutingDelete(String outingId) {
    SyncQueue.enqueue(
      entity: SyncEntity.outing,
      op: SyncOp.delete,
      localId: outingId,
    );
    unawaited(pushPending());
  }

  static void queueFriendSplitUpsert(Map<String, dynamic> friendSplitJson) {
    SyncQueue.enqueue(
      entity: SyncEntity.friendSplit,
      op: SyncOp.upsert,
      localId: friendSplitJson['id'].toString(),
      payload: friendSplitJson,
    );
    _kickPush();
  }

  static void queueFriendSplitDelete(String friendSplitId) {
    SyncQueue.enqueue(
      entity: SyncEntity.friendSplit,
      op: SyncOp.delete,
      localId: friendSplitId,
    );
    _kickPush();
  }

  /// Outings soft-deleted via [queueOutingDelete] / cascade delete, for the
  /// Settings "Deleted Outings" restore list (within 7 days retention).
  static Future<List<Map<String, dynamic>>> fetchDeletedOutings() async {
    if (!_ready) return const [];
    final uid = AuthService.currentUserId!;
    try {
      await _db.rpc('purge_expired_deleted_outings');
    } catch (_) {}
    final sevenDaysAgo =
        DateTime.now()
            .toUtc()
            .subtract(const Duration(days: 7))
            .toIso8601String();
    final rows = await _db
        .from(SupaTables.outings)
        .select()
        .eq(OutingMap.userId, uid)
        .eq(OutingMap.isActive, false)
        .gte('deleted_at', sevenDaysAgo)
        .order('deleted_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows as List);
  }

  /// Reverses a cascade delete — restores the outing and everything it
  /// cascaded (transactions/outing_expenses/settlements), then re-pulls so
  /// local Hive state reflects the restored rows immediately.
  static Future<void> restoreOuting(String outingId) async {
    if (!_ready) return;
    final uid = AuthService.currentUserId!;
    await _db.rpc(
      'restore_deleted_outing',
      params: {'p_outing_id': outingId, 'p_user_id': uid},
    );
    await pullAll(forceNotify: true);
  }

  static void queueFriendUpsert(
    String name,
    String? phone, {
    String? email,
    String? upiId,
    List<String>? upiIds,
    String? notes,
    String? id,
  }) {
    SyncQueue.enqueue(
      entity: SyncEntity.friend,
      op: SyncOp.upsert,
      localId: name,
      payload: {
        if (id != null && id.isNotEmpty) 'id': id,
        'name': name,
        'phone': phone,
        if (email != null) 'email': email,
        if (upiId != null) 'upiId': upiId,
        if (upiIds != null && upiIds.isNotEmpty) 'upiIds': upiIds,
        if (notes != null) 'notes': notes,
      },
    );
    _kickPush();
  }

  static void queueFriendDelete(String name, {String? id}) {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return;
    SyncQueue.enqueue(
      entity: SyncEntity.friendDelete,
      op: SyncOp.delete,
      localId: trimmed,
      payload: {'name': trimmed, if (id != null && id.isNotEmpty) 'id': id},
    );
    _kickPush();
  }

  static void queueUserSettings(Map<String, dynamic> sharedFields) {
    final uid = AuthService.currentUserId;
    if (uid == null) return;
    SyncQueue.enqueue(
      entity: SyncEntity.userSettings,
      op: SyncOp.upsert,
      localId: uid,
      payload: sharedFields,
    );
    _kickPush();
  }

  /// Queue verified SMS merchant for cloud backup (per-user, not global).
  static void queueMerchantUpsert(Map<String, dynamic> merchantJson) {
    final localId =
        merchantJson['id']?.toString() ??
        merchantJson['normalizedPayee']?.toString() ??
        '';
    if (localId.isEmpty) return;
    SyncQueue.enqueue(
      entity: SyncEntity.userMerchant,
      op: SyncOp.upsert,
      localId: localId,
      payload: merchantJson,
    );
    _kickPush();
  }

  static void queueMerchantDelete(String localId, {String? normalizedPayee}) {
    SyncQueue.enqueue(
      entity: SyncEntity.userMerchant,
      op: SyncOp.delete,
      localId: localId,
      payload: {
        'id': localId,
        if (normalizedPayee != null) 'normalizedPayee': normalizedPayee,
      },
    );
    _kickPush();
  }

  static void queueContributorUpsert(Map<String, dynamic> json) {
    final localId = json['id']?.toString() ?? json['name']?.toString() ?? '';
    if (localId.isEmpty) return;
    SyncQueue.enqueue(
      entity: SyncEntity.contributor,
      op: SyncOp.upsert,
      localId: localId,
      payload: json,
    );
    _kickPush();
  }

  static void queueContributorDelete(String localId, {String? name}) {
    SyncQueue.enqueue(
      entity: SyncEntity.contributor,
      op: SyncOp.delete,
      localId: localId,
      payload: {'id': localId, if (name != null) 'name': name},
    );
    _kickPush();
  }

  static void queueCategoryUpsert({
    required String name,
    required String type,
  }) {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return;
    SyncQueue.enqueue(
      entity: SyncEntity.category,
      op: SyncOp.upsert,
      localId: '${type}_$trimmed',
      payload: {'name': trimmed, 'type': type},
    );
    _kickPush();
  }

  /// Custom outing type (Camping, Concert, …) for web/mobile picker parity.
  static void queueOutingCategoryUpsert(String name) {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return;
    SyncQueue.enqueue(
      entity: SyncEntity.outingCategory,
      op: SyncOp.upsert,
      localId: trimmed.toLowerCase(),
      payload: {'name': trimmed, 'sort_order': 50},
    );
    _kickPush();
  }

  static Future<bool> _pullFriendSplits(
    String uid, {
    Set<String>? onlyIds,
  }) async {
    if (!Hive.isBoxOpen('friend_splits')) return false;
    try {
      var splitQuery = _db
          .from(SupaTables.friendSplits)
          .select()
          .eq('user_id', uid);
      var settlementQuery = _db
          .from(SupaTables.friendSettlements)
          .select()
          .eq('user_id', uid);
      if (onlyIds == null) {
        splitQuery = splitQuery.eq('is_active', true);
      } else {
        if (onlyIds.isEmpty) return false;
        final idList = onlyIds.toList();
        splitQuery = splitQuery.inFilter('id', idList);
        settlementQuery = settlementQuery.inFilter('friend_split_id', idList);
      }
      final rows = await splitQuery;
      final list = rows;
      final settlementRows = await settlementQuery;
      final settlementsBySplit = <String, List<Map<String, dynamic>>>{};
      for (final r in settlementRows) {
        final row = Map<String, dynamic>.from(r as Map);
        settlementsBySplit
            .putIfAbsent(row['friend_split_id'].toString(), () => [])
            .add(row);
      }

      final box = Hive.box('friend_splits');
      var changed = false;
      final serverIds = <String>{};

      for (final r in list) {
        final row = Map<String, dynamic>.from(r as Map);
        final remoteId = row['id'].toString();
        final remoteAt = row['updated_at']?.toString();
        final inactive = row['is_active'] == false || row['deleted_at'] != null;
        if (inactive) {
          if (!_keepLocalMoney(
            table: SyncTables.friendSplits.table,
            entity: SyncEntity.friendSplit,
            localId: remoteId,
            remoteUpdatedAt: remoteAt,
          )) {
            if (box.containsKey(remoteId)) {
              box.delete(remoteId);
              changed = true;
            }
            _stampMoneyClock(SyncTables.friendSplits.table, remoteId, remoteAt);
          }
          continue;
        }
        serverIds.add(remoteId);
        if (_keepLocalMoney(
          table: SyncTables.friendSplits.table,
          entity: SyncEntity.friendSplit,
          localId: remoteId,
          remoteUpdatedAt: remoteAt,
        )) {
          continue;
        }

        final doc = FriendSplitMap.toLocal(row);
        doc['id'] = remoteId;
        doc['settlements'] =
            (settlementsBySplit[remoteId] ?? const [])
                .map((s) => FriendSettlementMap.toLocal(s))
                .toList();

        final existing = box.get(remoteId);
        final existingJson =
            existing is Map ? Map<String, dynamic>.from(existing) : null;
        if (existingJson.toString() != doc.toString()) changed = true;
        box.put(remoteId, doc);
        _stampMoneyClock(SyncTables.friendSplits.table, remoteId, remoteAt);
      }

      if (onlyIds != null) return changed;
      // Prune local rows the server no longer has (deleted/deactivated
      // elsewhere), skipping anything with a pending local write.
      for (final key in box.keys.toList()) {
        final id = key.toString();
        if (serverIds.contains(id)) continue;
        if (SyncQueue.hasPending(SyncEntity.friendSplit, id)) continue;
        box.delete(id);
        changed = true;
      }

      return changed;
    } catch (e) {
      debugPrint('_pullFriendSplits failed: $e');
      return false;
    }
  }

  static Future<bool> _pullOutingCategories(String uid) async {
    try {
      final rows = await _db
          .from(SupaTables.outingCategories)
          .select('name,sort_order')
          .eq('user_id', uid)
          .order('sort_order');
      if (rows.isEmpty) {
        // Seed defaults once when empty.
        for (final entry in [
          ('Trip', 1),
          ('Temple', 2),
          ('Restaurant', 3),
          ('Movies', 4),
          ('Family', 5),
          ('Work', 6),
          ('Other', 100),
        ]) {
          try {
            await _db.from(SupaTables.outingCategories).insert({
              'user_id': uid,
              'name': entry.$1,
              'sort_order': entry.$2,
              'is_system': true,
            });
          } catch (_) {}
        }
        final seeded = await _db
            .from(SupaTables.outingCategories)
            .select('name,sort_order')
            .eq('user_id', uid)
            .order('sort_order');
        final names =
            seeded
                .map((r) => (r as Map)['name']?.toString() ?? '')
                .where((n) => n.isNotEmpty)
                .toList();
        if (names.isEmpty) return false;
        if (Hive.isBoxOpen('settings')) {
          Hive.box('settings').put('outing_categories', names);
        }
        return true;
      }
      final names =
          rows
              .map((r) => (r as Map)['name']?.toString() ?? '')
              .where((n) => n.isNotEmpty)
              .toList();
      if (!Hive.isBoxOpen('settings')) return false;
      final box = Hive.box('settings');
      final prev = box.get('outing_categories');
      box.put('outing_categories', names);
      return prev?.toString() != names.toString();
    } catch (_) {
      return false;
    }
  }

  static void queuePlanUpsert(Map<String, dynamic> planJson) {
    final payload = Map<String, dynamic>.from(planJson);
    final localId =
        payload['id']?.toString() ??
        '${payload['month']}_${payload['purposeName'] ?? 'Personal'}';
    if (localId.isEmpty) return;
    final month = (payload['month'] ?? '').toString();
    final purposeName = (payload['purposeName'] ?? 'Personal').toString();
    final uid = AuthService.currentUserId;
    if ((payload['remoteId']?.toString() ?? '').isEmpty && uid != null) {
      payload['remoteId'] =
          SyncIds.isUuid(localId)
              ? localId
              : (month.isEmpty
                  ? localId
                  : SyncIds.forPlan(uid, month, purposeName));
    }
    final updatedAt =
        (payload['updatedAt'] ??
                payload['updated_at'] ??
                DateTime.now().toUtc().toIso8601String())
            .toString();
    payload['updatedAt'] = updatedAt;
    payload['updated_at'] = updatedAt;
    SyncQueue.enqueue(
      entity: SyncEntity.monthlyPlan,
      op: SyncOp.upsert,
      localId: localId,
      payload: payload,
      updatedAt: updatedAt,
    );
    _kickPush();
  }

  static void queuePlanDelete(
    String remoteOrLocalId, {
    String? localId,
    String? month,
    String? purposeName,
  }) {
    final updatedAt = DateTime.now().toUtc().toIso8601String();
    SyncQueue.enqueue(
      entity: SyncEntity.monthlyPlan,
      op: SyncOp.delete,
      localId: localId ?? remoteOrLocalId,
      payload: {
        'remoteId': remoteOrLocalId,
        'id': remoteOrLocalId,
        if (month != null && month.isNotEmpty) 'month': month,
        if (purposeName != null) 'purposeName': purposeName,
      },
      updatedAt: updatedAt,
    );
    _kickPush();
  }

  /// Re-enqueue all local Hive user data and push to server.
  /// Use when mobile has data that never reached the web app (stuck queue /
  /// failed schema writes). Safe: upserts are idempotent by primary key.
  static Future<int> requeueAllLocalDataAndPush() async {
    if (!_ready) return 0;
    await SyncQueue.ensureOpen();
    var n = 0;

    if (Hive.isBoxOpen('settings')) {
      final raw = Hive.box('settings').get('onboardingAccounts');
      if (raw is List) {
        for (final e in raw) {
          if (e is! Map) continue;
          final m = Map<String, dynamic>.from(e);
          final name = (m['name'] ?? '').toString();
          if (name.isEmpty) continue;
          SyncQueue.enqueue(
            entity: SyncEntity.account,
            op: SyncOp.upsert,
            localId: name,
            payload: m,
          );
          n++;
        }
      }
    }

    if (Hive.isBoxOpen('transactions')) {
      final raw =
          Hive.box('transactions').get('list', defaultValue: <dynamic>[])
              as List;
      for (final e in raw) {
        if (e is! Map) continue;
        final m = Map<String, dynamic>.from(e);
        if (m['isPendingVerification'] == true) continue;
        final id = m['id']?.toString() ?? '';
        if (id.isEmpty) continue;
        if ((m['remoteId']?.toString() ?? '').isEmpty) {
          final uid = AuthService.currentUserId;
          if (uid != null) {
            m['remoteId'] = SyncIds.forTransaction(uid, id);
          }
        }
        SyncQueue.enqueue(
          entity: SyncEntity.transaction,
          op: SyncOp.upsert,
          localId: id,
          payload: m,
        );
        n++;
      }
    }

    if (Hive.isBoxOpen('outings')) {
      final box = Hive.box('outings');
      for (final key in box.keys) {
        if (key == 'list') continue;
        final e = box.get(key);
        if (e is! Map) continue;
        final m = Map<String, dynamic>.from(e);
        final id = m['id']?.toString() ?? '';
        if (id.isEmpty) continue;
        SyncQueue.enqueue(
          entity: SyncEntity.outing,
          op: SyncOp.upsert,
          localId: id,
          payload: m,
        );
        n++;
      }
      final legacy = box.get('list');
      if (legacy is List) {
        for (final e in legacy) {
          if (e is! Map) continue;
          final m = Map<String, dynamic>.from(e);
          final id = m['id']?.toString() ?? '';
          if (id.isEmpty) continue;
          SyncQueue.enqueue(
            entity: SyncEntity.outing,
            op: SyncOp.upsert,
            localId: id,
            payload: m,
          );
          n++;
        }
      }
    }

    if (Hive.isBoxOpen('friends')) {
      final box = Hive.box('friends');
      final raw = box.get('list');
      if (raw is List) {
        for (final e in raw) {
          if (e is! Map) continue;
          final m = Map<String, dynamic>.from(e);
          final name = (m['name'] ?? '').toString();
          if (name.isEmpty) continue;
          SyncQueue.enqueue(
            entity: SyncEntity.friend,
            op: SyncOp.upsert,
            localId: name,
            payload: m,
          );
          n++;
        }
      }
    }

    if (Hive.isBoxOpen('monthly_plans')) {
      final raw =
          Hive.box('monthly_plans').get('list', defaultValue: <dynamic>[])
              as List;
      for (final e in raw) {
        if (e is! Map) continue;
        final m = Map<String, dynamic>.from(e);
        final id = m['id']?.toString() ?? '';
        if (id.isEmpty) continue;
        queuePlanUpsert(m);
        n++;
      }
    }

    // Drain queue with fixed schema + name-based account/purpose resolve.
    // Bypass fullSync throttle so repair always pushes immediately.
    _lastFullSyncAt = null;
    if (_syncing) {
      // Wait briefly if a cycle is already running, then push.
      await Future<void>.delayed(const Duration(seconds: 2));
    }
    await pushPending();
    // Second pass after accounts/purposes are cached from first push.
    await pushPending();
    return n;
  }

  static String? get lastPushError {
    if (!Hive.isBoxOpen('settings')) return null;
    return Hive.box('settings').get(lastPushErrorKey)?.toString();
  }

  static int get pendingQueueLength => SyncQueue.length;

  /// Pull monthly plans from Supabase into Hive (web Plan parity).
  static Future<bool> _pullMonthlyPlans(String uid) async {
    try {
      final rows = await _db
          .from(SupaTables.monthlyPlans)
          .select()
          .eq('user_id', uid)
          .order('month', ascending: false);

      final purposeById = <String, String>{};
      try {
        final purposes = await _db
            .from(SupaTables.purposes)
            .select()
            .eq(PurposeMap.userId, uid);
        for (final r in purposes) {
          final id = r[PurposeMap.id]?.toString() ?? '';
          final name = r[PurposeMap.name]?.toString() ?? '';
          if (id.isNotEmpty && name.isNotEmpty) purposeById[id] = name;
        }
      } catch (_) {}

      final local = <Map<String, dynamic>>[];
      final previousPlans = <String, Map<String, dynamic>>{};
      if (Hive.isBoxOpen('monthly_plans')) {
        final rawPlans = Hive.box('monthly_plans').get('list');
        if (rawPlans is List) {
          for (final e in rawPlans) {
            if (e is! Map) continue;
            final m = Map<String, dynamic>.from(e);
            final id = (m['id'] ?? m['remoteId'] ?? '').toString();
            if (id.isNotEmpty) previousPlans[id] = m;
          }
        }
      }
      for (final r in rows) {
        final row = Map<String, dynamic>.from(r);
        final purposeId = row['purpose_id']?.toString();
        final purposeName =
            purposeId != null
                ? (purposeById[purposeId] ?? 'Personal')
                : 'Personal';
        final rawAlloc = row['allocations'];
        final allocs = <Map<String, dynamic>>[];
        if (rawAlloc is List) {
          for (final e in rawAlloc) {
            if (e is! Map) continue;
            final m = Map<String, dynamic>.from(e);
            allocs.add({
              'id': m['id']?.toString() ?? '',
              'category': m['category'] ?? 'Other',
              'plannedAmount':
                  (m['plannedAmount'] as num? ??
                          m['planned_amount'] as num? ??
                          0)
                      .toDouble(),
              if (m['color'] != null) 'color': m['color'],
              'rollover': m['rollover'] == true,
            });
          }
        }
        final planId = row['id']?.toString() ?? '';
        final remoteAt = row['updated_at']?.toString();
        final prevPlan = previousPlans[planId];
        if (prevPlan != null &&
            _keepLocalMoney(
              table: SyncTables.monthlyPlans.table,
              entity: SyncEntity.monthlyPlan,
              localId: planId,
              remoteUpdatedAt: remoteAt,
            )) {
          local.add(prevPlan);
          continue;
        }
        local.add({
          'id': planId,
          'remoteId': planId,
          'month': row['month']?.toString() ?? '',
          'title': row['title'],
          'purposeName': purposeName,
          'expectedIncome': (row['expected_income'] as num? ?? 0).toDouble(),
          'allocations': allocs,
          'dailySafeLimit': (row['daily_safe_limit'] as num?)?.toDouble(),
          'savingsTarget': (row['savings_target'] as num?)?.toDouble(),
          'isBudgetLocked': row['is_budget_locked'] == true,
        });
        _stampMoneyClock(SyncTables.monthlyPlans.table, planId, remoteAt);
      }
      for (final entry in previousPlans.entries) {
        final already = local.any((m) => m['id']?.toString() == entry.key);
        if (already) continue;
        if (SyncQueue.hasPending(SyncEntity.monthlyPlan, entry.key)) {
          local.add(entry.value);
        }
      }

      if (!Hive.isBoxOpen('monthly_plans')) {
        await SecureHive.openBox('monthly_plans');
      }
      Hive.box('monthly_plans').put('list', local);
      return local.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  static DateTime? oldestCachedTransactionDate() {
    if (!Hive.isBoxOpen('transactions')) return null;
    final List<dynamic> raw = Hive.box(
      'transactions',
    ).get('list', defaultValue: []);
    DateTime? oldest;
    for (final e in raw) {
      try {
        final d = DateTime.parse((e as Map)['date'].toString());
        if (oldest == null || d.isBefore(oldest)) oldest = d;
      } catch (_) {}
    }
    return oldest;
  }

  static bool _isMissingColumn(String message) {
    final m = message.toLowerCase();
    return m.contains('42703') ||
        m.contains('pgrst204') ||
        m.contains('schema cache') ||
        m.contains('could not find') ||
        m.contains('deleted_at');
  }

  /// True when the phone should keep its copy.
  ///
  /// No local clock yet: a queued outbox row wins (legacy offline edits).
  /// With a clock: the server wins only when its updated_at is strictly newer,
  /// and the outbox entry is dropped so the next push cannot overwrite it.
  static bool _keepLocalMoney({
    required String table,
    required String entity,
    required String localId,
    required String? remoteUpdatedAt,
  }) {
    final localAt = SyncClocks.get(table, localId);
    if (localAt == null) {
      return SyncQueue.hasPending(entity, localId);
    }
    if (SyncConflict.remoteIsNewer(localAt, remoteUpdatedAt)) {
      SyncQueue.drop(entity, localId);
      return false;
    }
    return true;
  }

  static void _stampMoneyClock(
    String table,
    String localId,
    String? remoteUpdatedAt,
  ) {
    if (remoteUpdatedAt == null || remoteUpdatedAt.isEmpty) return;
    SyncClocks.stamp(table, localId, remoteUpdatedAt);
  }

  /// Accounts + transactions changed since [LocalSyncEngine.cursorKey].
  ///
  /// The first pull only stores the cursor — [_pullAccountsAndPurposes] and
  /// [_pullTransactionsWindow] already filled Hive. Later pulls pick up web
  /// edits, including rows outside the 35-day window and soft-deletes.
  static Future<bool> _pullMoneyDelta(
    String uid, {
    required DateTime nextCursor,
  }) async {
    if (!Hive.isBoxOpen('settings')) return false;
    final settings = Hive.box('settings');
    final cursor = settings.get(LocalSyncEngine.cursorKey)?.toString();
    final cursorIso = nextCursor.toUtc().toIso8601String();
    if (cursor == null || cursor.isEmpty) {
      await settings.put(LocalSyncEngine.cursorKey, cursorIso);
      return false;
    }

    final accountRows = await _selectAll(
      () => _db
          .from(SupaTables.accounts)
          .select()
          .eq(AccountMap.userId, uid)
          .gt('updated_at', cursor),
    );
    final txRows = await _selectAll(
      () => _db
          .from(SupaTables.transactions)
          .select()
          .eq(TransactionMap.userId, uid)
          .gt('updated_at', cursor),
    );

    var changed = _mergeAccountDelta(accountRows);
    changed =
        await _mergeTransactionRows(
          txRows,
          uid,
          reconcileWindow: false,
          honorDeletes: true,
        ) ||
        changed;
    changed = await _pullCatalogDelta(uid, cursor) || changed;
    await settings.put(LocalSyncEngine.cursorKey, cursorIso);
    if (changed) {
      try {
        await AutoDetectionNativeSync.syncAllowedBanksToNative();
      } catch (e) {
        debugPrint('Bank allowlist mirror failed after money delta: $e');
      }
    }
    return changed;
  }

  static bool _mergeAccountDelta(dynamic rows) {
    if (!Hive.isBoxOpen('settings')) return false;
    final list = rows is List ? rows : const <dynamic>[];
    if (list.isEmpty) return false;
    final settings = Hive.box('settings');
    final raw = <Map<String, dynamic>>[];
    final existing = settings.get('onboardingAccounts') ?? [];
    if (existing is List) {
      for (final e in existing) {
        if (e is Map) raw.add(Map<String, dynamic>.from(e));
      }
    }
    var changed = false;
    for (final r in list) {
      if (r is! Map) continue;
      final row = Map<String, dynamic>.from(r);
      final name = (row[AccountMap.name] ?? '').toString();
      if (name.isEmpty) continue;
      final remoteAt = row['updated_at']?.toString();
      final pendingDelete =
          SyncQueue.hasPendingDelete(SyncEntity.account, localId: name) ||
          SyncQueue.hasPendingDelete(
            SyncEntity.account,
            localId: (row[AccountMap.id] ?? '').toString(),
            remoteId: (row[AccountMap.id] ?? '').toString(),
          );
      final deleted = pendingDelete || row['deleted_at'] != null;
      final restore = !deleted && _isBugHiddenAccount(row);
      if (_keepLocalMoney(
        table: SyncTables.accounts.table,
        entity: SyncEntity.account,
        localId: name,
        remoteUpdatedAt: remoteAt,
      )) {
        continue;
      }
      final rowId = (row[AccountMap.id] ?? '').toString();

      final idx = raw.indexWhere((a) {
        if (rowId.isNotEmpty &&
            rowId != 'null' &&
            a['id']?.toString() == rowId) {
          return true;
        }
        if ((a['name'] ?? '').toString().toLowerCase() == name.toLowerCase()) {
          return true;
        }
        return false;
      });
      if (deleted) {
        if (idx >= 0) {
          raw.removeAt(idx);
          changed = true;
        }
        _stampMoneyClock(SyncTables.accounts.table, name, remoteAt);
        continue;
      }
      final mapped = AccountMap.toLocal(row);
      if (restore) mapped['isActive'] = true;
      if (idx >= 0) {
        if (mapped.toString() != raw[idx].toString()) {
          raw[idx] = mapped;
          changed = true;
        }
      } else {
        raw.add(mapped);
        changed = true;
      }
      final remoteId = row[AccountMap.id]?.toString() ?? '';
      if (remoteId.isNotEmpty) {
        RemoteIdCache.putAccount(name, remoteId);
      }
      _stampMoneyClock(SyncTables.accounts.table, name, remoteAt);
    }
    // Same name only. Sharing a last-4 must not delete a different bank.
    final deduped = <Map<String, dynamic>>[];
    final seenN = <String>{};
    for (final acc in raw) {
      final n = (acc['name'] ?? '').toString().trim().toLowerCase();
      if (n.isEmpty) continue;
      if (seenN.contains(n)) continue;
      seenN.add(n);
      deduped.add(acc);
    }
    if (deduped.length != raw.length) {
      raw
        ..clear()
        ..addAll(deduped);
      changed = true;
    }
    if (changed) {
      settings.put('onboardingAccounts', raw);
    }
    return changed;
  }

  static bool _keepAnyLocal({
    required String table,
    required String entity,
    required List<String> localIds,
    required String? remoteUpdatedAt,
  }) {
    final ids = localIds.where((id) => id.isNotEmpty).toList();
    String? newest;
    var pending = false;
    for (final id in ids) {
      if (SyncQueue.hasPending(entity, id)) pending = true;
      final clock = SyncClocks.get(table, id);
      if (clock == null) continue;
      if (newest == null || SyncConflict.remoteIsNewer(newest, clock)) {
        newest = clock;
      }
    }
    if (newest == null) return pending;
    if (SyncConflict.remoteIsNewer(newest, remoteUpdatedAt)) {
      for (final id in ids) {
        SyncQueue.drop(entity, id);
      }
      return false;
    }
    return true;
  }

  /// Empty list when the table has no `updated_at` yet (migration not applied).
  /// Other errors propagate so the cursor is not moved past missed rows.
  static Future<List<Map<String, dynamic>>> _selectUpdatedSince(
    String table,
    String uid,
    String cursor, {
    String userColumn = 'user_id',
  }) async {
    try {
      final rows = await _selectAll(
        () => _db
            .from(table)
            .select()
            .eq(userColumn, uid)
            .gt('updated_at', cursor),
      );
      return [
        for (final r in (rows as List))
          if (r is Map) Map<String, dynamic>.from(r),
      ];
    } catch (e) {
      if (e is PostgrestException &&
          (e.code == '42703' || e.code == 'PGRST204')) {
        debugPrint('Delta skip $table until updated_at exists: $e');
        return const [];
      }
      rethrow;
    }
  }

  static Future<bool> _pullCatalogDelta(String uid, String cursor) async {
    var changed = false;
    changed =
        _mergePurposeDelta(
          await _selectUpdatedSince(SupaTables.purposes, uid, cursor),
        ) ||
        changed;
    changed =
        _mergeCategoryDelta(
          await _selectUpdatedSince(SupaTables.categories, uid, cursor),
        ) ||
        changed;
    changed =
        _mergeContributorDelta(
          await _selectUpdatedSince(SupaTables.contributors, uid, cursor),
        ) ||
        changed;
    changed =
        _mergeFriendDelta(
          await _selectUpdatedSince(SupaTables.friends, uid, cursor),
        ) ||
        changed;
    changed =
        await _mergeMerchantDelta(
          await _selectUpdatedSince(SupaTables.userMerchants, uid, cursor),
        ) ||
        changed;
    changed =
        _mergePlanDelta(
          await _selectUpdatedSince(SupaTables.monthlyPlans, uid, cursor),
        ) ||
        changed;
    changed =
        _mergeOutingCategoryDelta(
          await _selectUpdatedSince(SupaTables.outingCategories, uid, cursor),
        ) ||
        changed;
    final outingRows = await _selectUpdatedSince(
      SupaTables.outings,
      uid,
      cursor,
    );
    if (outingRows.isNotEmpty) {
      final ids =
          outingRows
              .map((r) => r['id']?.toString() ?? '')
              .where((id) => id.isNotEmpty)
              .toSet();
      changed = await _pullOutings(uid, onlyIds: ids) || changed;
    }
    final splitRows = await _selectUpdatedSince(
      SupaTables.friendSplits,
      uid,
      cursor,
    );
    if (splitRows.isNotEmpty) {
      final ids =
          splitRows
              .map((r) => r['id']?.toString() ?? '')
              .where((id) => id.isNotEmpty)
              .toSet();
      changed = await _pullFriendSplits(uid, onlyIds: ids) || changed;
    }
    final userRows = await _selectUpdatedSince(
      SupaTables.users,
      uid,
      cursor,
      userColumn: 'id',
    );
    if (userRows.isNotEmpty) {
      changed = await _pullUserSettings(uid) || changed;
    }
    return changed;
  }

  static bool _rowDeleted(Map<String, dynamic> row) =>
      row['is_active'] == false || row['deleted_at'] != null;

  /// Account hidden by the duplicate cleaner: inactive, but never deleted.
  /// User deletes write deleted_at. Those stay hidden.
  static bool _isBugHiddenAccount(Map<String, dynamic> row) {
    if (row['deleted_at'] != null) return false;
    return row[AccountMap.isActive] == false;
  }

  static bool _mergePurposeDelta(List<Map<String, dynamic>> rows) {
    if (rows.isEmpty || !Hive.isBoxOpen('settings')) return false;
    final settings = Hive.box('settings');
    final names = List<String>.from(
      settings.get('purposeTypes', defaultValue: <String>[]) ?? [],
    );
    var changed = false;
    for (final row in rows) {
      final name = (row[PurposeMap.name] ?? '').toString().trim();
      if (name.isEmpty) continue;
      final remoteAt = row['updated_at']?.toString();
      if (_keepLocalMoney(
        table: SyncTables.purposes.table,
        entity: SyncEntity.purpose,
        localId: name,
        remoteUpdatedAt: remoteAt,
      )) {
        continue;
      }
      final deleted = _rowDeleted(row);
      final idx = names.indexWhere(
        (n) => n.toLowerCase() == name.toLowerCase(),
      );
      if (deleted) {
        if (idx >= 0) {
          names.removeAt(idx);
          changed = true;
        }
      } else if (idx < 0) {
        names.add(name);
        changed = true;
      }
      final id = row[PurposeMap.id]?.toString() ?? '';
      if (id.isNotEmpty) RemoteIdCache.putPurpose(name, id);
      _stampMoneyClock(SyncTables.purposes.table, name, remoteAt);
    }
    if (changed) settings.put('purposeTypes', names);
    return changed;
  }

  static bool _mergeCategoryDelta(List<Map<String, dynamic>> rows) {
    if (rows.isEmpty) return false;
    if (!Hive.isBoxOpen('categories')) return false;
    final box = Hive.box('categories');
    List<String> read(String type) {
      final raw = box.get(type);
      if (raw is! List) return <String>[];
      return raw.map((e) => e.toString()).toList();
    }

    final expense = read('expense');
    final income = read('income');
    final colors = <String, String>{};
    final rawColors = box.get('colors');
    if (rawColors is Map) {
      rawColors.forEach((key, value) {
        final name = key.toString().trim().toLowerCase();
        final hex = value.toString().trim();
        if (name.isNotEmpty && hex.isNotEmpty) colors[name] = hex;
      });
    }
    var changed = false;
    for (final row in rows) {
      final name = (row['name'] ?? '').toString().trim();
      if (name.isEmpty) continue;
      final type =
          (row['type'] ?? 'expense').toString().toLowerCase() == 'income'
              ? 'income'
              : 'expense';
      final remoteAt = row['updated_at']?.toString();
      final localId = '${type}_$name';
      if (_keepLocalMoney(
        table: SyncTables.categories.table,
        entity: SyncEntity.category,
        localId: localId,
        remoteUpdatedAt: remoteAt,
      )) {
        continue;
      }
      final target = type == 'income' ? income : expense;
      final idx = target.indexWhere(
        (n) => n.toLowerCase() == name.toLowerCase(),
      );
      if (_rowDeleted(row)) {
        if (idx >= 0) {
          target.removeAt(idx);
          changed = true;
        }
      } else if (idx < 0) {
        target.add(name);
        changed = true;
      }
      if (!_rowDeleted(row)) {
        final hex = (row['color'] ?? '').toString().trim();
        if (hex.isNotEmpty && colors[name.toLowerCase()] != hex) {
          colors[name.toLowerCase()] = hex;
          changed = true;
        }
      }
      _stampMoneyClock(SyncTables.categories.table, localId, remoteAt);
    }
    if (changed) {
      box.put('expense', expense);
      box.put('income', income);
      box.put('colors', colors);
    }
    return changed;
  }

  static bool _mergeContributorDelta(List<Map<String, dynamic>> rows) {
    if (rows.isEmpty || !Hive.isBoxOpen('settings')) return false;
    final settings = Hive.box('settings');
    final raw = <Map<String, dynamic>>[];
    final existing = settings.get('contributors');
    if (existing is List) {
      for (final e in existing) {
        if (e is Map) raw.add(Map<String, dynamic>.from(e));
      }
    }
    var changed = false;
    for (final row in rows) {
      final mapped = ContributorMap.toLocal(row);
      final name = (mapped['name'] ?? '').toString();
      final id = (mapped['id'] ?? '').toString();
      if (name.isEmpty || id.isEmpty) continue;
      final remoteAt = row['updated_at']?.toString();
      if (_keepLocalMoney(
        table: SyncTables.contributors.table,
        entity: SyncEntity.contributor,
        localId: id,
        remoteUpdatedAt: remoteAt,
      )) {
        continue;
      }
      final idx = raw.indexWhere(
        (c) => (c['name'] ?? '').toString().toLowerCase() == name.toLowerCase(),
      );
      if (_rowDeleted(row)) {
        if (idx >= 0) {
          raw.removeAt(idx);
          changed = true;
        }
      } else if (idx >= 0) {
        raw[idx] = mapped;
        changed = true;
      } else {
        raw.add(mapped);
        changed = true;
      }
      RemoteIdCache.putContributor(name, id);
      _stampMoneyClock(SyncTables.contributors.table, id, remoteAt);
    }
    if (changed) settings.put('contributors', raw);
    return changed;
  }

  /// Server id -> local (new) name for friends with a queued upsert. While a
  /// rename is still queued the server row carries the old name; pulling it
  /// would briefly resurrect the old friend next to the renamed one.
  static Map<String, String> _pendingFriendRenameIds(
    List<Map<String, dynamic>> local,
  ) {
    final out = <String, String>{};
    for (final f in local) {
      final id = (f['id'] ?? '').toString();
      final name = (f['name'] ?? '').toString().trim();
      if (id.isEmpty || name.isEmpty) continue;
      if (SyncQueue.hasPending(SyncEntity.friend, name)) {
        out[id] = name.toLowerCase();
      }
    }
    return out;
  }

  static bool _isStaleRenamedFriend(
    Map<String, String> renamingIds,
    Map<String, dynamic> row,
    String remoteName,
  ) {
    final id = (row[FriendMap.id] ?? '').toString();
    final localName = renamingIds[id];
    return localName != null && localName != remoteName.toLowerCase();
  }

  static bool _mergeFriendDelta(List<Map<String, dynamic>> rows) {
    if (rows.isEmpty || !Hive.isBoxOpen('friends')) return false;
    final box = Hive.box('friends');
    final raw = box.get('list', defaultValue: <dynamic>[]);
    final list =
        raw is List
            ? raw
                .whereType<Map>()
                .map((e) => Map<String, dynamic>.from(e))
                .toList()
            : <Map<String, dynamic>>[];
    var changed = false;
    final renamingIds = _pendingFriendRenameIds(list);
    for (final row in rows) {
      final name = (row[FriendMap.name] ?? '').toString().trim();
      if (name.isEmpty) continue;
      if (_isStaleRenamedFriend(renamingIds, row, name)) continue;
      final remoteAt = row['updated_at']?.toString();
      if (_keepLocalMoney(
            table: SyncTables.friends.table,
            entity: SyncEntity.friend,
            localId: name,
            remoteUpdatedAt: remoteAt,
          ) ||
          _keepLocalMoney(
            table: SyncTables.friends.table,
            entity: SyncEntity.friendDelete,
            localId: name,
            remoteUpdatedAt: remoteAt,
          )) {
        continue;
      }
      final idx = list.indexWhere(
        (f) => (f['name'] ?? '').toString().toLowerCase() == name.toLowerCase(),
      );
      if (_rowDeleted(row)) {
        if (idx >= 0) {
          list.removeAt(idx);
          changed = true;
        }
      } else if (idx >= 0) {
        list[idx] = FriendMap.toLocal(row);
        changed = true;
      } else {
        list.add(FriendMap.toLocal(row));
        changed = true;
      }
      _stampMoneyClock(SyncTables.friends.table, name, remoteAt);
    }
    if (changed) box.put('list', list);
    return changed;
  }

  static Future<bool> _mergeMerchantDelta(
    List<Map<String, dynamic>> rows,
  ) async {
    if (rows.isEmpty) return false;
    if (!Hive.isBoxOpen('merchants_box')) {
      await SecureHive.openBox('merchants_box');
    }
    final box = Hive.box('merchants_box');
    var changed = false;
    for (final row in rows) {
      final local = UserMerchantMap.toLocal(row);
      final norm = (local['normalizedPayee'] ?? '').toString();
      final id = local['id']?.toString() ?? '';
      if (norm.isEmpty && id.isEmpty) continue;
      final remoteAt = row['updated_at']?.toString();
      if (_keepAnyLocal(
        table: SyncTables.userMerchants.table,
        entity: SyncEntity.userMerchant,
        localIds: [id, norm],
        remoteUpdatedAt: remoteAt,
      )) {
        continue;
      }
      final key = id.isNotEmpty ? id : norm;
      await box.put(key, local);
      _stampMoneyClock(SyncTables.userMerchants.table, id, remoteAt);
      _stampMoneyClock(SyncTables.userMerchants.table, norm, remoteAt);
      changed = true;
    }
    return changed;
  }

  static bool _mergePlanDelta(List<Map<String, dynamic>> rows) {
    if (rows.isEmpty) return false;
    if (!Hive.isBoxOpen('monthly_plans')) return false;
    final box = Hive.box('monthly_plans');
    final raw = box.get('list', defaultValue: <dynamic>[]);
    final list =
        raw is List
            ? raw
                .whereType<Map>()
                .map((e) => Map<String, dynamic>.from(e))
                .toList()
            : <Map<String, dynamic>>[];
    var changed = false;
    for (final row in rows) {
      final id = row['id']?.toString() ?? '';
      if (id.isEmpty) continue;
      final remoteAt = row['updated_at']?.toString();
      if (_keepLocalMoney(
        table: SyncTables.monthlyPlans.table,
        entity: SyncEntity.monthlyPlan,
        localId: id,
        remoteUpdatedAt: remoteAt,
      )) {
        continue;
      }
      final purposeId = row['purpose_id']?.toString();
      final mapped = {
        'id': id,
        'remoteId': id,
        'month': row['month']?.toString() ?? '',
        'title': row['title'],
        'purposeName':
            purposeId == null
                ? 'Personal'
                : (RemoteIdCache.purposeName(purposeId) ?? 'Personal'),
        'expectedIncome': (row['expected_income'] as num? ?? 0).toDouble(),
        'allocations': row['allocations'] is List ? row['allocations'] : [],
        'dailySafeLimit': (row['daily_safe_limit'] as num?)?.toDouble(),
        'savingsTarget': (row['savings_target'] as num?)?.toDouble(),
        'isBudgetLocked': row['is_budget_locked'] == true,
      };
      final idx = list.indexWhere((m) => m['id']?.toString() == id);
      if (idx >= 0) {
        list[idx] = mapped;
      } else {
        list.add(mapped);
      }
      _stampMoneyClock(SyncTables.monthlyPlans.table, id, remoteAt);
      changed = true;
    }
    if (changed) box.put('list', list);
    return changed;
  }

  static bool _mergeOutingCategoryDelta(List<Map<String, dynamic>> rows) {
    if (rows.isEmpty || !Hive.isBoxOpen('settings')) return false;
    final settings = Hive.box('settings');
    final names = <String>[];
    final raw = settings.get('outing_categories');
    if (raw is List) {
      for (final e in raw) {
        final n = e.toString().trim();
        if (n.isNotEmpty) names.add(n);
      }
    }
    var changed = false;
    for (final row in rows) {
      final name = (row['name'] ?? '').toString().trim();
      if (name.isEmpty) continue;
      final remoteAt = row['updated_at']?.toString();
      if (_keepLocalMoney(
        table: SyncTables.outingCategories.table,
        entity: SyncEntity.outingCategory,
        localId: name.toLowerCase(),
        remoteUpdatedAt: remoteAt,
      )) {
        continue;
      }
      if (!names.any((n) => n.toLowerCase() == name.toLowerCase())) {
        names.add(name);
        changed = true;
      }
      _stampMoneyClock(
        SyncTables.outingCategories.table,
        name.toLowerCase(),
        remoteAt,
      );
    }
    if (changed) settings.put('outing_categories', names);
    return changed;
  }
}
