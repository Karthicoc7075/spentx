/// Core barrel — theme, Soft palette, router, shared Soft navigation.
library;

export 'navigation/main_shell_navigation.dart';
export 'navigation/soft_bottom_nav.dart';
export 'router/app_router.dart';
export 'theme/app_colors.dart';
export 'theme/app_theme.dart';
export 'theme/soft_palette.dart';
export 'theme/spentx_tokens.dart';
