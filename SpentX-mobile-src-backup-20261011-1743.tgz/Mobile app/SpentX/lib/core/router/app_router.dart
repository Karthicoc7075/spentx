import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../features/auth/presentation/splash_screen.dart';
import '../../features/auth/presentation/onboarding_screen.dart';
import '../../features/auth/presentation/pin_setup_screen.dart';
import '../../features/auth/presentation/lock_screen.dart';
import '../../features/auth/presentation/auth_landing_screen.dart';
import '../../features/auth/presentation/auth_signup_screen.dart';
import '../../features/auth/presentation/auth_login_screen.dart';
import '../../features/auth/presentation/auth_forgot_password_screen.dart';
import '../../features/auth/presentation/auth_reset_password_screen.dart';
import '../../features/auth/presentation/auth_verify_email_screen.dart';
import '../../features/auth/presentation/auth_callback_screen.dart';
import '../services/auth_service.dart';
import '../utils/auth_routing_rules.dart';
import '../../features/home/presentation/main_wrapper.dart';
import '../../features/investments/presentation/investments_screen.dart';
import '../../features/groups/presentation/groups_screen.dart';
import '../../features/groups/presentation/group_detail_screen.dart';
import '../../features/plan/presentation/plan_screen.dart';
import '../../features/recurring/presentation/recurring_screen.dart';
import '../../features/notifications/presentation/notifications_screen.dart';
import '../../features/calendar/presentation/calendar_screen.dart';
import '../../features/export/presentation/export_screen.dart';
import '../../features/accounts/presentation/accounts_screen.dart';
import '../../features/accounts/presentation/account_detail_screen.dart';
import '../../features/accounts/presentation/account_discovery_screen.dart';
import '../../features/transactions/presentation/transactions_screen.dart';
import '../../features/transactions/presentation/transaction_detail_screen.dart';
import '../../features/friends/presentation/friends_screen.dart';
import '../../features/settings/presentation/merchant_names_screen.dart';
import '../../features/settings/presentation/app_guide_screen.dart';
import '../../features/settings/presentation/screens/developer_options_screen.dart';
import '../../features/settings/presentation/screens/sms_rules_storage_screen.dart';
import '../../features/settings/presentation/screens/master_debug_log_screen.dart';
import '../../features/settings/presentation/screens/notification_preferences_screen.dart';
import '../../features/sms/detected/sms_detection_lab_screen.dart';
import '../../features/sms/detected/real_sms_test_screen.dart';
import '../../features/sms/detected/detected_sms_screen.dart';
import '../../features/sms/rules/presentation/sms_rule_manager_screen.dart';
import '../../features/sms/rules/presentation/block_sms_screen.dart';
import '../../features/settings/presentation/screens/purpose_sharing_screen.dart';

import 'package:hive_flutter/hive_flutter.dart';
import '../providers/animation_provider.dart';

/// Global navigator key for root navigation (used by go_router and for context in callbacks)
final GlobalKey<NavigatorState> rootNavigatorKey = GlobalKey<NavigatorState>();

Page<dynamic> _animatedPage(
  BuildContext context,
  GoRouterState state,
  Widget child,
) {
  bool enabled = true;
  String styleStr = 'smooth';
  try {
    if (Hive.isBoxOpen('settings')) {
      final box = Hive.box('settings');
      enabled = box.get('animations_enabled', defaultValue: true) as bool;
      styleStr = box.get('animation_style', defaultValue: 'smooth') as String;
    }
  } catch (_) {}

  if (!enabled || styleStr == 'reduceMotion') {
    return NoTransitionPage<dynamic>(key: state.pageKey, child: child);
  }

  final style = AppAnimationStyle.values.firstWhere(
    (e) => e.name == styleStr,
    orElse: () => AppAnimationStyle.smooth,
  );

  Duration duration;
  Curve curve;

  switch (style) {
    case AppAnimationStyle.fast:
    case AppAnimationStyle.batterySaver:
    case AppAnimationStyle.minimal:
      duration = const Duration(milliseconds: 160);
      curve = Curves.easeOutQuad;
      break;
    case AppAnimationStyle.elegant:
      duration = const Duration(milliseconds: 380);
      curve = Curves.easeInOutCubic;
      break;
    case AppAnimationStyle.playful:
    case AppAnimationStyle.iosStyle:
      duration = const Duration(milliseconds: 320);
      curve = Curves.easeOutBack;
      break;
    case AppAnimationStyle.premium:
      duration = const Duration(milliseconds: 280);
      curve = Curves.easeOutCubic;
      break;
    case AppAnimationStyle.material:
    case AppAnimationStyle.androidNative:
      duration = const Duration(milliseconds: 260);
      curve = Curves.fastOutSlowIn;
      break;
    case AppAnimationStyle.smooth:
    default:
      duration = const Duration(milliseconds: 250);
      curve = Curves.easeOutCubic;
  }

  return CustomTransitionPage<dynamic>(
    key: state.pageKey,
    child: child,
    transitionDuration: duration,
    reverseTransitionDuration: duration,
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      final curvedAnim = CurvedAnimation(parent: animation, curve: curve);

      switch (style) {
        case AppAnimationStyle.fast:
        case AppAnimationStyle.minimal:
          return FadeTransition(opacity: curvedAnim, child: child);

        case AppAnimationStyle.iosStyle:
          const begin = Offset(1.0, 0.0);
          const end = Offset.zero;
          final slide = Tween(begin: begin, end: end).animate(curvedAnim);
          return SlideTransition(position: slide, child: child);

        case AppAnimationStyle.playful:
          final scale = Tween<double>(
            begin: 0.90,
            end: 1.0,
          ).animate(curvedAnim);
          final fade = Tween<double>(begin: 0.0, end: 1.0).animate(curvedAnim);
          return ScaleTransition(
            scale: scale,
            child: FadeTransition(opacity: fade, child: child),
          );

        case AppAnimationStyle.material:
        case AppAnimationStyle.androidNative:
        case AppAnimationStyle.premium:
        case AppAnimationStyle.elegant:
          final scale = Tween<double>(
            begin: 0.94,
            end: 1.0,
          ).animate(curvedAnim);
          final slide = Tween<Offset>(
            begin: const Offset(0.0, 0.04),
            end: Offset.zero,
          ).animate(curvedAnim);
          return SlideTransition(
            position: slide,
            child: ScaleTransition(
              scale: scale,
              child: FadeTransition(opacity: curvedAnim, child: child),
            ),
          );

        case AppAnimationStyle.smooth:
        default:
          const begin = Offset(0.04, 0.0);
          const end = Offset.zero;
          final slide = Tween(begin: begin, end: end).animate(curvedAnim);
          return SlideTransition(
            position: slide,
            child: FadeTransition(opacity: curvedAnim, child: child),
          );
      }
    },
  );
}

final GoRouter appRouter = GoRouter(
  navigatorKey: rootNavigatorKey,
  initialLocation: '/',
  // Cold-start from spentx://auth/callback must NOT become the initial
  // go_router location — that path was unmatched → black/error screen while
  // supabase_flutter exchanged the PKCE code. Supabase still consumes the
  // link via app_links; we always boot through splash (or the explicit
  // /auth/callback wait route when something navigates there).
  overridePlatformDefaultLocation: true,
  onException: (context, state, router) {
    final path = state.uri.path;
    final host = state.uri.host;
    final isAuthCallback =
        path == '/auth/callback' ||
        path == '/callback' ||
        (host == 'auth' && path.startsWith('/callback'));
    final isReset = path == '/reset-password' || host == 'reset-password';
    if (isAuthCallback) {
      router.go('/auth/callback');
      return;
    }
    if (isReset) {
      router.go('/auth/reset-password');
      return;
    }
    router.go(AuthService.isSignedIn ? '/' : '/auth');
  },
  redirect: (context, state) {
    final loc = state.matchedLocation;
    final uriPath = state.uri.path;
    final host = state.uri.host;
    // Normalize custom-scheme deep links that still reach the router
    // (warm start / tests) onto real screens.
    final isAuthCallback =
        loc == '/auth/callback' ||
        loc == '/callback' ||
        uriPath == '/auth/callback' ||
        uriPath == '/callback' ||
        (host == 'auth' && uriPath.startsWith('/callback'));
    if (isAuthCallback && loc != '/auth/callback') {
      return '/auth/callback';
    }
    bool? setupCompleted;
    var permissionsPending = false;
    var pinLock = false;
    try {
      if (Hive.isBoxOpen('settings')) {
        final box = Hive.box('settings');
        final cached = box.get(AuthService.accountHasDataKey);
        if (cached is bool) setupCompleted = cached;
        permissionsPending =
            box.get(AuthService.permissionsPromptPendingKey) == true;
        final hasPin = box.get('has_pin', defaultValue: false) == true;
        final lockEnabled =
            box.get('lock_screen_enabled', defaultValue: true) == true;
        pinLock = hasPin && lockEnabled;
      }
    } catch (_) {}
    // Email-confirm sessions, unfinished setup, and signed-out routes.
    // See [authRedirect]. /auth/callback stays here so its wait UI can
    // hand a confirm link back to the verify screen instead of Home.
    return authRedirect(
      loc: loc,
      signedIn: AuthService.isSignedIn,
      pendingEmail: AuthService.pendingVerificationEmail,
      lastSignedInEmail: AuthService.previousAccountEmail(),
      verifiedAwaitingLogin: AuthService.verifiedAwaitingLogin,
      setupCompleted: setupCompleted,
      permissionsPromptPending: permissionsPending,
      pinLock: pinLock,
    );
  },
  routes: [
    GoRoute(
      path: '/',
      pageBuilder:
          (context, state) =>
              _animatedPage(context, state, const SplashScreen()),
    ),
    GoRoute(
      path: '/auth',
      pageBuilder: (context, state) {
        final expired = state.uri.queryParameters['expired'] == 'true';
        return _animatedPage(
          context,
          state,
          AuthLandingScreen(sessionExpired: expired),
        );
      },
    ),
    GoRoute(
      path: '/auth/signup',
      pageBuilder:
          (context, state) =>
              _animatedPage(context, state, const AuthSignUpScreen()),
    ),
    GoRoute(
      path: '/auth/login',
      pageBuilder: (context, state) {
        final expired = state.uri.queryParameters['expired'] == 'true';
        return _animatedPage(
          context,
          state,
          AuthLoginScreen(sessionExpired: expired),
        );
      },
    ),
    GoRoute(
      path: '/auth/forgot-password',
      pageBuilder:
          (context, state) =>
              _animatedPage(context, state, const AuthForgotPasswordScreen()),
    ),
    GoRoute(
      path: '/auth/reset-password',
      pageBuilder:
          (context, state) =>
              _animatedPage(context, state, const AuthResetPasswordScreen()),
    ),
    GoRoute(
      path: '/auth/verify-email',
      pageBuilder:
          (context, state) => _animatedPage(
            context,
            state,
            AuthVerifyEmailScreen(
              email: state.extra as String?,
              verified: state.uri.queryParameters['verified'] == '1',
            ),
          ),
    ),
    // Email-confirm / OAuth deep link target (spentx://auth/callback).
    GoRoute(
      path: '/auth/callback',
      pageBuilder:
          (context, state) =>
              _animatedPage(context, state, const AuthCallbackScreen()),
    ),
    // Some platforms report only the path of spentx://auth/callback.
    GoRoute(path: '/callback', redirect: (_, __) => '/auth/callback'),
    GoRoute(
      path: '/onboarding',
      pageBuilder:
          (context, state) => _animatedPage(
            context,
            state,
            OnboardingScreen(
              resumePermissions:
                  state.uri.queryParameters['resume'] == 'permissions',
            ),
          ),
    ),
    GoRoute(
      path: '/pin-setup',
      pageBuilder:
          (context, state) =>
              _animatedPage(context, state, const PinSetupScreen()),
    ),
    GoRoute(
      path: '/lock',
      pageBuilder: (context, state) {
        final rawRedirect = state.uri.queryParameters['redirect'] ??
            (state.extra is String ? state.extra as String : null);
        final redirect = (rawRedirect != null &&
                rawRedirect.isNotEmpty &&
                !rawRedirect.startsWith('/lock') &&
                !rawRedirect.startsWith('/splash'))
            ? rawRedirect
            : '/home';
        return _animatedPage(
          context,
          state,
          LockScreen(redirectTo: redirect),
        );
      },
    ),
    GoRoute(
      path: '/home',
      pageBuilder:
          (context, state) =>
              _animatedPage(context, state, const MainWrapper()),
    ),
    GoRoute(
      path: '/activity',
      pageBuilder: (context, state) {
        final purpose = state.uri.queryParameters['purpose'];
        return _animatedPage(
          context,
          state,
          TransactionsScreen(
            initialPurpose:
                purpose == null || purpose.isEmpty
                    ? null
                    : Uri.decodeComponent(purpose),
          ),
        );
      },
    ),
    GoRoute(
      path: '/investments',
      pageBuilder:
          (context, state) =>
              _animatedPage(context, state, const InvestmentsScreen()),
    ),
    GoRoute(path: '/wealth', redirect: (_, __) => '/accounts?view=wealth'),
    GoRoute(
      path: '/outings',
      pageBuilder:
          (context, state) =>
              _animatedPage(context, state, const GroupsScreen()),
    ),
    GoRoute(
      path: '/outing-detail/:id',
      pageBuilder:
          (context, state) => _animatedPage(
            context,
            state,
            GroupDetailScreen(groupId: state.pathParameters['id'] ?? ''),
          ),
    ),
    GoRoute(
      path: '/plan',
      pageBuilder:
          (context, state) => _animatedPage(context, state, const PlanScreen()),
    ),
    GoRoute(path: '/budgets', redirect: (_, __) => '/plan'),
    GoRoute(
      path: '/recurring',
      pageBuilder:
          (context, state) =>
              _animatedPage(context, state, const RecurringScreen()),
    ),
    GoRoute(
      path: '/notifications',
      pageBuilder:
          (context, state) =>
              _animatedPage(context, state, const NotificationsScreen()),
    ),
    GoRoute(
      path: '/notification-preferences',
      pageBuilder:
          (context, state) => _animatedPage(
            context,
            state,
            const NotificationPreferencesScreen(),
          ),
    ),
    GoRoute(path: '/search', redirect: (_, __) => '/activity'),
    GoRoute(
      path: '/calendar',
      pageBuilder:
          (context, state) =>
              _animatedPage(context, state, const CalendarScreen()),
    ),
    GoRoute(
      path: '/export',
      pageBuilder:
          (context, state) =>
              _animatedPage(context, state, const ExportScreen()),
    ),
    GoRoute(
      path: '/accounts',
      pageBuilder: (context, state) {
        final showWealth = state.uri.queryParameters['view'] == 'wealth';
        return _animatedPage(
          context,
          state,
          AccountsScreen(initialWealth: showWealth),
        );
      },
    ),
    GoRoute(
      path: '/account-discovery',
      pageBuilder:
          (context, state) =>
              _animatedPage(context, state, const AccountDiscoveryScreen()),
    ),
    GoRoute(
      path: '/account-detail/:name',
      pageBuilder:
          (context, state) => _animatedPage(
            context,
            state,
            AccountDetailScreen(
              accountName: Uri.decodeComponent(
                state.pathParameters['name'] ?? '',
              ),
            ),
          ),
    ),
    GoRoute(
      path: '/transaction/:id',
      pageBuilder:
          (context, state) => _animatedPage(
            context,
            state,
            TransactionDetailScreen(id: state.pathParameters['id']),
          ),
    ),
    GoRoute(
      path: '/outing-expense/:outingId/:expenseId',
      pageBuilder:
          (context, state) => _animatedPage(
            context,
            state,
            TransactionDetailScreen(
              outingId: state.pathParameters['outingId'],
              expenseId: state.pathParameters['expenseId'],
            ),
          ),
    ),
    GoRoute(
      path: '/friends',
      pageBuilder:
          (context, state) =>
              _animatedPage(context, state, const FriendsScreen()),
    ),
    GoRoute(
      path: '/sms-detection-lab',
      pageBuilder:
          (context, state) =>
              _animatedPage(context, state, const SmsDetectionLabScreen()),
    ),
    GoRoute(
      path: '/real-sms-test',
      pageBuilder:
          (context, state) =>
              _animatedPage(context, state, const RealSmsTestScreen()),
    ),
    GoRoute(
      path: '/app-guide',
      pageBuilder:
          (context, state) =>
              _animatedPage(context, state, const AppGuideScreen()),
    ),
    GoRoute(
      path: '/merchant-names',
      pageBuilder:
          (context, state) =>
              _animatedPage(context, state, const MerchantNamesScreen()),
    ),
    GoRoute(
      path: '/developer-options',
      pageBuilder:
          (context, state) =>
              _animatedPage(context, state, const DeveloperOptionsScreen()),
    ),
    GoRoute(
      path: '/sms-rules-storage',
      pageBuilder:
          (context, state) =>
              _animatedPage(context, state, const SmsRulesStorageScreen()),
    ),
    GoRoute(
      path: '/master-debug-log',
      pageBuilder:
          (context, state) =>
              _animatedPage(context, state, const MasterDebugLogScreen()),
    ),
    GoRoute(
      path: '/sms-activity',
      pageBuilder:
          (context, state) =>
              _animatedPage(context, state, const DetectedSmsScreen()),
    ),
    GoRoute(
      path: '/detected-sms',
      pageBuilder:
          (context, state) =>
              _animatedPage(context, state, const DetectedSmsScreen()),
    ),
    GoRoute(
      path: '/sms-rules',
      pageBuilder:
          (context, state) =>
              _animatedPage(context, state, const SmsRuleManagerScreen()),
    ),
    GoRoute(
      path: '/block-sms',
      pageBuilder:
          (context, state) =>
              _animatedPage(context, state, const BlockSmsScreen()),
    ),
    GoRoute(
      path: '/sharing',
      pageBuilder:
          (context, state) =>
              _animatedPage(context, state, const PurposeSharingScreen()),
    ),
  ],
);
