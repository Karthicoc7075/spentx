import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../sync/sync_service.dart';

/// Fallback lists aligned with web `defaultCategories` (used offline / first run).
const _fallbackExpense = [
  'Food & Dining',
  'Groceries',
  'Transportation',
  'Rent / Housing',
  'Utilities',
  'Healthcare',
  'Entertainment',
  'Shopping',
  'Education',
  'Travel',
  'Bills & EMI',
  'Personal Care',
  'Gifts & Donations',
  'Miscellaneous',
  'Investment',
];

const _fallbackIncome = [
  'Salary',
  'Freelance / Business',
  'Investments',
  'Rental Income',
  'Bonus',
  'Gifts Received',
  'Interest',
  'Other Income',
  'Friend Returns',
];

class CategoryState {
  final List<String> expense;
  final List<String> income;

  /// Lowercase category name → saved hex (`#RRGGBB`) from Hive.
  /// Admin defaults and user categories both land here after sync.
  final Map<String, String> colors;

  const CategoryState({
    required this.expense,
    required this.income,
    this.colors = const <String, String>{},
  });

  CategoryState copyWith({
    List<String>? expense,
    List<String>? income,
    Map<String, String>? colors,
  }) {
    return CategoryState(
      expense: expense ?? this.expense,
      income: income ?? this.income,
      colors: colors ?? this.colors,
    );
  }

  /// Saved color for [name], or null when nothing is stored.
  String? colorHexFor(String name) {
    final key = name.trim().toLowerCase();
    if (key.isEmpty) return null;
    final hex = colors[key];
    if (hex == null || hex.trim().isEmpty) return null;
    return hex;
  }
}

class CategoryNotifier extends StateNotifier<CategoryState> {
  Box get _box => Hive.box('categories');

  CategoryNotifier()
      : super(const CategoryState(
          expense: _fallbackExpense,
          income: _fallbackIncome,
          colors: <String, String>{},
        )) {
    _loadFromStorage();
  }

  void reloadFromStorage() => _loadFromStorage();

  /// Old app-store defaults (pre-DB). Replace with web/DB-aligned list so
  /// quick-add stops showing stale Food/Shopping-only chips.
  static bool _looksLikeLegacyDefaults(List<String> expense, List<String> income) {
    const legacyExp = {
      'food',
      'shopping',
      'transport',
      'entertainment',
      'bills',
      'health',
      'trip',
      'hotel stay',
      'flight',
      'sightseeing',
      'other',
    };
    const legacyInc = {'salary', 'freelance', 'interest', 'investment', 'other'};
    if (expense.isEmpty) return true;
    final expKeys = expense.map((e) => e.toLowerCase()).toSet();
    final incKeys = income.map((e) => e.toLowerCase()).toSet();
    // Exactly the old fixed set (or subset of only those names).
    final expOnlyLegacy =
        expKeys.isNotEmpty && expKeys.every(legacyExp.contains);
    final incOnlyLegacy =
        incKeys.isEmpty || incKeys.every(legacyInc.contains);
    return expOnlyLegacy && incOnlyLegacy && expense.length <= 12;
  }

  void _loadFromStorage() {
    final List<dynamic>? savedExpense = _box.get('expense');
    final List<dynamic>? savedIncome = _box.get('income');

    var expense = savedExpense != null && savedExpense.isNotEmpty
        ? List<String>.from(savedExpense)
        : List<String>.from(_fallbackExpense);
    var income = savedIncome != null && savedIncome.isNotEmpty
        ? List<String>.from(savedIncome)
        : List<String>.from(_fallbackIncome);

    if (_looksLikeLegacyDefaults(expense, income)) {
      expense = List<String>.from(_fallbackExpense);
      income = List<String>.from(_fallbackIncome);
      _box.put('expense', expense);
      _box.put('income', income);
    }

    state = CategoryState(
      expense: expense,
      income: income,
      colors: _readColors(),
    );
  }

  Map<String, String> _readColors() {
    final raw = _box.get('colors');
    if (raw is! Map) return const {};
    final out = <String, String>{};
    raw.forEach((key, value) {
      final name = key.toString().trim().toLowerCase();
      final hex = value.toString().trim();
      if (name.isEmpty || hex.isEmpty) return;
      out[name] = hex;
    });
    return out;
  }

  void _saveToStorage() {
    _box.put('expense', state.expense);
    _box.put('income', state.income);
    _box.put('colors', state.colors);
  }

  /// Apply merged lists from Supabase (global defaults + user custom).
  void applyFromServer({
    required List<String> expense,
    required List<String> income,
  }) {
    final exp = expense.isNotEmpty ? expense : List<String>.from(_fallbackExpense);
    final inc = income.isNotEmpty ? income : List<String>.from(_fallbackIncome);
    // Keep any local-only custom names still pending push.
    final pendingExpense = _box.get('pending_custom_expense');
    final pendingIncome = _box.get('pending_custom_income');
    final extraE = pendingExpense is List
        ? pendingExpense.map((e) => e.toString()).where((n) => n.isNotEmpty)
        : <String>[];
    final extraI = pendingIncome is List
        ? pendingIncome.map((e) => e.toString()).where((n) => n.isNotEmpty)
        : <String>[];

    state = CategoryState(
      expense: _mergeUnique(exp, extraE),
      income: _mergeUnique(inc, extraI),
    );
    _saveToStorage();
  }

  List<String> _mergeUnique(List<String> base, Iterable<String> extra) {
    final seen = <String>{};
    final out = <String>[];
    for (final n in [...base, ...extra]) {
      final key = n.toLowerCase();
      if (seen.contains(key)) continue;
      seen.add(key);
      out.add(n);
    }
    return out;
  }

  void addExpenseCategory(String name) {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return;
    if (state.expense.any((c) => c.toLowerCase() == trimmed.toLowerCase())) {
      return;
    }
    state = state.copyWith(expense: [...state.expense, trimmed]);
    _saveToStorage();
    _trackPendingCustom('expense', trimmed);
    SyncService.queueCategoryUpsert(name: trimmed, type: 'expense');
  }

  void addIncomeCategory(String name) {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return;
    if (state.income.any((c) => c.toLowerCase() == trimmed.toLowerCase())) {
      return;
    }
    state = state.copyWith(income: [...state.income, trimmed]);
    _saveToStorage();
    _trackPendingCustom('income', trimmed);
    SyncService.queueCategoryUpsert(name: trimmed, type: 'income');
  }

  void _trackPendingCustom(String type, String name) {
    final key = type == 'income' ? 'pending_custom_income' : 'pending_custom_expense';
    final raw = _box.get(key);
    final list = raw is List ? raw.map((e) => e.toString()).toList() : <String>[];
    if (!list.any((n) => n.toLowerCase() == name.toLowerCase())) {
      list.add(name);
      _box.put(key, list);
    }
  }

  void clearPendingCustom(String type, String name) {
    final key = type == 'income' ? 'pending_custom_income' : 'pending_custom_expense';
    final raw = _box.get(key);
    if (raw is! List) return;
    _box.put(
      key,
      raw.map((e) => e.toString()).where((n) => n.toLowerCase() != name.toLowerCase()).toList(),
    );
  }
}

final categoryProvider = StateNotifierProvider<CategoryNotifier, CategoryState>(
  (_) => CategoryNotifier(),
);
