export '../../features/wealth/data/wealth_provider.dart';
