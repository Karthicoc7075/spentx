export '../../features/friends/data/friend_split_provider.dart';
