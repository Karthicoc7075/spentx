export '../../features/friends/data/contacts_provider.dart';
