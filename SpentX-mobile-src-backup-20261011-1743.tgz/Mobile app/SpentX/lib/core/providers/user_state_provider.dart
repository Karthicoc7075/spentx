import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../models/account_model.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../services/auth_service.dart';
import '../services/auto_detection_native_sync.dart';
import '../sync/sync_service.dart';

class UserState {
  final bool isFirstTimeUser;
  final List<AccountModel> accounts;
  final List<String> purposeTypes;
  final String profileName;
  final bool includeOutingExpenses;

  /// Soft caps matching web global_settings (mobile uses local defaults).
  static const maxAccounts = 8;
  static const maxPurposes = 10;

  UserState({
    required this.isFirstTimeUser,
    required this.accounts,
    required this.purposeTypes,
    this.profileName = 'User',
    this.includeOutingExpenses = true,
  });

  UserState copyWith({
    bool? isFirstTimeUser,
    List<AccountModel>? accounts,
    List<String>? purposeTypes,
    String? profileName,
    bool? includeOutingExpenses,
  }) {
    return UserState(
      isFirstTimeUser: isFirstTimeUser ?? this.isFirstTimeUser,
      accounts: accounts ?? this.accounts,
      purposeTypes: purposeTypes ?? this.purposeTypes,
      profileName: profileName ?? this.profileName,
      includeOutingExpenses: includeOutingExpenses ?? this.includeOutingExpenses,
    );
  }
}

class UserStateNotifier extends StateNotifier<UserState> {
  Box get _box => Hive.box('settings'); // assuming 'settings' box is generic enough

  /// Push the "banks the user actually added" list to native after any change
  /// to accounts, so the notification listener stops detecting SMS from banks
  /// that are not theirs. Fire-and-forget — a failed mirror only means native
  /// keeps the previous list until the next app start.
  void _refreshNativeBankAllowlist() {
    AutoDetectionNativeSync.syncAllowedBanksToNative();
  }

  UserStateNotifier()
      : super(UserState(
          isFirstTimeUser: true,
          accounts: [],
          purposeTypes: ['Personal', 'Family'],
        )) {
    _loadState();
  }

  void _loadState() {
    try {
      final isFirstTime = _box.get('isFirstTimeUser', defaultValue: true);
      
      final rawAccounts = _box.get('onboardingAccounts');
      List<AccountModel> loadedAccounts = [];
      if (rawAccounts != null) {
        loadedAccounts = (rawAccounts as List).map((e) => AccountModel.fromJson(Map<String, dynamic>.from(e))).toList();
      } else {
        // default if not found
        loadedAccounts = [AccountModel(name: 'Cash', type: 'Cash')];
      }

      final dedupedAccounts = deduplicate(loadedAccounts);
      if (dedupedAccounts.length != loadedAccounts.length) {
        loadedAccounts = dedupedAccounts;
        _box.put('onboardingAccounts', loadedAccounts.map((a) => a.toJson()).toList());
      } else {
        loadedAccounts = dedupedAccounts;
      }

      final rawPurposes = _box.get('purposeTypes');
      List<String> loadedPurposes = ['Personal', 'Family'];
      if (rawPurposes != null) {
        loadedPurposes = List<String>.from(rawPurposes);
      }

      // Prefer saved name → auth/user metadata → email local-part → User.
      var profile = _box.get('profile_name')?.toString().trim() ?? '';
      if (profile.isEmpty ||
          profile.toLowerCase() == 'karthi' ||
          profile.toLowerCase() == 'user') {
        final fromAuth = _resolveAuthDisplayName();
        if (fromAuth.isNotEmpty) {
          profile = fromAuth;
          _box.put('profile_name', profile);
        } else if (profile.isEmpty) {
          profile = 'User';
        }
      }

      // If accounts already exist (synced from server / prior setup), never
      // treat as first-time bank-count onboarding again.
      var firstTime = isFirstTime == true;
      if (firstTime && _accountsLookSetUp(loadedAccounts)) {
        firstTime = false;
        _box.put('isFirstTimeUser', false);
      }

      final includeOutings = _box.get('includeOutingExpenses', defaultValue: true) == true;

      state = UserState(
        isFirstTimeUser: firstTime,
        accounts: loadedAccounts,
        purposeTypes: loadedPurposes,
        profileName: profile,
        includeOutingExpenses: includeOutings,
      );
    } catch (_) {
      // Box errors fail gracefully to defaults
    }
  }

  void setIncludeOutingExpenses(bool value) {
    _box.put('includeOutingExpenses', value);
    state = state.copyWith(includeOutingExpenses: value);
  }

  /// Reload accounts/purposes from Hive after a background sync pull.
  /// Without this, net worth keeps stale opening balances until app restart.
  void reloadFromStorage() => _loadState();

  /// Merges only true duplicates: same id, or the same account name.
  /// Different banks that happen to share a last-4 stay. Blank ids never match,
  /// so a missing id cannot collapse every account into the first one.
  /// Preserves the richest metadata (non-empty last4, non-zero opening balance, default flag).
  static List<AccountModel> deduplicate(List<AccountModel> list) {
    if (list.length <= 1) return list;
    final result = <AccountModel>[];
    for (final acc in list) {
      final accName = acc.name.trim().toLowerCase();

      final existingIdx = result.indexWhere((existing) {
        final sameId = existing.id.isNotEmpty &&
            existing.id != 'null' &&
            acc.id.isNotEmpty &&
            acc.id != 'null' &&
            existing.id == acc.id;
        if (sameId) return true;
        final exName = existing.name.trim().toLowerCase();
        if (exName.isNotEmpty && exName == accName) return true;
        return false;
      });

      if (existingIdx >= 0) {
        final old = result[existingIdx];
        result[existingIdx] = old.copyWith(
          last4Digits: old.last4Digits.trim().isNotEmpty
              ? old.last4Digits
              : acc.last4Digits,
          openingBalance: old.openingBalance != 0
              ? old.openingBalance
              : acc.openingBalance,
          openingBalanceDate: (old.openingBalanceDate != null &&
                  old.openingBalanceDate!.isNotEmpty)
              ? old.openingBalanceDate
              : acc.openingBalanceDate,
          isDefault: old.isDefault || acc.isDefault,
          isActive: old.isActive || acc.isActive,
        );
      } else {
        result.add(acc);
      }
    }
    return result;
  }

  static bool _accountsLookSetUp(List<AccountModel> accounts) {
    if (accounts.isEmpty) return false;
    if (accounts.length > 1) return true;
    final only = accounts.first;
    final type = only.type.toLowerCase();
    if (type == 'bank' || type == 'wallet' || type == 'credit') return true;
    return only.name.trim().toLowerCase() != 'cash';
  }

  /// Completes onboarding NON-DESTRUCTIVELY.
  ///
  /// Defensive idempotency layer: if onboarding ever runs against an account
  /// that already has data (e.g. the sync pull populated accounts/purposes
  /// while the modal was open, or the server gate was unreachable), well-known
  /// defaults are MERGED by name instead of blindly inserted — the same
  /// "never create a duplicate of an existing well-known default" guarantee
  /// the server-side handle_new_user trigger has.
  void completeOnboarding({required List<AccountModel> newAccounts, required List<String> newPurposes}) {
    // Merge accounts by case-insensitive name: existing (possibly synced)
    // records win; only genuinely new names are added.
    final mergedAccounts = <AccountModel>[...state.accounts];
    final existingNames =
        mergedAccounts.map((a) => a.name.trim().toLowerCase()).toSet();
    final addedAccounts = <AccountModel>[];
    for (final a in newAccounts) {
      final key = a.name.trim().toLowerCase();
      if (key.isEmpty || existingNames.contains(key)) continue;
      mergedAccounts.add(a);
      addedAccounts.add(a);
      existingNames.add(key);
    }

    // Merge purposes the same way (prevents a second "Personal").
    final mergedPurposes = <String>[...state.purposeTypes];
    final existingPurposes =
        mergedPurposes.map((p) => p.trim().toLowerCase()).toSet();
    for (final p in newPurposes) {
      final key = p.trim().toLowerCase();
      if (key.isEmpty || existingPurposes.contains(key)) continue;
      mergedPurposes.add(p);
      existingPurposes.add(key);
    }

    // Fresh device with nothing loaded yet: _loadState's in-memory default is
    // empty/Cash-only, so the merge degrades to exactly the old behavior.
    final effectiveAccounts = deduplicate(
        mergedAccounts.isEmpty ? newAccounts : mergedAccounts);
    final effectivePurposes =
        mergedPurposes.isEmpty ? newPurposes : mergedPurposes;

    state = state.copyWith(
      isFirstTimeUser: false,
      accounts: effectiveAccounts,
      purposeTypes: effectivePurposes,
    );
    _box.put('isFirstTimeUser', false);
    _box.put('onboardingAccounts', effectiveAccounts.map((a) => a.toJson()).toList());
    _refreshNativeBankAllowlist();
    _box.put('purposeTypes', effectivePurposes);
    // Only newly-added accounts are pushed; their remote ids are
    // (user, name)-scoped, so even a double-push cannot duplicate rows.
    for (final a in (addedAccounts.isEmpty ? effectiveAccounts : addedAccounts)) {
      SyncService.queueAccountUpsert(a.toJson());
    }
    // The account now has data — later opens take the cached fast path.
    AuthService.markAccountHasData();
  }

  /// Mark account setup done without re-running the bank-count wizard
  /// (existing server accounts / sync already populated Hive).
  void markSetupComplete() {
    if (!state.isFirstTimeUser) return;
    state = state.copyWith(isFirstTimeUser: false);
    _box.put('isFirstTimeUser', false);
    AuthService.markAccountHasData();
  }

  /// True when this device already has more than the default Cash seed
  /// (or any bank account) — bank-count onboarding must not re-open.
  bool get hasExistingAccountSetup => _accountsLookSetUp(state.accounts);
  
  /// Best available display name from Supabase session (not hard-coded).
  static String _resolveAuthDisplayName() {
    final metaName = AuthService.currentUserDisplayName;
    if (metaName != null && metaName.trim().isNotEmpty) return metaName.trim();
    final email = AuthService.currentUserEmail;
    if (email != null && email.contains('@')) {
      final local = email.split('@').first.trim();
      if (local.isNotEmpty) {
        return local[0].toUpperCase() +
            (local.length > 1 ? local.substring(1) : '');
      }
    }
    return '';
  }

  /// Apply name from server `users.name` after pull (only if user never customized).
  void applyServerProfileName(String? name) {
    final remote = name?.trim() ?? '';
    if (remote.isEmpty) return;
    final local = state.profileName.trim();
    final userEdited = _box.get('profile_name_user_set') == true;
    if (userEdited && local.isNotEmpty) return;
    _box.put('profile_name', remote);
    state = state.copyWith(profileName: remote);
  }

  /// Adds an account.
  /// Returns `null` on success, or an error message when the name is taken,
  /// the bank last-4 is taken, or the account cap is reached.
  String? addAccount(AccountModel account) {
    final nameKey = account.name.trim().toLowerCase();
    if (nameKey.isEmpty) return 'Enter an account name.';
    if (state.accounts.any((a) => a.name.trim().toLowerCase() == nameKey)) {
      return 'Account "${account.name.trim()}" already exists.';
    }
    final last4 = account.last4Digits.trim();
    if (last4.length >= 3 && !account.isCash) {
      final duplicateLast4 = state.accounts.any(
        (a) =>
            a.type.trim().toLowerCase() == account.type.trim().toLowerCase() &&
            a.last4Digits.trim() == last4,
      );
      if (duplicateLast4) {
        return 'An account ending in $last4 already exists.';
      }
    }
    if (state.accounts.length >= UserState.maxAccounts) {
      return 'Account limit reached — maximum ${UserState.maxAccounts} accounts. Delete one to add another.';
    }
    final newAccounts = deduplicate([...state.accounts, account]);
    state = state.copyWith(accounts: newAccounts);
    _box.put('onboardingAccounts', newAccounts.map((a) => a.toJson()).toList());
    _refreshNativeBankAllowlist();
    SyncService.queueAccountUpsert(account.toJson());
    return null;
  }

  /// Returns false when purpose limit is reached.
  bool addPurpose(String name) {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return true;
    if (state.purposeTypes.any((p) => p.toLowerCase() == trimmed.toLowerCase())) {
      return true;
    }
    if (state.purposeTypes.length >= UserState.maxPurposes) return false;
    final next = [...state.purposeTypes, trimmed];
    updatePurposes(next);
    return true;
  }

  /// Removes an account by ID or name.
  /// IMPORTANT: Strictly removes at most ONE account, preventing accidental
  /// batch-deletion when accounts share a name or duplicates exist.
  void removeAccount(String accountIdOrName, {String? accountId}) {
    if (state.accounts.length <= 1) return; // keep at least one

    final targetId = accountId ??
        (state.accounts.any((a) => a.id == accountIdOrName) ? accountIdOrName : null);

    int index = -1;
    if (targetId != null && targetId.isNotEmpty) {
      index = state.accounts.indexWhere((a) => a.id == targetId);
    }
    if (index == -1) {
      final nameKey = accountIdOrName.trim().toLowerCase();
      index = state.accounts.indexWhere((a) => a.name.trim().toLowerCase() == nameKey);
    }
    if (index == -1) return;

    final targetAccount = state.accounts[index];
    final newAccounts = List<AccountModel>.from(state.accounts)..removeAt(index);
    state = state.copyWith(accounts: newAccounts);
    _box.put('onboardingAccounts', newAccounts.map((a) => a.toJson()).toList());
    _refreshNativeBankAllowlist();

    final stillHasSameName = newAccounts.any(
      (a) => a.name.trim().toLowerCase() == targetAccount.name.trim().toLowerCase(),
    );

    SyncService.queueAccountDelete(
      targetAccount.name,
      accountId: targetAccount.id,
      onlyIfNoOthers: stillHasSameName,
    );
  }

  /// Updates an account. Returns `null` on success, or an error when renaming
  /// to a name that already belongs to another account.
  String? updateAccount(AccountModel updated) {
    final nameKey = updated.name.trim().toLowerCase();
    if (nameKey.isEmpty) return 'Enter an account name.';
    final taken = state.accounts.any(
      (a) => a.id != updated.id && a.name.trim().toLowerCase() == nameKey,
    );
    if (taken) {
      return 'Account "${updated.name.trim()}" already exists.';
    }
    final last4 = updated.last4Digits.trim();
    if (last4.length >= 3 && !updated.isCash) {
      final takenLast4 = state.accounts.any(
        (a) =>
            a.id != updated.id &&
            a.type.trim().toLowerCase() == updated.type.trim().toLowerCase() &&
            a.last4Digits.trim() == last4,
      );
      if (takenLast4) {
        return 'An account ending in $last4 already exists.';
      }
    }
    final newAccounts = deduplicate(
        state.accounts.map((a) => a.id == updated.id ? updated : a).toList());
    state = state.copyWith(accounts: newAccounts);
    _box.put('onboardingAccounts', newAccounts.map((a) => a.toJson()).toList());
    _refreshNativeBankAllowlist();
    SyncService.queueAccountUpsert(updated.toJson());
    return null;
  }

  /// Mirrors web Settings → "Default payment account": exactly one account
  /// carries isDefault at a time. Same accounts.is_default column both
  /// platforms sync through, so setting it here also applies on web.
  void setDefaultAccount(String accountId) {
    final newAccounts = state.accounts
        .map((a) => a.copyWith(isDefault: a.id == accountId))
        .toList();
    state = state.copyWith(accounts: newAccounts);
    _box.put('onboardingAccounts', newAccounts.map((a) => a.toJson()).toList());
    _refreshNativeBankAllowlist();
    for (final a in newAccounts) {
      SyncService.queueAccountUpsert(a.toJson());
    }
  }

  void updatePurposes(List<String> purposes) {
    final previous = state.purposeTypes;
    final next = [
      for (final p in purposes)
        if (p.trim().isNotEmpty) p.trim(),
    ];
    state = state.copyWith(purposeTypes: next);
    _box.put('purposeTypes', next);
    final prevKeys = previous.map((p) => p.toLowerCase()).toSet();
    final nextKeys = next.map((p) => p.toLowerCase()).toSet();
    for (final name in next) {
      if (!prevKeys.contains(name.toLowerCase())) {
        SyncService.queuePurposeUpsert(name);
      }
    }
    for (final name in previous) {
      if (!nextKeys.contains(name.toLowerCase())) {
        SyncService.queuePurposeDelete(name);
      }
    }
  }

  void updateProfileName(String name) {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return;
    _box.put('profile_name', trimmed);
    _box.put('profile_name_user_set', true);
    state = state.copyWith(profileName: trimmed);
  }
}

final userStateProvider = StateNotifierProvider<UserStateNotifier, UserState>(
  (ref) => UserStateNotifier(),
);
