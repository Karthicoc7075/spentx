export '../../features/investments/data/investment_provider.dart';
