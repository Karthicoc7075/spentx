export '../../features/settings/data/animation_provider.dart';
