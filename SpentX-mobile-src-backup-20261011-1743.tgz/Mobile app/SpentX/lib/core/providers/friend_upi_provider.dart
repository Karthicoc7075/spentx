export '../../features/friends/data/friend_upi_provider.dart';
