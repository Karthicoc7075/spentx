class MerchantRule {
  final String id;
  final String identifier;
  final String normalizedIdentifierKey;
  final String displayName;
  final String defaultPurposeType;
  final String defaultCategory;
  /// credit | debit | transfer — same merchant can differ by type
  final String transactionType;
  final DateTime lastUsedAt;

  MerchantRule({
    required this.id,
    required this.identifier,
    required this.normalizedIdentifierKey,
    required this.displayName,
    required this.defaultPurposeType,
    required this.defaultCategory,
    this.transactionType = '',
    required this.lastUsedAt,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'identifier': identifier,
    'normalizedIdentifierKey': normalizedIdentifierKey,
    'displayName': displayName,
    'defaultPurposeType': defaultPurposeType,
    'defaultCategory': defaultCategory,
    'transactionType': transactionType,
    'lastUsedAt': lastUsedAt.toIso8601String(),
  };

  factory MerchantRule.fromMap(Map<dynamic, dynamic> map) {
    final identifierVal = map['identifier'] ?? map['normalizedMerchantKey'] ?? '';
    final normalizedVal = map['normalizedIdentifierKey'] ?? map['normalizedMerchantKey'] ?? map['identifier'] ?? '';
    final displayNameVal = map['displayName'] ?? map['merchantName'] ?? map['name'] ?? '';
    return MerchantRule(
      id: map['id'] ?? '',
      identifier: identifierVal,
      normalizedIdentifierKey: normalizedVal,
      displayName: displayNameVal,
      defaultPurposeType: map['defaultPurposeType'] ?? map['accountType'] ?? '',
      defaultCategory: map['defaultCategory'] ?? map['category'] ?? '',
      transactionType: map['transactionType']?.toString() ?? '',
      lastUsedAt: map['lastUsedAt'] != null ? DateTime.parse(map['lastUsedAt']) : DateTime.now(),
    );
  }

  // Legacy field getters for backward compatibility
  String get merchantName => displayName;
  String get normalizedMerchantKey => normalizedIdentifierKey;
  String get linkedBankId => '';
  String get bankName => '';

  MerchantRule copyWith({
    String? identifier,
    String? normalizedIdentifierKey,
    String? displayName,
    String? defaultPurposeType,
    String? defaultCategory,
    String? transactionType,
    DateTime? lastUsedAt,
  }) {
    return MerchantRule(
      id: id,
      identifier: identifier ?? this.identifier,
      normalizedIdentifierKey: normalizedIdentifierKey ?? this.normalizedIdentifierKey,
      displayName: displayName ?? this.displayName,
      defaultPurposeType: defaultPurposeType ?? this.defaultPurposeType,
      defaultCategory: defaultCategory ?? this.defaultCategory,
      transactionType: transactionType ?? this.transactionType,
      lastUsedAt: lastUsedAt ?? this.lastUsedAt,
    );
  }
}
