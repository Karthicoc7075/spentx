/// Supabase project configuration — SHARED project with the SpentX web app.
///
/// ⚠️ PLACEHOLDERS: paste the same URL + anon (public) key the web app uses
/// before building. The anon key is safe to ship in the client; never put the
/// service-role key here.
class SupabaseConfig {
  SupabaseConfig._();

  /// e.g. https://abcdefghijklm.supabase.co
  static const String url = 'https://vdhayvlweuglpvzweunq.supabase.co';

  /// The project's anon/public API key.
  static const String anonKey =
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZkaGF5dmx3ZXVnbHB2endldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODQwNTcyNTEsImV4cCI6MjA5OTYzMzI1MX0.kOefwz6KJSeUfjt233iyIJxMBdk9Jb6fuMRrMELdnLk';

  /// Deep link Supabase's password-reset email redirects to.
  /// Must match the AndroidManifest intent filter AND be listed in
  /// Supabase Dashboard → Authentication → URL Configuration → Redirect URLs.
  static const String resetPasswordRedirect = 'spentx://reset-password';

  /// Deep link Supabase's "Confirm your email" signup link redirects to.
  /// Must match the AndroidManifest intent filter AND be listed in
  /// Supabase Dashboard → Authentication → URL Configuration → Redirect URLs
  /// — same requirement as [resetPasswordRedirect].
  static const String emailConfirmRedirect = 'spentx://auth/callback';

  /// Minimum password length — keep in sync with the Supabase project's
  /// password policy (Dashboard → Authentication → Providers → Email).
  static const int minPasswordLength = 6;

  static bool get isConfigured =>
      !url.contains('YOUR_SUPABASE') && !anonKey.contains('YOUR_SUPABASE');
}
