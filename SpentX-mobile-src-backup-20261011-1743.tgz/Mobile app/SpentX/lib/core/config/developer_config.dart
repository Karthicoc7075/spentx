import 'package:flutter/material.dart';

/// Developer-only configuration flags for internal testing.
/// MUST be set to `false` in production builds.
const bool kDeveloperTerminalUI = false;

/// Color palette for the developer-only Terminal UI.
class TerminalColors {
  static const Color bg = Color(0xFF090D0A);
  static const Color green = Color(0xFF4ADE80);
  static const Color darkGreen = Color(0xFF15803D);
  static const Color muted = Color(0xFF166534);
  static const Color textMuted = Color(0xFF86EFAC);
  static const Color border = Color(0xFF22C55E);
}
