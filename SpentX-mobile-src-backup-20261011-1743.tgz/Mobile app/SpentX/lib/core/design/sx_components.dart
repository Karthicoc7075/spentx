import 'package:flutter/material.dart';

import '../theme/spentx_tokens.dart';
import 'sx_primitives.dart';

/// Indian-grouped rupee formatting (1,23,456) without decimals.
String sxGroupRupees(double value) {
  final whole = value.abs().truncate().toString();
  if (whole.length <= 3) return whole;
  final lastThree = whole.substring(whole.length - 3);
  final rest = whole.substring(0, whole.length - 3);
  final grouped =
      rest.replaceAllMapped(RegExp(r'\B(?=(\d{2})+(?!\d))'), (_) => ',');
  return '$grouped,$lastThree';
}

/// A financial figure. The currency symbol sits at reduced opacity so the
/// digits — the thing the user actually came to read — carry the weight, and
/// the value scales down rather than truncating.
class SxMoney extends StatelessWidget {
  const SxMoney({
    super.key,
    required this.amount,
    required this.size,
    this.color,
    this.signed = false,
    this.weight = FontWeight.w700,
  });

  final double amount;
  final double size;
  final Color? color;

  /// Retained for call-site compatibility; it no longer adds a leading "+".
  /// A negative amount always shows its "−" regardless of this flag.
  final bool signed;
  final FontWeight weight;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final c = color ?? t.textPrimary;
    // Never a leading "+". Colour already says money came in, and prefixing
    // every expense with "−" makes the amount itself look negative. The only
    // sign shown is a "−" on a value that is genuinely below zero.
    final sign = amount < 0 ? '−' : '';

    return FittedBox(
      fit: BoxFit.scaleDown,
      alignment: Alignment.centerRight,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.baseline,
        textBaseline: TextBaseline.alphabetic,
        children: [
          if (sign.isNotEmpty)
            Text(sign, style: AppType.money(c, size: size, weight: weight)),
          Text(
            '₹',
            style: AppType.money(
              c.withValues(alpha: 0.55),
              size: size * 0.78,
              weight: weight,
            ),
          ),
          Text(
            sxGroupRupees(amount),
            style: AppType.money(c, size: size, weight: weight),
          ),
        ],
      ),
    );
  }
}

/// Hero balance card: the largest figure on the screen, a delta badge, and
/// two or three compact actions.
class SxBalanceCard extends StatelessWidget {
  const SxBalanceCard({
    super.key,
    required this.label,
    required this.amount,
    this.deltaLabel,
    this.deltaIsPositive = true,
    this.actions = const [],
    this.onTap,
  });

  final String label;
  final double amount;
  final String? deltaLabel;
  final bool deltaIsPositive;
  final List<Widget> actions;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    return SxCard(
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  label.toUpperCase(),
                  style: AppType.caption(t.textSecondary)
                      .copyWith(letterSpacing: 1.2, fontWeight: FontWeight.w600),
                ),
              ),
              if (deltaLabel != null)
                SxBadge(
                  label: deltaLabel!,
                  tone: deltaIsPositive ? SxTone.positive : SxTone.negative,
                  icon: deltaIsPositive
                      ? Icons.trending_up_rounded
                      : Icons.trending_down_rounded,
                ),
            ],
          ),
          const SizedBox(height: AppSpacing.sm),
          Align(
            alignment: Alignment.centerLeft,
            child: SxMoney(amount: amount, size: 34, color: t.textPrimary),
          ),
          if (actions.isNotEmpty) ...[
            const SizedBox(height: AppSpacing.lg),
            Row(
              children: [
                for (var i = 0; i < actions.length; i++) ...[
                  if (i > 0) const SizedBox(width: AppSpacing.sm),
                  Expanded(child: actions[i]),
                ],
              ],
            ),
          ],
        ],
      ),
    );
  }
}

/// Compact label+value tile for 2- or 3-up grids.
class SxStatTile extends StatelessWidget {
  const SxStatTile({
    super.key,
    required this.label,
    required this.amount,
    this.tone = SxTone.neutral,
    this.icon,
    this.onTap,
  });

  final String label;
  final double amount;
  final SxTone tone;
  final IconData? icon;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final valueColor = switch (tone) {
      SxTone.positive => t.positive,
      SxTone.negative => t.negative,
      SxTone.neutral => t.textPrimary,
    };

    return SxCard(
      onTap: onTap,
      padding: const EdgeInsets.all(AppSpacing.md),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              if (icon != null) ...[
                Icon(icon, size: 14, color: t.textSecondary),
                const SizedBox(width: AppSpacing.xxs + 2),
              ],
              Flexible(
                child: Text(
                  label,
                  style: AppType.caption(t.textSecondary),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.xs),
          Align(
            alignment: Alignment.centerLeft,
            child: SxMoney(amount: amount, size: 19, color: valueColor),
          ),
        ],
      ),
    );
  }
}

/// A single transaction line: category tint circle, title + timestamp, and a
/// right-aligned signed amount.
class SxTransactionRow extends StatelessWidget {
  const SxTransactionRow({
    super.key,
    required this.title,
    required this.subtitle,
    required this.amount,
    required this.icon,
    this.iconBackground,
    this.iconColor,
    this.isNegative = true,
    this.neutralAmount = false,
    this.badge,
    this.onTap,
  });

  final String title;
  final String subtitle;
  final double amount;
  final IconData icon;
  final Color? iconBackground;
  final Color? iconColor;
  final bool isNegative;

  /// Transfers move money without being income or expense, so they render
  /// unsigned and in the neutral text colour rather than green/red.
  final bool neutralAmount;
  final Widget? badge;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final amountColor =
        neutralAmount ? t.textPrimary : t.amount(isNegative: isNegative);

    return SxCard(
      onTap: onTap,
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.md,
        vertical: AppSpacing.sm + 2,
      ),
      child: Row(
        children: [
          SxIconCircle(
            icon: icon,
            background: iconBackground,
            foreground: iconColor,
          ),
          const SizedBox(width: AppSpacing.sm),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        title,
                        style: AppType.body(t.textPrimary)
                            .copyWith(fontWeight: FontWeight.w600),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (badge != null) ...[
                      const SizedBox(width: AppSpacing.xs),
                      badge!,
                    ],
                  ],
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: AppType.caption(t.textSecondary),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          const SizedBox(width: AppSpacing.sm),
          SxMoney(
            amount: amount,
            size: 16,
            color: amountColor,
            signed: !neutralAmount,
          ),
        ],
      ),
    );
  }
}

/// Category row with a progress fill — used in analytics breakdowns.
class SxCategoryTile extends StatelessWidget {
  const SxCategoryTile({
    super.key,
    required this.label,
    required this.amount,
    required this.icon,
    this.progress,
    this.caption,
    this.iconBackground,
    this.iconColor,
    this.onTap,
  });

  final String label;
  final double amount;
  final IconData icon;

  /// 0..1 share of the total. Fills use the accent — one of its sanctioned uses.
  final double? progress;
  final String? caption;
  final Color? iconBackground;
  final Color? iconColor;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    return SxCard(
      onTap: onTap,
      padding: const EdgeInsets.all(AppSpacing.md),
      child: Column(
        children: [
          Row(
            children: [
              SxIconCircle(
                icon: icon,
                size: 38,
                background: iconBackground,
                foreground: iconColor,
              ),
              const SizedBox(width: AppSpacing.sm),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      label,
                      style: AppType.body(t.textPrimary)
                          .copyWith(fontWeight: FontWeight.w600),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    if (caption != null)
                      Text(caption!, style: AppType.caption(t.textSecondary)),
                  ],
                ),
              ),
              const SizedBox(width: AppSpacing.xs),
              SxMoney(amount: amount, size: 16, color: t.textPrimary),
            ],
          ),
          if (progress != null) ...[
            const SizedBox(height: AppSpacing.sm),
            ClipRRect(
              borderRadius: AppRadius.pillR,
              child: LinearProgressIndicator(
                value: progress!.clamp(0.0, 1.0),
                minHeight: 6,
                backgroundColor: t.field,
                valueColor: AlwaysStoppedAnimation(t.primary),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

/// Flat solid-accent highlight card. Max one per screen — it is the loudest
/// element in the system and stops working the moment there are two.
class SxAccentCard extends StatelessWidget {
  const SxAccentCard({
    super.key,
    required this.title,
    this.description,
    this.onTap,
  });

  final String title;
  final String? description;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    return SxCard(
      onTap: onTap,
      color: t.primary,
      borderColor: t.primary,
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  title,
                  style: AppType.section(t.onPrimary),
                ),
                if (description != null) ...[
                  const SizedBox(height: AppSpacing.xxs),
                  Text(
                    description!,
                    style: AppType.label(t.onPrimary.withValues(alpha: 0.75)),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(width: AppSpacing.sm),
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: t.onPrimary.withValues(alpha: 0.14),
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.arrow_forward_rounded, size: 19, color: t.onPrimary),
          ),
        ],
      ),
    );
  }
}

/// Period switcher (Day / Week / Month / Year).
class SxSegmentedControl extends StatelessWidget {
  const SxSegmentedControl({
    super.key,
    required this.segments,
    required this.selectedIndex,
    required this.onChanged,
  });

  final List<String> segments;
  final int selectedIndex;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    return Container(
      padding: const EdgeInsets.all(AppSpacing.xxs),
      decoration: BoxDecoration(
        color: t.field,
        borderRadius: AppRadius.tileR,
      ),
      child: Row(
        children: [
          for (var i = 0; i < segments.length; i++)
            Expanded(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => onChanged(i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  curve: Curves.easeOut,
                  height: 40,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: i == selectedIndex ? t.card : Colors.transparent,
                    borderRadius: AppRadius.iconButtonR,
                    border: i == selectedIndex
                        ? Border.all(color: t.border, width: 1)
                        : null,
                  ),
                  child: Text(
                    segments[i],
                    style: AppType.label(
                      i == selectedIndex ? t.textPrimary : t.textSecondary,
                    ).copyWith(
                      fontWeight:
                          i == selectedIndex ? FontWeight.w600 : FontWeight.w500,
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
