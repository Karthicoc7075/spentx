import 'package:flutter/material.dart';
import '../widgets/soft_buttons.dart';

import '../theme/spentx_tokens.dart';

/// Primitives for the "Premium Minimal Fintech — Modular Card UI" system.
///
/// Every widget here reads colour from `context.tokens`. None of them branch
/// on brightness: the token layer already resolved that, which is what keeps
/// light and dark structurally identical instead of drifting into two UIs.

/// The primary structural unit: a large rounded card with a hairline border.
///
/// Structure comes from the border, not from shadows — dark mode gets none at
/// all, and light mode gets at most one soft ambient shadow.
class SxCard extends StatelessWidget {
  const SxCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(AppSpacing.cardPad),
    this.color,
    this.onTap,
    this.borderColor,
    this.elevated = false,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color? color;
  final Color? borderColor;
  final VoidCallback? onTap;

  /// Opt-in ambient shadow. Ignored in dark mode by design.
  final bool elevated;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final showShadow = !context.isDarkMode;

    final content = Container(
      padding: padding,
      decoration: BoxDecoration(
        color: color ?? t.card,
        borderRadius: AppRadius.cardR,
        border: Border.all(color: borderColor ?? t.border, width: 1),
        boxShadow: showShadow
            ? (elevated ? AppShadows.bento : AppShadows.subtle)
            : null,
      ),
      child: child,
    );

    if (onTap == null) return content;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: AppRadius.cardR,
        splashColor: t.pressed,
        highlightColor: t.pressed,
        child: content,
      ),
    );
  }
}

/// Section title with an optional trailing text action ("See all").
class SxSectionHeader extends StatelessWidget {
  const SxSectionHeader({
    super.key,
    required this.title,
    this.actionLabel,
    this.onAction,
  });

  final String title;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    return Row(
      children: [
        Expanded(child: Text(title, style: AppType.section(t.textPrimary))),
        if (actionLabel != null && onAction != null)
          // 44px min tap target, kept flush to the right edge optically.
          TextButton(
            onPressed: onAction,
            style: TextButton.styleFrom(
              minimumSize: const Size(44, 44),
              padding: const EdgeInsets.symmetric(horizontal: AppSpacing.xs),
              foregroundColor: t.primary,
              textStyle: AppType.label(t.primary),
            ),
            child: Text(actionLabel!),
          ),
      ],
    );
  }
}

/// Compact square icon button. Bordered so it reads as an affordance on a
/// plain surface without needing a fill.
class SxIconButton extends StatelessWidget {
  const SxIconButton({
    super.key,
    required this.icon,
    required this.onPressed,
    this.tooltip,
    this.selected = false,
  });

  final IconData icon;
  final VoidCallback? onPressed;
  final String? tooltip;
  final bool selected;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final enabled = onPressed != null;
    final fg = !enabled
        ? t.disabled
        : selected
            ? t.primary
            : t.textSecondary;

    final button = Material(
      color: selected ? t.primarySoft : Colors.transparent,
      borderRadius: AppRadius.iconButtonR,
      child: InkWell(
        onTap: onPressed,
        borderRadius: AppRadius.iconButtonR,
        splashColor: t.pressed,
        highlightColor: t.pressed,
        child: Container(
          // 44x44 minimum tap target.
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            borderRadius: AppRadius.iconButtonR,
            border: Border.all(
              color: selected ? t.primary.withValues(alpha: 0.35) : t.border,
              width: 1,
            ),
          ),
          child: Icon(icon, size: 19, color: fg),
        ),
      ),
    );

    return tooltip == null ? button : Tooltip(message: tooltip!, child: button);
  }
}

/// Soft-tint pill. No border — the tint alone carries the meaning, so badges
/// stay quiet next to the financial figures they annotate.
class SxBadge extends StatelessWidget {
  const SxBadge({
    super.key,
    required this.label,
    this.tone = SxTone.neutral,
    this.icon,
  });

  final String label;
  final SxTone tone;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final (bg, fg) = switch (tone) {
      SxTone.positive => (t.primarySoft, t.positive),
      SxTone.negative => (t.negativeSoft, t.negative),
      SxTone.neutral => (t.field, t.textSecondary),
    };

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.sm,
        vertical: AppSpacing.xxs + 2,
      ),
      decoration: BoxDecoration(color: bg, borderRadius: AppRadius.pillR),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 12, color: fg),
            const SizedBox(width: AppSpacing.xxs + 2),
          ],
          Text(label, style: AppType.caption(fg).copyWith(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

enum SxTone { positive, negative, neutral }

/// Circular icon tint used as the leading element of rows and tiles.
class SxIconCircle extends StatelessWidget {
  const SxIconCircle({
    super.key,
    required this.icon,
    this.size = 44,
    this.background,
    this.foreground,
  });

  final IconData icon;
  final double size;
  final Color? background;
  final Color? foreground;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: background ?? t.primarySoft,
        shape: BoxShape.circle,
      ),
      child: Icon(icon, size: size * 0.42, color: foreground ?? t.primary),
    );
  }
}

/// Primary call-to-action. Solid [primary] with dark ink — the only
/// full-bleed green surface allowed outside a single accent card per screen.
class SxPrimaryButton extends StatelessWidget {
  const SxPrimaryButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.expand = true,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool expand;

  @override
  Widget build(BuildContext context) {
    // App colour rule: shared primary gradient, white text.
    return SoftGradientButton(
      label: label,
      icon: icon,
      onPressed: onPressed,
      height: 54,
      expand: expand,
      borderRadius: AppRadius.tileR,
    );
  }
}
