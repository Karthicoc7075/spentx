import 'package:flutter/material.dart';

import '../theme/spentx_tokens.dart';
import 'sx_primitives.dart';

/// Empty, loading, and transient-feedback states.
///
/// Deliberately illustration-free: an icon, one short line, and the action
/// that resolves the state. Anything more turns a dead end into decoration.

class SxEmptyState extends StatelessWidget {
  const SxEmptyState({
    super.key,
    required this.icon,
    required this.message,
    this.actionLabel,
    this.onAction,
  });

  final IconData icon;
  final String message;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.screenH,
        vertical: AppSpacing.xxl,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SxIconCircle(icon: icon, size: 56),
          const SizedBox(height: AppSpacing.md),
          Text(
            message,
            textAlign: TextAlign.center,
            style: AppType.body(t.textSecondary),
          ),
          if (actionLabel != null && onAction != null) ...[
            const SizedBox(height: AppSpacing.lg),
            SxPrimaryButton(
              label: actionLabel!,
              onPressed: onAction,
              expand: false,
            ),
          ],
        ],
      ),
    );
  }
}

/// Shimmering placeholder block. Compose these into the same shape as the
/// real content so the layout doesn't jump when data lands.
class SxSkeleton extends StatefulWidget {
  const SxSkeleton({
    super.key,
    this.width,
    this.height = 14,
    this.radius = AppRadius.tile,
  });

  final double? width;
  final double height;
  final double radius;

  @override
  State<SxSkeleton> createState() => _SxSkeletonState();
}

class _SxSkeletonState extends State<SxSkeleton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1200),
  )..repeat(reverse: true);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) => Container(
        width: widget.width,
        height: widget.height,
        decoration: BoxDecoration(
          color: Color.lerp(t.field, t.border, _c.value),
          borderRadius: BorderRadius.circular(widget.radius),
        ),
      ),
    );
  }
}

/// Skeleton shaped like [SxTransactionRow] — circle, two text lines, amount.
class SxTransactionRowSkeleton extends StatelessWidget {
  const SxTransactionRowSkeleton({super.key});

  @override
  Widget build(BuildContext context) {
    return SxCard(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.md,
        vertical: AppSpacing.sm + 2,
      ),
      child: Row(
        children: [
          const SxSkeleton(width: 44, height: 44, radius: AppRadius.pill),
          const SizedBox(width: AppSpacing.sm),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                SxSkeleton(width: 130, height: 13),
                SizedBox(height: AppSpacing.xs),
                SxSkeleton(width: 90, height: 11),
              ],
            ),
          ),
          const SizedBox(width: AppSpacing.sm),
          const SxSkeleton(width: 64, height: 16),
        ],
      ),
    );
  }
}

/// Toast / snackbar in the design system's language.
void sxShowToast(
  BuildContext context,
  String message, {
  SxTone tone = SxTone.neutral,
  IconData? icon,
}) {
  final t = context.tokens;
  final accent = switch (tone) {
    SxTone.positive => t.positive,
    SxTone.negative => t.negative,
    SxTone.neutral => t.textSecondary,
  };

  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(
      SnackBar(
        content: Row(
          children: [
            if (icon != null) ...[
              Icon(icon, size: 18, color: accent),
              const SizedBox(width: AppSpacing.sm),
            ],
            Expanded(
              child: Text(message, style: AppType.label(t.textPrimary)),
            ),
          ],
        ),
        backgroundColor: t.card,
        behavior: SnackBarBehavior.floating,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: AppRadius.tileR,
          side: BorderSide(color: t.border, width: 1),
        ),
        margin: const EdgeInsets.all(AppSpacing.md),
        duration: const Duration(seconds: 3),
      ),
    );
}

/// Bottom sheet with the system's surface, radius, and grabber.
Future<T?> sxShowSheet<T>({
  required BuildContext context,
  required Widget child,
  bool isScrollControlled = true,
}) {
  final t = context.tokens;
  return showModalBottomSheet<T>(
    context: context,
    isScrollControlled: isScrollControlled,
    backgroundColor: t.surface,
    barrierColor: t.scrim,
    elevation: 0,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(AppRadius.card)),
    ),
    builder: (ctx) => Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.viewInsetsOf(ctx).bottom),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: AppSpacing.sm),
              child: Container(
                width: 36,
                height: 4,
                decoration: BoxDecoration(
                  color: ctx.tokens.border,
                  borderRadius: AppRadius.pillR,
                ),
              ),
            ),
            Flexible(child: child),
          ],
        ),
      ),
    ),
  );
}

/// Confirmation dialog. [destructive] swaps the CTA to the negative tone.
Future<bool> sxConfirm({
  required BuildContext context,
  required String title,
  required String message,
  String confirmLabel = 'Confirm',
  String cancelLabel = 'Cancel',
  bool destructive = false,
}) async {
  final t = context.tokens;
  final result = await showDialog<bool>(
    context: context,
    barrierColor: t.scrim,
    builder: (ctx) => Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.all(AppSpacing.xl),
      child: SxCard(
        color: ctx.tokens.surface,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: AppType.section(ctx.tokens.textPrimary)),
            const SizedBox(height: AppSpacing.xs),
            Text(message, style: AppType.body(ctx.tokens.textSecondary)),
            const SizedBox(height: AppSpacing.lg),
            Row(
              children: [
                Expanded(
                  child: TextButton(
                    onPressed: () => Navigator.pop(ctx, false),
                    style: TextButton.styleFrom(
                      minimumSize: const Size(0, 48),
                      foregroundColor: ctx.tokens.textSecondary,
                    ),
                    child: Text(cancelLabel, style: AppType.label(ctx.tokens.textSecondary)),
                  ),
                ),
                const SizedBox(width: AppSpacing.sm),
                Expanded(
                  child: SizedBox(
                    height: 48,
                    child: Material(
                      color: destructive
                          ? ctx.tokens.negative
                          : ctx.tokens.primary,
                      borderRadius: AppRadius.tileR,
                      child: InkWell(
                        onTap: () => Navigator.pop(ctx, true),
                        borderRadius: AppRadius.tileR,
                        child: Center(
                          child: Text(
                            confirmLabel,
                            style: AppType.label(
                              destructive ? Colors.white : ctx.tokens.onPrimary,
                            ).copyWith(fontWeight: FontWeight.w600),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    ),
  );
  return result ?? false;
}
