import 'package:flutter/material.dart';
import '../widgets/soft_buttons.dart';

import '../theme/spentx_tokens.dart';

/// Inputs, secondary actions, and bottom navigation.

/// Quiet counterpart to [SxPrimaryButton]: bordered, no fill, so two actions
/// side by side never read as equally weighted.
class SxSecondaryButton extends StatelessWidget {
  const SxSecondaryButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.expand = true,
    this.destructive = false,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool expand;
  final bool destructive;

  @override
  Widget build(BuildContext context) {
    // App colour rule: white / #18181B, ink text, light outline.
    return SoftOutlineButton(
      label: label,
      icon: icon,
      onPressed: onPressed,
      height: 54,
      expand: expand,
      destructive: destructive,
      borderRadius: AppRadius.tileR,
    );
  }
}

/// Text input on the recessed [field] token. Borderless at rest so forms read
/// as a stack of quiet rows; the accent only appears on focus.
class SxTextField extends StatelessWidget {
  const SxTextField({
    super.key,
    this.controller,
    this.hint,
    this.label,
    this.keyboardType,
    this.validator,
    this.onChanged,
    this.maxLines = 1,
    this.prefixIcon,
    this.suffix,
    this.autofocus = false,
    this.obscureText = false,
    this.enabled = true,
  });

  final TextEditingController? controller;
  final String? hint;
  final String? label;
  final TextInputType? keyboardType;
  final String? Function(String?)? validator;
  final ValueChanged<String>? onChanged;
  final int maxLines;
  final IconData? prefixIcon;
  final Widget? suffix;
  final bool autofocus;
  final bool obscureText;
  final bool enabled;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        if (label != null) ...[
          Text(
            label!.toUpperCase(),
            style: AppType.caption(t.textSecondary)
                .copyWith(letterSpacing: 1.1, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: AppSpacing.xs),
        ],
        TextFormField(
          controller: controller,
          keyboardType: keyboardType,
          validator: validator,
          onChanged: onChanged,
          maxLines: maxLines,
          autofocus: autofocus,
          obscureText: obscureText,
          enabled: enabled,
          style: AppType.body(t.textPrimary),
          cursorColor: t.primary,
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: AppType.body(t.textSecondary.withValues(alpha: 0.7)),
            filled: true,
            fillColor: enabled ? t.field : t.field.withValues(alpha: 0.5),
            prefixIcon: prefixIcon == null
                ? null
                : Icon(prefixIcon, size: 18, color: t.textSecondary),
            suffixIcon: suffix,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: AppSpacing.md,
              vertical: AppSpacing.sm + 2,
            ),
            border: OutlineInputBorder(
              borderRadius: AppRadius.tileR,
              borderSide: BorderSide.none,
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: AppRadius.tileR,
              borderSide: BorderSide.none,
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: AppRadius.tileR,
              borderSide: BorderSide(color: t.primary, width: 1.5),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: AppRadius.tileR,
              borderSide: BorderSide(color: t.negative, width: 1),
            ),
            focusedErrorBorder: OutlineInputBorder(
              borderRadius: AppRadius.tileR,
              borderSide: BorderSide(color: t.negative, width: 1.5),
            ),
            errorStyle: AppType.caption(t.negative),
          ),
        ),
      ],
    );
  }
}

/// Bottom navigation item spec.
class SxNavItem {
  const SxNavItem({required this.icon, required this.label});
  final IconData icon;
  final String label;
}

/// Bottom navigation bar — max 5 items, active item uses the accent.
class SxBottomNav extends StatelessWidget {
  const SxBottomNav({
    super.key,
    required this.items,
    required this.currentIndex,
    required this.onTap,
    this.centerAction,
  });

  final List<SxNavItem> items;
  final int currentIndex;
  final ValueChanged<int> onTap;

  /// Optional raised action rendered between the two halves (the "+" FAB).
  final Widget? centerAction;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final half = (items.length / 2).ceil();

    Widget buildItem(int i) {
      final active = i == currentIndex;
      return Expanded(
        child: InkWell(
          onTap: () => onTap(i),
          borderRadius: AppRadius.iconButtonR,
          splashColor: t.pressed,
          highlightColor: t.pressed,
          child: SizedBox(
            // 44px minimum tap target.
            height: 56,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  items[i].icon,
                  size: 20,
                  color: active ? t.primary : t.textSecondary,
                ),
                const SizedBox(height: 3),
                Text(
                  items[i].label,
                  style: AppType.caption(active ? t.primary : t.textSecondary)
                      .copyWith(
                    fontWeight: active ? FontWeight.w600 : FontWeight.w400,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return SafeArea(
      top: false,
      child: Container(
        margin: const EdgeInsets.fromLTRB(
          AppSpacing.md,
          0,
          AppSpacing.md,
          AppSpacing.sm,
        ),
        decoration: BoxDecoration(
          color: t.surface,
          borderRadius: AppRadius.cardR,
          border: Border.all(color: t.border, width: 1),
        ),
        child: Material(
          color: Colors.transparent,
          child: Row(
            children: [
              for (var i = 0; i < half; i++) buildItem(i),
              if (centerAction != null)
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: AppSpacing.xs,
                  ),
                  child: centerAction!,
                ),
              for (var i = half; i < items.length; i++) buildItem(i),
            ],
          ),
        ),
      ),
    );
  }
}
