import 'dart:developer' as dev;
import 'dart:convert';

import 'package:hive_flutter/hive_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/services/auth_service.dart';
import '../../../data/local/hive_service.dart';
import '../../../models/projector_settings_model.dart';

/// One durable patch for the fields this device edited. The server JSON object
/// is shared with the website, so a patch never replaces fields it did not
/// edit.
///
/// Investments no longer live here (see `public.investments` and
/// InvestmentService). A legacy `holdings` key on the server is preserved
/// untouched and never written to the local investments box.
class ProjectorSyncStore {
  ProjectorSyncStore(this.settings, this.investments);

  final Box settings;
  final Box investments;
  static const cacheKey = 'projector_settings_cache';
  static const legacyDirtyKey = 'projector_settings_dirty';
  static const pendingKey = 'projector_pending_patch';

  Map<String, dynamic> get pendingPatch {
    final raw = settings.get(pendingKey);
    return raw is Map ? Map<String, dynamic>.from(raw) : {};
  }

  bool get hasPending =>
      pendingPatch.isNotEmpty || settings.get(legacyDirtyKey) == true;

  ProjectorSettingsModel get cachedSettings {
    final raw = settings.get(cacheKey);
    return raw is Map
        ? ProjectorSettingsModel.fromMap(Map<String, dynamic>.from(raw))
        : const ProjectorSettingsModel();
  }

  Future<void> stage(Map<String, dynamic> patch) async {
    // Hive updates its in-memory value synchronously. Stage before any await so
    // an immediately following logout also sees these unsynced changes.
    await settings.put(pendingKey, {...pendingPatch, ...patch});
    await applyLocal(patch);
  }

  Future<void> applyLocal(Map<String, dynamic> value) async {
    final effective = {...value, ...pendingPatch};
    final cached = settings.get(cacheKey);
    final merged = <String, dynamic>{
      if (cached is Map) ...Map<String, dynamic>.from(cached),
      ...effective,
    };
    await settings.put(cacheKey, ProjectorSettingsModel.fromMap(merged).toMap());
  }

  /// Callers serialize network sync. New local edits may arrive at any await;
  /// only fields still matching the acknowledged patch are removed.
  Future<void> synchronize({
    required Future<Map<String, dynamic>> Function() read,
    required Future<void> Function(Map<String, dynamic>) write,
    required bool Function() isCurrentUser,
  }) async {
    if (settings.get(legacyDirtyKey) == true) {
      await stage({...cachedSettings.toMap(), ...pendingPatch});
      await settings.delete(legacyDirtyKey);
    }
    final remote = await read();
    if (!isCurrentUser()) return;
    while (pendingPatch.isNotEmpty) {
      final sent = pendingPatch;
      remote.addAll(sent);
      await write(remote);
      if (!isCurrentUser()) return;
      final remaining = pendingPatch;
      for (final key in sent.keys) {
        // Values returned by Hive keep their identity until replaced by stage.
        if (remaining[key] == sent[key]) remaining.remove(key);
      }
      await settings.put(pendingKey, remaining);
    }
    if (isCurrentUser()) await applyLocal(remote);
  }
}

class ProjectorService {
  static SupabaseClient get _db => Supabase.instance.client;
  static Future<void>? _syncInFlight;

  static ProjectorSyncStore get _store =>
      ProjectorSyncStore(Hive.box('settings'), Hive.box('investments'));

  static bool get hasPendingChanges =>
      Hive.isBoxOpen('settings') &&
      ((Hive.box('settings').get(ProjectorSyncStore.pendingKey) as Map?)
                  ?.isNotEmpty ==
              true ||
          Hive.box('settings').get(ProjectorSyncStore.legacyDirtyKey) == true);

  static Future<void> flushPending() async {
    final pending = _syncInFlight ??= _synchronize();
    try {
      await pending;
    } finally {
      if (identical(_syncInFlight, pending)) _syncInFlight = null;
    }
  }

  static Future<void> _synchronize() async {
    final uid = AuthService.currentUserId;
    if (uid == null || AuthService.syncHeldForAccountSwitch) return;
    await SecureHive.openBox('settings');
    await SecureHive.openBox('investments');
    var exists = false;
    String? originalJson;
    await _store.synchronize(
      read: () async {
        final row =
            await _db
                .from('projector_settings')
                .select('settings')
                .eq('user_id', uid)
                .maybeSingle();
        exists = row != null;
        originalJson =
            row?['settings'] == null ? null : jsonEncode(row!['settings']);
        return row?['settings'] is Map
            ? Map<String, dynamic>.from(row!['settings'] as Map)
            : {};
      },
      write: (value) async {
        if (AuthService.currentUserId != uid ||
            AuthService.syncHeldForAccountSwitch) {
          throw StateError('Account changed during investment sync');
        }
        if (!exists) {
          // A concurrent insert fails without acknowledging our pending patch.
          await _db.from('projector_settings').insert({
            'user_id': uid,
            'settings': value,
          });
          exists = true;
        } else {
          var update = _db
              .from('projector_settings')
              .update({'settings': value})
              .eq('user_id', uid);
          update =
              originalJson == null
                  ? update.isFilter('settings', null)
                  : update.eq('settings', originalJson!);
          final rows = await update.select('user_id');
          if (rows.isEmpty) {
            throw StateError(
              'Cloud settings changed during sync; local changes retained for retry',
            );
          }
        }
        originalJson = jsonEncode(value);
        try {
          _db.channel('user-sync:$uid').sendBroadcastMessage(
            event: 'investment-changed',
            payload: {
              'op': 'update',
              'source': 'mobile',
              'time': DateTime.now().millisecondsSinceEpoch,
            },
          );
        } catch (_) {}
      },
      isCurrentUser:
          () =>
              AuthService.currentUserId == uid &&
              !AuthService.syncHeldForAccountSwitch,
    );
  }

  static Future<void> _trySync() async {
    try {
      await flushPending();
    } catch (e, stack) {
      dev.log('Projector changes retained for retry: $e', stackTrace: stack);
    }
  }

  static Future<ProjectorSettingsModel> fetchSettings() async {
    await SecureHive.openBox('settings');
    await SecureHive.openBox('investments');
    await _trySync();
    return _store.cachedSettings;
  }

  static Future<ProjectorSettingsModel> saveSettings(
    ProjectorSettingsModel settings,
  ) async {
    await _store.stage(settings.toMap());
    await _trySync();
    return _store.cachedSettings;
  }
}
