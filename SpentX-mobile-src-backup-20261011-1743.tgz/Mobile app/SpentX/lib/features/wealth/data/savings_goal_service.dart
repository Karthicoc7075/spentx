import 'dart:developer' as dev;
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:uuid/uuid.dart';
import '../../../core/services/auth_service.dart';
import '../../../core/sync/conflict_row_writer.dart';
import '../../../core/services/device_user_state.dart';
import '../../../core/sync/durable_collection.dart';
import '../../../core/sync/sync_error_kind.dart';
import '../../../models/savings_goal_model.dart';

/// Local-first savings goals.
///
/// * Goal rows go through a [DurableCollection] outbox and are written with
///   [ConflictRowWriter] (updated_at conflict check, soft delete only).
/// * Deposits are separate outbox items applied on the server by the
///   `add_goal_contribution` RPC, which adds atomically and ignores replays of
///   the same contribution id — two devices depositing never overwrite each
///   other, and a retry never double counts.
class SavingsGoalService {
  static SupabaseClient get _db => Supabase.instance.client;
  static final Map<String, Future<void>> _inFlight = {};
  static int _generation = 0;
  static void resetSession() {
    _generation++;
    _inFlight.clear();
  }

  /// Local-only flag: the user typed a new "Saved" value in the edit form.
  /// Without it an update never sends saved_amount, so it cannot erase a
  /// deposit made on another device.
  static const savedChangedKey = '_saved_changed';

  static const _localOwner = 'local_user';

  static DurableCollection _store(String uid) => DurableCollection(
    Hive.box('settings'),
    'savings_goals_v2:$uid',
    area: 'Savings goals',
  );
  static DurableCollection _contribStore(String uid) => DurableCollection(
    Hive.box('settings'),
    'goal_contributions_v1:$uid',
    area: 'Goal deposits',
  );

  static String get _effectiveUserId =>
      AuthService.currentUserId ?? _localOwner;

  static bool get hasPendingChanges {
    if (!Hive.isBoxOpen('settings')) return false;
    final uid = AuthService.currentUserId;
    if (uid == null) return false;
    // Server not migrated yet: keep the changes (parked across logout) but
    // never block sign-out over them.
    if (SyncSchemaStatus.isMissing(schemaKey)) return false;
    return _store(uid).hasPending || _contribStore(uid).hasPending;
  }

  /// [SyncSchemaStatus] key for savings_goals + goal_contributions RPC.
  static const schemaKey = 'savings_goals';
  static const _parkArea = 'savings_goals';
  static const _parkContribArea = 'goal_contributions';

  /// Called right before the logout wipe: keeps unsynced goal changes for
  /// this user on the phone so they upload after the next sign-in.
  static Future<void> parkUnsynced(String uid) async {
    if (!Hive.isBoxOpen('settings')) return;
    await DeviceUserState.park(_parkArea, uid, _store(uid));
    await DeviceUserState.park(_parkContribArea, uid, _contribStore(uid));
  }

  static List<SavingsGoalModel> cachedGoals() {
    if (!Hive.isBoxOpen('settings')) return [];
    if (AuthService.currentUserId != null &&
        AuthService.syncHeldForAccountSwitch) {
      return [];
    }
    final goals =
        _store(_effectiveUserId).rows.map(SavingsGoalModel.fromMap).toList()
          ..sort((a, b) => (a.createdAt ?? '').compareTo(b.createdAt ?? ''));
    return goals;
  }

  static Future<void> flushPending() async {
    final uid = AuthService.currentUserId;
    if (uid == null || AuthService.syncHeldForAccountSwitch) return;
    final future = _inFlight.putIfAbsent(uid, () => _synchronize(uid));
    try {
      await future;
      SyncSchemaStatus.markPresent(schemaKey);
    } catch (e) {
      if (SyncErrors.classify(e) == SyncErrorKind.schemaMissing) {
        SyncSchemaStatus.markMissing(schemaKey);
        dev.log('Goal tables/RPC missing on server; changes kept: $e');
        return;
      }
      rethrow;
    } finally {
      if (identical(_inFlight[uid], future)) _inFlight.remove(uid);
    }
  }

  static Map<String, dynamic> _payload(
    Map<String, dynamic> row,
    bool isInsert,
  ) {
    final clean = ConflictRowWriter.stripLocal(row);
    final savedChanged = row[savedChangedKey] == true;
    return {
      'name': clean['name'],
      'target_amount': clean['target_amount'],
      if (isInsert || savedChanged) 'saved_amount': clean['saved_amount'] ?? 0,
      'monthly_contribution': clean['monthly_contribution'],
      'target_date': clean['target_date'],
      'color': clean['color'] ?? 'indigo',
      'icon': clean['icon'] ?? SavingsGoalModel.defaultIcon,
      'is_active': clean['is_active'] ?? true,
      if (isInsert && clean['created_at'] != null)
        'created_at': clean['created_at'],
    };
  }

  static Future<void> _flushContributions(
    String uid,
    bool Function() current,
  ) async {
    final contrib = _contribStore(uid);
    if (!contrib.hasPending) return;
    await contrib.synchronize(
      isCurrent: current,
      write: (id, row) async {
        if (row == null) return;
        // P0002 goal gone / 22023 overdraw / 23503 FK are permanent: the
        // outbox parks them (listed in Settings) instead of blocking sync.
        await _db.rpc(
          'add_goal_contribution',
          params: {
            'p_goal_id': row['goal_id'],
            'p_amount': row['amount'],
            'p_contribution_id': id,
            'p_transaction_id': row['transaction_id'],
            'p_note': row['note'],
            'p_source': 'mobile',
          },
        );
      },
      // Contributions are write-only on the device; nothing to pull.
      read: () async => const <Map<String, dynamic>>[],
    );
  }

  static Future<void> _synchronize(String uid) async {
    final generation = _generation;
    bool current() =>
        generation == _generation &&
        AuthService.currentUserId == uid &&
        !AuthService.syncHeldForAccountSwitch;
    final store = _store(uid);
    if (!store.initialized) {
      final settings = Hive.box('settings');
      final legacy = settings.get('savings_goals_cache');
      final ownsLegacy = settings.get(AuthService.lastUserIdKey) == uid;
      await store.importRows(
        ownsLegacy && legacy is List
            ? legacy
                .whereType<Map>()
                .map((r) => Map<String, dynamic>.from(r))
                .where((r) => r['user_id'] == null || r['user_id'] == uid)
                .toList()
            : [],
      );
    }
    // Changes parked by an earlier logout (server was not migrated yet).
    await DeviceUserState.restoreParked(_parkArea, uid, store);
    await DeviceUserState.restoreParked(
      _parkContribArea,
      uid,
      _contribStore(uid),
    );
    // Goals created while signed out (kept at sign-in) upload now.
    await store.adoptFrom(_store(_localOwner));
    await _contribStore(uid).adoptFrom(_contribStore(_localOwner));
    if (!current()) return;
    await store.synchronize(
      isCurrent: current,
      write: (id, row) async {
        if (!current()) throw StateError('Account changed during goal sync');
        await ConflictRowWriter.write(
          _db,
          table: 'savings_goals',
          uid: uid,
          id: id,
          row: row,
          deletePatch: {
            'is_active': false,
            'deleted_at': DateTime.now().toUtc().toIso8601String(),
          },
          payload: _payload,
        );
        _broadcast(uid, row == null ? 'delete' : 'upsert', id);
      },
      afterWrites: () => _flushContributions(uid, current),
      read: () async {
        final rows = await _db
            .from('savings_goals')
            .select('*')
            .eq('user_id', uid)
            .isFilter('deleted_at', null)
            .order('created_at');
        return rows
            .map((r) => Map<String, dynamic>.from(r))
            .where((r) => r['is_active'] != false)
            .toList();
      },
    );
  }

  static void _broadcast(String uid, String op, String id) {
    try {
      _db
          .channel('user-sync:$uid')
          .sendBroadcastMessage(
            event: 'savings-goal-changed',
            payload: {
              'op': op,
              'id': id,
              'source': 'mobile',
              'time': DateTime.now().millisecondsSinceEpoch,
            },
          );
    } catch (_) {}
  }

  static Future<List<SavingsGoalModel>> fetchSavingsGoals() async {
    try {
      await flushPending();
    } catch (e) {
      dev.log('Goal changes retained for retry: $e');
    }
    return cachedGoals();
  }

  /// [savedChanged] must be true only when the user typed a new saved
  /// amount for an existing goal.
  static Future<SavingsGoalModel> saveSavingsGoal(
    SavingsGoalModel goal, {
    bool savedChanged = false,
  }) async {
    final uid = _effectiveUserId;
    final row = ConflictRowWriter.stampEdit({
      ...goal.toMap(),
      'user_id': uid,
      if (savedChanged) savedChangedKey: true,
    }, baseUpdatedAt: goal.updatedAt);
    await _store(uid).stage(goal.id, row);
    if (AuthService.currentUserId != null &&
        !AuthService.syncHeldForAccountSwitch) {
      try {
        await flushPending();
      } catch (e) {
        dev.log('Goal changes retained for retry: $e');
      }
    }
    return cachedGoals().firstWhere(
      (g) => g.id == goal.id,
      orElse: () => SavingsGoalModel.fromMap(row),
    );
  }

  /// Soft delete only. Failures stay queued and retry; nothing is ever
  /// hard-deleted from the server.
  static Future<void> deleteSavingsGoal(String goalId) async {
    final uid = _effectiveUserId;
    await _store(uid).stage(goalId, null);
    if (AuthService.currentUserId != null &&
        !AuthService.syncHeldForAccountSwitch) {
      try {
        await flushPending();
      } catch (e) {
        dev.log('Goal deletion retained for retry: $e');
      }
    }
  }

  /// Queues an atomic deposit (or a negative withdrawal) and shows it locally
  /// at once. [transactionId] is the Supabase id of the bank transaction
  /// that funded it, so deleting that transaction reverses the deposit.
  static Future<void> addContribution({
    required String goalId,
    required double amount,
    String? transactionId,
    String? note,
  }) async {
    if (amount == 0) throw ArgumentError('Amount must not be zero');
    final uid = _effectiveUserId;
    final store = _store(uid);
    final existing =
        store.rows.where((r) => r['id'].toString() == goalId).toList();
    if (existing.isEmpty) throw StateError('Goal not found');
    final goal = SavingsGoalModel.fromMap(existing.first);
    final next = goal.savedAmount + amount;
    if (next < 0)
      throw ArgumentError('Withdrawal is larger than the saved amount');
    final id = const Uuid().v4();
    await _contribStore(uid).stage(id, {
      'id': id,
      'goal_id': goalId,
      'amount': double.parse(amount.toStringAsFixed(2)),
      'transaction_id': transactionId,
      'note': note,
      'contributed_at': DateTime.now().toUtc().toIso8601String(),
    });
    await store.putLocalRow(goalId, {
      ...existing.first,
      'saved_amount': double.parse(next.toStringAsFixed(2)),
    });
    if (AuthService.currentUserId != null &&
        !AuthService.syncHeldForAccountSwitch) {
      try {
        await flushPending();
      } catch (e) {
        dev.log('Goal deposit retained for retry: $e');
      }
    }
  }
}
