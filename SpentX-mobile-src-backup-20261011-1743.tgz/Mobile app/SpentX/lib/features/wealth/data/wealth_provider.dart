import 'dart:async';
import '../../../core/services/auth_service.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../models/savings_goal_model.dart';
import '../../../models/projector_settings_model.dart';
import 'savings_goal_service.dart';
import 'projector_service.dart';
import '../../../core/providers/transaction_provider.dart' as model;
import '../../../core/providers/user_state_provider.dart';

// --- SAVINGS GOALS PROVIDER ---
class SavingsGoalNotifier extends StateNotifier<AsyncValue<List<SavingsGoalModel>>> {
  SavingsGoalNotifier() : super(const AsyncValue.loading()) {
    _userId = AuthService.currentUserId;
    _authSubscription = AuthService.onAuthStateChange((_) {
      final next = AuthService.currentUserId;
      if (next == _userId) return;
      _userId = next;
      clearForLogout();
      if (next != null) unawaited(loadGoals());
    });
    loadGoals();
  }

  String? _userId;
  int _generation = 0;
  StreamSubscription<dynamic>? _authSubscription;

  void clearForLogout() {
    _generation++;
    state = const AsyncValue.data([]);
  }

  void reloadFromStorage() {
    _generation++;
    state = AsyncValue.data(SavingsGoalService.cachedGoals());
  }

  @override
  void dispose() {
    _authSubscription?.cancel();
    super.dispose();
  }

  Future<void> loadGoals() async {
    final generation = _generation;
    final uid = AuthService.currentUserId;
    try {
      final goals = await SavingsGoalService.fetchSavingsGoals();
      if (!mounted || generation != _generation || uid != AuthService.currentUserId) return;
      state = AsyncValue.data(goals);
    } catch (e, stack) {
      if (!mounted || generation != _generation || uid != AuthService.currentUserId) return;
      state = AsyncValue.error(e, stack);
    }
  }

  Future<void> saveGoal(SavingsGoalModel goal, {bool savedChanged = false}) async {
    final current = state.value ?? [];
    final idx = current.indexWhere((g) => g.id == goal.id);
    final updated = List<SavingsGoalModel>.from(current);
    if (idx >= 0) {
      updated[idx] = goal;
    } else {
      updated.add(goal);
    }
    state = AsyncValue.data(updated);

    // Staging failures (local storage) surface to the caller; network
    // failures stay queued inside the service and retry.
    await SavingsGoalService.saveSavingsGoal(goal, savedChanged: savedChanged);
    if (!mounted) return;
    state = AsyncValue.data(SavingsGoalService.cachedGoals());
  }

  Future<void> deleteGoal(String goalId) async {
    final current = state.value ?? [];
    state = AsyncValue.data(current.where((g) => g.id != goalId).toList());
    try {
      await SavingsGoalService.deleteSavingsGoal(goalId);
    } catch (e) {
      if (mounted) state = AsyncValue.data(current);
      rethrow;
    }
  }

  /// Atomic deposit via the add_goal_contribution RPC (queued offline).
  Future<void> addFunds(
    String goalId,
    double amount, {
    String? transactionId,
    String? note,
  }) async {
    await SavingsGoalService.addContribution(
      goalId: goalId,
      amount: amount,
      transactionId: transactionId,
      note: note,
    );
    if (!mounted) return;
    state = AsyncValue.data(SavingsGoalService.cachedGoals());
  }
}

final savingsGoalProvider =
    StateNotifierProvider<SavingsGoalNotifier, AsyncValue<List<SavingsGoalModel>>>((ref) {
  return SavingsGoalNotifier();
});

// --- PROJECTOR SETTINGS PROVIDER ---
class ProjectorSettingsNotifier extends StateNotifier<ProjectorSettingsModel> {
  ProjectorSettingsNotifier() : super(const ProjectorSettingsModel()) {
    loadSettings();
  }

  Future<void> loadSettings() async {
    try {
      final s = await ProjectorService.fetchSettings();
      state = s;
    } catch (_) {}
  }

  Future<void> updateSettings(ProjectorSettingsModel newSettings) async {
    state = newSettings;
    await ProjectorService.saveSettings(newSettings);
  }
}

final projectorSettingsProvider =
    StateNotifierProvider<ProjectorSettingsNotifier, ProjectorSettingsModel>((ref) {
  return ProjectorSettingsNotifier();
});

// --- EMERGENCY FUND HEALTH ---
class EmergencyFundHealth {
  final double liquidBalance;
  final double monthlyExpenses;
  final double monthsCovered;
  final String status; // 'healthy' | 'moderate' | 'low'
  final String message;

  const EmergencyFundHealth({
    required this.liquidBalance,
    required this.monthlyExpenses,
    required this.monthsCovered,
    required this.status,
    required this.message,
  });
}

final emergencyFundProvider = Provider<EmergencyFundHealth>((ref) {
  final accounts = ref.watch(userStateProvider).accounts.where((a) => a.isActive);
  final txNotifier = ref.read(model.transactionProvider.notifier);
  final txs = ref.watch(model.transactionProvider);

  double bank = 0;
  double cash = 0;
  double creditDebt = 0;

  for (final a in accounts) {
    final bal = txNotifier.getFullAccountBalance(a.name);
    final t = a.type.toLowerCase();
    if (t == 'cash') {
      cash += bal;
    } else if (t == 'credit') {
      creditDebt += bal.abs();
    } else if (t == 'investment' ||
        t == 'mutual_fund' ||
        t == 'stocks' ||
        t == 'equity' ||
        t == 'crypto') {
      // Invested assets are non-liquid
    } else {
      bank += bal;
    }
  }

  final liquidBalance = (bank + cash - creditDebt).clamp(0.0, double.infinity);

  // Compute 3-month monthly average burn rate
  final now = DateTime.now();
  final threeMonthsAgo = DateTime(now.year, now.month - 3, now.day);
  double totalExpense3M = 0;
  double currentMonthExpense = 0;

  for (final t in txs) {
    if (!t.isExpense || t.isPendingVerification) continue;
    final cat = t.category.trim().toLowerCase();
    // Exclude investment outflows from monthly expense burn rate
    if (cat == 'investment' ||
        cat == 'investments' ||
        cat == 'stocks' ||
        cat == 'mutual funds' ||
        cat == 'mutual fund' ||
        cat == 'sip') {
      continue;
    }

    if (t.date.isAfter(threeMonthsAgo)) {
      totalExpense3M += t.amount;
    }
    if (t.date.year == now.year && t.date.month == now.month) {
      currentMonthExpense += t.amount;
    }
  }

  double monthlyExpenses = totalExpense3M / 3.0;
  if (monthlyExpenses <= 0) {
    monthlyExpenses = currentMonthExpense;
  }
  if (monthlyExpenses <= 0) {
    monthlyExpenses = 1.0; // Avoid division by zero
  }

  final monthsCovered = liquidBalance / monthlyExpenses;

  String status = 'healthy';
  String message = '';

  if (monthsCovered >= 6.0) {
    status = 'healthy';
    message = 'Solid safety net! You have ${monthsCovered.toStringAsFixed(1)} months of expenses covered.';
  } else if (monthsCovered >= 3.0) {
    status = 'moderate';
    message = '${monthsCovered.toStringAsFixed(1)} months runway. Consider expanding to 6 months for complete security.';
  } else {
    status = 'low';
    message = 'Runway is ${monthsCovered.toStringAsFixed(1)} months. Aim to build at least 3 to 6 months of liquid expenses.';
  }

  return EmergencyFundHealth(
    liquidBalance: liquidBalance,
    monthlyExpenses: monthlyExpenses,
    monthsCovered: monthsCovered,
    status: status,
    message: message,
  );
});
