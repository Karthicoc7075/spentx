import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../../core/services/auth_service.dart';
import '../../../core/sync/supabase_schema_map.dart';
import '../../../core/providers/transaction_provider.dart' as txp;
import '../../../core/providers/user_state_provider.dart';
import '../../investments/data/investment_provider.dart';
import 'snapshot_outbox.dart';

/// Daily Snapshot (Wealth History) — mirrors the web `useDailySnapshot`
/// hook. Reads/writes the existing `net_worth_history` +
/// `account_balance_history` Supabase tables (already modeled for exactly
/// this) rather than a new schema, and never touches transaction history.
///
/// Writes go through [SnapshotOutbox] (Hive-backed, retried until the server
/// accepts them; deterministic ids via [SyncIds.forNetWorthSnapshot] /
/// [SyncIds.forAccountSnapshot] keep upserts idempotent). Reads are cached in
/// Hive for instant, offline display.

class AccountSnapshotBalance {
  final String accountId;
  final double balance;
  const AccountSnapshotBalance({
    required this.accountId,
    required this.balance,
  });

  Map<String, dynamic> toJson() => {'accountId': accountId, 'balance': balance};
  factory AccountSnapshotBalance.fromJson(Map json) => AccountSnapshotBalance(
    accountId: (json['accountId'] ?? '').toString(),
    balance: (json['balance'] as num? ?? 0).toDouble(),
  );
}

class NetWorthSnapshot {
  final String? id;
  final String date; // UTC yyyy-MM-dd — matches web's snapshot_date key
  final double cashBalance;
  final double bankBalance;
  final double walletBalance;
  final double investmentValue;
  final double netWorth;

  const NetWorthSnapshot({
    this.id,
    required this.date,
    required this.cashBalance,
    required this.bankBalance,
    required this.walletBalance,
    required this.investmentValue,
    required this.netWorth,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'date': date,
    'cashBalance': cashBalance,
    'bankBalance': bankBalance,
    'walletBalance': walletBalance,
    'investmentValue': investmentValue,
    'netWorth': netWorth,
  };

  factory NetWorthSnapshot.fromJson(Map json) => NetWorthSnapshot(
    id: json['id']?.toString(),
    date: (json['date'] ?? '').toString(),
    cashBalance: (json['cashBalance'] as num? ?? 0).toDouble(),
    bankBalance: (json['bankBalance'] as num? ?? 0).toDouble(),
    walletBalance: (json['walletBalance'] as num? ?? 0).toDouble(),
    investmentValue: (json['investmentValue'] as num? ?? 0).toDouble(),
    netWorth: (json['netWorth'] as num? ?? 0).toDouble(),
  );
}

class DailySnapshotState {
  final List<NetWorthSnapshot> history; // sorted desc by date
  final Map<String, List<AccountSnapshotBalance>> accountsByDate;
  final bool isLoading;

  const DailySnapshotState({
    this.history = const [],
    this.accountsByDate = const {},
    this.isLoading = true,
  });

  DailySnapshotState copyWith({
    List<NetWorthSnapshot>? history,
    Map<String, List<AccountSnapshotBalance>>? accountsByDate,
    bool? isLoading,
  }) => DailySnapshotState(
    history: history ?? this.history,
    accountsByDate: accountsByDate ?? this.accountsByDate,
    isLoading: isLoading ?? this.isLoading,
  );

  NetWorthSnapshot? get today {
    final key = _todayKey();
    for (final row in history) {
      if (row.date == key) return row;
    }
    return null;
  }

  NetWorthSnapshot? get yesterday {
    final key = _todayKey();
    for (final row in history) {
      if (row.date.compareTo(key) < 0) return row;
    }
    return null;
  }
}

String _todayKey() => DateTime.now().toUtc().toIso8601String().substring(0, 10);

class DailySnapshotNotifier extends StateNotifier<DailySnapshotState> {
  final Ref _ref;
  static const _boxName = 'wealth_snapshots';
  static const _historyKey = 'history';
  static const _accountsKey = 'accountsByDate';
  String? _lastSyncedSignature;

  DailySnapshotNotifier(this._ref) : super(const DailySnapshotState()) {
    _loadFromCache();
    _refresh();
  }

  Box get _box => Hive.box(_boxName);
  Timer? _refreshTimer;

  void reloadFromStorage() => _loadFromCache();

  @override
  void dispose() {
    _refreshTimer?.cancel();
    super.dispose();
  }

  void _scheduleRefresh() {
    _refreshTimer?.cancel();
    _refreshTimer = Timer(const Duration(milliseconds: 250), () {
      _refreshTimer = null;
      refresh();
    });
  }

  void _loadFromCache() {
    final minDate = AuthService.accountCreatedDateKey;
    final rawHistory = _box.get(_historyKey, defaultValue: []) as List;
    final history =
        rawHistory
            .map((e) => NetWorthSnapshot.fromJson(Map.from(e as Map)))
            .where((s) => minDate == null || s.date.compareTo(minDate) >= 0)
            .toList()
          ..sort((a, b) => b.date.compareTo(a.date));
    final rawAccounts = _box.get(_accountsKey, defaultValue: {}) as Map;
    final accountsByDate = <String, List<AccountSnapshotBalance>>{};
    for (final entry in rawAccounts.entries) {
      final dateKey = entry.key.toString();
      if (minDate != null && dateKey.compareTo(minDate) < 0) continue;
      accountsByDate[dateKey] =
          (entry.value as List)
              .map((e) => AccountSnapshotBalance.fromJson(Map.from(e as Map)))
              .toList();
    }
    state = state.copyWith(
      history: history,
      accountsByDate: accountsByDate,
      isLoading: false,
    );
  }

  void _saveToCache() {
    _box.put(_historyKey, state.history.map((e) => e.toJson()).toList());
    _box.put(
      _accountsKey,
      state.accountsByDate.map(
        (k, v) => MapEntry(k, v.map((e) => e.toJson()).toList()),
      ),
    );
  }

  /// Today's per-type balances computed live from accounts + transactions —
  /// same formulas the Wealth screen already uses, so the snapshot never
  /// drifts from what the user sees today.
  ({
    double cash,
    double bank,
    double wallet,
    double investment,
    double netWorth,
    List<AccountSnapshotBalance> perAccount,
  })
  _computeToday() {
    final rawAccounts = _ref
        .read(userStateProvider)
        .accounts
        .where((a) => a.isActive)
        .toList();
    final accounts = UserStateNotifier.deduplicate(rawAccounts);
    final txNotifier = _ref.read(txp.transactionProvider.notifier);

    double cash = 0, bank = 0, wallet = 0, credit = 0;
    final perAccount = <AccountSnapshotBalance>[];
    for (final a in accounts) {
      // Legacy investment-typed accounts are represented by investments rows.
      if (a.isInvestment) continue;
      final balance = txNotifier.getFullAccountBalance(a.name);
      final remoteId = RemoteIdCache.accountId(a.name);
      switch (a.type.trim().toLowerCase()) {
        case 'cash':
          cash += balance;
          break;
        case 'wallet':
          wallet += balance;
          break;
        case 'credit':
          credit += balance;
          break;
        default:
          bank += balance;
      }
      if (remoteId != null) {
        perAccount.add(
          AccountSnapshotBalance(accountId: remoteId, balance: balance),
        );
      }
    }
    final creditDebt = credit.abs();
    double investment = 0;
    try {
      investment = _ref.read(investmentProvider.notifier).portfolio().current;
    } catch (_) {}
    return (
      cash: cash,
      bank: bank,
      wallet: wallet,
      investment: investment,
      netWorth: bank + cash + wallet - creditDebt,
      perAccount: perAccount,
    );
  }

  Future<void> _refresh() async {
    final today = _computeToday();
    final todayKey = _todayKey();
    final signature =
        '$todayKey:${today.netWorth}:${today.cash}:${today.bank}:${today.wallet}:${today.investment}';

    // Always publish today's snapshot locally first. History must remain
    // useful when the user is offline, before auth has finished restoring, or
    // when the remote tables are temporarily unavailable.
    final localToday = NetWorthSnapshot(
      id: null,
      date: todayKey,
      cashBalance: today.cash,
      bankBalance: today.bank,
      walletBalance: today.wallet,
      investmentValue: today.investment,
      netWorth: today.netWorth,
    );
    final historyByDate = <String, NetWorthSnapshot>{
      for (final row in state.history) row.date: row,
      todayKey: localToday,
    };
    final localAccounts = <String, List<AccountSnapshotBalance>>{
      for (final entry in state.accountsByDate.entries)
        entry.key: List<AccountSnapshotBalance>.of(entry.value),
    };
    localAccounts[todayKey] = List<AccountSnapshotBalance>.of(today.perAccount);
    final minDate = AuthService.accountCreatedDateKey;
    final localHistory =
        historyByDate.values
            .where((row) => minDate == null || row.date.compareTo(minDate) >= 0)
            .toList()
          ..sort((a, b) => b.date.compareTo(a.date));
    if (minDate != null) {
      localAccounts.removeWhere((dateKey, _) => dateKey.compareTo(minDate) < 0);
    }
    state = state.copyWith(
      history: localHistory,
      accountsByDate: localAccounts,
      isLoading: false,
    );
    _saveToCache();

    final uid = AuthService.currentUserId;
    if (uid == null) return;

    if (_lastSyncedSignature != signature) {
      _lastSyncedSignature = signature;
      await SnapshotOutbox.stageUpsert(
        date: todayKey,
        netWorthRow: NetWorthHistoryMap.toRemote(
          uid,
          todayKey,
          cash: today.cash,
          bank: today.bank,
          wallet: today.wallet,
          investment: today.investment,
          total: today.netWorth,
        ),
        accountRows: [
          for (final account in today.perAccount)
            AccountBalanceHistoryMap.toRemote(
              uid,
              account.accountId,
              todayKey,
              account.balance,
            ),
        ],
      );
    }
    try {
      await SnapshotOutbox.flushPending();
    } catch (_) {
      // Kept in the outbox; retried on the next refresh / sync.
    }

    await _pullHistory(uid);
  }

  Future<void> _pullHistory(String uid) async {
    try {
      final db = Supabase.instance.client;
      final minDate = AuthService.accountCreatedDateKey;
      final pendingDeletes = SnapshotOutbox.pendingDeletes();

      // Clean up legacy or stray snapshots that pre-date user's account creation
      if (minDate != null) {
        try {
          await db
              .from(SupaTables.netWorthHistory)
              .delete()
              .eq('user_id', uid)
              .lt('snapshot_date', minDate);
          await db
              .from(SupaTables.accountBalanceHistory)
              .delete()
              .eq('user_id', uid)
              .lt('snapshot_date', minDate);
        } catch (_) {
          // Best-effort tidy-up of rows older than the account; retried next pull.
        }
      }

      var nwQuery = db
          .from(SupaTables.netWorthHistory)
          .select()
          .eq('user_id', uid);
      if (minDate != null) {
        nwQuery = nwQuery.gte('snapshot_date', minDate);
      }
      final netWorthRows =
          await nwQuery.order('snapshot_date', ascending: false);
      final remoteHistory =
          (netWorthRows as List)
              .map(
                (r) => NetWorthHistoryMap.toLocal(
                  Map<String, dynamic>.from(r as Map),
                ),
              )
              .map((json) => NetWorthSnapshot.fromJson(json))
              .where((s) => minDate == null || s.date.compareTo(minDate) >= 0)
              .where((s) => !pendingDeletes.contains(s.date))
              .toList();
      final historyByDate = <String, NetWorthSnapshot>{
        for (final row in state.history)
          if (minDate == null || row.date.compareTo(minDate) >= 0)
            row.date: row,
        for (final row in remoteHistory) row.date: row,
      };
      final history =
          historyByDate.values.toList()
            ..sort((a, b) => b.date.compareTo(a.date));

      var accQuery = db
          .from(SupaTables.accountBalanceHistory)
          .select()
          .eq('user_id', uid);
      if (minDate != null) {
        accQuery = accQuery.gte('snapshot_date', minDate);
      }
      final accountRows = await accQuery;
      final accountsByDate = <String, List<AccountSnapshotBalance>>{
        for (final entry in state.accountsByDate.entries)
          if (minDate == null || entry.key.compareTo(minDate) >= 0)
            entry.key: List<AccountSnapshotBalance>.of(entry.value),
      };
      final remoteAccountsByDate = <String, List<AccountSnapshotBalance>>{};
      for (final r in (accountRows as List)) {
        final json = AccountBalanceHistoryMap.toLocal(
          Map<String, dynamic>.from(r as Map),
        );
        final date = json['date'] as String;
        if (minDate != null && date.compareTo(minDate) < 0) continue;
        if (pendingDeletes.contains(date)) continue;
        (remoteAccountsByDate[date] ??= []).add(
          AccountSnapshotBalance(
            accountId: json['accountId'] as String,
            balance: json['balance'] as double,
          ),
        );
      }
      accountsByDate.addAll(remoteAccountsByDate);

      state = state.copyWith(
        history: history,
        accountsByDate: accountsByDate,
        isLoading: false,
      );
      _saveToCache();
    } catch (_) {
      // Keep whatever was already loaded from cache — offline is fine.
      state = state.copyWith(isLoading: false);
    }
  }

  Future<void> refresh() => _refresh();

  /// Removes one day's snapshot (net worth AND per-account rows). Works
  /// offline: the delete is queued and retried until the server accepts it.
  Future<void> deleteSnapshot(String date) async {
    final uid = AuthService.currentUserId;
    if (uid == null) return;
    await SnapshotOutbox.stageDelete(date);
    final history = state.history.where((row) => row.date != date).toList();
    final accounts = Map<String, List<AccountSnapshotBalance>>.from(state.accountsByDate)
      ..remove(date);
    state = state.copyWith(history: history, accountsByDate: accounts);
    _saveToCache();
    if (date == _todayKey()) _lastSyncedSignature = null;
    try {
      await SnapshotOutbox.flushPending();
    } catch (_) {}
  }
}

final dailySnapshotProvider =
    StateNotifierProvider<DailySnapshotNotifier, DailySnapshotState>((ref) {
      final notifier = DailySnapshotNotifier(ref);
      ref.listen(
        txp.transactionProvider,
        (_, __) => notifier._scheduleRefresh(),
      );
      ref.listen(userStateProvider, (_, __) => notifier._scheduleRefresh());
      ref.listen(investmentProvider, (_, __) => notifier._scheduleRefresh());
      return notifier;
    });

/// Today vs yesterday comparison, including Missing Cash detection (cash
/// dropped more than today's recorded cash expenses explain).
class SnapshotComparison {
  final double netWorthDelta;
  final double cashDelta;
  final double bankDelta;
  final double walletDelta;
  final double missingCash;
  const SnapshotComparison({
    required this.netWorthDelta,
    required this.cashDelta,
    required this.bankDelta,
    required this.walletDelta,
    required this.missingCash,
  });
}

final snapshotComparisonProvider = Provider<SnapshotComparison?>((ref) {
  final state = ref.watch(dailySnapshotProvider);
  final today = state.today;
  final yesterday = state.yesterday;
  if (today == null || yesterday == null) return null;

  final cashDrop = yesterday.cashBalance - today.cashBalance;

  final accounts = ref.watch(userStateProvider).accounts;
  final cashAccountNames =
      accounts
          .where((a) => a.type.toLowerCase() == 'cash')
          .map((a) => a.name.toLowerCase())
          .toSet();
  final txState = ref.watch(txp.transactionProvider);
  final todayKey = _todayKey();
  double recordedCashExpenseToday = 0;
  for (final tx in txState) {
    if (tx.isExpense &&
        tx.date.toUtc().toIso8601String().substring(0, 10) == todayKey &&
        cashAccountNames.contains(tx.account.toLowerCase())) {
      recordedCashExpenseToday += tx.amount;
    }
  }
  final missingCash =
      cashDrop > 0
          ? (cashDrop - recordedCashExpenseToday)
              .clamp(0, double.infinity)
              .toDouble()
          : 0.0;

  return SnapshotComparison(
    netWorthDelta: today.netWorth - yesterday.netWorth,
    cashDelta: today.cashBalance - yesterday.cashBalance,
    bankDelta: today.bankBalance - yesterday.bankBalance,
    walletDelta: today.walletBalance - yesterday.walletBalance,
    missingCash: missingCash,
  );
});
