import 'dart:developer' as dev;

import 'package:hive_flutter/hive_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/services/auth_service.dart';
import '../../../core/sync/durable_collection.dart';
import '../../../core/sync/supabase_schema_map.dart';

/// Offline outbox for Daily Snapshot rows (net_worth_history +
/// account_balance_history). Keyed by snapshot date, so the newest local
/// write for a day wins; a queued delete removes BOTH tables' rows for that
/// day. Failures stay queued and retry on the next sync instead of being
/// swallowed.
class SnapshotOutbox {
  SnapshotOutbox._();

  static SupabaseClient get _db => Supabase.instance.client;
  static Future<void>? _inFlight;

  static DurableCollection _store(String uid) => DurableCollection(
    Hive.box('settings'),
    'snapshot_outbox_v1:$uid',
    area: 'Wealth snapshots',
  );

  static bool get hasPendingChanges {
    final uid = AuthService.currentUserId;
    return uid != null && Hive.isBoxOpen('settings') && _store(uid).hasPending;
  }

  /// Dates with a delete still waiting to upload (hidden from pulls).
  static Set<String> pendingDeletes() {
    final uid = AuthService.currentUserId;
    if (uid == null || !Hive.isBoxOpen('settings')) return const {};
    final raw = Hive.box('settings').get('snapshot_outbox_v1:$uid');
    if (raw is! Map) return const {};
    final pending = (raw['pending'] as Map?) ?? const {};
    return {
      for (final e in pending.entries)
        if ((e.value as Map?)?['row'] == null) e.key.toString(),
    };
  }

  static Future<void> stageUpsert({
    required String date,
    required Map<String, dynamic> netWorthRow,
    required List<Map<String, dynamic>> accountRows,
  }) async {
    final uid = AuthService.currentUserId;
    if (uid == null || !Hive.isBoxOpen('settings')) return;
    await _store(uid).stage(date, {
      'id': date,
      'net_worth': netWorthRow,
      'accounts': accountRows,
    });
  }

  static Future<void> stageDelete(String date) async {
    final uid = AuthService.currentUserId;
    if (uid == null || !Hive.isBoxOpen('settings')) return;
    await _store(uid).stage(date, null);
  }

  static Future<void> flushPending() async {
    final uid = AuthService.currentUserId;
    if (uid == null || AuthService.syncHeldForAccountSwitch) return;
    if (!Hive.isBoxOpen('settings') || !_store(uid).hasPending) return;
    final pending = _inFlight ??= _synchronize(uid);
    try {
      await pending;
    } finally {
      if (identical(_inFlight, pending)) _inFlight = null;
    }
  }

  static Future<void> _synchronize(String uid) async {
    bool current() =>
        AuthService.currentUserId == uid &&
        !AuthService.syncHeldForAccountSwitch;
    try {
      await _store(uid).synchronize(
        isCurrent: current,
        write: (date, row) async {
          if (row == null) {
            await _db
                .from(SupaTables.netWorthHistory)
                .delete()
                .eq('user_id', uid)
                .eq('snapshot_date', date);
            await _db
                .from(SupaTables.accountBalanceHistory)
                .delete()
                .eq('user_id', uid)
                .eq('snapshot_date', date);
            return;
          }
          await _db
              .from(SupaTables.netWorthHistory)
              .upsert(Map<String, dynamic>.from(row['net_worth'] as Map));
          final accounts =
              (row['accounts'] as List? ?? const [])
                  .map((e) => Map<String, dynamic>.from(e as Map))
                  .toList();
          if (accounts.isNotEmpty) {
            await _db.from(SupaTables.accountBalanceHistory).upsert(accounts);
          }
        },
        // Snapshot history is pulled by DailySnapshotNotifier itself.
        read: () async => const <Map<String, dynamic>>[],
      );
    } catch (e) {
      dev.log('Snapshot changes retained for retry: $e');
      rethrow;
    }
  }
}
