import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/theme/soft_palette.dart';

/// Soft Soft surfaces for Accounts and Wealth. Dark mode keeps SoftPalette.
class SoftTone {
  SoftTone(this.context);

  final BuildContext context;

  bool get dark => Theme.of(context).brightness == Brightness.dark;

  Color get canvas => dark ? SoftPalette.darkBg : const Color(0xFFF8FAFC);
  Color get card => dark ? SoftPalette.darkCard : const Color(0xFFFFFFFF);
  Color get border => dark ? SoftPalette.darkBorder : const Color(0xFFF1F5F9);
  Color get ink => dark ? SoftPalette.darkInk : const Color(0xFF0F172A);
  Color get slate => dark ? SoftPalette.darkMuted : const Color(0xFF64748B);
  Color get muted => dark ? SoftPalette.darkFaint : const Color(0xFF94A3B8);
  Color get emerald => dark ? SoftPalette.darkEmerald : const Color(0xFF10B981);
  Color get emeraldDeep =>
      dark ? SoftPalette.darkEmerald : const Color(0xFF059669);
  Color get mint =>
      dark ? SoftPalette.darkEmeraldSoft : const Color(0xFFECFDF5);
  Color get track => dark ? const Color(0xFF1C1917) : const Color(0xFFF1F5F9);

  List<BoxShadow> get shadow =>
      dark
          ? const []
          : const [
            BoxShadow(
              color: Color(0x0A0F172A),
              blurRadius: 16,
              spreadRadius: -2,
              offset: Offset(0, 4),
            ),
          ];

  TextStyle text(
    double size,
    FontWeight weight,
    Color color, {
    double? letterSpacing,
  }) {
    return GoogleFonts.plusJakartaSans(
      fontSize: size,
      fontWeight: weight,
      color: color,
      letterSpacing: letterSpacing,
    );
  }

  BoxDecoration cardBox({double radius = 24}) {
    return BoxDecoration(
      color: card,
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: border),
      boxShadow: shadow,
    );
  }
}

/// Deep-forest hero shared by the Accounts and Wealth bodies.
class SoftForestHero extends StatelessWidget {
  const SoftForestHero({super.key, required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF0B3023), Color(0xFF06281E)],
        ),
        borderRadius: BorderRadius.all(Radius.circular(24)),
      ),
      child: child,
    );
  }
}

/// Mini balance tile drawn on the forest hero.
class SoftHeroMiniTile extends StatelessWidget {
  const SoftHeroMiniTile({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
  });

  final String label;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    final tone = SoftTone(context);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 14, color: const Color(0xFF10B981)),
          const SizedBox(height: 6),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: tone.text(
              10,
              FontWeight.w600,
              Colors.white.withValues(alpha: 0.72),
            ),
          ),
          const SizedBox(height: 2),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: tone.text(13, FontWeight.w800, Colors.white),
          ),
        ],
      ),
    );
  }
}

class SoftSparkline extends StatelessWidget {
  const SoftSparkline({super.key, required this.values});

  final List<double> values;

  @override
  Widget build(BuildContext context) {
    final tone = SoftTone(context);
    return CustomPaint(
      size: const Size(78, 32),
      painter: _SparkPainter(values, tone.emerald),
    );
  }
}

class _SparkPainter extends CustomPainter {
  _SparkPainter(this.values, this.color);

  final List<double> values;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final paint =
        Paint()
          ..color = color
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..strokeCap = StrokeCap.round;
    if (values.length < 2) {
      final y = size.height / 2;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
      canvas.drawCircle(Offset(size.width, y), 3, Paint()..color = color);
      return;
    }
    var minY = values.first;
    var maxY = values.first;
    for (final value in values) {
      if (value < minY) minY = value;
      if (value > maxY) maxY = value;
    }
    final span = (maxY - minY).abs() < 0.0001 ? 1.0 : maxY - minY;
    final path = Path();
    Offset? last;
    for (var i = 0; i < values.length; i++) {
      final x = size.width * i / (values.length - 1);
      final y =
          size.height - ((values[i] - minY) / span) * (size.height - 8) - 4;
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        final prevX = size.width * (i - 1) / (values.length - 1);
        final prevY =
            size.height -
            ((values[i - 1] - minY) / span) * (size.height - 8) -
            4;
        path.cubicTo((prevX + x) / 2, prevY, (prevX + x) / 2, y, x, y);
      }
      last = Offset(x, y);
    }
    canvas.drawPath(path, paint);
    if (last != null) {
      canvas.drawCircle(last, 3, Paint()..color = color);
    }
  }

  @override
  bool shouldRepaint(covariant _SparkPainter oldDelegate) {
    return oldDelegate.values != values || oldDelegate.color != color;
  }
}

/// Soft surface card for Wealth sections.
class SoftWealthCard extends StatelessWidget {
  const SoftWealthCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.onTap,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final tone = SoftTone(context);
    final card = Container(
      padding: padding,
      decoration: tone.cardBox(),
      child: child,
    );
    if (onTap == null) return card;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: const BorderRadius.all(Radius.circular(24)),
        child: card,
      ),
    );
  }
}

/// Daily snapshot row. Date and chips come from the saved snapshot.
class SoftDailySnapshotCard extends StatelessWidget {
  const SoftDailySnapshotCard({
    super.key,
    required this.onViewHistory,
    this.dateLabel,
    this.chips = const [],
    this.emptyLabel,
  });

  final VoidCallback onViewHistory;
  final String? dateLabel;
  final List<String> chips;
  final String? emptyLabel;

  @override
  Widget build(BuildContext context) {
    final tone = SoftTone(context);
    return SoftWealthCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: tone.mint,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(
                  LucideIcons.calendarClock,
                  size: 18,
                  color: tone.emeraldDeep,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'Daily Snapshot',
                  style: tone.text(15, FontWeight.w700, tone.ink),
                ),
              ),
              if (dateLabel != null)
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: tone.mint,
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(
                    dateLabel!,
                    style: tone.text(11, FontWeight.w700, tone.emeraldDeep),
                  ),
                ),
            ],
          ),
          if (emptyLabel != null) ...[
            const SizedBox(height: 12),
            Text(
              emptyLabel!,
              style: tone.text(13, FontWeight.w500, tone.slate),
            ),
          ],
          if (chips.isNotEmpty) ...[
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final chip in chips)
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: tone.mint,
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      chip,
                      style: tone.text(11, FontWeight.w600, tone.emeraldDeep),
                    ),
                  ),
              ],
            ),
          ],
          const SizedBox(height: 10),
          InkWell(
            onTap: onViewHistory,
            child: Text(
              'View snapshot history →',
              style: tone.text(13, FontWeight.w700, tone.emeraldDeep),
            ),
          ),
        ],
      ),
    );
  }
}

/// Soft emerald status pill for Wealth hero.
class SoftWealthPill extends StatelessWidget {
  const SoftWealthPill({super.key, required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    final tone = SoftTone(context);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: tone.mint,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        label,
        style: tone.text(11, FontWeight.w700, tone.emeraldDeep),
      ),
    );
  }
}
