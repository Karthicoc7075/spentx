import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import '../../../../core/theme/soft_palette.dart';

typedef SnapshotTrendPoint = ({String label, double netWorth});

/// Daily net-worth trend from real Daily Snapshot rows — mirrors the web
/// SnapshotTrendChart.
class SnapshotTrendChart extends StatelessWidget {
  final List<SnapshotTrendPoint> data;
  const SnapshotTrendChart({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    if (data.length < 2) return const SizedBox.shrink();

    final minY = data.map((d) => d.netWorth).reduce((a, b) => a < b ? a : b);
    final maxY = data.map((d) => d.netWorth).reduce((a, b) => a > b ? a : b);
    final pad = ((maxY - minY).abs() * 0.1).clamp(1, double.infinity);

    return SizedBox(
      height: 160,
      child: LineChart(
        LineChartData(
          minY: minY - pad,
          maxY: maxY + pad,
          gridData: const FlGridData(show: true, drawVerticalLine: false),
          borderData: FlBorderData(show: false),
          titlesData: FlTitlesData(
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 24,
                interval: (data.length / 4).clamp(1, data.length).toDouble(),
                getTitlesWidget: (value, meta) {
                  final i = value.toInt();
                  if (i < 0 || i >= data.length) return const SizedBox.shrink();
                  return Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(data[i].label, style: const TextStyle(fontSize: 10, color: Colors.grey)),
                  );
                },
              ),
            ),
          ),
          lineTouchData: LineTouchData(
            touchTooltipData: LineTouchTooltipData(
              getTooltipItems: (spots) => spots
                  .map((s) => LineTooltipItem('₹${s.y.toStringAsFixed(0)}', const TextStyle(color: Colors.white, fontSize: 11)))
                  .toList(),
            ),
          ),
          lineBarsData: [
            LineChartBarData(
              spots: [
                for (var i = 0; i < data.length; i++) FlSpot(i.toDouble(), data[i].netWorth),
              ],
              isCurved: true,
              color: SoftPalette.emerald,
              barWidth: 2,
              dotData: const FlDotData(show: false),
              belowBarData: BarAreaData(
                show: true,
                color: SoftPalette.emerald.withValues(alpha: 0.12),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
