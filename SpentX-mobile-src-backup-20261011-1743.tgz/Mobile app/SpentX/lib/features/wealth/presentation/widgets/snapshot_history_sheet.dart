import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/providers/user_state_provider.dart';
import '../../../../core/services/auth_service.dart';
import '../../../../models/account_model.dart';
import '../../data/daily_snapshot_provider.dart';
import 'soft_wealth_widgets.dart';

String _fmt(double v) => NumberFormat.currency(
  symbol: '₹',
  decimalDigits: 0,
  locale: 'en_IN',
).format(v);

DateTime? _parseDay(String date) {
  final parts = date.split('-');
  if (parts.length != 3) return DateTime.tryParse(date);
  final y = int.tryParse(parts[0]);
  final m = int.tryParse(parts[1]);
  final d = int.tryParse(parts[2]);
  if (y == null || m == null || d == null) return null;
  return DateTime(y, m, d);
}

String _dayLabel(String date) {
  final d = _parseDay(date);
  if (d == null) return date;
  return DateFormat('d MMM yyyy').format(d);
}

enum _FilterRange { today, days7, thisMonth, lastMonth, all }

class SnapshotHistorySheet extends ConsumerStatefulWidget {
  const SnapshotHistorySheet({super.key});

  static Future<void> show(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor:
          dark ? SoftTone(context).canvas : const Color(0xFFF8FAFC),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => const SnapshotHistorySheet(),
    );
  }

  @override
  ConsumerState<SnapshotHistorySheet> createState() =>
      _SnapshotHistorySheetState();
}

class _SnapshotHistorySheetState extends ConsumerState<SnapshotHistorySheet> {
  _FilterRange _filter = _FilterRange.days7;

  @override
  Widget build(BuildContext context) {
    final tone = SoftTone(context);
    final state = ref.watch(dailySnapshotProvider);
    final userAccounts = ref.watch(userStateProvider).accounts;
    final history = state.history;

    // Snapshot keys are stored in UTC, so filter against UTC calendar days as
    // well. Using the device's local date made the newest row disappear for
    // users near the UTC day boundary.
    final now = DateTime.now();
    final nowUtc = now.toUtc();
    final todayUtc = DateTime.utc(nowUtc.year, nowUtc.month, nowUtc.day);
    final todayStr = DateFormat('yyyy-MM-dd').format(todayUtc);
    final currentMonthKey = DateFormat('yyyy-MM').format(todayUtc);
    final lastMonthKey = DateFormat(
      'yyyy-MM',
    ).format(DateTime.utc(nowUtc.year, nowUtc.month - 1, 1));

    final minDate = AuthService.accountCreatedDateKey;
    final filtered =
        history.where((item) {
          if (minDate != null && item.date.compareTo(minDate) < 0) return false;
          if (_filter == _FilterRange.today) return item.date == todayStr;
          if (_filter == _FilterRange.days7) {
            final d = DateTime.tryParse('${item.date}T00:00:00Z');
            if (d == null) return true;
            final snapshotDay = DateTime.utc(d.year, d.month, d.day);
            final age = todayUtc.difference(snapshotDay).inDays;
            return age >= 0 && age <= 7;
          }
          if (_filter == _FilterRange.thisMonth) {
            return item.date.startsWith(currentMonthKey);
          }
          if (_filter == _FilterRange.lastMonth) {
            return item.date.startsWith(lastMonthKey);
          }
          return true;
        }).toList();

    final priorByDate = <String, NetWorthSnapshot>{};
    for (var i = 0; i < history.length; i++) {
      if (i + 1 < history.length) {
        priorByDate[history[i].date] = history[i + 1];
      }
    }

    return DraggableScrollableSheet(
      initialChildSize: 0.85,
      minChildSize: 0.5,
      maxChildSize: 0.95,
      expand: false,
      builder: (context, scrollController) {
        return SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  margin: const EdgeInsets.only(top: 10),
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: tone.border,
                    borderRadius: BorderRadius.circular(999),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 4),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Daily Snapshot History',
                      style: tone.text(20, FontWeight.w700, tone.ink),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Saved cash, bank, and wallet balances.',
                      style: tone.text(13, FontWeight.w500, tone.slate),
                    ),
                  ],
                ),
              ),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
                child: Row(
                  children: [
                    _FilterChipItem(
                      label: 'Today',
                      isSelected: _filter == _FilterRange.today,
                      onTap: () => setState(() => _filter = _FilterRange.today),
                    ),
                    _FilterChipItem(
                      label: 'Last 7 Days',
                      isSelected: _filter == _FilterRange.days7,
                      onTap: () => setState(() => _filter = _FilterRange.days7),
                    ),
                    _FilterChipItem(
                      label: 'This Month',
                      isSelected: _filter == _FilterRange.thisMonth,
                      onTap:
                          () =>
                              setState(() => _filter = _FilterRange.thisMonth),
                    ),
                    _FilterChipItem(
                      label: 'Last Month',
                      isSelected: _filter == _FilterRange.lastMonth,
                      onTap:
                          () =>
                              setState(() => _filter = _FilterRange.lastMonth),
                    ),
                    _FilterChipItem(
                      label: 'All',
                      isSelected: _filter == _FilterRange.all,
                      onTap: () => setState(() => _filter = _FilterRange.all),
                    ),
                  ],
                ),
              ),
              Expanded(
                child:
                    filtered.isEmpty
                        ? ListView(
                          controller: scrollController,
                          padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
                          children: [
                            _EmptyHistory(
                              loading: state.isLoading && history.isEmpty,
                              filteredOut: history.isNotEmpty,
                              accountCreatedDate: minDate,
                            ),
                          ],
                        )
                        : ListView.builder(
                          controller: scrollController,
                          padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
                          itemCount: filtered.length,
                          itemBuilder: (context, index) {
                            final dayRow = filtered[index];
                            final prior = priorByDate[dayRow.date];
                            final delta =
                                prior == null
                                    ? null
                                    : dayRow.netWorth - prior.netWorth;
                            return _SnapshotDayCard(
                              day: dayRow,
                              delta: delta,
                              accounts:
                                  state.accountsByDate[dayRow.date] ?? const [],
                              userAccounts: userAccounts,
                            );
                          },
                        ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _SnapshotDayCard extends StatelessWidget {
  const _SnapshotDayCard({
    required this.day,
    required this.delta,
    required this.accounts,
    required this.userAccounts,
  });

  final NetWorthSnapshot day;
  final double? delta;
  final List<AccountSnapshotBalance> accounts;
  final List<AccountModel> userAccounts;

  String _accountLabel(String id) {
    for (final acc in userAccounts) {
      if (acc.id == id ||
          acc.name == id ||
          acc.name.toLowerCase() == id.toLowerCase()) {
        return acc.name.isEmpty ? id : acc.name;
      }
    }
    return id;
  }

  @override
  Widget build(BuildContext context) {
    final tone = SoftTone(context);
    final rows = <(String, double)>[
      ('Cash', day.cashBalance),
      ('Bank', day.bankBalance),
      ('Wallet', day.walletBalance),
      if (day.investmentValue != 0) ('Investments', day.investmentValue),
    ];

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: tone.cardBox(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: tone.mint,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(
                    LucideIcons.calendar,
                    size: 18,
                    color: tone.emeraldDeep,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _dayLabel(day.date),
                        style: tone.text(15, FontWeight.w700, tone.ink),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'Net worth',
                        style: tone.text(12, FontWeight.w500, tone.slate),
                      ),
                    ],
                  ),
                ),
                Text(
                  _fmt(day.netWorth),
                  style: tone.text(16, FontWeight.w800, tone.ink),
                ),
              ],
            ),
            if (delta != null) ...[
              const SizedBox(height: 10),
              _DeltaPill(delta: delta!),
            ],
            const SizedBox(height: 14),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final row in rows)
                  _BalanceChip(label: row.$1, value: _fmt(row.$2)),
              ],
            ),
            if (accounts.isNotEmpty) ...[
              const SizedBox(height: 14),
              Container(height: 1, color: tone.border),
              const SizedBox(height: 12),
              for (final account in accounts)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          _accountLabel(account.accountId),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: tone.text(13, FontWeight.w500, tone.slate),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Text(
                        _fmt(account.balance),
                        style: tone.text(14, FontWeight.w700, tone.ink),
                      ),
                    ],
                  ),
                ),
            ],
          ],
        ),
      ),
    );
  }
}

class _BalanceChip extends StatelessWidget {
  const _BalanceChip({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final tone = SoftTone(context);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: tone.mint,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        '$label $value',
        style: tone.text(11, FontWeight.w600, tone.emeraldDeep),
      ),
    );
  }
}

class _DeltaPill extends StatelessWidget {
  const _DeltaPill({required this.delta});

  final double delta;

  @override
  Widget build(BuildContext context) {
    final tone = SoftTone(context);
    final flat = delta.abs() < 0.5;
    final up = delta > 0;
    final color =
        flat ? tone.slate : (up ? tone.emeraldDeep : const Color(0xFFDC2626));
    final bg = flat ? tone.track : (up ? tone.mint : const Color(0xFFFEE2E2));
    final sign = flat ? '' : (up ? '+' : '−');
    final label =
        flat
            ? 'No change from previous day'
            : '$sign${_fmt(delta.abs())} from previous day';
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(label, style: tone.text(11, FontWeight.w700, color)),
    );
  }
}

class _EmptyHistory extends StatelessWidget {
  const _EmptyHistory({
    required this.loading,
    required this.filteredOut,
    this.accountCreatedDate,
  });

  final bool loading;
  final bool filteredOut;
  final String? accountCreatedDate;

  @override
  Widget build(BuildContext context) {
    final tone = SoftTone(context);
    final title =
        loading
            ? 'Loading snapshots'
            : filteredOut
            ? 'Nothing in this range'
            : 'No snapshots yet';
    final body =
        loading
            ? 'Checking saved daily balances.'
            : filteredOut
            ? 'Daily snapshots only record from your account creation date onwards.'
            : 'Daily balances appear here after your accounts sync. Snapshots start tracking from the day your account was created.';
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 28, 20, 28),
      decoration: tone.cardBox(),
      child: Column(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              color: tone.mint,
              borderRadius: BorderRadius.circular(18),
            ),
            child: Icon(
              LucideIcons.calendarClock,
              size: 22,
              color: tone.emeraldDeep,
            ),
          ),
          const SizedBox(height: 14),
          Text(
            title,
            textAlign: TextAlign.center,
            style: tone.text(16, FontWeight.w700, tone.ink),
          ),
          const SizedBox(height: 6),
          Text(
            body,
            textAlign: TextAlign.center,
            style: tone.text(13, FontWeight.w500, tone.slate),
          ),
        ],
      ),
    );
  }
}

class _FilterChipItem extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;

  const _FilterChipItem({
    required this.label,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final tone = SoftTone(context);
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(999),
          child: Ink(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: isSelected ? tone.emerald : tone.card,
              borderRadius: BorderRadius.circular(999),
              border: isSelected ? null : Border.all(color: tone.border),
              boxShadow: isSelected ? null : tone.shadow,
            ),
            child: Text(
              label,
              style: tone.text(
                12,
                FontWeight.w600,
                isSelected ? Colors.white : tone.slate,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
