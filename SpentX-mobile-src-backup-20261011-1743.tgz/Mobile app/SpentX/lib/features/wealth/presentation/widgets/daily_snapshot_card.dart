import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../data/daily_snapshot_provider.dart';
import 'snapshot_history_sheet.dart';
import 'soft_wealth_widgets.dart';

class DailySnapshotCard extends ConsumerWidget {
  const DailySnapshotCard({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final history = ref.watch(dailySnapshotProvider).history;
    final latest = history.isEmpty ? null : history.first;
    final money = NumberFormat.currency(
      symbol: '₹',
      decimalDigits: 0,
      locale: 'en_IN',
    );
    String? dateLabel;
    final chips = <String>[];
    if (latest != null) {
      final parsed = DateTime.tryParse('${latest.date}T00:00:00Z');
      if (parsed != null) {
        dateLabel = DateFormat('d MMM').format(parsed.toLocal());
      }
      chips.add('Cash ${money.format(latest.cashBalance)}');
      chips.add('Bank ${money.format(latest.bankBalance)}');
      chips.add('Wallet ${money.format(latest.walletBalance)}');
    }
    return SoftDailySnapshotCard(
      onViewHistory: () => SnapshotHistorySheet.show(context),
      dateLabel: dateLabel,
      chips: chips,
      emptyLabel: latest == null
          ? 'No snapshots yet. Today\'s balances show up after your accounts sync.'
          : null,
    );
  }
}
