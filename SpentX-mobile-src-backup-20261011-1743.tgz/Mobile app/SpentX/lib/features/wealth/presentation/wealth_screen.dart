import 'package:flutter/material.dart';
import '../../../core/theme/soft_palette.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../core/providers/investment_provider.dart';
import '../../../core/providers/transaction_provider.dart' as model;
import '../../../core/providers/user_state_provider.dart';
import '../../investments/presentation/widgets/investment_form_sheet.dart';
import '../../../models/savings_goal_model.dart';
import '../data/daily_snapshot_provider.dart';
import '../data/wealth_provider.dart';
import 'widgets/soft_wealth_widgets.dart';
import '../../../core/widgets/premium_bottom_sheet.dart';

Color _goalColor(String? colorName, SoftTone tone) {
  switch (colorName?.toLowerCase()) {
    case 'indigo':
      return const Color(0xFF6366F1);
    case 'emerald':
    case 'mint':
      return const Color(0xFF10B981);
    case 'amber':
      return const Color(0xFFF59E0B);
    case 'rose':
      return const Color(0xFFF43F5E);
    case 'sky':
      return const Color(0xFF0EA5E9);
    case 'violet':
      return const Color(0xFF8B5CF6);
    default:
      return tone.emeraldDeep;
  }
}

/// Wealth cards rendered inside the Accounts & Wealth screen.
class WealthContent extends ConsumerStatefulWidget {
  const WealthContent({super.key});

  @override
  ConsumerState<WealthContent> createState() => _WealthContentState();
}

class _WealthContentState extends ConsumerState<WealthContent> {
  String _fmt(double v) {
    return NumberFormat.currency(
      symbol: '₹',
      decimalDigits: 0,
      locale: 'en_IN',
    ).format(v);
  }

  /// Accurate breakdown of wealth matching web algorithms.
  ({
    double cash,
    double bank,
    double wallet,
    double investment,
    double creditDebt,
    double liquidNetWorth,
    double totalNetWorth,
    double monthlyChange,
  })
  _computeBreakdown() {
    final rawAccounts =
        ref.watch(userStateProvider).accounts.where((a) => a.isActive).toList();
    final accounts = UserStateNotifier.deduplicate(rawAccounts);
    final txs = ref.watch(model.transactionProvider);
    final txNotifier = ref.read(model.transactionProvider.notifier);

    double cash = 0;
    double bank = 0;
    double wallet = 0;
    double credit = 0;

    for (final a in accounts) {
      // Legacy investment-typed accounts are represented by investments rows
      // (imported once), so their balance is not counted again here.
      if (a.isInvestment) continue;
      final bal = txNotifier.getFullAccountBalance(a.name);
      if (a.isCash) {
        cash += bal;
      } else if (a.isCredit) {
        credit += bal;
      } else if (a.isWallet) {
        wallet += bal;
      } else {
        bank += bal;
      }
    }

    // Holdings (current value) + investment spends not linked to a holding.
    ref.watch(investmentProvider);
    final investment =
        ref.read(investmentProvider.notifier).portfolio().current;

    final creditDebt = credit.abs();
    final liquidNetWorth = bank + wallet + cash - creditDebt;
    final totalNetWorth = liquidNetWorth + investment;

    final now = DateTime.now();
    final startThisMonth = DateTime(now.year, now.month, 1);
    final startLastMonth = DateTime(now.year, now.month - 1, 1);
    final endLastMonth = DateTime(now.year, now.month, 0, 23, 59, 59);

    double thisMonthSavings = 0;
    double lastMonthSavings = 0;

    for (final t in txs) {
      if (t.isPendingVerification) continue;
      final delta = t.isExpense ? -t.amount : t.amount;
      if (t.date.isAfter(startThisMonth)) {
        thisMonthSavings += delta;
      } else if (t.date.isAfter(startLastMonth) &&
          t.date.isBefore(endLastMonth)) {
        lastMonthSavings += delta;
      }
    }

    return (
      cash: cash,
      bank: bank,
      wallet: wallet,
      investment: investment,
      creditDebt: creditDebt,
      liquidNetWorth: liquidNetWorth,
      totalNetWorth: totalNetWorth,
      monthlyChange: thisMonthSavings - lastMonthSavings,
    );
  }

  void _createGoal() => _showGoalModal();

  Future<void> _showGoalModal({SavingsGoalModel? existingGoal}) async {
    final nameCtrl = TextEditingController(text: existingGoal?.name ?? '');
    final targetCtrl = TextEditingController(
      text:
          existingGoal != null
              ? existingGoal.targetAmount.toStringAsFixed(0)
              : '',
    );
    final depositCtrl = TextEditingController(
      text:
          existingGoal != null
              ? existingGoal.savedAmount.toStringAsFixed(0)
              : '0',
    );
    final monthlyCtrl = TextEditingController(
      text:
          existingGoal?.monthlyContribution != null
              ? existingGoal!.monthlyContribution!.toStringAsFixed(0)
              : '',
    );
    String selectedIcon =
        existingGoal?.displayIcon ?? SavingsGoalModel.defaultIcon;
    String selectedColor = existingGoal?.color ?? 'indigo';
    DateTime? targetDate =
        existingGoal?.targetDate != null
            ? DateTime.tryParse(existingGoal!.targetDate!)
            : null;
    bool hasDeadline = targetDate != null;

    final rawAccounts =
        ref
            .read(userStateProvider)
            .accounts
            .where((a) => a.isActive && (a.isBank || a.isWallet))
            .toList();
    final dedupedAccounts = UserStateNotifier.deduplicate(rawAccounts);
    final seen = <String>{};
    final accounts = dedupedAccounts.where((a) => seen.add(a.name)).toList();
    String? selectedAccount = accounts.isNotEmpty ? accounts.first.name : null;
    bool deductFromAccount = existingGoal == null;
    String? nameError;
    String? targetError;
    String? savedError;
    String? monthlyError;

    final saved = await PremiumBottomSheet.show<bool>(
      context: context,
      child: StatefulBuilder(
        builder: (ctx, setModalState) {
          final tone = SoftTone(ctx);
          return Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                        color: _goalColor(
                          selectedColor,
                          tone,
                        ).withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Center(
                        child: Text(
                          selectedIcon,
                          style: const TextStyle(fontSize: 22),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            existingGoal == null
                                ? 'New savings goal'
                                : 'Edit savings goal',
                            style: tone.text(18, FontWeight.w800, tone.ink),
                          ),
                          Text(
                            'Set targets, custom icons & deadlines',
                            style: tone.text(12, FontWeight.w500, tone.slate),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                TextField(
                  controller: nameCtrl,
                  textCapitalization: TextCapitalization.sentences,
                  style: tone.text(14, FontWeight.w600, tone.ink),
                  decoration: _softDialogInputDecoration(
                    'Goal name *',
                    tone,
                  ).copyWith(errorText: nameError),
                  onChanged: (_) {
                    if (nameError != null)
                      setModalState(() => nameError = null);
                  },
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: targetCtrl,
                        keyboardType: const TextInputType.numberWithOptions(
                          decimal: true,
                        ),
                        style: tone.text(14, FontWeight.w600, tone.ink),
                        decoration: _softDialogInputDecoration(
                          'Target (₹) *',
                          tone,
                        ).copyWith(errorText: targetError),
                        onChanged: (_) {
                          if (targetError != null)
                            setModalState(() => targetError = null);
                        },
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: TextField(
                        controller: depositCtrl,
                        keyboardType: const TextInputType.numberWithOptions(
                          decimal: true,
                        ),
                        style: tone.text(14, FontWeight.w600, tone.ink),
                        decoration: _softDialogInputDecoration(
                          existingGoal == null
                              ? 'Initial Saved (₹)'
                              : 'Saved (₹)',
                          tone,
                        ).copyWith(errorText: savedError),
                        onChanged: (_) {
                          if (savedError != null)
                            setModalState(() => savedError = null);
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: monthlyCtrl,
                  keyboardType: const TextInputType.numberWithOptions(
                    decimal: true,
                  ),
                  style: tone.text(14, FontWeight.w600, tone.ink),
                  decoration: _softDialogInputDecoration(
                    'Monthly contribution (₹, optional)',
                    tone,
                  ).copyWith(
                    errorText: monthlyError,
                    hintText: 'Leave empty for none',
                  ),
                  onChanged: (_) {
                    if (monthlyError != null)
                      setModalState(() => monthlyError = null);
                  },
                ),
                const SizedBox(height: 14),
                Text(
                  'Pick Icon',
                  style: tone.text(12, FontWeight.w700, tone.slate),
                ),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children:
                      [
                        '🏍️',
                        '✈️',
                        '💻',
                        '🏠',
                        '🚗',
                        '💍',
                        '🎓',
                        '🛡️',
                        '🎯',
                        '💰',
                        '📱',
                        '🏖️',
                      ].map((emoji) {
                        final isSelected = selectedIcon == emoji;
                        return InkWell(
                          onTap:
                              () => setModalState(() => selectedIcon = emoji),
                          borderRadius: BorderRadius.circular(10),
                          child: Container(
                            width: 38,
                            height: 38,
                            decoration: BoxDecoration(
                              color: isSelected ? tone.mint : tone.track,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                color:
                                    isSelected ? tone.emeraldDeep : tone.border,
                                width: isSelected ? 1.5 : 1,
                              ),
                            ),
                            child: Center(
                              child: Text(
                                emoji,
                                style: const TextStyle(fontSize: 18),
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                ),
                const SizedBox(height: 14),
                Text(
                  'Color Theme',
                  style: tone.text(12, FontWeight.w700, tone.slate),
                ),
                const SizedBox(height: 6),
                Row(
                  children:
                      [
                        ('indigo', const Color(0xFF6366F1)),
                        ('emerald', const Color(0xFF10B981)),
                        ('amber', const Color(0xFFF59E0B)),
                        ('rose', const Color(0xFFF43F5E)),
                        ('sky', const Color(0xFF0EA5E9)),
                        ('violet', const Color(0xFF8B5CF6)),
                      ].map((pair) {
                        final isSelected = selectedColor == pair.$1;
                        return Padding(
                          padding: const EdgeInsets.only(right: 10),
                          child: InkWell(
                            onTap:
                                () => setModalState(
                                  () => selectedColor = pair.$1,
                                ),
                            borderRadius: BorderRadius.circular(999),
                            child: Container(
                              width: 28,
                              height: 28,
                              decoration: BoxDecoration(
                                color: pair.$2,
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color:
                                      isSelected
                                          ? Colors.white
                                          : Colors.transparent,
                                  width: 2.5,
                                ),
                                boxShadow:
                                    isSelected
                                        ? [
                                          BoxShadow(
                                            color: pair.$2.withValues(
                                              alpha: 0.5,
                                            ),
                                            blurRadius: 6,
                                          ),
                                        ]
                                        : null,
                              ),
                              child:
                                  isSelected
                                      ? const Icon(
                                        Icons.check,
                                        size: 14,
                                        color: Colors.white,
                                      )
                                      : null,
                            ),
                          ),
                        );
                      }).toList(),
                ),
                const SizedBox(height: 14),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Target Deadline',
                      style: tone.text(12, FontWeight.w700, tone.slate),
                    ),
                    Row(
                      children: [
                        Text(
                          hasDeadline ? 'Fixed date' : 'Any time (Flexible)',
                          style: tone.text(
                            12,
                            FontWeight.w600,
                            hasDeadline ? tone.emeraldDeep : tone.slate,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Switch.adaptive(
                          value: hasDeadline,
                          activeTrackColor: SoftColors.control,
                          onChanged: (val) {
                            setModalState(() {
                              hasDeadline = val;
                              if (val && targetDate == null) {
                                targetDate = DateTime.now().add(
                                  const Duration(days: 180),
                                );
                              }
                            });
                          },
                        ),
                      ],
                    ),
                  ],
                ),
                if (hasDeadline && targetDate != null) ...[
                  const SizedBox(height: 6),
                  InkWell(
                    onTap: () async {
                      // Date-only bounds; an overdue saved deadline must
                      // stay selectable or showDatePicker asserts.
                      final range = goalDeadlinePickerRange(targetDate);
                      final picked = await showDatePicker(
                        context: ctx,
                        initialDate: range.initial,
                        firstDate: range.first,
                        lastDate: range.last,
                      );
                      if (picked != null) {
                        setModalState(() => targetDate = picked);
                      }
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 14,
                        vertical: 12,
                      ),
                      decoration: BoxDecoration(
                        color: tone.track,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: tone.border),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            LucideIcons.calendar,
                            size: 16,
                            color: tone.emeraldDeep,
                          ),
                          const SizedBox(width: 8),
                          Text(
                            DateFormat('MMMM yyyy').format(targetDate!),
                            style: tone.text(13, FontWeight.w700, tone.ink),
                          ),
                          const Spacer(),
                          Text(
                            'Change',
                            style: tone.text(12, FontWeight.w600, tone.slate),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
                if (existingGoal == null && accounts.isNotEmpty) ...[
                  const SizedBox(height: 14),
                  Text(
                    'Funding Bank (Optional)',
                    style: tone.text(12, FontWeight.w700, tone.slate),
                  ),
                  const SizedBox(height: 6),
                  DropdownButtonFormField<String>(
                    initialValue: selectedAccount,
                    dropdownColor: tone.card,
                    isExpanded: true,
                    decoration: _softDialogInputDecoration('Source Bank', tone),
                    items:
                        accounts.map((a) {
                          return DropdownMenuItem(
                            value: a.name,
                            child: Text(
                              a.name,
                              style: tone.text(13, FontWeight.w600, tone.ink),
                            ),
                          );
                        }).toList(),
                    onChanged:
                        (val) => setModalState(() => selectedAccount = val),
                  ),
                ],
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(ctx, false),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: tone.slate,
                          side: BorderSide(color: tone.border),
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                        child: const Text('Cancel'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton(
                        onPressed: () {
                          final n = nameCtrl.text.trim();
                          final t = parseAmountInput(targetCtrl.text) ?? 0;
                          final sv =
                              depositCtrl.text.trim().isEmpty
                                  ? 0.0
                                  : parseAmountInput(depositCtrl.text);
                          final mc =
                              monthlyCtrl.text.trim().isEmpty
                                  ? 0.0
                                  : parseAmountInput(monthlyCtrl.text);
                          if (sv == null || sv < 0) {
                            setModalState(() => savedError = 'Enter 0 or more');
                          }
                          if (mc == null || mc < 0) {
                            setModalState(
                              () => monthlyError = 'Enter 0 or more',
                            );
                          }
                          bool hasErr = false;
                          if (n.isEmpty) {
                            setModalState(
                              () => nameError = 'Please enter a goal name',
                            );
                            hasErr = true;
                          }
                          if (t <= 0) {
                            setModalState(
                              () =>
                                  targetError = 'Enter a target greater than 0',
                            );
                            hasErr = true;
                          }
                          if (hasErr ||
                              savedError != null ||
                              monthlyError != null)
                            return;

                          FocusScope.of(ctx).unfocus();
                          Navigator.pop(ctx, true);
                        },
                        style: FilledButton.styleFrom(
                          backgroundColor: SoftColors.control,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                        child: Text(
                          existingGoal == null ? 'Create Goal' : 'Save Changes',
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );

    final name = nameCtrl.text.trim();
    final target = parseAmountInput(targetCtrl.text) ?? 0;
    final savedVal = parseAmountInput(depositCtrl.text) ?? 0;
    final monthly = parseAmountInput(monthlyCtrl.text);
    final defaultPurpose = defaultPurposeOf(
      ref.read(userStateProvider).purposeTypes,
    );

    if (saved != true || !mounted || name.isEmpty || target <= 0) return;

    final finalDateStr =
        hasDeadline && targetDate != null
            ? DateFormat('yyyy-MM-dd').format(targetDate!)
            : null;

    try {
      if (existingGoal != null) {
        final savedChanged =
            (savedVal - existingGoal.savedAmount).abs() >= 0.005;
        final updated = existingGoal.copyWith(
          name: name,
          targetAmount: target,
          savedAmount: savedVal,
          targetDate: finalDateStr,
          clearTargetDate: finalDateStr == null,
          monthlyContribution: monthly,
          clearMonthlyContribution: monthly == null || monthly <= 0,
          color: selectedColor,
          icon: selectedIcon,
        );
        await ref
            .read(savingsGoalProvider.notifier)
            .saveGoal(updated, savedChanged: savedChanged);
      } else {
        final newGoal = SavingsGoalModel(
          name: name,
          targetAmount: target,
          savedAmount: savedVal,
          monthlyContribution: monthly != null && monthly > 0 ? monthly : null,
          targetDate: finalDateStr,
          color: selectedColor,
          icon: selectedIcon,
        );
        await ref.read(savingsGoalProvider.notifier).saveGoal(newGoal);

        if (savedVal > 0 && selectedAccount != null && deductFromAccount) {
          final now = DateTime.now();
          ref
              .read(model.transactionProvider.notifier)
              .addTransaction(
                model.Transaction(
                  merchant: 'Savings: $name',
                  amount: savedVal,
                  isExpense: true,
                  time: DateFormat('hh:mm a').format(now),
                  category: 'Settlements',
                  account: selectedAccount!,
                  purpose: defaultPurpose,
                  date: now,
                  note: 'Initial deposit to savings goal "$name"',
                ),
              );
        }
      }
      if (mounted) {
        final tone = SoftTone(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              existingGoal == null
                  ? 'Savings goal created! 🎯'
                  : 'Goal updated! ✨',
            ),
            backgroundColor: tone.emeraldDeep,
            duration: const Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to save goal: $e'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
    }
  }

  Future<void> _deleteGoal(SavingsGoalModel goal) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) {
        final tone = SoftTone(ctx);
        return AlertDialog(
          backgroundColor: tone.card,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          title: Text(
            'Delete Goal?',
            style: tone.text(18, FontWeight.w800, tone.ink),
          ),
          content: Text(
            'Are you sure you want to delete "${goal.name}"? This cannot be undone.',
            style: tone.text(13, FontWeight.w500, tone.slate),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(
                'Cancel',
                style: tone.text(14, FontWeight.w600, tone.slate),
              ),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              style: FilledButton.styleFrom(
                backgroundBuilder: SoftColors.plainBackground,
                backgroundColor: Colors.redAccent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: const Text('Delete'),
            ),
          ],
        );
      },
    );
    if (confirmed == true && mounted) {
      try {
        await ref.read(savingsGoalProvider.notifier).deleteGoal(goal.id);
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Could not delete goal: $e'),
              backgroundColor: Colors.redAccent,
            ),
          );
        }
      }
    }
  }

  Future<void> _quickDeposit(SavingsGoalModel goal) async {
    final amountCtrl = TextEditingController(text: '1000');
    final rawAccounts =
        ref
            .read(userStateProvider)
            .accounts
            .where((a) => a.isActive && (a.isBank || a.isWallet))
            .toList();
    final dedupedAccounts = UserStateNotifier.deduplicate(rawAccounts);
    final seen = <String>{};
    final accounts = dedupedAccounts.where((a) => seen.add(a.name)).toList();
    String? selectedAccount = accounts.isNotEmpty ? accounts.first.name : null;
    bool deductFromBank = true;
    String? inlineError;

    final confirmed = await PremiumBottomSheet.show<bool>(
      context: context,
      child: StatefulBuilder(
        builder: (ctx, setModalState) {
          final tone = SoftTone(ctx);
          return Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: tone.mint,
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Center(
                        child: Text(
                          goal.icon ?? '🎯',
                          style: const TextStyle(fontSize: 22),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Deposit to ${goal.name}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: tone.text(18, FontWeight.w800, tone.ink),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            'Saved ₹${NumberFormat('#,##0').format(goal.savedAmount)} of ₹${NumberFormat('#,##0').format(goal.targetAmount)}',
                            style: tone.text(12, FontWeight.w500, tone.slate),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                TextField(
                  controller: amountCtrl,
                  keyboardType: const TextInputType.numberWithOptions(
                    decimal: true,
                  ),
                  style: tone.text(16, FontWeight.w700, tone.ink),
                  decoration: _softDialogInputDecoration(
                    'Amount to Add (₹)',
                    tone,
                  ).copyWith(errorText: inlineError),
                  onChanged: (_) {
                    if (inlineError != null)
                      setModalState(() => inlineError = null);
                  },
                ),
                const SizedBox(height: 10),
                Row(
                  children:
                      [500, 1000, 2000, 5000].map((preset) {
                        return Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: InkWell(
                            onTap: () {
                              setModalState(() {
                                amountCtrl.text = preset.toString();
                                inlineError = null;
                              });
                            },
                            borderRadius: BorderRadius.circular(10),
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 8,
                              ),
                              decoration: BoxDecoration(
                                color: tone.track,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(color: tone.border),
                              ),
                              child: Text(
                                '+₹$preset',
                                style: tone.text(
                                  12,
                                  FontWeight.w700,
                                  tone.slate,
                                ),
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                ),
                if (accounts.isNotEmpty) ...[
                  const SizedBox(height: 14),
                  DropdownButtonFormField<String>(
                    initialValue: selectedAccount,
                    dropdownColor: tone.card,
                    isExpanded: true,
                    decoration: _softDialogInputDecoration(
                      'Paid from Account',
                      tone,
                    ),
                    items:
                        accounts.map((a) {
                          return DropdownMenuItem(
                            value: a.name,
                            child: Text(
                              a.name,
                              style: tone.text(13, FontWeight.w600, tone.ink),
                            ),
                          );
                        }).toList(),
                    onChanged:
                        (val) => setModalState(() => selectedAccount = val),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Checkbox(
                        value: deductFromBank,
                        activeColor: SoftColors.control,
                        onChanged:
                            (val) => setModalState(
                              () => deductFromBank = val ?? true,
                            ),
                      ),
                      Expanded(
                        child: Text(
                          'Deduct from account balance',
                          style: tone.text(12, FontWeight.w600, tone.ink),
                        ),
                      ),
                    ],
                  ),
                ],
                const SizedBox(height: 18),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(ctx, false),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: tone.slate,
                          side: BorderSide(color: tone.border),
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                        child: const Text('Cancel'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton(
                        onPressed: () {
                          final a =
                              double.tryParse(
                                amountCtrl.text.replaceAll(',', '').trim(),
                              ) ??
                              0;
                          if (a <= 0) {
                            setModalState(
                              () => inlineError = 'Enter a valid amount',
                            );
                            return;
                          }
                          FocusScope.of(ctx).unfocus();
                          Navigator.pop(ctx, true);
                        },
                        style: FilledButton.styleFrom(
                          backgroundColor: SoftColors.control,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                        child: const Text('Deposit'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );

    final amount = parseAmountInput(amountCtrl.text) ?? 0;
    if (confirmed != true || !mounted || amount <= 0) return;

    try {
      String? txId;
      if (deductFromBank && selectedAccount != null) {
        final now = DateTime.now();
        final tx = model.Transaction(
          merchant: 'Savings: ${goal.name}',
          amount: amount,
          isExpense: true,
          time: DateFormat('hh:mm a').format(now),
          category: 'Settlements',
          account: selectedAccount!,
          purpose: defaultPurposeOf(ref.read(userStateProvider).purposeTypes),
          date: now,
          note: 'Quick deposit to savings goal "${goal.name}"',
        );
        ref.read(model.transactionProvider.notifier).addTransaction(tx);
        txId = tx.id;
      }
      // Atomic server-side add, linked to the bank transaction (deleting
      // that transaction reverses the deposit).
      await ref
          .read(savingsGoalProvider.notifier)
          .addFunds(goal.id, amount, transactionId: txId);
      if (mounted) {
        final tone = SoftTone(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Deposited ₹${NumberFormat('#,##0').format(amount)} to ${goal.name}! 💰',
            ),
            backgroundColor: tone.emeraldDeep,
            duration: const Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to deposit: $e'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
    }
  }

  Future<void> _showInvestmentModal({InvestmentHolding? existingHolding}) =>
      showInvestmentFormSheet(context, ref, existing: existingHolding);

  Future<void> _deleteHolding(InvestmentHolding holding) =>
      confirmDeleteInvestment(context, ref, holding);

  @override
  Widget build(BuildContext context) {
    final breakdown = _computeBreakdown();
    final goals =
        ref.watch(savingsGoalProvider).value ?? const <SavingsGoalModel>[];
    final holdings = ref.watch(investmentProvider);
    final portfolio = ref.read(investmentProvider.notifier).portfolio();
    final goalsSaved = goals.fold<double>(
      0,
      (sum, goal) => sum + goal.savedAmount,
    );
    final assetCount = holdings.length;
    // Same number as the breakdown (no double counting).
    final investmentShown = breakdown.investment;
    final totalWealthOnly = investmentShown + goalsSaved;
    final goalsTarget = goals.fold<double>(
      0,
      (sum, goal) => sum + goal.targetAmount,
    );

    final tone = SoftTone(context);
    final spark =
        ref
            .watch(dailySnapshotProvider)
            .history
            .reversed
            .map((row) => row.investmentValue)
            .toList();

    final chips = [
      ('Investments', _fmt(investmentShown), LucideIcons.trendingUp),
      ('Goals Saved', _fmt(goalsSaved), LucideIcons.flag),
      if (goalsTarget > 0)
        ('Goals Target', _fmt(goalsTarget), LucideIcons.target),
    ];

    return ListView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
      children: [
        SoftForestHero(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'TOTAL WEALTH',
                style: tone.text(
                  10,
                  FontWeight.w700,
                  Colors.white.withValues(alpha: 0.7),
                  letterSpacing: 0.6,
                ),
              ),
              const SizedBox(height: 8),
              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Expanded(
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.centerLeft,
                      child: Text(
                        _fmt(totalWealthOnly),
                        style: tone.text(
                          32,
                          FontWeight.w800,
                          Colors.white,
                          letterSpacing: -0.8,
                        ),
                      ),
                    ),
                  ),
                  if (spark.length >= 2) ...[
                    const SizedBox(width: 8),
                    SoftSparkline(
                      values:
                          spark.length <= 12
                              ? spark
                              : spark.sublist(spark.length - 12),
                    ),
                  ],
                ],
              ),
              const SizedBox(height: 4),
              Text(
                'Investments & Savings Goals',
                style: tone.text(
                  12,
                  FontWeight.w500,
                  Colors.white.withValues(alpha: 0.72),
                ),
              ),
              const SizedBox(height: 16),
              _ChipRows(chips: chips),
            ],
          ),
        ),
        const SizedBox(height: 20),
        Row(
          children: [
            Text(
              'Savings Goals',
              style: tone.text(
                20,
                FontWeight.w700,
                tone.ink,
                letterSpacing: -0.3,
              ),
            ),
            const SizedBox(width: 8),
            Text(
              '(${goals.length})',
              style: tone.text(14, FontWeight.w600, tone.slate),
            ),
            const Spacer(),
            InkWell(
              onTap: _createGoal,
              borderRadius: BorderRadius.circular(8),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                child: Text(
                  '+ Add',
                  style: tone.text(14, FontWeight.w700, tone.emeraldDeep),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        if (goals.isEmpty)
          _WealthEmptyState(
            asset: 'assets/images/goal_empty.png',
            title: 'Set a savings goal',
            description:
                'Pick a goal amount and track what you save toward it.',
            onTap: _createGoal,
          )
        else
          ...goals.map(
            (goal) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _GoalCard(
                goal: goal,
                saved: _fmt(goal.savedAmount),
                target: _fmt(goal.targetAmount),
                remaining: _fmt(
                  (goal.targetAmount - goal.savedAmount)
                      .clamp(0, double.infinity)
                      .toDouble(),
                ),
                meta: _goalMeta(goal),
                onDeposit: () => _quickDeposit(goal),
                onEdit: () => _showGoalModal(existingGoal: goal),
                onDelete: () => _deleteGoal(goal),
              ),
            ),
          ),
        if (goals.isNotEmpty)
          Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: _createGoal,
              borderRadius: BorderRadius.circular(24),
              child: Ink(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: tone.cardBox(),
                child: Text(
                  'Create Another Goal',
                  textAlign: TextAlign.center,
                  style: tone.text(14, FontWeight.w700, tone.emeraldDeep),
                ),
              ),
            ),
          ),
        const SizedBox(height: 20),
        Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Investments',
                    style: tone.text(
                      20,
                      FontWeight.w700,
                      tone.ink,
                      letterSpacing: -0.3,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    'Capital deployed directly',
                    style: tone.text(12, FontWeight.w500, tone.slate),
                  ),
                ],
              ),
            ),
            InkWell(
              onTap: () => _showInvestmentModal(),
              borderRadius: BorderRadius.circular(8),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                child: Text(
                  '+ Add',
                  style: tone.text(14, FontWeight.w700, tone.emeraldDeep),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        if (assetCount == 0 && investmentShown == 0)
          _WealthEmptyState(
            asset: 'assets/images/investment_empty.png',
            title: 'No investments yet',
            description:
                'Add an investment to see the capital you have put in.',
            onTap: () => _showInvestmentModal(),
          )
        else ...[
          SoftWealthCard(
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'CURRENT VALUE',
                        style: tone.text(
                          10,
                          FontWeight.w800,
                          tone.emeraldDeep,
                          letterSpacing: 0.5,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        _fmt(investmentShown),
                        style: tone.text(22, FontWeight.w800, tone.ink),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'Invested ${_fmt(portfolio.invested)} · '
                        '${portfolio.gain >= 0 ? '+' : ''}${portfolio.gainPercent.toStringAsFixed(1)}%',
                        style: tone.text(
                          11,
                          FontWeight.w600,
                          portfolio.gain >= 0
                              ? tone.emeraldDeep
                              : const Color(0xFFDC2626),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Flexible(
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: tone.mint,
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      'Active Portfolio · $assetCount ${assetCount == 1 ? 'Asset' : 'Assets'}',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: tone.text(11, FontWeight.w700, tone.emeraldDeep),
                    ),
                  ),
                ),
              ],
            ),
          ),
          for (final holding in holdings)
            _InvestmentCard(
              icon: _holdingIcon(holding.type),
              name: holding.name,
              subtitle:
                  '${_holdingLabel(holding.type)} · Invested ${_fmt(holding.investedAmount)}',
              amount: _fmt(holding.currentValue),
              growth: holding.investedAmount > 0 ? holding.gainPercent : null,
              onEdit: () => _showInvestmentModal(existingHolding: holding),
              onDelete: () => _deleteHolding(holding),
            ),
        ],
      ],
    );
  }

  String? _goalMeta(SavingsGoalModel goal) {
    if (goal.targetDate != null && goal.targetDate!.isNotEmpty) {
      try {
        final d = DateTime.parse(goal.targetDate!);
        return 'Target: ${DateFormat('MMM yyyy').format(d)}';
      } catch (_) {
        return 'Target: ${goal.targetDate}';
      }
    }
    final monthly = goal.monthlyContribution;
    if (monthly != null && monthly > 0) {
      return '${_fmt(monthly)} / month';
    }
    final raw = goal.createdAt;
    if (raw == null || raw.isEmpty) return 'Any time · Flexible';
    final parsed = DateTime.tryParse(raw);
    if (parsed == null) return 'Any time · Flexible';
    return 'Started ${DateFormat('d MMM yyyy').format(parsed.toLocal())}';
  }
}

InputDecoration _softDialogInputDecoration(String label, SoftTone tone) {
  final outline = OutlineInputBorder(
    borderRadius: BorderRadius.circular(14),
    borderSide: BorderSide(color: tone.border),
  );
  return InputDecoration(
    labelText: label,
    labelStyle: tone.text(13, FontWeight.w600, tone.slate),
    filled: true,
    fillColor: tone.track,
    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
    enabledBorder: outline,
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: BorderSide(color: tone.emerald, width: 1.5),
    ),
  );
}

class _ChipRows extends StatelessWidget {
  const _ChipRows({required this.chips});

  final List<(String, String, IconData)> chips;

  @override
  Widget build(BuildContext context) {
    final rows = <Widget>[];
    for (var i = 0; i < chips.length; i += 2) {
      final right = i + 1 < chips.length ? chips[i + 1] : null;
      rows.add(
        Padding(
          padding: EdgeInsets.only(top: i == 0 ? 0 : 8),
          child: Row(
            children: [
              Expanded(child: _BalanceChip(chip: chips[i])),
              const SizedBox(width: 8),
              Expanded(
                child:
                    right == null
                        ? const SizedBox.shrink()
                        : _BalanceChip(chip: right),
              ),
            ],
          ),
        ),
      );
    }
    return Column(children: rows);
  }
}

class _BalanceChip extends StatelessWidget {
  const _BalanceChip({required this.chip});

  final (String, String, IconData) chip;

  @override
  Widget build(BuildContext context) {
    return SoftHeroMiniTile(label: chip.$1, value: chip.$2, icon: chip.$3);
  }
}

class _WealthEmptyState extends StatelessWidget {
  const _WealthEmptyState({
    required this.asset,
    required this.title,
    required this.description,
    this.onTap,
  });

  final String asset;
  final String title;
  final String description;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final tone = SoftTone(context);
    return SoftWealthCard(
      onTap: onTap,
      child: Column(
        children: [
          Image.asset(asset, height: 156, fit: BoxFit.contain),
          const SizedBox(height: 8),
          Text(
            title,
            textAlign: TextAlign.center,
            style: tone.text(16, FontWeight.w800, tone.ink),
          ),
          const SizedBox(height: 6),
          Text(
            description,
            textAlign: TextAlign.center,
            style: tone.text(13, FontWeight.w500, tone.slate),
          ),
        ],
      ),
    );
  }
}

class _GoalCard extends StatelessWidget {
  const _GoalCard({
    required this.goal,
    required this.saved,
    required this.target,
    required this.remaining,
    required this.meta,
    required this.onDeposit,
    this.onEdit,
    this.onDelete,
  });

  final SavingsGoalModel goal;
  final String saved;
  final String target;
  final String remaining;
  final String? meta;
  final VoidCallback onDeposit;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;

  @override
  Widget build(BuildContext context) {
    final tone = SoftTone(context);
    final percent = (goal.progressPercentage * 100).round();
    final progress = goal.progressPercentage.clamp(0.0, 1.0).toDouble();
    final accent = _goalColor(goal.color, tone);
    final isDone = goal.isCompleted;

    return SoftWealthCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: accent.withValues(alpha: 0.14),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Center(
                  child: Text(
                    goal.icon?.isNotEmpty == true ? goal.icon! : '🎯',
                    style: const TextStyle(fontSize: 22),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      goal.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: tone.text(15, FontWeight.w700, tone.ink),
                    ),
                    if (meta != null) ...[
                      const SizedBox(height: 3),
                      Text(
                        meta!,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: tone.text(12, FontWeight.w500, tone.slate),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: accent.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  '$percent%',
                  style: tone.text(11, FontWeight.w700, accent),
                ),
              ),
              if (onEdit != null || onDelete != null) ...[
                const SizedBox(width: 4),
                if (onEdit != null)
                  InkWell(
                    onTap: onEdit,
                    borderRadius: BorderRadius.circular(8),
                    child: Padding(
                      padding: const EdgeInsets.all(6),
                      child: Icon(
                        LucideIcons.pencil,
                        size: 15,
                        color: tone.slate,
                      ),
                    ),
                  ),
                if (onDelete != null)
                  InkWell(
                    onTap: onDelete,
                    borderRadius: BorderRadius.circular(8),
                    child: const Padding(
                      padding: EdgeInsets.all(6),
                      child: Icon(
                        LucideIcons.trash2,
                        size: 15,
                        color: Colors.redAccent,
                      ),
                    ),
                  ),
              ],
            ],
          ),
          const SizedBox(height: 12),
          Text(saved, style: tone.text(18, FontWeight.w800, tone.ink)),
          const SizedBox(height: 2),
          Text('of $target', style: tone.text(12, FontWeight.w500, tone.slate)),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(99),
            child: LinearProgressIndicator(
              value: progress,
              minHeight: 6,
              backgroundColor: accent.withValues(alpha: 0.15),
              color: accent,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child:
                    isDone
                        ? Row(
                          children: [
                            Icon(
                              LucideIcons.checkCircle2,
                              size: 14,
                              color: tone.emeraldDeep,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              'Target Achieved! 🎉',
                              style: tone.text(
                                12,
                                FontWeight.w700,
                                tone.emeraldDeep,
                              ),
                            ),
                          ],
                        )
                        : Text(
                          '$remaining remaining',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: tone.text(12, FontWeight.w500, tone.slate),
                        ),
              ),
              InkWell(
                onTap: onDeposit,
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    vertical: 2,
                    horizontal: 4,
                  ),
                  child: Text(
                    '+ Quick Deposit',
                    style: tone.text(12, FontWeight.w700, tone.emeraldDeep),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _InvestmentCard extends StatelessWidget {
  const _InvestmentCard({
    required this.icon,
    required this.name,
    required this.subtitle,
    required this.amount,
    this.growth,
    this.onEdit,
    this.onDelete,
  });

  final IconData icon;
  final String name;
  final String subtitle;
  final String amount;
  final double? growth;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;

  @override
  Widget build(BuildContext context) {
    final tone = SoftTone(context);
    final growthText =
        growth == null
            ? null
            : '${growth! > 0 ? '+' : ''}${growth!.toStringAsFixed(1)}%';
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: SoftWealthCard(
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: tone.mint,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, color: tone.emeraldDeep, size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: tone.text(15, FontWeight.w700, tone.ink),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: tone.text(12, FontWeight.w500, tone.slate),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(amount, style: tone.text(16, FontWeight.w800, tone.ink)),
                if (growthText != null)
                  Text(
                    growthText,
                    style: tone.text(
                      12,
                      FontWeight.w700,
                      growth! < 0 ? const Color(0xFFDC2626) : tone.emeraldDeep,
                    ),
                  ),
              ],
            ),
            if (onEdit != null && onDelete != null) ...[
              const SizedBox(width: 2),
              InvestmentCardMenu(onEdit: onEdit!, onDelete: onDelete!),
            ],
          ],
        ),
      ),
    );
  }
}

String _holdingLabel(InvestmentType type) {
  switch (type) {
    case InvestmentType.liquid:
      return 'Liquid';
    case InvestmentType.mutualFund:
      return 'Mutual fund';
    case InvestmentType.fixedDeposit:
      return 'Fixed deposit';
    case InvestmentType.stocks:
      return 'Stocks';
    case InvestmentType.bonds:
      return 'Bonds';
    case InvestmentType.crypto:
      return 'Crypto';
    case InvestmentType.gold:
      return 'Gold';
    case InvestmentType.realEstate:
      return 'Real estate';
    case InvestmentType.other:
      return 'Investment';
  }
}

IconData _holdingIcon(InvestmentType type) {
  switch (type) {
    case InvestmentType.mutualFund:
    case InvestmentType.stocks:
      return Icons.trending_up_rounded;
    case InvestmentType.fixedDeposit:
    case InvestmentType.bonds:
      return Icons.account_balance_outlined;
    case InvestmentType.gold:
      return Icons.workspace_premium_outlined;
    case InvestmentType.realEstate:
      return Icons.home_outlined;
    case InvestmentType.crypto:
      return Icons.currency_bitcoin;
    case InvestmentType.liquid:
    case InvestmentType.other:
      return Icons.pie_chart_outline_rounded;
  }
}

/// Bounds for the goal-deadline picker (date-only). firstDate is the earlier
/// of the saved deadline and today, so editing an overdue goal never trips
/// showDatePicker's initialDate >= firstDate assertion.
({DateTime first, DateTime initial, DateTime last}) goalDeadlinePickerRange(
  DateTime? saved, {
  DateTime? now,
}) {
  final n = now ?? DateTime.now();
  final today = DateTime(n.year, n.month, n.day);
  final savedDay =
      saved == null ? null : DateTime(saved.year, saved.month, saved.day);
  final first = savedDay != null && savedDay.isBefore(today) ? savedDay : today;
  var last = today.add(const Duration(days: 3650));
  if (savedDay != null && savedDay.isAfter(last)) last = savedDay;
  var initial = savedDay ?? today;
  if (initial.isBefore(first)) initial = first;
  if (initial.isAfter(last)) initial = last;
  return (first: first, initial: initial, last: last);
}
