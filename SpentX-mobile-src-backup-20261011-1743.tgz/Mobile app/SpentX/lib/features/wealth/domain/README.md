# wealth domain — net-worth / snapshot entities
