import 'dart:convert';
import 'dart:io';

import 'package:csv/csv.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:intl/intl.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../../../core/providers/transaction_provider.dart' as model;
import '../data/backup_builder.dart';
import 'widgets/soft_export_widgets.dart';

/// Export & Backup — real implementation.
/// - CSV export of the full transaction ledger (spreadsheet-friendly)
/// - JSON full backup (versioned, see BackupBuilder): ledger, accounts,
///   budgets, investments, goals, plans, friends, outings, recurring, prefs
/// Both are written to a temp file and handed to the system share sheet.
class ExportScreen extends ConsumerStatefulWidget {
  const ExportScreen({super.key});

  @override
  ConsumerState<ExportScreen> createState() => _ExportScreenState();
}

class _ExportScreenState extends ConsumerState<ExportScreen> {
  static const _lastExportKey = 'last_export_at';
  bool _busy = false;

  String _dateRangePreset = 'all'; // 'all', 'month', 'custom'
  DateTimeRange? _customDateRange;

  String? _lastExportLabel() {
    try {
      final raw = Hive.box('settings').get(_lastExportKey)?.toString();
      if (raw == null) return null;
      final at = DateTime.tryParse(raw);
      if (at == null) return null;
      final now = DateTime.now();
      final sameDay =
          at.year == now.year && at.month == now.month && at.day == now.day;
      final day = sameDay ? 'Today' : DateFormat('d MMM yyyy').format(at);
      return '$day, ${DateFormat('h:mm a').format(at)}';
    } catch (_) {
      return null;
    }
  }

  Future<void> _recordExport() async {
    try {
      await Hive.box(
        'settings',
      ).put(_lastExportKey, DateTime.now().toIso8601String());
    } catch (_) {}
    if (mounted) setState(() {});
  }

  Future<File> _writeTempFile(String name, String content) async {
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/$name');
    await file.writeAsString(content);
    return file;
  }

  List<dynamic> _getFilteredTransactions() {
    final all = ref.read(model.transactionProvider);
    if (_dateRangePreset == 'all') return all;
    if (_dateRangePreset == 'month') {
      final now = DateTime.now();
      return all
          .where((t) => t.date.year == now.year && t.date.month == now.month)
          .toList();
    }
    if (_dateRangePreset == 'custom' && _customDateRange != null) {
      final start = DateTime(
        _customDateRange!.start.year,
        _customDateRange!.start.month,
        _customDateRange!.start.day,
      );
      final end = DateTime(
        _customDateRange!.end.year,
        _customDateRange!.end.month,
        _customDateRange!.end.day,
        23,
        59,
        59,
      );
      return all
          .where((t) => !t.date.isBefore(start) && !t.date.isAfter(end))
          .toList();
    }
    return all;
  }

  String _dateRangeSubtitle() {
    if (_dateRangePreset == 'all') return 'All dates';
    if (_dateRangePreset == 'month') {
      return DateFormat('MMMM yyyy').format(DateTime.now());
    }
    if (_dateRangePreset == 'custom' && _customDateRange != null) {
      final s = DateFormat('d MMM yyyy').format(_customDateRange!.start);
      final e = DateFormat('d MMM yyyy').format(_customDateRange!.end);
      return '$s – $e';
    }
    return 'Custom range';
  }

  Future<void> _pickCustomRange() async {
    final now = DateTime.now();
    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime(now.year + 2),
      initialDateRange:
          _customDateRange ??
          DateTimeRange(start: DateTime(now.year, now.month, 1), end: now),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: Theme.of(context).colorScheme.copyWith(
              primary: SoftExportTone.emeraldDeep(context),
              onPrimary: Colors.white,
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null) {
      setState(() {
        _customDateRange = picked;
        _dateRangePreset = 'custom';
      });
    }
  }

  Future<void> _exportCsv() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final txs = _getFilteredTransactions();
      if (txs.isEmpty) {
        _toast('No transactions match the selected date range.');
        return;
      }
      final rows = <List<dynamic>>[
        [
          'Date',
          'Time',
          'Merchant',
          'Category',
          'Purpose',
          'Account',
          'Amount',
          'Type',
          'Payment Mode',
          'Transfer',
          'Auto-Detected',
          'Bank',
          'Account Last4',
          'Reference ID',
          'UPI ID',
          'Note',
        ],
        ...txs.map(
          (t) => [
            DateFormat('yyyy-MM-dd').format(t.date),
            DateFormat('HH:mm').format(t.date),
            t.merchant,
            t.category,
            t.purpose ?? '',
            t.account,
            t.isExpense ? -t.amount : t.amount,
            t.isTransfer ? 'Transfer' : (t.isExpense ? 'Expense' : 'Income'),
            t.paymentType,
            t.isTransfer ? 'Yes' : 'No',
            t.isAutoDetected ? 'Yes' : 'No',
            t.bankName,
            t.accountLast4,
            t.referenceId,
            t.upiId,
            t.note,
          ],
        ),
      ];
      final csv = const ListToCsvConverter().convert(rows);
      final stamp = DateFormat('yyyyMMdd_HHmm').format(DateTime.now());
      final file = await _writeTempFile('spentx_transactions_$stamp.csv', csv);
      try {
        final result = await SharePlus.instance.share(
          ShareParams(
            files: [XFile(file.path, mimeType: 'text/csv')],
            subject: 'SpentX transactions export',
          ),
        );
        // Cancelled share sheet is not an export.
        if (result.status != ShareResultStatus.dismissed) {
          await _recordExport();
        }
      } finally {
        try {
          if (await file.exists()) await file.delete();
        } catch (_) {}
      }
    } catch (e) {
      _toast('Export failed: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _exportJson() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final txs = ref.read(model.transactionProvider);
      final backup = BackupBuilder.build(
        transactions: [
          for (final t in txs) Map<String, dynamic>.from(t.toJson()),
        ],
      );
      final pretty = const JsonEncoder.withIndent('  ').convert(backup);
      final stamp = DateFormat('yyyyMMdd_HHmm').format(DateTime.now());
      final file = await _writeTempFile('spentx_backup_$stamp.json', pretty);
      try {
        final result = await SharePlus.instance.share(
          ShareParams(
            files: [XFile(file.path, mimeType: 'application/json')],
            subject: 'SpentX data backup',
          ),
        );
        if (result.status != ShareResultStatus.dismissed) {
          await _recordExport();
        }
      } finally {
        try {
          if (await file.exists()) await file.delete();
        } catch (_) {}
      }
    } catch (e) {
      _toast('Backup failed: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    final txCount = ref.watch(model.transactionProvider).length;
    final lastExport = _lastExportLabel();
    final ink = SoftExportTone.ink(context);
    final slate = SoftExportTone.slate(context);
    final muted = SoftExportTone.muted(context);

    return Scaffold(
      backgroundColor: SoftExportTone.canvas(context),
      appBar: AppBar(
        backgroundColor: SoftExportTone.canvas(context),
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        leadingWidth: 56,
        leading: Padding(
          padding: const EdgeInsets.only(left: 8),
          child: Center(
            child: SoftExportBackButton(
              onPressed: () => Navigator.maybePop(context),
            ),
          ),
        ),
        title: Text(
          'Export & Backup',
          style: SoftExportTone.text(
            context,
            fontSize: 18,
            fontWeight: FontWeight.w700,
            letterSpacing: -0.3,
            color: ink,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 12),
            SoftExportCard(
              radius: 26,
              child: Row(
                children: [
                  SoftExportIconSquare(
                    icon:
                        lastExport == null
                            ? LucideIcons.info
                            : LucideIcons.checkCircle,
                    size: 48,
                    iconSize: 22,
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Last Export',
                          style: SoftExportTone.text(
                            context,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: slate,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          lastExport ??
                              'Never — $txCount transactions ready to export',
                          style: SoftExportTone.text(
                            context,
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                            color: ink,
                            height: 1.3,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            const SoftExportSectionLabel('DATE RANGE'),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _dateRangePreset = 'all'),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      decoration: BoxDecoration(
                        color:
                            _dateRangePreset == 'all'
                                ? SoftExportTone.emerald(
                                  context,
                                ).withValues(alpha: 0.15)
                                : SoftExportTone.card(context),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color:
                              _dateRangePreset == 'all'
                                  ? SoftExportTone.emeraldDeep(context)
                                  : SoftExportTone.border(context),
                        ),
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        'All Dates',
                        style: SoftExportTone.text(
                          context,
                          fontSize: 12.5,
                          fontWeight: FontWeight.w600,
                          color:
                              _dateRangePreset == 'all'
                                  ? SoftExportTone.emeraldDeep(context)
                                  : slate,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _dateRangePreset = 'month'),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      decoration: BoxDecoration(
                        color:
                            _dateRangePreset == 'month'
                                ? SoftExportTone.emerald(
                                  context,
                                ).withValues(alpha: 0.15)
                                : SoftExportTone.card(context),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color:
                              _dateRangePreset == 'month'
                                  ? SoftExportTone.emeraldDeep(context)
                                  : SoftExportTone.border(context),
                        ),
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        'This Month',
                        style: SoftExportTone.text(
                          context,
                          fontSize: 12.5,
                          fontWeight: FontWeight.w600,
                          color:
                              _dateRangePreset == 'month'
                                  ? SoftExportTone.emeraldDeep(context)
                                  : slate,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: GestureDetector(
                    onTap: _pickCustomRange,
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      decoration: BoxDecoration(
                        color:
                            _dateRangePreset == 'custom'
                                ? SoftExportTone.emerald(
                                  context,
                                ).withValues(alpha: 0.15)
                                : SoftExportTone.card(context),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color:
                              _dateRangePreset == 'custom'
                                  ? SoftExportTone.emeraldDeep(context)
                                  : SoftExportTone.border(context),
                        ),
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        _dateRangePreset == 'custom' && _customDateRange != null
                            ? 'Custom Range'
                            : 'Pick Dates',
                        style: SoftExportTone.text(
                          context,
                          fontSize: 12.5,
                          fontWeight: FontWeight.w600,
                          color:
                              _dateRangePreset == 'custom'
                                  ? SoftExportTone.emeraldDeep(context)
                                  : slate,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              'Selected: ${_dateRangeSubtitle()} (${_getFilteredTransactions().length} records)',
              style: SoftExportTone.text(
                context,
                fontSize: 12,
                fontWeight: FontWeight.w500,
                color: slate,
              ),
            ),
            const SizedBox(height: 24),
            const SoftExportSectionLabel('EXPORT FORMAT'),
            const SizedBox(height: 14),
            _ActionTile(
              icon: LucideIcons.fileSpreadsheet,
              title: 'Export to Excel / CSV (.csv)',
              subtitle:
                  'Compatible with Microsoft Excel, Google Sheets, Numbers',
              isHighlighted: true,
              onTap: _exportCsv,
            ),
            const SizedBox(height: 10),
            _ActionTile(
              icon: LucideIcons.fileJson,
              title: 'Export as JSON Backup',
              subtitle:
                  'Full backup — transactions, accounts, budgets, investments',
              onTap: _exportJson,
            ),
            const SizedBox(height: 16),
            Text(
              'Files are shared through the system share sheet — save to Drive, send to WhatsApp/Gmail, or keep in Files.',
              style: SoftExportTone.text(
                context,
                fontSize: 12.5,
                fontWeight: FontWeight.w500,
                color: muted,
                height: 1.45,
              ),
            ),

            const SizedBox(height: 80),
          ],
        ),
      ),
    );
  }
}

class _ActionTile extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  final bool isHighlighted;
  final VoidCallback onTap;

  const _ActionTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.isHighlighted = false,
  });

  @override
  Widget build(BuildContext context) {
    return SoftExportCard(
      padding: const EdgeInsets.all(16),
      borderColor: isHighlighted ? SoftExportTone.mintDeep(context) : null,
      onTap: onTap,
      child: Row(
        children: [
          SoftExportIconSquare(icon: icon, emphasized: isHighlighted),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: SoftExportTone.text(
                    context,
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -0.2,
                    color: SoftExportTone.ink(context),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: SoftExportTone.text(
                    context,
                    fontSize: 12.5,
                    fontWeight: FontWeight.w500,
                    color: SoftExportTone.slate(context),
                    height: 1.35,
                  ),
                ),
              ],
            ),
          ),
          Icon(
            LucideIcons.chevronRight,
            size: 18,
            color: SoftExportTone.muted(context),
          ),
        ],
      ),
    );
  }
}
