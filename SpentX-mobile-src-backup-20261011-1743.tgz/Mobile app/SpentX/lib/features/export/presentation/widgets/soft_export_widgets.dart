import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../core/theme/soft_palette.dart';

/// Home Soft Soft tokens for Export & Backup.
///
/// Light values are the Home match. Dark mode keeps the same shapes and
/// swaps only the surfaces so the screen stays readable.
abstract final class SoftExportTone {
  static bool _dark(BuildContext context) =>
      Theme.of(context).brightness == Brightness.dark;

  static Color canvas(BuildContext context) =>
      _dark(context) ? SoftPalette.darkBg : const Color(0xFFF8FAFC);

  static Color card(BuildContext context) =>
      _dark(context) ? SoftPalette.darkCard : const Color(0xFFFFFFFF);

  static Color border(BuildContext context) =>
      _dark(context) ? SoftPalette.darkBorder : const Color(0xFFF1F5F9);

  static Color ink(BuildContext context) =>
      _dark(context) ? SoftPalette.darkInk : const Color(0xFF0F172A);

  static Color slate(BuildContext context) =>
      _dark(context) ? SoftPalette.darkMuted : const Color(0xFF64748B);

  static Color muted(BuildContext context) =>
      _dark(context) ? SoftPalette.darkFaint : const Color(0xFF94A3B8);

  static Color emerald(BuildContext context) =>
      _dark(context) ? SoftPalette.darkEmerald : const Color(0xFF10B981);

  static Color emeraldDeep(BuildContext context) =>
      _dark(context) ? SoftPalette.darkEmerald : const Color(0xFF059669);

  static Color mint(BuildContext context) =>
      _dark(context) ? SoftPalette.darkEmeraldSoft : const Color(0xFFECFDF5);

  static Color mintDeep(BuildContext context) =>
      _dark(context)
          ? SoftPalette.darkEmerald.withValues(alpha: 0.35)
          : const Color(0xFFD1FAE5);

  /// `0 4px 16px -2px rgba(15,23,42,0.04)`
  static const shadow = [
    BoxShadow(
      color: Color.fromRGBO(15, 23, 42, 0.04),
      offset: Offset(0, 4),
      blurRadius: 16,
      spreadRadius: -2,
    ),
  ];

  static TextStyle text(
    BuildContext context, {
    required double fontSize,
    FontWeight fontWeight = FontWeight.w500,
    Color? color,
    double? letterSpacing,
    double? height,
  }) {
    return GoogleFonts.plusJakartaSans(
      fontSize: fontSize,
      fontWeight: fontWeight,
      color: color ?? ink(context),
      letterSpacing: letterSpacing,
      height: height,
    );
  }
}

class SoftExportBackButton extends StatelessWidget {
  const SoftExportBackButton({
    super.key,
    required this.onPressed,
    this.tooltip = 'Back',
  });

  final VoidCallback onPressed;
  final String tooltip;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final btn = Material(
      color: SoftExportTone.card(context),
      shape: const CircleBorder(),
      elevation: 0,
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onPressed,
        child: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: SoftExportTone.card(context),
            border: Border.all(color: SoftExportTone.border(context)),
            boxShadow: isDark ? null : SoftExportTone.shadow,
          ),
          child: Icon(
            Icons.arrow_back_ios_new_rounded,
            size: 16,
            color: SoftExportTone.ink(context),
          ),
        ),
      ),
    );
    return Tooltip(message: tooltip, child: btn);
  }
}

class SoftExportSectionLabel extends StatelessWidget {
  const SoftExportSectionLabel(this.title, {super.key});

  final String title;

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: SoftExportTone.text(
        context,
        fontSize: 11,
        fontWeight: FontWeight.w700,
        color: SoftExportTone.slate(context),
        letterSpacing: 1.2,
      ),
    );
  }
}

/// Pale mint rounded square used for export icons.
class SoftExportIconSquare extends StatelessWidget {
  const SoftExportIconSquare({
    super.key,
    required this.icon,
    this.emphasized = false,
    this.size = 44,
    this.iconSize = 20,
  });

  final IconData icon;
  final bool emphasized;
  final double size;
  final double iconSize;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color:
            emphasized
                ? SoftExportTone.mintDeep(context)
                : SoftExportTone.mint(context),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Icon(
        icon,
        size: iconSize,
        color:
            emphasized
                ? SoftExportTone.emeraldDeep(context)
                : SoftExportTone.emerald(context),
      ),
    );
  }
}

class SoftExportCard extends StatelessWidget {
  const SoftExportCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.borderColor,
    this.highlighted = false,
    this.onTap,
    this.radius = 24,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color? borderColor;
  final bool highlighted;
  final VoidCallback? onTap;
  final double radius;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final border =
        borderColor ??
        (highlighted
            ? SoftExportTone.mintDeep(context)
            : SoftExportTone.border(context));
    final card = Container(
      padding: padding,
      decoration: BoxDecoration(
        color: SoftExportTone.card(context),
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: border),
        boxShadow: isDark ? null : SoftExportTone.shadow,
      ),
      child: child,
    );
    if (onTap == null) return card;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(radius),
        splashColor: SoftExportTone.mint(context),
        highlightColor: SoftExportTone.mint(context).withValues(alpha: 0.65),
        child: card,
      ),
    );
  }
}
