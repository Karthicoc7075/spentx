import 'package:hive_flutter/hive_flutter.dart';

import '../../investments/data/investment_service.dart';
import '../../recurring/data/recurring_bill_service.dart';
import '../../wealth/data/savings_goal_service.dart';

/// Builds the JSON full backup.
///
/// Format versions:
/// - v1 (no `version` key): transactions, accounts, purposeTypes, budgets,
///   investments (legacy holdings list).
/// - v2 (`version: 2`): every v1 key kept at the same place (old readers keep
///   working; `investments` now holds rows from InvestmentService), plus
///   savingsGoals, monthlyPlans, friends, friendUpiLinks, friendSplits,
///   outings, recurringBills and non-secret appPreferences.
///
/// There is no in-app restore yet; [normalize] is the tolerant reader a
/// future restore must use (accepts v1 and v2).
abstract final class BackupBuilder {
  static const version = 2;

  static final _secretKey = RegExp(
    r'pin|pass|token|secret|key|hash|salt|session|auth|jwt|otp|credential|'
    r'biometric|fingerprint|cipher|encrypt|private|refresh|cookie',
    caseSensitive: false,
  );

  /// Keys never exported as preferences (secrets, or data exported elsewhere).
  static bool isSecretOrInternalKey(String key) {
    if (key.contains(':')) return true; // per-user stores / outboxes
    if (_secretKey.hasMatch(key)) return true;
    const exportedElsewhere = {
      'onboardingAccounts',
      'purposeTypes',
      'contributors',
      'last_export_at',
    };
    return exportedElsewhere.contains(key);
  }

  /// Only simple, readable preference values (no blobs / nested stores).
  static bool isPreferenceValue(Object? v) {
    if (v is bool || v is num) return true;
    if (v is String) return v.length <= 500;
    if (v is List) return v.length <= 50 && v.every((e) => e is String);
    return false;
  }

  static Map<String, dynamic> preferencesFrom(Map<dynamic, dynamic> raw) {
    final out = <String, dynamic>{};
    raw.forEach((k, v) {
      final key = k.toString();
      if (isSecretOrInternalKey(key) || !isPreferenceValue(v)) return;
      out[key] = v;
    });
    return out;
  }

  /// Converts Hive values (DateTime, nested maps…) into
  /// something JsonEncoder accepts.
  static Object? jsonSafe(Object? v) {
    if (v == null || v is bool || v is num || v is String) {
      if (v is double && !v.isFinite) return null;
      return v;
    }
    if (v is DateTime) return v.toIso8601String();
    if (v is Map) {
      return {for (final e in v.entries) e.key.toString(): jsonSafe(e.value)};
    }
    if (v is Iterable) return [for (final e in v) jsonSafe(e)];
    return v.toString();
  }

  static Object? _boxGet(String box, String key, Object fallback) =>
      Hive.isBoxOpen(box)
          ? Hive.box(box).get(key, defaultValue: fallback)
          : fallback;

  static List<Object?> _boxValues(
    String box, {
    Set<String> skipKeys = const {},
  }) {
    if (!Hive.isBoxOpen(box)) return const [];
    final b = Hive.box(box);
    return [
      for (final k in b.keys)
        if (!skipKeys.contains(k.toString()) && b.get(k) is Map) b.get(k),
    ];
  }

  static Map<String, dynamic> build({
    required List<Map<String, dynamic>> transactions,
    DateTime? now,
  }) {
    final settingsOpen = Hive.isBoxOpen('settings');
    final settings = settingsOpen ? Hive.box('settings') : null;
    final legacyHoldings = _boxGet(
      'investments',
      'holdings',
      const <dynamic>[],
    );
    final backup = <String, dynamic>{
      'app': 'SpentX',
      'version': version,
      'exportedAt': (now ?? DateTime.now()).toIso8601String(),
      // ── v1 keys (unchanged positions) ──
      'transactions': transactions,
      'accounts': settings?.get('onboardingAccounts') ?? const [],
      'purposeTypes': settings?.get('purposeTypes') ?? const [],
      'budgets': _boxGet('budgets', 'list', const <dynamic>[]),
      'investments': InvestmentService.cachedRows(),
      // ── v2 additions ──
      if (legacyHoldings is List && legacyHoldings.isNotEmpty)
        'legacyHoldings': legacyHoldings,
      'savingsGoals': [
        for (final g in SavingsGoalService.cachedGoals()) g.toMap(),
      ],
      'monthlyPlans': _boxGet('monthly_plans', 'list', const <dynamic>[]),
      'friends': _boxGet('friends', 'list', const <dynamic>[]),
      'friendUpiLinks': _boxGet('friends', 'friend_upi_links', const {}),
      'friendSplits': _boxValues('friend_splits'),
      // Outings are stored one per key (members/expenses/settlements inline).
      'outings': _boxValues('outings', skipKeys: const {'list'}),
      'outingCategories': settings?.get('outing_categories') ?? const [],
      'recurringBills': RecurringBillService.cachedBills(),
      'appPreferences':
          settings == null ? const {} : preferencesFrom(settings.toMap()),
    };
    return jsonSafe(backup) as Map<String, dynamic>;
  }

  /// Tolerant reader for v1 and v2 backups (for a future restore).
  static Map<String, dynamic> normalize(Map<String, dynamic> raw) {
    final v = (raw['version'] as num?)?.toInt() ?? 1;
    List<dynamic> list(String k) => raw[k] is List ? raw[k] as List : const [];
    return {
      'version': v,
      'transactions': list('transactions'),
      'accounts': list('accounts'),
      'purposeTypes': list('purposeTypes'),
      'budgets': list('budgets'),
      // v1 "investments" was the legacy holdings list.
      'investments': v >= 2 ? list('investments') : const [],
      'legacyHoldings': v >= 2 ? list('legacyHoldings') : list('investments'),
      'savingsGoals': list('savingsGoals'),
      'monthlyPlans': list('monthlyPlans'),
      'friends': list('friends'),
      'friendUpiLinks':
          raw['friendUpiLinks'] is Map ? raw['friendUpiLinks'] : const {},
      'friendSplits': list('friendSplits'),
      'outings': list('outings'),
      'outingCategories': list('outingCategories'),
      'recurringBills': list('recurringBills'),
      'appPreferences':
          raw['appPreferences'] is Map ? raw['appPreferences'] : const {},
    };
  }
}
