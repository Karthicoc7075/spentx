import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/theme/soft_palette.dart';

/// Home Soft Soft tokens for Calendar.
///
/// Light values match Home. Dark mode keeps the same shapes and swaps surfaces.
abstract final class SoftCalendarTone {
  static bool _dark(BuildContext context) =>
      Theme.of(context).brightness == Brightness.dark;

  static Color canvas(BuildContext context) =>
      _dark(context) ? SoftPalette.darkBg : const Color(0xFFF8FAFC);

  static Color card(BuildContext context) =>
      _dark(context) ? SoftPalette.darkCard : const Color(0xFFFFFFFF);

  static Color border(BuildContext context) =>
      _dark(context) ? SoftPalette.darkBorder : const Color(0xFFF1F5F9);

  static Color ink(BuildContext context) =>
      _dark(context) ? SoftPalette.darkInk : const Color(0xFF0F172A);

  static Color slate(BuildContext context) =>
      _dark(context) ? SoftPalette.darkMuted : const Color(0xFF64748B);

  static Color muted(BuildContext context) =>
      _dark(context) ? SoftPalette.darkFaint : const Color(0xFF94A3B8);

  static Color emerald(BuildContext context) =>
      _dark(context) ? SoftPalette.darkEmerald : const Color(0xFF10B981);

  static Color emeraldDeep(BuildContext context) =>
      _dark(context) ? SoftPalette.darkEmerald : const Color(0xFF059669);

  static Color mint(BuildContext context) =>
      _dark(context) ? SoftPalette.darkEmeraldSoft : const Color(0xFFECFDF5);

  static Color mintDeep(BuildContext context) =>
      _dark(context)
          ? SoftPalette.darkEmerald.withValues(alpha: 0.35)
          : const Color(0xFFD1FAE5);

  static Color rose(BuildContext context) =>
      _dark(context) ? const Color(0xFFFB7185) : const Color(0xFFE11D48);

  /// `0 4px 16px -2px rgba(15,23,42,0.04)`
  static const shadow = [
    BoxShadow(
      color: Color.fromRGBO(15, 23, 42, 0.04),
      offset: Offset(0, 4),
      blurRadius: 16,
      spreadRadius: -2,
    ),
  ];

  static TextStyle text(
    BuildContext context, {
    required double fontSize,
    FontWeight fontWeight = FontWeight.w500,
    Color? color,
    double? letterSpacing,
    double? height,
  }) {
    return GoogleFonts.plusJakartaSans(
      fontSize: fontSize,
      fontWeight: fontWeight,
      color: color ?? ink(context),
      letterSpacing: letterSpacing,
      height: height,
    );
  }
}

class SoftCalendarIconButton extends StatelessWidget {
  const SoftCalendarIconButton({
    super.key,
    required this.icon,
    required this.onPressed,
    this.tooltip,
    this.iconSize = 18,
  });

  final IconData icon;
  final VoidCallback onPressed;
  final String? tooltip;
  final double iconSize;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final btn = Material(
      color: SoftCalendarTone.card(context),
      shape: const CircleBorder(),
      elevation: 0,
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onPressed,
        splashColor: SoftCalendarTone.mint(context),
        child: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: SoftCalendarTone.card(context),
            border: Border.all(color: SoftCalendarTone.border(context)),
            boxShadow: isDark ? null : SoftCalendarTone.shadow,
          ),
          child: Icon(
            icon,
            size: iconSize,
            color: SoftCalendarTone.ink(context),
          ),
        ),
      ),
    );
    if (tooltip == null) return btn;
    return Tooltip(message: tooltip!, child: btn);
  }
}

class SoftCalendarCard extends StatelessWidget {
  const SoftCalendarCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.radius = 24,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: SoftCalendarTone.card(context),
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: SoftCalendarTone.border(context)),
        boxShadow: isDark ? null : SoftCalendarTone.shadow,
      ),
      child: child,
    );
  }
}

/// One calendar day. Selected days are mint, today gets an emerald ring,
/// and expense days keep the rose dot.
class SoftCalendarDayChip extends StatelessWidget {
  const SoftCalendarDayChip({
    super.key,
    required this.label,
    required this.selected,
    this.isToday = false,
    this.hasExpense = false,
    this.onTap,
  });

  final String label;
  final bool selected;
  final bool isToday;
  final bool hasExpense;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final accent = selected || isToday;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        splashColor: SoftCalendarTone.mint(context),
        highlightColor: SoftCalendarTone.mint(context).withValues(alpha: 0.7),
        child: Ink(
          decoration: BoxDecoration(
            color:
                selected
                    ? SoftCalendarTone.mintDeep(context)
                    : Colors.transparent,
            borderRadius: BorderRadius.circular(14),
            border:
                isToday
                    ? Border.all(
                      color: SoftCalendarTone.emerald(context),
                      width: 1.5,
                    )
                    : null,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                label,
                style: SoftCalendarTone.text(
                  context,
                  fontSize: 14,
                  fontWeight: accent ? FontWeight.w700 : FontWeight.w500,
                  color:
                      accent
                          ? SoftCalendarTone.emeraldDeep(context)
                          : SoftCalendarTone.ink(context),
                ),
              ),
              if (hasExpense)
                Container(
                  margin: const EdgeInsets.only(top: 4),
                  width: 4,
                  height: 4,
                  decoration: BoxDecoration(
                    color: SoftCalendarTone.rose(context),
                    shape: BoxShape.circle,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

/// One ledger row for the selected day. Pale mint (or a category pastel)
/// icon square, merchant, category, time, and a signed rupee amount.
class SoftCalendarEntryTile extends StatelessWidget {
  const SoftCalendarEntryTile({
    super.key,
    required this.merchant,
    required this.category,
    required this.timeLabel,
    required this.amount,
    required this.amountColor,
    required this.onTap,
  });

  final String merchant;
  final String category;
  final String timeLabel;
  final String amount;
  final Color amountColor;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final mark = _categoryMark(context, category);
    final trimmed = category.trim();
    final subtitle = trimmed.isEmpty ? timeLabel : '$trimmed · $timeLabel';

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(24),
        splashColor: SoftCalendarTone.mint(context),
        child: Ink(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: SoftCalendarTone.card(context),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: SoftCalendarTone.border(context)),
            boxShadow: isDark ? null : SoftCalendarTone.shadow,
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: mark.fill,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(mark.icon, size: 18, color: mark.ink),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      merchant,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: SoftCalendarTone.text(
                        context,
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: SoftCalendarTone.text(
                        context,
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                        color: SoftCalendarTone.slate(context),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Text(
                amount,
                style: SoftCalendarTone.text(
                  context,
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  color: amountColor,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

({Color fill, Color ink, IconData icon}) _categoryMark(
  BuildContext context,
  String category,
) {
  final dark = Theme.of(context).brightness == Brightness.dark;
  final key = category.toLowerCase();
  if (key.contains('food') ||
      key.contains('restaurant') ||
      key.contains('dining')) {
    return (
      fill: dark ? const Color(0xFF3F2214) : const Color(0xFFFFF7ED),
      ink: const Color(0xFFEA580C),
      icon: LucideIcons.utensils,
    );
  }
  if (key.contains('shop') || key.contains('groc')) {
    return (
      fill: dark ? const Color(0xFF3F2A12) : const Color(0xFFFFFBEB),
      ink: const Color(0xFFD97706),
      icon: LucideIcons.shoppingBag,
    );
  }
  if (key.contains('entertain') || key.contains('movie')) {
    return (
      fill: dark ? const Color(0xFF3F1218) : const Color(0xFFFFF1F2),
      ink: const Color(0xFFE11D48),
      icon: LucideIcons.film,
    );
  }
  final mint = SoftCalendarTone.mint(context);
  final emerald = SoftCalendarTone.emeraldDeep(context);
  if (key.contains('salary') || key.contains('income')) {
    return (fill: mint, ink: emerald, icon: LucideIcons.briefcase);
  }
  if (key.contains('transport') ||
      key.contains('travel') ||
      key.contains('fuel') ||
      key.contains('cab')) {
    return (fill: mint, ink: emerald, icon: LucideIcons.car);
  }
  if (key.contains('stay') || key.contains('hotel')) {
    return (fill: mint, ink: emerald, icon: LucideIcons.hotel);
  }
  return (fill: mint, ink: emerald, icon: LucideIcons.receipt);
}
