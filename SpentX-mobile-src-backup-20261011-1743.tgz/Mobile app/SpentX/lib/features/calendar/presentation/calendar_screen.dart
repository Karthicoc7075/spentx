import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../core/providers/transaction_provider.dart' as model;
import '../../../core/sync/sync_service.dart';
import '../../../core/utils/transaction_display_utils.dart';
import 'widgets/soft_calendar_widgets.dart';

/// Spending calendar — fully wired to the real transaction ledger.
/// Month navigation works, expense dots reflect real data, and the day
/// summary card shows real figures for the selected day.
class CalendarScreen extends ConsumerStatefulWidget {
  const CalendarScreen({super.key});

  @override
  ConsumerState<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends ConsumerState<CalendarScreen> {
  late DateTime _visibleMonth;
  late DateTime _selectedDay;
  bool _fetchingMonth = false;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    _visibleMonth = DateTime(now.year, now.month);
    _selectedDay = DateTime(now.year, now.month, now.day);
  }

  void _changeMonth(int delta) {
    setState(() {
      _visibleMonth = DateTime(_visibleMonth.year, _visibleMonth.month + delta);
      // Keep selection inside the visible month.
      final now = DateTime.now();
      if (_visibleMonth.year == now.year && _visibleMonth.month == now.month) {
        _selectedDay = DateTime(now.year, now.month, now.day);
      } else {
        _selectedDay = DateTime(_visibleMonth.year, _visibleMonth.month, 1);
      }
    });
    _ensureMonthLoaded(_visibleMonth);
  }

  /// Months fetched (or proven cached) in this screen, as year*12+month.
  final Set<int> _loadedMonths = {};

  /// Latest month requested while a fetch was running; fetched next.
  DateTime? _queuedMonth;

  /// Oldest cached transaction when the screen opened: everything from that
  /// month on came from the normal sync window. Later on-demand fetches of
  /// old months must NOT count as proof that the months in between loaded.
  DateTime? _baselineOldest;
  bool _baselineTaken = false;

  static int _monthKey(DateTime m) => m.year * 12 + m.month;

  Future<void> _ensureMonthLoaded(DateTime month) async {
    final key = _monthKey(month);
    if (_loadedMonths.contains(key)) return;
    if (_fetchingMonth) {
      _queuedMonth = month; // keep only the latest request
      return;
    }
    final startOfMonth = DateTime(month.year, month.month, 1);
    final endOfMonth = DateTime(month.year, month.month + 1, 0, 23, 59, 59);
    if (!_baselineTaken) {
      _baselineTaken = true;
      _baselineOldest = SyncService.oldestCachedTransactionDate();
    }
    final base = _baselineOldest;
    if (base != null &&
        !DateTime(base.year, base.month).isAfter(startOfMonth)) {
      _loadedMonths.add(key);
      return;
    }

    _fetchingMonth = true;
    try {
      final fetched = await SyncService.fetchTransactionRange(
        from: startOfMonth,
        to: endOfMonth,
      );
      // null = offline / not signed in / failed: retry on the next visit.
      if (fetched != null) _loadedMonths.add(key);
    } catch (_) {
      // Leave unmarked so the next visit retries.
    } finally {
      _fetchingMonth = false;
    }
    if (mounted) setState(() {});
    final queued = _queuedMonth;
    _queuedMonth = null;
    if (queued != null && mounted) await _ensureMonthLoaded(queued);
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final txs = ref.watch(model.transactionProvider);
    final fmt = NumberFormat.currency(
      symbol: '₹',
      decimalDigits: 0,
      locale: 'en_IN',
    );

    final monthTxs =
        txs
            .where(
              (t) =>
                  !t.isPendingVerification &&
                  t.date.year == _visibleMonth.year &&
                  t.date.month == _visibleMonth.month,
            )
            .toList();

    final expenseDays = <int>{};
    for (final t in monthTxs) {
      if (t.isExpense && !t.isTransfer) expenseDays.add(t.date.day);
    }

    final daysInMonth =
        DateTime(_visibleMonth.year, _visibleMonth.month + 1, 0).day;
    // Weekday of the 1st (Sunday-first grid): DateTime.weekday is 1=Mon..7=Sun.
    final leadingBlanks =
        DateTime(_visibleMonth.year, _visibleMonth.month, 1).weekday % 7;

    final dayTxs =
        monthTxs.where((t) => t.date.day == _selectedDay.day).toList()
          ..sort((a, b) => b.date.compareTo(a.date));
    final daySpent = dayTxs
        .where((t) => t.isExpense && !t.isTransfer)
        .fold(0.0, (s, t) => s + t.amount);
    final dayEarned = dayTxs
        .where((t) => !t.isExpense && !t.isTransfer && t.category != 'Transfer')
        .fold(0.0, (s, t) => s + t.amount);

    final isCurrentMonth =
        _visibleMonth.year == now.year && _visibleMonth.month == now.month;
    final selectedIsToday = isCurrentMonth && _selectedDay.day == now.day;

    final ink = SoftCalendarTone.ink(context);

    return Scaffold(
      backgroundColor: SoftCalendarTone.canvas(context),
      appBar: AppBar(
        backgroundColor: SoftCalendarTone.canvas(context),
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        leadingWidth: 56,
        leading: Padding(
          padding: const EdgeInsets.only(left: 8),
          child: Center(
            child: SoftCalendarIconButton(
              icon: Icons.arrow_back_ios_new_rounded,
              iconSize: 16,
              tooltip: 'Back',
              onPressed: () => Navigator.maybePop(context),
            ),
          ),
        ),
        title: Text(
          'Calendar',
          style: SoftCalendarTone.text(
            context,
            fontSize: 18,
            fontWeight: FontWeight.w700,
            letterSpacing: -0.3,
            color: ink,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          children: [
            const SizedBox(height: 8),
            SoftCalendarCard(
              radius: 26,
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SoftCalendarIconButton(
                        icon: LucideIcons.chevronLeft,
                        onPressed: () => _changeMonth(-1),
                      ),
                      Text(
                        DateFormat('MMMM yyyy').format(_visibleMonth),
                        style: SoftCalendarTone.text(
                          context,
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          letterSpacing: -0.3,
                          color: ink,
                        ),
                      ),
                      SoftCalendarIconButton(
                        icon: LucideIcons.chevronRight,
                        onPressed: () => _changeMonth(1),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children:
                        ['S', 'M', 'T', 'W', 'T', 'F', 'S']
                            .map(
                              (d) => SizedBox(
                                width: 40,
                                child: Center(
                                  child: Text(
                                    d,
                                    style: SoftCalendarTone.text(
                                      context,
                                      fontSize: 12,
                                      fontWeight: FontWeight.w600,
                                      color: SoftCalendarTone.slate(context),
                                    ),
                                  ),
                                ),
                              ),
                            )
                            .toList(),
                  ),
                  const SizedBox(height: 8),
                  GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 7,
                          mainAxisSpacing: 4,
                          crossAxisSpacing: 4,
                        ),
                    itemCount: leadingBlanks + daysInMonth,
                    itemBuilder: (context, index) {
                      if (index < leadingBlanks) {
                        return const SizedBox.shrink();
                      }
                      final day = index - leadingBlanks + 1;
                      final isToday = isCurrentMonth && day == now.day;
                      final isSelected = day == _selectedDay.day;
                      final hasExpense = expenseDays.contains(day);

                      return SoftCalendarDayChip(
                        label: '$day',
                        selected: isSelected,
                        isToday: isToday,
                        hasExpense: hasExpense,
                        onTap:
                            () => setState(() {
                              _selectedDay = DateTime(
                                _visibleMonth.year,
                                _visibleMonth.month,
                                day,
                              );
                            }),
                      );
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            SoftCalendarCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    selectedIsToday
                        ? 'Today'
                        : DateFormat('d MMMM yyyy').format(_selectedDay),
                    style: SoftCalendarTone.text(
                      context,
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      letterSpacing: -0.3,
                      color: ink,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _DayStat(
                        label: 'Spent',
                        value: fmt.format(daySpent),
                        color: SoftCalendarTone.rose(context),
                      ),
                      _DayStat(
                        label: 'Earned',
                        value: fmt.format(dayEarned),
                        color: SoftCalendarTone.emeraldDeep(context),
                      ),
                      _DayStat(
                        label: 'Txns',
                        value: '${dayTxs.length}',
                        color: SoftCalendarTone.emerald(context),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'ENTRIES FOR THIS DAY · ${dayTxs.length}',
                style: SoftCalendarTone.text(
                  context,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.6,
                  color: SoftCalendarTone.muted(context),
                ),
              ),
            ),
            const SizedBox(height: 12),
            if (dayTxs.isEmpty)
              SoftCalendarCard(
                child: SizedBox(
                  width: double.infinity,
                  child: Column(
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: SoftCalendarTone.mint(context),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Icon(
                          LucideIcons.receipt,
                          size: 18,
                          color: SoftCalendarTone.emeraldDeep(context),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        'No transactions this day',
                        style: SoftCalendarTone.text(
                          context,
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: SoftCalendarTone.slate(context),
                        ),
                      ),
                    ],
                  ),
                ),
              )
            else
              for (final tx in dayTxs) ...[
                SoftCalendarEntryTile(
                  merchant: _merchantLabel(tx),
                  category: tx.category,
                  timeLabel: _timeLabel(tx),
                  amount: _amountLabel(tx, fmt),
                  amountColor:
                      tx.isTransfer
                          ? ink
                          : tx.isExpense
                          ? SoftCalendarTone.rose(context)
                          : SoftCalendarTone.emerald(context),
                  onTap: () => context.push('/transaction/${tx.id}'),
                ),
                const SizedBox(height: 10),
              ],
            const SizedBox(height: 80),
          ],
        ),
      ),
    );
  }

  String _merchantLabel(model.Transaction tx) {
    final resolved = TransactionDisplayUtils.merchantTitle(tx).trim();
    if (resolved.isNotEmpty) return resolved;
    final title = (tx.title ?? '').trim();
    if (title.isNotEmpty) return title;
    final category = tx.category.trim();
    if (category.isNotEmpty) return category;
    return 'Transaction';
  }

  String _timeLabel(model.Transaction tx) {
    final raw = tx.time.trim();
    final looksLikeClock = RegExp(
      r'^\d{1,2}:\d{2}(\s*[AaPp][Mm])?$',
    ).hasMatch(raw);
    if (looksLikeClock) return raw;
    return DateFormat('h:mm a').format(tx.date.toLocal());
  }

  String _amountLabel(model.Transaction tx, NumberFormat fmt) {
    final money = fmt.format(tx.amount.abs());
    if (tx.isTransfer) return money;
    return tx.isExpense ? '−$money' : '+$money';
  }
}

class _DayStat extends StatelessWidget {
  final String label, value;
  final Color color;

  const _DayStat({
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          value,
          style: SoftCalendarTone.text(
            context,
            fontSize: 18,
            fontWeight: FontWeight.w700,
            letterSpacing: -0.3,
            color: color,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: SoftCalendarTone.text(
            context,
            fontSize: 11,
            fontWeight: FontWeight.w600,
            color: SoftCalendarTone.slate(context),
          ),
        ),
      ],
    );
  }
}
