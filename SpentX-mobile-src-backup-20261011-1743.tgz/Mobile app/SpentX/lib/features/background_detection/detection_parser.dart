import 'dart:convert';
import 'transaction_model.dart';

class DetectionParser {
  static TransactionModel? parsePayload(String payload) {
    try {
      final jsonMap = jsonDecode(payload);
      return TransactionModel.fromJson(jsonMap);
    } catch (e) {
      return null;
    }
  }
}
