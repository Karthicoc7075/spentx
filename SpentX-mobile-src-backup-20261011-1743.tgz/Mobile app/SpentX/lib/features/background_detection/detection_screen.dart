import 'package:flutter/material.dart';
import '../../core/theme/soft_palette.dart';
import 'transaction_model.dart';

class DetectionScreen {
  static void showTransactionBottomSheet(
    BuildContext context,
    TransactionModel transaction,
  ) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _DetectionBottomSheet(transaction: transaction),
    );
  }
}

class _DetectionBottomSheet extends StatefulWidget {
  final TransactionModel transaction;

  const _DetectionBottomSheet({required this.transaction});

  @override
  State<_DetectionBottomSheet> createState() => _DetectionBottomSheetState();
}

class _DetectionBottomSheetState extends State<_DetectionBottomSheet> {
  static const _cardShadow = <BoxShadow>[
    BoxShadow(
      color: Color(0x0A0F172A),
      blurRadius: 16,
      offset: Offset(0, 4),
      spreadRadius: -2,
    ),
  ];

  String _accountType = 'Personal';
  final String _category = 'General';

  @override
  Widget build(BuildContext context) {
    final isDebit = widget.transaction.type == 'debit';

    return Container(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
        top: 12,
        left: 20,
        right: 20,
      ),
      decoration: const BoxDecoration(
        color: SoftPalette.bg,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        boxShadow: [
          BoxShadow(
            color: Color(0x120F172A),
            blurRadius: 32,
            offset: Offset(0, -8),
            spreadRadius: -8,
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 42,
              height: 4,
              decoration: BoxDecoration(
                color: SoftPalette.border,
                borderRadius: BorderRadius.circular(999),
              ),
            ),
          ),
          const SizedBox(height: 22),
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(11),
                decoration: BoxDecoration(
                  color: SoftPalette.emeraldSoft,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(
                  isDebit
                      ? Icons.arrow_upward_rounded
                      : Icons.arrow_downward_rounded,
                  color: SoftPalette.emerald,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'Review detected transaction',
                  style: const TextStyle(
                    color: SoftPalette.ink,
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -0.2,
                  ),
                ),
              ),
              IconButton(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.close_rounded),
                color: SoftPalette.muted,
                tooltip: 'Close',
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
            decoration: BoxDecoration(
              color: SoftPalette.card,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: SoftPalette.border),
              boxShadow: _cardShadow,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  isDebit ? 'Amount spent' : 'Amount received',
                  style: const TextStyle(
                    color: SoftPalette.muted,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '₹${widget.transaction.amount.toStringAsFixed(2)}',
                  style: const TextStyle(
                    color: SoftPalette.ink,
                    fontSize: 40,
                    height: 1.1,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -1.2,
                  ),
                ),
                const SizedBox(height: 18),
                _buildInfoRow(
                  Icons.storefront_rounded,
                  'Merchant',
                  widget.transaction.merchant,
                ),
                const SizedBox(height: 12),
                _buildInfoRow(
                  Icons.account_balance_rounded,
                  'Bank',
                  widget.transaction.bank,
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _buildSelectorCard('Account', _accountType, () {
                  setState(() {
                    _accountType =
                        _accountType == 'Personal' ? 'Home' : 'Personal';
                  });
                }),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildSelectorCard('Category', _category, () {
                  // Connect to Category Picker
                }),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => Navigator.pop(context),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: SoftPalette.ink,
                    backgroundColor: SoftPalette.card,
                    padding: const EdgeInsets.symmetric(vertical: 17),
                    side: const BorderSide(color: SoftPalette.border),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18),
                    ),
                  ),
                  child: const Text(
                    'Ignore',
                    style: TextStyle(
                      color: SoftPalette.ink,
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: const Text(
                          'Transaction saved',
                          style: TextStyle(
                            color: SoftPalette.onEmerald,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        backgroundColor: SoftPalette.emerald,
                        behavior: SnackBarBehavior.floating,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    foregroundColor: Colors.white,
                    backgroundColor: SoftColors.control,
                    padding: const EdgeInsets.symmetric(vertical: 17),
                    elevation: 0,
                    shadowColor: Colors.transparent,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18),
                    ),
                  ),
                  child: const Text(
                    'Save transaction',
                    style: TextStyle(
                      color: SoftPalette.onEmerald,
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(9),
          decoration: BoxDecoration(
            color: SoftPalette.emeraldSoft,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Icon(icon, color: SoftPalette.emerald, size: 20),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: const TextStyle(
                  color: SoftPalette.muted,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                value,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: SoftPalette.ink,
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSelectorCard(String label, String value, VoidCallback onTap) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.fromLTRB(14, 13, 12, 13),
          decoration: BoxDecoration(
            color: SoftPalette.card,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: SoftPalette.border),
            boxShadow: _cardShadow,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: const TextStyle(
                  color: SoftPalette.muted,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 7),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      value,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: SoftPalette.ink,
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  const Icon(
                    Icons.keyboard_arrow_down_rounded,
                    color: SoftPalette.muted,
                    size: 19,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
