class TransactionModel {
  final double amount;
  final String merchant;
  final String bank;
  final String type;
  final String rawText;

  TransactionModel({
    required this.amount,
    required this.merchant,
    required this.bank,
    required this.type,
    required this.rawText,
  });

  factory TransactionModel.fromJson(Map<String, dynamic> json) {
    return TransactionModel(
      amount: double.tryParse(json['amount'].toString().replaceAll(',', '')) ?? 0.0,
      merchant: json['merchant'] ?? 'Unknown',
      bank: json['bank'] ?? 'Bank',
      type: json['type'] ?? 'debit',
      rawText: json['rawText'] ?? '',
    );
  }
}
