import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:hive_flutter/hive_flutter.dart';
import '../sms/detected/sms_detection_pipeline.dart';
import '../sms/detected/detection_queue.dart';
import '../sms/detected/detected_sms_storage.dart';
import '../sms/detected/pending_verification_presenter.dart';
import '../sms/core/app_foreground_detector.dart';
import '../sms/core/sms_pending_service.dart';

class NotificationService {
  static const MethodChannel _channel = MethodChannel('com.spentx/notifications');
  static const EventChannel _eventChannel =
      EventChannel('com.spentx/transaction_events');
  static bool _listening = false;
  static StreamSubscription<dynamic>? _eventSub;

  static const MethodChannel _permissionsChannel =
      MethodChannel('com.spentx.app/permissions');

  static void startListening() {
    if (_listening) return;
    _listening = true;

    _eventSub = _eventChannel.receiveBroadcastStream().listen((payload) async {
      if (payload != null) {
        final ref = AppForegroundDetector.isInForeground ? AppForegroundDetector.ref : null;
        await handlePayload(payload.toString(), ref: ref);
      }
    });

    _channel.invokeMethod<String>('getInitialPayload').then((payload) async {
      if (payload != null && payload.isNotEmpty) {
        await handlePayload(payload);
      }
    });

    unawaited(flushPendingPayloads());
  }

  /// Stops the transaction-event listener. Called on sign-out so a
  /// logged-out device raises no detection popups.
  static void stopListening() {
    _eventSub?.cancel();
    _eventSub = null;
    _listening = false;
  }

  @Deprecated('Use startListening')
  static void initialize(BuildContext context) => startListening();

  static Future<bool> shouldOpenPendingQueue() async {
    try {
      final result = await _channel.invokeMethod<bool>('shouldOpenPendingQueue');
      return result ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Process initial intent + native queue. Returns true if pending queue non-empty.
  static Future<bool> processAllPendingPayloads({WidgetRef? ref}) async {
    if (!SmsDetectionPipeline.isAutoDetectionEnabled) {
      await discardPendingPayloads();
      return _hasPendingItems();
    }

    var processed = false;

    try {
      final initial = await _channel.invokeMethod<String>('getInitialPayload');
      if (initial != null && initial.isNotEmpty) {
        processed = await handlePayload(initial, ref: ref) || processed;
      }
    } catch (_) {}

    try {
      final List<dynamic>? pending = await _permissionsChannel
          .invokeMethod<List<dynamic>>('getPendingTransactionPayloads');
      if (pending != null) {
        for (final item in pending) {
          if (item is String && item.isNotEmpty) {
            processed = await handlePayload(item, ref: ref) || processed;
          }
        }
      }
    } catch (_) {}

    SmsPendingService.reconcile();
    _refreshQueue(ref);
    return _hasPendingItems() || processed;
  }

  static bool _hasPendingItems() {
    if (!Hive.isBoxOpen('pending_detections')) return false;
    final q = Hive.box('pending_detections').get('queue', defaultValue: const <dynamic>[]) as List;
    return q.isNotEmpty;
  }

  static void _refreshQueue(WidgetRef? ref) {
    ref?.read(detectionQueueProvider.notifier).refresh();
  }

  /// Returns true when a pending verification record exists or was created.
  static Future<bool> handlePayload(String payload, {WidgetRef? ref}) async {
    if (!SmsDetectionPipeline.isAutoDetectionEnabled) return false;
    try {
      final jsonMap = Map<String, dynamic>.from(jsonDecode(payload));
      final txId = jsonMap['transactionId']?.toString();

      if (txId != null && txId.isNotEmpty && DetectedSmsStorage.get(txId) == null) {
        await SmsDetectionPipeline.processNotificationPayload(jsonMap);
      } else if (txId == null || txId.isEmpty) {
        await SmsDetectionPipeline.processNotificationPayload(jsonMap);
      }

      if (txId != null && txId.isNotEmpty) {
        _ensureQueueContains(txId);
        if (jsonMap['pending'] == true || jsonMap['pending']?.toString() == 'true') {
          unawaited(SmsPendingService.storeNotificationTapTarget(txId));
        }
      }

      SmsPendingService.reconcile();
      _refreshQueue(ref);

      final materializedId = txId ?? SmsPendingService.listAwaitingVerification().firstOrNull?.id;
      if (ref != null &&
          materializedId != null &&
          materializedId.isNotEmpty &&
          DetectedSmsStorage.get(materializedId) != null) {
        PendingVerificationPresenter.requestShow(ref, targetTransactionId: materializedId);
      }

      return DetectedSmsStorage.get(txId ?? '') != null || _hasPendingItems();
    } catch (_) {
      return false;
    }
  }

  static void _ensureQueueContains(String txId) {
    if (!Hive.isBoxOpen('pending_detections')) return;
    final qbox = Hive.box('pending_detections');
    final List<dynamic> q = List<dynamic>.from(qbox.get('queue', defaultValue: const <dynamic>[]));
    if (!q.contains(txId)) {
      q.add(txId);
      qbox.put('queue', q);
    }
  }

  static Future<void> discardPendingPayloads() => flushPendingPayloads(process: false);

  static Future<void> flushPendingPayloads({bool process = true}) async {
    if (!process || !SmsDetectionPipeline.isAutoDetectionEnabled) {
      try {
        await _permissionsChannel.invokeMethod<List<dynamic>>('getPendingTransactionPayloads');
      } catch (_) {}
      return;
    }
    try {
      final List<dynamic>? pending = await _permissionsChannel
          .invokeMethod<List<dynamic>>('getPendingTransactionPayloads');
      if (pending == null) return;
      for (final item in pending) {
        if (item is String && item.isNotEmpty) {
          await handlePayload(item);
        }
      }
      DetectedSmsStorage.reconcilePendingQueue();
    } catch (_) {}
  }

  static Future<void> setBackgroundDetection(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('background_detection_enabled', enabled);
  }

  static Future<bool> isBackgroundDetectionEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('background_detection_enabled') ?? true;
  }

  static Future<void> openNotificationListenerSettings() async {
    await _channel.invokeMethod('openListenerSettings');
  }
}