import 'package:flutter/material.dart';

import '../../../../core/theme/soft_palette.dart';
import '../../../../core/widgets/reference_ui.dart';

class OnboardingSuccessScreen extends StatelessWidget {
  const OnboardingSuccessScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = isDark ? SoftPalette.darkBg : SoftPalette.bg;
    final ink = isDark ? SoftPalette.darkInk : SoftPalette.ink;
    final muted = isDark ? SoftPalette.darkMuted : SoftPalette.muted;

    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 24, 24, 24),
          child: Column(
            children: [
              const Spacer(),
              Container(
                width: 88,
                height: 88,
                decoration: BoxDecoration(
                  color: SoftPalette.emeraldSoft,
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.check_circle_rounded,
                  size: 48,
                  color: SoftPalette.emerald,
                ),
              ),
              const SizedBox(height: 24),
              Text(
                'All set up!',
                style: TextStyle(
                  color: ink,
                  fontSize: 26,
                  fontWeight: FontWeight.w800,
                  letterSpacing: -0.4,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Your fintech dashboard is ready to use.',
                textAlign: TextAlign.center,
                style: TextStyle(color: muted, fontSize: 14, height: 1.45),
              ),
              const SizedBox(height: 28),
              SxSoftCard(
                padding: const EdgeInsets.fromLTRB(20, 18, 20, 18),
                child: Column(
                  children: const [
                    _SummaryRow(label: 'Accounts Linked', value: '3'),
                    SizedBox(height: 16),
                    _SummaryRow(label: 'Primary Purpose', value: 'Personal'),
                    SizedBox(height: 16),
                    _SummaryRow(label: 'Total Balance', value: '₹ 45,200'),
                  ],
                ),
              ),
              const Spacer(),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: FilledButton(
                  onPressed: () {},
                  style: FilledButton.styleFrom(
                    backgroundColor: SoftColors.control,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(24),
                    ),
                  ),
                  child: const Text(
                    'Enter app',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  final String label;
  final String value;

  const _SummaryRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final ink = isDark ? SoftPalette.darkInk : SoftPalette.ink;
    final muted = isDark ? SoftPalette.darkMuted : SoftPalette.muted;
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            color: muted,
            fontWeight: FontWeight.w600,
            fontSize: 13,
          ),
        ),
        Text(
          value,
          style: TextStyle(
            fontWeight: FontWeight.w800,
            fontSize: 15,
            color: ink,
          ),
        ),
      ],
    );
  }
}
