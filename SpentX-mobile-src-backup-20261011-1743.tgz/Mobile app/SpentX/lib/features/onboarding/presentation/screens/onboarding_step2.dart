import 'package:flutter/material.dart';

import '../../../../core/theme/soft_palette.dart';
import '../../../../core/widgets/reference_ui.dart';

class OnboardingStep2 extends StatelessWidget {
  const OnboardingStep2({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = isDark ? SoftPalette.darkBg : SoftPalette.bg;
    final ink = isDark ? SoftPalette.darkInk : SoftPalette.ink;
    final muted = isDark ? SoftPalette.darkMuted : SoftPalette.muted;

    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  SoftCircleIconButton(
                    icon: Icons.arrow_back_ios_new_rounded,
                    onPressed: () => Navigator.pop(context),
                  ),
                  const Spacer(),
                  _SoftDots(current: 1, total: 4),
                  const Spacer(),
                  const SizedBox(width: 40),
                ],
              ),
              const SizedBox(height: 28),
              Text(
                'Account detail',
                style: TextStyle(
                  color: ink,
                  fontSize: 24,
                  fontWeight: FontWeight.w800,
                  letterSpacing: -0.4,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Enter your primary bank details',
                style: TextStyle(color: muted, fontSize: 14, height: 1.45),
              ),
              const SizedBox(height: 10),
              Text(
                'Account 1 of 3',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  color: SoftPalette.emerald,
                  fontSize: 13,
                ),
              ),
              const SizedBox(height: 24),
              SxSoftCard(
                padding: const EdgeInsets.fromLTRB(16, 18, 16, 18),
                child: Column(
                  children: [
                    _SoftField(
                      label: 'Bank Name',
                      hint: 'Select your bank',
                      icon: Icons.account_balance,
                    ),
                    const SizedBox(height: 16),
                    _SoftField(
                      label: 'Last 4 Digits',
                      hint: 'e.g. 1234',
                      keyboardType: TextInputType.number,
                    ),
                    const SizedBox(height: 16),
                    _SoftField(
                      label: 'Initial Balance',
                      hint: '₹ 0.00',
                      keyboardType: TextInputType.number,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 32),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context),
                      style: OutlinedButton.styleFrom(
                        minimumSize: const Size.fromHeight(52),
                        side: BorderSide(
                          color: isDark
                              ? SoftPalette.darkBorder
                              : SoftPalette.border,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(24),
                        ),
                        foregroundColor: ink,
                      ),
                      child: const Text(
                        'Back',
                        style: TextStyle(fontWeight: FontWeight.w700),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    flex: 2,
                    child: FilledButton(
                      onPressed: () {},
                      style: FilledButton.styleFrom(
                        minimumSize: const Size.fromHeight(52),
                        backgroundColor: SoftColors.control,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(24),
                        ),
                      ),
                      child: const Text(
                        'Next account',
                        style: TextStyle(fontWeight: FontWeight.w700),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SoftField extends StatelessWidget {
  const _SoftField({
    required this.label,
    required this.hint,
    this.icon,
    this.keyboardType,
  });

  final String label;
  final String hint;
  final IconData? icon;
  final TextInputType? keyboardType;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final muted = isDark ? SoftPalette.darkMuted : SoftPalette.muted;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: muted,
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          keyboardType: keyboardType,
          decoration: InputDecoration(
            hintText: hint,
            prefixIcon: icon == null
                ? null
                : Icon(icon, size: 20, color: SoftPalette.emerald),
            filled: true,
            fillColor:
                isDark ? SoftPalette.darkSurfaceVariant : SoftPalette.surfaceVariant,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide.none,
            ),
          ),
        ),
      ],
    );
  }
}

class _SoftDots extends StatelessWidget {
  const _SoftDots({required this.current, required this.total});
  final int current;
  final int total;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(total, (i) {
        final active = i == current;
        return Container(
          width: 8,
          height: 8,
          margin: const EdgeInsets.symmetric(horizontal: 3),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: active ? SoftPalette.emerald : SoftPalette.border,
          ),
        );
      }),
    );
  }
}
