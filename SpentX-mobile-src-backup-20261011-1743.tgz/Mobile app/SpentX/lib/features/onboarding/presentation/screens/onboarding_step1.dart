import 'package:flutter/material.dart';

import '../../../../core/theme/soft_palette.dart';
import '../../../../core/widgets/reference_ui.dart';

class OnboardingStep1 extends StatefulWidget {
  const OnboardingStep1({super.key});

  @override
  State<OnboardingStep1> createState() => _OnboardingStep1State();
}

class _OnboardingStep1State extends State<OnboardingStep1> {
  int _count = 2;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = isDark ? SoftPalette.darkBg : SoftPalette.bg;
    final ink = isDark ? SoftPalette.darkInk : SoftPalette.ink;
    final muted = isDark ? SoftPalette.darkMuted : SoftPalette.muted;

    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
          child: Column(
            children: [
              Row(
                children: [
                  SoftCircleIconButton(
                    icon: Icons.arrow_back_ios_new_rounded,
                    onPressed: () => Navigator.maybePop(context),
                  ),
                  const Spacer(),
                  _SoftDots(current: 0, total: 4),
                  const Spacer(),
                  const SizedBox(width: 40),
                ],
              ),
              const Spacer(),
              Text(
                'How many accounts?',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: ink,
                  fontSize: 24,
                  fontWeight: FontWeight.w800,
                  letterSpacing: -0.4,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Select the number of bank accounts you use',
                textAlign: TextAlign.center,
                style: TextStyle(color: muted, fontSize: 14, height: 1.45),
              ),
              const SizedBox(height: 32),
              SxSoftCard(
                padding: const EdgeInsets.fromLTRB(20, 24, 20, 24),
                child: Column(
                  children: [
                    Text(
                      '$_count',
                      style: TextStyle(
                        color: ink,
                        fontSize: 48,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Slider(
                      value: _count.toDouble(),
                      min: 1,
                      max: 6,
                      divisions: 5,
                      activeColor: SoftPalette.emerald,
                      onChanged: (v) => setState(() => _count = v.round()),
                    ),
                  ],
                ),
              ),
              const Spacer(),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: FilledButton(
                  onPressed: () {},
                  style: FilledButton.styleFrom(
                    backgroundColor: SoftColors.control,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(24),
                    ),
                  ),
                  child: const Text(
                    'Continue',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              TextButton(
                onPressed: () {},
                child: Text(
                  'Skip for now',
                  style: TextStyle(
                    color: muted,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SoftDots extends StatelessWidget {
  const _SoftDots({required this.current, required this.total});
  final int current;
  final int total;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(total, (i) {
        final active = i == current;
        return Container(
          width: 8,
          height: 8,
          margin: const EdgeInsets.symmetric(horizontal: 3),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: active
                ? SoftPalette.emerald
                : SoftPalette.border,
          ),
        );
      }),
    );
  }
}
