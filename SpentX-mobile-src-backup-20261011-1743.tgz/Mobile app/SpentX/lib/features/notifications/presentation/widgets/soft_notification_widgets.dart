import 'package:flutter/material.dart';

import '../../../../core/theme/soft_palette.dart';
import '../../../../core/widgets/reference_ui.dart';

class SoftNotificationCard extends StatelessWidget {
  const SoftNotificationCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.onTap,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final card = SxSoftCard(padding: padding, child: child);
    if (onTap == null) return card;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: const BorderRadius.all(Radius.circular(18)),
        child: card,
      ),
    );
  }
}

Color softNotificationAccent(String type) {
  switch (type) {
    case 'sms_auto':
      return SoftPalette.mintDark;
    case 'sms_pending':
      return SoftPalette.emerald;
    case 'budget':
    case 'daily-limit':
    case 'burn-rate':
    case 'weekly-share':
      return SoftPalette.negative;
    default:
      return SoftPalette.emerald;
  }
}
