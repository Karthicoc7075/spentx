import 'package:flutter/material.dart';
import '../../../core/theme/spentx_tokens.dart';
import '../../../core/design/sx_primitives.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:intl/intl.dart';
import 'package:go_router/go_router.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../core/widgets/reference_ui.dart';
import 'widgets/soft_notification_widgets.dart';
import '../../../core/services/notification_history_service.dart';

class NotificationsScreen extends ConsumerWidget {
  const NotificationsScreen({super.key});

  IconData _iconForType(String type) {
    switch (type) {
      case 'sms_auto':
        return LucideIcons.smartphone;
      case 'sms_pending':
        return LucideIcons.messageSquare;
      case 'budget':
        return LucideIcons.target;
      case 'daily-limit':
        return LucideIcons.calendarClock;
      case 'burn-rate':
        return LucideIcons.flame;
      case 'weekly-share':
        return LucideIcons.pieChart;
      default:
        return LucideIcons.bell;
    }
  }

  Color _colorForType(String type) => softNotificationAccent(type);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final records = ref.watch(notificationHistoryProvider);

    final t = context.tokens;
    return Scaffold(
      backgroundColor: t.background,
      appBar: AppBar(
        backgroundColor: t.surface,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        leadingWidth: 56,
        leading: Padding(
          padding: const EdgeInsets.only(left: 8),
          child: Center(
            child: SoftCircleIconButton(
              icon: Icons.arrow_back_ios_new_rounded,
              tooltip: 'Back',
              onPressed: () => Navigator.maybePop(context),
            ),
          ),
        ),
        title: Text(
          'Notification History',
          style: AppType.section(SoftPalette.ink),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 4),
            child: SxIconButton(
              icon: LucideIcons.slidersHorizontal,
              tooltip: 'Notification Preferences',
              onPressed: () => context.push('/notification-preferences'),
            ),
          ),
          if (records.isNotEmpty)
            TextButton(
              onPressed: () async {
                await NotificationHistoryService.markAllRead();
                ref.invalidate(notificationHistoryProvider);
              },
              child: Text(
                'Mark read',
                style: AppType.label(SoftPalette.emerald),
              ),
            ),
        ],
      ),
      body: records.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    LucideIcons.bellRing,
                    size: 48,
                    color: context.tokens.textSecondary,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'No notification history yet',
                    style: TextStyle(
                      color: context.tokens.textSecondary,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'All detected SMS, alerts, and other notifications appear here',
                    style: TextStyle(
                      fontSize: 12,
                      color: context.tokens.textSecondary,
                    ),
                  ),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              itemCount: records.length,
              itemBuilder: (context, i) {
                final r = records[i];
                final color = _colorForType(r.type);
                final timeStr = DateFormat('MMM dd, hh:mm a').format(r.createdAt);
                return Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _NotifTile(
                    icon: _iconForType(r.type),
                    color: color,
                    title: r.title,
                    body: r.body,
                    time: timeStr,
                    isDark: isDark,
                    isNew: !r.isRead,
                  ),
                );
              },
            ),
    );
  }
}

class _NotifTile extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title, body, time;
  final bool isDark, isNew;

  const _NotifTile({
    required this.icon,
    required this.color,
    required this.title,
    required this.body,
    required this.time,
    required this.isDark,
    this.isNew = false,
  });

  @override
  Widget build(BuildContext context) {
    return SoftNotificationCard(
      padding: const EdgeInsets.all(16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(color: color.withValues(alpha: 0.12), shape: BoxShape.circle),
            child: Icon(icon, color: color, size: 18),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        title,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                          color: Theme.of(context).colorScheme.onSurface,
                        ),
                      ),
                    ),
                    if (isNew)
                      Container(
                        width: 8,
                        height: 8,
                        decoration: BoxDecoration(color: color, shape: BoxShape.circle),
                      ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  body,
                  style: TextStyle(
                    fontSize: 13,
                    color: context.tokens.textSecondary,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  time,
                  style: TextStyle(
                    fontSize: 11,
                    color: context.tokens.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}