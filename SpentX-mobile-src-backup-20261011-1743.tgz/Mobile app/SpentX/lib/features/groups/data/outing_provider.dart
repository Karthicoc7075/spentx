import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/sync/sync_service.dart';
import 'package:uuid/uuid.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../../../core/services/outing_transaction_sync.dart';
import '../../../core/utils/outing_total_refresh.dart';

// ── MANAGE OUTING MODELS ──

/// Parity with web [TripMember]: id, name, upiId, friendId, isCurrentUser.
class OutingMember {
  final String id;
  final String name;
  final String? upiId;
  final String? friendId;
  final bool isCurrentUser;

  OutingMember({
    String? id,
    required this.name,
    this.upiId,
    this.friendId,
    this.isCurrentUser = false,
  }) : id = id ?? const Uuid().v4();

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    if (upiId != null && upiId!.isNotEmpty) 'upiId': upiId,
    if (friendId != null && friendId!.isNotEmpty) 'friendId': friendId,
    'isCurrentUser': isCurrentUser || name.toLowerCase() == 'you',
  };

  factory OutingMember.fromJson(Map<dynamic, dynamic> json) {
    final name = (json['name'] ?? 'Member').toString();
    final isYou = json['isCurrentUser'] == true || name.toLowerCase() == 'you';
    return OutingMember(
      id: json['id'] as String?,
      name: isYou ? 'You' : name,
      upiId: json['upiId']?.toString() ?? json['upi']?.toString(),
      friendId: json['friendId']?.toString() ?? json['friend_id']?.toString(),
      isCurrentUser: isYou,
    );
  }

  OutingMember copyWith({
    String? name,
    String? upiId,
    String? friendId,
    bool? isCurrentUser,
  }) => OutingMember(
    id: id,
    name: name ?? this.name,
    upiId: upiId ?? this.upiId,
    friendId: friendId ?? this.friendId,
    isCurrentUser: isCurrentUser ?? this.isCurrentUser,
  );
}

enum SplitType { solo, equally, custom }

/// Resolves legacy `'you'` keys vs real member UUIDs on trip expenses.
bool outingMemberIsYou(String memberKey, String? youMemberId) =>
    memberKey == 'you' || (youMemberId != null && memberKey == youMemberId);

bool outingExpenseIncludesYou(List<String> memberIds, String? youMemberId) =>
    memberIds.contains('you') ||
    (youMemberId != null && memberIds.contains(youMemberId));

/// Settlement / pending map key for the current user on this expense.
String outingYourMemberKey(List<String> memberIds, String? youMemberId) {
  if (memberIds.contains('you')) return 'you';
  if (youMemberId != null && memberIds.contains(youMemberId)) {
    return youMemberId;
  }
  return 'you';
}

/// One repayment from a member (cash, UPI, etc.) toward their split share.
class SettlementPayment {
  final double amount;
  final String mode;
  final DateTime date;

  const SettlementPayment({
    required this.amount,
    required this.mode,
    required this.date,
  });

  Map<String, dynamic> toJson() => {
    'amount': amount,
    'mode': mode,
    'date': date.toIso8601String(),
  };

  factory SettlementPayment.fromJson(Map<dynamic, dynamic> json) =>
      SettlementPayment(
        amount: (json['amount'] as num? ?? 0).toDouble(),
        mode: (json['mode'] ?? 'Cash').toString(),
        date: DateTime.parse(
          json['date']?.toString() ?? DateTime.now().toIso8601String(),
        ),
      );
}

class OutingExpense {
  final String id;
  final String title;
  final double amount;
  final String category;
  final DateTime date;
  final String paymentMode;
  final List<String> memberIds; // IDs of members involved in split
  final List<String>
  settledMemberIds; // IDs of members who have paid their share
  final SplitType splitType;
  final String? transactionId;
  final String? accountId;
  final String purpose; // Added purpose
  /// Who paid this bill (member id). Null / you id = you paid.
  final String? paidByMemberId;

  /// Original DB split mode for web-only split types (custom/percentage/shares).
  /// Kept for backward-compat with rows this device didn't author; new
  /// mobile-authored custom splits use [customSplitAmounts] instead.
  final String? remoteSplitType;

  /// Original DB split payload, preserved so mobile sync does not flatten it.
  final List<Map<String, dynamic>>? remoteSplits;
  final Map<String, String> settledModes; // memberId -> last mode (legacy)
  /// Partial repayments per member — supports e.g. ₹500 online + ₹500 cash.
  final Map<String, List<SettlementPayment>> settlementPayments;

  /// Real per-member amounts when [splitType] is [SplitType.custom] — set by
  /// mobile's own Custom split entry, or parsed from a web-authored custom
  /// split on pull. When null (or splitType isn't custom), every member's
  /// share is [perPersonShare] (equal division).
  final Map<String, double>? customSplitAmounts;

  OutingExpense({
    String? id,
    required this.title,
    required this.amount,
    required this.category,
    required this.date,
    this.paymentMode = 'Cash',
    this.memberIds = const ['you'],
    this.settledMemberIds = const [],
    this.splitType = SplitType.solo,
    this.transactionId,
    this.accountId,
    this.purpose = 'Personal',
    this.paidByMemberId,
    this.remoteSplitType,
    this.remoteSplits,
    this.settledModes = const {},
    this.settlementPayments = const {},
    this.customSplitAmounts,
  }) : id = id ?? const Uuid().v4();

  String effectivePaidBy(String? youMemberId) =>
      paidByMemberId ?? youMemberId ?? 'you';

  bool isPaidByYou(String? youMemberId) {
    if (youMemberId == null) return false;
    final payer = effectivePaidBy(youMemberId);
    return outingMemberIsYou(payer, youMemberId);
  }

  /// Your share still owed to whoever paid (when a friend paid).
  double amountYouOwe(String? youMemberId) {
    if (youMemberId == null ||
        !outingExpenseIncludesYou(memberIds, youMemberId)) {
      return 0;
    }
    if (isPaidByYou(youMemberId)) return 0;
    final key = outingYourMemberKey(memberIds, youMemberId);
    return pendingAmountForMember(key);
  }

  String paidByLabel(Outing outing) {
    final youId = outing.youMemberId;
    final payerId = youId != null ? effectivePaidBy(youId) : paidByMemberId;
    if (payerId == null || outingMemberIsYou(payerId, youId)) return 'You';
    return outing.memberDisplayName(payerId);
  }

  double get perPersonShare =>
      amount / (memberIds.isEmpty ? 1 : memberIds.length);

  /// This member's exact share — the custom amount when [splitType] is
  /// [SplitType.custom] and one is set for them, else the equal share.
  double shareForMember(String? memberId) {
    if (memberId == null || splitType != SplitType.custom) {
      return perPersonShare;
    }
    return customSplitAmounts?[memberId] ?? perPersonShare;
  }

  double settledAmountForMember(String memberId) {
    final list = settlementPayments[memberId] ?? const [];
    return list.fold(0.0, (sum, p) => sum + p.amount);
  }

  double pendingAmountForMember(String memberId) {
    final pending = shareForMember(memberId) - settledAmountForMember(memberId);
    return pending < 0.01 ? 0 : pending;
  }

  bool isMemberFullySettled(String memberId) =>
      pendingAmountForMember(memberId) <= 0;

  List<SettlementPayment> paymentsForMember(String memberId) =>
      List<SettlementPayment>.from(settlementPayments[memberId] ?? const []);

  /// Friends still owe you their share (only when you paid the bill).
  double pendingFromFriendsExcluding(String? youMemberId) {
    if (youMemberId == null || !isPaidByYou(youMemberId)) return 0;
    var total = 0.0;
    for (final mid in memberIds) {
      if (outingMemberIsYou(mid, youMemberId)) continue;
      total += pendingAmountForMember(mid);
    }
    return total;
  }

  /// Sum already returned by friends toward this expense (you paid).
  double returnedFromFriendsExcluding(String? youMemberId) {
    if (youMemberId == null || !isPaidByYou(youMemberId)) return 0;
    var total = 0.0;
    for (final entry in settlementPayments.entries) {
      if (outingMemberIsYou(entry.key, youMemberId)) continue;
      if (!memberIds.contains(entry.key)) continue;
      total += entry.value.fold(0.0, (s, p) => s + p.amount);
    }
    return total;
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'amount': amount,
    'category': category,
    'date': date.toIso8601String(),
    'paymentMode': paymentMode,
    'memberIds': memberIds,
    'settledMemberIds': settledMemberIds,
    'splitType': splitType.index,
    'transactionId': transactionId,
    'accountId': accountId,
    'purpose': purpose,
    if (paidByMemberId != null) 'paidByMemberId': paidByMemberId,
    if (remoteSplitType != null) 'remoteSplitType': remoteSplitType,
    if (remoteSplits != null) 'remoteSplits': remoteSplits,
    if (customSplitAmounts != null) 'customSplitAmounts': customSplitAmounts,
    'settledModes': settledModes,
    'settlementPayments': settlementPayments.map(
      (k, v) => MapEntry(k, v.map((p) => p.toJson()).toList()),
    ),
  };

  static Map<String, List<SettlementPayment>> _parseSettlementPayments(
    Map<dynamic, dynamic> json,
    double perShare,
  ) {
    final map = <String, List<SettlementPayment>>{};
    final raw = json['settlementPayments'];
    if (raw is Map) {
      raw.forEach((key, value) {
        if (value is! List) return;
        map[key.toString()] =
            value
                .map(
                  (e) => SettlementPayment.fromJson(
                    Map<dynamic, dynamic>.from(e as Map),
                  ),
                )
                .toList();
      });
    }

    if (map.isEmpty) {
      final settledIds = List<String>.from(
        json['settledMemberIds'] ?? const [],
      );
      final modes = Map<String, String>.from(json['settledModes'] ?? {});
      for (final mid in settledIds) {
        map[mid] = [
          SettlementPayment(
            amount: perShare,
            mode: modes[mid] ?? 'Cash',
            date: DateTime.parse(
              json['date']?.toString() ?? DateTime.now().toIso8601String(),
            ),
          ),
        ];
      }
    }
    return map;
  }

  factory OutingExpense.fromJson(Map<dynamic, dynamic> json) {
    final amt = (json['amount'] as num? ?? 0).toDouble();
    final members = List<String>.from(json['memberIds'] ?? ['you']);
    final perShare = amt / (members.isEmpty ? 1 : members.length);
    final payments = _parseSettlementPayments(json, perShare);
    final rawSplitType = json['splitType'];
    final splitIndex =
        rawSplitType is int
            ? rawSplitType
            : rawSplitType == 'equally'
            ? SplitType.equally.index
            : rawSplitType == 'custom'
            ? SplitType.custom.index
            : SplitType.solo.index;
    final rawRemoteSplits = json['remoteSplits'];
    final remoteSplits =
        rawRemoteSplits is List
            ? rawRemoteSplits
                .whereType<Map>()
                .map((e) => Map<String, dynamic>.from(e))
                .toList()
            : null;
    final rawCustomSplits = json['customSplitAmounts'];
    final customSplitAmounts =
        rawCustomSplits is Map
            ? rawCustomSplits.map(
              (k, v) => MapEntry(k.toString(), (v as num).toDouble()),
            )
            : null;

    return OutingExpense(
      id: json['id'] as String?,
      title: (json['title'] ?? 'Expense').toString(),
      amount: (json['amount'] as num? ?? 0).toDouble(),
      category: (json['category'] ?? 'Other').toString(),
      date: DateTime.parse(json['date'] ?? DateTime.now().toIso8601String()),
      paymentMode: (json['paymentMode'] ?? 'Cash').toString(),
      memberIds: List<String>.from(json['memberIds'] ?? ['you']),
      settledMemberIds: List<String>.from(json['settledMemberIds'] ?? []),
      splitType:
          SplitType.values[splitIndex.clamp(0, SplitType.values.length - 1)],
      transactionId: json['transactionId']?.toString(),
      accountId: json['accountId']?.toString(),
      purpose: (json['purpose'] ?? 'Personal').toString(),
      paidByMemberId: json['paidByMemberId']?.toString(),
      remoteSplitType: json['remoteSplitType']?.toString(),
      remoteSplits: remoteSplits,
      customSplitAmounts: customSplitAmounts,
      settledModes: Map<String, String>.from(json['settledModes'] ?? {}),
      settlementPayments: payments,
    );
  }

  OutingExpense copyWith({
    String? title,
    double? amount,
    String? category,
    DateTime? date,
    String? paymentMode,
    List<String>? memberIds,
    List<String>? settledMemberIds,
    SplitType? splitType,
    String? transactionId,
    String? accountId,
    String? purpose,
    String? paidByMemberId,
    String? remoteSplitType,
    List<Map<String, dynamic>>? remoteSplits,
    Map<String, String>? settledModes,
    Map<String, List<SettlementPayment>>? settlementPayments,
    Map<String, double>? customSplitAmounts,
  }) {
    return OutingExpense(
      id: id,
      title: title ?? this.title,
      amount: amount ?? this.amount,
      category: category ?? this.category,
      date: date ?? this.date,
      paymentMode: paymentMode ?? this.paymentMode,
      memberIds: memberIds ?? this.memberIds,
      settledMemberIds: settledMemberIds ?? this.settledMemberIds,
      splitType: splitType ?? this.splitType,
      transactionId: transactionId ?? this.transactionId,
      accountId: accountId ?? this.accountId,
      purpose: purpose ?? this.purpose,
      paidByMemberId: paidByMemberId ?? this.paidByMemberId,
      remoteSplitType: remoteSplitType ?? this.remoteSplitType,
      remoteSplits: remoteSplits ?? this.remoteSplits,
      // Pass an empty map (not null) to explicitly clear a previous custom
      // split when switching away from Custom — null here means "keep".
      customSplitAmounts: customSplitAmounts ?? this.customSplitAmounts,
      settledModes: settledModes ?? this.settledModes,
      settlementPayments: settlementPayments ?? this.settlementPayments,
    );
  }

  double get userShare => perPersonShare;

  /// Money returned by friends (excludes your own repayments to others).
  double currentImpactExcludingYou(String? youMemberId) {
    var received = 0.0;
    for (final entry in settlementPayments.entries) {
      if (youMemberId != null && entry.key == youMemberId) continue;
      if (!memberIds.contains(entry.key)) continue;
      received += entry.value.fold(0.0, (s, p) => s + p.amount);
    }
    return amount - received;
  }

  double get totalFriendsShare => amount - userShare;

  /// Prefer [pendingFromFriendsExcluding] on [Outing] with You member id.
  double get pendingFriendShare {
    var total = 0.0;
    for (final mid in memberIds) {
      total += pendingAmountForMember(mid);
    }
    return total;
  }
}

class Outing {
  final String id;
  final String title;
  final String category;
  final String? location;
  final DateTime startDate;
  final DateTime endDate;
  final List<OutingMember> members;
  final List<OutingExpense> expenses;
  final bool isActive;
  final bool isAutoMode;
  final String status;

  /// Applied to this outing's rollup + auto-linked transactions, so the
  /// user isn't asked to pick a purpose per-transaction while it's open.
  final String purpose;
  final double? budget;

  Outing({
    String? id,
    required this.title,
    required this.category,
    this.location,
    required this.startDate,
    required this.endDate,
    this.members = const [],
    this.expenses = const [],
    this.isActive = true,
    this.isAutoMode = true,
    this.status = 'active',
    this.purpose = 'Personal',
    this.budget,
  }) : id = id ?? const Uuid().v4();

  // 1. Total Trip Spend (Gross)
  double get totalGrossSpend => expenses.fold(0.0, (sum, e) => sum + e.amount);

  /// Total amount YOU personally paid across this trip's expenses (gross —
  /// before any returns), regardless of split. Matches web's "Total your
  /// spent" KPI card.
  double get yourPaidTotal {
    final youId = youMemberId;
    if (youId == null) return 0;
    return expenses.fold(
      0.0,
      (sum, e) => e.isPaidByYou(youId) ? sum + e.amount : sum,
    );
  }

  // 2. Your Current Financial Impact (What you haven't been paid back yet)
  double get userNetCost {
    final youId =
        members.where((m) => m.name.toLowerCase() == 'you').firstOrNull?.id;
    return expenses.fold(
      0.0,
      (sum, e) => sum + e.currentImpactExcludingYou(youId),
    );
  }

  // 3. Pending from Friends
  double get pendingFromFriends {
    final youId = youMemberId;
    return expenses.fold(
      0.0,
      (sum, e) => sum + e.pendingFromFriendsExcluding(youId),
    );
  }

  double get totalReturnedFromFriends {
    final youId = youMemberId;
    return expenses.fold(
      0.0,
      (sum, e) => sum + e.returnedFromFriendsExcluding(youId),
    );
  }

  /// Sum of your per-person shares across split expenses.
  double get yourSplitShareTotal {
    final youId = youMemberId;
    return expenses.fold(0.0, (sum, e) {
      if (!outingExpenseIncludesYou(e.memberIds, youId)) return sum;
      return sum + e.shareForMember(youId);
    });
  }

  /// Gross amount you paid for equally-split expenses (your "spent" on splits).
  double get mySplitContributed {
    final youId = youMemberId;
    if (youId == null) return 0.0;
    return expenses.fold(0.0, (sum, e) {
      if (e.splitType != SplitType.equally || e.memberIds.length <= 1) {
        return sum;
      }
      if (!e.isPaidByYou(youId)) return sum;
      return sum + e.amount;
    });
  }

  /// Per-friend: gross amount the friend paid for equally-split expenses (their "spent" on splits).
  Map<String, double> friendsSplitContributed() {
    final youId = youMemberId;
    if (youId == null) return {};
    final map = <String, double>{};
    for (final e in expenses) {
      if (e.splitType != SplitType.equally || e.memberIds.length <= 1) continue;
      if (e.isPaidByYou(youId)) continue;
      final payerId = e.effectivePaidBy(youId);
      if (outingMemberIsYou(payerId, youId)) continue;
      final name = memberDisplayName(payerId);
      map[name] = (map[name] ?? 0.0) + e.amount;
    }
    return map;
  }

  String? get youMemberId =>
      members.where((m) => m.name.toLowerCase() == 'you').firstOrNull?.id;

  bool isYouMemberKey(String memberKey) =>
      outingMemberIsYou(memberKey, youMemberId);

  bool expenseIncludesYou(OutingExpense e) =>
      outingExpenseIncludesYou(e.memberIds, youMemberId);

  String memberDisplayName(String memberKey) {
    if (isYouMemberKey(memberKey)) return 'You';
    final m = members.where((x) => x.id == memberKey).firstOrNull;
    return m?.name ?? 'Friend';
  }

  /// Per-friend: still pending toward you (you paid) or you owe them (they paid).
  Map<String, ({double pendingToYou, double youOwe})> friendBalanceSummary() {
    final youId = youMemberId;
    final map = <String, ({double pendingToYou, double youOwe})>{};
    if (youId == null) return map;

    for (final e in expenses) {
      if (e.isPaidByYou(youId)) {
        for (final mid in e.memberIds) {
          if (isYouMemberKey(mid)) continue;
          final pending = e.pendingAmountForMember(mid);
          if (pending < 0.01) continue;
          final name = memberDisplayName(mid);
          final cur = map[name] ?? (pendingToYou: 0.0, youOwe: 0.0);
          map[name] = (
            pendingToYou: cur.pendingToYou + pending,
            youOwe: cur.youOwe,
          );
        }
      } else {
        final owed = e.amountYouOwe(youId);
        if (owed < 0.01) continue;
        final name = e.paidByLabel(this);
        if (name.toLowerCase() == 'you') continue;
        final cur = map[name] ?? (pendingToYou: 0.0, youOwe: 0.0);
        map[name] = (pendingToYou: cur.pendingToYou, youOwe: cur.youOwe + owed);
      }
    }
    return map;
  }

  /// Total you still owe friends who paid for trip expenses. (gross, before netting what they owe you)
  double get youOweToFriends {
    final youId = youMemberId;
    if (youId == null) return 0;
    return expenses.fold(0.0, (sum, e) => sum + e.amountYouOwe(youId));
  }

  /// Net total you owe friends (after auto subtracting what they owe you). For remaining balance display.
  double get youOweToFriendsNet {
    final bals = friendBalanceSummary();
    return bals.values.fold(
      0.0,
      (s, b) => s + (b.youOwe - b.pendingToYou).clamp(0.0, double.infinity),
    );
  }

  /// True if there are unsettled balances between you and any member on this outing.
  bool get hasPendingBalances {
    for (final b in friendBalanceSummary().values) {
      if ((b.pendingToYou - b.youOwe).abs() > 0.01) return true;
    }
    return false;
  }

  /// Total net amount friends owe you on this outing (positive).
  double get totalNetOwedToYou {
    double total = 0.0;
    for (final b in friendBalanceSummary().values) {
      final net = b.pendingToYou - b.youOwe;
      if (net > 0.01) total += net;
    }
    return total;
  }

  /// friend name -> net amount you owe them (after auto-netting what they owe you back).
  /// Used to suggest the actual remaining to send without manual calc.
  Map<String, double> youOweByFriendName() {
    final youId = youMemberId;
    if (youId == null) return {};
    final balances = friendBalanceSummary();
    final map = <String, double>{};
    for (final entry in balances.entries) {
      final netOwe = entry.value.youOwe - entry.value.pendingToYou;
      if (netOwe > 0.01) {
        map[entry.key] = netOwe;
      }
    }
    return map;
  }

  double get totalSpent =>
      userNetCost; // Maintain compatibility but point to user share

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'category': category,
    'location': location,
    'startDate': startDate.toIso8601String(),
    'endDate': endDate.toIso8601String(),
    'members': members.map((m) => m.toJson()).toList(),
    'expenses': expenses.map((e) => e.toJson()).toList(),
    'isActive': isActive,
    'isAutoMode': isAutoMode,
    'status': status,
    'purpose': purpose,
    if (budget != null) 'budget': budget,
  };

  factory Outing.fromJson(Map<dynamic, dynamic> json) => Outing(
    id: json['id'] as String?,
    title: (json['title'] ?? json['name'] ?? 'Untitled Trip').toString(),
    category: (json['category'] ?? 'Trip').toString(),
    location: json['location']?.toString(),
    startDate: DateTime.parse(
      json['startDate'] ?? DateTime.now().toIso8601String(),
    ),
    endDate: DateTime.parse(
      json['endDate'] ?? DateTime.now().toIso8601String(),
    ),
    members:
        (json['members'] as List? ?? [])
            .map((m) => OutingMember.fromJson(m ?? {}))
            .toList(),
    expenses:
        (json['expenses'] as List? ?? [])
            .map((e) => OutingExpense.fromJson(e ?? {}))
            .toList(),
    isActive: json['isActive'] ?? true,
    isAutoMode: json['isAutoMode'] ?? false,
    status:
        (json['status'] ?? (json['isActive'] == false ? 'completed' : 'active'))
            .toString(),
    purpose: (json['purpose'] ?? 'Personal').toString(),
    budget: (json['budget'] as num?)?.toDouble(),
  );

  Outing copyWith({
    String? title,
    String? category,
    String? location,
    DateTime? startDate,
    DateTime? endDate,
    List<OutingMember>? members,
    List<OutingExpense>? expenses,
    bool? isActive,
    bool? isAutoMode,
    String? status,
    String? purpose,
    double? budget,
  }) {
    return Outing(
      id: id,
      title: title ?? this.title,
      category: category ?? this.category,
      location: location ?? this.location,
      startDate: startDate ?? this.startDate,
      endDate: endDate ?? this.endDate,
      members: members ?? this.members,
      expenses: expenses ?? this.expenses,
      isActive: isActive ?? this.isActive,
      isAutoMode: isAutoMode ?? this.isAutoMode,
      status: status ?? this.status,
      purpose: purpose ?? this.purpose,
      budget: budget ?? this.budget,
    );
  }
}

// ── NOTIFIER ──

class OutingNotifier extends StateNotifier<List<Outing>> {
  final Ref ref;
  Box get _box => Hive.box('outings');
  Box get _settings => Hive.box('settings');

  OutingNotifier(this.ref) : super([]) {
    _loadFromStorage();
  }

  /// Reload outings from Hive after a background sync pull.
  void reloadFromStorage() => _loadFromStorage();

  void _loadFromStorage() {
    try {
      final List<Outing> loaded = [];
      // 1. Support new key-based storage (Preferred)
      for (var key in _box.keys) {
        if (key == 'list') continue; // Skip legacy key here
        final e = _box.get(key);
        if (e is Map) {
          try {
            final o = Outing.fromJson(e);
            if (!loaded.any((existing) => existing.id == o.id)) loaded.add(o);
          } catch (err) {
            debugPrint('Error parsing outing with key $key: $err');
          }
        }
      }

      // 2. Fallback to legacy list storage if nothing found or to merge
      final legacy = _box.get('list');
      if (legacy is List) {
        for (var e in legacy) {
          try {
            final o = Outing.fromJson(e);
            if (!loaded.any((existing) => existing.id == o.id)) loaded.add(o);
          } catch (err) {
            debugPrint('Error parsing legacy outing: $err');
          }
        }
      }

      state = loaded..sort((a, b) => b.startDate.compareTo(a.startDate));
      expireEndedOutings(silent: true);
      reconcileTransactionExpenses();
    } catch (e, stack) {
      debugPrint('CRITICAL: Outing storage load failed: $e');
      debugPrint(stack.toString());
      state = [];
    }
  }

  /// Default system list (must include Other for "add custom" UX).
  static const List<String> defaultOutingCategories = [
    'Trip',
    'Temple',
    'Restaurant',
    'Movies',
    'Family',
    'Work',
    'Other',
  ];

  List<String> get globalCategories {
    final raw = _settings.get(
      'outing_categories',
      defaultValue: defaultOutingCategories,
    );
    final list =
        (raw is List)
            ? raw
                .map((e) => e.toString().trim())
                .where((e) => e.isNotEmpty)
                .toList()
            : List<String>.from(defaultOutingCategories);
    // Always expose system defaults even if older local list is short.
    final merged = <String>[];
    final seen = <String>{};
    for (final c in [...defaultOutingCategories, ...list]) {
      final key = c.toLowerCase();
      if (seen.contains(key)) continue;
      seen.add(key);
      merged.add(c);
    }
    // Keep Other last.
    merged.sort((a, b) {
      if (a == 'Other') return 1;
      if (b == 'Other') return -1;
      return a.toLowerCase().compareTo(b.toLowerCase());
    });
    return merged;
  }

  void addGlobalCategory(String cat) {
    final name = cat.trim();
    if (name.isEmpty || name.toLowerCase() == 'other') return;
    final cur = globalCategories;
    if (cur.any((c) => c.toLowerCase() == name.toLowerCase())) {
      // Still select it for the form via caller setState.
      return;
    }
    final withoutOther = cur.where((c) => c != 'Other').toList();
    final next = [...withoutOther, name, if (cur.contains('Other')) 'Other'];
    _settings.put('outing_categories', next);
    state = [...state]; // Force rebuild listeners
    // Best-effort push to Supabase outing_categories.
    try {
      SyncService.queueOutingCategoryUpsert(name);
    } catch (_) {}
  }

  void deleteGlobalCategory(String cat) {
    final name = cat.trim();
    if (name.isEmpty ||
        defaultOutingCategories.any(
          (d) => d.toLowerCase() == name.toLowerCase(),
        )) {
      return; // never delete system defaults
    }
    final cur = globalCategories;
    if (cur.any((c) => c.toLowerCase() == name.toLowerCase())) {
      final updated =
          cur.where((c) => c.toLowerCase() != name.toLowerCase()).toList();
      _settings.put('outing_categories', updated);
      state = [...state];
    }
  }

  /// Replace local list from server pull (names only).
  void replaceGlobalCategories(List<String> names) {
    final cleaned =
        names.map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
    if (cleaned.isEmpty) return;
    final merged = <String>[];
    final seen = <String>{};
    for (final c in [...defaultOutingCategories, ...cleaned]) {
      final key = c.toLowerCase();
      if (seen.contains(key)) continue;
      seen.add(key);
      merged.add(c);
    }
    merged.sort((a, b) {
      if (a == 'Other') return 1;
      if (b == 'Other') return -1;
      return a.toLowerCase().compareTo(b.toLowerCase());
    });
    _settings.put('outing_categories', merged);
    state = [...state];
  }

  /// Persist + enqueue for Supabase sync (Hive-first, queue after).
  void _putAndSync(Outing o) {
    final json = o.toJson();
    // gross trip total for web total_spent (sum of expense rows).
    final gross = o.expenses.fold<double>(0, (s, e) => s + e.amount);
    json['totalSpent'] = gross;
    _box.put(o.id, json);
    SyncService.queueOutingUpsert(Map<String, dynamic>.from(json));
  }

  /// After expense list changes: rewrite "Outing total" rollup + push total_spent.
  void _scheduleTotalRefresh(String outingId) {
    Future.microtask(() {
      try {
        refreshOutingTotalSpent(ref, outingId);
      } catch (e, st) {
        debugPrint('refreshOutingTotalSpent failed: $e\n$st');
      }
    });
  }

  /// Creates a trip. Only one open outing is allowed.
  ///
  /// Expires stale trips first, then heals ghost `isActive` flags that the UI
  /// does not treat as active (so create is never blocked by invisible trips).
  /// Start/end dates drive lifecycle: open from create, **running** from start
  /// date, **completed** automatically after end date.
  Future<void> createOuting(Outing outing) async {
    expireEndedOutings(silent: true);
    _healGhostActiveFlags();

    final blocking = state.where((o) => o.isActive).firstOrNull;
    if (blocking != null) {
      throw StateError('End “${blocking.title}” before starting a new trip.');
    }

    final created = _applyDateLifecycle(outing);
    state = [created, ...state];
    _putAndSync(created);
  }

  /// Clear past-end open flags and ensure at most one open trip remains.
  void _healGhostActiveFlags() {
    final today = outingLocalDay(DateTime.now());

    // Prefer a currently-running open trip; else first open trip by list order.
    Outing? keep;
    for (final o in state) {
      if (!o.isActive) continue;
      if (o.status == 'archived' || o.status == 'cancelled') continue;
      final endDay = outingLocalDay(o.endDate);
      if (endDay.isBefore(today)) continue; // expired — will complete
      if (outingIsCurrentlyRunning(o)) {
        keep = o;
        break;
      }
      keep ??= o;
    }

    final changedIds = <String>{};
    final updated = <Outing>[];
    for (final o in state) {
      if (!o.isActive || o.status == 'archived' || o.status == 'cancelled') {
        updated.add(o);
        continue;
      }
      final endDay = outingLocalDay(o.endDate);
      final pastEnd = endDay.isBefore(today);
      final shouldStayOpen = keep != null && o.id == keep.id && !pastEnd;
      if (shouldStayOpen) {
        // Ensure status is active while the trip is still open.
        if (o.status != 'active') {
          changedIds.add(o.id);
          updated.add(o.copyWith(status: 'active', isActive: true));
        } else {
          updated.add(o);
        }
      } else if (pastEnd) {
        changedIds.add(o.id);
        updated.add(o.copyWith(status: 'completed', isActive: false));
      } else {
        // Extra open trip while another is open — close without rewriting dates.
        changedIds.add(o.id);
        updated.add(o.copyWith(status: 'completed', isActive: false));
      }
    }

    if (changedIds.isNotEmpty) {
      state = updated;
      for (final o in state) {
        if (changedIds.contains(o.id)) _putAndSync(o);
      }
    }
  }

  Future<void> endOutingEarly(String id) async {
    state = [
      for (final o in state)
        if (o.id == id)
          o.copyWith(
            status: 'completed',
            isActive: false,
            endDate: DateTime.now(),
          )
        else
          o,
    ];
    final updated = state.where((o) => o.id == id).firstOrNull;
    if (updated == null) return;
    _putAndSync(updated);
  }

  Future<void> completeOuting(String id) async {
    state = [
      for (final o in state)
        if (o.id == id)
          o.copyWith(
            status: 'completed',
            isActive: false,
            endDate: DateTime.now(),
          )
        else
          o,
    ];
    final updated = state.where((o) => o.id == id).firstOrNull;
    if (updated == null) return;
    _putAndSync(updated);
  }

  Future<void> archiveOuting(String id) async {
    state = [
      for (final o in state)
        if (o.id == id) o.copyWith(status: 'archived', isActive: false) else o,
    ];
    final updated = state.where((o) => o.id == id).firstOrNull;
    if (updated == null) return;
    _putAndSync(updated);
  }

  Future<void> cancelOuting(String id) async {
    state = [
      for (final o in state)
        if (o.id == id) o.copyWith(status: 'cancelled', isActive: false) else o,
    ];
    final updated = state.where((o) => o.id == id).firstOrNull;
    if (updated == null) return;
    _putAndSync(updated);
  }

  Future<void> updateOuting(Outing outing) async {
    // Re-apply date lifecycle when start/end are edited (e.g. extend end date).
    final reconciled = _applyDateLifecycle(outing);
    state = [
      for (final o in state)
        if (o.id == outing.id) reconciled else o,
    ];
    _putAndSync(reconciled);
    expireEndedOutings(silent: true);
  }

  /// Derive open/active/completed flags from [startDate]/[endDate].
  ///
  /// - Before start: open + upcoming (`isActive`, status active)
  /// - Start…end inclusive: active (running when today is in range)
  /// - After end day: completed automatically
  /// Archived/cancelled are never auto-changed.
  Outing _applyDateLifecycle(Outing o) {
    if (o.status == 'archived' || o.status == 'cancelled') return o;
    // A trip already completed (including early complete) stays completed.
    // Re-applying dates on an expense edit must not open it again the same day.
    if (o.status == 'completed' && !o.isActive) return o;
    final today = outingLocalDay(DateTime.now());
    final endDay = outingLocalDay(o.endDate);
    if (endDay.isBefore(today)) {
      return o.copyWith(status: 'completed', isActive: false);
    }
    return o.copyWith(status: 'active', isActive: true);
  }

  /// Delete outing locally + queue server delete.
  /// Call [cascadeOutingLedgerCleanup] from UI with a transaction notifier
  /// first so linked spends become normal and rollups are removed.
  Future<void> deleteOuting(String id) async {
    state = state.where((o) => o.id != id).toList();
    await _box.delete(id);
    SyncService.queueOutingDelete(id);
  }

  Outing? get activeOuting {
    return state.where(outingIsCurrentlyRunning).firstOrNull;
  }

  /// Date-driven outing lifecycle (call on launch, resume, Outings screen):
  ///
  /// - **Start date** → trip is open/active (banner + SMS auto-link once today
  ///   is on/after start — see [outingIsCurrentlyRunning]).
  /// - **End date** → after the end calendar day fully passes, trip is marked
  ///   `status: completed` + `isActive: false` automatically (end date kept).
  void expireEndedOutings({bool silent = false}) {
    final today = outingLocalDay(DateTime.now());
    final changedIds = <String>{};

    final updated = <Outing>[];
    for (final o in state) {
      // Never auto-touch archived / cancelled history.
      if (o.status == 'archived' || o.status == 'cancelled') {
        updated.add(o);
        continue;
      }

      final endDay = outingLocalDay(o.endDate);
      // Trip stays open through the full last calendar day; complete the
      // morning after end date.
      if (endDay.isBefore(today)) {
        if (o.isActive || o.status != 'completed') {
          changedIds.add(o.id);
          if (!silent) {
            debugPrint(
              'Outing "${o.title}" auto-completed (end date ${endDay.toIso8601String().split('T').first} passed)',
            );
          }
          updated.add(o.copyWith(status: 'completed', isActive: false));
        } else {
          updated.add(o);
        }
        continue;
      }

      // Still within (or before) schedule: keep open as active so start date
      // makes it "running" without a second user action.
      if (!o.isActive || o.status != 'active') {
        // Only re-open if user hasn't manually completed early with endDate
        // still in the future... Manual complete sets endDate=now, so after
        // end day it falls into the completed branch above. If they completed
        // early and we rewrote endDate to now, endDay is today — still open
        // through today; next day completes. Good.
        // If status is completed but end is still in the future (legacy data
        // without endDate rewrite), leave completed — don't revive.
        if (o.status == 'completed' && !o.isActive) {
          updated.add(o);
        } else {
          changedIds.add(o.id);
          updated.add(o.copyWith(status: 'active', isActive: true));
        }
      } else {
        updated.add(o);
      }
    }

    if (changedIds.isNotEmpty) {
      state = updated;
      for (final o in state) {
        if (changedIds.contains(o.id)) _putAndSync(o);
      }
    }
    // Collapse multi-active leftovers so create + UI stay aligned.
    _healGhostActiveFlags();
  }

  void addExpenseToActive(OutingExpense expense) {
    final active = state.where(outingIsCurrentlyRunning).firstOrNull;
    if (active != null) {
      updateOuting(active.copyWith(expenses: [...active.expenses, expense]));
      _scheduleTotalRefresh(active.id);
    }
  }

  void addExpenseToOuting(String outingId, OutingExpense expense) {
    final o = state.where((o) => o.id == outingId).firstOrNull;
    if (o != null) {
      updateOuting(o.copyWith(expenses: [...o.expenses, expense]));
      _scheduleTotalRefresh(outingId);
    }
  }

  void deleteExpense(String outingId, String expenseId) {
    final o = state.where((o) => o.id == outingId).firstOrNull;
    if (o != null) {
      updateOuting(
        o.copyWith(
          expenses: o.expenses.where((e) => e.id != expenseId).toList(),
        ),
      );
      _scheduleTotalRefresh(outingId);
    }
  }

  OutingExpense? expenseForTransaction(String outingId, String transactionId) {
    final o = state.where((o) => o.id == outingId).firstOrNull;
    if (o == null) return null;
    return o.expenses
        .where((e) => e.transactionId == transactionId)
        .firstOrNull;
  }

  /// Creates or updates trip expense row for a linked transaction (auto-split if friends on trip).
  void syncTransactionExpense({
    required String outingId,
    required String transactionId,
    required String title,
    required double amount,
    required String category,
    required DateTime date,
    required String paymentMode,
    required String? accountId,
    String purpose = 'Personal',
    SplitType? splitType,
    List<String>? memberIds,
    String? paidByMemberId,
    Map<String, double>? customSplitAmounts,
  }) {
    final o = state.where((o) => o.id == outingId).firstOrNull;
    if (o == null) return;

    final existing = expenseForTransaction(outingId, transactionId);
    final youId = o.youMemberId;
    final expense = OutingTransactionSync.buildExpense(
      outing: o,
      transactionId: transactionId,
      title: title,
      amount: amount,
      category: category,
      date: date,
      paymentMode: paymentMode,
      accountId: accountId,
      purpose: purpose,
      existing: existing,
      splitType: splitType,
      memberIds: memberIds,
      // Who paid is the expense's own fact, not the ledger row's. Falling
      // straight through to "you" re-homed a friend-paid bill onto you every
      // time the linked transaction was re-synced — including the merchant
      // rename this sheet exists for. Only a caller that actually says who
      // paid may change it.
      paidByMemberId: paidByMemberId ?? existing?.paidByMemberId ?? youId,
      customSplitAmounts: customSplitAmounts,
    );

    if (existing != null) {
      updateExpense(outingId, expense);
    } else {
      addExpenseToOuting(outingId, expense);
    }
    // add/updateExpense already schedule refresh when going through those methods;
    // keep an extra tick after linked-tx sync so amount edits always land.
    _scheduleTotalRefresh(outingId);
  }

  /// `Transaction.isSimpleTransaction` read straight off a stored Hive row.
  ///
  /// The backfill below works on raw maps because this provider cannot import
  /// `transaction_provider` (that dependency already runs the other way), so
  /// the rule is spelled out against the same JSON keys `Transaction.toJson`
  /// writes. Keep the two in step: a transfer or a divided amount — Friend
  /// Split, Purpose Split, Category Split, per-item allocation — has no single
  /// amount + category + purpose to carry into a trip, so it is never
  /// backfilled as a trip expense.
  static bool _rawTxCanBecomeTripExpense(Map<String, dynamic> map) {
    if (map['isTransfer'] == true) return false;
    if (map['isGroup'] == true) return false;
    if ((map['groupCount'] as num? ?? 0) > 0) return false;
    if (((map['splits'] as List?)?.length ?? 0) > 1) return false;
    if (((map['items'] as List?)?.length ?? 0) > 1) return false;
    return true;
  }

  /// Backfill outing expenses for transactions already tagged with [outingId].
  void reconcileTransactionExpenses() {
    if (!Hive.isBoxOpen('transactions')) return;
    final txBox = Hive.box('transactions');
    final List<dynamic> raw = txBox.get('list', defaultValue: []);
    var changed = false;
    final updatedOutings = <Outing>[];

    for (final o in state) {
      var outing = o;
      for (final rawTx in raw) {
        if (rawTx is! Map) continue;
        final map = Map<String, dynamic>.from(rawTx);
        if (map['outingId']?.toString() != o.id) continue;
        if (map['isExpense'] == false) continue;
        if (!_rawTxCanBecomeTripExpense(map)) continue;
        final txId = map['id']?.toString();
        if (txId == null) continue;
        if (outing.expenses.any((e) => e.transactionId == txId)) continue;

        final expense = OutingTransactionSync.buildExpense(
          outing: outing,
          transactionId: txId,
          title: map['merchant']?.toString() ?? 'Expense',
          amount: (map['amount'] as num? ?? 0).toDouble(),
          category: map['category']?.toString() ?? 'Other',
          date: DateTime.parse(
            map['date']?.toString() ?? DateTime.now().toIso8601String(),
          ),
          paymentMode: map['paymentType']?.toString() ?? 'Online',
          accountId: map['account']?.toString(),
          purpose: map['purpose']?.toString() ?? 'Personal',
        );
        outing = outing.copyWith(expenses: [...outing.expenses, expense]);
        changed = true;
      }
      updatedOutings.add(outing);
    }

    if (changed) {
      state = updatedOutings;
      for (final o in state) {
        _putAndSync(o);
      }
    }
  }

  void removeExpenseByTransactionId(String outingId, String transactionId) {
    final o = state.where((o) => o.id == outingId).firstOrNull;
    if (o != null) {
      final updated =
          o.expenses.where((e) => e.transactionId != transactionId).toList();
      updateOuting(o.copyWith(expenses: updated));
      _scheduleTotalRefresh(outingId);
    }
  }

  void updateExpense(String outingId, OutingExpense expense) {
    final o = state.where((o) => o.id == outingId).firstOrNull;
    if (o != null) {
      final updated = [
        for (final e in o.expenses)
          if (e.id == expense.id) expense else e,
      ];
      updateOuting(o.copyWith(expenses: updated));
      _scheduleTotalRefresh(outingId);
    }
  }

  OutingExpense _syncLegacySettlementFlags(
    OutingExpense expense,
    String memberId,
  ) {
    final total = expense.settledAmountForMember(memberId);
    final share = expense.shareForMember(memberId);
    var settledIds = List<String>.from(expense.settledMemberIds);
    final modes = Map<String, String>.from(expense.settledModes);

    if (total >= share - 0.01) {
      if (!settledIds.contains(memberId)) settledIds.add(memberId);
      final payments = expense.paymentsForMember(memberId);
      if (payments.isNotEmpty) {
        modes[memberId] = payments.last.mode;
      }
    } else {
      settledIds.remove(memberId);
      modes.remove(memberId);
    }

    return expense.copyWith(settledMemberIds: settledIds, settledModes: modes);
  }

  /// Record part of a member's share (cash, UPI, online — any mix).
  void recordMemberSettlement(
    String outingId,
    String expenseId,
    String memberId, {
    required double amount,
    required String mode,
    DateTime? date,
  }) {
    if (amount <= 0) return;
    final o = state.where((o) => o.id == outingId).firstOrNull;
    if (o == null) return;

    final updated = [
      for (final e in o.expenses)
        if (e.id == expenseId)
          _syncLegacySettlementFlags(
            e.copyWith(
              settlementPayments: {
                ...e.settlementPayments,
                memberId: [
                  ...e.paymentsForMember(memberId),
                  SettlementPayment(
                    amount: amount,
                    mode: mode,
                    date: date ?? DateTime.now(),
                  ),
                ],
              },
            ),
            memberId,
          )
        else
          e,
    ];
    updateOuting(o.copyWith(expenses: updated));
  }

  /// Reverts/removes the most recent settlement payment for a member on an outing expense
  void revertMemberSettlement({
    required String outingId,
    String? expenseId,
    required String memberId,
    required double amount,
  }) {
    final o = state.where((o) => o.id == outingId).firstOrNull;
    if (o == null) return;

    final updated = [
      for (final e in o.expenses)
        if (expenseId == null || e.id == expenseId)
          (() {
            final payments = List<SettlementPayment>.from(
              e.paymentsForMember(memberId),
            );
            final idx = payments.lastIndexWhere(
              (p) => (p.amount - amount).abs() < 0.01,
            );
            if (idx >= 0) {
              payments.removeAt(idx);
              return _syncLegacySettlementFlags(
                e.copyWith(
                  settlementPayments: {
                    ...e.settlementPayments,
                    memberId: payments,
                  },
                ),
                memberId,
              );
            }
            return e;
          })()
        else
          e,
    ];
    updateOuting(o.copyWith(expenses: updated));
  }

  void settleMember(
    String outingId,
    String expenseId,
    String memberId, {
    String mode = 'Cash',
    String? accountId,
  }) {
    final o = state.where((o) => o.id == outingId).firstOrNull;
    final expense = o?.expenses.where((e) => e.id == expenseId).firstOrNull;
    if (expense == null) return;
    final pending = expense.pendingAmountForMember(memberId);
    if (pending <= 0) return;
    recordMemberSettlement(
      outingId,
      expenseId,
      memberId,
      amount: pending,
      mode: mode,
    );
  }

  /// Reverts/removes a settlement payment when a repayment transaction is deleted in the ledger.
  void revertSettlementByFriendOrTx({
    String? outingId,
    required String friendName,
    required double amount,
  }) {
    final cleanFriendName =
        friendName.toLowerCase().replaceAll('from ', '').trim();
    final updatedList = <Outing>[];
    bool anyChanged = false;

    for (final o in state) {
      if (outingId != null && outingId.isNotEmpty && o.id != outingId) {
        updatedList.add(o);
        continue;
      }
      final member =
          o.members
              .where((m) => m.name.toLowerCase() == cleanFriendName)
              .firstOrNull;
      if (member == null) {
        updatedList.add(o);
        continue;
      }

      bool outingChanged = false;
      final updatedExpenses = <OutingExpense>[];
      for (final e in o.expenses) {
        final payments = List<SettlementPayment>.from(
          e.paymentsForMember(member.id),
        );
        final idx = payments.lastIndexWhere(
          (p) => (p.amount - amount).abs() < 0.01,
        );
        if (idx >= 0 && !outingChanged) {
          payments.removeAt(idx);
          outingChanged = true;
          anyChanged = true;
          updatedExpenses.add(
            _syncLegacySettlementFlags(
              e.copyWith(
                settlementPayments: {
                  ...e.settlementPayments,
                  member.id: payments,
                },
              ),
              member.id,
            ),
          );
        } else {
          updatedExpenses.add(e);
        }
      }

      if (outingChanged) {
        final updatedOuting = o.copyWith(expenses: updatedExpenses);
        updatedList.add(updatedOuting);
        _putAndSync(updatedOuting);
      } else {
        updatedList.add(o);
      }
    }

    if (anyChanged) {
      state = updatedList;
    }
  }
}

final outingProvider = StateNotifierProvider<OutingNotifier, List<Outing>>(
  (ref) => OutingNotifier(ref),
);

/// True when [day] falls on or between the outing's start/end calendar days.
/// Calendar day in the user's zone. UTC timestamps from sync use their
/// local date, which is the day the trip card shows.
DateTime outingLocalDay(DateTime d) {
  final local = d.toLocal();
  return DateTime(local.year, local.month, local.day);
}

bool outingRunsOnCalendarDay(Outing o, DateTime day) {
  final d = outingLocalDay(day);
  final start = outingLocalDay(o.startDate);
  final end = outingLocalDay(o.endDate);
  return !d.isBefore(start) && !d.isAfter(end);
}

/// Trip is marked active and today is within its scheduled dates.
/// Used for SMS auto-tag, home banner, privacy mode, etc.
bool outingIsCurrentlyRunning(Outing o) {
  return o.isActive && outingRunsOnCalendarDay(o, DateTime.now());
}

/// Trip still has `isActive` and has not passed its end date (includes
/// upcoming scheduled trips that are not yet in their date window).
/// Used for “one open trip” UI (create FAB / Outings list).
bool outingIsOpen(Outing o) {
  if (!o.isActive) return false;
  final today = outingLocalDay(DateTime.now());
  final endDay = outingLocalDay(o.endDate);
  return !endDay.isBefore(today);
}

/// Currently running trip (today ∈ [start, end] and isActive).
final activeOutingProvider = Provider<Outing?>((ref) {
  final list = ref.watch(outingProvider);
  return list.where(outingIsCurrentlyRunning).firstOrNull;
});

/// Any open trip that blocks creating another (isActive, end date not past).
final openOutingProvider = Provider<Outing?>((ref) {
  final list = ref.watch(outingProvider);
  // Prefer currently running, else any open (e.g. upcoming).
  return list.where(outingIsCurrentlyRunning).firstOrNull ??
      list.where(outingIsOpen).firstOrNull;
});

/// Most recent completed trip that still has unsettled friend balances.
final unsettledCompletedOutingProvider = Provider<Outing?>((ref) {
  final list = ref.watch(outingProvider);
  final now = DateTime.now();
  for (final o in list) {
    if (o.status == 'completed' || !o.isActive) {
      final daysAgo = now.difference(o.endDate).inDays;
      if (daysAgo >= 0 && daysAgo <= 30 && o.hasPendingBalances) {
        return o;
      }
    }
  }
  return null;
});
