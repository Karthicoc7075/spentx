import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../../../core/utils/outing_totals.dart';
import '../../../core/providers/outing_provider.dart';
import '../../../core/providers/private_mode_provider.dart';
import '../../../core/providers/transaction_provider.dart' as model;

/// User preference: hide non-trip data while a trip is running.
final outingPrivacyModeProvider =
    StateNotifierProvider<OutingPrivacyNotifier, bool>((ref) {
  return OutingPrivacyNotifier(ref);
});

/// Switch is only interactive while an outing is in progress.
final canToggleOutingPrivacyProvider = Provider<bool>((ref) {
  return ref.watch(activeOutingProvider) != null;
});

/// Privacy applies only while a trip is running (toggle on + in-date active outing).
final isOutingPrivacyActiveProvider = Provider<bool>((ref) {
  if (!ref.watch(outingPrivacyModeProvider)) return false;
  return ref.watch(activeOutingProvider) != null;
});

/// Private mode is suppressed while outing privacy is active.
final effectivePrivateModeProvider = Provider<bool>((ref) {
  final privacyOn = ref.watch(outingPrivacyModeProvider);
  final tripActive = ref.watch(activeOutingProvider) != null;
  if (privacyOn && tripActive) return false;
  return ref.watch(privateModeProvider);
});

class OutingPrivacyNotifier extends StateNotifier<bool> {
  OutingPrivacyNotifier(this._ref)
      : super(
          Hive.box('settings').get('outing_privacy_mode', defaultValue: false) ==
              true,
        ) {
    _ref.listen<Outing?>(activeOutingProvider, (previous, next) {
      if (next == null && state) {
        setEnabled(false);
        return;
      }
      if (next != null && state) {
        _disablePrivateMode();
      }
    });
  }

  final Ref _ref;

  Future<void> setEnabled(bool value) async {
    if (value && _ref.read(activeOutingProvider) == null) return;
    if (state == value) {
      await OutingPrivacyService.setEnabled(value);
      if (value) await _disablePrivateMode();
      return;
    }
    state = value;
    await OutingPrivacyService.setEnabled(value);
    if (value) await _disablePrivateMode();
  }

  Future<void> _disablePrivateMode() async {
    if (!_ref.read(privateModeProvider)) return;
    await PrivateModeService.setEnabled(false);
    _ref.read(privateModeProvider.notifier).state = false;
  }
}

class OutingPrivacyService {
  static Future<void> setEnabled(bool value) async {
    await Hive.box('settings').put('outing_privacy_mode', value);
  }

  static bool get isEnabled =>
      Hive.box('settings').get('outing_privacy_mode', defaultValue: false) ==
      true;
}

/// Trip spend totals (deduped linked SMS rows + never count display rollups).
double outingGrossSpend(Outing outing, List<model.Transaction> txs) {
  return computeOutingTotalSpend(outing, txs);
}

/// Recent outing-only activity items for privacy home.
List<dynamic> outingRecentActivity(
  Outing outing,
  List<model.Transaction> txs, {
  int limit = 8,
}) {
  final linked =
      outing.expenses.map((e) => e.transactionId).whereType<String>().toSet();
  final items = <dynamic>[
    ...outing.expenses,
    ...txs.where(
      (t) =>
          t.outingId == outing.id &&
          t.isExpense &&
          !linked.contains(t.id) &&
          !isOutingRollupTransaction(t),
    ),
  ];
  items.sort((a, b) {
    final da = a is OutingExpense
        ? a.date
        : (a as model.Transaction).date;
    final db = b is OutingExpense
        ? b.date
        : (b as model.Transaction).date;
    return db.compareTo(da);
  });
  return items.take(limit).toList();
}