import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../core/widgets/premium_bottom_sheet.dart';
import '../data/outing_provider.dart';
import '../../../core/providers/transaction_provider.dart';
import '../../../core/sync/sync_service.dart';
import '../../../core/utils/outing_totals.dart';
import '../../transactions/presentation/add_transaction_sheet.dart';
import 'widgets/create_outing_sheet.dart';
import '../../../core/widgets/reference_ui.dart';
import '../../../core/widgets/soft_page_kit.dart';
import 'widgets/soft_outing_widgets.dart';

String _formatIndian(int value) {
  final str = value.toString();
  if (str.length <= 3) return str;
  final lastThree = str.substring(str.length - 3);
  String remaining = str.substring(0, str.length - 3);
  final reg = RegExp(r'\B(?=(\d{2})+(?!\d))');
  remaining = remaining.replaceAllMapped(reg, (m) => '${m[0]},');
  return '$remaining,$lastThree';
}

String _outingDayLabel(Outing outing) {
  final now = DateTime.now();
  final today = DateTime(now.year, now.month, now.day);
  final start = outingLocalDay(outing.startDate);
  final end = outingLocalDay(outing.endDate);
  final total = end.difference(start).inDays + 1;
  final day = today.difference(start).inDays + 1;
  final clamped = day.clamp(1, total < 1 ? 1 : total);
  return 'Day $clamped of ${total < 1 ? 1 : total}';
}

String _outingDurationLabel(Outing outing) {
  final start = DateTime(
    outing.startDate.year,
    outing.startDate.month,
    outing.startDate.day,
  );
  final end = DateTime(
    outing.endDate.year,
    outing.endDate.month,
    outing.endDate.day,
  );
  final days = end.difference(start).inDays + 1;
  return '$days day${days == 1 ? '' : 's'}';
}

class GroupsScreen extends ConsumerStatefulWidget {
  const GroupsScreen({super.key});

  @override
  ConsumerState<GroupsScreen> createState() => _GroupsScreenState();
}

class _GroupsScreenState extends ConsumerState<GroupsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _syncOutings());
  }

  Future<void> _syncOutings() async {
    ref.read(outingProvider.notifier).expireEndedOutings();
    try {
      await SyncService.pullAll(forceNotify: true);
    } catch (e) {
      debugPrint('Outing sync failed: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final outings =
        ref
            .watch(outingProvider)
            .where((o) => o.status != 'cancelled')
            .toList();
    final today = outingLocalDay(DateTime.now());
    final running = outings.where(outingIsCurrentlyRunning).toList();
    final upcoming =
        outings
            .where(
              (o) =>
                  o.status == 'active' &&
                  o.isActive &&
                  outingLocalDay(o.startDate).isAfter(today),
            )
            .toList();
    final completed = outings.where((o) => o.status == 'completed').toList();
    final archived = outings.where((o) => o.status == 'archived').toList();

    Future<void> createOuting() async {
      await PremiumBottomSheet.show(
        context: context,
        child: const CreateOutingSheet(),
      );
    }

    return Scaffold(
      backgroundColor: SoftKit.canvas(context),
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            // Home-style header. No profile avatar and no header "+": the
            // single Create action is the bottom-bar plus (solid #10B981).
            SoftKitHeader(
              title: 'Outings',
              subtitle: 'Shared trips & expenses',
              actions: [
                SoftKitCircleButton(
                  icon: Icons.group_outlined,
                  tooltip: 'Friends',
                  onPressed: () => context.push('/friends'),
                ),
              ],
            ),
            Expanded(
              child: RefreshIndicator(
                onRefresh: _syncOutings,
                child: ListView(
                  physics: const AlwaysScrollableScrollPhysics(
                    parent: BouncingScrollPhysics(),
                  ),
                  padding: const EdgeInsets.fromLTRB(16, 6, 16, 32),
                  children: [
                    if (running.isNotEmpty) ...[
                      ...running.map(
                        (outing) => Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: _ReferenceActiveOutingCard(outing: outing),
                        ),
                      ),
                      const SizedBox(height: 8),
                    ],
                    if (upcoming.isNotEmpty) ...[
                      _OutingSectionHeader(
                        title: 'Upcoming',
                        count: upcoming.length,
                      ),
                      ...upcoming.map(
                        (outing) => _ReferenceOutingCard(
                          outing: outing,
                          badge: 'PLANNED',
                        ),
                      ),
                    ],
                    if (completed.isNotEmpty) ...[
                      _OutingSectionHeader(
                        title: 'Completed',
                        count: completed.length,
                      ),
                      ...completed.map(
                        (outing) => _ReferenceOutingCard(
                          outing: outing,
                          badge: 'Settled',
                        ),
                      ),
                    ],
                    if (archived.isNotEmpty) ...[
                      const _OutingSectionHeader(
                        title: 'Archived',
                        count: null,
                      ),
                      SoftKitCard(
                        child: Row(
                          children: [
                            _OutingIconBubble(icon: Icons.archive_outlined),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Archived Outings',
                                    style: SoftKit.text(
                                      context,
                                      14,
                                      FontWeight.w700,
                                      SoftKit.ink(context),
                                    ),
                                  ),
                                  Text(
                                    'Past outings you\'ve archived (${archived.length} trips)',
                                    style: SoftKit.text(
                                      context,
                                      12,
                                      FontWeight.w500,
                                      SoftKit.slate(context),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Icon(
                              Icons.chevron_right_rounded,
                              color: SoftKit.faint(context),
                            ),
                          ],
                        ),
                      ),
                    ],
                    if (outings.isEmpty)
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 72),
                        child: SoftKitEmptyState(
                          icon: Icons.map_outlined,
                          title: 'No trips yet',
                          message:
                              'Tap + below to start a trip and track group expenses.',
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: SxReferenceBottomBar(
        active: 'accounts',
        onAdd: createOuting,
      ),
    );
  }
}

class _OutingSectionHeader extends StatelessWidget {
  final String title;
  final int? count;
  const _OutingSectionHeader({required this.title, required this.count});
  @override
  Widget build(BuildContext context) =>
      SoftKitSectionLabel(title, count: count);
}

class _OutingIconBubble extends StatelessWidget {
  const _OutingIconBubble({required this.icon, this.size = 42});
  final IconData icon;
  final double size;
  @override
  Widget build(BuildContext context) => Container(
    width: size,
    height: size,
    decoration: BoxDecoration(
      color: SoftKit.softTint(context),
      shape: BoxShape.circle,
    ),
    child: Icon(icon, color: SoftKit.positive(context), size: size * 0.48),
  );
}

class _OutingChip extends StatelessWidget {
  const _OutingChip(this.label, {this.accent = false});
  final String label;
  final bool accent;
  @override
  Widget build(BuildContext context) {
    final dark = SoftKit.dark(context);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color:
            accent
                ? SoftKit.softTint(context)
                : (dark
                    ? SoftPalette.darkSurfaceVariant
                    : const Color(0xFFF1F5F9)),
        borderRadius: BorderRadius.circular(99),
      ),
      child: Text(
        label,
        style: SoftKit.text(
          context,
          11,
          FontWeight.w600,
          accent ? SoftKit.positive(context) : SoftKit.slate(context),
        ),
      ),
    );
  }
}

class _ReferenceActiveOutingCard extends ConsumerWidget {
  final Outing outing;
  const _ReferenceActiveOutingCard({required this.outing});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final spent = computeOutingTotalSpend(
      outing,
      ref.watch(transactionProvider),
    );
    final budget = outing.budget ?? 0;
    final progress = budget <= 0 ? 0.0 : (spent / budget).clamp(0.0, 1.0);
    final ink = SoftKit.ink(context);
    final slate = SoftKit.slate(context);
    final green = SoftKit.positive(context);
    return SoftKitCard(
      onTap: () => context.push('/outing-detail/${outing.id}'),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const _OutingChip('ACTIVE OUTING', accent: true),
              const SizedBox(width: 9),
              Text(
                _outingDayLabel(outing),
                style: SoftKit.text(context, 12, FontWeight.w500, slate),
              ),
              const Spacer(),
              Text(
                'Details  →',
                style: SoftKit.text(context, 12, FontWeight.w700, green),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              const _OutingIconBubble(icon: Icons.luggage_outlined, size: 36),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  outing.title,
                  style: SoftKit.text(context, 18, FontWeight.w800, ink),
                ),
              ),
              Text(
                '${DateFormat('d MMM').format(outing.startDate)} – ${DateFormat('d MMM').format(outing.endDate)}',
                style: SoftKit.text(context, 11, FontWeight.w500, slate),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Text(
                '₹${_formatIndian(spent.toInt())}',
                style: SoftKit.text(context, 24, FontWeight.w800, ink),
              ),
              Text(
                ' / ${_formatIndian(budget.toInt())}',
                style: SoftKit.text(context, 13, FontWeight.w500, slate),
              ),
              const Spacer(),
              Text(
                '${(progress * 100).round()}% used',
                style: SoftKit.text(context, 13, FontWeight.w700, green),
              ),
            ],
          ),
          const SizedBox(height: 10),
          SoftOutingProgress(value: progress),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: Text(
                  'Auto-synced with Trip Ledger',
                  style: SoftKit.text(context, 12, FontWeight.w500, slate),
                ),
              ),
              SoftKitButton(
                label: 'Expense',
                icon: Icons.add_rounded,
                height: 40,
                expand: false,
                onPressed:
                    () => AddTransactionSheet.show(
                      context,
                      startInTripMode: true,
                    ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _ReferenceOutingCard extends ConsumerWidget {
  final Outing outing;
  final String badge;
  const _ReferenceOutingCard({required this.outing, required this.badge});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final spent = computeOutingTotalSpend(
      outing,
      ref.watch(transactionProvider),
    );
    final icon =
        outing.category.toLowerCase().contains('temple')
            ? Icons.account_balance_outlined
            : Icons.luggage_outlined;
    final ink = SoftKit.ink(context);
    final slate = SoftKit.slate(context);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: SoftKitCard(
        onTap: () => context.push('/outing-detail/${outing.id}'),
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            _OutingIconBubble(icon: icon),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    outing.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: SoftKit.text(context, 14, FontWeight.w700, ink),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    '${DateFormat('d MMM').format(outing.startDate)} – ${DateFormat('d MMM').format(outing.endDate)} · ${outing.members.length} members',
                    style: SoftKit.text(context, 11.5, FontWeight.w500, slate),
                  ),
                  const SizedBox(height: 7),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [
                      _OutingChip(
                        outing.status == 'completed' ? 'Settled' : 'Planned',
                        accent: outing.status == 'completed',
                      ),
                      _OutingChip(_outingDurationLabel(outing)),
                      _OutingChip('${outing.members.length} members'),
                      if (outing.budget != null)
                        _OutingChip(
                          'Budget ₹${_formatIndian(outing.budget!.toInt())}',
                          accent: true,
                        ),
                    ],
                  ),
                ],
              ),
            ),
            if (outing.status == 'completed')
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    '₹${_formatIndian(spent.toInt())}',
                    style: SoftKit.text(context, 14, FontWeight.w800, ink),
                  ),
                  Text(
                    'your spend',
                    style: SoftKit.text(context, 10, FontWeight.w500, slate),
                  ),
                ],
              )
            else
              Icon(
                Icons.chevron_right_rounded,
                size: 20,
                color: SoftKit.faint(context),
              ),
          ],
        ),
      ),
    );
  }
}
