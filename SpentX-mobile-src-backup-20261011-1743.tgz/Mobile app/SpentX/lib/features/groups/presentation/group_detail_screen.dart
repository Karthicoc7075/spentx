import 'package:flutter/material.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../core/theme/spentx_tokens.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:intl/intl.dart';
import 'package:go_router/go_router.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/utils/outing_delete_cascade.dart';
import '../../../core/widgets/premium_bottom_sheet.dart';
import '../data/outing_provider.dart';
import '../../../core/providers/transaction_provider.dart'
    show transactionProvider, Transaction;
import '../../sms/detected/auto_rule_engine.dart';
import '../../sms/detected/detected_sms_storage.dart';
import '../../sms/detected/detection_popup.dart';
import '../../sms/detected/pending_model.dart';
import '../../transactions/presentation/add_transaction_sheet.dart';
import 'widgets/create_outing_sheet.dart';
import '../../friends/presentation/friends_screen.dart'
    show FriendReturnConfirmSheet;

import 'widgets/outing_unlink_dialog.dart';
import 'widgets/soft_outing_widgets.dart';

enum _ExpenseFilter { all, automatic, manual, solo, split }

String _inr(num value) {
  return NumberFormat.currency(
    symbol: '₹',
    decimalDigits: 0,
    locale: 'en_IN',
  ).format(value.toInt());
}

class GroupDetailScreen extends ConsumerStatefulWidget {
  final String groupId;
  const GroupDetailScreen({super.key, required this.groupId});

  @override
  ConsumerState<GroupDetailScreen> createState() => _GroupDetailScreenState();
}

class _GroupDetailScreenState extends ConsumerState<GroupDetailScreen> {
  _ExpenseFilter _expenseFilter = _ExpenseFilter.all;
  bool _showSettlementSummary = false;

  List<Transaction> _getAutoTaggedTransactions(String outingId) {
    final allTxs = ref.watch(transactionProvider);
    return allTxs.where((t) => t.outingId == outingId).toList();
  }

  DateTime _activityDate(dynamic item) {
    if (item is OutingExpense) return item.date;
    if (item is PendingTransaction) return item.date;
    return (item as Transaction).date;
  }

  int _dayNumberForDate(DateTime d, Outing outing) {
    final startDay = DateTime(
      outing.startDate.year,
      outing.startDate.month,
      outing.startDate.day,
    );
    final itemDay = DateTime(d.year, d.month, d.day);
    final diff = itemDay.difference(startDay).inDays;
    return diff + 1;
  }

  List<PendingTransaction> _getPendingForOuting(String outingId) {
    return DetectedSmsStorage.getAll()
        .where((p) => p.outingId == outingId && p.isExpense)
        .toList();
  }

  Future<void> _confirmAndUnlink({
    required dynamic item,
    required Outing outing,
    required String title,
    required double amount,
    required bool isExpenseObj,
    required bool isPendingObj,
  }) async {
    final ok = await OutingUnlinkDialog.confirm(
      context,
      itemName: title,
      amount: amount,
      isPendingOnly: isPendingObj,
    );
    if (!ok || !mounted) return;

    if (isExpenseObj) {
      _unlinkExpenseFromTrip(item as OutingExpense, outing.id);
    } else if (isPendingObj) {
      _unlinkPendingFromTrip(item as PendingTransaction);
    } else {
      _unlinkTransactionFromTrip(item as Transaction, outing.id);
    }
  }

  void _unlinkTransactionFromTrip(Transaction tx, String outingId) {
    // updateTransaction preserves the member split as a Friend Split before
    // dropping the trip link — see _preserveSplitOnUnlink.
    ref
        .read(transactionProvider.notifier)
        .updateTransaction(tx.copyWith(clearOutingId: true));
    ref
        .read(outingProvider.notifier)
        .removeExpenseByTransactionId(outingId, tx.id);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Removed from trip'),
        backgroundColor: AppColors.expense,
      ),
    );
  }

  void _unlinkExpenseFromTrip(OutingExpense expense, String outingId) {
    if (expense.transactionId != null && expense.transactionId!.isNotEmpty) {
      final tx =
          ref
              .read(transactionProvider)
              .where((t) => t.id == expense.transactionId)
              .firstOrNull;
      if (tx != null) {
        ref
            .read(transactionProvider.notifier)
            .updateTransaction(tx.copyWith(clearOutingId: true));
      }
      ref
          .read(outingProvider.notifier)
          .removeExpenseByTransactionId(outingId, expense.transactionId!);
    } else {
      // A manual trip entry has no ledger row behind it — the OutingExpense IS
      // the record of that spend. Unlinking used to call deleteExpense(), which
      // destroyed it: the money vanished from the app entirely instead of
      // becoming a normal transaction. Materialise it as a real ledger row
      // first, carrying every field across unchanged, then drop it from the
      // trip.
      final outing =
          ref.read(outingProvider).where((o) => o.id == outingId).firstOrNull;
      ref
          .read(transactionProvider.notifier)
          .materialiseOutingExpense(expense, outing: outing);
      ref.read(outingProvider.notifier).deleteExpense(outingId, expense.id);
    }
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Removed from trip'),
        backgroundColor: AppColors.expense,
      ),
    );
  }

  /// Bank SMS / online auto-detected spends on this trip.
  List<dynamic> _bankDetectedItems(
    Outing outing,
    List<Transaction> autoTxs,
    List<PendingTransaction> pending,
  ) {
    final linkedTxIds =
        outing.expenses.map((e) => e.transactionId).whereType<String>().toSet();
    final items = <dynamic>[];

    for (final p in pending) {
      if (!linkedTxIds.contains(p.id)) items.add(p);
    }

    for (final t in autoTxs) {
      if (!t.isExpense) continue;
      if (t.isAutoDetected || t.isAutoLinked || t.paymentType != 'Cash') {
        items.add(t);
      }
    }

    items.sort((a, b) => _activityDate(b).compareTo(_activityDate(a)));
    return items;
  }

  /// Manual cash entries only (no bank SMS row).
  List<dynamic> _manualCashItems(Outing outing, List<Transaction> autoTxs) {
    final items = <dynamic>[
      ...outing.expenses.where(
        (e) => e.transactionId == null || e.transactionId!.isEmpty,
      ),
    ];
    items.sort((a, b) => _activityDate(b).compareTo(_activityDate(a)));
    return items;
  }

  double _sumItems(Iterable<dynamic> items) {
    double sum = 0;
    for (final item in items) {
      if (item is OutingExpense) {
        sum += item.amount;
      } else if (item is Transaction) {
        sum += item.amount;
      } else if (item is PendingTransaction) {
        sum += item.amount;
      }
    }
    return sum;
  }

  void _unlinkPendingFromTrip(PendingTransaction pending) {
    DetectedSmsStorage.save(
      PendingTransaction(
        id: pending.id,
        amount: pending.amount,
        receiver: pending.receiver,
        bank: pending.bank,
        date: pending.date,
        rawMessage: pending.rawMessage,
        isExpense: pending.isExpense,
        isTransfer: pending.isTransfer,
        accountLast4: pending.accountLast4,
        referenceId: pending.referenceId,
        upiId: pending.upiId,
      ),
    );
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Removed from trip'),
        backgroundColor: AppColors.expense,
      ),
    );
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final outings = ref.watch(outingProvider);
    final outing = outings.firstWhere(
      (o) => o.id == widget.groupId,
      orElse:
          () => Outing(
            title: 'Not Found',
            category: 'Other',
            startDate: DateTime.now(),
            endDate: DateTime.now(),
          ),
    );

    if (outing.title == 'Not Found') {
      return Scaffold(
        backgroundColor: OutingDetailTone(context).canvas,
        body: Center(
          child: Text(
            'Trip not found',
            style: OutingDetailTone(
              context,
            ).text(14, FontWeight.w600, OutingDetailTone(context).slate),
          ),
        ),
      );
    }

    final autoTxs = _getAutoTaggedTransactions(outing.id);
    final pendingForTrip = _getPendingForOuting(outing.id);
    final autoExpenses = autoTxs.where((t) => t.isExpense).toList();

    final bankDetectedItems = _bankDetectedItems(
      outing,
      autoTxs,
      pendingForTrip,
    );
    final manualCashItems = _manualCashItems(outing, autoTxs);
    final linkedTxIds =
        outing.expenses.map((e) => e.transactionId).whereType<String>().toSet();

    double grossSpend = outing.expenses.fold(0.0, (s, e) => s + e.amount);
    for (final t in autoTxs) {
      if (t.isExpense && !linkedTxIds.contains(t.id)) grossSpend += t.amount;
    }
    for (final p in pendingForTrip) {
      if (!linkedTxIds.contains(p.id)) grossSpend += p.amount;
    }

    final yourShare = outing.yourSplitShareTotal;
    final userNetCost = outing.userNetCost;
    final youOweTotal = outing.youOweToFriends;

    // Section order answers the page's questions in the order they get asked:
    // what did this cost me → do I owe anyone → what was spent → on what →
    // who was here. Previously the balance information was split across four
    // places and the expense list sat between two of them.
    const gap = SizedBox(height: AppSpacing.xl);

    final tone = OutingDetailTone(context);

    return Scaffold(
      backgroundColor: tone.canvas,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          _buildSliverAppBar(context, outing),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(
              AppSpacing.screenH,
              AppSpacing.xs,
              AppSpacing.screenH,
              0,
            ),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                if (_showSettlementSummary)
                  _buildSettlementSummaryCard(outing, grossSpend),

                _buildOutingStatusCard(outing),
                const SizedBox(height: AppSpacing.sm),
                _buildHeroCard(
                  outing,
                  grossSpend,
                  yourShare,
                  userNetCost,
                  manualCashItems,
                  bankDetectedItems,
                ),

                if (youOweTotal > 0.01) ...[
                  const SizedBox(height: AppSpacing.sm),
                  _buildYouOwePrompt(outing),
                ],

                gap,
                _buildBalancesSection(outing),

                gap,
                _SectionTitle(
                  'ACTIVITY (${manualCashItems.length + bankDetectedItems.length})',
                ),
                const SizedBox(height: AppSpacing.sm),
                _buildExpenseFilterTabs(outing),
                const SizedBox(height: AppSpacing.sm),
                _buildExpenseList(outing, manualCashItems, bankDetectedItems),

                gap,
                const _SectionTitle('WHERE IT WENT'),
                const SizedBox(height: AppSpacing.sm),
                _buildCategoryChart(outing, autoExpenses),

                gap,
                _buildMembersRow(outing),

                if (outing.members.any((m) => m.name != 'You')) ...[
                  gap,
                  const _SectionTitle('SETTLEMENT HISTORY'),
                  const SizedBox(height: AppSpacing.sm),
                  _buildRepaymentHistory(outing),
                ],

                // Clears the bottom action bar + home indicator.
                SizedBox(
                  height:
                      AppSpacing.xxl + MediaQuery.of(context).padding.bottom,
                ),
              ]),
            ),
          ),
        ],
      ),
      // Deliberately no FAB. "Add Outing Expense" used to render three times
      // at once — a full-width button under the header, an inline button beside
      // the Activity title, and an extended FAB that overlapped the bottom bar
      // — so the same action competed with itself and with "End Trip".
      bottomNavigationBar: _buildBottomActionBar(context, outing),
    );
  }

  Widget _buildSettlementSummaryCard(Outing outing, double grossSpend) {
    final balances = outing.friendBalanceSummary();
    final youOwe = outing.youOweToFriends;

    final tone = OutingDetailTone(context);
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      padding: const EdgeInsets.all(16),
      decoration: tone.cardBox(fill: tone.mint, borderColor: tone.border),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(
                  '${outing.title} — Settlement Summary',
                  style: tone.text(16, FontWeight.w700, tone.ink),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 4,
                ),
                decoration: BoxDecoration(
                  color: tone.emeraldDeep,
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  'Total: ${_inr(grossSpend)}',
                  style: tone.text(12, FontWeight.w700, Colors.white),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Text(
            'MEMBER BALANCES & SETTLEMENTS',
            style: tone.text(
              11,
              FontWeight.w700,
              tone.emeraldDeep,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 8),
          if (balances.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Text(
                'All settlements completed! (₹0)',
                style: tone.text(13, FontWeight.w500, tone.slate),
              ),
            )
          else
            ...balances.entries.map((e) {
              final friendName = e.key;
              final friendPending = e.value.pendingToYou;
              final friendYouOwe = e.value.youOwe;

              if (friendPending > 0.01) {
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        '$friendName owes You',
                        style: tone.text(14, FontWeight.w500, tone.ink),
                      ),
                      Text(
                        _inr(friendPending),
                        style: tone.text(14, FontWeight.w700, tone.emeraldDeep),
                      ),
                    ],
                  ),
                );
              } else if (friendYouOwe > 0.01) {
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'You owe $friendName',
                        style: tone.text(14, FontWeight.w500, tone.ink),
                      ),
                      Text(
                        _inr(friendYouOwe),
                        style: tone.text(14, FontWeight.w700, tone.orange),
                      ),
                    ],
                  ),
                );
              }
              return const SizedBox.shrink();
            }),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'You owe',
                  style: tone.text(14, FontWeight.w500, tone.ink),
                ),
                Text(
                  _inr(youOwe),
                  style: tone.text(
                    14,
                    FontWeight.w700,
                    youOwe > 0 ? tone.orange : tone.ink,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Shared Soft confirmation chrome for group actions. The callbacks keep the
  /// existing mutations and navigation exactly as before; this only centralises
  /// the dialog surface and button treatment.
  void _showSoftConfirmationDialog({
    required BuildContext context,
    required String title,
    required String message,
    required String confirmLabel,
    required VoidCallback onConfirm,
  }) {
    final tone = OutingDetailTone(context);
    showDialog<void>(
      context: context,
      builder:
          (ctx) => AlertDialog(
            backgroundColor: tone.card,
            surfaceTintColor: Colors.transparent,
            elevation: 8,
            shadowColor: Colors.black.withValues(alpha: 0.08),
            insetPadding: const EdgeInsets.symmetric(
              horizontal: 24,
              vertical: 24,
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24),
              side: BorderSide(color: tone.border),
            ),
            titlePadding: const EdgeInsets.fromLTRB(24, 24, 24, 8),
            contentPadding: const EdgeInsets.fromLTRB(24, 0, 24, 8),
            actionsPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            title: Text(title, style: tone.text(18, FontWeight.w700, tone.ink)),
            content: Text(
              message,
              style: tone.text(14, FontWeight.w500, tone.slate),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                style: TextButton.styleFrom(
                  foregroundColor: tone.slate,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 12,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                child: Text(
                  'Cancel',
                  style: tone.text(14, FontWeight.w700, tone.slate),
                ),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(ctx);
                  onConfirm();
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: SoftColors.control,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 18,
                    vertical: 12,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                child: Text(
                  confirmLabel,
                  style: tone.text(14, FontWeight.w700, Colors.white),
                ),
              ),
            ],
          ),
    );
  }

  void _showEndTripConfirmationDialog(BuildContext context, Outing outing) {
    _showSoftConfirmationDialog(
      context: context,
      title: 'End Trip',
      message:
          'Are you sure you want to end this outing?\n\nBefore completing the outing, ensure all expenses and settlements have been recorded.',
      confirmLabel: 'Continue',
      onConfirm: () {
        setState(() {
          _showSettlementSummary = true;
        });
      },
    );
  }

  void _showCompleteOutingConfirmationDialog(
    BuildContext context,
    Outing outing,
  ) {
    _showSoftConfirmationDialog(
      context: context,
      title: 'Complete Outing',
      message: 'All settlements have been recorded.\n\nComplete this outing?',
      confirmLabel: 'Complete',
      onConfirm: () async {
        await ref.read(outingProvider.notifier).completeOuting(outing.id);
        if (!mounted || !context.mounted) return;
        setState(() {
          _showSettlementSummary = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Outing completed!'),
            backgroundColor: AppColors.income,
          ),
        );
      },
    );
  }

  void _showArchiveOutingConfirmationDialog(
    BuildContext context,
    Outing outing,
  ) {
    _showSoftConfirmationDialog(
      context: context,
      title: 'Archive Outing',
      message: 'Archive this outing?',
      confirmLabel: 'Archive',
      onConfirm: () async {
        await ref.read(outingProvider.notifier).archiveOuting(outing.id);
        if (!mounted || !context.mounted) return;
        setState(() {
          _showSettlementSummary = false;
        });
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('Outing archived!')));
      },
    );
  }

  void _showCancelOutingConfirmationDialog(
    BuildContext context,
    Outing outing,
  ) {
    _showSoftConfirmationDialog(
      context: context,
      title: 'Cancel Outing',
      message:
          'This will cancel the outing.\n\nExpenses and settlements will be preserved for history.',
      confirmLabel: 'Confirm',
      onConfirm: () async {
        await ref.read(outingProvider.notifier).cancelOuting(outing.id);
        if (!mounted || !context.mounted) return;
        setState(() {
          _showSettlementSummary = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Outing cancelled'),
            backgroundColor: AppColors.expense,
          ),
        );
      },
    );
  }

  /// The page's single action surface.
  ///
  /// While a trip is active the primary job is logging spend, so "Add expense"
  /// is the filled button and ending the trip is the quieter neighbour — it is
  /// a once-per-trip action and doesn't deserve the loudest control on screen.
  Widget? _buildBottomActionBar(BuildContext context, Outing outing) {
    final tone = OutingDetailTone(context);

    Widget bar({required Widget child}) => Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
      decoration: BoxDecoration(
        color: tone.card,
        border: Border(top: BorderSide(color: tone.border)),
      ),
      child: SafeArea(top: false, child: child),
    );

    final shape = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(16),
    );
    final outlineStyle = OutlinedButton.styleFrom(
      backgroundColor: tone.card,
      foregroundColor: tone.ink,
      side: BorderSide(color: tone.border),
      padding: const EdgeInsets.symmetric(vertical: 12),
      shape: shape,
    );
    final emeraldStyle = ElevatedButton.styleFrom(
      backgroundColor: SoftColors.control,
      foregroundColor: Colors.white,
      elevation: 0,
      padding: const EdgeInsets.symmetric(vertical: 12),
      shape: shape,
    );

    if (outing.status == 'active' && !_showSettlementSummary) {
      return bar(
        child: Row(
          children: [
            Expanded(
              child: SizedBox(
                height: 52,
                child: OutlinedButton(
                  onPressed:
                      () => _showEndTripConfirmationDialog(context, outing),
                  style: outlineStyle,
                  child: Text(
                    'End Trip',
                    style: tone.text(14, FontWeight.w700, tone.ink),
                  ),
                ),
              ),
            ),
            const SizedBox(width: AppSpacing.sm),
            Expanded(
              flex: 2,
              child: SizedBox(
                height: 52,
                child: ElevatedButton(
                  onPressed:
                      () => AddTransactionSheet.show(
                        context,
                        startInTripMode: true,
                      ),
                  style: emeraldStyle,
                  child: Text(
                    '+ Add Expense',
                    style: tone.text(15, FontWeight.w700, Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    }

    if (_showSettlementSummary) {
      return bar(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {
                      AddTransactionSheet.show(context, startInTripMode: true);
                    },
                    icon: Icon(
                      LucideIcons.plusCircle,
                      size: 16,
                      color: tone.ink,
                    ),
                    label: Text(
                      'Record Settlement',
                      style: tone.text(12, FontWeight.w700, tone.ink),
                    ),
                    style: outlineStyle,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed:
                        () => _showCompleteOutingConfirmationDialog(
                          context,
                          outing,
                        ),
                    icon: const Icon(LucideIcons.checkCircle, size: 16),
                    label: Text(
                      'Complete Outing',
                      style: tone.text(12, FontWeight.w700, Colors.white),
                    ),
                    style: emeraldStyle,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed:
                        () => _showArchiveOutingConfirmationDialog(
                          context,
                          outing,
                        ),
                    icon: Icon(LucideIcons.archive, size: 16, color: tone.ink),
                    label: Text(
                      'Archive Outing',
                      style: tone.text(12, FontWeight.w700, tone.ink),
                    ),
                    style: outlineStyle,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed:
                        () => _showCancelOutingConfirmationDialog(
                          context,
                          outing,
                        ),
                    icon: const Icon(LucideIcons.xCircle, size: 16),
                    label: Text(
                      'Cancel Outing',
                      style: tone.text(12, FontWeight.w700, Colors.white),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundBuilder: SoftColors.plainBackground,
                      backgroundColor: AppColors.expense,
                      foregroundColor: AppColors.onAccent(AppColors.expense),
                      elevation: 0,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: shape,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      );
    }

    if (outing.status == 'completed') {
      return bar(
        child: SizedBox(
          height: 52,
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed:
                () => _showArchiveOutingConfirmationDialog(context, outing),
            icon: const Icon(LucideIcons.archive, size: 18),
            label: Text(
              'Archive Outing',
              style: tone.text(15, FontWeight.w700, Colors.white),
            ),
            style: emeraldStyle,
          ),
        ),
      );
    }

    return null;
  }

  /// Compact bar carrying the trip's identity as real content.
  ///
  /// It used to reserve 180px for a 15%-opacity gradient with a giant faded
  /// map glyph, while the facts that actually identify a trip — its category,
  /// dates and location — were pushed into the scrolling body. The decoration
  /// is gone and those facts are the subtitle.
  Widget _buildSliverAppBar(BuildContext context, Outing outing) {
    final tone = OutingDetailTone(context);
    final dates =
        '${DateFormat('d MMM').format(outing.startDate)}–${DateFormat('d MMM').format(outing.endDate)}';
    final meta = [
      outing.category,
      dates,
      if (outing.location != null && outing.location!.trim().isNotEmpty)
        outing.location!,
    ].join(' · ');

    Widget circleButton({required Widget child, required VoidCallback onTap}) {
      return Material(
        color: tone.card,
        elevation: 0,
        shape: CircleBorder(side: BorderSide(color: tone.border)),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: SizedBox(width: 40, height: 40, child: child),
        ),
      );
    }

    return SliverAppBar(
      pinned: true,
      toolbarHeight: 72,
      backgroundColor: tone.canvas,
      surfaceTintColor: Colors.transparent,
      scrolledUnderElevation: 0,
      elevation: 0,
      titleSpacing: 8,
      leadingWidth: 56,
      leading: Padding(
        padding: const EdgeInsets.only(left: 12),
        child: Center(
          child: circleButton(
            onTap: () => context.pop(),
            child: Icon(
              Icons.arrow_back_ios_new_rounded,
              size: 16,
              color: tone.ink,
            ),
          ),
        ),
      ),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            outing.title,
            style: tone.text(
              18,
              FontWeight.w800,
              tone.ink,
              letterSpacing: -0.3,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 2),
          Text(
            meta,
            style: tone.text(12, FontWeight.w500, tone.slate),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
      actions: [
        Padding(
          padding: const EdgeInsets.only(right: 12),
          child: Center(
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                circleButton(
                  onTap: () => _showOutingMenu(context, outing),
                  child: Icon(
                    LucideIcons.moreVertical,
                    size: 18,
                    color: tone.ink,
                  ),
                ),
                if (outing.status == 'active')
                  Positioned(
                    right: 2,
                    top: 2,
                    child: Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        color: tone.emerald,
                        shape: BoxShape.circle,
                        border: Border.all(color: tone.canvas, width: 1.5),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  /// The trip's one answer, then its support.
  ///
  /// This used to be a grid of up to eight identically-weighted bordered
  /// tiles (TOTAL TRIP / TOTAL YOUR SPENT / YOUR SHARE / BUDGET / PENDING
  /// RETURN / RETURNED / YOU OWE / YOUR OUTSTANDING). Eight equal numbers is
  /// the same as no answer, so the figure a trip page exists to give — what
  /// this trip actually cost *you*, after friends pay you back — is now the
  /// hero, and the rest are quiet supporting figures on one recessed strip.
  Widget _buildHeroCard(
    Outing outing,
    double gross,
    double yourShare,
    double yourImpact,
    List<dynamic> manualCashItems,
    List<dynamic> bankDetectedItems,
  ) {
    final hasFriends = outing.members.any((m) => m.name != 'You');
    // Net cost only means something once friends are involved; a solo trip's
    // honest headline is simply what it cost.
    final heroValue = hasFriends ? yourImpact : gross;
    final heroLabel = hasFriends ? 'YOUR NET COST' : 'TOTAL SPENT';
    final tone = OutingDetailTone(context);
    final hasBudget = outing.budget != null;
    final over = hasBudget && outing.budget! > 0 && gross > outing.budget!;
    final progress =
        !hasBudget || outing.budget! <= 0
            ? 0.0
            : (gross / outing.budget!).clamp(0.0, 1.0);
    final pct = (progress * 100).round();

    return Column(
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF0D3D2F), Color(0xFF06281E)],
            ),
            borderRadius: BorderRadius.all(Radius.circular(24)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                heroLabel,
                style: tone.text(
                  10,
                  FontWeight.w700,
                  Colors.white.withValues(alpha: 0.7),
                  letterSpacing: 0.6,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                _inr(heroValue),
                style: tone.text(
                  32,
                  FontWeight.w800,
                  Colors.white,
                  letterSpacing: -0.8,
                ),
              ),
              Text(
                'INR',
                style: tone.text(
                  12,
                  FontWeight.w600,
                  Colors.white.withValues(alpha: 0.72),
                ),
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  _StatCell(
                    label: 'Trip Total',
                    value: _inr(gross),
                    onDark: true,
                  ),
                  const _CellDivider(onDark: true),
                  _StatCell(
                    label: 'You Paid',
                    value: _inr(outing.yourPaidTotal),
                    onDark: true,
                    emphasize: true,
                  ),
                  if (hasFriends) ...[
                    const _CellDivider(onDark: true),
                    _StatCell(
                      label: 'Your Share',
                      value: _inr(yourShare),
                      onDark: true,
                    ),
                  ],
                ],
              ),
              if (hasBudget) ...[
                const SizedBox(height: 14),
                Row(
                  children: [
                    Text(
                      'Budget Progress',
                      style: tone.text(
                        12,
                        FontWeight.w600,
                        Colors.white.withValues(alpha: 0.8),
                      ),
                    ),
                    const Spacer(),
                    Text(
                      '$pct%',
                      style: tone.text(12, FontWeight.w700, Colors.white),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                ClipRRect(
                  borderRadius: BorderRadius.circular(999),
                  child: LinearProgressIndicator(
                    value: progress,
                    minHeight: 6,
                    backgroundColor: Colors.white.withValues(alpha: 0.16),
                    color:
                        over
                            ? const Color(0xFFFDA4AF)
                            : const Color(0xFF10B981),
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'Budget ${_inr(outing.budget!)} · Spent ${_inr(gross)}',
                  style: tone.text(
                    11,
                    FontWeight.w500,
                    Colors.white.withValues(alpha: 0.7),
                  ),
                ),
              ],
            ],
          ),
        ),
        const SizedBox(height: 12),
        OutingDetailCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Payment Breakdown',
                style: tone.text(16, FontWeight.w700, tone.ink),
              ),
              const SizedBox(height: 12),
              _buildPaymentSummary(outing, manualCashItems, bankDetectedItems),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildOutingStatusCard(Outing outing) {
    final tone = OutingDetailTone(context);
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final start = DateTime(
      outing.startDate.year,
      outing.startDate.month,
      outing.startDate.day,
    );
    final end = DateTime(
      outing.endDate.year,
      outing.endDate.month,
      outing.endDate.day,
    );
    final total = (end.difference(start).inDays + 1).clamp(1, 999);
    final day = (today.difference(start).inDays + 1).clamp(1, total);
    final isActive = outing.status == 'active';
    final statusLabel =
        isActive
            ? 'Active Outing — Day $day of $total'
            : '${outing.status[0].toUpperCase()}${outing.status.substring(1)} Outing';
    return OutingDetailCard(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      child: Row(
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: isActive ? tone.emerald : tone.muted,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              statusLabel,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: tone.text(14, FontWeight.w700, tone.ink),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: tone.mint,
              borderRadius: BorderRadius.circular(999),
            ),
            child: Text(
              'GROUP',
              style: tone.text(
                10,
                FontWeight.w800,
                tone.emeraldDeep,
                letterSpacing: 0.6,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPaymentSummary(
    Outing outing,
    List<dynamic> manualCashItems,
    List<dynamic> bankDetectedItems,
  ) {
    final youMemberId =
        outing.members
            .where((m) => m.name.toLowerCase() == 'you')
            .firstOrNull
            ?.id;
    double cashPaid = _sumItems(manualCashItems);
    double onlinePaid = _sumItems(bankDetectedItems);

    double cashRec = 0.0;
    double onlineRec = 0.0;
    for (final e in outing.expenses) {
      for (final entry in e.settlementPayments.entries) {
        if (youMemberId != null && entry.key == youMemberId) continue;
        for (final p in entry.value) {
          final mode = p.mode.toLowerCase();
          if (mode == 'cash') {
            cashRec += p.amount;
          } else {
            onlineRec += p.amount;
          }
        }
      }
    }

    final bool showRecv = outing.members.any((m) => m.name != 'You');
    final tone = OutingDetailTone(context);

    return Column(
      children: [
        _PaymentRow(
          label: 'Manually added',
          paid: cashPaid,
          rec: cashRec,
          icon: LucideIcons.banknote,
          showRecv: showRecv,
        ),
        const SizedBox(height: 10),
        Divider(height: 1, color: tone.border),
        const SizedBox(height: 10),
        _PaymentRow(
          label: 'Auto-detected (Bank SMS / UPI)',
          paid: onlinePaid,
          rec: onlineRec,
          icon: LucideIcons.creditCard,
          showRecv: showRecv,
        ),
      ],
    );
  }

  /// Who owes whom, in one place.
  ///
  /// This replaces four separate treatments of the same fact that used to
  /// appear on this page simultaneously: the PENDING RETURN / RETURNED / YOU
  /// OWE / YOUR OUTSTANDING stat tiles, the "SPLIT & BALANCES" card, the
  /// orange "YOU NEED TO SEND" banners, and the "SETTLE UP" list. A reader had
  /// to reconcile four renderings of one number to answer "are we square?".
  Widget _buildBalancesSection(Outing outing) {
    if (!outing.members.any((m) => m.name != 'You')) {
      return const SizedBox.shrink();
    }

    final tone = OutingDetailTone(context);
    final mySpent = outing.mySplitContributed;
    final friendSpents = outing.friendsSplitContributed();
    final balances = outing.friendBalanceSummary();

    if (balances.isEmpty && mySpent <= 0 && friendSpents.isEmpty) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _SectionTitle('BALANCES'),
          const SizedBox(height: 10),
          OutingDetailCard(
            child: Row(
              children: [
                Icon(LucideIcons.users, size: 16, color: tone.slate),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'No split balances yet — use Equal split on an expense to '
                    'start tracking who owes what.',
                    style: tone.text(12, FontWeight.w500, tone.slate),
                  ),
                ),
              ],
            ),
          ),
        ],
      );
    }

    // One net figure per friend: pending-to-you minus what you owe them, so
    // the row states the single remaining amount to settle rather than making
    // the reader subtract two numbers themselves.
    final rows = balances.entries.toList();
    final settledCount =
        rows
            .where((e) => (e.value.pendingToYou - e.value.youOwe).abs() <= 0.01)
            .length;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: _SectionTitle(
                settledCount == rows.length && rows.isNotEmpty
                    ? 'BALANCES · ALL SETTLED'
                    : 'BALANCES',
              ),
            ),
            InkWell(
              onTap:
                  () =>
                      AddTransactionSheet.show(context, startInTripMode: true),
              child: Text(
                'Settle up',
                style: tone.text(13, FontWeight.w700, tone.emeraldDeep),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        OutingDetailCard(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
          child: Column(
            children: [
              for (var i = 0; i < rows.length; i++) ...[
                if (i > 0) Divider(height: 1, color: tone.border),
                _BalanceRow(
                  name: rows[i].key,
                  net: rows[i].value.pendingToYou - rows[i].value.youOwe,
                  onSettle: () {
                    final net =
                        rows[i].value.pendingToYou - rows[i].value.youOwe;
                    if (net > 0.01) {
                      PremiumBottomSheet.show(
                        context: context,
                        child: FriendReturnConfirmSheet(
                          friendName: rows[i].key,
                          expense: null,
                          ref: ref,
                        ),
                      );
                    } else {
                      AddTransactionSheet.show(
                        context,
                        startInTripMode: true,
                      );
                    }
                  },
                ),
              ],
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildMembersRow(Outing outing) {
    final tone = OutingDetailTone(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _SectionTitle('MEMBERS (${outing.members.length})'),
        const SizedBox(height: 10),
        SizedBox(
          height: 92,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            itemCount: outing.members.length,
            separatorBuilder: (_, __) => const SizedBox(width: 14),
            itemBuilder: (context, i) {
              final m = outing.members[i];
              final isYou = m.name == 'You';
              final initial = m.name.isEmpty ? '?' : m.name[0].toUpperCase();
              return SizedBox(
                width: 64,
                child: Column(
                  children: [
                    Stack(
                      clipBehavior: Clip.none,
                      children: [
                        Container(
                          width: 48,
                          height: 48,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: isYou ? tone.mint : tone.card,
                            shape: BoxShape.circle,
                            border: Border.all(color: tone.border),
                          ),
                          child: Text(
                            initial,
                            style: tone.text(
                              16,
                              FontWeight.w700,
                              isYou ? tone.emeraldDeep : tone.ink,
                            ),
                          ),
                        ),
                        if (isYou)
                          Positioned(
                            right: -6,
                            bottom: -2,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 5,
                                vertical: 2,
                              ),
                              decoration: BoxDecoration(
                                color: tone.emeraldDeep,
                                borderRadius: BorderRadius.circular(999),
                              ),
                              child: Text(
                                'You',
                                style: tone.text(
                                  9,
                                  FontWeight.w700,
                                  Colors.white,
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      m.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: tone.text(12, FontWeight.w600, tone.ink),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  /// Category/payment totals: each linked SMS transaction is stored as an [OutingExpense];
  /// only count auto transactions that have no matching expense row.
  Map<String, double> _categoryTotals(
    Outing outing,
    List<Transaction> autoTxs,
  ) {
    final linkedTxIds =
        outing.expenses.map((e) => e.transactionId).whereType<String>().toSet();
    final Map<String, double> totals = {};
    for (var e in outing.expenses) {
      totals[e.category] = (totals[e.category] ?? 0) + e.amount;
    }
    for (var t in autoTxs) {
      if (linkedTxIds.contains(t.id)) continue;
      totals[t.category] = (totals[t.category] ?? 0) + t.amount;
    }
    return totals;
  }

  Widget _buildCategoryChart(Outing outing, List<Transaction> autoTxs) {
    final totals = _categoryTotals(outing, autoTxs);
    if (totals.isEmpty) return const SizedBox.shrink();

    final tone = OutingDetailTone(context);
    final ranked =
        totals.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final grand = ranked.fold<double>(0, (s, e) => s + e.value);
    if (grand <= 0) return const SizedBox.shrink();
    final top = ranked.take(4).toList();
    final rest = grand - top.fold<double>(0, (s, e) => s + e.value);

    Widget segment(double value, Color color) {
      final flex = ((value / grand) * 1000).round().clamp(1, 1000);
      return Expanded(flex: flex, child: ColoredBox(color: color));
    }

    return OutingDetailCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: SizedBox(
              height: 10,
              child: Row(
                children: [
                  for (final e in top) segment(e.value, _getCatColor(e.key)),
                  if (rest > 0.01) segment(rest, tone.border),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          for (final e in top)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: _getCatColor(e.key),
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      e.key,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: tone.text(13, FontWeight.w600, tone.ink),
                    ),
                  ),
                  Text(
                    '${((e.value / grand) * 100).round()}%',
                    style: tone.text(12, FontWeight.w700, tone.slate),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    _inr(e.value),
                    style: tone.text(13, FontWeight.w700, tone.ink),
                  ),
                ],
              ),
            ),
          if (ranked.length > 4)
            Text(
              '+${ranked.length - 4} more · ${_inr(rest)}',
              style: tone.text(12, FontWeight.w500, tone.slate),
            ),
        ],
      ),
    );
  }

  /// A single prompt when you owe money, shown directly under the hero.
  ///
  /// Was a stack of full-width orange banners — one per friend — each
  /// repeating the same 11px explainer, sitting in the middle of the Activity
  /// list. The per-friend amounts now live in [_buildBalancesSection]; this is
  /// just the nudge, and it only appears when there is something to send.
  Widget _buildYouOwePrompt(Outing outing) {
    final owed = outing.youOweByFriendName();
    if (owed.isEmpty) return const SizedBox.shrink();

    final tone = OutingDetailTone(context);
    final total = owed.values.fold<double>(0, (s, v) => s + v);
    final who = owed.length == 1 ? owed.keys.first : '${owed.length} friends';

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: tone.cardBox(
        fill: tone.orangeSoft,
        borderColor: tone.orangeBorder,
      ),
      child: Row(
        children: [
          Icon(LucideIcons.send, size: 16, color: tone.orange),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              'You owe ${_inr(total)} to $who',
              style: tone.text(14, FontWeight.w700, tone.ink),
            ),
          ),
          InkWell(
            onTap:
                () => AddTransactionSheet.show(context, startInTripMode: true),
            borderRadius: BorderRadius.circular(999),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: tone.orange,
                borderRadius: BorderRadius.circular(999),
              ),
              child: Text(
                'Pay UPI',
                style: tone.text(12, FontWeight.w700, Colors.white),
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Filter pills, matching the Activity screen's chip treatment: a soft tinted
  /// fill rather than a solid brand slab, so a filter never shouts louder than
  /// the money in the list it filters.
  Widget _buildExpenseFilterTabs(Outing outing) {
    final tone = OutingDetailTone(context);
    final hasSolo = outing.expenses.any((e) => e.splitType == SplitType.solo);
    final tabs = <(_ExpenseFilter, String)>[
      (_ExpenseFilter.all, 'All'),
      (_ExpenseFilter.automatic, 'Automatic'),
      (_ExpenseFilter.manual, 'Manual'),
      if (hasSolo) (_ExpenseFilter.solo, 'Solo'),
      (_ExpenseFilter.split, 'Split'),
    ];
    return SizedBox(
      height: 34,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        itemCount: tabs.length,
        separatorBuilder: (_, __) => const SizedBox(width: AppSpacing.xs),
        itemBuilder: (context, i) {
          final tab = tabs[i];
          final selected = _expenseFilter == tab.$1;
          return GestureDetector(
            onTap: () => setState(() => _expenseFilter = tab.$1),
            behavior: HitTestBehavior.opaque,
            child: Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(
                color: selected ? tone.emerald : tone.card,
                borderRadius: BorderRadius.circular(999),
                border: Border.all(
                  color: selected ? tone.emerald : tone.border,
                ),
              ),
              child: Text(
                tab.$2,
                style: tone.text(
                  13,
                  selected ? FontWeight.w700 : FontWeight.w600,
                  selected ? Colors.white : tone.slate,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildExpenseList(
    Outing outing,
    List<dynamic> manualCashItems,
    List<dynamic> bankDetectedItems,
  ) {
    final mergedItems = <dynamic>[...bankDetectedItems, ...manualCashItems];
    if (mergedItems.isEmpty) {
      return _EmptyNote('No expenses recorded yet');
    }

    List<dynamic> allItems;
    switch (_expenseFilter) {
      case _ExpenseFilter.automatic:
        allItems = mergedItems.where((i) => i is! OutingExpense).toList();
        break;
      case _ExpenseFilter.manual:
        allItems = mergedItems.whereType<OutingExpense>().toList();
        break;
      case _ExpenseFilter.solo:
        allItems =
            mergedItems
                .where(
                  (i) => i is OutingExpense && i.splitType == SplitType.solo,
                )
                .toList();
        break;
      case _ExpenseFilter.split:
        allItems =
            mergedItems
                .where(
                  (i) => i is OutingExpense && i.splitType != SplitType.solo,
                )
                .toList();
        break;
      case _ExpenseFilter.all:
        allItems = mergedItems;
        break;
    }
    if (allItems.isEmpty) {
      return _EmptyNote('No expenses match this filter');
    }

    allItems.sort((a, b) => _activityDate(b).compareTo(_activityDate(a)));

    // Group by outing day for multi-day display
    final Map<int, List<dynamic>> dayGroups = {};
    for (final item in allItems) {
      final dn = _dayNumberForDate(_activityDate(item), outing);
      dayGroups.putIfAbsent(dn, () => []).add(item);
    }
    final sortedDayNums =
        dayGroups.keys.toList()..sort((a, b) => b.compareTo(a)); // recent first

    final startDay = DateTime(
      outing.startDate.year,
      outing.startDate.month,
      outing.startDate.day,
    );
    final endDay = DateTime(
      outing.endDate.year,
      outing.endDate.month,
      outing.endDate.day,
    );
    final isOneDayOuting =
        startDay.isAtSameMomentAs(endDay) || dayGroups.length <= 1;

    Widget buildItemRow(dynamic item) {
      final bool isExpenseObj = item is OutingExpense;
      final bool isPendingObj = item is PendingTransaction;
      final String title =
          isExpenseObj
              ? item.title
              : isPendingObj
              ? item.receiver
              : (item as Transaction).merchant;
      final double amount =
          isExpenseObj
              ? item.amount
              : isPendingObj
              ? item.amount
              : (item as Transaction).amount;
      final String cat =
          isExpenseObj
              ? item.category
              : isPendingObj
              ? 'Other'
              : (item as Transaction).category;
      final String account =
          isExpenseObj
              ? () {
                final acc = (item.accountId ?? '').trim();
                if (acc.isNotEmpty) return acc;
                final mode = (item.paymentMode).trim();
                return mode.isNotEmpty ? mode : 'Cash';
              }()
              : isPendingObj
              ? 'Online'
              : () {
                final tx = item as Transaction;
                final acc = tx.account.trim();
                return acc.isNotEmpty ? acc : tx.paymentType;
              }();
      final bool isPendingVerify =
          isPendingObj ||
          (!isExpenseObj && (item as Transaction).isPendingVerification);
      final bool canUnlink =
          isExpenseObj ||
          isPendingObj ||
          (!isExpenseObj && (item as Transaction).outingId != null);

      // Only "paid by" is surfaced here; the split/settlement breakdown lives on
      // the item's own detail screen, not on this list card.
      String? paidByLabel;
      if (isExpenseObj) {
        paidByLabel = item.paidByLabel(outing);
      } else if (!isPendingObj) {
        final tx = item as Transaction;
        paidByLabel = outing.expenses
            .where((e) => e.transactionId == tx.id)
            .firstOrNull
            ?.paidByLabel(outing);
      }

      final tone = OutingDetailTone(context);
      final splitNote =
          isExpenseObj
              ? (item.splitType == SplitType.solo ? 'Solo' : 'Split')
              : null;
      return GestureDetector(
        onTap: () {
          if (isExpenseObj) {
            if (item.transactionId != null && item.transactionId!.isNotEmpty) {
              context.push('/transaction/${item.transactionId}');
            } else {
              context.push('/outing-expense/${outing.id}/${item.id}');
            }
          } else if (isPendingObj) {
            PremiumBottomSheet.show(
              context: context,
              child: DetectionPopup(
                pendingTx: AutoRuleEngine.pendingToTransaction(item),
              ),
            );
          } else {
            context.push('/transaction/${(item as Transaction).id}');
          }
        },
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(14),
          decoration: tone.cardBox(
            borderColor: isPendingVerify ? tone.orangeBorder : tone.border,
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: _getCatColor(cat).withValues(alpha: 0.14),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(
                  _getCatIcon(cat),
                  size: 18,
                  color: _getCatColor(cat),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: tone.text(15, FontWeight.w700, tone.ink),
                    ),
                    const SizedBox(height: 3),
                    if (paidByLabel != null)
                      Text(
                        'Paid by $paidByLabel',
                        style: tone.text(
                          12,
                          FontWeight.w500,
                          paidByLabel == 'You' ? tone.slate : tone.emeraldDeep,
                        ),
                      ),
                    Text(
                      splitNote == null
                          ? '$cat · $account'
                          : '$cat · $account · $splitNote',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: tone.text(12, FontWeight.w500, tone.slate),
                    ),
                  ],
                ),
              ),
              if (canUnlink)
                GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap:
                      () => _confirmAndUnlink(
                        item: item,
                        outing: outing,
                        title: title,
                        amount: amount,
                        isExpenseObj: isExpenseObj,
                        isPendingObj: isPendingObj,
                      ),
                  child: Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: Icon(
                      LucideIcons.unlink,
                      size: 16,
                      color: tone.muted,
                    ),
                  ),
                ),
              Text(
                _inr(amount),
                style: tone.text(15, FontWeight.w800, tone.ink),
              ),
            ],
          ),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        for (final dn in sortedDayNums) ...[
          if (!isOneDayOuting) ...[
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: OutingDetailTone(context).mint,
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      'DAY $dn',
                      style: OutingDetailTone(context).text(
                        11,
                        FontWeight.w700,
                        OutingDetailTone(context).emeraldDeep,
                        letterSpacing: 0.6,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    DateFormat(
                      'd MMM yyyy',
                    ).format(startDay.add(Duration(days: dn - 1))),
                    style: OutingDetailTone(context).text(
                      12,
                      FontWeight.w500,
                      OutingDetailTone(context).slate,
                    ),
                  ),
                ],
              ),
            ),
          ],
          ...dayGroups[dn]!.map((item) => buildItemRow(item)),
          if (dn != sortedDayNums.last) const SizedBox(height: 12),
        ],
      ],
    );
  }

  void _showOutingMenu(BuildContext context, Outing outing) {
    final sheetBg = context.tokens.card;
    final onSurface = context.tokens.textPrimary;
    final muted = context.tokens.textSecondary;
    final handle = context.tokens.border;

    showModalBottomSheet(
      context: context,
      backgroundColor: sheetBg,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        final bottomInset = MediaQuery.paddingOf(ctx).bottom;
        return Padding(
          padding: EdgeInsets.fromLTRB(8, 12, 8, 16 + bottomInset),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: handle,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 8),
              ListTile(
                leading: Icon(LucideIcons.edit, color: muted),
                title: Text(
                  'Edit Trip Details',
                  style: TextStyle(
                    color: onSurface,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                onTap: () {
                  Navigator.pop(ctx);
                  PremiumBottomSheet.show(
                    context: context,
                    child: CreateOutingSheet(outing: outing),
                  );
                },
              ),
              if (outing.isActive)
                ListTile(
                  leading: const Icon(
                    LucideIcons.checkCircle,
                    color: AppColors.income,
                  ),
                  title: Text(
                    'End Trip & Settle',
                    style: TextStyle(
                      color: onSurface,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  onTap: () {
                    ref.read(outingProvider.notifier).endOutingEarly(outing.id);
                    Navigator.pop(ctx);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Trip ended successfully!'),
                        backgroundColor: AppColors.income,
                      ),
                    );
                  },
                ),
              ListTile(
                leading: const Icon(
                  LucideIcons.trash2,
                  color: AppColors.expense,
                ),
                title: const Text(
                  'Delete trip',
                  style: TextStyle(
                    color: AppColors.expense,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                onTap: () {
                  Navigator.pop(ctx); // Close more menu
                  showDialog(
                    context: context,
                    builder: (confirmCtx) {
                      final d =
                          Theme.of(confirmCtx).brightness == Brightness.dark;
                      return AlertDialog(
                        backgroundColor:
                            d ? AppColors.darkCard : AppColors.lightSurface,
                        surfaceTintColor: Colors.transparent,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        title: Text(
                          'Delete Trip?',
                          style: TextStyle(
                            color:
                                d
                                    ? AppColors.darkTextPrimary
                                    : AppColors.lightTextPrimary,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        content: Text(
                          'This removes the trip and its expenses right away. You can restore it anytime from Settings > Deleted Outings.',
                          style: TextStyle(
                            color:
                                d
                                    ? AppColors.darkTextSecondary
                                    : AppColors.lightTextSecondary,
                          ),
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(confirmCtx),
                            child: Text(
                              'Cancel',
                              style: TextStyle(
                                color:
                                    d
                                        ? AppColors.darkTextSecondary
                                        : AppColors.lightTextSecondary,
                              ),
                            ),
                          ),
                          ElevatedButton(
                            onPressed: () async {
                              await cascadeDeleteOuting(ref, outing.id);
                              if (!confirmCtx.mounted) return;
                              Navigator.pop(confirmCtx);
                              if (!context.mounted) return;
                              context.pop(); // Go back from detail screen
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundBuilder: SoftColors.plainBackground,
                              backgroundColor: AppColors.expense,
                              foregroundColor: AppColors.onAccent(
                                AppColors.expense,
                              ),
                            ),
                            child: const Text('Delete'),
                          ),
                        ],
                      );
                    },
                  );
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildRepaymentHistory(Outing outing) {
    final youMemberId =
        outing.members
            .where((m) => m.name.toLowerCase() == 'you')
            .firstOrNull
            ?.id;

    final settledExpenses =
        outing.expenses.where((e) => e.settlementPayments.isNotEmpty).toList();

    if (settledExpenses.isEmpty) {
      final tone = OutingDetailTone(context);
      return OutingDetailCard(
        child: Row(
          children: [
            Icon(LucideIcons.history, size: 16, color: tone.slate),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                'No settlements recorded yet',
                style: tone.text(12, FontWeight.w500, tone.slate),
              ),
            ),
          ],
        ),
      );
    }

    final List<Map<String, dynamic>> settlements = [];
    for (final e in settledExpenses) {
      for (final entry in e.settlementPayments.entries) {
        if (youMemberId != null && entry.key == youMemberId) continue;
        final memberName =
            outing.members
                .firstWhere(
                  (m) => m.id == entry.key,
                  orElse: () => OutingMember(name: 'Someone'),
                )
                .name;
        for (final p in entry.value) {
          settlements.add({
            'name': memberName,
            'expense': e.title,
            'amount': p.amount.toInt(),
            'mode': p.mode,
            'date': p.date,
          });
        }
      }
    }
    settlements.sort(
      (a, b) => (b['date'] as DateTime).compareTo(a['date'] as DateTime),
    );

    if (settlements.isEmpty) {
      return _EmptyNote('No returns yet');
    }

    final tone = OutingDetailTone(context);
    return OutingDetailCard(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      child: Column(
        children: [
          for (var i = 0; i < settlements.length; i++) ...[
            if (i > 0) Divider(height: 1, color: tone.border),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Row(
                children: [
                  Container(
                    width: 36,
                    height: 36,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: tone.mint,
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      LucideIcons.check,
                      size: 16,
                      color: tone.emeraldDeep,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text.rich(
                          TextSpan(
                            style: tone.text(13, FontWeight.w500, tone.ink),
                            children: [
                              TextSpan(
                                text: '${settlements[i]['name']}',
                                style: tone.text(13, FontWeight.w700, tone.ink),
                              ),
                              TextSpan(
                                text:
                                    ' paid ${_inr(settlements[i]['amount'] as int)} (${settlements[i]['mode']}) to you for ',
                                style: tone.text(
                                  12,
                                  FontWeight.w500,
                                  tone.slate,
                                ),
                              ),
                              TextSpan(
                                text: '${settlements[i]['expense']}',
                                style: tone.text(
                                  12,
                                  FontWeight.w700,
                                  tone.emeraldDeep,
                                ),
                              ),
                            ],
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 2),
                        Text(
                          DateFormat(
                            'd MMM, h:mm a',
                          ).format(settlements[i]['date'] as DateTime),
                          style: tone.text(11, FontWeight.w500, tone.muted),
                        ),
                        if ('${settlements[i]['mode']}'.toLowerCase().contains(
                          'upi',
                        )) ...[
                          const SizedBox(height: 4),
                          Text(
                            'UPI Auto-verified',
                            style: tone.text(
                              11,
                              FontWeight.w700,
                              tone.emeraldDeep,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    _inr(settlements[i]['amount'] as int),
                    style: tone.text(14, FontWeight.w800, tone.emeraldDeep),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Color _getCatColor(String cat) {
    switch (cat.toLowerCase()) {
      case 'food':
      case 'restaurant':
        return const Color(0xFFEA580C);
      case 'shopping':
        return const Color(0xFFD97706);
      case 'transport':
      case 'travel':
      case 'flight':
        return const Color(0xFF059669);
      case 'stay':
      case 'hotel stay':
      case 'hotel':
        return const Color(0xFF0F766E);
      case 'entertainment':
        return const Color(0xFFE11D48);
      case 'temple':
        return const Color(0xFFB45309);
      case 'bills':
        return const Color(0xFF10B981);
      default:
        return const Color(0xFF059669);
    }
  }

  IconData _getCatIcon(String cat) {
    switch (cat.toLowerCase()) {
      case 'food':
      case 'restaurant':
        return LucideIcons.utensils;
      case 'shopping':
        return LucideIcons.shoppingBag;
      case 'transport':
        return LucideIcons.car;
      case 'flight':
        return LucideIcons.plane;
      case 'entertainment':
        return LucideIcons.film;
      case 'temple':
        return LucideIcons.landmark;
      case 'hotel stay':
        return LucideIcons.hotel;
      default:
        return LucideIcons.receipt;
    }
  }
}

/// Centred muted note for the page's empty states, which each used to inline
/// `Colors.grey` (2.83:1 on a white card).
class _EmptyNote extends StatelessWidget {
  final String message;
  const _EmptyNote(this.message);
  @override
  Widget build(BuildContext context) {
    final tone = OutingDetailTone(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Center(
        child: Text(
          message,
          textAlign: TextAlign.center,
          style: tone.text(13, FontWeight.w500, tone.slate),
        ),
      ),
    );
  }
}

/// Section heading with an optional trailing text action.
///
/// Was `Colors.grey` (#9E9E9E), which measures 2.83:1 on a white card — the
/// labels naming every section on this page were failing AA.
class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle(this.title);

  @override
  Widget build(BuildContext context) {
    final tone = OutingDetailTone(context);
    return Text(
      title,
      style: tone.text(11, FontWeight.w700, tone.muted, letterSpacing: 1.2),
    );
  }
}

/// One figure in the hero card's supporting row. Deliberately *not* a boxed
/// card: the page used to render up to eight identically-styled bordered
/// tiles, so no number read as more important than any other.
class _StatCell extends StatelessWidget {
  final String label;
  final String value;
  final bool onDark;
  final bool emphasize;
  const _StatCell({
    required this.label,
    required this.value,
    this.onDark = false,
    this.emphasize = false,
  });

  @override
  Widget build(BuildContext context) {
    final tone = OutingDetailTone(context);
    final labelColor =
        onDark ? Colors.white.withValues(alpha: 0.7) : tone.slate;
    final valueColor =
        onDark
            ? (emphasize ? const Color(0xFFA7F3D0) : Colors.white)
            : tone.ink;
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            label,
            style: tone.text(10, FontWeight.w600, labelColor),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 2),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(
              value,
              style: tone.text(14, FontWeight.w800, valueColor),
            ),
          ),
        ],
      ),
    );
  }
}

class _CellDivider extends StatelessWidget {
  final bool onDark;
  const _CellDivider({this.onDark = false});
  @override
  Widget build(BuildContext context) => Container(
    width: 1,
    height: 26,
    margin: const EdgeInsets.symmetric(horizontal: 8),
    color:
        onDark
            ? Colors.white.withValues(alpha: 0.2)
            : OutingDetailTone(context).border,
  );
}

/// One friend's net position on this trip, plus what to do about it.
///
/// Soft-minimalist balance badge chrome (Settled / Owes you / You owe)
/// matching spentx_outing stitch pills.
class _BalanceRow extends StatelessWidget {
  final String name;
  final double net;
  final VoidCallback? onSettle;
  const _BalanceRow({required this.name, required this.net, this.onSettle});

  @override
  Widget build(BuildContext context) {
    final tone = OutingDetailTone(context);
    final settled = net.abs() <= 0.01;
    final owesYou = net > 0.01;
    final badgeLabel =
        settled ? 'Settled' : (owesYou ? 'You receive' : 'You owe');
    final badgeFill =
        settled ? tone.mint : (owesYou ? tone.mint : tone.orangeSoft);
    final badgeInk =
        settled ? tone.emeraldDeep : (owesYou ? tone.emeraldDeep : tone.orange);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            alignment: Alignment.center,
            decoration: BoxDecoration(color: tone.mint, shape: BoxShape.circle),
            child: Text(
              name.isEmpty ? '?' : name[0].toUpperCase(),
              style: tone.text(13, FontWeight.w700, tone.emeraldDeep),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: tone.text(14, FontWeight.w700, tone.ink),
                ),
                Text(
                  settled ? 'Settled' : (owesYou ? 'Owes you' : 'You owe'),
                  style: tone.text(12, FontWeight.w500, tone.slate),
                ),
              ],
            ),
          ),
          Text(
            _inr(net.abs()),
            style: tone.text(
              14,
              FontWeight.w800,
              settled ? tone.ink : (owesYou ? tone.emeraldDeep : tone.orange),
            ),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: badgeFill,
              borderRadius: BorderRadius.circular(999),
            ),
            child: Text(
              badgeLabel,
              style: tone.text(11, FontWeight.w700, badgeInk),
            ),
          ),
          if (!settled && onSettle != null) ...[
            const SizedBox(width: 4),
            TextButton(
              onPressed: onSettle,
              style: TextButton.styleFrom(
                minimumSize: const Size(0, 30),
                padding: const EdgeInsets.symmetric(horizontal: 6),
                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                foregroundColor: tone.emeraldDeep,
              ),
              child: Text(
                'Settle',
                style: tone.text(12, FontWeight.w700, tone.emeraldDeep),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

/// How the trip was paid for — manual entries vs bank-detected — as a two-row
/// summary. The per-item title bullets it used to print were a duplicate of
/// the Activity list directly below it, so they're gone; the counts stay.
class _PaymentRow extends StatelessWidget {
  final String label;
  final double paid;
  final double rec;
  final IconData icon;
  final bool showRecv;
  const _PaymentRow({
    required this.label,
    required this.paid,
    required this.rec,
    required this.icon,
    required this.showRecv,
  });

  @override
  Widget build(BuildContext context) {
    final tone = OutingDetailTone(context);
    return Row(
      children: [
        Container(
          width: 40,
          height: 40,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: tone.mint,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Icon(icon, size: 18, color: tone.emeraldDeep),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            label,
            style: tone.text(14, FontWeight.w600, tone.ink),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
        ),
        const SizedBox(width: 8),
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_inr(paid), style: tone.text(14, FontWeight.w800, tone.ink)),
            if (showRecv && rec > 0.01) ...[
              const SizedBox(height: 4),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: tone.mint,
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  '+${_inr(rec)}',
                  style: tone.text(11, FontWeight.w700, tone.emeraldDeep),
                ),
              ),
            ],
          ],
        ),
      ],
    );
  }
}
