import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../../../core/theme/soft_palette.dart';

/// Confirms removing an expense from a trip before unlink runs.
class OutingUnlinkDialog {
  OutingUnlinkDialog._();

  static Future<bool> confirm(
    BuildContext context, {
    required String itemName,
    double? amount,
    bool isPendingOnly = false,
  }) async {
    final amountLine = amount != null ? '₹${amount.toInt()}' : null;
    final label = '"$itemName"${amountLine != null ? ' ($amountLine)' : ''}';
    // Both non-pending cases now say the same thing, because they now DO the
    // same thing: a manual trip entry used to be deleted outright on unlink,
    // so this copy warned about that. It is converted to a normal transaction
    // instead, so the spend survives either way.
    final body =
        isPendingOnly
            ? 'Remove $label from this trip? It will stay in detected SMS until you verify again.'
            : 'Remove $label from this trip? The transaction stays in Activity as a '
                'normal expense; only the trip link is removed.';

    final result = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder:
          (ctx) => AlertDialog(
            backgroundColor: SoftPalette.surface,
            surfaceTintColor: Colors.transparent,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24),
            ),
            title: const Row(
              children: [
                Icon(LucideIcons.unlink, color: SoftPalette.emerald, size: 22),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Unlink from trip?',
                    style: TextStyle(
                      color: SoftPalette.ink,
                      fontWeight: FontWeight.w700,
                      fontSize: 18,
                    ),
                  ),
                ),
              ],
            ),
            content: Text(
              body,
              style: const TextStyle(
                color: SoftPalette.muted,
                fontSize: 14,
                height: 1.45,
              ),
            ),
            actionsPadding: const EdgeInsets.fromLTRB(20, 0, 20, 18),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                style: TextButton.styleFrom(
                  foregroundColor: SoftPalette.muted,
                  textStyle: const TextStyle(fontWeight: FontWeight.w600),
                ),
                child: const Text('Cancel'),
              ),
              ElevatedButton(
                onPressed: () => Navigator.pop(ctx, true),
                style: ElevatedButton.styleFrom(
                  backgroundColor: SoftColors.control,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                child: const Text(
                  'Unlink',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
            ],
          ),
    );
    return result == true;
  }
}
