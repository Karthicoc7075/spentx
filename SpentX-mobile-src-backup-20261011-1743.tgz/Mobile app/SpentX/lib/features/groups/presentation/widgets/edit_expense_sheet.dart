import 'package:flutter/material.dart';
import '../../../../core/theme/spentx_tokens.dart';
import '../../../../core/theme/soft_palette.dart';
import '../../../../core/widgets/reference_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/providers/transaction_provider.dart';

class EditExpenseSheet extends ConsumerStatefulWidget {
  final Transaction transaction;
  const EditExpenseSheet({super.key, required this.transaction});

  @override
  ConsumerState<EditExpenseSheet> createState() => _EditExpenseSheetState();
}

class _EditExpenseSheetState extends ConsumerState<EditExpenseSheet> {
  late TextEditingController _nameController;
  late TextEditingController _amountController;
  late String _accountType;

  bool _hasMerchantError = false;
  bool _hasAmountError = false;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.transaction.merchant);
    _amountController = TextEditingController(
      text: widget.transaction.amount.toString(),
    );
    _accountType = widget.transaction.account;
  }

  @override
  void dispose() {
    _nameController.dispose();
    _amountController.dispose();
    super.dispose();
  }

  void _saveChanges() {
    final name = _nameController.text.trim();
    final amountText = _amountController.text.trim();
    final amount = double.tryParse(amountText) ?? 0;

    setState(() {
      _hasMerchantError = name.isEmpty;
      _hasAmountError = amount <= 0;
    });

    if (_hasMerchantError || _hasAmountError) return;

    final updated = widget.transaction.copyWith(
      merchant: name,
      amount: amount,
      account: _accountType,
    );
    ref.read(transactionProvider.notifier).updateTransaction(updated);
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Expense updated successfully!'),
        backgroundColor: AppColors.income,
      ),
    );
  }

  void _removeFromOuting() {
    ref
        .read(transactionProvider.notifier)
        .updateTransactionOuting(widget.transaction.id, null);
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Removed from outing. Now a normal transaction.'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 24,
        right: 24,
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
        top: 24,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'Manage Expense',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      color: SoftPalette.ink,
                    ),
                  ),
                ),
                SoftCircleIconButton(
                  icon: Icons.close_rounded,
                  tooltip: 'Close',
                  onPressed: () => Navigator.maybePop(context),
                ),
              ],
            ),
            const SizedBox(height: 24),

            // ── Section: Quick Actions ──
            if (widget.transaction.outingId != null) ...[
              _MenuActionTile(
                icon: LucideIcons.link2Off,
                label: 'Remove from Outing',
                subtitle: 'Convert back to normal expense',
                color: AppColors.expense,
                onTap: _removeFromOuting,
              ),
              const Divider(height: 32),
            ],

            // ── Section: Basic Info ──
            Container(
              decoration: BoxDecoration(
                border:
                    _hasMerchantError
                        ? Border.all(color: AppColors.expense, width: 1.5)
                        : null,
                borderRadius: BorderRadius.circular(12),
              ),
              child: TextField(
                controller: _nameController,
                onChanged: (v) {
                  if (_hasMerchantError && v.trim().isNotEmpty) {
                    setState(() => _hasMerchantError = false);
                  }
                },
                decoration: InputDecoration(
                  filled: true,
                  fillColor: context.tokens.field,
                  labelText: _hasMerchantError ? 'Name Required' : 'Name',
                  labelStyle: TextStyle(
                    color: _hasMerchantError ? AppColors.expense : null,
                  ),
                  prefixIcon: Icon(
                    LucideIcons.shoppingBag,
                    size: 18,
                    color: _hasMerchantError ? AppColors.expense : null,
                  ),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 8,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Container(
              decoration: BoxDecoration(
                border:
                    _hasAmountError
                        ? Border.all(color: AppColors.expense, width: 1.5)
                        : null,
                borderRadius: BorderRadius.circular(12),
              ),
              child: TextField(
                controller: _amountController,
                keyboardType: TextInputType.number,
                onChanged: (v) {
                  if (_hasAmountError && (double.tryParse(v) ?? 0) > 0) {
                    setState(() => _hasAmountError = false);
                  }
                },
                decoration: InputDecoration(
                  filled: true,
                  fillColor: context.tokens.field,
                  labelText: _hasAmountError ? 'Amount Required' : 'Amount',
                  labelStyle: TextStyle(
                    color: _hasAmountError ? AppColors.expense : null,
                  ),
                  prefixIcon: Icon(
                    LucideIcons.indianRupee,
                    size: 18,
                    color: _hasAmountError ? AppColors.expense : null,
                  ),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 8,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 24),

            // ── Section: Account Type ──
            Text(
              'Account Type',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w500,
                color: Theme.of(
                  context,
                ).colorScheme.onSurface.withValues(alpha: 0.55),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                _AccountToggleButton(
                  label: 'Personal',
                  icon: LucideIcons.user,
                  isSelected: _accountType == 'Personal',
                  onTap: () => setState(() => _accountType = 'Personal'),
                ),
                const SizedBox(width: 12),
                _AccountToggleButton(
                  label: 'Home',
                  icon: LucideIcons.home,
                  isSelected: _accountType == 'Home',
                  onTap: () => setState(() => _accountType = 'Home'),
                ),
              ],
            ),
            const SizedBox(height: 32),

            // ── Save Button ──
            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton(
                onPressed: _saveChanges,
                style: ElevatedButton.styleFrom(
                  backgroundColor: SoftColors.control,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  elevation: 0,
                ),
                child: const Text(
                  'Save Changes',
                  style: TextStyle(fontWeight: FontWeight.w500, fontSize: 16),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MenuActionTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  const _MenuActionTile({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final muted = Theme.of(
      context,
    ).colorScheme.onSurface.withValues(alpha: 0.55);
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, size: 20, color: color),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: TextStyle(
                      fontWeight: FontWeight.w500,
                      fontSize: 14,
                      color: color,
                    ),
                  ),
                  Text(subtitle, style: TextStyle(fontSize: 11, color: muted)),
                ],
              ),
            ),
            Icon(LucideIcons.chevronRight, size: 16, color: muted),
          ],
        ),
      ),
    );
  }
}

class _AccountToggleButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool isSelected;
  final VoidCallback onTap;

  const _AccountToggleButton({
    required this.label,
    required this.icon,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color:
                isSelected
                    ? AppColors.primary.withValues(alpha: 0.1)
                    : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isSelected ? AppColors.primary : (context.tokens.border),
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                size: 16,
                color:
                    isSelected
                        ? AppColors.primary
                        : (context.tokens.textSecondary),
              ),
              const SizedBox(width: 8),
              Text(
                label,
                style: TextStyle(
                  fontWeight: isSelected ? FontWeight.w500 : FontWeight.normal,
                  color: isSelected ? AppColors.primary : null,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
