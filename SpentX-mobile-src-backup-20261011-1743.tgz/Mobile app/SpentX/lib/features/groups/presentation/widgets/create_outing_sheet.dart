import 'package:flutter/material.dart';
import '../../../../core/theme/soft_palette.dart';
import '../../../../core/widgets/soft_page_kit.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:intl/intl.dart';
import '../../../../core/theme/app_colors.dart';
import '../../data/outing_provider.dart';
import '../../../../core/providers/friends_provider.dart';
import '../../../../core/providers/user_state_provider.dart';
import '../../../../features/friends/presentation/friend_picker_screen.dart';

class CreateOutingSheet extends ConsumerStatefulWidget {
  final Outing? outing;
  const CreateOutingSheet({super.key, this.outing});

  @override
  ConsumerState<CreateOutingSheet> createState() => _CreateOutingSheetState();
}

class _CreateOutingSheetState extends ConsumerState<CreateOutingSheet> {
  late final TextEditingController _titleCtrl;
  late final TextEditingController _locationCtrl;
  late final TextEditingController _quickNameCtrl;
  late final TextEditingController _budgetCtrl;

  late String _selectedCategory;
  late String _selectedPurpose;
  late DateTime _startDate;
  late DateTime _endDate;
  late List<OutingMember> _tempMembers;

  bool _hasTitleError = false;

  @override
  void initState() {
    super.initState();
    final o = widget.outing;
    _titleCtrl = TextEditingController(text: o?.title ?? '');
    _locationCtrl = TextEditingController(text: o?.location ?? '');
    _quickNameCtrl = TextEditingController();
    _budgetCtrl = TextEditingController(
      text: o?.budget != null ? o!.budget!.toStringAsFixed(0) : '',
    );

    _selectedCategory = o?.category ?? 'Trip';
    _selectedPurpose = o?.purpose ?? 'Personal';
    _startDate = o?.startDate ?? DateTime.now();
    _endDate = o?.endDate ?? DateTime.now().add(const Duration(days: 2));

    _tempMembers =
        o != null
            ? List<OutingMember>.from(o.members)
            : [OutingMember(name: 'You', isCurrentUser: true)];
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _locationCtrl.dispose();
    _quickNameCtrl.dispose();
    _budgetCtrl.dispose();
    super.dispose();
  }

  bool _isOnTrip(String name) =>
      _tempMembers.any((m) => m.name.toLowerCase() == name.toLowerCase());

  void _addMemberToTrip({
    required String name,
    String? upiId,
    String? friendId,
  }) {
    final trimmed = name.trim();
    if (trimmed.isEmpty || trimmed.toLowerCase() == 'you') return;
    if (_isOnTrip(trimmed)) return;
    setState(() {
      _tempMembers.add(
        OutingMember(
          name: trimmed,
          upiId: upiId,
          friendId: friendId,
          isCurrentUser: false,
        ),
      );
    });
    // Name-only friends are fine; UPI can be added later on Friends page.
    ref.read(manualFriendsProvider.notifier).addFriends([trimmed]);
  }

  void _removeMember(OutingMember m) {
    if (m.isCurrentUser || m.name.toLowerCase() == 'you') return;
    setState(() => _tempMembers.remove(m));
  }

  void _toggleFriend(Friend f) {
    if (_isOnTrip(f.name)) {
      setState(() {
        _tempMembers.removeWhere(
          (m) => m.name.toLowerCase() == f.name.toLowerCase(),
        );
      });
      return;
    }
    final upi =
        f.upiId?.trim().isNotEmpty == true
            ? f.upiId
            : (f.upiIds.isNotEmpty ? f.upiIds.first : null);
    _addMemberToTrip(name: f.name, upiId: upi);
  }

  void _openContactsPicker() {
    final alreadyAdded = _tempMembers.map((m) => m.name).toSet();
    Navigator.push(
      context,
      MaterialPageRoute(
        builder:
            (_) => FriendPickerScreen(
              outingMemberNames: alreadyAdded,
              onSelect: (result) {
                _addMemberToTrip(name: result.name, upiId: result.upiId);
              },
            ),
      ),
    );
  }

  void _showAddCustomCategoryDialog() {
    final textCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(SoftKit.radius),
          ),
          backgroundColor: SoftKit.card(context),
          surfaceTintColor: Colors.transparent,
          title: Text(
            'Add category',
            style: SoftKit.text(
              context,
              18,
              FontWeight.w700,
              SoftKit.ink(context),
            ),
          ),
          content: TextField(
            controller: textCtrl,
            autofocus: true,
            textCapitalization: TextCapitalization.words,
            style: const TextStyle(fontWeight: FontWeight.w500),
            decoration: SoftKit.input(
              context,
              hint: 'e.g. Camping, Concert',
              label: 'Category name',
            ),
            onSubmitted: (v) {
              final val = v.trim();
              if (val.isEmpty) return;
              ref.read(outingProvider.notifier).addGlobalCategory(val);
              setState(() => _selectedCategory = val);
              Navigator.pop(context);
            },
          ),
          actions: [
            Row(
              children: [
                Expanded(
                  child: SoftKitButton.secondary(
                    label: 'Cancel',
                    height: 44,
                    onPressed: () => Navigator.pop(context),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: SoftKitButton(
                    label: 'Add',
                    height: 44,
                    onPressed: () {
                      final val = textCtrl.text.trim();
                      if (val.isEmpty) return;
                      ref.read(outingProvider.notifier).addGlobalCategory(val);
                      setState(() => _selectedCategory = val);
                      Navigator.pop(context);
                    },
                  ),
                ),
              ],
            ),
          ],
        );
      },
    );
  }

  Future<void> _pickStartDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _startDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
    );
    if (picked != null) {
      setState(() {
        _startDate = DateTime(picked.year, picked.month, picked.day);
        if (_endDate.isBefore(_startDate)) {
          _endDate = _startDate;
        }
      });
    }
  }

  Future<void> _pickEndDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _endDate.isBefore(_startDate) ? _startDate : _endDate,
      firstDate: _startDate,
      lastDate: DateTime(2030),
    );
    if (picked != null) {
      setState(() {
        _endDate = DateTime(picked.year, picked.month, picked.day);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final categories = ref.watch(outingProvider.notifier).globalCategories;
    final purposes = ref.watch(userStateProvider).purposeTypes;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final bottomInset = MediaQuery.of(context).viewInsets.bottom;

    return SizedBox(
      width: double.infinity,
      child: SingleChildScrollView(
        padding: EdgeInsets.fromLTRB(20, 20, 20, 20 + bottomInset),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    widget.outing != null ? 'Edit Trip' : 'Start New Outing',
                    style: SoftKit.text(
                      context,
                      20,
                      FontWeight.w800,
                      SoftKit.ink(context),
                    ),
                  ),
                ),
                SoftKitCircleButton(
                  icon: Icons.close_rounded,
                  tooltip: 'Close',
                  onPressed: () => Navigator.maybePop(context),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              'Active trip dates can receive SMS spends when auto-detect is on in Settings.',
              style: SoftKit.text(
                context,
                12,
                FontWeight.w500,
                SoftKit.slate(context),
              ),
            ),
            const SizedBox(height: 18),

            _sectionLabel('TRIP TITLE'),
            TextField(
              controller: _titleCtrl,
              cursorColor: SoftKit.plusGreen,
              onChanged: (val) {
                if (_hasTitleError && val.trim().isNotEmpty) {
                  setState(() => _hasTitleError = false);
                }
              },
              style: SoftKit.text(
                context,
                15,
                FontWeight.w600,
                SoftKit.ink(context),
              ),
              decoration: SoftKit.input(
                context,
                hint: 'e.g. Goa Trip 2024',
                errorText: _hasTitleError ? 'Title is required' : null,
              ),
            ),
            const SizedBox(height: 16),

            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _sectionLabel('CATEGORY'),
                      DropdownButtonFormField<String>(
                        initialValue:
                            categories.contains(_selectedCategory)
                                ? _selectedCategory
                                : (categories.isNotEmpty
                                    ? categories.first
                                    : 'Trip'),
                        isExpanded: true,
                        icon: Icon(
                          LucideIcons.chevronDown,
                          size: 18,
                          color: SoftKit.slate(context),
                        ),
                        dropdownColor: SoftKit.card(context),
                        borderRadius: BorderRadius.circular(16),
                        decoration: SoftKit.input(context),
                        items: [
                          ...categories.map(
                            (c) => DropdownMenuItem(
                              value: c,
                              child: Text(
                                c == 'Other' ? 'Other…' : c,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontSize: 14),
                              ),
                            ),
                          ),
                          const DropdownMenuItem(
                            value: '__add_new__',
                            child: Row(
                              children: [
                                Icon(
                                  LucideIcons.plus,
                                  size: 15,
                                  color: AppColors.primary,
                                ),
                                SizedBox(width: 6),
                                Expanded(
                                  child: Text(
                                    'Add category',
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      color: AppColors.primary,
                                      fontWeight: FontWeight.w600,
                                      fontSize: 13,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                        onChanged: (v) {
                          if (v == null) return;
                          if (v == 'Other' || v == '__add_new__') {
                            _showAddCustomCategoryDialog();
                            return;
                          }
                          setState(() => _selectedCategory = v);
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _sectionLabel('LOCATION'),
                      TextField(
                        controller: _locationCtrl,
                        cursorColor: SoftKit.plusGreen,
                        decoration: SoftKit.input(context, hint: 'Optional'),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 16),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _sectionLabel('PURPOSE'),
                      DropdownButtonFormField<String>(
                        initialValue:
                            purposes.contains(_selectedPurpose)
                                ? _selectedPurpose
                                : (purposes.isNotEmpty
                                    ? purposes.first
                                    : 'Personal'),
                        isExpanded: true,
                        icon: Icon(
                          LucideIcons.chevronDown,
                          size: 18,
                          color: SoftKit.slate(context),
                        ),
                        dropdownColor: SoftKit.card(context),
                        borderRadius: BorderRadius.circular(16),
                        decoration: SoftKit.input(context),
                        items:
                            purposes
                                .map(
                                  (p) => DropdownMenuItem(
                                    value: p,
                                    child: Text(
                                      p,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(fontSize: 14),
                                    ),
                                  ),
                                )
                                .toList(),
                        onChanged: (v) {
                          if (v == null) return;
                          setState(() => _selectedPurpose = v);
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _sectionLabel('BUDGET'),
                      TextField(
                        controller: _budgetCtrl,
                        cursorColor: SoftKit.plusGreen,
                        keyboardType: TextInputType.number,
                        decoration: SoftKit.input(context, hint: 'Optional'),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 16),
            _sectionLabel('TRIP DATES'),
            Row(
              children: [
                Expanded(
                  child: _DatePickerTile(
                    label: 'START DATE',
                    date: _startDate,
                    isDark: isDark,
                    onTap: _pickStartDate,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _DatePickerTile(
                    label: 'END DATE',
                    date: _endDate,
                    isDark: isDark,
                    onTap: _pickEndDate,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              'Becomes Active on the start date. Completes automatically the day after the end date.',
              style: SoftKit.text(
                context,
                11,
                FontWeight.w500,
                SoftKit.slate(context),
              ),
            ),

            const SizedBox(height: 18),
            _sectionLabel('MEMBERS ON THIS TRIP'),
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text(
                'Name is enough — UPI can be added later on Friends.',
                style: SoftKit.text(
                  context,
                  12,
                  FontWeight.w500,
                  SoftKit.slate(context),
                ),
              ),
            ),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children:
                  _tempMembers
                      .map(
                        (m) => Chip(
                          backgroundColor: SoftKit.field(context),
                          side: BorderSide(color: SoftKit.fieldBorder(context)),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          labelStyle: SoftKit.text(
                            context,
                            13,
                            FontWeight.w600,
                            SoftKit.ink(context),
                          ),
                          label: Text(
                            (m.upiId != null && m.upiId!.trim().isNotEmpty)
                                ? '${m.name} · ${m.upiId}'
                                : m.name,
                          ),
                          onDeleted:
                              (m.isCurrentUser || m.name == 'You')
                                  ? null
                                  : () => _removeMember(m),
                        ),
                      )
                      .toList(),
            ),
            const SizedBox(height: 14),

            // Saved friends chips (tap to add to trip) directly below Quick Add
            _sectionLabel('YOUR FRIENDS (TAP TO ADD)'),
            Builder(
              builder: (context) {
                final friends = ref.watch(friendsProvider);
                if (friends.isEmpty) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Text(
                      'No saved friends yet. Tap "Add from contacts" below to pick friends.',
                      style: SoftKit.text(
                        context,
                        12,
                        FontWeight.w500,
                        SoftKit.slate(context),
                      ),
                    ),
                  );
                }
                return Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children:
                      friends.map((f) {
                        final onTrip = _isOnTrip(f.name);
                        return FilterChip(
                          selected: onTrip,
                          label: Text(
                            f.name,
                            style: TextStyle(
                              fontWeight:
                                  onTrip ? FontWeight.bold : FontWeight.w500,
                              color:
                                  onTrip
                                      ? Colors.white
                                      : SoftKit.ink(context),
                            ),
                          ),
                          avatar: CircleAvatar(
                            radius: 12,
                            backgroundColor:
                                onTrip
                                    ? Colors.white
                                    : SoftKit.fieldBorder(context),
                            child: Text(
                              f.name.isNotEmpty ? f.name[0].toUpperCase() : 'F',
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                color:
                                    onTrip
                                        ? SoftKit.primaryGreen
                                        : SoftKit.ink(context),
                              ),
                            ),
                          ),
                          onSelected: (_) => _toggleFriend(f),
                          selectedColor: SoftColors.control,
                          checkmarkColor: Colors.white,
                          backgroundColor: SoftKit.field(context),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                            side: BorderSide(
                              color:
                                  onTrip
                                      ? SoftKit.primaryGreen
                                      : SoftKit.fieldBorder(context),
                              width: 1,
                            ),
                          ),
                        );
                      }).toList(),
                );
              },
            ),
            const SizedBox(height: 12),
            SoftKitButton.secondary(
              label: 'Add from contacts',
              icon: LucideIcons.contact,
              height: 46,
              onPressed: _openContactsPicker,
            ),

            const SizedBox(height: 24),
            SoftKitButton(
              label: widget.outing != null ? 'Update trip' : 'Start trip',
              icon:
                  widget.outing != null
                      ? LucideIcons.check
                      : LucideIcons.rocket,
              height: 52,
              onPressed: _submit,
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _submit() async {
    final title = _titleCtrl.text.trim();
    if (title.isEmpty) {
      setState(() => _hasTitleError = true);
      return;
    }

    if (widget.outing != null) {
      final updated = widget.outing!.copyWith(
        title: _titleCtrl.text,
        category: _selectedCategory,
        location: _locationCtrl.text,
        startDate: _startDate,
        endDate: _endDate,
        members: _tempMembers,
        purpose: _selectedPurpose,
        budget: double.tryParse(_budgetCtrl.text.trim()),
      );
      ref.read(outingProvider.notifier).updateOuting(updated);
      // Sync friends to local storage
      ref
          .read(manualFriendsProvider.notifier)
          .addFriends(_tempMembers.map((m) => m.name).toList());
      for (final m in _tempMembers) {
        if (m.name.toLowerCase() != 'you') {
          ref.read(recentFriendsProvider.notifier).recordUse(m.name);
        }
      }
    } else {
      // Expire + heal first so we don't block on invisible stale trips.
      final notifier = ref.read(outingProvider.notifier);
      notifier.expireEndedOutings(silent: true);
      final open = ref.read(openOutingProvider);
      if (open != null) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('End “${open.title}” before starting a new trip.'),
            backgroundColor: AppColors.expense,
          ),
        );
        return;
      }
      final outing = Outing(
        title: _titleCtrl.text,
        category: _selectedCategory,
        location: _locationCtrl.text.isEmpty ? null : _locationCtrl.text,
        startDate: _startDate,
        endDate: _endDate,
        members: _tempMembers,
        isActive: true,
        status: 'active',
        purpose: _selectedPurpose,
        budget: double.tryParse(_budgetCtrl.text.trim()),
        isAutoMode: true,
      );
      try {
        await notifier.createOuting(outing);
      } catch (e) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              e is StateError ? e.message : 'Could not create trip',
            ),
            backgroundColor: AppColors.expense,
          ),
        );
        return;
      }
      ref
          .read(manualFriendsProvider.notifier)
          .addFriends(_tempMembers.map((m) => m.name).toList());
      for (final m in _tempMembers) {
        if (m.name.toLowerCase() != 'you') {
          ref.read(recentFriendsProvider.notifier).recordUse(m.name);
        }
      }
    }
    if (!mounted) return;
    Navigator.pop(context);
  }

  Widget _sectionLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(
        text,
        style: SoftKit.text(
          context,
          11,
          FontWeight.w700,
          SoftKit.slate(context),
          letterSpacing: 1.1,
        ),
      ),
    );
  }
}

class _DatePickerTile extends StatelessWidget {
  final String label;
  final DateTime date;
  final bool isDark;
  final VoidCallback onTap;

  const _DatePickerTile({
    required this.label,
    required this.date,
    required this.isDark,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: SoftKit.field(context),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: SoftKit.fieldBorder(context)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: SoftKit.text(
                context,
                11,
                FontWeight.w600,
                SoftKit.slate(context),
                letterSpacing: 0.8,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(
                  LucideIcons.calendar,
                  size: 16,
                  color: SoftKit.slate(context),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    DateFormat('dd MMM yyyy').format(date),
                    style: SoftKit.text(
                      context,
                      13.5,
                      FontWeight.w600,
                      SoftKit.ink(context),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
