import 'package:flutter/material.dart';
import '../../../../core/theme/spentx_tokens.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/theme/soft_palette.dart';
import '../../data/outing_provider.dart';
import '../../../../core/providers/transaction_provider.dart';

/// Trip ledger: total / your share / pending & returns / per-friend + history.
class OutingStatementSection extends ConsumerWidget {
  final Outing outing;
  final bool isDark;

  const OutingStatementSection({
    super.key,
    required this.outing,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final txs =
        ref
            .watch(transactionProvider)
            .where((t) => t.outingId == outing.id)
            .toList()
          ..sort((a, b) => b.date.compareTo(a.date));

    final totalTrip = outing.expenses.fold(0.0, (s, e) => s + e.amount);
    final youSpentOnSplits = outing.yourSplitShareTotal;
    final pendingReturn = outing.pendingFromFriends;
    final returned = outing.totalReturnedFromFriends;
    final youOwe = outing.youOweToFriendsNet;
    final outstanding = outing.userNetCost;

    final mySplitSpent = outing.mySplitContributed;
    final friendSplitSpent = outing.friendsSplitContributed();

    double youPaidViaUpi = txs
        .where((t) => t.isExpense && !t.isTransfer)
        .fold(0.0, (s, t) => s + t.amount);
    double youReceived = txs
        .where((t) => !t.isExpense && !t.isTransfer)
        .fold(0.0, (s, t) => s + t.amount);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: isDark ? SoftPalette.darkCard : SoftPalette.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color:
                  isDark
                      ? SoftPalette.darkBorder.withValues(alpha: 0.3)
                      : SoftPalette.border,
            ),
          ),
          child: Column(
            children: [
              _StatRow(
                label: 'Total trip spend',
                value: '₹${totalTrip.toInt()}',
                isDark: isDark,
                bold: true,
              ),
              const SizedBox(height: 10),
              _StatRow(
                label: 'Your share (splits)',
                value: '₹${youSpentOnSplits.toInt()}',
                isDark: isDark,
                color: SoftPalette.emerald,
              ),
              if (outing.members.any((m) => m.name != 'You')) ...[
                const SizedBox(height: 8),
                _StatRow(
                  label: 'Pending return (friends owe you)',
                  value: '₹${pendingReturn.toInt()}',
                  isDark: isDark,
                  color: SoftPalette.mint,
                ),
                const SizedBox(height: 8),
                _StatRow(
                  label: 'Returned / received on splits',
                  value: '₹${returned.toInt()}',
                  isDark: isDark,
                  color: SoftPalette.emerald,
                ),
                if (youOwe > 0.01) ...[
                  const SizedBox(height: 8),
                  _StatRow(
                    label: 'You still owe friends',
                    value: '₹${youOwe.toInt()}',
                    isDark: isDark,
                    color: SoftPalette.muted,
                  ),
                ],
                if (outstanding > 0.01) ...[
                  const SizedBox(height: 8),
                  _StatRow(
                    label: 'Your outstanding (out of pocket)',
                    value: '₹${outstanding.toInt()}',
                    isDark: isDark,
                    color: SoftPalette.negative,
                  ),
                ],
              ],
              if (youPaidViaUpi > 0) ...[
                const SizedBox(height: 8),
                _StatRow(
                  label: 'Your UPI/bank on trip',
                  value: '₹${youPaidViaUpi.toInt()}',
                  isDark: isDark,
                ),
              ],
              if (youReceived > 0) ...[
                const SizedBox(height: 8),
                _StatRow(
                  label: 'UPI/bank received on trip',
                  value: '₹${youReceived.toInt()}',
                  isDark: isDark,
                  color: SoftPalette.emerald,
                ),
              ],
              if (mySplitSpent > 0 || friendSplitSpent.isNotEmpty) ...[
                const SizedBox(height: 14),
                Divider(
                  height: 1,
                  color: isDark ? SoftPalette.darkDivider : SoftPalette.divider,
                ),
                const SizedBox(height: 10),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'SPLIT BILLS PAID',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      letterSpacing: 1.1,
                      color: context.tokens.textSecondary,
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                if (mySplitSpent > 0)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: _StatRow(
                      label: 'You spent (split)',
                      value: '₹${mySplitSpent.toInt()}',
                      isDark: isDark,
                      color: SoftPalette.emerald,
                    ),
                  ),
                ...friendSplitSpent.entries.map(
                  (e) => Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: _StatRow(
                      label: '${e.key} spent (split)',
                      value: '₹${e.value.toInt()}',
                      isDark: isDark,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
        const SizedBox(height: 16),
        Text(
          'STATEMENT HISTORY',
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w500,
            letterSpacing: 1.2,
            color: context.tokens.textSecondary,
          ),
        ),
        const SizedBox(height: 10),
        if (txs.isEmpty)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: isDark ? SoftPalette.darkCard : SoftPalette.surface,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Text(
              'No linked bank/UPI transactions yet',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 12,
                color: context.tokens.textSecondary,
              ),
            ),
          )
        else
          ...txs.map(
            (t) => _StatementTile(
              transaction: t,
              isDark: isDark,
              onTap: () => context.push('/transaction/${t.id}'),
            ),
          ),
      ],
    );
  }
}

class _StatRow extends StatelessWidget {
  final String label;
  final String value;
  final bool isDark;
  final Color? color;
  final bool bold;

  const _StatRow({
    required this.label,
    required this.value,
    required this.isDark,
    this.color,
    this.bold = false,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Text(
            label,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(fontSize: 13, color: context.tokens.textSecondary),
          ),
        ),
        Text(
          value,
          style: TextStyle(
            fontSize: bold ? 16 : 14,
            fontWeight: FontWeight.w500,
            color: color ?? (context.tokens.textPrimary),
          ),
        ),
      ],
    );
  }
}

class _StatementTile extends StatelessWidget {
  final Transaction transaction;
  final bool isDark;
  final VoidCallback onTap;

  const _StatementTile({
    required this.transaction,
    required this.isDark,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isOut = transaction.isExpense;
    final color = isOut ? SoftPalette.negative : SoftPalette.emerald;
    final icon = isOut ? LucideIcons.arrowUpRight : LucideIcons.arrowDownLeft;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: isDark ? SoftPalette.darkCard : SoftPalette.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color:
                isDark
                    ? SoftPalette.darkBorder.withValues(alpha: 0.25)
                    : SoftPalette.border,
          ),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.12),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, size: 14, color: color),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    transaction.merchant,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontWeight: FontWeight.w500,
                      fontSize: 13,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '${DateFormat('MMM dd, hh:mm a').format(transaction.date)} · ${transaction.paymentType}',
                    style: const TextStyle(
                      fontSize: 11,
                      color: SoftPalette.muted,
                    ),
                  ),
                ],
              ),
            ),
            Text(
              // Direction is already carried by `color` (and the row label).
              '₹${transaction.amount.toInt()}',
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 14,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
