import 'package:flutter/material.dart';
import '../../../../core/theme/soft_palette.dart';
import '../../../../core/theme/spentx_tokens.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../../../core/theme/app_colors.dart';
import '../../data/outing_provider.dart';
import '../../../../core/providers/transaction_provider.dart';
import '../../../sms/core/sms_pending_service.dart';

class DetectionPromptSheet extends ConsumerWidget {
  const DetectionPromptSheet({super.key});

  static void show(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => const DetectionPromptSheet(),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final activeOuting = ref.watch(activeOutingProvider);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final pending = SmsPendingService.listAwaitingVerification().firstOrNull;
    final title = (pending?.savedTitle ?? pending?.receiver ?? '').trim();
    final category = (pending?.savedCategory ?? '').trim();
    final amount = pending?.amount ?? 0;

    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: context.tokens.card,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        border: Border.all(
          color: context.tokens.border,
          width: 0.8,
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: isDark ? Colors.white24 : Colors.black12,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.primary.withValues(alpha: 0.14),
              shape: BoxShape.circle,
            ),
            child: const Icon(LucideIcons.scanLine, color: AppColors.primary, size: 32),
          ),
          const SizedBox(height: 16),
          Text(
            pending == null ? 'No new SMS expense' : 'New Expense Detected!',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w700,
              color: context.tokens.textPrimary,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            pending == null
                ? 'Detected messages show up here when a bank SMS arrives.'
                : 'We found a transaction from your messages',
            style: TextStyle(
              fontSize: 13,
              color: context.tokens.textSecondary,
            ),
          ),
          const SizedBox(height: 28),
          if (pending != null)
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: context.tokens.field,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppColors.primary.withValues(alpha: 0.2)),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.food.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Icon(LucideIcons.utensils, color: AppColors.primary, size: 20),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title.isEmpty ? 'Unknown' : title,
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 16,
                          color: context.tokens.textPrimary,
                        ),
                      ),
                      Text(
                        category.isEmpty ? 'Uncategorized' : category,
                        style: TextStyle(
                          fontSize: 12,
                          color: context.tokens.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
                Text(
                  '₹${amount.toStringAsFixed(0)}',
                  style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 20,
                    color: AppColors.expense,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 28),
          if (pending != null && activeOuting != null) ...[
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: SoftColors.control,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  elevation: 0,
                ),
                onPressed: () {
                  final expense = OutingExpense(
                    title: title.isEmpty ? 'Expense' : title,
                    amount: amount,
                    category: category.isEmpty ? 'Other' : category,
                    date: pending.date,
                  );
                  SmsPendingService.remove(pending.id);
                  ref.read(outingProvider.notifier).addExpenseToActive(expense);
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Added to "${activeOuting.title}"'),
                      backgroundColor: AppColors.income,
                    ),
                  );
                },
                child: Text(
                  'Add to "${activeOuting.title}"',
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
                ),
              ),
            ),
            const SizedBox(height: 12),
          ],
          if (pending != null)
          SizedBox(
            width: double.infinity,
            height: 50,
            child: OutlinedButton(
              style: OutlinedButton.styleFrom(
                side: BorderSide(
                  color: context.tokens.border,
                ),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
              onPressed: () {
                ref.read(transactionProvider.notifier).addTransaction(
                  Transaction(
                    merchant: title.isEmpty ? 'Unknown' : title,
                    category: category.isEmpty ? 'Other' : category,
                    account: pending.bank.isEmpty ? 'Personal' : pending.bank,
                    time: 'SMS',
                    amount: amount,
                    isExpense: pending.isExpense,
                    isTransfer: pending.isTransfer,
                    date: pending.date,
                    isAutoDetected: true,
                    note: pending.rawMessage,
                    upiId: pending.upiId,
                    referenceId: pending.referenceId,
                    accountLast4: pending.accountLast4,
                    bankName: pending.bank,
                  ),
                );
                SmsPendingService.remove(pending.id);
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Added as Normal Transaction')),
                );
              },
              child: Text(
                'Add as Normal Expense',
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                  color: context.tokens.textPrimary,
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }
}
