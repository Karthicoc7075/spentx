import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../core/theme/soft_palette.dart';
import '../../../../core/theme/spentx_tokens.dart';
import '../../../../core/widgets/reference_ui.dart';

/// Soft Soft surfaces for the outing detail page. Dark mode keeps SoftPalette.
class OutingDetailTone {
  OutingDetailTone(this.context);

  final BuildContext context;

  bool get dark => Theme.of(context).brightness == Brightness.dark;

  Color get canvas => dark ? SoftPalette.darkBg : const Color(0xFFF8FAFC);
  Color get card => dark ? SoftPalette.darkCard : const Color(0xFFFFFFFF);
  Color get border => dark ? SoftPalette.darkBorder : const Color(0xFFF1F5F9);
  Color get ink => dark ? SoftPalette.darkInk : const Color(0xFF0F172A);
  Color get slate => dark ? SoftPalette.darkMuted : const Color(0xFF64748B);
  Color get muted => dark ? SoftPalette.darkFaint : const Color(0xFF94A3B8);
  Color get emerald => dark ? SoftPalette.darkEmerald : const Color(0xFF10B981);
  Color get emeraldDeep =>
      dark ? SoftPalette.darkEmerald : const Color(0xFF059669);
  Color get mint =>
      dark ? SoftPalette.darkEmeraldSoft : const Color(0xFFECFDF5);
  Color get orange => const Color(0xFFEA580C);
  Color get orangeSoft =>
      dark ? const Color(0xFF3F2214) : const Color(0xFFFFF7ED);
  Color get orangeBorder =>
      dark ? const Color(0xFF7C2D12) : const Color(0xFFFED7AA);

  List<BoxShadow> get shadow =>
      dark
          ? const []
          : const [
            BoxShadow(
              color: Color(0x0A0F172A),
              blurRadius: 16,
              spreadRadius: -2,
              offset: Offset(0, 4),
            ),
          ];

  TextStyle text(
    double size,
    FontWeight weight,
    Color color, {
    double? letterSpacing,
  }) {
    return GoogleFonts.plusJakartaSans(
      fontSize: size,
      fontWeight: weight,
      color: color,
      letterSpacing: letterSpacing,
    );
  }

  BoxDecoration cardBox({Color? fill, Color? borderColor, double radius = 24}) {
    return BoxDecoration(
      color: fill ?? card,
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: borderColor ?? border),
      boxShadow: shadow,
    );
  }
}

class OutingDetailCard extends StatelessWidget {
  const OutingDetailCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.fill,
    this.borderColor,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color? fill;
  final Color? borderColor;

  @override
  Widget build(BuildContext context) {
    final tone = OutingDetailTone(context);
    return Container(
      width: double.infinity,
      padding: padding,
      decoration: tone.cardBox(fill: fill, borderColor: borderColor),
      child: child,
    );
  }
}

/// Soft outing list card surface.
class SoftOutingCard extends StatelessWidget {
  const SoftOutingCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.onTap,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final card = SxSoftCard(padding: padding, child: child);
    if (onTap == null) return card;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: const BorderRadius.all(Radius.circular(18)),
        child: card,
      ),
    );
  }
}

/// Soft light hero for outing detail (no dark green invent).
class SoftOutingHero extends StatelessWidget {
  const SoftOutingHero({
    super.key,
    required this.label,
    required this.amountText,
    this.badge = 'Calculated',
  });

  final String label;
  final String amountText;
  final String badge;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    return SoftOutingCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  label,
                  style: TextStyle(
                    color: SoftPalette.muted,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 5,
                ),
                decoration: BoxDecoration(
                  color: SoftPalette.emeraldSoft,
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(
                    color: SoftPalette.mint.withValues(alpha: 0.35),
                  ),
                ),
                child: Text(
                  badge,
                  style: const TextStyle(
                    color: SoftPalette.emerald,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            amountText,
            style: TextStyle(
              color: SoftPalette.ink,
              fontSize: 32,
              fontWeight: FontWeight.w800,
              letterSpacing: -0.6,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'INR',
            style: TextStyle(
              color: t.textSecondary,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

/// Soft emerald progress for outing budget.
class SoftOutingProgress extends StatelessWidget {
  const SoftOutingProgress({super.key, required this.value, this.over = false});

  final double value;
  final bool over;

  @override
  Widget build(BuildContext context) {
    final clamped = value.isNaN ? 0.0 : value.clamp(0.0, 1.0);
    return ClipRRect(
      borderRadius: BorderRadius.circular(999),
      child: LinearProgressIndicator(
        value: clamped,
        minHeight: 8,
        backgroundColor: SoftPalette.surfaceVariant,
        valueColor: AlwaysStoppedAnimation(
          over ? SoftPalette.negative : SoftPalette.emerald,
        ),
      ),
    );
  }
}
