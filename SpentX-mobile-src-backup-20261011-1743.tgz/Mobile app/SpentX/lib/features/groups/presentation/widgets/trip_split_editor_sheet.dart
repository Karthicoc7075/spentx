import 'package:flutter/material.dart';
import '../../../../core/theme/soft_palette.dart';
import '../../../../core/theme/spentx_tokens.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../../../core/theme/app_colors.dart';
import '../../data/outing_provider.dart';
import '../../../../core/services/outing_transaction_sync.dart';
import '../../../../core/providers/transaction_provider.dart' as model;
import '../../../../core/utils/transaction_display_utils.dart';

/// Edit which friends share a trip-linked transaction.
class TripSplitEditorSheet extends ConsumerStatefulWidget {
  final model.Transaction transaction;

  const TripSplitEditorSheet({super.key, required this.transaction});

  static Future<void> show(BuildContext context, model.Transaction tx) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => TripSplitEditorSheet(transaction: tx),
    );
  }

  @override
  ConsumerState<TripSplitEditorSheet> createState() => _TripSplitEditorSheetState();
}

class _TripSplitEditorSheetState extends ConsumerState<TripSplitEditorSheet> {
  SplitType _splitType = SplitType.solo;
  List<String> _memberIds = ['you'];
  bool _initialized = false;
  final Map<String, TextEditingController> _customSplitControllers = {};

  TextEditingController _customSplitController(String memberId) {
    return _customSplitControllers.putIfAbsent(
      memberId,
      () => TextEditingController(),
    );
  }

  @override
  void dispose() {
    for (final c in _customSplitControllers.values) {
      c.dispose();
    }
    super.dispose();
  }

  void _loadInitial() {
    final outingId = widget.transaction.outingId;
    if (outingId == null) return;

    final expense = ref
        .read(outingProvider.notifier)
        .expenseForTransaction(outingId, widget.transaction.id);
    if (expense != null) {
      _splitType = expense.splitType;
      _memberIds = List.from(expense.memberIds);
      expense.customSplitAmounts?.forEach((memberId, value) {
        _customSplitController(memberId).text = value.toStringAsFixed(0);
      });
      return;
    }

    final outing = ref.read(outingProvider).where((o) => o.id == outingId).firstOrNull;
    if (outing != null) {
      final d = OutingTransactionSync.defaultSplit(outing);
      _splitType = d.splitType;
      _memberIds = List.from(d.memberIds);
    }
  }

  bool get _customSplitValid {
    var sum = 0.0;
    for (final mId in _memberIds) {
      sum += double.tryParse(_customSplitController(mId).text) ?? 0;
    }
    return (sum - widget.transaction.amount).abs() < 0.01;
  }

  void _save() {
    final outingId = widget.transaction.outingId;
    if (outingId == null) return;
    if (_splitType == SplitType.custom && !_customSplitValid) return;
    final tx = widget.transaction;
    final memberIds = _splitType == SplitType.solo ? ['you'] : _memberIds;
    final customSplitAmounts = _splitType == SplitType.custom
        ? {
            for (final mId in memberIds)
              mId: double.tryParse(_customSplitController(mId).text) ?? 0,
          }
        : null;

    ref.read(outingProvider.notifier).syncTransactionExpense(
      outingId: outingId,
      transactionId: tx.id,
      title: TransactionDisplayUtils.merchantTitle(tx),
      amount: tx.amount,
      category: tx.category,
      date: tx.date,
      paymentMode: tx.paymentType,
      accountId: tx.account,
      purpose: tx.purpose ?? 'Personal',
      splitType: _splitType,
      memberIds: memberIds,
      customSplitAmounts: customSplitAmounts,
    );

    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Split updated'), backgroundColor: AppColors.income),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!_initialized) {
      _initialized = true;
      _loadInitial();
    }

    final outingId = widget.transaction.outingId;
    final outing = ref.watch(outingProvider).where((o) => o.id == outingId).firstOrNull;

    if (outing == null) {
      return const SizedBox.shrink();
    }

    final hasFriends = outing.members.any((m) => m.name.toLowerCase() != 'you');

    return Container(
      width: double.infinity,
      constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(context).height * 0.9),
      decoration: BoxDecoration(
        color: context.tokens.card,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.only(
          left: 24,
          right: 24,
          top: 20,
          bottom: MediaQuery.of(context).viewInsets.bottom + 24,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: context.tokens.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          const SizedBox(height: 20),
          Text(
            'SPLIT WITH FRIENDS',
            style: TextStyle(fontSize: 11, fontWeight: FontWeight.w500, color: context.tokens.textSecondary, letterSpacing: 1.2),
          ),
          const SizedBox(height: 8),
          Text(
            widget.transaction.merchant,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
          ),
          Text(
            '₹${widget.transaction.amount.toInt()} on ${outing.title}',
            style: TextStyle(fontSize: 13, color: context.tokens.textSecondary),
          ),
          const SizedBox(height: 24),
          if (!hasFriends)
            Text(
              'Add friends to this trip to split expenses.',
              style: TextStyle(color: context.tokens.textSecondary),
            )
          else ...[
            Row(
              children: [
                Expanded(
                  child: _SplitChip(
                    label: 'Solo',
                    icon: LucideIcons.user,
                    isSelected: _splitType == SplitType.solo,
                    onTap: () => setState(() {
                      _splitType = SplitType.solo;
                      _memberIds = ['you'];
                    }),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _SplitChip(
                    label: 'Split equally',
                    icon: LucideIcons.users,
                    isSelected: _splitType == SplitType.equally,
                    onTap: () => setState(() {
                      _splitType = SplitType.equally;
                      if (_memberIds.length <= 1) {
                        _memberIds = [
                          for (final m in outing.members)
                            m.name.toLowerCase() == 'you' ? 'you' : m.id,
                        ];
                      }
                    }),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _SplitChip(
                    label: 'Custom',
                    icon: LucideIcons.calculator,
                    isSelected: _splitType == SplitType.custom,
                    onTap: () => setState(() {
                      _splitType = SplitType.custom;
                      _memberIds = [
                        for (final m in outing.members)
                          m.name.toLowerCase() == 'you' ? 'you' : m.id,
                      ];
                    }),
                  ),
                ),
              ],
            ),
            if (_splitType == SplitType.custom) ...[
              const SizedBox(height: 20),
              Text(
                'HOW MUCH DOES EACH PERSON OWE?',
                style: TextStyle(fontSize: 11, fontWeight: FontWeight.w500, color: context.tokens.textSecondary, letterSpacing: 1),
              ),
              const SizedBox(height: 12),
              ...outing.members.map((m) {
                final mId = m.name.toLowerCase() == 'you' ? 'you' : m.id;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    children: [
                      Expanded(child: Text(m.name)),
                      SizedBox(
                        width: 100,
                        child: TextFormField(
                          controller: _customSplitController(mId),
                          keyboardType: TextInputType.number,
                          textAlign: TextAlign.right,
                          onChanged: (_) => setState(() {}),
                          decoration: const InputDecoration(hintText: '0'),
                        ),
                      ),
                    ],
                  ),
                );
              }),
              Text(
                'Allocated ₹${_memberIds.fold<double>(0, (sum, mId) => sum + (double.tryParse(_customSplitController(mId).text) ?? 0)).toStringAsFixed(0)} / ₹${widget.transaction.amount.toStringAsFixed(0)}',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: _customSplitValid ? AppColors.income : AppColors.expense,
                ),
              ),
            ],
            if (_splitType == SplitType.equally) ...[
              const SizedBox(height: 20),
              Text(
                'WHO SHARES THIS EXPENSE?',
                style: TextStyle(fontSize: 11, fontWeight: FontWeight.w500, color: context.tokens.textSecondary, letterSpacing: 1),
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: outing.members.map((m) {
                  final mId = m.name.toLowerCase() == 'you' ? 'you' : m.id;
                  final isSelected = _memberIds.contains(mId);
                  return FilterChip(
                    label: Text(m.name),
                    selected: isSelected,
                    onSelected: (val) {
                      setState(() {
                        if (val) {
                          _memberIds.add(mId);
                        } else if (_memberIds.length > 1) {
                          _memberIds.remove(mId);
                        }
                      });
                    },
                  );
                }).toList(),
              ),
              const SizedBox(height: 8),
              Text(
                'Pick only the friends for this payment.',
                style: TextStyle(fontSize: 11, color: context.tokens.textSecondary),
              ),
            ],
          ],
          const SizedBox(height: 28),
          SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton(
              onPressed: (_splitType == SplitType.custom && !_customSplitValid)
                  ? null
                  : _save,
              style: ElevatedButton.styleFrom(
                backgroundColor: SoftColors.control,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
              child: const Text('Save Split', style: TextStyle(fontWeight: FontWeight.w500)),
            ),
          ),
        ],
        ),
      ),
    );
  }
}

class _SplitChip extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool isSelected;
  final VoidCallback onTap;

  const _SplitChip({
    required this.label,
    required this.icon,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: isSelected ? AppColors.primary : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? AppColors.primary : context.tokens.border,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 16, color: isSelected ? AppColors.onAccent(AppColors.primary) : context.tokens.textSecondary),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 13,
                color: isSelected ? AppColors.onAccent(AppColors.primary) : context.tokens.textSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}