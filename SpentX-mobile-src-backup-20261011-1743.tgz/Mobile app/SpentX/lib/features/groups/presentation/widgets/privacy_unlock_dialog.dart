import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:local_auth/local_auth.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/soft_palette.dart';
import '../../../../core/services/pin_service.dart';

/// PIN or fingerprint confirmation before disabling privacy features
/// (outing privacy or private mode). Reusable for secure toggles.
class PrivacyUnlockDialog {
  static final LocalAuthentication _localAuth = LocalAuthentication();

  /// Confirm disable for Outing Privacy (kept for backward compat).
  static Future<bool> confirmDisable(
    BuildContext context,
    WidgetRef ref,
  ) async {
    return confirm(
      context: context,
      title: 'Enter PIN to turn off',
      reason: 'Confirm with fingerprint/face to turn off outing privacy',
    );
  }

  /// Confirm disable for Private Mode (requires PIN or biometric).
  static Future<bool> confirmDisablePrivateMode(
    BuildContext context,
    WidgetRef ref,
  ) async {
    return confirm(
      context: context,
      title: 'Enter PIN to turn off',
      reason: 'Confirm with fingerprint/face to turn off private mode',
    );
  }

  /// Generic secure confirmation using PIN (with bio fallback) or direct biometrics.
  static Future<bool> confirm({
    required BuildContext context,
    required String title,
    required String reason,
  }) async {
    if (PinService.hasPin) {
      return _pinDialog(context, title: title, reason: reason);
    }
    return _fingerprintDialog(context, reason: reason);
  }

  static Future<bool> _pinDialog(
    BuildContext context, {
    required String title,
    required String reason,
  }) async {
    final ctrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder:
          (ctx) => AlertDialog(
            backgroundColor: SoftPalette.card,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24),
            ),
            title: Text(
              title,
              style: TextStyle(
                color: SoftPalette.ink,
                fontWeight: FontWeight.w500,
              ),
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: ctrl,
                  obscureText: true,
                  keyboardType: TextInputType.number,
                  maxLength: 4,
                  textAlign: TextAlign.center,
                  autofocus: true,
                  style: TextStyle(
                    color: SoftPalette.ink,
                    fontSize: 22,
                    letterSpacing: 12,
                  ),
                  decoration: InputDecoration(
                    counterText: '',
                    hintText: '••••',
                    hintStyle: TextStyle(color: SoftPalette.faint),
                    border: InputBorder.none,
                  ),
                  onSubmitted: (v) {
                    if (PinService.isLockedOut) {
                      final secs = PinService.lockoutRemaining.inSeconds;
                      ScaffoldMessenger.of(ctx).showSnackBar(
                        SnackBar(
                          content: Text('Too many attempts. Try again in ${secs}s'),
                          backgroundColor: AppColors.expense,
                        ),
                      );
                      ctrl.clear();
                      return;
                    }
                    if (PinService.verifyPin(v)) {
                      Navigator.pop(ctx, true);
                    } else {
                      final locked = PinService.isLockedOut;
                      ScaffoldMessenger.of(ctx).showSnackBar(
                        SnackBar(
                          content: Text(
                            locked
                                ? 'Too many attempts. Try again in ${PinService.lockoutRemaining.inSeconds}s'
                                : 'Incorrect PIN',
                          ),
                          backgroundColor: AppColors.expense,
                        ),
                      );
                      ctrl.clear();
                    }
                  },
                ),
                const SizedBox(height: 12),
                TextButton.icon(
                  onPressed: () async {
                    try {
                      final auth = await _localAuth.authenticate(
                        localizedReason: reason,
                        options: const AuthenticationOptions(
                          biometricOnly: false,
                          stickyAuth: true,
                        ),
                      );
                      if (!ctx.mounted) return;
                      if (auth) {
                        Navigator.pop(ctx, true);
                      } else {
                        ScaffoldMessenger.of(ctx).showSnackBar(
                          const SnackBar(
                            content: Text('Biometric not recognized'),
                            backgroundColor: AppColors.expense,
                          ),
                        );
                      }
                    } catch (e) {
                      if (!ctx.mounted) return;
                      ScaffoldMessenger.of(ctx).showSnackBar(
                        const SnackBar(
                          content: Text('Biometric unavailable — use PIN'),
                          backgroundColor: AppColors.expense,
                        ),
                      );
                    }
                  },
                  icon: Icon(LucideIcons.fingerprint, size: 18),
                  label: const Text(
                    'Use fingerprint / face',
                    style: TextStyle(fontSize: 12),
                  ),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: Text(
                  'Cancel',
                  style: TextStyle(color: SoftPalette.faint),
                ),
              ),
              TextButton(
                onPressed: () {
                  if (PinService.verifyPin(ctrl.text)) {
                    Navigator.pop(ctx, true);
                  } else {
                    ScaffoldMessenger.of(ctx).showSnackBar(
                      const SnackBar(
                        content: Text('Incorrect PIN'),
                        backgroundColor: AppColors.expense,
                      ),
                    );
                    ctrl.clear();
                  }
                },
                child: const Text(
                  'Unlock',
                  style: TextStyle(
                    color: SoftPalette.emerald,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
    );
    ctrl.dispose();
    return ok == true;
  }

  static Future<bool> _fingerprintDialog(
    BuildContext context, {
    required String reason,
  }) async {
    try {
      final authenticated = await _localAuth.authenticate(
        localizedReason: reason,
        options: const AuthenticationOptions(
          biometricOnly: false,
          stickyAuth: true,
          useErrorDialogs: true,
        ),
      );
      if (!authenticated && context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Fingerprint verification failed'),
            backgroundColor: AppColors.expense,
          ),
        );
      }
      return authenticated;
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Fingerprint error: $e'),
            backgroundColor: AppColors.expense,
          ),
        );
      }
      return false;
    }
  }
}
