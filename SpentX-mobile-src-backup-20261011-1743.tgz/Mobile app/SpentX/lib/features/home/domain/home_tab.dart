/// Main shell tab indices (shared Soft bottom nav).
///
/// Order matches [SoftBottomNav] / [MainWrapper]: Home, Activity, Analytics, More.
enum HomeTab {
  home,
  activity,
  analytics,
  more;

  static HomeTab fromIndex(int i) {
    if (i < 0 || i >= HomeTab.values.length) return HomeTab.home;
    return HomeTab.values[i];
  }
}
