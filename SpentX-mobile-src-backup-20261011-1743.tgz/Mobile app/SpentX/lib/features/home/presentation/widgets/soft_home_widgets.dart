import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/theme/soft_palette.dart';
import '../../../../core/theme/spentx_tokens.dart';

/// Soft Neo-Fintech card — white, radius 20–24, soft shadow, no hard border.
class SoftHomeCard extends StatelessWidget {
  const SoftHomeCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.onTap,
    this.borderColor,
    this.radius = 24,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  final Color? borderColor;
  final double radius;

  static const softShadow = [
    BoxShadow(color: Color(0x0F050D1A), blurRadius: 24, offset: Offset(0, 8)),
  ];

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final content = Container(
      padding: padding,
      decoration: BoxDecoration(
        color: t.card,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(
          color:
              borderColor ??
              (isDark
                  ? SoftPalette.darkBorder.withValues(alpha: 0.55)
                  : SoftPalette.border.withValues(alpha: 0.55)),
          width: isDark ? 1 : 0.5,
        ),
        boxShadow: isDark ? null : softShadow,
      ),
      child: child,
    );
    if (onTap == null) return content;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(radius),
        child: content,
      ),
    );
  }
}

/// Soft section title row (title + optional emerald action).
class SoftHomeSectionHeader extends StatelessWidget {
  const SoftHomeSectionHeader({
    super.key,
    required this.title,
    this.actionLabel,
    this.onAction,
  });

  final String title;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final actionColor = isDark ? SoftPalette.darkEmerald : SoftPalette.mint;
    return Row(
      children: [
        Expanded(
          child: Text(
            title,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              letterSpacing: -0.3,
              color: t.textPrimary,
            ),
          ),
        ),
        if (actionLabel != null && onAction != null)
          GestureDetector(
            onTap: onAction,
            behavior: HitTestBehavior.opaque,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 2),
              child: Text(
                actionLabel!,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: actionColor,
                ),
              ),
            ),
          ),
      ],
    );
  }
}

/// Soft Figma greeting: "Hello {name}" + no time-of-day swap.
class SoftHomeGreeting extends StatelessWidget {
  const SoftHomeGreeting({super.key, required this.name});

  final String name;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    return Text(
      'Hello $name 👋',
      style: TextStyle(
        fontSize: 22,
        fontWeight: FontWeight.w700,
        letterSpacing: -0.4,
        color: t.textPrimary,
        height: 1.15,
      ),
    );
  }
}

/// Shared top chrome for the Home and Analytics surfaces.
///
/// Keeping the greeting/title row in one widget prevents the two primary
/// screens from drifting apart in spacing, icon sizing, avatar treatment, or
/// notification affordances.
class SoftAppHeader extends StatelessWidget {
  const SoftAppHeader({
    super.key,
    required this.title,
    required this.subtitle,
    required this.initials,
    this.hasUnread = false,
    this.onNotifications,
    this.onProfile,
  });

  final String title;
  final String subtitle;
  final String initials;
  final bool hasUnread;
  final VoidCallback? onNotifications;
  final VoidCallback? onProfile;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w700,
                  letterSpacing: -0.4,
                  color: t.textPrimary,
                  height: 1.15,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w500,
                  letterSpacing: -0.1,
                  color: SoftHomeTone.muted(context),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 12),
        Row(
          children: [
            Material(
              color: t.card,
              borderRadius: BorderRadius.circular(999),
              child: InkWell(
                onTap: onNotifications,
                borderRadius: BorderRadius.circular(999),
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: t.card,
                    boxShadow: isDark ? null : SoftHomeCard.softShadow,
                    border: Border.all(
                      color:
                          isDark
                              ? SoftPalette.darkBorder.withValues(alpha: 0.6)
                              : const Color(0xFFE2E8F0),
                      width: 1,
                    ),
                  ),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Icon(LucideIcons.bell, size: 17, color: t.textSecondary),
                      if (hasUnread)
                        Positioned(
                          top: 8,
                          right: 8,
                          child: Container(
                            width: 6,
                            height: 6,
                            decoration: const BoxDecoration(
                              color: Color(0xFFEF4444),
                              shape: BoxShape.circle,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: onProfile,
              child: Stack(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color:
                          isDark
                              ? SoftPalette.darkEmeraldSoft
                              : SoftPalette.emeraldSoft,
                      border: Border.all(
                        color:
                            isDark
                                ? SoftPalette.mint.withValues(alpha: 0.4)
                                : const Color(0xFFA7F3D0),
                        width: 1.2,
                      ),
                    ),
                    child: Center(
                      child: Text(
                        initials,
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color:
                              isDark
                                  ? const Color(0xFF6EE7B7)
                                  : SoftPalette.mintDark,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: Container(
                      width: 10,
                      height: 10,
                      decoration: BoxDecoration(
                        color: SoftPalette.mint,
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: isDark ? SoftPalette.darkBg : SoftPalette.card,
                          width: 1.5,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }
}

/// Soft emerald tone helpers for Home.
abstract final class SoftHomeTone {
  static Color card(BuildContext context) => context.tokens.card;
  static Color border(BuildContext context) => context.tokens.border;
  static Color muted(BuildContext context) => const Color(0xFF63738C);
  static Color ink(BuildContext context) => context.tokens.textPrimary;
  static Color emerald(BuildContext context) => SoftPalette.emerald;
  static Color emeraldSoft(BuildContext context) => SoftPalette.emeraldSoft;

  /// Soft Figma liquid card gradient ~ rich emerald green matching Image 1
  static const liquidTop = Color(0xFF064E3B);
  static const liquidMid = Color(0xFF04382A);
  static const liquidBottom = Color(0xFF02251B);

  static Color heroGradientTop(bool isDark) =>
      isDark ? const Color(0xFF032219) : liquidTop;
  static Color heroGradientMid(bool isDark) =>
      isDark ? const Color(0xFF083C2D) : liquidMid;
  static Color heroGradientBottom(bool isDark) =>
      isDark ? const Color(0xFF021710) : liquidBottom;
}

/// Soft Soft surfaces for the outing-privacy home. Dark mode keeps SoftPalette.
class HomePrivacyTone {
  HomePrivacyTone(this.context);

  final BuildContext context;

  bool get dark => Theme.of(context).brightness == Brightness.dark;

  Color get canvas => dark ? SoftPalette.darkBg : const Color(0xFFF8FAFC);
  Color get card => dark ? SoftPalette.darkCard : const Color(0xFFFFFFFF);
  Color get border => dark ? SoftPalette.darkBorder : const Color(0xFFF1F5F9);
  Color get ink => dark ? SoftPalette.darkInk : const Color(0xFF0F172A);
  Color get slate => dark ? SoftPalette.darkMuted : const Color(0xFF64748B);
  Color get muted => dark ? SoftPalette.darkFaint : const Color(0xFF94A3B8);
  Color get emerald => dark ? SoftPalette.darkEmerald : const Color(0xFF10B981);
  Color get emeraldDeep =>
      dark ? SoftPalette.darkEmerald : const Color(0xFF059669);
  Color get mint =>
      dark ? SoftPalette.darkEmeraldSoft : const Color(0xFFECFDF5);

  List<BoxShadow> get shadow =>
      dark
          ? const []
          : const [
            BoxShadow(
              color: Color(0x0A0F172A),
              blurRadius: 16,
              spreadRadius: -2,
              offset: Offset(0, 4),
            ),
          ];

  TextStyle text(
    double size,
    FontWeight weight,
    Color color, {
    double? letterSpacing,
  }) {
    return GoogleFonts.plusJakartaSans(
      fontSize: size,
      fontWeight: weight,
      color: color,
      letterSpacing: letterSpacing,
    );
  }

  BoxDecoration cardBox({Color? fill, Color? borderColor, double radius = 24}) {
    return BoxDecoration(
      color: fill ?? card,
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: borderColor ?? border),
      boxShadow: shadow,
    );
  }
}
