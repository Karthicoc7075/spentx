import 'package:flutter/material.dart';
import '../../../../core/theme/soft_palette.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../data/dashboard_kpi_provider.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/spentx_tokens.dart';

class KpiConfigSheet extends ConsumerStatefulWidget {
  const KpiConfigSheet({super.key});

  static Future<void> show(BuildContext context) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const KpiConfigSheet(),
    );
  }

  @override
  ConsumerState<KpiConfigSheet> createState() => _KpiConfigSheetState();
}

class _KpiConfigSheetState extends ConsumerState<KpiConfigSheet> {
  late List<DashboardKpiKey> _activeKeys;
  late Set<DashboardKpiKey> _activeSet;

  @override
  void initState() {
    super.initState();
    final config = ref.read(dashboardKpiProvider);
    _activeKeys = List.from(config.activeKeys);
    _activeSet = _activeKeys.toSet();
  }

  void _onReorder(int oldIndex, int newIndex) {
    setState(() {
      if (newIndex > oldIndex) newIndex -= 1;
      final item = _activeKeys.removeAt(oldIndex);
      _activeKeys.insert(newIndex, item);
      ref.read(dashboardKpiProvider.notifier).updateKeys(_activeKeys);
    });
  }

  void _toggleKey(DashboardKpiKey key, bool enable) {
    if (!enable && _activeKeys.length <= 1) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('At least one KPI card must remain visible.')),
      );
      return;
    }

    setState(() {
      if (enable) {
        if (!_activeSet.contains(key)) {
          _activeKeys.add(key);
          _activeSet.add(key);
        }
      } else {
        _activeKeys.remove(key);
        _activeSet.remove(key);
      }
      ref.read(dashboardKpiProvider.notifier).updateKeys(_activeKeys);
    });
  }

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    // Inactive keys that can be enabled
    final inactiveKeys = DashboardKpiKey.values
        .where((k) => !_activeSet.contains(k))
        .toList();

    return Container(
      decoration: BoxDecoration(
        color: t.card,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        border: Border(
          top: BorderSide(
            color: isDark ? Colors.white.withValues(alpha: 0.1) : Colors.black.withValues(alpha: 0.08),
          ),
        ),
      ),
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 12,
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.72,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 36,
                height: 4,
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(
                  color: isDark ? Colors.white24 : Colors.black12,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Customize Dashboard Cards',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Drag to reorder · Toggle to show or hide',
                      style: TextStyle(
                        fontSize: 12,
                        color: t.textSecondary,
                      ),
                    ),
                  ],
                ),
                TextButton(
                  onPressed: () {
                    ref.read(dashboardKpiProvider.notifier).resetToDefault();
                    setState(() {
                      _activeKeys = List.from(DashboardKpiConfig.defaultKeys);
                      _activeSet = _activeKeys.toSet();
                    });
                  },
                  child: const Text('Reset'),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Expanded(
              child: ListView(
                children: [
                  Text(
                    'ACTIVE CARDS (DRAG TO REORDER)',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 1.1,
                      color: t.textSecondary,
                    ),
                  ),
                  const SizedBox(height: 8),
                  ReorderableListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: _activeKeys.length,
                    onReorder: _onReorder,
                    itemBuilder: (context, index) {
                      final key = _activeKeys[index];
                      return Container(
                        key: ValueKey(key),
                        margin: const EdgeInsets.only(bottom: 8),
                        decoration: BoxDecoration(
                          color: t.field,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: isDark ? Colors.white.withValues(alpha: 0.05) : Colors.black.withValues(alpha: 0.05),
                          ),
                        ),
                        child: ListTile(
                          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
                          leading: Icon(key.icon, size: 20, color: AppColors.primary),
                          title: Text(
                            key.label,
                            style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Switch.adaptive(
                                value: true,
                                activeThumbColor: Colors.white,
                                activeTrackColor: SoftColors.control,
                                onChanged: (val) => _toggleKey(key, val),
                              ),
                              const SizedBox(width: 4),
                              ReorderableDragStartListener(
                                index: index,
                                child: Icon(
                                  LucideIcons.gripVertical,
                                  size: 18,
                                  color: t.textSecondary,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                  if (inactiveKeys.isNotEmpty) ...[
                    const SizedBox(height: 16),
                    Text(
                      'AVAILABLE CARDS',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 1.1,
                        color: t.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 8),
                    ...inactiveKeys.map((key) {
                      return Container(
                        key: ValueKey(key),
                        margin: const EdgeInsets.only(bottom: 8),
                        decoration: BoxDecoration(
                          color: t.field.withValues(alpha: 0.6),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: isDark ? Colors.white.withValues(alpha: 0.03) : Colors.black.withValues(alpha: 0.03),
                          ),
                        ),
                        child: ListTile(
                          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
                          leading: Icon(key.icon, size: 20, color: t.textSecondary),
                          title: Text(
                            key.label,
                            style: TextStyle(
                              fontWeight: FontWeight.w500,
                              fontSize: 14,
                              color: t.textSecondary,
                            ),
                          ),
                          trailing: Switch.adaptive(
                            value: false,
                            activeThumbColor: Colors.white,
                            activeTrackColor: SoftColors.control,
                            onChanged: (val) => _toggleKey(key, val),
                          ),
                        ),
                      );
                    }),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 48,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: SoftColors.control,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                onPressed: () => Navigator.pop(context),
                child: const Text('Done', style: TextStyle(fontWeight: FontWeight.bold)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
