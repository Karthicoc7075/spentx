import 'dart:math' as math;
import 'package:flutter/material.dart';

import '../../../../core/theme/spentx_tokens.dart';

// ─────────────────────────────────────────────────────────────
// 1. Sparkline Graph Painter
// ─────────────────────────────────────────────────────────────
class SparklinePainter extends CustomPainter {
  final List<double> points;
  final Color strokeColor;
  final Color fillStartColor;

  const SparklinePainter({
    required this.points,
    required this.strokeColor,
    required this.fillStartColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (points.length < 2) return;

    final double minVal = points.reduce(math.min);
    final double maxVal = points.reduce(math.max);
    final double range = (maxVal - minVal) == 0 ? 1.0 : (maxVal - minVal);

    final double stepX = size.width / (points.length - 1);
    final List<Offset> offsets = [];

    for (int i = 0; i < points.length; i++) {
      final double x = i * stepX;
      final double normalized = (points[i] - minVal) / range;
      final double y = size.height - (normalized * (size.height - 8)) - 4;
      offsets.add(Offset(x, y));
    }

    // Gradient fill under curve
    final Path fillPath = Path()..moveTo(offsets.first.dx, size.height);
    for (int i = 0; i < offsets.length; i++) {
      if (i == 0) {
        fillPath.lineTo(offsets[i].dx, offsets[i].dy);
      } else {
        final p0 = offsets[i - 1];
        final p1 = offsets[i];
        final cx = (p0.dx + p1.dx) / 2;
        fillPath.cubicTo(cx, p0.dy, cx, p1.dy, p1.dx, p1.dy);
      }
    }
    fillPath.lineTo(offsets.last.dx, size.height);
    fillPath.close();

    final fillPaint =
        Paint()
          ..shader = LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [fillStartColor, fillStartColor.withValues(alpha: 0.0)],
          ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawPath(fillPath, fillPaint);

    // Stroke line
    final Path strokePath = Path()..moveTo(offsets.first.dx, offsets.first.dy);
    for (int i = 1; i < offsets.length; i++) {
      final p0 = offsets[i - 1];
      final p1 = offsets[i];
      final cx = (p0.dx + p1.dx) / 2;
      strokePath.cubicTo(cx, p0.dy, cx, p1.dy, p1.dx, p1.dy);
    }

    final strokePaint =
        Paint()
          ..color = strokeColor
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.4
          ..strokeCap = StrokeCap.round
          ..strokeJoin = StrokeJoin.round;
    canvas.drawPath(strokePath, strokePaint);

    // Peak marker matching Image 1: solid white dot with glowing outer mint halo
    final Offset peak = offsets.last;
    final glowPaint =
        Paint()
          ..color = const Color(0xFF34D399).withValues(alpha: 0.45)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6);
    canvas.drawCircle(peak, 7.5, glowPaint);

    final outerRing =
        Paint()
          ..color = const Color(0xFF34D399)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.8;
    canvas.drawCircle(peak, 5.0, outerRing);

    final whiteCenter =
        Paint()
          ..color = Colors.white
          ..style = PaintingStyle.fill;
    canvas.drawCircle(peak, 3.2, whiteCenter);
  }

  @override
  bool shouldRepaint(covariant SparklinePainter old) =>
      old.points != points || old.strokeColor != strokeColor;
}

// ─────────────────────────────────────────────────────────────
// 2. Horseshoe Speedometer Gauge Painter
// ─────────────────────────────────────────────────────────────
class DonutGaugePainter extends CustomPainter {
  final double percentage; // 0.0 to 1.0
  final Color trackColor;
  final Color progressColor;

  const DonutGaugePainter({
    required this.percentage,
    required this.trackColor,
    required this.progressColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = (size.width - 10) / 2;

    const startAngle = math.pi * 0.75;
    const totalSweep = math.pi * 1.5;

    final trackPaint =
        Paint()
          ..color = trackColor
          ..style = PaintingStyle.stroke
          ..strokeWidth = 9.0
          ..strokeCap = StrokeCap.round;

    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      startAngle,
      totalSweep,
      false,
      trackPaint,
    );

    final clampedPct = percentage.clamp(0.0, 1.0);
    if (clampedPct > 0) {
      final progressPaint =
          Paint()
            ..color = progressColor
            ..style = PaintingStyle.stroke
            ..strokeWidth = 9.0
            ..strokeCap = StrokeCap.round;

      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle,
        totalSweep * clampedPct,
        false,
        progressPaint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant DonutGaugePainter old) =>
      old.percentage != percentage ||
      old.trackColor != trackColor ||
      old.progressColor != progressColor;
}

// ─────────────────────────────────────────────────────────────
// 3. Wavy Divider & Wave Line Painter
// ─────────────────────────────────────────────────────────────
class WavyDivider extends StatelessWidget {
  final String label;

  const WavyDivider({super.key, required this.label});

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final waveColor =
        Theme.of(context).brightness == Brightness.dark
            ? const Color(0xFF3F3F46)
            : const Color(0xFFD4D4D8);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Expanded(
            child: SizedBox(
              height: 10,
              child: CustomPaint(painter: WaveLinePainter(color: waveColor)),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Text(
              label,
              style: TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w600,
                color: t.textDisabled,
                letterSpacing: 0.1,
              ),
            ),
          ),
          Expanded(
            child: SizedBox(
              height: 10,
              child: CustomPaint(painter: WaveLinePainter(color: waveColor)),
            ),
          ),
        ],
      ),
    );
  }
}

class WaveLinePainter extends CustomPainter {
  final Color color;

  const WaveLinePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint =
        Paint()
          ..color = color
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.2
          ..strokeCap = StrokeCap.round;

    final path = Path();
    final midY = size.height / 2;
    const waveCount = 3.5;
    final waveLength = size.width / waveCount;
    final amplitude = size.height * 0.38;

    path.moveTo(0, midY);
    for (double x = 0; x < size.width; x += waveLength) {
      final x1 = x + waveLength * 0.25;
      final y1 = midY - amplitude;
      final x2 = x + waveLength * 0.75;
      final y2 = midY + amplitude;
      final x3 = math.min(x + waveLength, size.width);
      final y3 = midY;
      path.cubicTo(x1, y1, x2, y2, x3, y3);
    }

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant WaveLinePainter old) => old.color != color;
}

// ─────────────────────────────────────────────────────────────
// 4. Savings Plant Illustration & Painter
// ─────────────────────────────────────────────────────────────
class SavingsPlantIllustration extends StatelessWidget {
  const SavingsPlantIllustration({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      width: 44,
      height: 44,
      decoration: BoxDecoration(
        color:
            isDark ? const Color(0xFF1E293B) : const Color(0xFFF0FDF4),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color:
              isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
          width: 0.8,
        ),
      ),
      child: const CustomPaint(painter: PlantPotPainter()),
    );
  }
}

class PlantPotPainter extends CustomPainter {
  const PlantPotPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;

    // 1. Trapezoid White/Mint Planter Pot
    final potPath = Path();
    potPath.moveTo(cx - 9, cy + 2);
    potPath.lineTo(cx + 9, cy + 2);
    potPath.lineTo(cx + 6.5, cy + 14);
    potPath.lineTo(cx - 6.5, cy + 14);
    potPath.close();

    final potPaint =
        Paint()
          ..color = const Color(0xFFE2F4EE)
          ..style = PaintingStyle.fill;
    canvas.drawPath(potPath, potPaint);

    final potOutline =
        Paint()
          ..color = const Color(0xFF0D9488).withValues(alpha: 0.45)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.0;
    canvas.drawPath(potPath, potOutline);

    // Pot rim
    canvas.drawLine(
      Offset(cx - 9.5, cy + 2),
      Offset(cx + 9.5, cy + 2),
      Paint()
        ..color = const Color(0xFF0D9488)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.6
        ..strokeCap = StrokeCap.round,
    );

    // Decorative vertical dashes on the pot
    final dashPaint =
        Paint()
          ..color = const Color(0xFF14B8A6).withValues(alpha: 0.5)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.0;
    canvas.drawLine(Offset(cx - 2.5, cy + 5), Offset(cx - 2.0, cy + 11), dashPaint);
    canvas.drawLine(Offset(cx + 2.5, cy + 5), Offset(cx + 2.0, cy + 11), dashPaint);

    // 2. Green Stems
    final stemPaint =
        Paint()
          ..color = const Color(0xFF10B981)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.6
          ..strokeCap = StrokeCap.round;

    final stem1 =
        Path()
          ..moveTo(cx, cy + 2)
          ..quadraticBezierTo(cx - 4, cy - 4, cx - 8, cy - 8);
    canvas.drawPath(stem1, stemPaint);

    final stem2 =
        Path()
          ..moveTo(cx, cy + 2)
          ..quadraticBezierTo(cx + 3, cy - 5, cx + 5, cy - 10);
    canvas.drawPath(stem2, stemPaint);

    // 3. Green Leaves
    final leafPaint =
        Paint()
          ..color = const Color(0xFF34D399)
          ..style = PaintingStyle.fill;

    // Left leaf
    canvas.save();
    canvas.translate(cx - 8, cy - 8);
    canvas.rotate(-0.5);
    canvas.drawOval(
      Rect.fromCenter(center: Offset.zero, width: 7.5, height: 4.2),
      leafPaint,
    );
    canvas.restore();

    // Middle leaf
    canvas.save();
    canvas.translate(cx - 3, cy - 6);
    canvas.rotate(0.2);
    canvas.drawOval(
      Rect.fromCenter(center: Offset.zero, width: 6.5, height: 3.5),
      leafPaint,
    );
    canvas.restore();

    // 4. Golden Coin Blossom (Upper Right)
    final coinCenter = Offset(cx + 6, cy - 10);
    final coinPaint =
        Paint()
          ..color = const Color(0xFFFBBF24)
          ..style = PaintingStyle.fill;
    canvas.drawCircle(coinCenter, 5.0, coinPaint);

    final coinBorder =
        Paint()
          ..color = const Color(0xFFD97706)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.0;
    canvas.drawCircle(coinCenter, 5.0, coinBorder);

    // Inner rupee sign / coin dot
    canvas.drawCircle(
      coinCenter,
      2.0,
      Paint()
        ..color = const Color(0xFFB45309)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.8,
    );

    // 5. Sparkle dots (Golden / Mint)
    final sparklePaint =
        Paint()
          ..color = const Color(0xFFF59E0B)
          ..style = PaintingStyle.fill;
    canvas.drawCircle(Offset(cx + 12, cy - 14), 1.2, sparklePaint);
    canvas.drawCircle(Offset(cx - 9, cy - 13), 1.0, leafPaint);
  }

  @override
  bool shouldRepaint(covariant PlantPotPainter old) => false;
}
