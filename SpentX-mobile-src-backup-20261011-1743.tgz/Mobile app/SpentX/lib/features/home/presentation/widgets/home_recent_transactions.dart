import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/navigation/main_shell_navigation.dart';
import '../../../../core/providers/outing_provider.dart';
import '../../../../core/providers/transaction_provider.dart' as model;
import '../../../../core/theme/spentx_tokens.dart';
import '../../../../core/utils/transaction_display_utils.dart';
import '../../../../core/widgets/category_icon.dart';
import 'soft_home_widgets.dart';

class ShowcaseTx {
  final String title;
  final String category;
  final String subtitle;
  final String amountStr;
  final String bankTag;
  final bool isExpense;
  final bool isTransfer;
  final String? id;

  const ShowcaseTx({
    required this.title,
    required this.category,
    required this.subtitle,
    required this.amountStr,
    required this.bankTag,
    required this.isExpense,
    this.isTransfer = false,
    this.id,
  });
}

class HomeRecentTransactionsSection extends StatelessWidget {
  final List<model.Transaction> allTxs;
  final List<Outing> outings;
  final bool isPrivate;
  final String Function(int) formatIndian;
  final Map<String, String> categoryColors;

  const HomeRecentTransactionsSection({
    super.key,
    required this.allTxs,
    required this.outings,
    required this.isPrivate,
    required this.formatIndian,
    this.categoryColors = const {},
  });

  static List<model.Transaction>? _sortedSource;
  static List<model.Transaction>? _sorted;

  static List<model.Transaction> _visibleSorted(List<model.Transaction> all) {
    if (identical(_sortedSource, all) && _sorted != null) return _sorted!;
    final list =
        all.where((tx) => !tx.isPendingVerification).toList()
          ..sort((a, b) => b.date.compareTo(a.date));
    _sortedSource = all;
    _sorted = list;
    return list;
  }

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final txList = _visibleSorted(allTxs);

    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));

    final List<ShowcaseTx> displayItems = [];

    if (txList.isNotEmpty) {
      for (final tx in txList.take(10)) {
        final txDate = tx.date;
        final txDay = DateTime(txDate.year, txDate.month, txDate.day);
        String dayLabel;
        if (txDay == today) {
          dayLabel = 'Today';
        } else if (txDay == yesterday) {
          dayLabel = 'Yesterday';
        } else {
          dayLabel = DateFormat('d MMM').format(txDate);
        }

        final timeStr = _homeRecentTimeLabel(tx, txDate);
        final purposeStr = _homeRecentPurposeLabel(tx.purpose);
        final accountStr = _homeRecentAccountLabel(tx);
        final displayTitle = TransactionDisplayUtils.listHeadline(tx);
        final isTransfer =
            tx.isTransfer || tx.category.trim().toLowerCase() == 'transfer';

        final subtitle = '$dayLabel · $timeStr · $purposeStr';
        final amountPrefix = isTransfer ? '' : (tx.isExpense ? '-₹' : '+₹');
        final amountStr =
            isPrivate
                ? '••••'
                : '$amountPrefix${formatIndian(tx.amount.toInt())}';

        displayItems.add(
          ShowcaseTx(
            title: displayTitle,
            category: tx.category,
            subtitle: subtitle,
            amountStr: amountStr,
            bankTag: accountStr,
            isExpense: tx.isExpense,
            isTransfer: isTransfer,
            id: tx.id,
          ),
        );
      }
    }

    return SoftHomeCard(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 6),
      radius: 24,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header row inside card matching Image 1
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Recent Transactions',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: t.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    'Categorized cashflow',
                    style: TextStyle(
                      fontSize: 11.5,
                      fontWeight: FontWeight.w500,
                      color: t.textDisabled,
                    ),
                  ),
                ],
              ),
              GestureDetector(
                onTap: () => MainShellNavigation.openTab(context, 1),
                behavior: HitTestBehavior.opaque,
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 4,
                    vertical: 4,
                  ),
                  child: Row(
                    children: [
                      Text(
                        'View all',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color:
                              isDark
                                  ? const Color(0xFF34D399)
                                  : const Color(0xFF0D9488),
                        ),
                      ),
                      const SizedBox(width: 2),
                      Icon(
                        LucideIcons.arrowRight,
                        size: 13,
                        color:
                            isDark
                                ? const Color(0xFF34D399)
                                : const Color(0xFF0D9488),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          if (displayItems.isEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(4, 4, 4, 12),
              child: Text(
                'No transactions yet.',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  color: t.textDisabled,
                ),
              ),
            )
          else
            ...displayItems.map(
              (item) => _buildShowcaseTile(context, item, isDark),
            ),
        ],
      ),
    );
  }

  Widget _buildShowcaseTile(
    BuildContext context,
    ShowcaseTx item,
    bool isDark,
  ) {
    final t = context.tokens;
    final catData = CategoryIcon.resolve(item.category);
    final tone = CategoryToneLookup.resolve(
      storedHex: categoryColors[item.category.trim().toLowerCase()],
      isExpense: item.isExpense,
      isTransfer: item.isTransfer,
      isDark: isDark,
    );

    final Color iconBg = tone.bg;
    final Color iconFg = tone.fg;
    final Color amountColor =
        item.isExpense
            ? t.textPrimary
            : (isDark ? const Color(0xFF34D399) : const Color(0xFF10B981));

    final IconData icon = _resolveCategoryIcon(item.category, catData.icon);

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: isDark ? t.card : Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () {
            if (item.id != null) {
              context.push('/transaction/${item.id}');
            }
          },
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Left: Colored rounded square icon container (matches Image 1)
                Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    color: iconBg,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(child: Icon(icon, size: 17, color: iconFg)),
                ),
                const SizedBox(width: 10),

                // Middle: title, category, and date/purpose subtitle
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Row(
                        children: [
                          Flexible(
                            child: Text(
                              item.title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 13.5,
                                fontWeight: FontWeight.w700,
                                color: t.textPrimary,
                              ),
                            ),
                          ),
                          if (item.category.trim().isNotEmpty) ...[
                            const SizedBox(width: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 6,
                                vertical: 2,
                              ),
                              decoration: BoxDecoration(
                                color: iconBg,
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                item.category,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w700,
                                  color: iconFg,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                      const SizedBox(height: 2),
                      Text(
                        item.subtitle,
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w500,
                          color: t.textDisabled,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),

                // Right: amount + bank tag
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      item.amountStr,
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: amountColor,
                      ),
                    ),
                    if (item.bankTag.isNotEmpty) ...[
                      const SizedBox(height: 2),
                      Text(
                        item.bankTag,
                        style: TextStyle(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w500,
                          color: t.textDisabled,
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  static IconData _resolveCategoryIcon(String category, IconData fallback) {
    final cat = category.toLowerCase().trim();
    if (cat.contains('food') ||
        cat.contains('dining') ||
        cat.contains('coffee') ||
        cat.contains('cafe')) {
      return LucideIcons.bookOpen;
    }
    if (cat.contains('salary') || cat.contains('income')) {
      return LucideIcons.briefcase;
    }
    if (cat.contains('groc') ||
        cat.contains('mart') ||
        cat.contains('market') ||
        cat.contains('supermarket')) {
      return LucideIcons.shoppingCart;
    }
    if (cat.contains('transport') ||
        cat.contains('transit') ||
        cat.contains('metro') ||
        cat.contains('travel') ||
        cat.contains('fuel')) {
      return LucideIcons.zap;
    }
    return fallback;
  }

  static String _homeRecentTimeLabel(model.Transaction tx, DateTime local) {
    final raw = tx.time.trim();
    final looksLikeClock = RegExp(
      r'^\d{1,2}:\d{2}(\s*[AaPp][Mm])?$',
    ).hasMatch(raw);
    if (looksLikeClock) return raw;
    return DateFormat('h:mm a').format(local);
  }

  static String _homeRecentPurposeLabel(String? purpose) {
    final raw = (purpose ?? '').trim();
    if (raw.isEmpty) return 'Personal';
    if (raw.length == 1) return raw.toUpperCase();
    return '${raw[0].toUpperCase()}${raw.substring(1)}';
  }

  static String _homeRecentAccountLabel(model.Transaction tx) {
    final raw =
        tx.bankName.trim().isNotEmpty
            ? tx.bankName.trim()
            : (tx.account.trim().isNotEmpty ? tx.account.trim() : '');
    if (raw.isEmpty) return '';
    if (raw.toLowerCase() == 'cash') return 'Cash';
    if (raw == raw.toLowerCase() && raw.length <= 6 && !raw.contains(' ')) {
      return raw.toUpperCase();
    }
    return raw;
  }
}
