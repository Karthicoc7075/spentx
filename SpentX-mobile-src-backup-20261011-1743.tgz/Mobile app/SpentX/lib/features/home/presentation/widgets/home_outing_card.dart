import 'package:flutter/material.dart';
import '../../../../core/theme/soft_palette.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/navigation/main_shell_navigation.dart';
import '../../../../core/providers/outing_provider.dart';
import '../../../../core/providers/transaction_provider.dart' as model;
import '../../../../core/theme/spentx_tokens.dart';
import '../../../transactions/presentation/add_transaction_sheet.dart';
import 'soft_home_widgets.dart';

// ─────────────────────────────────────────────────────────────
// 1. Home Active Outing Card
// ─────────────────────────────────────────────────────────────
class HomeActiveOutingCard extends StatelessWidget {
  final Outing? outing;
  final String Function(int) formatIndian;

  const HomeActiveOutingCard({
    super.key,
    required this.outing,
    required this.formatIndian,
  });

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    if (outing == null) {
      return SoftHomeCard(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 14),
        radius: 24,
        child: Row(
          children: [
            Expanded(
              child: Text(
                'No active outing',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: t.textDisabled,
                ),
              ),
            ),
            GestureDetector(
              onTap: () => context.push('/outings'),
              child: Text(
                'Trips',
                style: TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w700,
                  color: isDark ? const Color(0xFF34D399) : const Color(0xFF0D9488),
                ),
              ),
            ),
          ],
        ),
      );
    }

    final trip = outing!;
    final String tripTitle =
        trip.title.trim().isNotEmpty ? trip.title.trim() : 'Outing';
    final double budget = (trip.budget != null && trip.budget! > 0) ? trip.budget! : 0;
    final double totalSpent =
        trip.expenses.fold<double>(0, (sum, e) => sum + e.amount);
    final int usedPct = budget > 0 ? ((totalSpent / budget) * 100).round() : 0;

    final now = DateTime.now();
    final tripDays = trip.endDate.difference(trip.startDate).inDays + 1;
    final daySpan = tripDays < 1 ? 1 : tripDays;
    final dayIndex = (now.difference(trip.startDate).inDays + 1).clamp(1, daySpan);

    final startStr = DateFormat('d MMM').format(trip.startDate);
    final endStr = DateFormat('d MMM').format(trip.endDate);

    return SoftHomeCard(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      radius: 24,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Top Row: Active Outing Badge + Day info + Details link
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color:
                          isDark
                              ? const Color(0xB306281E)
                              : const Color(0xFFF0FDF4),
                      borderRadius: BorderRadius.circular(999),
                      border: Border.all(
                        color:
                            isDark
                                ? const Color(0x4D10B981)
                                : const Color(0xFFA7F3D0),
                        width: 1,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 2.5,
                          height: 10,
                          decoration: BoxDecoration(
                            color: const Color(0xFF10B981),
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                        const SizedBox(width: 5),
                        Text(
                          'ACTIVE OUTING',
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 0.6,
                            color:
                                isDark
                                    ? const Color(0xFF6EE7B7)
                                    : const Color(0xFF065F46),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    'Day $dayIndex of $daySpan',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      color: t.textDisabled,
                    ),
                  ),
                ],
              ),
              GestureDetector(
                onTap: () {
                  if (outing != null) {
                    context.push('/outing-detail/${outing!.id}');
                  } else {
                    context.push('/outings');
                  }
                },
                child: Row(
                  children: [
                    Text(
                      'Details',
                      style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w600,
                        color:
                            isDark
                                ? const Color(0xFF34D399)
                                : const Color(0xFF0D9488),
                      ),
                    ),
                    const SizedBox(width: 2),
                    Icon(
                      LucideIcons.arrowRight,
                      size: 13,
                      color:
                          isDark
                              ? const Color(0xFF34D399)
                              : const Color(0xFF0D9488),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),

          // Title & Dates
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  const Text('💼', style: TextStyle(fontSize: 16)),
                  const SizedBox(width: 6),
                  Text(
                    tripTitle,
                    style: TextStyle(
                      fontSize: 15.5,
                      fontWeight: FontWeight.w700,
                      color: t.textPrimary,
                    ),
                  ),
                ],
              ),
              Text(
                '$startStr – $endStr',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  color: t.textDisabled,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),

          // Budget Progress Row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.baseline,
                textBaseline: TextBaseline.alphabetic,
                children: [
                  Text(
                    '₹${formatIndian(totalSpent.toInt())}',
                    style: TextStyle(
                      fontSize: 14.5,
                      fontWeight: FontWeight.w700,
                      color: t.textPrimary,
                    ),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    budget > 0
                        ? 'of ₹${formatIndian(budget.toInt())}'
                        : 'no budget',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      color: t.textDisabled,
                    ),
                  ),
                ],
              ),
              Text(
                '$usedPct% used',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color:
                      isDark
                          ? const Color(0xFF34D399)
                          : const Color(0xFF0D9488),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),

          // Progress Bar
          ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: LinearProgressIndicator(
              value: (usedPct / 100.0).clamp(0.0, 1.0),
              minHeight: 8,
              backgroundColor:
                  isDark ? const Color(0xFF27272A) : const Color(0xFFF1F5F9),
              valueColor: const AlwaysStoppedAnimation<Color>(
                Color(0xFF10B981),
              ),
            ),
          ),
          const SizedBox(height: 10),

          // Bottom Action Row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Auto-synced with Trip Ledger',
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                  color: t.textDisabled,
                ),
              ),
              GestureDetector(
                onTap: () => AddTransactionSheet.show(context),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 6.5,
                  ),
                  decoration: BoxDecoration(
                    color:
                        isDark
                            ? const Color(0xFF18181B)
                            : const Color(0xFF0F172A),
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: const Row(
                    children: [
                      Text(
                        '+',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF34D399),
                        ),
                      ),
                      SizedBox(width: 4),
                      Text(
                        'Expense',
                        style: TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
// 2. Outing privacy home
// ─────────────────────────────────────────────────────────────

class HomePrivacyHeader extends StatelessWidget {
  const HomePrivacyHeader({
    super.key,
    required this.greeting,
    required this.initials,
    this.hasUnread = false,
    this.onNotifications,
    this.onProfile,
  });

  final String greeting;
  final String initials;
  final bool hasUnread;
  final VoidCallback? onNotifications;
  final VoidCallback? onProfile;

  @override
  Widget build(BuildContext context) {
    final tone = HomePrivacyTone(context);
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                greeting,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: tone.text(
                  22,
                  FontWeight.w800,
                  tone.ink,
                  letterSpacing: -0.4,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                'HOME',
                style: tone.text(
                  12,
                  FontWeight.w700,
                  tone.slate,
                  letterSpacing: 0.8,
                ),
              ),
            ],
          ),
        ),
        _PrivacyCircleButton(
          onTap: onNotifications,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Icon(LucideIcons.bell, size: 17, color: tone.ink),
              if (hasUnread)
                const Positioned(
                  top: 8,
                  right: 8,
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      color: Color(0xFFEF4444),
                      shape: BoxShape.circle,
                    ),
                    child: SizedBox(width: 6, height: 6),
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(width: 8),
        GestureDetector(
          onTap: onProfile,
          child: Container(
            width: 40,
            height: 40,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: tone.mint,
              shape: BoxShape.circle,
              border: Border.all(color: tone.border),
            ),
            child: Text(
              initials,
              style: tone.text(13, FontWeight.w700, tone.emeraldDeep),
            ),
          ),
        ),
      ],
    );
  }
}

class HomeOutingPrivacyBody extends StatelessWidget {
  const HomeOutingPrivacyBody({
    super.key,
    required this.outing,
    required this.activity,
    required this.gross,
    required this.formatIndian,
    required this.onExitPrivacy,
  });

  final Outing outing;
  final List<dynamic> activity;
  final double gross;
  final String Function(int) formatIndian;
  final VoidCallback onExitPrivacy;

  String _inr(num value) => '₹${formatIndian(value.toInt())}';

  double get _netBalance {
    return outing.friendBalanceSummary().values.fold<double>(
      0,
      (sum, row) => sum + (row.pendingToYou - row.youOwe),
    );
  }

  @override
  Widget build(BuildContext context) {
    final tone = HomePrivacyTone(context);
    final net = _netBalance;
    final balanceText =
        net < -0.01
            ? 'Your Balance: ${_inr(net.abs())} you owe'
            : 'Your Balance: ${_inr(net.abs())} to receive';
    final balanceFill =
        net < -0.01 ? const Color(0xFFFFF7ED) : const Color(0xFFECFDF5);
    final balanceInk =
        net < -0.01 ? const Color(0xFFEA580C) : const Color(0xFF059669);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: tone.cardBox(fill: tone.mint),
          child: Row(
            children: [
              Icon(LucideIcons.eyeOff, size: 18, color: tone.emeraldDeep),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Outing privacy on',
                      style: tone.text(14, FontWeight.w700, tone.ink),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      outing.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: tone.text(12, FontWeight.w500, tone.slate),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Material(
                color: tone.card,
                borderRadius: BorderRadius.circular(999),
                child: InkWell(
                  onTap: onExitPrivacy,
                  borderRadius: BorderRadius.circular(999),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 6,
                    ),
                    child: Text(
                      'Exit privacy',
                      style: tone.text(12, FontWeight.w700, tone.emeraldDeep),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF12261A), Color(0xFF064E3B)],
            ),
            borderRadius: BorderRadius.circular(24),
            boxShadow: tone.shadow,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      'OUTING EXPENSES',
                      style: tone.text(
                        11,
                        FontWeight.w700,
                        Colors.white.withValues(alpha: 0.72),
                        letterSpacing: 0.8,
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.14),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      'Members',
                      style: tone.text(11, FontWeight.w700, Colors.white),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Text(
                _inr(gross),
                style: tone.text(
                  34,
                  FontWeight.w800,
                  Colors.white,
                  letterSpacing: -0.8,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'Total trip spend',
                style: tone.text(
                  13,
                  FontWeight.w500,
                  Colors.white.withValues(alpha: 0.72),
                ),
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: balanceFill,
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  balanceText,
                  style: tone.text(12, FontWeight.w700, balanceInk),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              flex: 3,
              child: _PrivacyActionButton(
                label: 'Add Split',
                filled: true,
                onTap:
                    () => AddTransactionSheet.show(
                      context,
                      startInTripMode: true,
                    ),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              flex: 3,
              child: _PrivacyActionButton(
                label: 'View Outing',
                onTap: () => context.push('/outing-detail/${outing.id}'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              flex: 3,
              child: _PrivacyActionButton(
                label: 'Settle Up',
                onTap:
                    () => AddTransactionSheet.show(
                      context,
                      startInTripMode: true,
                    ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 14),
          decoration: tone.cardBox(),
          child: Row(
            children: [
              _PrivacyStat(label: 'Trip Total', value: _inr(gross)),
              _PrivacyStatDivider(),
              _PrivacyStat(
                label: 'You Paid',
                value: _inr(outing.yourPaidTotal),
              ),
              _PrivacyStatDivider(),
              _PrivacyStat(
                label: 'Your Share',
                value: _inr(outing.yourSplitShareTotal),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        Row(
          children: [
            Expanded(
              child: Text(
                'OUTING ACTIVITY',
                style: tone.text(
                  12,
                  FontWeight.w700,
                  tone.muted,
                  letterSpacing: 0.8,
                ),
              ),
            ),
            GestureDetector(
              onTap: () => MainShellNavigation.openTab(context, 1),
              behavior: HitTestBehavior.opaque,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Text(
                  'See all',
                  style: tone.text(13, FontWeight.w700, tone.emeraldDeep),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        if (activity.isEmpty)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: tone.cardBox(),
            child: Text(
              'No expenses logged in this trip yet.',
              style: tone.text(13, FontWeight.w500, tone.slate),
            ),
          )
        else
          for (final item in activity) ...[
            _PrivacyActivityTile(
              outing: outing,
              item: item,
              amount: _inr(_itemAmount(item)),
            ),
            const SizedBox(height: 10),
          ],
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: Text(
                'PERSONAL MONEY & PLAN',
                style: tone.text(
                  12,
                  FontWeight.w700,
                  tone.muted,
                  letterSpacing: 0.6,
                ),
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: tone.mint,
                borderRadius: BorderRadius.circular(999),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(LucideIcons.lock, size: 12, color: tone.emeraldDeep),
                  const SizedBox(width: 4),
                  Text(
                    'Masked',
                    style: tone.text(11, FontWeight.w700, tone.emeraldDeep),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.fromLTRB(14, 6, 14, 12),
          decoration: tone.cardBox(),
          child: Column(
            children: [
              _MaskedMoneyRow(
                icon: LucideIcons.pieChart,
                label: 'Monthly Envelopes & Limits',
              ),
              Divider(height: 1, color: tone.border),
              _MaskedMoneyRow(
                icon: LucideIcons.landmark,
                label: 'Bank Balances & SMS Sync',
              ),
              const SizedBox(height: 8),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Hidden while privacy mode is active',
                  style: tone.text(12, FontWeight.w500, tone.slate),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  double _itemAmount(dynamic item) {
    if (item is OutingExpense) return item.amount;
    if (item is model.Transaction) return item.amount;
    return 0;
  }
}

class _PrivacyCircleButton extends StatelessWidget {
  const _PrivacyCircleButton({required this.child, this.onTap});

  final Widget child;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final tone = HomePrivacyTone(context);
    return Material(
      color: tone.card,
      elevation: 0,
      shape: CircleBorder(side: BorderSide(color: tone.border)),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(width: 40, height: 40, child: child),
      ),
    );
  }
}

class _PrivacyActionButton extends StatelessWidget {
  const _PrivacyActionButton({
    required this.label,
    required this.onTap,
    this.filled = false,
  });

  final String label;
  final VoidCallback onTap;
  final bool filled;

  @override
  Widget build(BuildContext context) {
    final tone = HomePrivacyTone(context);
    return SizedBox(
      height: 44,
      child:
          filled
              ? ElevatedButton(
                onPressed: onTap,
                style: ElevatedButton.styleFrom(
                  backgroundColor: SoftColors.control,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: tone.text(12, FontWeight.w700, Colors.white),
                ),
              )
              : OutlinedButton(
                onPressed: onTap,
                style: OutlinedButton.styleFrom(
                  backgroundColor: tone.card,
                  foregroundColor: tone.ink,
                  side: BorderSide(color: tone.border),
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: tone.text(12, FontWeight.w700, tone.ink),
                ),
              ),
    );
  }
}

class _PrivacyStat extends StatelessWidget {
  const _PrivacyStat({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final tone = HomePrivacyTone(context);
    return Expanded(
      child: Column(
        children: [
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: tone.text(11, FontWeight.w600, tone.slate),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: tone.text(14, FontWeight.w800, tone.ink),
          ),
        ],
      ),
    );
  }
}

class _PrivacyStatDivider extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 1,
      height: 28,
      color: HomePrivacyTone(context).border,
    );
  }
}

class _PrivacyActivityTile extends StatelessWidget {
  const _PrivacyActivityTile({
    required this.outing,
    required this.item,
    required this.amount,
  });

  final Outing outing;
  final dynamic item;
  final String amount;

  @override
  Widget build(BuildContext context) {
    final tone = HomePrivacyTone(context);
    final title =
        item is OutingExpense
            ? (item.title.trim().isEmpty ? 'Expense' : item.title)
            : (item as model.Transaction).merchant;
    final category =
        item is OutingExpense
            ? item.category
            : (item as model.Transaction).category;
    final note =
        item is OutingExpense
            ? '${item.category} · ${item.splitType == SplitType.solo ? 'Solo' : 'Split'} · Paid by ${item.paidByLabel(outing)}'
            : '${(item as model.Transaction).category} · ${(item as model.Transaction).account}';

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () {
          if (item is OutingExpense) {
            final txId = item.transactionId;
            if (txId != null && txId.isNotEmpty) {
              context.push('/transaction/$txId');
            } else {
              context.push('/outing-expense/${outing.id}/${item.id}');
            }
          } else if (item is model.Transaction) {
            context.push('/transaction/${item.id}');
          }
        },
        borderRadius: BorderRadius.circular(24),
        child: Ink(
          padding: const EdgeInsets.all(14),
          decoration: tone.cardBox(),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: tone.mint,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(
                  _privacyCatIcon(category),
                  size: 18,
                  color: tone.emeraldDeep,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: tone.text(15, FontWeight.w700, tone.ink),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      note,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: tone.text(12, FontWeight.w500, tone.slate),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Text(amount, style: tone.text(15, FontWeight.w800, tone.ink)),
            ],
          ),
        ),
      ),
    );
  }
}

class _MaskedMoneyRow extends StatelessWidget {
  const _MaskedMoneyRow({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    final tone = HomePrivacyTone(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: tone.mint,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, size: 18, color: tone.emeraldDeep),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              label,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: tone.text(14, FontWeight.w600, tone.ink),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: tone.canvas,
              borderRadius: BorderRadius.circular(999),
              border: Border.all(color: tone.border),
            ),
            child: Text(
              'Hidden',
              style: tone.text(11, FontWeight.w700, tone.slate),
            ),
          ),
        ],
      ),
    );
  }
}

IconData _privacyCatIcon(String cat) {
  switch (cat.toLowerCase()) {
    case 'food':
    case 'restaurant':
    case 'dining':
    case 'food & dining':
      return LucideIcons.utensils;
    case 'shopping':
    case 'groceries':
      return LucideIcons.shoppingBag;
    case 'transport':
    case 'travel':
    case 'flight':
      return LucideIcons.car;
    case 'stay':
    case 'hotel':
    case 'hotel stay':
      return LucideIcons.hotel;
    default:
      return LucideIcons.receipt;
  }
}
