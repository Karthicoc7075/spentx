import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/theme/soft_palette.dart';
import 'home_painters.dart';
import 'soft_home_widgets.dart';

/// Home hero: liquid balance (bank + cash + wallet − credit card dues).
/// Goals and investments live on the Wealth page only.
class HomeHeroCard extends StatefulWidget {
  final double liquidBalance;
  final double netSavedThisMonth;
  final bool isPrivate;
  final VoidCallback onPrivacyToggle;
  final String Function(int) formatIndian;

  const HomeHeroCard({
    super.key,
    required this.liquidBalance,
    required this.netSavedThisMonth,
    required this.isPrivate,
    required this.onPrivacyToggle,
    required this.formatIndian,
  });

  @override
  State<HomeHeroCard> createState() => _HomeHeroCardState();
}

class _HomeHeroCardState extends State<HomeHeroCard> {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          colors: [
            SoftHomeTone.liquidTop,
            SoftHomeTone.liquidMid,
            SoftHomeTone.liquidBottom,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x29000000),
            blurRadius: 20,
            offset: Offset(0, 8),
            spreadRadius: -4,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Stack(
          children: [
            // Ambient glowing background spots
            Positioned(
              top: -40,
              right: -30,
              child: Container(
                width: 170,
                height: 170,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: SoftPalette.mint.withValues(alpha: 0.16),
                ),
              ),
            ),
            Positioned(
              bottom: -30,
              left: -20,
              child: Container(
                width: 150,
                height: 150,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFF14B8A6).withValues(alpha: 0.12),
                ),
              ),
            ),

            // Single slide: liquid balance (goals/investments → Wealth page).
            Column(
              children: [
                SizedBox(
                  height: 148,
                  child: _buildHeroSlide(
                    title: 'LIQUID BALANCE',
                    amountStr:
                        widget.isPrivate
                            ? '••••••'
                            : '₹${widget.formatIndian(widget.liquidBalance.toInt())}.00',
                    subPillText:
                        widget.netSavedThisMonth != 0
                            ? '${widget.netSavedThisMonth >= 0 ? "↗ +" : "↘ -"}₹${widget.formatIndian(widget.netSavedThisMonth.abs().toInt())}'
                            : null,
                    subPillLabel: 'net saved this month',
                    emptyLabel: 'Waiting for your first money in',
                    sparklinePoints: const [],
                    isPrivate: widget.isPrivate,
                    onPrivacyToggle: widget.onPrivacyToggle,
                    onTap: () => context.push('/accounts'),
                  ),
                ),
                // Keeps the card height the same as before the dots were removed.
                const SizedBox(height: 13),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeroSlide({
    required String title,
    required String amountStr,
    required String? subPillText,
    required String subPillLabel,
    required String emptyLabel,
    required List<double> sparklinePoints,
    required bool isPrivate,
    required VoidCallback onPrivacyToggle,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            // Top Row (Label + Hide Button)
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: const BoxDecoration(
                        color: Color(0xFF34D399),
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x6634D399),
                            blurRadius: 6,
                            spreadRadius: 1,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1.3,
                        color: Color(0xFF6EE7B7),
                      ),
                    ),
                  ],
                ),
                GestureDetector(
                  onTap: onPrivacyToggle,
                  behavior: HitTestBehavior.opaque,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 6.5,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(999),
                      border: Border.all(
                        color: Colors.white.withValues(alpha: 0.2),
                        width: 1,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          isPrivate ? LucideIcons.eyeOff : LucideIcons.eye,
                          color: const Color(0xFFA7F3D0),
                          size: 15,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          isPrivate ? 'Show' : 'Hide',
                          style: const TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w600,
                            color: Color(0xFFA7F3D0),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),

            // Amount & Sparkline Row
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        amountStr,
                        style: const TextStyle(
                          fontSize: 32,
                          fontWeight: FontWeight.w800,
                          letterSpacing: -0.8,
                          color: Colors.white,
                          height: 1.1,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 6),
                      if (subPillText != null)
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 3,
                              ),
                              decoration: BoxDecoration(
                                color: const Color(
                                  0xFF10B981,
                                ).withValues(alpha: 0.22),
                                borderRadius: BorderRadius.circular(999),
                                border: Border.all(
                                  color: const Color(
                                    0xFF34D399,
                                  ).withValues(alpha: 0.45),
                                  width: 1.1,
                                ),
                              ),
                              child: Text(
                                subPillText,
                                style: const TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: Color(0xFF34D399),
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Flexible(
                              child: Text(
                                subPillLabel,
                                style: const TextStyle(
                                  fontSize: 12.5,
                                  fontWeight: FontWeight.w500,
                                  color: Color(0xCCA7F3D0),
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        )
                      else
                        Text(
                          emptyLabel,
                          style: const TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w500,
                            color: Color(0xCCA7F3D0),
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                    ],
                  ),
                ),

                // Sparkline Graph
                SizedBox(
                  width: 88,
                  height: 40,
                  child: CustomPaint(
                    painter: SparklinePainter(
                      points: sparklinePoints,
                      strokeColor: const Color(0xFF34D399),
                      fillStartColor: const Color(
                        0xFF34D399,
                      ).withValues(alpha: 0.28),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
