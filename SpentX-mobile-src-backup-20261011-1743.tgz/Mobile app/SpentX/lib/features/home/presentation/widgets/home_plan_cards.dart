import 'package:flutter/material.dart';
import '../../../../core/theme/soft_palette.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/theme/spentx_tokens.dart';
import 'home_painters.dart';
import 'soft_home_widgets.dart';

// ─────────────────────────────────────────────────────────────
// 1. Ultra-Slim SMS Banner
// ─────────────────────────────────────────────────────────────
class HomeSmsBanner extends StatelessWidget {
  final int count;

  const HomeSmsBanner({super.key, required this.count});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF132A22) : const Color(0xFFF0FDF4),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(
          color: isDark ? const Color(0xFF047857) : const Color(0xFFBBF7D0),
          width: 0.9,
        ),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => context.push('/detected-sms'),
          borderRadius: BorderRadius.circular(999),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7.5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 7,
                      height: 7,
                      decoration: const BoxDecoration(
                        color: Color(0xFF10B981),
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Icon(
                      LucideIcons.smartphone,
                      size: 14,
                      color:
                          isDark
                              ? const Color(0xFF34D399)
                              : const Color(0xFF047857),
                    ),
                    const SizedBox(width: 7),
                    Text(
                      '$count new transactions from SMS',
                      style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w600,
                        color:
                            isDark
                                ? const Color(0xFFE2E8F0)
                                : const Color(0xFF1E293B),
                      ),
                    ),
                  ],
                ),
                Text(
                  'Review →',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color:
                        isDark
                            ? const Color(0xFF34D399)
                            : const Color(0xFF047857),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
// 2. Monthly Budget Usage Card
// ─────────────────────────────────────────────────────────────
class HomeMonthlyBudgetCard extends StatelessWidget {
  final double remaining;
  final double spent;
  final double limit;
  final int usagePct;
  final String? purposeLabel;
  final String Function(int) formatIndian;

  const HomeMonthlyBudgetCard({
    super.key,
    required this.remaining,
    required this.spent,
    required this.limit,
    required this.usagePct,
    this.purposeLabel,
    required this.formatIndian,
  });

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isHigh = usagePct >= 90;

    return Column(
      children: [
        const WavyDivider(label: 'Monthly Plan'),
        const SizedBox(height: 8),
        SoftHomeCard(
          padding: const EdgeInsets.all(14),
          radius: 24,
          child: Column(
            children: [
              // Top Status Pill
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  color:
                      isDark
                          ? (isHigh
                              ? const Color(0x33EF4444)
                              : const Color(0xB306281E))
                          : (isHigh
                              ? const Color(0xFFFEF2F2)
                              : const Color(0xFFE8F8F0)),
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(
                    color:
                        isDark
                            ? (isHigh
                                ? const Color(0x66EF4444)
                                : const Color(0x4010B981))
                            : const Color(0xFFD1FAE5),
                    width: 0.8,
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    RichText(
                      text: TextSpan(
                        style: TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w500,
                          color:
                              isDark
                                  ? (isHigh
                                      ? const Color(0xFFFCA5A5)
                                      : const Color(0xFFA7F3D0))
                                  : (isHigh
                                      ? const Color(0xFF991B1B)
                                      : const Color(0xFF065F46)),
                        ),
                        children:
                            limit <= 0
                                ? const [TextSpan(text: 'No monthly plan yet')]
                                : [
                                  const TextSpan(text: 'You can Spend '),
                                  TextSpan(
                                    text: '₹${formatIndian(remaining.toInt())}',
                                    style: TextStyle(
                                      fontWeight: FontWeight.w700,
                                      color:
                                          isDark
                                              ? (isHigh
                                                  ? const Color(0xFFEF4444)
                                                  : const Color(0xFF34D399))
                                              : (isHigh
                                                  ? const Color(0xFFDC2626)
                                                  : const Color(0xFF10B981)),
                                    ),
                                  ),
                                  const TextSpan(text: ' More This Month'),
                                ],
                      ),
                    ),
                    Row(
                      children: [
                        Container(
                          width: 7,
                          height: 7,
                          decoration: BoxDecoration(
                            color:
                                isHigh
                                    ? const Color(0xFFEF4444)
                                    : const Color(0xFF10B981),
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 5),
                        Text(
                          isHigh ? 'Caution ›' : 'Normal ›',
                          style: TextStyle(
                            fontSize: 11.5,
                            fontWeight: FontWeight.w700,
                            color:
                                isDark
                                    ? (isHigh
                                        ? const Color(0xFFEF4444)
                                        : const Color(0xFF34D399))
                                    : (isHigh
                                        ? const Color(0xFFDC2626)
                                        : const Color(0xFF047857)),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),

              // Speedometer Gauge + Metrics Row
              GestureDetector(
                onTap: () => context.push('/plan'),
                behavior: HitTestBehavior.opaque,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // Circular horseshoe speedometer arc gauge (matching Image 1)
                    SizedBox(
                      width: 74,
                      height: 74,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          CustomPaint(
                            size: const Size(74, 74),
                            painter: DonutGaugePainter(
                              percentage: usagePct / 100.0,
                              trackColor:
                                  isDark
                                      ? const Color(0xFF27272A)
                                      : const Color(0xFFE6F4EA),
                              progressColor:
                                  isHigh
                                      ? const Color(0xFFEF4444)
                                      : SoftColors.control,
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 2),
                            child: Text(
                              '$usagePct%',
                              style: TextStyle(
                                fontSize: 15.5,
                                fontWeight: FontWeight.w800,
                                color: t.textPrimary,
                                letterSpacing: -0.2,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 18),

                    // Info Column
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Monthly Budget Usage',
                            style: TextStyle(
                              fontSize: 12.5,
                              fontWeight: FontWeight.w500,
                              color: t.textDisabled,
                            ),
                          ),
                          if (purposeLabel != null &&
                              purposeLabel!.trim().isNotEmpty) ...[
                            const SizedBox(height: 2),
                            Text(
                              purposeLabel!.trim(),
                              style: TextStyle(
                                fontSize: 11.5,
                                fontWeight: FontWeight.w700,
                                color:
                                    isDark
                                        ? const Color(0xFF34D399)
                                        : const Color(0xFF047857),
                              ),
                            ),
                          ],
                          const SizedBox(height: 3),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.baseline,
                            textBaseline: TextBaseline.alphabetic,
                            children: [
                              Text(
                                '₹${formatIndian(spent.toInt())}',
                                style: TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.w800,
                                  color: t.textPrimary,
                                  letterSpacing: -0.3,
                                ),
                              ),
                              const SizedBox(width: 4),
                              Text(
                                '/',
                                style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w500,
                                  color: t.textDisabled,
                                ),
                              ),
                              const SizedBox(width: 4),
                              Text(
                                '₹${formatIndian(limit.toInt())}',
                                style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w700,
                                  color:
                                      isDark
                                          ? const Color(0xFF34D399)
                                          : const Color(0xFF10B981),
                                  letterSpacing: -0.2,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ─────────────────────────────────────────────────────────────
// Empty monthly plan — uploaded illustration, no fake numbers.
// ─────────────────────────────────────────────────────────────
class HomeEmptyMonthlyPlan extends StatelessWidget {
  const HomeEmptyMonthlyPlan({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final ink = isDark ? const Color(0xFFF8FAFC) : const Color(0xFF0F172A);
    final slate = isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B);
    return GestureDetector(
      onTap: () => context.push('/plan'),
      behavior: HitTestBehavior.opaque,
      child: Column(
        children: [
          const WavyDivider(label: 'Monthly Plan'),
          const SizedBox(height: 8),
          SoftHomeCard(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 18),
            radius: 24,
            child: Column(
              children: [
                Image.asset(
                  'assets/images/monthly_plan_illustration.png',
                  height: 168,
                  fit: BoxFit.contain,
                ),
                const SizedBox(height: 8),
                Text(
                  'Create a monthly plan',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    color: ink,
                    letterSpacing: -0.2,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'Set this month\'s plan for Home, Food, Transport, Shopping and Others.',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                    height: 1.35,
                    color: slate,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
// 3. Saving Reports Section Card
// ─────────────────────────────────────────────────────────────
class HomeSavingReportCard extends StatelessWidget {
  final String profileName;
  final double totalSaving;
  final double savingTarget;
  final int savingPct;
  final String Function(int) formatIndian;

  const HomeSavingReportCard({
    super.key,
    required this.profileName,
    required this.totalSaving,
    required this.savingTarget,
    required this.savingPct,
    required this.formatIndian,
  });

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Column(
      children: [
        const WavyDivider(label: 'Saving Report'),
        const SizedBox(height: 10),

        // Main Savings Card
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: t.card,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: t.border, width: 1),
            boxShadow:
                isDark
                    ? [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.25),
                        blurRadius: 12,
                        offset: const Offset(0, 4),
                      ),
                    ]
                    : AppShadows.subtle,
          ),
          child: Column(
            children: [
              // Top Row: Potted Plant Icon + Total Saving + Percent Trend
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      // Cute potted plant illustration matching Image 1
                      const SavingsPlantIllustration(),
                      const SizedBox(width: 10),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Total Saving',
                            style: TextStyle(
                              fontSize: 11.5,
                              fontWeight: FontWeight.w500,
                              color:
                                  isDark
                                      ? const Color(0xFF94A3B8)
                                      : t.textDisabled,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.baseline,
                            textBaseline: TextBaseline.alphabetic,
                            children: [
                              Text(
                                '₹${formatIndian(totalSaving.toInt())}',
                                style: TextStyle(
                                  fontSize: 16.5,
                                  fontWeight: FontWeight.w800,
                                  color: t.textPrimary,
                                ),
                              ),
                              const SizedBox(width: 5),
                              Text(
                                '₹${formatIndian(savingTarget.toInt())}',
                                style: TextStyle(
                                  fontSize: 13.5,
                                  fontWeight: FontWeight.w700,
                                  color:
                                      isDark
                                          ? const Color(0xFF34D399)
                                          : const Color(0xFF10B981),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        '$savingPct%',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                          color: t.textPrimary,
                          letterSpacing: -0.3,
                        ),
                      ),
                      const SizedBox(width: 3),
                      Icon(
                        LucideIcons.arrowUpRight,
                        size: 20,
                        color:
                            isDark
                                ? const Color(0xFF34D399)
                                : const Color(0xFF10B981),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 14),

              // Interactive Slider Progress Bar with Vertical Pill Handle
              LayoutBuilder(
                builder: (context, constraints) {
                  final totalWidth = constraints.maxWidth;
                  final progressFraction = (savingPct / 100.0).clamp(0.0, 1.0);
                  final activeWidth = totalWidth * progressFraction;

                  return SizedBox(
                    height: 14,
                    child: Stack(
                      alignment: Alignment.centerLeft,
                      children: [
                        // Inactive background track
                        Container(
                          width: totalWidth,
                          height: 8,
                          decoration: BoxDecoration(
                            color:
                                isDark
                                    ? const Color(0xFF27272A)
                                    : const Color(0xFFE6F4EA),
                            borderRadius: BorderRadius.circular(999),
                          ),
                        ),
                        // Filled active track
                        Container(
                          width: activeWidth,
                          height: 8,
                          decoration: BoxDecoration(
                            color: const Color(0xFF10B981),
                            borderRadius: BorderRadius.circular(999),
                          ),
                        ),
                        // Vertical slider handle thumb
                        Positioned(
                          left: (activeWidth - 4).clamp(0.0, totalWidth - 8),
                          child: Container(
                            width: 8,
                            height: 14,
                            decoration: BoxDecoration(
                              color: const Color(0xFF047857),
                              borderRadius: BorderRadius.circular(4),
                              border: Border.all(
                                color: Colors.white,
                                width: 1.2,
                              ),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0x33000000),
                                  blurRadius: 3,
                                  offset: Offset(0, 1),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
              const SizedBox(height: 12),

              // Motivational Banner Pill
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 7.5,
                ),
                decoration: BoxDecoration(
                  color:
                      isDark
                          ? const Color(0xFF132A22)
                          : const Color(0xFFECFDF5),
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(
                    color:
                        isDark
                            ? const Color(0xFF065F46)
                            : const Color(0xFFD1FAE5),
                    width: 0.8,
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      savingTarget <= 0
                          ? 'Set a savings target in your monthly plan.'
                          : "🌿 You're doing great, $profileName! Keep it up.. 👍",
                      style: TextStyle(
                        fontSize: 11.5,
                        fontWeight: FontWeight.w600,
                        color:
                            isDark
                                ? const Color(0xFFA7F3D0)
                                : const Color(0xFF047857),
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
