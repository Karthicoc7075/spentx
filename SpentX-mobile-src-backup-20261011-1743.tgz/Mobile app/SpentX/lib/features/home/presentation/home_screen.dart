import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/providers/outing_privacy_provider.dart';
import '../../../core/providers/outing_provider.dart';
import '../../../core/providers/plan_provider.dart';
import '../../../core/providers/transaction_provider.dart' as model;
import '../../../core/providers/user_state_provider.dart';
import '../../../core/providers/wealth_provider.dart';
import '../../../core/services/auth_service.dart';
import '../../../core/services/notification_history_service.dart';
import '../../../core/sync/sync_service.dart';
import '../../../core/navigation/main_shell_navigation.dart';
import '../../../core/theme/spentx_tokens.dart';
import '../../../core/utils/budget_spend.dart';
import '../../../core/utils/ledger_month_index.dart';
import '../../../core/providers/category_provider.dart';
import '../../../core/widgets/terminal_wrapper.dart';
import '../../groups/presentation/widgets/privacy_unlock_dialog.dart';
import '../../sms/detected/detection_queue.dart';
import '../../sms/detected/pending_verification_presenter.dart';
import '../data/private_mode_provider.dart';
import 'widgets/home_hero_card.dart';
import 'widgets/home_outing_card.dart';
import 'widgets/home_plan_cards.dart';
import 'widgets/home_recent_transactions.dart';
import 'widgets/soft_home_widgets.dart';

final GlobalKey<ConsumerState<HomeScreen>> homeScreenKey =
    GlobalKey<ConsumerState<HomeScreen>>();

const double _bottomClearance = 80.0;

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _spinController;
  bool _refreshing = false;

  @override
  void initState() {
    super.initState();
    _spinController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final notifier = ref.read(userStateProvider.notifier);
      final userState = ref.read(userStateProvider);
      if (userState.isFirstTimeUser) {
        notifier.markSetupComplete();
      }
    });
  }

  @override
  void dispose() {
    _spinController.dispose();
    super.dispose();
  }

  Future<void> _refreshAllData() async {
    if (_refreshing) return;
    setState(() => _refreshing = true);
    _spinController.repeat();
    var synced = false;
    try {
      if (AuthService.isConfigured && AuthService.isSignedIn) {
        await SyncService.fullSync(force: true);
        synced = true;
      }
    } catch (_) {
      synced = false;
    }

    try {
      ref.read(userStateProvider.notifier).reloadFromStorage();
      ref.read(outingProvider.notifier).reloadFromStorage();
      ref.read(model.transactionProvider.notifier).reloadFromStorage();
      ref.read(planProvider.notifier).reloadFromStorage();
      ref.read(detectionQueueProvider.notifier).refresh();
    } catch (_) {}

    if (mounted) {
      _spinController.stop();
      _spinController.reset();
      setState(() => _refreshing = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            synced
                ? 'All data synced & refreshed'
                : AuthService.isSignedIn
                ? 'Local data refreshed (sync pending)'
                : 'Local data refreshed',
          ),
          duration: const Duration(seconds: 2),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  String _formatIndian(int value) {
    final str = value.toString();
    if (str.length <= 3) return str;
    final lastThree = str.substring(str.length - 3);
    String remaining = str.substring(0, str.length - 3);
    final reg = RegExp(r'\B(?=(\d{2})+(?!\d))');
    remaining = remaining.replaceAllMapped(reg, (m) => '${m[0]},');
    return '$remaining,$lastThree';
  }

  Future<void> _exitOutingPrivacy() async {
    final ok = await PrivacyUnlockDialog.confirmDisable(context, ref);
    if (!ok || !mounted) return;
    await ref.read(outingPrivacyModeProvider.notifier).setEnabled(false);
  }

  String _getInitials(String name) {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return 'KT';
    final parts = trimmed.split(RegExp(r'\s+'));
    if (parts.length >= 2) {
      return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    }
    return trimmed.length >= 2
        ? trimmed.substring(0, 2).toUpperCase()
        : trimmed.toUpperCase();
  }

  @override
  Widget build(BuildContext context) {
    ref.listen<List<String>>(detectionQueueProvider, (previous, next) {
      final prevLen = previous?.length ?? 0;
      if (next.length > prevLen && next.isNotEmpty) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (!context.mounted) return;
          ref.read(detectionQueueProvider.notifier).refresh();
          PendingVerificationPresenter.processQueueIfNeeded(
            context: context,
            ref: ref,
          );
        });
      }
    });

    return ValueListenableBuilder<bool>(
      valueListenable: SyncService.firstSyncDone,
      builder: (context, syncDone, _) {
        if (!syncDone && SyncService.hasNoLocalCache) {
          return const _FirstSyncLoadingScreen();
        }
        return _buildHomeContent(context);
      },
    );
  }

  Widget _buildHomeContent(BuildContext context) {
    final t = context.tokens;
    final userState = ref.watch(userStateProvider);
    final emergency = ref.watch(emergencyFundProvider);
    final allTxs = ref.watch(model.transactionProvider);
    final outings = ref.watch(outingProvider);
    final isPrivate = ref.watch(privateModeProvider);
    final privacyActive = ref.watch(isOutingPrivacyActiveProvider);

    final fullName =
        userState.profileName.trim().isNotEmpty
            ? userState.profileName
            : 'there';
    final firstName = fullName.split(RegExp(r'\s+')).first;
    final initials = _getInitials(fullName);
    final hasUnread = ref.watch(hasUnreadNotificationsProvider);
    final pendingCount = ref.watch(detectionQueueProvider).length;

    final activeOuting =
        outings.where((o) => o.isActive && o.status != 'settled').firstOrNull;
    final privacyOuting =
        privacyActive ? ref.watch(activeOutingProvider) : null;
    final privacyActivity =
        privacyOuting == null
            ? const <dynamic>[]
            : outingRecentActivity(privacyOuting, allTxs);
    final privacyGross =
        privacyOuting == null ? 0.0 : outingGrossSpend(privacyOuting, allTxs);

    // Month-to-date totals. The index is rebuilt only when the ledger
    // list or the calendar day changes, not on every home rebuild.
    final monthIndex = LedgerMonthIndex.of(allTxs);
    final thisMonthIncome = monthIndex.mtdIncome;
    final thisMonthExpense = monthIndex.mtdExpense;
    final categoryColors = ref.watch(categoryProvider).colors;

    final double netSavedThisMonth = thisMonthIncome - thisMonthExpense;
    final double liquidBalance = emergency.liquidBalance;

    // Goals and investments are shown on the Wealth page only.

    // Monthly Plan / Budget Usage
    final plans = ref.watch(planProvider);
    final currentMonthKey = currentPlanMonth();
    // This month only. Personal wins when another purpose also has a plan.
    final activePlan = pickHomePlan(plans, currentMonthKey);

    final double budgetLimit = activePlan?.totalPlanned ?? 0.0;
    final planPurpose = activePlan?.purposeName ?? 'Personal';
    final planOutingLines = [
      for (final outing in outings)
        for (final expense in outing.expenses)
          PurposeOutingSpend(
            category: expense.category,
            amount: expense.amount,
            date: expense.date,
            purpose: expense.purpose,
            transactionId: expense.transactionId,
            isCancelled: outing.status == 'cancelled',
          ),
    ];
    final categoryBudgetSpend =
        activePlan == null
            ? const <String, double>{}
            : purposeCategorySpendTotals(
              transactions: allTxs,
              month: currentMonthKey,
              purposeName: planPurpose,
              excludedTransactionIds: {
                for (final line in planOutingLines)
                  if ((line.transactionId ?? '').trim().isNotEmpty)
                    line.transactionId!.trim(),
              },
            );
    final outingBudgetSpend =
        activePlan == null
            ? 0.0
            : purposeOutingTotal(
              transactions: allTxs,
              outings: planOutingLines,
              month: currentMonthKey,
              purposeName: planPurpose,
            );
    final double budgetSpent =
        categoryBudgetSpend.values.fold<double>(
          0,
          (sum, value) => sum + value,
        ) +
        outingBudgetSpend;
    final double budgetRemaining = (budgetLimit - budgetSpent).clamp(
      0.0,
      double.infinity,
    );
    final int budgetUsagePct =
        budgetLimit > 0 ? ((budgetSpent / budgetLimit) * 100).round() : 0;

    // Savings Report
    final double? planSavingTarget = activePlan?.savingsTarget;
    final bool hasSavingTarget =
        planSavingTarget != null && planSavingTarget > 0;
    final double savingTarget = hasSavingTarget ? planSavingTarget : 0.0;
    final double totalSaving = netSavedThisMonth;
    final int savingPct =
        savingTarget > 0
            ? ((totalSaving.clamp(0.0, double.infinity) / savingTarget) * 100)
                .clamp(0, 100)
                .round()
            : 0;

    final showingPrivacy = privacyOuting != null;
    final privacyTone = HomePrivacyTone(context);

    return TerminalWrapper(
      screenName: 'HomeScreen',
      child: Scaffold(
        backgroundColor: showingPrivacy ? privacyTone.canvas : t.background,
        body: SafeArea(
          top: true,
          bottom: false,
          child: RefreshIndicator(
            color: t.primary,
            backgroundColor: showingPrivacy ? privacyTone.card : t.card,
            onRefresh: _refreshAllData,
            child: CustomScrollView(
              physics: const AlwaysScrollableScrollPhysics(
                parent: BouncingScrollPhysics(),
              ),
              slivers: [
                const SliverToBoxAdapter(child: SizedBox(height: 6)),

                // Top Header Bar
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  sliver: SliverToBoxAdapter(
                    child:
                        showingPrivacy
                            ? HomePrivacyHeader(
                              greeting: 'Hello $firstName',
                              initials: initials,
                              hasUnread: hasUnread,
                              onNotifications:
                                  () => context.push('/notifications'),
                              onProfile:
                                  () => MainShellNavigation.openTab(context, 3),
                            )
                            : SoftAppHeader(
                              title: 'Hello $firstName 👋',
                              subtitle: 'Personal Wealth & Cashflow',
                              initials: initials,
                              hasUnread: hasUnread,
                              onNotifications:
                                  () => context.push('/notifications'),
                              onProfile:
                                  () => MainShellNavigation.openTab(context, 3),
                            ),
                  ),
                ),

                const SliverToBoxAdapter(child: SizedBox(height: 10)),

                if (!showingPrivacy) ...[
                  // Bento Hero Section (Liquid Balance / Wealth Carousel)
                  SliverPadding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    sliver: SliverToBoxAdapter(
                      child: HomeHeroCard(
                        liquidBalance: liquidBalance,
                        netSavedThisMonth: netSavedThisMonth,
                        isPrivate: isPrivate,
                        onPrivacyToggle: () {
                          ref.read(privateModeProvider.notifier).state =
                              !isPrivate;
                        },
                        formatIndian: _formatIndian,
                      ),
                    ),
                  ),
                  if (pendingCount > 0) ...[
                    const SliverToBoxAdapter(child: SizedBox(height: 10)),
                    SliverPadding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      sliver: SliverToBoxAdapter(
                        child: HomeSmsBanner(count: pendingCount),
                      ),
                    ),
                  ],
                  const SliverToBoxAdapter(child: SizedBox(height: 10)),
                ],

                // Main Body Content
                SliverPadding(
                  padding: EdgeInsets.fromLTRB(
                    16,
                    0,
                    16,
                    _bottomClearance + MediaQuery.of(context).padding.bottom,
                  ),
                  sliver: SliverList(
                    delegate: SliverChildListDelegate([
                      if (privacyOuting != null) ...[
                        HomeOutingPrivacyBody(
                          outing: privacyOuting,
                          activity: privacyActivity,
                          gross: privacyGross,
                          formatIndian: _formatIndian,
                          onExitPrivacy: _exitOutingPrivacy,
                        ),
                      ] else ...[
                        // 1. Monthly Plan — illustration only when none exists.
                        if (activePlan == null)
                          const HomeEmptyMonthlyPlan()
                        else
                          HomeMonthlyBudgetCard(
                            remaining: budgetRemaining,
                            spent: budgetSpent,
                            limit: budgetLimit,
                            usagePct: budgetUsagePct,
                            purposeLabel:
                                (activePlan.purposeName ?? '').trim().isEmpty
                                    ? 'Personal'
                                    : activePlan.purposeName!.trim(),
                            formatIndian: _formatIndian,
                          ),

                        if (hasSavingTarget) ...[
                          const SizedBox(height: 12),
                          HomeSavingReportCard(
                            profileName: firstName,
                            totalSaving: totalSaving,
                            savingTarget: savingTarget,
                            savingPct: savingPct,
                            formatIndian: _formatIndian,
                          ),
                        ],

                        if (activeOuting != null) ...[
                          const SizedBox(height: 12),
                          HomeActiveOutingCard(
                            outing: activeOuting,
                            formatIndian: _formatIndian,
                          ),
                        ],

                        const SizedBox(height: 12),

                        // 4. Recent Transactions Section
                        HomeRecentTransactionsSection(
                          allTxs: allTxs,
                          outings: outings,
                          isPrivate: isPrivate,
                          formatIndian: _formatIndian,
                          categoryColors: categoryColors,
                        ),
                      ],
                    ]),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _FirstSyncLoadingScreen extends StatefulWidget {
  const _FirstSyncLoadingScreen();

  @override
  State<_FirstSyncLoadingScreen> createState() =>
      _FirstSyncLoadingScreenState();
}

class _FirstSyncLoadingScreenState extends State<_FirstSyncLoadingScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulseCtrl;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = isDark ? const Color(0xFF0F172A) : const Color(0xFFF8FAFC);
    final textPrimary = isDark ? Colors.white : const Color(0xFF0F172A);
    final textSecondary =
        isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

    return Scaffold(
      backgroundColor: bg,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              AnimatedBuilder(
                animation: _pulseCtrl,
                builder: (context, child) {
                  final scale = 1.0 + (_pulseCtrl.value * 0.08);
                  final opacity = 0.4 + (_pulseCtrl.value * 0.6);
                  return Transform.scale(
                    scale: scale,
                    child: Container(
                      width: 84,
                      height: 84,
                      decoration: BoxDecoration(
                        color: const Color(0xFF10B981).withValues(alpha: 0.15),
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: const Color(
                              0xFF10B981,
                            ).withValues(alpha: 0.25 * opacity),
                            blurRadius: 28,
                            spreadRadius: 4,
                          ),
                        ],
                      ),
                      child: const Center(
                        child: Icon(
                          Icons.sync_rounded,
                          size: 42,
                          color: Color(0xFF10B981),
                        ),
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(height: 32),
              Text(
                'Setting up your workspace',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                  color: textPrimary,
                  letterSpacing: -0.4,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Restoring your accounts, budgets, and transactions...',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                  color: textSecondary,
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 32),
              SizedBox(
                width: 140,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: const LinearProgressIndicator(
                    backgroundColor: Color(0x2010B981),
                    valueColor: AlwaysStoppedAnimation<Color>(
                      Color(0xFF10B981),
                    ),
                    minHeight: 4,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
