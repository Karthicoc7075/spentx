import 'package:flutter/material.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../core/theme/spentx_tokens.dart';
import '../../../core/navigation/main_shell_navigation.dart';
import '../../../core/navigation/soft_bottom_nav.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/widgets/premium_bottom_sheet.dart';
import '../../../core/providers/transaction_provider.dart' as model;
import '../../../core/providers/outing_provider.dart';
import '../../../core/providers/settlement_feedback_provider.dart';
import '../../../core/services/notification_permission_service.dart';
import '../../../core/services/notification_history_service.dart';
import '../../../core/services/plan_alert_service.dart';
import '../../../core/services/pending_verification_bootstrap.dart';
import '../../sms/sms_notification.dart';
import '../../sms/detected/detection_queue.dart';
import '../../sms/detected/pending_verification_presenter.dart';
import '../../transactions/presentation/add_transaction_sheet.dart';
import '../../transactions/presentation/transactions_screen.dart';
import '../../analytics/presentation/analytics_screen.dart';
import '../../settings/presentation/settings_screen.dart';
import 'home_screen.dart';

class MainWrapper extends ConsumerStatefulWidget {
  const MainWrapper({super.key});

  @override
  ConsumerState<MainWrapper> createState() => _MainWrapperState();
}

class _MainWrapperState extends ConsumerState<MainWrapper>
    with WidgetsBindingObserver {
  int _currentIndex = 0;
  bool _didRunInitialPendingCheck = false;

  late final _screens = [
    HomeScreen(key: homeScreenKey),
    const TransactionsScreen(),
    const AnalyticsScreen(),
    const SettingsScreen(),
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    MainShellNavigation.pendingTab.addListener(_onPendingShellTab);
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      SmsNotificationService.cancelAllNotifications();
      ref.read(outingProvider.notifier).expireEndedOutings();
      _checkFirstTimePermission();
      _runInitialPendingVerification();
      _checkPlanAlerts();
      _consumePendingShellTab();
    });
  }

  void _onPendingShellTab() => _consumePendingShellTab();

  void _consumePendingShellTab() {
    final tab = MainShellNavigation.pendingTab.value;
    if (tab == null || !mounted) return;
    MainShellNavigation.pendingTab.value = null;
    if (_currentIndex != tab) {
      setState(() => _currentIndex = tab);
    }
  }

  @override
  void dispose() {
    MainShellNavigation.pendingTab.removeListener(_onPendingShellTab);
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      SmsNotificationService.cancelAllNotifications();
      // Start date → active, end date passed → auto-completed.
      ref.read(outingProvider.notifier).expireEndedOutings(silent: true);
      _drainPendingAndShowVerify();
    }
  }

  Future<void> _drainPendingAndShowVerify() async {
    if (!mounted) return;
    // Reload Hive only — do not invalidate (recreates notifiers, janks low-end).
    ref.read(model.transactionProvider.notifier).reloadFromStorage();
    await PendingVerificationBootstrap.afterUnlock(context: context, ref: ref);
  }

  Future<void> _runInitialPendingVerification() async {
    if (_didRunInitialPendingCheck || !mounted) return;
    _didRunInitialPendingCheck = true;

    await Future.delayed(const Duration(milliseconds: 320));
    if (!mounted) return;

    await PendingVerificationBootstrap.processStartupAndShowIfNeeded(
      ref: ref,
      context: context,
    );
  }

  void _checkPlanAlerts() {
    PlanAlertService.check(
      transactions: ref.read(model.transactionProvider),
    ).whenComplete(() {
      if (!mounted) return;
      ref.invalidate(notificationHistoryProvider);
    });
  }

  Future<void> _checkFirstTimePermission() async {
    final prefs = await SharedPreferences.getInstance();
    final hasPrompted =
        prefs.getBool('has_prompted_notification_permission') ?? false;

    if (!hasPrompted) {
      final isEnabled =
          await NotificationPermissionService.isNotificationListenerEnabled();
      if (!isEnabled && mounted) {
        PremiumBottomSheet.show(
          context: context,
          child: const _PermissionPromptSheet(),
        );
        await prefs.setBool('has_prompted_notification_permission', true);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    ref.listen<bool>(openPendingVerificationOnHomeProvider, (previous, next) {
      if (next == true) {
        ref.read(openPendingVerificationOnHomeProvider.notifier).state = false;
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (!mounted || PendingVerificationPresenter.popupAlreadyOpen) return;
          ref.read(detectionQueueProvider.notifier).refresh();
          final targetTx = ref.read(openPendingVerificationForTxProvider);
          ref.read(openPendingVerificationForTxProvider.notifier).state = null;
          PendingVerificationPresenter.processQueueIfNeeded(
            context: context,
            ref: ref,
            targetTransactionId: targetTx,
          );
        });
      }
    });

    ref.listen<String?>(openPendingVerificationForTxProvider, (previous, next) {
      if (next != null && next.isNotEmpty) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (!mounted || PendingVerificationPresenter.popupAlreadyOpen) return;
          ref.read(detectionQueueProvider.notifier).prioritize(next);
          final txId = next;
          ref.read(openPendingVerificationForTxProvider.notifier).state = null;
          PendingVerificationPresenter.processQueueIfNeeded(
            context: context,
            ref: ref,
            targetTransactionId: txId,
          );
        });
      }
    });

    ref.listen<String?>(settlementFeedbackProvider, (prev, next) {
      if (next != null && next.isNotEmpty) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(next),
              backgroundColor: AppColors.income,
              behavior: SnackBarBehavior.floating,
              duration: const Duration(seconds: 4),
            ),
          );
          ref.read(settlementFeedbackProvider.notifier).state = null;
        });
      }
    });

    return Scaffold(
      body: IndexedStack(index: _currentIndex, children: _screens),
      bottomNavigationBar: SoftBottomNav(
        currentIndex: _currentIndex,
        onChanged: (index) => setState(() => _currentIndex = index),
        onAdd: () => AddTransactionSheet.show(context),
        settingsSelected: _currentIndex == 3,
      ),
    );
  }
}

class _PermissionPromptSheet extends StatelessWidget {
  const _PermissionPromptSheet();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AppColors.primary.withValues(alpha: 0.15),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              LucideIcons.bellRing,
              color: AppColors.primary,
              size: 36,
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'Enable Auto-Detection',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.w500),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 12),
          Text(
            'SpentX can automatically detect your expenses from App Notifications without needing SMS permissions.\n\nWould you like to enable this to save time?',
            style: TextStyle(
              fontSize: 14,
              color: context.tokens.textSecondary,
              height: 1.5,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 32),
          SizedBox(
            width: double.infinity,
            height: 54,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: SoftColors.control,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                elevation: 0,
              ),
              onPressed: () async {
                Navigator.pop(context);
                await NotificationPermissionService.openNotificationListenerSettings();
              },
              child: const Text(
                'Allow Permission',
                style: TextStyle(fontWeight: FontWeight.w500, fontSize: 16),
              ),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            height: 54,
            child: TextButton(
              style: TextButton.styleFrom(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text(
                'Maybe Later',
                style: TextStyle(
                  color: context.tokens.textSecondary,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
