import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../../../core/sync/sync_service.dart';

/// Masks sensitive money on home (net worth, Personal, Family, account balances).
final privateModeProvider = StateProvider<bool>((ref) {
  return Hive.box('settings').get('private_mode', defaultValue: false) == true;
});

class PrivateModeService {
  static const mask = '*****';

  static Future<void> setEnabled(bool value) async {
    await Hive.box('settings').put('private_mode', value);
    // Genuinely-shared setting → syncs to the users row (Hive-first, queued).
    SyncService.queueUserSettings({'private_mode': value});
  }

  static String money(String formatted, {required bool isPrivate}) {
    if (!isPrivate) return formatted;
    return mask;
  }

  static bool shouldMaskPurpose(String purpose, bool isPrivate) {
    if (!isPrivate) return false;
    final p = purpose.toLowerCase();
    return p == 'personal' || p == 'family';
  }
}