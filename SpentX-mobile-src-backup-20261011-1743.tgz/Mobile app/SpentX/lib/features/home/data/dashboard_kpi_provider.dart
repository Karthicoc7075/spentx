import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:lucide_icons/lucide_icons.dart';

enum DashboardKpiKey {
  netWorth('net-worth', 'Net Worth', LucideIcons.wallet),
  income('total-income', 'Income', LucideIcons.trendingUp),
  expense('total-expense', 'Expense', LucideIcons.trendingDown),
  savings('net-savings', 'Savings', LucideIcons.piggyBank),
  cash('cash-in-hand', 'Cash', LucideIcons.banknote),
  bank('bank-balance', 'Bank', LucideIcons.building2),
  investment('investment-value', 'Investment', LucideIcons.lineChart);

  final String id;
  final String label;
  final IconData icon;

  const DashboardKpiKey(this.id, this.label, this.icon);

  static DashboardKpiKey fromId(String id) {
    return DashboardKpiKey.values.firstWhere(
      (k) => k.id == id,
      orElse: () => DashboardKpiKey.netWorth,
    );
  }
}

class DashboardKpiConfig {
  final List<DashboardKpiKey> activeKeys;

  const DashboardKpiConfig({required this.activeKeys});

  static const List<DashboardKpiKey> defaultKeys = [
    DashboardKpiKey.netWorth,
    DashboardKpiKey.income,
    DashboardKpiKey.expense,
    DashboardKpiKey.savings,
    DashboardKpiKey.cash,
    DashboardKpiKey.bank,
    DashboardKpiKey.investment,
  ];

  DashboardKpiConfig copyWith({List<DashboardKpiKey>? activeKeys}) {
    return DashboardKpiConfig(activeKeys: activeKeys ?? this.activeKeys);
  }
}

class DashboardKpiNotifier extends StateNotifier<DashboardKpiConfig> {
  static const _boxName = 'settings';
  static const _storageKey = 'dashboard_kpi_keys';

  DashboardKpiNotifier()
      : super(const DashboardKpiConfig(activeKeys: DashboardKpiConfig.defaultKeys)) {
    _load();
  }

  void reloadFromStorage() => _load();

  void _load() {
    try {
      if (!Hive.isBoxOpen(_boxName)) return;
      final raw = Hive.box(_boxName).get(_storageKey);
      if (raw is! List) {
        state = const DashboardKpiConfig(activeKeys: DashboardKpiConfig.defaultKeys);
        return;
      }
      final loaded = raw
          .map((e) => DashboardKpiKey.values.where((k) => k.id == e.toString()).firstOrNull)
          .whereType<DashboardKpiKey>()
          .toList();
      state = DashboardKpiConfig(
        activeKeys: loaded.isNotEmpty ? loaded : DashboardKpiConfig.defaultKeys,
      );
    } catch (_) {}
  }

  void updateKeys(List<DashboardKpiKey> keys) {
    if (keys.isEmpty) return;
    state = state.copyWith(activeKeys: keys);
    _persist();
  }

  void resetToDefault() {
    state = const DashboardKpiConfig(activeKeys: DashboardKpiConfig.defaultKeys);
    _persist();
  }

  void _persist() {
    try {
      if (!Hive.isBoxOpen(_boxName)) return;
      Hive.box(_boxName).put(
        _storageKey,
        state.activeKeys.map((k) => k.id).toList(),
      );
    } catch (_) {}
  }
}

final dashboardKpiProvider =
    StateNotifierProvider<DashboardKpiNotifier, DashboardKpiConfig>(
  (ref) => DashboardKpiNotifier(),
);

enum DashboardDatePreset {
  last7Days('7d', 'Last 7 Days'),
  thisMonth('This Month', 'This Month'),
  lastMonth('Last Month', 'Last Month'),
  customMonth('Custom', 'Custom Month'),
  last3Months('3m', 'Last 3 Months'),
  last6Months('6m', 'Last 6 Months'),
  last12Months('12m', 'Last 12 Months');

  final String chipLabel;
  final String fullLabel;

  const DashboardDatePreset(this.chipLabel, this.fullLabel);
}

class DashboardDateFilterHelper {
  static DateTimeRange getDateRange(
    DashboardDatePreset preset, {
    DateTime? customMonth,
  }) {
    final now = DateTime.now();

    switch (preset) {
      case DashboardDatePreset.last7Days:
        final start = DateTime(now.year, now.month, now.day - 6);
        final end = DateTime(now.year, now.month, now.day, 23, 59, 59);
        return DateTimeRange(start: start, end: end);

      case DashboardDatePreset.thisMonth:
        final start = DateTime(now.year, now.month, 1);
        final end = DateTime(now.year, now.month + 1, 0, 23, 59, 59);
        return DateTimeRange(start: start, end: end);

      case DashboardDatePreset.lastMonth:
        final start = DateTime(now.year, now.month - 1, 1);
        final end = DateTime(now.year, now.month, 0, 23, 59, 59);
        return DateTimeRange(start: start, end: end);

      case DashboardDatePreset.customMonth:
        final target = customMonth ?? now;
        final start = DateTime(target.year, target.month, 1);
        final end = DateTime(target.year, target.month + 1, 0, 23, 59, 59);
        return DateTimeRange(start: start, end: end);

      case DashboardDatePreset.last3Months:
        final start = DateTime(now.year, now.month - 2, 1);
        final end = DateTime(now.year, now.month + 1, 0, 23, 59, 59);
        return DateTimeRange(start: start, end: end);

      case DashboardDatePreset.last6Months:
        final start = DateTime(now.year, now.month - 5, 1);
        final end = DateTime(now.year, now.month + 1, 0, 23, 59, 59);
        return DateTimeRange(start: start, end: end);

      case DashboardDatePreset.last12Months:
        final start = DateTime(now.year, now.month - 11, 1);
        final end = DateTime(now.year, now.month + 1, 0, 23, 59, 59);
        return DateTimeRange(start: start, end: end);
    }
  }
}
