/// Home shell data markers — providers stay in core during migration.
///
/// Screens under presentation/ still read core providers; move them here
/// feature-by-feature in later runs.
library;
