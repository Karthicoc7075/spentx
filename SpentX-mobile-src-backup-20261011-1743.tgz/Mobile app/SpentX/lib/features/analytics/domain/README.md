# analytics domain — migrate KPI / chart entities here
