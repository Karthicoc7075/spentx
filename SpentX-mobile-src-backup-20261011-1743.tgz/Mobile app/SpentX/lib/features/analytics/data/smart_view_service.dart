import 'dart:developer' as dev;
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../../../core/services/auth_service.dart';
import '../../../../models/smart_view_model.dart';

class SmartViewService {
  static SupabaseClient get _db => Supabase.instance.client;

  static Future<List<SmartViewModel>> fetchSmartViews() async {
    final userId = AuthService.currentUserId;
    if (userId == null || userId.isEmpty) return [];

    try {
      final rows = await _db
          .from('smart_views')
          .select('*')
          .eq('user_id', userId)
          .order('created_at', ascending: true);

      return (rows as List<dynamic>)
          .cast<Map<String, dynamic>>()
          .where((r) => r['deleted_at'] == null) // soft-deleted
          .map(SmartViewModel.fromMap)
          .toList();
    } catch (e, stack) {
      dev.log('Error fetching smart views: $e', stackTrace: stack);
      return [];
    }
  }

  static Future<SmartViewModel> saveSmartView({
    String? id,
    required String name,
    String? accountId,
    String? purposeId,
    List<String> categoryIds = const [],
    String? contributorId,
  }) async {
    final userId = AuthService.currentUserId;
    if (userId == null || userId.isEmpty) {
      throw Exception('Sign in before saving Smart Views.');
    }

    final payload = <String, dynamic>{
      'user_id': userId,
      'name': name,
      'account_id': accountId,
      'purpose_id': purposeId,
      'category_ids': categoryIds,
      'contributor_id': contributorId,
    };
    if (id != null && id.isNotEmpty) {
      payload['id'] = id;
    }

    final res =
        await _db.from('smart_views').upsert(payload).select('*').single();

    return SmartViewModel.fromMap(res);
  }

  static Future<void> deleteSmartView(String id) async {
    final userId = AuthService.currentUserId;
    if (userId == null || userId.isEmpty) return;

    // Soft delete (deleted_at, migration 20261011_security_audit_fixes);
    // hard delete only if that column does not exist yet.
    try {
      await _db
          .from('smart_views')
          .update({'deleted_at': DateTime.now().toUtc().toIso8601String()})
          .eq('user_id', userId)
          .eq('id', id);
    } on PostgrestException catch (e) {
      final missing =
          e.code == '42703' ||
          e.code == 'PGRST204' ||
          e.message.contains('deleted_at');
      if (!missing) rethrow;
      await _db.from('smart_views').delete().eq('user_id', userId).eq('id', id);
    }
  }
}
