import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../core/theme/soft_palette.dart';
import '../../../core/widgets/category_icon.dart';

/// Soft Soft analytics surfaces. Light tokens follow the Analytics spec.
/// Dark mode keeps [SoftPalette] dark surfaces.
abstract final class AnalyticsSoft {
  static bool dark(BuildContext context) =>
      Theme.of(context).brightness == Brightness.dark;

  static const emerald = Color(0xFF10B981);
  static const emeraldDeep = Color(0xFF059669);
  static const rose = Color(0xFFFB7185);
  static const amber = Color(0xFFF59E0B);
  static const teal = Color(0xFF14B8A6);
  static const indigo = Color(0xFF6366F1);

  static const _shadow = [
    BoxShadow(
      color: Color.fromRGBO(0, 0, 0, 0.03),
      offset: Offset(0, 8),
      blurRadius: 30,
    ),
  ];

  static Color canvas(BuildContext context) =>
      dark(context) ? SoftPalette.darkBg : const Color(0xFFF8FAF9);

  static Color card(BuildContext context) =>
      dark(context) ? SoftPalette.darkCard : const Color(0xFFFFFFFF);

  static Color border(BuildContext context) =>
      dark(context) ? SoftPalette.darkBorder : const Color(0xFFF1F5F9);

  static Color ink(BuildContext context) =>
      dark(context) ? SoftPalette.darkInk : const Color(0xFF0F172A);

  static Color slate(BuildContext context) =>
      dark(context) ? SoftPalette.darkMuted : const Color(0xFF475569);

  static Color muted(BuildContext context) =>
      dark(context) ? SoftPalette.darkFaint : const Color(0xFF94A3B8);

  static Color mint(BuildContext context) =>
      dark(context) ? SoftPalette.darkEmeraldSoft : const Color(0xFFECFDF5);

  static Color mintMid(BuildContext context) =>
      dark(context) ? const Color(0xFF064E3B) : const Color(0xFFD1FAE5);

  static Color slate50(BuildContext context) =>
      dark(context) ? SoftPalette.darkSurfaceVariant : const Color(0xFFF8FAFC);

  static Color slate100(BuildContext context) =>
      dark(context) ? SoftPalette.darkBorder : const Color(0xFFF1F5F9);

  static Color track(BuildContext context) =>
      dark(context) ? SoftPalette.darkBorder : const Color(0xFFF1F5F9);

  static List<BoxShadow>? shadow(BuildContext context) =>
      dark(context) ? null : _shadow;

  static TextStyle text(
    BuildContext context,
    double size,
    FontWeight weight,
    Color color, {
    double? letterSpacing,
    double? height,
  }) {
    return GoogleFonts.plusJakartaSans(
      fontSize: size,
      fontWeight: weight,
      color: color,
      letterSpacing: letterSpacing,
      height: height,
    );
  }

  static BoxDecoration cardBox(BuildContext context) {
    return BoxDecoration(
      color: card(context),
      borderRadius: BorderRadius.circular(24),
      border: Border.all(color: border(context)),
      boxShadow: shadow(context),
    );
  }

  /// Stored category hex when present. Otherwise the type color used on
  /// activity rows: expense rose, income emerald, transfer blue.
  static Color category({
    String? storedHex,
    bool isExpense = true,
    bool isTransfer = false,
  }) {
    return CategoryToneLookup.resolve(
      storedHex: storedHex,
      isExpense: isExpense,
      isTransfer: isTransfer,
    ).fg;
  }

  static Color purpose(String name, int index) {
    switch (name.toLowerCase()) {
      case 'personal':
        return emerald;
      case 'family':
        return teal;
      case 'work':
        return indigo;
      case 'other':
        return const Color(0xFF94A3B8);
    }
    const fallback = <Color>[emerald, teal, indigo, Color(0xFF94A3B8)];
    return fallback[index % fallback.length];
  }
}

class AnalyticsSoftCard extends StatelessWidget {
  const AnalyticsSoftCard({super.key, required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: AnalyticsSoft.cardBox(context),
      child: child,
    );
  }
}
