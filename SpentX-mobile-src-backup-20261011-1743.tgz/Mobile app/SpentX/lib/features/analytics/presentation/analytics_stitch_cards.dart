import 'dart:math' as math;

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../core/providers/plan_provider.dart';
import '../../../core/providers/category_provider.dart';
import '../../../core/providers/private_mode_provider.dart';
import '../../../core/providers/transaction_provider.dart' as model;
import 'soft_analytics_widgets.dart';
import '../../../core/utils/reimbursement.dart';
import '../../../core/utils/transaction_display_utils.dart';
import '../../../core/widgets/category_icon.dart';
import '../../../core/providers/outing_provider.dart';

/// Soft-minimalist analytics cards matching
/// design_refs/.../spentx_analytics_soft_minimalist.
/// Business totals come from callers — these widgets only reshape presentation.

String _fmtInr(double v, {bool compact = false}) {
  if (compact && v.abs() >= 1000) {
    final k = v / 1000;
    final s =
        k == k.roundToDouble() ? k.toStringAsFixed(0) : k.toStringAsFixed(1);
    return '₹${s}k';
  }
  return NumberFormat.currency(
    symbol: '₹',
    decimalDigits: 0,
    locale: 'en_IN',
  ).format(v);
}

List<model.Transaction> _expenseOnly(List<model.Transaction> txs) =>
    txs.where((t) => t.isExpense && !t.isFriendReturn).toList();

// ── Spending Trend (line + peak tooltip) ──────────────────────────────────

class AnalyticsSpendingTrendCard extends StatefulWidget {
  /// Period-filtered txs (Daily).
  final List<model.Transaction> txs;

  /// Broader history for Weekly/Monthly buckets.
  final List<model.Transaction> historyTxs;
  final int timeRange;

  const AnalyticsSpendingTrendCard({
    super.key,
    required this.txs,
    required this.historyTxs,
    required this.timeRange,
  });

  @override
  State<AnalyticsSpendingTrendCard> createState() =>
      _AnalyticsSpendingTrendCardState();
}

class _AnalyticsSpendingTrendCardState
    extends State<AnalyticsSpendingTrendCard> {
  /// 0 day · 1 week · 2 month. Week is the default.
  int _view = 1;

  @override
  Widget build(BuildContext context) {
    final points = _buildPoints();
    final peakIdx =
        points.isEmpty
            ? -1
            : points
                .asMap()
                .entries
                .reduce((a, b) => a.value.value >= b.value.value ? a : b)
                .key;
    final avg =
        points.isEmpty
            ? 0.0
            : points.fold<double>(0, (s, p) => s + p.value) / points.length;
    final peak = peakIdx >= 0 ? points[peakIdx] : null;
    final avgLabel =
        _view == 0
            ? (_anchorIsToday ? 'Hourly average' : 'Daily average')
            : (_view == 1 ? 'Daily average' : 'Weekly average');
    final sub = _subtitle();

    return AnalyticsSoftCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Spending Trend',
                      style: AnalyticsSoft.text(
                        context,
                        14,
                        FontWeight.w700,
                        AnalyticsSoft.ink(context),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      sub,
                      style: AnalyticsSoft.text(
                        context,
                        12,
                        FontWeight.w500,
                        AnalyticsSoft.muted(context),
                      ),
                    ),
                  ],
                ),
              ),
              _TrendGranularityTabs(
                current: _view,
                onChanged: (v) => setState(() => _view = v),
              ),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 168,
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                LineChart(_lineData(context, points, peakIdx)),
                if (peak != null && peak.value > 0)
                  _PeakTooltipOverlay(
                    label: '${peak.label}: ${_fmtInr(peak.value)}',
                    index: peakIdx,
                    count: points.length,
                  ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: AnalyticsSoft.slate50(context),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        avgLabel,
                        style: AnalyticsSoft.text(
                          context,
                          11,
                          FontWeight.w500,
                          AnalyticsSoft.muted(context),
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        _fmtInr(avg),
                        style: AnalyticsSoft.text(
                          context,
                          13,
                          FontWeight.w700,
                          AnalyticsSoft.ink(context),
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        'Highest spending',
                        style: AnalyticsSoft.text(
                          context,
                          11,
                          FontWeight.w500,
                          AnalyticsSoft.muted(context),
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text.rich(
                        TextSpan(
                          children: [
                            TextSpan(
                              text:
                                  peak == null || peak.value <= 0
                                      ? '—'
                                      : _fmtInr(peak.value),
                              style: AnalyticsSoft.text(
                                context,
                                13,
                                FontWeight.w700,
                                AnalyticsSoft.ink(context),
                              ),
                            ),
                            if (peak != null && peak.value > 0)
                              TextSpan(
                                text: ' (${peak.label})',
                                style: AnalyticsSoft.text(
                                  context,
                                  11,
                                  FontWeight.w500,
                                  AnalyticsSoft.muted(context),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  bool get _anchorIsToday {
    final now = DateTime.now();
    final anchor = _anchorDay();
    return anchor.year == now.year &&
        anchor.month == now.month &&
        anchor.day == now.day;
  }

  DateTime _anchorDay() {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    if (widget.timeRange == 0) return today;
    final expenses = _expenseOnly(widget.txs);
    if (expenses.isEmpty) {
      if (widget.timeRange == 1) {
        final last = DateTime(now.year, now.month, 0);
        return DateTime(last.year, last.month, last.day);
      }
      return today;
    }
    var latest = expenses.first.date;
    for (final tx in expenses) {
      if (tx.date.isAfter(latest)) latest = tx.date;
    }
    return DateTime(latest.year, latest.month, latest.day);
  }

  String _subtitle() {
    final anchor = _anchorDay();
    if (_view == 0) {
      return _anchorIsToday
          ? 'Hourly spending today'
          : 'Day by day in ${DateFormat('MMMM').format(anchor)}';
    }
    if (_view == 1) {
      return _anchorIsToday
          ? 'Monday to Sunday this week'
          : 'Monday to Sunday of ${DateFormat('d MMM').format(anchor)}';
    }
    if (widget.timeRange == 2) return 'Week by week across 3 months';
    return 'Week by week in ${DateFormat('MMMM').format(anchor)}';
  }

  List<_TrendPoint> _buildPoints() {
    final expenses = _expenseOnly(widget.historyTxs);
    final anchor = _anchorDay();
    if (_view == 0 && _anchorIsToday) {
      return List.generate(24, (hour) {
        final sum = expenses
            .where(
              (t) =>
                  t.date.year == anchor.year &&
                  t.date.month == anchor.month &&
                  t.date.day == anchor.day &&
                  t.date.hour == hour,
            )
            .fold<double>(0, (s, t) => s + t.amount);
        final label =
            hour == 0
                ? '12a'
                : hour < 12
                ? '${hour}a'
                : hour == 12
                ? '12p'
                : '${hour - 12}p';
        return _TrendPoint(label, sum);
      });
    }
    if (_view == 0) {
      final start = DateTime(anchor.year, anchor.month, 1);
      final end = DateTime(anchor.year, anchor.month + 1, 1);
      final points = <_TrendPoint>[];
      for (
        var day = start;
        day.isBefore(end);
        day = day.add(const Duration(days: 1))
      ) {
        final sum = expenses
            .where(
              (t) =>
                  t.date.year == day.year &&
                  t.date.month == day.month &&
                  t.date.day == day.day,
            )
            .fold<double>(0, (s, t) => s + t.amount);
        points.add(_TrendPoint(DateFormat('d').format(day), sum));
      }
      return points;
    }
    if (_view == 1) {
      final start = anchor.subtract(Duration(days: anchor.weekday - 1));
      return List.generate(7, (i) {
        final day = start.add(Duration(days: i));
        final sum = expenses
            .where(
              (t) =>
                  t.date.year == day.year &&
                  t.date.month == day.month &&
                  t.date.day == day.day,
            )
            .fold<double>(0, (s, t) => s + t.amount);
        return _TrendPoint(DateFormat('EEE').format(day), sum);
      });
    }
    final now = DateTime.now();
    final monthStart =
        widget.timeRange == 2
            ? DateTime(now.year, now.month - 2, 1)
            : DateTime(anchor.year, anchor.month, 1);
    final monthEnd =
        widget.timeRange == 2
            ? DateTime(now.year, now.month + 1, 1)
            : DateTime(anchor.year, anchor.month + 1, 1);
    final points = <_TrendPoint>[];
    var cursor = monthStart;
    var week = 1;
    while (cursor.isBefore(monthEnd)) {
      final next = cursor.add(const Duration(days: 7));
      final end = next.isAfter(monthEnd) ? monthEnd : next;
      final sum = expenses
          .where((t) => !t.date.isBefore(cursor) && t.date.isBefore(end))
          .fold<double>(0, (s, t) => s + t.amount);
      points.add(_TrendPoint('W$week', sum));
      cursor = end;
      week++;
    }
    return points;
  }

  LineChartData _lineData(
    BuildContext context,
    List<_TrendPoint> points,
    int peakIdx,
  ) {
    final maxY = points.fold<double>(0, (m, p) => math.max(m, p.value));
    final pad = math.max(maxY * 0.18, 1.0);
    return LineChartData(
      minY: 0,
      maxY: maxY + pad,
      gridData: const FlGridData(show: false),
      borderData: FlBorderData(show: false),
      titlesData: FlTitlesData(
        topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        rightTitles: const AxisTitles(
          sideTitles: SideTitles(showTitles: false),
        ),
        leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        bottomTitles: AxisTitles(
          sideTitles: SideTitles(
            showTitles: true,
            reservedSize: 22,
            interval: 1,
            getTitlesWidget: (value, meta) {
              final i = value.toInt();
              if (i < 0 || i >= points.length) return const SizedBox.shrink();
              final isPeak = i == peakIdx && points[i].value > 0;
              final show = isPeak || points.length <= 7 || i % 6 == 0;
              if (!show) return const SizedBox.shrink();
              final label = points[i].label;
              if (isPeak) {
                return Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 6,
                      vertical: 2,
                    ),
                    decoration: BoxDecoration(
                      color: AnalyticsSoft.mint(context),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      label,
                      style: AnalyticsSoft.text(
                        context,
                        10,
                        FontWeight.w700,
                        AnalyticsSoft.emeraldDeep,
                      ),
                    ),
                  ),
                );
              }
              return Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(
                  label,
                  style: AnalyticsSoft.text(
                    context,
                    10,
                    FontWeight.w500,
                    AnalyticsSoft.muted(context),
                  ),
                ),
              );
            },
          ),
        ),
      ),
      lineTouchData: LineTouchData(
        enabled: true,
        handleBuiltInTouches: true,
        touchTooltipData: LineTouchTooltipData(
          getTooltipColor: (_) => AnalyticsSoft.ink(context),
          tooltipBorderRadius: BorderRadius.circular(999),
          tooltipPadding: const EdgeInsets.symmetric(
            horizontal: 10,
            vertical: 6,
          ),
          getTooltipItems:
              (spots) =>
                  spots.map((s) {
                    final i = s.x.toInt().clamp(0, points.length - 1);
                    return LineTooltipItem(
                      '${points[i].label}: ${_fmtInr(s.y)}',
                      AnalyticsSoft.text(
                        context,
                        11,
                        FontWeight.w600,
                        Colors.white,
                      ),
                    );
                  }).toList(),
        ),
      ),
      lineBarsData: [
        LineChartBarData(
          spots: [
            for (var i = 0; i < points.length; i++)
              FlSpot(i.toDouble(), points[i].value),
          ],
          isCurved: true,
          curveSmoothness: 0.35,
          color: AnalyticsSoft.emerald,
          barWidth: 2.5,
          isStrokeCapRound: true,
          dotData: FlDotData(
            show: true,
            checkToShowDot:
                (spot, _) => spot.x.toInt() == peakIdx && spot.y > 0,
            getDotPainter:
                (spot, percent, bar, index) => FlDotCirclePainter(
                  radius: 5,
                  color: AnalyticsSoft.emerald,
                  strokeWidth: 2.5,
                  strokeColor: AnalyticsSoft.card(context),
                ),
          ),
          belowBarData: BarAreaData(
            show: true,
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                AnalyticsSoft.emerald.withValues(alpha: 0.22),
                AnalyticsSoft.emerald.withValues(alpha: 0.0),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _TrendPoint {
  final String label;
  final double value;
  const _TrendPoint(this.label, this.value);
}

class _TrendGranularityTabs extends StatelessWidget {
  final int current;
  final ValueChanged<int> onChanged;
  const _TrendGranularityTabs({required this.current, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    const labels = ['Day', 'Week', 'Month'];
    return Container(
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        color: AnalyticsSoft.slate100(context),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: List.generate(3, (i) {
          final selected = current == i;
          return GestureDetector(
            onTap: () => onChanged(i),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 160),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color:
                    selected ? AnalyticsSoft.card(context) : Colors.transparent,
                borderRadius: BorderRadius.circular(9),
                boxShadow: selected ? AnalyticsSoft.shadow(context) : null,
              ),
              child: Text(
                labels[i],
                style: AnalyticsSoft.text(
                  context,
                  11,
                  selected ? FontWeight.w700 : FontWeight.w500,
                  selected
                      ? AnalyticsSoft.ink(context)
                      : AnalyticsSoft.slate(context),
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}

/// Floating dark pill over the peak — stitch “Thu: ₹1,240”.
class _PeakTooltipOverlay extends StatelessWidget {
  final String label;
  final int index;
  final int count;
  const _PeakTooltipOverlay({
    required this.label,
    required this.index,
    required this.count,
  });

  @override
  Widget build(BuildContext context) {
    final frac = count <= 1 ? 0.5 : index / (count - 1);
    return Align(
      alignment: Alignment(-1 + 2 * frac.clamp(0.08, 0.92), -0.92),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: AnalyticsSoft.card(context),
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: AnalyticsSoft.border(context)),
          boxShadow: AnalyticsSoft.shadow(context),
        ),
        child: Text(
          label,
          style: AnalyticsSoft.text(
            context,
            11,
            FontWeight.w600,
            AnalyticsSoft.ink(context),
          ),
        ),
      ),
    );
  }
}

// ── Where your money went ─────────────────────────────────────────────────

class AnalyticsWhereMoneyWentCard extends ConsumerWidget {
  final List<model.Transaction> txs;
  final String periodWhen;
  final VoidCallback? onViewAll;
  const AnalyticsWhereMoneyWentCard({
    super.key,
    required this.txs,
    required this.periodWhen,
    this.onViewAll,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isPrivate = ref.watch(privateModeProvider);
    final expenses = _expenseOnly(txs);
    final totals = <String, double>{};
    final counts = <String, int>{};
    for (final tx in expenses) {
      totals[tx.category] = (totals[tx.category] ?? 0) + tx.amount;
      counts[tx.category] = (counts[tx.category] ?? 0) + 1;
    }
    final sorted =
        totals.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final total = sorted.fold<double>(0, (s, e) => s + e.value);
    final top = sorted.take(4).toList();
    final categoryState = ref.watch(categoryProvider);
    final colors = [
      for (final e in top)
        AnalyticsSoft.category(storedHex: categoryState.colorHexFor(e.key)),
    ];
    final noun = sorted.length == 1 ? 'category' : 'categories';

    return AnalyticsSoftCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Where your money went',
                      style: AnalyticsSoft.text(
                        context,
                        14,
                        FontWeight.w700,
                        AnalyticsSoft.ink(context),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${sorted.length} active $noun $periodWhen',
                      style: AnalyticsSoft.text(
                        context,
                        12,
                        FontWeight.w500,
                        AnalyticsSoft.muted(context),
                      ),
                    ),
                  ],
                ),
              ),
              if (onViewAll != null)
                GestureDetector(
                  onTap: onViewAll,
                  child: Padding(
                    padding: const EdgeInsets.only(left: 8, top: 2),
                    child: Text(
                      'View all →',
                      style: AnalyticsSoft.text(
                        context,
                        13,
                        FontWeight.w600,
                        AnalyticsSoft.emeraldDeep,
                      ),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 16),
          if (top.isEmpty)
            Text(
              'No expense data',
              style: AnalyticsSoft.text(
                context,
                12,
                FontWeight.w500,
                AnalyticsSoft.muted(context),
              ),
            )
          else ...[
            Row(
              children: [
                SizedBox(
                  width: 112,
                  height: 112,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      CustomPaint(
                        size: const Size(112, 112),
                        painter: _SoftDonutPainter(
                          colors: colors,
                          values: [for (final e in top) e.value],
                          total: total,
                          track: AnalyticsSoft.track(context),
                        ),
                      ),
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            isPrivate
                                ? PrivateModeService.mask
                                : _fmtInr(total, compact: true),
                            style: AnalyticsSoft.text(
                              context,
                              15,
                              FontWeight.w800,
                              AnalyticsSoft.ink(context),
                            ),
                          ),
                          Text(
                            'TOTAL',
                            style: AnalyticsSoft.text(
                              context,
                              9,
                              FontWeight.w700,
                              AnalyticsSoft.muted(context),
                              letterSpacing: 0.6,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    children: [
                      for (var i = 0; i < top.length; i++)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 6),
                          child: Row(
                            children: [
                              Container(
                                width: 8,
                                height: 8,
                                decoration: BoxDecoration(
                                  color: colors[i],
                                  shape: BoxShape.circle,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  top[i].key,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: AnalyticsSoft.text(
                                    context,
                                    12,
                                    FontWeight.w500,
                                    AnalyticsSoft.slate(context),
                                  ),
                                ),
                              ),
                              Text(
                                total > 0
                                    ? '${(top[i].value / total * 100).round()}%'
                                    : '0%',
                                style: AnalyticsSoft.text(
                                  context,
                                  12,
                                  FontWeight.w700,
                                  AnalyticsSoft.ink(context),
                                ),
                              ),
                            ],
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            for (var i = 0; i < top.length; i++)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: _CategorySoftRow(
                  name: top[i].key,
                  accent: colors[i],
                  subtitle:
                      '${counts[top[i].key] ?? 0} ${(counts[top[i].key] ?? 0) == 1 ? 'entry' : 'entries'}',
                  amount:
                      isPrivate
                          ? PrivateModeService.mask
                          : _fmtInr(top[i].value),
                ),
              ),
          ],
        ],
      ),
    );
  }
}

class _SoftDonutPainter extends CustomPainter {
  const _SoftDonutPainter({
    required this.colors,
    required this.values,
    required this.total,
    required this.track,
  });

  final List<Color> colors;
  final List<double> values;
  final double total;
  final Color track;

  @override
  void paint(Canvas canvas, Size size) {
    const stroke = 10.0;
    final center = size.center(Offset.zero);
    final radius = (size.shortestSide - stroke) / 2;
    final rect = Rect.fromCircle(center: center, radius: radius);
    final trackPaint =
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = stroke
          ..strokeCap = StrokeCap.round
          ..color = track;
    canvas.drawCircle(center, radius, trackPaint);
    if (total <= 0) return;
    var start = -math.pi / 2;
    for (var i = 0; i < values.length; i++) {
      final sweep = (values[i] / total) * math.pi * 2;
      if (sweep <= 0) continue;
      final paint =
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = stroke
            ..strokeCap = StrokeCap.round
            ..color = colors[i];
      canvas.drawArc(rect, start, sweep, false, paint);
      start += sweep;
    }
  }

  @override
  bool shouldRepaint(covariant _SoftDonutPainter oldDelegate) =>
      oldDelegate.total != total || oldDelegate.track != track;
}

class _CategorySoftRow extends StatelessWidget {
  final String name;
  final String subtitle;
  final String amount;
  final Color accent;
  const _CategorySoftRow({
    required this.name,
    required this.subtitle,
    required this.amount,
    required this.accent,
  });

  @override
  Widget build(BuildContext context) {
    final cat = CategoryIcon.resolve(name);
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AnalyticsSoft.slate50(context),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: accent.withValues(alpha: 0.14),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(cat.icon, size: 18, color: accent),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AnalyticsSoft.text(
                    context,
                    12,
                    FontWeight.w600,
                    AnalyticsSoft.ink(context),
                  ),
                ),
                Text(
                  subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AnalyticsSoft.text(
                    context,
                    11,
                    FontWeight.w500,
                    AnalyticsSoft.muted(context),
                  ),
                ),
              ],
            ),
          ),
          Text(
            amount,
            style: AnalyticsSoft.text(
              context,
              12,
              FontWeight.w700,
              AnalyticsSoft.ink(context),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Spending by Purpose ───────────────────────────────────────────────────

class AnalyticsPurposeBarsCard extends ConsumerWidget {
  final List<model.Transaction> txs;
  const AnalyticsPurposeBarsCard({super.key, required this.txs});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isPrivate = ref.watch(privateModeProvider);
    final expenses = _expenseOnly(txs);
    final map = <String, double>{};
    for (final tx in expenses) {
      final key =
          (tx.purpose == null || tx.purpose!.trim().isEmpty)
              ? 'Personal'
              : tx.purpose!.trim();
      map[key] = (map[key] ?? 0) + tx.amount;
    }
    final sorted =
        map.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final total = sorted.fold<double>(0, (s, e) => s + e.value);
    return AnalyticsSoftCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Spending by Purpose',
                      style: AnalyticsSoft.text(
                        context,
                        14,
                        FontWeight.w700,
                        AnalyticsSoft.ink(context),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Intent behind each expense',
                      style: AnalyticsSoft.text(
                        context,
                        12,
                        FontWeight.w500,
                        AnalyticsSoft.muted(context),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                width: 32,
                height: 32,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: AnalyticsSoft.slate50(context),
                  shape: BoxShape.circle,
                  border: Border.all(color: AnalyticsSoft.border(context)),
                ),
                child: Icon(
                  LucideIcons.slidersHorizontal,
                  size: 14,
                  color: AnalyticsSoft.slate(context),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          if (sorted.isEmpty)
            Text(
              'No purpose spend',
              style: AnalyticsSoft.text(
                context,
                12,
                FontWeight.w500,
                AnalyticsSoft.muted(context),
              ),
            )
          else
            for (var i = 0; i < sorted.length; i++) ...[
              if (i > 0) const SizedBox(height: 12),
              _PurposeBarRow(
                label: sorted[i].key,
                pct: total > 0 ? sorted[i].value / total : 0,
                amountLabel:
                    isPrivate
                        ? PrivateModeService.mask
                        : _fmtInr(sorted[i].value),
                color: AnalyticsSoft.purpose(sorted[i].key, i),
              ),
            ],
        ],
      ),
    );
  }
}

class _PurposeBarRow extends StatelessWidget {
  final String label;
  final double pct;
  final String amountLabel;
  final Color color;
  const _PurposeBarRow({
    required this.label,
    required this.pct,
    required this.amountLabel,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                label,
                style: AnalyticsSoft.text(
                  context,
                  12,
                  FontWeight.w600,
                  AnalyticsSoft.ink(context),
                ),
              ),
            ),
            Text(
              '${(pct * 100).round()}% · $amountLabel',
              style: AnalyticsSoft.text(
                context,
                12,
                FontWeight.w500,
                AnalyticsSoft.slate(context),
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(99),
          child: LinearProgressIndicator(
            value: pct.clamp(0.0, 1.0),
            minHeight: 8,
            backgroundColor: AnalyticsSoft.track(context),
            color: color,
          ),
        ),
      ],
    );
  }
}

// ── Budget Performance ────────────────────────────────────────────────────

class AnalyticsBudgetPerformanceCard extends ConsumerWidget {
  final List<model.Transaction> allTxs;
  final String purpose;
  const AnalyticsBudgetPerformanceCard({
    super.key,
    required this.allTxs,
    required this.purpose,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final fmt = NumberFormat.currency(
      symbol: '₹',
      decimalDigits: 0,
      locale: 'en_IN',
    );
    final month = currentPlanMonth();
    final plans = ref.watch(planProvider);
    final isPrivate = ref.watch(privateModeProvider);

    final plan =
        plans
            .where(
              (p) =>
                  p.month == month &&
                  (p.purposeName ?? 'Personal').toLowerCase() ==
                      purpose.toLowerCase(),
            )
            .firstOrNull;

    final now = DateTime.now();
    final thisMonthTxs =
        allTxs
            .where(
              (tx) =>
                  !tx.isTransfer &&
                  tx.category != 'Repayment' &&
                  tx.isExpense &&
                  !tx.isFriendReturn &&
                  tx.date.year == now.year &&
                  tx.date.month == now.month &&
                  (purpose == 'All' ||
                      (tx.purpose ?? 'Personal').toLowerCase() ==
                          purpose.toLowerCase()),
            )
            .toList();

    final actualsByCategory = <String, double>{};
    for (final tx in thisMonthTxs) {
      actualsByCategory[tx.category] =
          (actualsByCategory[tx.category] ?? 0) + tx.amount;
    }
    final totalActual = actualsByCategory.values.fold<double>(
      0,
      (s, v) => s + v,
    );

    if (plan == null || plan.allocations.isEmpty) {
      return AnalyticsSoftCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Budget Performance',
              style: AnalyticsSoft.text(
                context,
                14,
                FontWeight.w700,
                AnalyticsSoft.ink(context),
              ),
            ),
            const SizedBox(height: 2),
            Text(
              'Monthly expense cap',
              style: AnalyticsSoft.text(
                context,
                12,
                FontWeight.w500,
                AnalyticsSoft.muted(context),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'No active budget for ${formatPlanMonth(month)} ($purpose).',
              style: AnalyticsSoft.text(
                context,
                12,
                FontWeight.w500,
                AnalyticsSoft.slate(context),
              ),
            ),
          ],
        ),
      );
    }

    final totalPlanned = plan.totalPlanned;
    final usedPct =
        totalPlanned > 0 ? (totalActual / totalPlanned).clamp(0.0, 2.0) : 0.0;
    final remaining = (totalPlanned - totalActual).clamp(0.0, double.infinity);
    final onTrack = totalActual <= totalPlanned;
    // Simple projection: pace * days-in-month.
    final day = now.day.clamp(1, 31);
    final daysInMonth = DateTime(now.year, now.month + 1, 0).day;
    final projected = day > 0 ? (totalActual / day) * daysInMonth : totalActual;

    final mini =
        plan.allocations.map((a) {
            final spent = actualsByCategory[a.category] ?? 0;
            final ratio =
                a.plannedAmount > 0
                    ? (spent / a.plannedAmount).clamp(0.0, 1.5)
                    : 0.0;
            return (a.category, ratio, spent > a.plannedAmount);
          }).toList()
          ..sort((a, b) => b.$2.compareTo(a.$2));

    Color miniColor(double ratio, bool over) {
      if (over || ratio > 1) return AnalyticsSoft.rose;
      if (ratio >= 0.8) return AnalyticsSoft.amber;
      return AnalyticsSoft.emerald;
    }

    return AnalyticsSoftCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Budget Performance',
                      style: AnalyticsSoft.text(
                        context,
                        14,
                        FontWeight.w700,
                        AnalyticsSoft.ink(context),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Monthly expense cap',
                      style: AnalyticsSoft.text(
                        context,
                        12,
                        FontWeight.w500,
                        AnalyticsSoft.muted(context),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 5,
                ),
                decoration: BoxDecoration(
                  color:
                      onTrack
                          ? AnalyticsSoft.mint(context)
                          : AnalyticsSoft.rose.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  onTrack ? 'On track' : 'Over budget',
                  style: AnalyticsSoft.text(
                    context,
                    11,
                    FontWeight.w700,
                    onTrack ? AnalyticsSoft.emeraldDeep : AnalyticsSoft.rose,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            crossAxisAlignment: CrossAxisAlignment.baseline,
            textBaseline: TextBaseline.alphabetic,
            children: [
              Text(
                isPrivate ? PrivateModeService.mask : fmt.format(totalActual),
                style: AnalyticsSoft.text(
                  context,
                  20,
                  FontWeight.w800,
                  AnalyticsSoft.ink(context),
                ),
              ),
              const SizedBox(width: 6),
              Text(
                isPrivate ? '' : '/ ${fmt.format(totalPlanned)}',
                style: AnalyticsSoft.text(
                  context,
                  13,
                  FontWeight.w500,
                  AnalyticsSoft.muted(context),
                ),
              ),
              const Spacer(),
              Text(
                '${(usedPct * 100).round()}% used',
                style: AnalyticsSoft.text(
                  context,
                  12,
                  FontWeight.w600,
                  AnalyticsSoft.slate(context),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(99),
            child: LinearProgressIndicator(
              value: usedPct.clamp(0.0, 1.0),
              minHeight: 8,
              backgroundColor: AnalyticsSoft.track(context),
              color: onTrack ? AnalyticsSoft.emerald : AnalyticsSoft.rose,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Text(
                isPrivate
                    ? 'Remaining ${PrivateModeService.mask}'
                    : 'Remaining ${fmt.format(remaining)}',
                style: AnalyticsSoft.text(
                  context,
                  12,
                  FontWeight.w600,
                  AnalyticsSoft.emeraldDeep,
                ),
              ),
              const Spacer(),
              Text(
                isPrivate
                    ? 'Projected ${PrivateModeService.mask}'
                    : 'Projected ${fmt.format(projected)}',
                style: AnalyticsSoft.text(
                  context,
                  12,
                  FontWeight.w500,
                  AnalyticsSoft.muted(context),
                ),
              ),
            ],
          ),
          if (mini.isNotEmpty) ...[
            const SizedBox(height: 12),
            Row(
              children: [
                for (var i = 0; i < math.min(2, mini.length); i++) ...[
                  if (i > 0) const SizedBox(width: 8),
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: AnalyticsSoft.slate50(context),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  mini[i].$1,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: AnalyticsSoft.text(
                                    context,
                                    11,
                                    FontWeight.w600,
                                    AnalyticsSoft.slate(context),
                                  ),
                                ),
                              ),
                              Text(
                                '${(mini[i].$2 * 100).round()}%',
                                style: AnalyticsSoft.text(
                                  context,
                                  11,
                                  FontWeight.w700,
                                  miniColor(mini[i].$2, mini[i].$3),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 6),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(99),
                            child: LinearProgressIndicator(
                              value: mini[i].$2.clamp(0.0, 1.0),
                              minHeight: 6,
                              backgroundColor: AnalyticsSoft.track(context),
                              color: miniColor(mini[i].$2, mini[i].$3),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ],
        ],
      ),
    );
  }
}

// ── Savings Journey ───────────────────────────────────────────────────────

class AnalyticsSavingsJourneyCard extends ConsumerWidget {
  final List<model.Transaction> allTxs;
  final double income;
  final double spent;
  final String purpose;

  const AnalyticsSavingsJourneyCard({
    super.key,
    required this.allTxs,
    required this.income,
    required this.spent,
    required this.purpose,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isPrivate = ref.watch(privateModeProvider);
    final fmt = NumberFormat.currency(
      symbol: '₹',
      decimalDigits: 0,
      locale: 'en_IN',
    );
    final saved = income - spent;
    final month = currentPlanMonth();
    final plans = ref.watch(planProvider);
    final plan =
        plans
            .where(
              (p) =>
                  p.month == month &&
                  (p.purposeName ?? 'Personal').toLowerCase() ==
                      purpose.toLowerCase(),
            )
            .firstOrNull;

    final target =
        plan?.savingsTarget ??
        ((plan?.expectedIncome ?? 0) > 0
            ? (plan!.expectedIncome - plan.totalPlanned).clamp(
              0.0,
              double.infinity,
            )
            : 0.0);
    final rate = income > 0 ? (saved / income * 100) : 0.0;
    final reached =
        target > 0 ? (saved.clamp(0, target) / target).clamp(0.0, 1.0) : 0.0;

    final now = DateTime.now();
    final months = <({String label, double value, bool current})>[];
    double maxAbs = 1;
    for (var i = 5; i >= 0; i--) {
      final m = DateTime(now.year, now.month - i, 1);
      final next = DateTime(m.year, m.month + 1, 1);
      final monthTxs =
          allTxs
              .where(
                (tx) =>
                    !tx.isTransfer &&
                    tx.category != 'Repayment' &&
                    !tx.date.isBefore(m) &&
                    tx.date.isBefore(next),
              )
              .toList();
      final totals = computeReimbursementTotals(monthTxs);
      final net = totals.income - totals.netSpend;
      months.add((
        label: DateFormat('MMM').format(m),
        value: net.clamp(0.0, double.infinity),
        current: i == 0,
      ));
      maxAbs = math.max(maxAbs, net.clamp(0.0, double.infinity));
    }

    return AnalyticsSoftCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'Savings Journey',
                  style: AnalyticsSoft.text(
                    context,
                    14,
                    FontWeight.w700,
                    AnalyticsSoft.ink(context),
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 5,
                ),
                decoration: BoxDecoration(
                  color:
                      rate >= 0
                          ? AnalyticsSoft.mint(context)
                          : AnalyticsSoft.rose.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  '${rate.toStringAsFixed(1)}% rate',
                  style: AnalyticsSoft.text(
                    context,
                    11,
                    FontWeight.w700,
                    rate >= 0 ? AnalyticsSoft.emeraldDeep : AnalyticsSoft.rose,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            isPrivate
                ? 'Saved: ${PrivateModeService.mask}'
                : 'Saved: ${fmt.format(saved)}',
            style: AnalyticsSoft.text(
              context,
              20,
              FontWeight.w800,
              AnalyticsSoft.ink(context),
            ),
          ),
          const SizedBox(height: 2),
          Text(
            target > 0
                ? (isPrivate
                    ? 'Target: ${PrivateModeService.mask}'
                    : 'Target: ${fmt.format(target)}')
                : 'No savings target set',
            style: AnalyticsSoft.text(
              context,
              12,
              FontWeight.w500,
              AnalyticsSoft.muted(context),
            ),
          ),
          if (target > 0) ...[
            const SizedBox(height: 12),
            ClipRRect(
              borderRadius: BorderRadius.circular(99),
              child: LinearProgressIndicator(
                value: reached,
                minHeight: 8,
                backgroundColor: AnalyticsSoft.track(context),
                color: AnalyticsSoft.emerald,
              ),
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                Text(
                  isPrivate
                      ? PrivateModeService.mask
                      : '${fmt.format(saved.clamp(0, target))} / ${fmt.format(target)}',
                  style: AnalyticsSoft.text(
                    context,
                    12,
                    FontWeight.w500,
                    AnalyticsSoft.slate(context),
                  ),
                ),
                const Spacer(),
                Text(
                  '${(reached * 100).round()}% reached',
                  style: AnalyticsSoft.text(
                    context,
                    12,
                    FontWeight.w600,
                    AnalyticsSoft.slate(context),
                  ),
                ),
              ],
            ),
          ],
          const SizedBox(height: 16),
          Divider(height: 1, color: AnalyticsSoft.border(context)),
          const SizedBox(height: 12),
          Text(
            '6-MONTH TREND',
            style: AnalyticsSoft.text(
              context,
              11,
              FontWeight.w700,
              AnalyticsSoft.muted(context),
              letterSpacing: 1.1,
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 96,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                for (final m in months)
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Flexible(
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: Container(
                              width: 22,
                              height: math.max(8, (m.value / maxAbs) * 72),
                              decoration: BoxDecoration(
                                color:
                                    m.current
                                        ? AnalyticsSoft.emerald
                                        : AnalyticsSoft.slate100(context),
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          m.label,
                          style: AnalyticsSoft.text(
                            context,
                            10,
                            m.current ? FontWeight.w700 : FontWeight.w500,
                            m.current
                                ? AnalyticsSoft.emeraldDeep
                                : AnalyticsSoft.muted(context),
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ── Top Expenses ──────────────────────────────────────────────────────────

class AnalyticsTopExpensesCard extends ConsumerWidget {
  final List<model.Transaction> txs;
  final List<Outing> outings;
  final String caption;
  final VoidCallback? onViewAll;
  const AnalyticsTopExpensesCard({
    super.key,
    required this.txs,
    required this.outings,
    required this.caption,
    this.onViewAll,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isPrivate = ref.watch(privateModeProvider);
    final grouped = <String, double>{};
    final meta = <String, String>{};
    final handledOutingIds = <String>{};

    for (final tx in _expenseOnly(txs)) {
      if (tx.outingId != null) {
        if (handledOutingIds.contains(tx.outingId)) continue;
        final outing = outings.where((o) => o.id == tx.outingId).firstOrNull;
        if (outing != null) {
          grouped[outing.title] = outing.userNetCost;
          meta[outing.title] =
              outing.category.isNotEmpty ? outing.category : 'Trip';
          handledOutingIds.add(tx.outingId!);
        } else {
          final label = TransactionDisplayUtils.merchantTitle(tx);
          grouped[label] = (grouped[label] ?? 0) + tx.amount;
          meta[label] = tx.category;
        }
      } else {
        final label = TransactionDisplayUtils.merchantTitle(tx);
        grouped[label] = (grouped[label] ?? 0) + tx.amount;
        meta[label] = tx.category;
      }
    }

    final sorted =
        grouped.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final total = sorted.fold<double>(0, (s, e) => s + e.value);
    final top = sorted.take(4).toList();

    return AnalyticsSoftCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Top Expenses',
                      style: AnalyticsSoft.text(
                        context,
                        14,
                        FontWeight.w700,
                        AnalyticsSoft.ink(context),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      caption,
                      style: AnalyticsSoft.text(
                        context,
                        12,
                        FontWeight.w500,
                        AnalyticsSoft.muted(context),
                      ),
                    ),
                  ],
                ),
              ),
              if (onViewAll != null)
                GestureDetector(
                  onTap: onViewAll,
                  child: Text(
                    'View all →',
                    style: AnalyticsSoft.text(
                      context,
                      13,
                      FontWeight.w600,
                      AnalyticsSoft.emeraldDeep,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 16),
          if (top.isEmpty)
            Text(
              'No spending data',
              style: AnalyticsSoft.text(
                context,
                12,
                FontWeight.w500,
                AnalyticsSoft.muted(context),
              ),
            )
          else
            for (final e in top)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: _TopExpenseRow(
                  title: e.key,
                  subtitle:
                      '${meta[e.key] ?? 'Expense'} · ${total > 0 ? (e.value / total * 100).toStringAsFixed(1) : '0'}%',
                  amount:
                      isPrivate ? PrivateModeService.mask : _fmtInr(e.value),
                  isOuting: outings.any((o) => o.title == e.key),
                  category: meta[e.key] ?? e.key,
                  accent: AnalyticsSoft.category(
                    storedHex: ref
                        .watch(categoryProvider)
                        .colorHexFor(meta[e.key] ?? e.key),
                  ),
                ),
              ),
        ],
      ),
    );
  }
}

class _TopExpenseRow extends StatelessWidget {
  final String title;
  final String subtitle;
  final String amount;
  final bool isOuting;
  final String category;
  final Color accent;
  const _TopExpenseRow({
    required this.title,
    required this.subtitle,
    required this.amount,
    required this.isOuting,
    required this.category,
    required this.accent,
  });

  @override
  Widget build(BuildContext context) {
    final cat = CategoryIcon.resolve(category);
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AnalyticsSoft.slate50(context),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: accent.withValues(alpha: 0.14),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(
              isOuting ? LucideIcons.map : cat.icon,
              size: 18,
              color: accent,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AnalyticsSoft.text(
                    context,
                    12,
                    FontWeight.w600,
                    AnalyticsSoft.ink(context),
                  ),
                ),
                Text(
                  subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AnalyticsSoft.text(
                    context,
                    11,
                    FontWeight.w500,
                    AnalyticsSoft.muted(context),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Text(
            amount,
            style: AnalyticsSoft.text(
              context,
              12,
              FontWeight.w700,
              AnalyticsSoft.ink(context),
            ),
          ),
        ],
      ),
    );
  }
}
