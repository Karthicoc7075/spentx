import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:intl/intl.dart';
import 'package:go_router/go_router.dart';
import '../../../core/providers/transaction_provider.dart' as model;
import '../../../core/providers/outing_provider.dart';
import '../../../core/providers/user_state_provider.dart';
import '../../../core/providers/outing_privacy_provider.dart';
import '../../../core/sync/sync_service.dart';
import '../../../core/services/notification_history_service.dart';
import '../../../core/utils/reimbursement.dart';
import '../../../core/widgets/terminal_wrapper.dart';
import '../../../core/widgets/soft_date_range_picker.dart';
import 'analytics_stitch_cards.dart';
import 'soft_analytics_widgets.dart';

class AnalyticsScreen extends ConsumerStatefulWidget {
  const AnalyticsScreen({super.key});

  @override
  ConsumerState<AnalyticsScreen> createState() => _AnalyticsScreenState();
}

/// Expands every Split Expense into one synthetic transaction per split row
/// — its own category, purpose and amount — so every chart below (category
/// breakdown, purpose filter, cash flow, top accounts/spending) attributes
/// spend to the right bucket instead of dumping the whole transaction total
/// under its first category. Mirrors the web app's `buildCategoryTotals`
/// split handling. Non-split transactions pass through unchanged.
List<model.Transaction> _flattenSplitExpenses(List<model.Transaction> txs) {
  final result = <model.Transaction>[];
  for (final t in txs) {
    if (!t.isSplitExpense || t.splits.isEmpty) {
      result.add(t);
      continue;
    }
    for (final s in t.splits) {
      if (s.amount <= 0) continue;
      result.add(
        t.copyWith(
          category: s.categoryId.isEmpty ? t.category : s.categoryId,
          purpose: s.purposeId.isEmpty ? t.purpose : s.purposeId,
          amount: s.amount,
          splits: const [],
        ),
      );
    }
  }
  return result;
}

class _PeriodTotals {
  final double income, spent;
  const _PeriodTotals(this.income, this.spent);
}

/// Computes totals for a given historical period offset.
_PeriodTotals _computePeriodTotals(
  List<model.Transaction> allTxs,
  List<Outing> outings,
  String purpose,
  int timeRange,
  int periodsAgo, {
  bool includeOutingExpenses = true,
  String? accountFilter,
  String? contributorFilter,
  Set<String>? categoryFilter,
  DateTime? customFrom,
  DateTime? customTo,
}) {
  final now = DateTime.now();
  DateTime start, end;

  switch (timeRange) {
    case 0: // This Month
      {
        final mi = now.month - 1 - periodsAgo;
        final year = now.year + (mi < 0 ? ((mi - 11) ~/ 12) : 0);
        final month = ((mi % 12) + 12) % 12 + 1;
        start = DateTime(year, month, 1);
        end = DateTime(
          month == 12 ? year + 1 : year,
          month == 12 ? 1 : month + 1,
          1,
        );
      }
      break;
    case 1: // Previous Month (selected) — periodsAgo shifts further back
      {
        final mi = now.month - 2 - periodsAgo;
        final year = now.year + (mi < 0 ? ((mi - 11) ~/ 12) : 0);
        final month = ((mi % 12) + 12) % 12 + 1;
        start = DateTime(year, month, 1);
        end = DateTime(
          month == 12 ? year + 1 : year,
          month == 12 ? 1 : month + 1,
          1,
        );
      }
      break;
    case 2: // Last 3 Months
      {
        final endMonth = DateTime(now.year, now.month + 1 - 3 * periodsAgo, 1);
        final startMonth = DateTime(endMonth.year, endMonth.month - 3, 1);
        start = startMonth;
        end = endMonth;
      }
      break;
    default: // Custom = the applied calendar range
      if (customFrom != null && customTo != null) {
        final from = DateTime(
          customFrom.year,
          customFrom.month,
          customFrom.day,
        );
        final to = DateTime(customTo.year, customTo.month, customTo.day + 1);
        final span = to.difference(from);
        end = to.subtract(Duration(days: span.inDays * periodsAgo));
        start = from.subtract(Duration(days: span.inDays * periodsAgo));
      } else {
        start = DateTime(now.year - periodsAgo, 1, 1);
        end = DateTime(now.year - periodsAgo + 1, 1, 1);
      }
  }

  var txs =
      allTxs
          .where(
            (t) =>
                !t.isTransfer &&
                t.category != 'Repayment' &&
                !t.date.isBefore(start) &&
                t.date.isBefore(end),
          )
          .toList();

  txs = _flattenSplitExpenses(txs);

  if (purpose != 'All') {
    txs =
        txs
            .where((t) => t.purpose?.toLowerCase() == purpose.toLowerCase())
            .toList();
  }
  if (accountFilter != null && accountFilter.isNotEmpty) {
    txs = txs.where((t) => t.account == accountFilter).toList();
  }
  if (contributorFilter != null && contributorFilter.isNotEmpty) {
    txs =
        txs
            .where(
              (t) =>
                  (t.contributorSource ?? 'Me').toLowerCase() ==
                  contributorFilter.toLowerCase(),
            )
            .toList();
  }
  if (categoryFilter != null && categoryFilter.isNotEmpty) {
    txs = txs.where((t) => categoryFilter.contains(t.category)).toList();
  }

  final List<model.Transaction> periodTxs = [...txs];

  if (includeOutingExpenses) {
    final linkedTxIds =
        allTxs.where((t) => t.outingId != null).map((t) => t.id).toSet();

    for (final outing in outings) {
      if (purpose == 'Family') continue;

      double unlinkedUserShareTotal = 0;
      DateTime? latestDate;

      for (final e in outing.expenses) {
        if (e.transactionId != null && linkedTxIds.contains(e.transactionId)) {
          continue;
        }

        final share = e.amount;
        if (share > 0) {
          unlinkedUserShareTotal += share;
          if (latestDate == null || e.date.isAfter(latestDate)) {
            latestDate = e.date;
          }
        }
      }

      if (unlinkedUserShareTotal > 0) {
        final txDate = latestDate ?? outing.startDate;
        if (!txDate.isBefore(start) && txDate.isBefore(end)) {
          periodTxs.add(
            model.Transaction(
              merchant: outing.title,
              category: outing.category.isNotEmpty ? outing.category : 'Trip',
              account: 'Mixed',
              time: 'Trip',
              amount: unlinkedUserShareTotal,
              isExpense: true,
              date: txDate,
              purpose: 'Personal',
              outingId: outing.id,
              note: 'Outing · ${outing.category}',
            ),
          );
        }
      }
    }
  }

  final totals = computeReimbursementTotals(periodTxs);
  return _PeriodTotals(totals.income, totals.netSpend);
}

class _AnalyticsScreenState extends ConsumerState<AnalyticsScreen> {
  // 0 This Month · 1 Previous Month · 2 Last 3 Months · 3 Custom
  int _timeRange = 0;
  DateTime? _customFromDate;
  DateTime? _customToDate;
  bool _fetchingRange = false;
  // Purpose kept as All — design has no purpose filter chips on Analytics.
  final String _selectedPurpose = 'All';

  String _getInitials(String name) {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return '?';
    final parts = trimmed.split(RegExp(r'\s+'));
    if (parts.length >= 2) {
      return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    }
    return trimmed.length >= 2
        ? trimmed.substring(0, 2).toUpperCase()
        : trimmed.toUpperCase();
  }

  Future<void> _showDateRangeSheet() async {
    final now = DateTime.now();
    final lastDay = DateTime(now.year, now.month, now.day);
    final first = DateTime(2020);

    DateTime start = _customFromDate ?? DateTime(now.year, now.month, 1);
    DateTime end = _customToDate ?? lastDay;
    start = DateTime(start.year, start.month, start.day);
    end = DateTime(end.year, end.month, end.day);
    if (end.isAfter(lastDay)) end = lastDay;
    if (start.isBefore(first)) start = first;
    if (start.isAfter(end)) start = end;

    final picked = await showSoftDateRangePicker(
      context: context,
      firstDate: first,
      lastDate: lastDay,
      initialDateRange: DateTimeRange(start: start, end: end),
    );
    if (!mounted || picked == null) return;
    setState(() {
      _customFromDate = DateTime(
        picked.start.year,
        picked.start.month,
        picked.start.day,
      );
      _customToDate = DateTime(
        picked.end.year,
        picked.end.month,
        picked.end.day,
      );
      _timeRange = 3;
    });
    _ensureRangeCached(3);
  }

  Future<void> _ensureRangeCached(int range) async {
    if (_fetchingRange) return;
    final now = DateTime.now();
    DateTime needFrom;
    if (range == 3) {
      needFrom = _customFromDate ?? DateTime(now.year, now.month - 2, now.day);
    } else if (range == 2) {
      needFrom = DateTime(now.year, now.month - 2, 1);
    } else {
      return;
    }
    final oldest = SyncService.oldestCachedTransactionDate();
    if (oldest != null && !oldest.isAfter(needFrom)) return;

    _fetchingRange = true;
    final fetched = await SyncService.fetchTransactionRange(
      from: needFrom,
      to: oldest ?? now,
    );
    _fetchingRange = false;
    if (!mounted) return;
    if (fetched == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Offline — this chart only covers transactions cached on this device.',
          ),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  List<model.Transaction> _getFilteredData(
    List<model.Transaction> allTxs,
    List<Outing> outings, {
    String? privacyOutingId,
    bool includeOutingExpenses = true,
    bool ignoreTimeRange = false,
  }) {
    if (privacyOutingId != null) {
      final outing = outings.where((o) => o.id == privacyOutingId).firstOrNull;
      if (outing == null) return [];
      final linked =
          outing.expenses
              .map((e) => e.transactionId)
              .whereType<String>()
              .toSet();
      final result = _flattenSplitExpenses(
        allTxs
            .where(
              (t) =>
                  t.outingId == privacyOutingId &&
                  !t.isTransfer &&
                  t.category != 'Repayment' &&
                  !linked.contains(t.id),
            )
            .toList(),
      );
      for (final e in outing.expenses) {
        if (e.transactionId != null) continue;
        result.add(
          model.Transaction(
            merchant: '${outing.title}: ${e.title}',
            category: e.category,
            account: e.accountId ?? 'Trip',
            time: 'Trip',
            amount: e.amount,
            isExpense: true,
            date: e.date,
            purpose: 'Personal',
            outingId: outing.id,
            note: '',
          ),
        );
      }
      return result;
    }

    var txs =
        allTxs
            .where((t) => !t.isTransfer && t.category != 'Repayment')
            .toList();

    if (!includeOutingExpenses) {
      txs = txs.where((t) => t.outingId == null).toList();
    }

    // Split Expenses first — every chart/filter attributes each split's own
    // amount to its own category/purpose, never the whole transaction total.
    txs = _flattenSplitExpenses(txs);

    // 1. Purpose Filter
    if (_selectedPurpose != 'All') {
      txs =
          txs
              .where(
                (t) =>
                    t.purpose?.toLowerCase() == _selectedPurpose.toLowerCase(),
              )
              .toList();
    }

    // 2. Time Range Filter
    final now = DateTime.now();
    if (!ignoreTimeRange) {
      txs =
          txs.where((t) {
            if (_timeRange == 0) {
              return t.date.year == now.year && t.date.month == now.month;
            }
            if (_timeRange == 1) {
              final prev = DateTime(now.year, now.month - 1, 1);
              return t.date.year == prev.year && t.date.month == prev.month;
            }
            if (_timeRange == 2) {
              final start = DateTime(now.year, now.month - 2, 1);
              return !t.date.isBefore(start);
            }
            if (_timeRange == 3 &&
                _customFromDate != null &&
                _customToDate != null) {
              final from = DateTime(
                _customFromDate!.year,
                _customFromDate!.month,
                _customFromDate!.day,
              );
              final to = DateTime(
                _customToDate!.year,
                _customToDate!.month,
                _customToDate!.day + 1,
              );
              return !t.date.isBefore(from) && t.date.isBefore(to);
            }
            if (_timeRange == 3) return t.date.year == now.year;
            return true;
          }).toList();
    }

    // 3. Add Outing Roll-Up Transactions
    final List<model.Transaction> result = [...txs];
    if (includeOutingExpenses) {
      final linkedTxIds =
          allTxs.where((t) => t.outingId != null).map((t) => t.id).toSet();

      for (var outing in outings) {
        if (_selectedPurpose == 'Family') continue;

        double unlinkedOutingTotal = 0;
        DateTime? latestDate;

        for (var e in outing.expenses) {
          if (e.transactionId != null &&
              linkedTxIds.contains(e.transactionId)) {
            continue;
          }

          if (e.amount > 0) {
            unlinkedOutingTotal += e.amount;
            if (latestDate == null || e.date.isAfter(latestDate)) {
              latestDate = e.date;
            }
          }
        }

        if (unlinkedOutingTotal > 0) {
          final txDate = latestDate ?? outing.startDate;
          bool timeMatch = ignoreTimeRange;
          if (!ignoreTimeRange) {
            if (_timeRange == 0) {
              timeMatch = txDate.year == now.year && txDate.month == now.month;
            } else if (_timeRange == 1) {
              final prev = DateTime(now.year, now.month - 1, 1);
              timeMatch =
                  txDate.year == prev.year && txDate.month == prev.month;
            } else if (_timeRange == 2) {
              final start = DateTime(now.year, now.month - 2, 1);
              timeMatch = !txDate.isBefore(start);
            } else if (_timeRange == 3 &&
                _customFromDate != null &&
                _customToDate != null) {
              final from = DateTime(
                _customFromDate!.year,
                _customFromDate!.month,
                _customFromDate!.day,
              );
              final to = DateTime(
                _customToDate!.year,
                _customToDate!.month,
                _customToDate!.day + 1,
              );
              timeMatch = !txDate.isBefore(from) && txDate.isBefore(to);
            } else if (_timeRange == 3) {
              timeMatch = txDate.year == now.year;
            }
          }

          if (timeMatch) {
            result.add(
              model.Transaction(
                merchant: outing.title,
                category: outing.category.isNotEmpty ? outing.category : 'Trip',
                account: 'Mixed',
                time: 'Trip',
                amount: unlinkedOutingTotal,
                isExpense: true,
                date: txDate,
                purpose: 'Personal',
                outingId: outing.id,
                note: 'Outing · ${outing.category}',
              ),
            );
          }
        }
      }
    }
    return result;
  }

  @override
  Widget build(BuildContext context) {
    final allTxs = ref.watch(model.transactionProvider);
    final outings = ref.watch(outingProvider);
    final userState = ref.watch(userStateProvider);
    final privacyActive = ref.watch(isOutingPrivacyActiveProvider);
    final activeOuting = ref.watch(activeOutingProvider);
    final profileName =
        userState.profileName.trim().isNotEmpty ? userState.profileName : '';
    final hasUnread = ref.watch(hasUnreadNotificationsProvider);

    final filtered = _getFilteredData(
      allTxs,
      outings,
      privacyOutingId: privacyActive ? activeOuting?.id : null,
      includeOutingExpenses: userState.includeOutingExpenses,
    );
    final historyForTrend = _getFilteredData(
      allTxs,
      outings,
      privacyOutingId: privacyActive ? activeOuting?.id : null,
      includeOutingExpenses: userState.includeOutingExpenses,
      ignoreTimeRange: true,
    );

    final totals = computeReimbursementTotals(filtered);
    final income = totals.income;
    final spent = totals.netSpend;

    final prevPeriodTotals = _computePeriodTotals(
      allTxs,
      outings,
      _selectedPurpose,
      _timeRange,
      1,
      includeOutingExpenses: userState.includeOutingExpenses,
      customFrom: _customFromDate,
      customTo: _customToDate,
    );

    final hasSpend = filtered.any((t) => t.isExpense && !t.isFriendReturn);
    final topPad = MediaQuery.of(context).padding.top;

    return TerminalWrapper(
      screenName: 'Analysis',
      child: Scaffold(
        backgroundColor: AnalyticsSoft.canvas(context),
        body: Column(
          children: [
            ClipRect(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
                child: Container(
                  padding: EdgeInsets.fromLTRB(16, topPad + 10, 16, 12),
                  decoration: BoxDecoration(
                    color: AnalyticsSoft.canvas(
                      context,
                    ).withValues(alpha: 0.85),
                    border: Border(
                      bottom: BorderSide(color: AnalyticsSoft.border(context)),
                    ),
                  ),
                  child: _AnalyticsHeader(
                    title:
                        privacyActive && activeOuting != null
                            ? 'Trip analytics'
                            : 'Analytics',
                    subtitle:
                        privacyActive && activeOuting != null
                            ? 'Outing spend & splits'
                            : 'Understand your spending & savings',
                    initials: _getInitials(profileName),
                    hasUnread: hasUnread,
                    onNotifications: () => context.push('/notifications'),
                    onProfile: () => context.push('/settings'),
                  ),
                ),
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: EdgeInsets.fromLTRB(
                  16,
                  16,
                  16,
                  96 + MediaQuery.of(context).padding.bottom,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (privacyActive && activeOuting != null) ...[
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: AnalyticsSoft.mint(context),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              LucideIcons.eyeOff,
                              size: 16,
                              color: AnalyticsSoft.emeraldDeep,
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                'Showing ${activeOuting.title} only — full analytics hidden',
                                style: AnalyticsSoft.text(
                                  context,
                                  12,
                                  FontWeight.w500,
                                  AnalyticsSoft.slate(context),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                    ],

                    if (!privacyActive)
                      _TimeTabs(
                        currentIndex: _timeRange,
                        onChanged: (val) {
                          if (val == 3) {
                            _showDateRangeSheet();
                            return;
                          }
                          setState(() => _timeRange = val);
                          _ensureRangeCached(val);
                        },
                      ),
                    if (!privacyActive) const SizedBox(height: 16),

                    _CashflowOverviewCard(
                      income: income,
                      expense: spent,
                      prevNet: prevPeriodTotals.income - prevPeriodTotals.spent,
                      incomeCount:
                          filtered
                              .where((t) => !t.isExpense && !t.isTransfer)
                              .length,
                      expenseCount:
                          filtered
                              .where((t) => t.isExpense && !t.isTransfer)
                              .length,
                    ),
                    const SizedBox(height: 16),

                    AnalyticsSpendingTrendCard(
                      txs: filtered,
                      historyTxs: historyForTrend,
                      timeRange: _timeRange,
                    ),
                    if (hasSpend) ...[
                      const SizedBox(height: 16),
                      AnalyticsWhereMoneyWentCard(
                        txs: filtered,
                        periodWhen: _periodWhen(),
                        onViewAll: () => context.push('/activity'),
                      ),
                    ],

                    if (!privacyActive && hasSpend) ...[
                      const SizedBox(height: 16),
                      AnalyticsPurposeBarsCard(txs: filtered),
                    ],

                    if (!privacyActive) ...[
                      const SizedBox(height: 16),
                      AnalyticsBudgetPerformanceCard(
                        allTxs: allTxs,
                        purpose:
                            _selectedPurpose == 'All'
                                ? 'Personal'
                                : _selectedPurpose,
                      ),
                    ],

                    if (!privacyActive) ...[
                      const SizedBox(height: 16),
                      AnalyticsSavingsJourneyCard(
                        allTxs: allTxs,
                        income: income,
                        spent: spent,
                        purpose:
                            _selectedPurpose == 'All'
                                ? 'Personal'
                                : _selectedPurpose,
                      ),
                    ],

                    if (hasSpend) ...[
                      const SizedBox(height: 16),
                      AnalyticsTopExpensesCard(
                        txs: filtered,
                        caption: _outflowCaption(),
                        onViewAll: () => context.push('/activity'),
                        outings:
                            privacyActive && activeOuting != null
                                ? [activeOuting]
                                : outings,
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _periodWhen() => switch (_timeRange) {
    0 => 'this month',
    1 => 'last month',
    2 => 'in the last 3 months',
    _ => 'in this range',
  };

  String _outflowCaption() => switch (_timeRange) {
    0 => 'Largest outflows this month',
    1 => 'Largest outflows last month',
    2 => 'Largest outflows in the last 3 months',
    _ => 'Largest outflows in this range',
  };
}

class _AnalyticsHeader extends StatelessWidget {
  const _AnalyticsHeader({
    required this.title,
    required this.subtitle,
    required this.initials,
    required this.hasUnread,
    required this.onNotifications,
    required this.onProfile,
  });

  final String title;
  final String subtitle;
  final String initials;
  final bool hasUnread;
  final VoidCallback onNotifications;
  final VoidCallback onProfile;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: AnalyticsSoft.text(
                  context,
                  20,
                  FontWeight.w700,
                  AnalyticsSoft.ink(context),
                ),
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: AnalyticsSoft.text(
                  context,
                  12,
                  FontWeight.w500,
                  AnalyticsSoft.muted(context),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 12),
        Material(
          color: AnalyticsSoft.card(context),
          shape: const CircleBorder(),
          child: InkWell(
            onTap: onNotifications,
            customBorder: const CircleBorder(),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AnalyticsSoft.card(context),
                border: Border.all(color: AnalyticsSoft.border(context)),
                boxShadow: AnalyticsSoft.shadow(context),
              ),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Icon(
                    LucideIcons.bell,
                    size: 18,
                    color: AnalyticsSoft.slate(context),
                  ),
                  if (hasUnread)
                    Positioned(
                      top: 8,
                      right: 8,
                      child: Container(
                        width: 8,
                        height: 8,
                        decoration: BoxDecoration(
                          color: AnalyticsSoft.emerald,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: AnalyticsSoft.card(context),
                            width: 1.5,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        GestureDetector(
          onTap: onProfile,
          child: Container(
            width: 40,
            height: 40,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AnalyticsSoft.mint(context),
              border: Border.all(color: AnalyticsSoft.mintMid(context)),
            ),
            child: Text(
              initials,
              style: AnalyticsSoft.text(
                context,
                12,
                FontWeight.w700,
                AnalyticsSoft.emeraldDeep,
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _TimeTabs extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onChanged;
  const _TimeTabs({required this.currentIndex, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    const labels = ['This Month', 'Previous Month', 'Last 3 Months', 'Custom'];
    return FittedBox(
      fit: BoxFit.scaleDown,
      alignment: Alignment.centerLeft,
      child: Row(
        children: List.generate(labels.length, (i) {
          final selected = currentIndex == i;
          return Padding(
            padding: EdgeInsets.only(right: i == labels.length - 1 ? 0 : 8),
            child: GestureDetector(
              onTap: () => onChanged(i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 10,
                ),
                decoration: BoxDecoration(
                  color:
                      selected
                          ? AnalyticsSoft.emerald
                          : AnalyticsSoft.card(context),
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(
                    color:
                        selected
                            ? AnalyticsSoft.emerald
                            : AnalyticsSoft.border(context),
                  ),
                  boxShadow:
                      selected && !AnalyticsSoft.dark(context)
                          ? const [
                            BoxShadow(
                              color: Color.fromRGBO(16, 185, 129, 0.28),
                              offset: Offset(0, 6),
                              blurRadius: 16,
                            ),
                          ]
                          : AnalyticsSoft.shadow(context),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (i == 3) ...[
                      Icon(
                        LucideIcons.calendar,
                        size: 13,
                        color:
                            selected
                                ? Colors.white
                                : AnalyticsSoft.slate(context),
                      ),
                      const SizedBox(width: 5),
                    ],
                    Text(
                      labels[i],
                      style: AnalyticsSoft.text(
                        context,
                        13,
                        selected ? FontWeight.w700 : FontWeight.w600,
                        selected ? Colors.white : AnalyticsSoft.slate(context),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}

class _CashflowOverviewCard extends StatelessWidget {
  final double income;
  final double expense;
  final double prevNet;
  final int incomeCount;
  final int expenseCount;

  const _CashflowOverviewCard({
    required this.income,
    required this.expense,
    required this.prevNet,
    required this.incomeCount,
    required this.expenseCount,
  });

  @override
  Widget build(BuildContext context) {
    final net = income - expense;
    final total = (income + expense).abs();
    final surplusPct = total <= 0 ? 0.0 : (income / total).clamp(0.0, 1.0);
    final outflowPct = 1.0 - surplusPct;
    final delta = prevNet == 0 ? null : ((net - prevNet) / prevNet.abs()) * 100;
    final fmt = NumberFormat.currency(
      symbol: '₹',
      decimalDigits: 0,
      locale: 'en_IN',
    );
    final up = delta != null && delta >= 0;
    final surplusFlex = (surplusPct * 1000).round();
    final outflowFlex = (outflowPct * 1000).round();

    return AnalyticsSoftCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'CASHFLOW OVERVIEW',
                  style: AnalyticsSoft.text(
                    context,
                    11,
                    FontWeight.w700,
                    AnalyticsSoft.muted(context),
                    letterSpacing: 1.2,
                  ),
                ),
              ),
              if (delta != null)
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 5,
                  ),
                  decoration: BoxDecoration(
                    color:
                        up
                            ? AnalyticsSoft.mint(context)
                            : AnalyticsSoft.rose.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        up ? LucideIcons.trendingUp : LucideIcons.trendingDown,
                        size: 13,
                        color:
                            up ? AnalyticsSoft.emeraldDeep : AnalyticsSoft.rose,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        '${up ? '+' : ''}${delta.toStringAsFixed(1)}% vs prev month',
                        style: AnalyticsSoft.text(
                          context,
                          11,
                          FontWeight.w700,
                          up ? AnalyticsSoft.emeraldDeep : AnalyticsSoft.rose,
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),
          Text.rich(
            TextSpan(
              children: [
                TextSpan(
                  text: net >= 0 ? '+' : '−',
                  style: AnalyticsSoft.text(
                    context,
                    30,
                    FontWeight.w800,
                    net >= 0 ? AnalyticsSoft.emeraldDeep : AnalyticsSoft.rose,
                    height: 1,
                  ),
                ),
                TextSpan(
                  text: fmt.format(net.abs()),
                  style: AnalyticsSoft.text(
                    context,
                    30,
                    FontWeight.w800,
                    AnalyticsSoft.ink(context),
                    height: 1,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 4),
          Text(
            net >= 0 ? 'Net Cashflow Surplus' : 'Net Cashflow Deficit',
            style: AnalyticsSoft.text(
              context,
              12,
              FontWeight.w500,
              AnalyticsSoft.slate(context),
            ),
          ),
          const SizedBox(height: 16),
          ClipRRect(
            borderRadius: BorderRadius.circular(99),
            child: SizedBox(
              height: 8,
              child:
                  total <= 0
                      ? ColoredBox(color: AnalyticsSoft.track(context))
                      : Row(
                        children: [
                          if (surplusFlex > 0)
                            Expanded(
                              flex: surplusFlex.clamp(1, 1000),
                              child: const ColoredBox(
                                color: AnalyticsSoft.emerald,
                              ),
                            ),
                          if (outflowFlex > 0)
                            Expanded(
                              flex: outflowFlex.clamp(1, 1000),
                              child: const ColoredBox(
                                color: AnalyticsSoft.rose,
                              ),
                            ),
                        ],
                      ),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: const BoxDecoration(
                  color: AnalyticsSoft.emerald,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 6),
              Text(
                'Surplus ${(surplusPct * 100).round()}%',
                style: AnalyticsSoft.text(
                  context,
                  12,
                  FontWeight.w600,
                  AnalyticsSoft.slate(context),
                ),
              ),
              const Spacer(),
              Container(
                width: 8,
                height: 8,
                decoration: const BoxDecoration(
                  color: AnalyticsSoft.rose,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 6),
              Text(
                'Outflow ${(outflowPct * 100).round()}%',
                style: AnalyticsSoft.text(
                  context,
                  12,
                  FontWeight.w600,
                  AnalyticsSoft.slate(context),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _flowCell(
                  context,
                  amount: '+${fmt.format(income)}',
                  amountColor: AnalyticsSoft.emeraldDeep,
                  meta: 'Income · $incomeCount Credits',
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _flowCell(
                  context,
                  amount: '−${fmt.format(expense)}',
                  amountColor: AnalyticsSoft.rose,
                  meta: 'Expense · $expenseCount Debits',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _flowCell(
    BuildContext context, {
    required String amount,
    required Color amountColor,
    required String meta,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AnalyticsSoft.slate50(context),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            amount,
            style: AnalyticsSoft.text(
              context,
              16,
              FontWeight.w800,
              amountColor,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            meta,
            style: AnalyticsSoft.text(
              context,
              11,
              FontWeight.w500,
              AnalyticsSoft.muted(context),
            ),
          ),
        ],
      ),
    );
  }
}
