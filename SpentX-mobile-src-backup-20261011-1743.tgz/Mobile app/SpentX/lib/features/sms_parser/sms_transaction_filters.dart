import 'sms_classifier.dart';
import 'sms_non_transaction_rules.dart';

/// Hard filters — ignore before any parse / template / rule matching.
class SmsTransactionFilters {
  SmsTransactionFilters._();

  /// Whether [body] states that money has already moved.
  ///
  /// Delegates to [SmsClassifier.statesMoneyMoved], which owns the one shared
  /// verb vocabulary. Exposed here as well because this is the filter layer
  /// every caller reaches for, and a second copy of the vocabulary is exactly
  /// how the gates drifted apart before.
  static bool statesMoneyMoved(String body) =>
      SmsClassifier.statesMoneyMoved(body);

  /// The amount a transaction is FOR, ignoring any balance the message quotes.
  ///
  /// Most bank SMS carry two numbers — what moved, and what is left. Two rules
  /// separate them:
  ///
  ///  1. If the message never says money moved, every number in it is
  ///     informational and there is no transaction amount at all. This is what
  ///     stops "the available balance in your A/c XX5678 ... is INR 12,418.68"
  ///     from being read as a ₹12,418 transaction — the balance wording sits
  ///     30 characters away from the number, too far for any lead-in window.
  ///  2. Otherwise, skip any amount introduced by balance wording, so
  ///     "Rs.2200 used ... Avl Bal Rs.17,800" is ₹2,200 and not ₹17,800.
  ///
  /// Returns null when the message quotes nothing but a balance.
  static double? transactionAmount(String message) {
    if (!statesMoneyMoved(message)) return null;

    for (final m in _amountWithContext.allMatches(message)) {
      final lead = message.substring(0, m.start).toLowerCase();
      if (_balanceLeadIn.hasMatch(lead)) continue;
      final value = double.tryParse(m.group(1)?.replaceAll(',', '') ?? '');
      if (value != null && value > 0) return value;
    }
    // SBI UPI "debited by 250.0" — no currency marker at all.
    final bare = RegExp(
      r'\b(?:debited|credited)\s+(?:by|for|with)\s+([0-9][0-9,]*(?:\.[0-9]{1,2})?)(?![0-9A-Za-z_/])',
      caseSensitive: false,
    ).firstMatch(message);
    final bareValue =
        double.tryParse(bare?.group(1)?.replaceAll(',', '') ?? '');
    if (bareValue != null && bareValue > 0) return bareValue;
    return null;
  }

  /// Amount with the right-boundary lookahead — a real amount is never
  /// followed by a letter, underscore or slash (`Rs899_90D_2GB`).
  static final RegExp _amountWithContext = RegExp(
    r'(?:rs\.?|inr|₹)\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)(?![0-9A-Za-z_/])',
    caseSensitive: false,
  );

  /// Balance wording immediately before an amount. The window is deliberately
  /// short: an "Avl Bal" earlier in the message must not disqualify a genuine
  /// transaction amount that comes after it.
  static final RegExp _balanceLeadIn = RegExp(
    r'(?:avl|avbl|available|closing|current|ledger)\s*(?:bal|balance)'
    r'[^0-9a-z]{0,8}$'
    r'|(?:bal|balance)\s*(?:is|:)?[^0-9a-z]{0,4}$',
    caseSensitive: false,
  );

  static String _norm(String message) =>
      message.toLowerCase().replaceAll(RegExp(r'\s+'), ' ').trim();

  static bool isFailedTransaction(String message) {
    final n = _norm(message);
    const keywords = [
      'failed',
      'unsuccessful',
      'declined',
      'insufficient funds',
      'could not be processed',
      'transaction failed',
    ];
    if (!keywords.any((k) => n.contains(k))) return false;
    // Require txn context so "failed delivery" promos are not dropped.
    return n.contains('rs') ||
        n.contains('inr') ||
        n.contains('₹') ||
        n.contains('txn') ||
        n.contains('transaction') ||
        n.contains('debited') ||
        n.contains('credited') ||
        n.contains('paid');
  }

  static bool isAdvertisement(String message) {
    final res = SmsClassifier.classify(message);
    if (res.type == SmsType.promotional) return true;
    final n = _norm(message);
    const keywords = [
      'reward',
      'rewards',
      'claim now',
      'offer',
      'holiday',
      'cashback',
      'delivery code',
      'feedback call',
      'cylinder delivery',
      'wakefit',
      'bharatgas',
      'unlocked',
    ];
    if (!keywords.any((k) => n.contains(k))) return false;
    // Promo without bank txn cues.
    final hasTxnCue = n.contains('debited') ||
        n.contains('credited') ||
        n.contains('withdrawn') ||
        n.contains('spent') ||
        n.contains('paid thru') ||
        n.contains('paid through') ||
        n.contains('deposited') ||
        (n.contains('rs') && RegExp(r'rs\.?\s*[0-9]').hasMatch(n)) ||
        (n.contains('inr') && RegExp(r'inr\s*[0-9]').hasMatch(n));
    return !hasTxnCue;
  }

  static bool isBalanceInquiry(String message) {
    final n = _norm(message);
    // Same vocabulary as every other gate (see SmsClassifier.statesMoneyMoved).
    // The local list this replaced had no 'used', so a debit-card POS message
    // — "Debit Card 7890 used Rs.2200.00 at LIFESTYLE. Avl Bal Rs.17,800" —
    // counted as a balance enquiry purely because it quotes the balance, and
    // a real spend was thrown away.
    if (SmsClassifier.statesMoneyMoved(message)) return false;

    return n.contains('available bal') ||
        n.contains('available balance') ||
        n.contains('avl bal') ||
        n.contains('a/c bal') ||
        n.contains('bal in ') ||
        n.contains('as on yesterday') ||
        n.contains('subject to clearing') ||
        n.contains('real time a/c bal') ||
        n.contains('bal dial');
  }

  static bool isNonTransaction(String message) {
    if (isBalanceInquiry(message)) return true;
    // Admin-managed + bundled structural rules (balance alerts, telecom plan
    // codes, due reminders, OTPs). Checked before the classifier so a rule
    // shipped from the backend can fix a false positive without an app build.
    if (SmsNonTransactionRules.matches(message) != null) return true;
    final res = SmsClassifier.classify(message);
    return !res.isFinancialTransaction;
  }

  /// The non-transaction rule that rejected [message], for debug logs and the
  /// Unparsed SMS list. Null when no rule fired.
  static String? nonTransactionRuleId(String message) =>
      SmsNonTransactionRules.matches(message);

  static bool shouldIgnore(String message) =>
      isFailedTransaction(message) ||
      isAdvertisement(message) ||
      isBalanceInquiry(message) ||
      isNonTransaction(message);
}