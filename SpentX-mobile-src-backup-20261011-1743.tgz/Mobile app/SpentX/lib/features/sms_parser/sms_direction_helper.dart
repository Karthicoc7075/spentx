import 'models/transaction_parsed.dart';

/// Resolves credit vs debit vs transfer from raw SMS text.
/// Raw-message keywords always win over template/parser direction so a
/// mis-trained debit template cannot mark a credit SMS as spent.
class SmsDirectionHelper {
  static String normalize(String message) =>
      message.toLowerCase().replaceAll(RegExp(r'\s+'), ' ').trim();

  /// Cash deposited at an ATM/CDM by the user — a self-transfer (Cash →
  /// Bank), not income. Narrower than a blanket "deposited" match: salary
  /// credit SMS also legitimately says "deposited" (e.g. "...deposited to
  /// your A/c ** by Salary-...") but never mentions the machine, so this
  /// only fires when BOTH deposit-language AND machine-language are present.
  static bool isCashDepositAtSelfMachineSms(String message) {
    final n = normalize(message);
    final mentionsDeposit = n.contains('deposited') ||
        n.contains('cash deposit') ||
        n.contains('deposit of');
    final mentionsMachine = n.contains('via atm') ||
        n.contains('via cdm') ||
        n.contains('cash deposit machine');
    return mentionsDeposit && mentionsMachine;
  }

  /// "Acct XX234 debited for Rs 450; ZOMATO credited" and "debited for
  /// Rs.250 and credited to a/c no. XXXXX5678" describe the user's money
  /// leaving: the "credited" half is the payee. When the debit wording comes
  /// first, the message is a debit even though it also says credited.
  static final RegExp _debitWord = RegExp(
    r'\bdebited\b|\b(a\s+)?debit\s+(by|of)\b|\bdeducted\b',
  );
  static final RegExp _creditWord = RegExp(
    r'\bcredited\b|\bcredit\s+alert\b|\breceived\b|\bdeposited\b|\bcredit\s+of\b',
  );

  static bool debitStatedFirst(String message) {
    final n = normalize(message);
    final d = _debitWord.firstMatch(n);
    if (d == null) return false;
    final c = _creditWord.firstMatch(n);
    return c == null || d.start < c.start;
  }

  static bool isCreditSms(String message) {
    final n = normalize(message);
    if (debitStatedFirst(message)) return false;
    final isSelfCashDeposit = isCashDepositAtSelfMachineSms(message);
    return n.contains('credited to') ||
        n.contains('credit alert') ||
        n.contains('credited') ||
        n.contains('received from') ||
        n.contains('received in') ||
        (n.contains('received') && !n.contains('debited')) ||
        n.contains('added to your account') ||
        // Deposit-language alone is ambiguous (salary credit SMS also says
        // "deposited") — only counts as credit when it's NOT an ATM/CDM
        // self-deposit, which is a transfer instead (see isTransferSms).
        (!isSelfCashDeposit &&
            (n.contains('deposited') ||
                n.contains('cash deposit') ||
                n.contains('deposit of')));
  }

  /// Opening an FD/RD moves money the user still owns. Not a spend.
  static bool isOwnHoldingTransferSms(String message) {
    final n = normalize(message);
    final holding = n.contains('fixed deposit') ||
        n.contains('recurring deposit') ||
        RegExp(r'\bfd\b').hasMatch(n) ||
        RegExp(r'\brd\b').hasMatch(n);
    return holding &&
        (n.contains('created') || n.contains('booked') || n.contains('opened'));
  }

  static bool isTransferSms(String message) {
    if (isCashDepositAtSelfMachineSms(message)) return true;
    if (isCreditSms(message)) return false;
    if (isOwnHoldingTransferSms(message)) return true;
    final n = normalize(message);
    return n.contains('withdrawn') ||
        n.contains('atm w/d') ||
        (n.contains('atm') && (n.contains('withdraw') || n.contains('cash')));
  }

  static bool isDebitSms(String message) {
    if (isCreditSms(message)) return false;
    final n = normalize(message);
    return n.contains('debited') ||
        RegExp(r'\b(a\s+)?debit\s+(by|of)\b').hasMatch(n) ||
        n.contains('spent at') ||
        (n.contains('spent') && !n.contains('credit alert')) ||
        n.contains('paid to') ||
        n.contains('sent to') ||
        n.contains('purchase') ||
        (n.contains('sent') && n.contains('debited'));
  }

  static TransactionDirection resolveDirection({
    required String rawMessage,
    TransactionParsed? parsed,
    String? fallbackType,
  }) {
    if (isCreditSms(rawMessage)) return TransactionDirection.income;
    if (isTransferSms(rawMessage)) return TransactionDirection.transfer;
    if (isDebitSms(rawMessage)) return TransactionDirection.expense;

    if (parsed != null) return parsed.direction;

    switch (fallbackType?.toLowerCase()) {
      case 'credit':
        return TransactionDirection.income;
      case 'transfer':
        return TransactionDirection.transfer;
      default:
        return TransactionDirection.expense;
    }
  }

  static bool isExpense({
    required String rawMessage,
    TransactionParsed? parsed,
    String? fallbackType,
  }) {
    return resolveDirection(
          rawMessage: rawMessage,
          parsed: parsed,
          fallbackType: fallbackType,
        ) ==
        TransactionDirection.expense;
  }

  static String typeLabel({
    required String rawMessage,
    TransactionParsed? parsed,
    String? fallbackType,
  }) {
    switch (resolveDirection(
      rawMessage: rawMessage,
      parsed: parsed,
      fallbackType: fallbackType,
    )) {
      case TransactionDirection.income:
        return 'credit';
      case TransactionDirection.transfer:
        return 'transfer';
      default:
        return 'debit';
    }
  }
}