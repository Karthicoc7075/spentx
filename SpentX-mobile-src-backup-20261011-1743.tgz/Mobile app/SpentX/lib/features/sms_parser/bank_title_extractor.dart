import 'models/transaction_parsed.dart';
import 'sms_direction_helper.dart';

/// Bank-specific title extraction. Priority inside this module:
/// 1) Bank structural rules (At/On, to, Salary-, etc.)
/// 2) UPI ID
/// 3) Sender account (**last4)
/// 4) Generic contextual patterns
class BankTitleExtractor {
  BankTitleExtractor._();

  static const _genericNoise = {
    'clearing',
    'credited',
    'deposited',
    'received',
    'balance',
    'avl bal',
    'available',
    'account',
    'bank',
    'a/c',
    'unknown',
    'tpt',
    'neft',
    'imps',
    'rtgs',
    'transfer',
    'info',
  };

  /// Returns non-null title when a bank-specific rule matches.
  static String? extractTitle(String message) {
    final trimmed = message.trim();
    if (trimmed.isEmpty) return null;

    return _hdfcCardAtOn(trimmed) ??
        _canaraUpiTo(trimmed) ??
        _canaraCreditAccount(trimmed) ??
        _hdfcSalary(trimmed) ??
        _hdfcAnnualFee(trimmed) ??
        _sbiYonoAtm(trimmed) ??
        _extractUpiId(trimmed) ??
        _genericAtOn(trimmed) ??
        _genericToRecipient(trimmed);
  }

  /// Applies bank title + direction/mode corrections on a parsed transaction.
  static TransactionParsed enrich(TransactionParsed parsed, String rawMessage) {
    final title = extractTitle(rawMessage);
    var name = (title != null && title.isNotEmpty) ? title : parsed.name;
    if (_isGenericTitle(name)) {
      final alt = extractTitle(rawMessage);
      if (alt != null && alt.isNotEmpty) name = alt;
    }

    var direction = SmsDirectionHelper.resolveDirection(
      rawMessage: rawMessage,
      parsed: parsed,
    );
    var mode = parsed.mode;

    final lower = rawMessage.toLowerCase();
    if (lower.contains('yono cash') || RegExp(r'yono\s+cash\s+rs', caseSensitive: false).hasMatch(rawMessage)) {
      name = 'SBI ATM Withdraw';
      direction = TransactionDirection.transfer;
      mode = TransactionMode.atm;
    } else if (_hdfcAnnualFee(rawMessage) != null) {
      name = _hdfcAnnualFee(rawMessage)!;
      direction = TransactionDirection.expense;
      mode = TransactionMode.card;
    } else if (RegExp(r'\bat\s+.+?\bon\s+\d{4}-\d{2}-\d{2}', caseSensitive: false, dotAll: true)
        .hasMatch(rawMessage)) {
      direction = TransactionDirection.expense;
      if (lower.contains('card')) mode = TransactionMode.card;
    }

    var upi = parsed.upiId;
    if (upi.isEmpty) {
      final extracted = _extractUpiId(rawMessage);
      if (extracted != null && extracted.isNotEmpty) upi = extracted;
    }
    if (direction == TransactionDirection.expense && upi.isEmpty) {
      final recipient = _genericToRecipient(rawMessage) ?? _canaraUpiTo(rawMessage);
      if (recipient != null && recipient.isNotEmpty && !_isGenericTitle(recipient)) {
        name = recipient;
      }
    }
    final identifier = upi.isNotEmpty ? upi : name;
    return TransactionParsed(
      amount: parsed.amount,
      direction: direction,
      bank: parsed.bank,
      accountLast4: parsed.accountLast4,
      name: name,
      rawIdentifier: identifier,
      mode: mode,
      accountFlow: (mode == TransactionMode.atm || direction == TransactionDirection.transfer)
          ? AccountFlow.cash
          : parsed.accountFlow,
      upiId: upi,
      referenceId: parsed.referenceId,
      dateTime: parsed.dateTime,
      rawMessage: parsed.rawMessage,
    );
  }

  // HDFC / card: "At MERCHANT On YYYY-MM-DD:..."
  static String? _hdfcCardAtOn(String message) {
    final m = RegExp(
      r'\bAt\s+(.+?)\s+On\s+\d{4}-\d{2}-\d{2}',
      caseSensitive: false,
      dotAll: true,
    ).firstMatch(message);
    if (m == null) return null;
    final t = _cleanTitle(m.group(1));
    return t.isEmpty ? null : t;
  }

  static String? _genericAtOn(String message) {
    final m = RegExp(
      r'\bAt\s+(.+?)\s+On\s+\d{1,2}[-/]\d{1,2}[-/]\d{2,4}',
      caseSensitive: false,
      dotAll: true,
    ).firstMatch(message);
    if (m == null) return null;
    final t = _cleanTitle(m.group(1));
    return t.isEmpty ? null : t;
  }

  // Canara UPI: "to KARTHI P" until "," or "UPI Ref"
  static String? _canaraUpiTo(String message) {
    final m = RegExp(
      r'\bto\s+(.+?)(?:\s*,|\s+UPI\s+Ref|\s+upi\s+ref|$)',
      caseSensitive: false,
      dotAll: true,
    ).firstMatch(message);
    if (m == null) return null;
    final t = _cleanTitle(m.group(1));
    if (t.isEmpty || _isGenericTitle(t)) return null;
    return t;
  }

  // Canara credit: from a/c no. XX0034 → **0034
  static String? _canaraCreditAccount(String message) {
    final lower = message.toLowerCase();
    if (!lower.contains('credited')) return null;
    final m = RegExp(
      r'from\s+a/c\s+no\.?\s*(?:xx|\*{2}|XX)(\d{4})',
      caseSensitive: false,
    ).firstMatch(message);
    if (m == null) return null;
    return '**${m.group(1)}';
  }

  // HDFC salary: after "Salary-" until ".Avl" or end
  static String? _hdfcSalary(String message) {
    final lower = message.toLowerCase();
    if (!lower.contains('salary') && !lower.contains('deposited')) return null;
    final m = RegExp(
      r'Salary-(.+?)(?:\.Avl|\.avl|\s+avl|\s+bal|$)',
      caseSensitive: false,
      dotAll: true,
    ).firstMatch(message);
    if (m != null) {
      final t = _cleanTitle(m.group(1));
      if (t.isNotEmpty && !_isGenericTitle(t)) return t;
    }
    final m2 = RegExp(
      r'for\s+[X\d\-]+-TPT-[A-Za-z]+\s+Salary-(.+?)(?:\.Avl|\.avl|$)',
      caseSensitive: false,
      dotAll: true,
    ).firstMatch(message);
    if (m2 != null) {
      final t = _cleanTitle(m2.group(1));
      if (t.isNotEmpty && !_isGenericTitle(t)) return t;
    }
    return null;
  }

  static String? _hdfcAnnualFee(String message) {
    final lower = message.toLowerCase();
    if (!lower.contains('annual fee') && !lower.contains('debit card annual')) {
      if (!RegExp(r'for:\s*debit\s+card\s+annual\s+fee', caseSensitive: false).hasMatch(message)) {
        return null;
      }
    }
    return 'HDFC Debit Card Annual Fee';
  }

  static String? _sbiYonoAtm(String message) {
    if (!RegExp(r'yono\s+cash', caseSensitive: false).hasMatch(message)) return null;
    return 'SBI ATM Withdraw';
  }

  static String? _extractUpiId(String message) {
    final m = RegExp(r'([a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+)', caseSensitive: false)
        .firstMatch(message);
    return m?.group(0);
  }

  static String? _genericToRecipient(String message) {
    final m = RegExp(
      r'(?:to|paid to|sent to)\s+(.+?)(?:\s+on\s+|\s*,|\s+UPI\s+Ref|\s+upi\s+ref|$)',
      caseSensitive: false,
      dotAll: true,
    ).firstMatch(message);
    if (m == null) return null;
    final t = _cleanTitle(m.group(1));
    return t.isEmpty || _isGenericTitle(t) ? null : t;
  }

  static String _cleanTitle(String? raw) {
    if (raw == null) return '';
    return raw
        .replaceAll(RegExp(r'\s+'), ' ')
        .replaceAll(RegExp(r'\.+$'), '')
        .trim();
  }

  static bool _isGenericTitle(String name) {
    if (name.trim().isEmpty) return true;
    final lower = name.toLowerCase().trim();
    if (lower == 'unknown') return true;
    return _genericNoise.any((g) => lower == g || lower.contains(g));
  }
}