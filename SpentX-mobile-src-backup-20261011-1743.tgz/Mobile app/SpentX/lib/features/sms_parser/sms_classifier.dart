enum SmsType {
  financialTransaction,
  accountUpdate,
  promotional,
  otp,
  bankingInfo,
}

class SmsClassificationResult {
  final SmsType type;
  final String reason;

  const SmsClassificationResult({
    required this.type,
    required this.reason,
  });

  bool get isFinancialTransaction => type == SmsType.financialTransaction;
}

/// Classifies bank SMS messages into financial transactions vs non-transactional alerts.
class SmsClassifier {
  SmsClassifier._();

  static String _normalize(String message) =>
      message.toLowerCase().replaceAll(RegExp(r'\s+'), ' ').trim();

  /// Whether [message] states that money has **already moved**.
  ///
  /// One vocabulary, shared by every gate below and by
  /// [SmsTransactionFilters], so a verb recognised in one place cannot be
  /// unknown in another. The three gates used to keep their own ad-hoc lists
  /// and disagreed: "used" and "sent" were missing from all of them, which
  /// silently dropped debit-card POS messages and the HDFC UPI
  /// "Sent Rs.X ... To PAYEE" format — one of the most common in India.
  ///
  /// Bare `used`, `paid`, `sent` and `credit` are deliberately NOT enough on
  /// their own: "data used as on", "paid holiday offer" and "credit card
  /// offer" all move no money. Each needs a currency symbol or a direction
  /// word beside it.
  static final RegExp _moneyMovedPattern = RegExp(
    r'\b(debited|credited|spent|withdrawn|withdrawal|deducted|transferred'
    r'|deposited|purchased)\b'
    r'|\bw/d\b'
    r'|\b(paid|sent|received)\s+(to|from|in|at|by|via|thru|through|rs|inr|₹)'
    r'|\bused\s+(rs|inr|₹|for|at|on\s+(your\s+)?(debit|credit)\s+card)'
    r'|\b(salary|neft|imps|rtgs|upi)\s+credit\b'
    r'|\bcredit\s+of\s+(rs|inr|₹)'
    r'|\b(neft|imps|rtgs|fd|upi)\s+of\s+(rs|inr|₹)'
    r'|\bcreated\s+from\s+a/c'
    // SBI: "has a debit by transfer of Rs 560", "a debit of Rs 560".
    r'|\b(a\s+)?debit\s+(by|of)\s+(transfer|rs|inr|₹|[0-9])',
    caseSensitive: false,
  );

  /// Money that has NOT moved yet — a reminder, a mandate, a due date.
  ///
  /// These read exactly like a real debit ("Rs.2,499.00 will be debited...")
  /// and booking them creates a transaction for money still in the account.
  /// Checked before the verb gate, because the verb is present and correct;
  /// it is the tense that disqualifies it.
  static final RegExp _futureTensePattern = RegExp(
    r'\bwill\s+be\s+(debited|deducted|credited|charged|deposited)\b'
    r'|\b(due\s+on|due\s+by|due\s+date)\b'
    r'|\btowards\s+[^.]{0,30}\bmandate\b'
    r'|\bstanding\s+instruction\b'
    r'|\bscheduled\s+(for|on)\b'
    r'|\bautopay\s+on\b'
    r'|\bwill\s+be\s+auto[- ]?debited\b',
    caseSensitive: false,
  );

  /// True when [message] states money already moved, and is not a reminder
  /// about money that is going to move.
  static bool statesMoneyMoved(String message) {
    final n = _normalize(message);
    if (_futureTensePattern.hasMatch(n)) return false;
    return _moneyMovedPattern.hasMatch(n);
  }

  static SmsClassificationResult classify(String message) {
    final n = _normalize(message);

    if (n.isEmpty) {
      return const SmsClassificationResult(
        type: SmsType.bankingInfo,
        reason: 'Empty SMS message',
      );
    }

    // 1. OTP / AUTHENTICATION CHECK
    if (_isOtp(n)) {
      return const SmsClassificationResult(
        type: SmsType.otp,
        reason: 'OTP / Login authentication code',
      );
    }

    // 2. BANKING INFORMATION / PROFILE UPDATES CHECK
    if (_isBankingInfo(n)) {
      return const SmsClassificationResult(
        type: SmsType.bankingInfo,
        reason: 'Banking information / service update',
      );
    }

    // 3. ACCOUNT UPDATE / BALANCE ALERTS CHECK
    if (_isAccountUpdate(n)) {
      return const SmsClassificationResult(
        type: SmsType.accountUpdate,
        reason: 'Account update / balance alert / statement / KYC',
      );
    }

    // 4. PROMOTIONAL SMS CHECK
    if (_isPromotional(n)) {
      return const SmsClassificationResult(
        type: SmsType.promotional,
        reason: 'Promotional / marketing offer',
      );
    }

    // 5. FINANCIAL TRANSACTION CHECK
    if (_isFinancialTransaction(n)) {
      return const SmsClassificationResult(
        type: SmsType.financialTransaction,
        reason: 'Financial transaction',
      );
    }

    // Fallback: If not clearly a financial transaction, treat as non-transactional banking info
    return const SmsClassificationResult(
      type: SmsType.bankingInfo,
      reason: 'Non-transactional banking message',
    );
  }

  static bool _isOtp(String n) {
    if (n.contains('otp') ||
        n.contains('one time password') ||
        n.contains('verification code') ||
        n.contains('auth code') ||
        (n.contains('secret code') && n.contains('share'))) {
      return true;
    }
    return false;
  }

  static bool _isBankingInfo(String n) {
    const keywords = [
      'password changed',
      'password updated',
      'profile updated',
      'beneficiary added',
      'payee added',
      'mobile number updated',
      'email updated',
      'account activated',
      'service request',
      'netbanking login',
      'login alert',
      'device registered',
      'pin changed',
    ];
    return keywords.any((k) => n.contains(k));
  }

  static bool _isAccountUpdate(String n) {
    // Explicit account update / balance alert indicators
    const keywords = [
      'minimum limit',
      'minimum balance',
      'gone below',
      'has gone below',
      'below minimum limit',
      'below minimum',
      'low balance',
      'bal gone below',
      'yesterday\'s bal',
      'yesterdays bal',
      'bal in ',
      'whatsapp banking',
      'statement available',
      'e-statement',
      'monthly statement',
      'kyc reminder',
      'update kyc',
      'kyc update',
      'card expiry',
      'card expiring',
      'expiring soon',
      're-issue',
      'bill reminder',
      'payment due date',
      'maintenance notification',
      'account maintenance',
    ];

    if (keywords.any((k) => n.contains(k))) return true;

    // A reminder about money that has not moved yet is an update, not a
    // transaction — even though it names a real amount and a real verb.
    if (_futureTensePattern.hasMatch(n)) return true;

    // Balance mentioned, but nothing actually moved.
    final containsBalPattern = n.contains('bal') || n.contains('balance');
    final hasTxnVerb = statesMoneyMoved(n);

    if (containsBalPattern && !hasTxnVerb) {
      if (n.contains('limit') ||
          n.contains('below') ||
          n.contains('avail') ||
          n.contains('avl bal') ||
          n.contains('status')) {
        return true;
      }
    }

    return false;
  }

  static bool _isPromotional(String n) {
    const keywords = [
      'pre-approved',
      'instant loan',
      'apply for',
      'apply now',
      'claim now',
      'reward points',
      'cashback offer',
      'cashback promo',
      'discount offer',
      'special offer',
      'holiday deal',
      'insurance offer',
      'credit card offer',
    ];
    if (keywords.any((k) => n.contains(k))) {
      final hasTxnVerb = n.contains('debited') ||
          n.contains('credited') ||
          n.contains('spent at') ||
          n.contains('paid to');
      return !hasTxnVerb;
    }
    return false;
  }

  static bool _isFinancialTransaction(String n) {
    // If message is classified as account update, banking info, or OTP, it is NOT a transaction
    if (_isAccountUpdate(n) || _isBankingInfo(n) || _isOtp(n)) {
      return false;
    }

    // Requires an amount indicator (₹, Rs, INR) OR explicit payment mode/action
    final hasAmount = n.contains('rs') ||
        n.contains('inr') ||
        n.contains('₹') ||
        RegExp(r'\d+(?:\.\d{1,2})?').hasMatch(n);

    if (!hasAmount) return false;

    // The message must state that money already moved. This replaced a list
    // of loose substrings ('spent', 'paid', 'purchase', 'vpa', 'utr') which
    // both let junk through and — because it had no 'sent' and required
    // 'upi ref' to be adjacent — dropped the HDFC UPI format outright.
    return statesMoneyMoved(n);
  }

}
