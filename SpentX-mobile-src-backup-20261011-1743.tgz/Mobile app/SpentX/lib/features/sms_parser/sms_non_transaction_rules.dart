import 'dart:convert';

import 'package:hive/hive.dart';

import '../sms/rules/sms_hive_boxes.dart';
import 'sms_classifier.dart';

/// The 19 non-transaction rules — messages that name a real amount but move no
/// money (balance alerts, telecom plan codes, due reminders, failed txns, OTPs).
///
/// Two sources, admin first:
///
///   1. `sms_block_rules`, pulled by [SmsRulesRefreshService] into Hive. An
///      admin can add or correct a rule and every device picks it up within a
///      day, with no app release.
///   2. `assets/sms/sms_block_rules_seed.json`, bundled, as the offline
///      fallback — a fresh install with no network still rejects the junk.
///
/// Kept separate from the user's own block rules (`SmsRuleEngine.isBlocked`):
/// those are personal ("never track my landlord"), these are structural facts
/// about what a bank SMS means. Mixing them would let a rules refresh wipe a
/// user's own rules, or let a user delete a rule that protects the ledger.
///
/// Deliberately free of any Flutter import: this sits in the filter chain that
/// `tool/` scripts import from a plain Dart VM, and pulling `rootBundle` in
/// here would make the whole chain unimportable outside Flutter. Reading the
/// asset is therefore somebody else's job — see [SmsNonTransactionRulesLoader]
/// — and this class only takes the JSON it is handed.
///
/// Matching is synchronous because [SmsRuleEngine.parse] is, and sits on the
/// live SMS path. Until [loadFromJson] has run, [matches] returns null and the
/// other filters still apply.
class SmsNonTransactionRules {
  SmsNonTransactionRules._();

  static List<_CompiledRule>? _bundled;

  static bool get isLoaded => _bundled != null;
  static int get ruleCount => _bundled?.length ?? 0;

  /// Compile the rule set from the seed JSON. Called by
  /// [SmsNonTransactionRulesLoader] at startup, and directly by tests.
  static void loadFromJson(String jsonText) {
    try {
      final root = jsonDecode(jsonText) as Map<String, dynamic>;
      final rows = (root['rows'] as List?) ?? const [];
      _bundled = rows
          .whereType<Map>()
          .map(_CompiledRule.fromRow)
          .whereType<_CompiledRule>()
          .toList();
    } catch (_) {
      // Malformed seed must not disable detection outright — the classifier
      // gates still run. Empty means "no extra rules".
      _bundled = const [];
    }
  }

  /// Marks the set as loaded-but-empty, for a device where the asset is
  /// missing. Keeps [isLoaded] honest instead of retrying forever.
  static void markUnavailable() => _bundled ??= const [];

  /// The id of the first rule that says [message] is not a transaction, or
  /// null when none does.
  ///
  /// Admin rules are consulted first so a correction shipped from the backend
  /// wins over the bundled copy of the same rule.
  static String? matches(String message) {
    if (message.trim().isEmpty) return null;

    // Rules of the form `^(?!.*<verbs>)...` mean "no transaction verb
    // anywhere". Each carries its own frozen copy of the verb list, so a verb
    // added to [SmsClassifier] later ("a debit by transfer of Rs 560") is
    // still judged verb-less by them and a real spend is thrown away. When
    // the classifier says money moved, those rules do not apply.
    final moved = SmsClassifier.statesMoneyMoved(message);

    final fromAdmin = _matchAdminRules(message, skipNoVerbRules: moved);
    if (fromAdmin != null) return fromAdmin;

    for (final rule in _bundled ?? const <_CompiledRule>[]) {
      if (moved && rule.isNoVerbRule) continue;
      if (rule.matches(message)) return rule.id;
    }
    return null;
  }

  static bool _isNoVerbPattern(String pattern) =>
      pattern.trimLeft().startsWith('^(?!');

  /// Admin-pulled rows in the block-rules box that came from the backend.
  ///
  /// Only rows flagged `fromAdmin` (set by [RuleTableMap.blockToLocal]) are
  /// read here; a user's own rules stay with [SmsRuleEngine.isBlocked].
  static String? _matchAdminRules(
    String message, {
    bool skipNoVerbRules = false,
  }) {
    if (!Hive.isBoxOpen(SmsHiveBoxes.blockRules)) return null;
    try {
      final box = Hive.box<dynamic>(SmsHiveBoxes.blockRules);
      for (final raw in box.values) {
        if (raw is! Map) continue;
        if (raw['fromAdmin'] != true) continue;
        final pattern = raw['pattern']?.toString() ?? '';
        if (pattern.isEmpty) continue;
        if (skipNoVerbRules && _isNoVerbPattern(pattern)) continue;
        try {
          if (RegExp(pattern, caseSensitive: false).hasMatch(message)) {
            return raw['id']?.toString() ?? 'admin_block_rule';
          }
        } catch (_) {
          // A bad regex from the backend must not break the whole pass.
        }
      }
    } catch (_) {}
    return null;
  }
}

class _CompiledRule {
  final String id;
  final String category;
  final RegExp regex;

  const _CompiledRule({
    required this.id,
    required this.category,
    required this.regex,
  });

  bool matches(String message) => regex.hasMatch(message);

  bool get isNoVerbRule =>
      SmsNonTransactionRules._isNoVerbPattern(regex.pattern);

  static _CompiledRule? fromRow(Map<dynamic, dynamic> row) {
    if (row['is_active'] == false) return null;
    final pattern = row['pattern']?.toString() ?? '';
    if (pattern.isEmpty) return null;
    try {
      return _CompiledRule(
        id: row['rule_id']?.toString() ?? 'nt_rule',
        category: row['category']?.toString() ?? '',
        regex: RegExp(
          pattern,
          caseSensitive: row['case_sensitive'] == true,
          multiLine: true,
        ),
      );
    } catch (_) {
      // Skip a rule that will not compile rather than losing all 19.
      return null;
    }
  }
}
