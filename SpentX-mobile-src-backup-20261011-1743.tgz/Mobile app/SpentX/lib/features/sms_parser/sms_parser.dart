import 'models/transaction_parsed.dart';
import 'sms_direction_helper.dart';
import 'sms_transaction_filters.dart';
import 'bank_title_extractor.dart';
import '../../core/utils/bank_keywords.dart';

class UniversalSmsParser {
  static TransactionParsed? parseSms(String message) {
    if (message.trim().isEmpty) return null;

    // STEP 1: NORMALIZE MESSAGE
    final originalMessage = message;
    final normalized = message.toLowerCase().replaceAll(RegExp(r'\s+'), ' ');

    if (SmsTransactionFilters.shouldIgnore(message)) return null;

    // STEP 2: DETECT TRANSACTION TYPE & VALIDATE
    final isCredit = SmsDirectionHelper.isCreditSms(message);
    final isDebit = SmsDirectionHelper.isDebitSms(message);
    final isTransferType = SmsDirectionHelper.isTransferSms(message);
    final isTransaction = isCredit || isDebit || isTransferType;

    if (!isTransaction) return null; // Ignore non-transactional messages (like balance alerts)

    var direction = SmsDirectionHelper.resolveDirection(rawMessage: message);
    TransactionMode mode = TransactionMode.unknown;

    // STEP 3: EXTRACT AMOUNT
    // Right-boundary lookahead: a real amount is never followed by a letter,
    // underscore or slash. Without it `Rs899_90D_2GB` (a telecom plan code)
    // parsed as ₹899 and became a spend.
    final amountPattern = RegExp(
        r'(?:rs\.?|inr|₹)\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)(?![0-9A-Za-z_/])',
        caseSensitive: false);
    final amountMatch = amountPattern.firstMatch(normalized);
    // SBI UPI: "A/C X1234 debited by 250.0 on date 10Oct26" carries no
    // Rs/INR at all. Accept a bare number only right after the verb.
    final valStr = (amountMatch?.group(1) ?? bareVerbAmount(normalized) ?? '')
        .replaceAll(',', '');
    if (valStr.isEmpty) return null; // No amount, not a transaction
    final amount = double.tryParse(valStr);
    if (amount == null || amount <= 0) return null;

    // STEP 4: EXTRACT BANK NAME (whole words only, UPI handles ignored —
    // "swiggy@icici" is the payee's PSP, not the user's bank)
    final bankKey = resolveBankKey(message);
    final bankName = bankKey.isEmpty ? 'Unknown' : bankDisplayName(bankKey);

    // STEP 5: EXTRACT ACCOUNT LAST 4 (account/card context only)
    final last4 = extractAccountLast4(message);
    final accountLast4 = last4.isEmpty ? 'Unknown' : last4;

    // STEP 6: EXTRACT TITLE & UPI (bank-specific first)
    String name = BankTitleExtractor.extractTitle(message) ?? _extractName(message);
    String upiId = _extractUpi(message);

    if (isCredit && (name.toLowerCase() == 'unknown' || _isGenericNoise(name))) {
      final alt = _extractStableSourceForCredit(message);
      if (alt.isNotEmpty) name = alt;
    }

    // STEP 7: EXTRACT DATE & TIME
    DateTime dateTime = _extractDateTime(message);

    // STEP 8: EXTRACT REFERENCE ID
    final refPattern = RegExp(r'(?:ref|upi ref|upi ref no|txn|utr|id|ref no|upi)\s*:?\s*([0-9a-z]{6,})', caseSensitive: false);
    final refMatch = refPattern.firstMatch(normalized);
    final referenceId = refMatch?.group(1) ?? '';
    
    // STEP 8.5: ATM / transfer overrides
    if (normalized.contains('yono cash')) {
      name = 'SBI ATM Withdraw';
      mode = TransactionMode.atm;
      direction = TransactionDirection.transfer;
    }

    // STEP 9: DETECT MODE (General fallback)
    if (mode == TransactionMode.unknown) {
      if (normalized.contains('upi')) {
        mode = TransactionMode.upi;
      } else if (normalized.contains('atm') || normalized.contains('cash')) {
        mode = TransactionMode.atm;
      } else if (normalized.contains('card') || normalized.contains('visa') || normalized.contains('mastercard')) {
        mode = TransactionMode.card;
      }
    }

    // STEP 10: CLASSIFY ACCOUNT FLOW
    AccountFlow accountFlow = AccountFlow.external;
    if (mode == TransactionMode.atm || direction == TransactionDirection.transfer) {
      accountFlow = AccountFlow.cash;
    }

    // Debit: prefer recipient/UPI over sender-style "from" names.
    if (isDebit && !isTransferType) {
      if (upiId.isNotEmpty) {
        name = upiId;
      } else {
        final recipientTitle = BankTitleExtractor.extractTitle(message);
        if (recipientTitle != null &&
            recipientTitle.isNotEmpty &&
            !_isGenericNoise(recipientTitle)) {
          name = recipientTitle;
        }
      }
    }

    final stableId = upiId.isNotEmpty ? upiId : name;

    return TransactionParsed(
      amount: amount,
      direction: direction,
      bank: bankName,
      accountLast4: accountLast4,
      name: name,
      rawIdentifier: stableId,
      mode: mode,
      accountFlow: accountFlow,
      referenceId: referenceId,
      upiId: upiId,
      dateTime: dateTime,
      rawMessage: originalMessage,
    );
  }

  /// "debited by 250.0", "credited by Rs500", "debited for 1,200" — the
  /// amount right after the verb when the message has no currency marker.
  static String? bareVerbAmount(String normalized) {
    final m = RegExp(
      r'\b(?:debited|credited)\s+(?:by|for|with)\s+(?:rs\.?|inr|₹)?\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)(?![0-9a-z_/])',
      caseSensitive: false,
    ).firstMatch(normalized);
    return m?.group(1);
  }

  static String _extractUpi(String text) {
    final upiPattern = RegExp(r'([a-zA-Z0-9._-]+)@([a-zA-Z0-9.-]+)', caseSensitive: false);
    final match = upiPattern.firstMatch(text);
    return match?.group(0) ?? '';
  }

  static String _extractName(String text) {
    final originalLines = text.split(RegExp(r'\n|\r\n'));
    final bankKeywords = ['hdfc', 'sbi', 'icici', 'axis', 'kotak', 'pnb', 'bob', 'canara', 'yono', 'union', 'bank', 'account', 'a/c', 'card', 'bank', 'linked'];
    
    // Patterns with capture groups
    final upiPattern = RegExp(r'([a-zA-Z0-9._-]+)@([a-zA-Z0-9.-]+)', caseSensitive: false);
    final toPattern = RegExp(r'(?:to|paid to|sent to)\s+([A-Za-z0-9. ]+?)(?=\s+on|\s+at|\s+bal|\s+ref|$)', caseSensitive: false);
    final atPattern = RegExp(r'(?:at|spent at|at atm|merchant)\s+([A-Za-z0-9. ]+?)(?=\s+on|\s+at|\s+bal|\s+ref|$)', caseSensitive: false);
    final fromPattern = RegExp(r'from\s+([A-Za-z0-9. ]+?)(?=\s+on|\s+at|\s+bal|\s+ref|$)', caseSensitive: false);
    final upiSlashedPattern = RegExp(r'UPI/(?:P2A|P2M)/[0-9]+/([A-Za-z0-9. ]+)', caseSensitive: false);
    final forPattern = RegExp(r'(?:for|info|salary|payroll)\s*[:\-]?\s*([A-Za-z0-9.&\- ]+)', caseSensitive: false);

    for (final line in originalLines) {
      final cleanLine = line.trim();
      if (cleanLine.isEmpty) continue;
      
      // Try patterns in order of priority
      
      // 1) UPI
      final upiMatch = upiPattern.firstMatch(cleanLine);
      if (upiMatch != null) {
        String name = upiMatch.group(1)!;
        if (RegExp(r'^\d+$').hasMatch(name)) return _titleCase('${upiMatch.group(1)}@${upiMatch.group(2)}');
        if (!_isGenericNoise(name)) return _titleCase(name);
      }

      // 2) Slashed UPI (Axis)
      final slashMatch = upiSlashedPattern.firstMatch(cleanLine);
      if (slashMatch != null) {
        final v = slashMatch.group(1)!.trim();
        if (!_isGenericNoise(v)) return _titleCase(v);
      }

      // 3) "At" (Merchant) - Highest priority for expenses
      final atMatch = atPattern.firstMatch(cleanLine);
      if (atMatch != null) {
        String val = atMatch.group(1)!.trim();
        if (val.length > 2 && !_isBankName(val, bankKeywords) && !_isGenericNoise(val)) return _titleCase(val);
      }

      // 4) "To" (Recipient)
      final toMatch = toPattern.firstMatch(cleanLine);
      if (toMatch != null) {
        String val = toMatch.group(1)!.trim();
        if (val.length > 2 && !_isBankName(val, bankKeywords) && !_isGenericNoise(val)) return _titleCase(val);
      }

      // 5) "For: [Purpose]" / salary ref
      final forMatch = forPattern.firstMatch(cleanLine);
      if (forMatch != null) {
        String val = forMatch.group(1)!.trim();
        if (val.length > 2 && !_isBankName(val, bankKeywords) && !_isGenericNoise(val)) return _titleCase(val);
      }

      // 6) "From a/c no. XX0034"
      final fromAccountPattern = RegExp(r'from a/c no\. (?:xx|\*)(\d{4})', caseSensitive: false);
      final fromAccMatch = fromAccountPattern.firstMatch(cleanLine);
      if (fromAccMatch != null) return 'From **${fromAccMatch.group(1)}';

      // 7) General "From" (Lowest priority)
      final fromMatch = fromPattern.firstMatch(cleanLine);
      if (fromMatch != null) {
        String val = fromMatch.group(1)!.trim();
        if (val.length > 2 && !_isBankName(val, bankKeywords) && !_isGenericNoise(val)) return _titleCase(val);
      }
    }

    // Salary/credit employer/company priority for stable identifier (not varying ref text like "May Salary-...")
    final lowerText = text.toLowerCase();
    if (lowerText.contains('salary') || lowerText.contains('payroll') || lowerText.contains('salary credit') || lowerText.contains('salary deposit')) {
      final salPatterns = <RegExp>[
        RegExp(r'Salary[-:\s]+([A-Za-z0-9.&\- ]+?)(?:\.|\s+on|\s+avl|\s+bal|$)', caseSensitive: false),
        RegExp(r'(?:salary|payroll)[^\w]*([A-Za-z0-9.&\- ]+?)(?:\.|\s+on|\s+avl|\s+bal|$)', caseSensitive: false),
        RegExp(r'(?:from|by)\s+([A-Za-z0-9.&\- ]+?)\s*(?:salary|payroll)', caseSensitive: false),
        RegExp(r'for\s+[x\d\-]+[a-z\s\-]*?([A-Za-z0-9.&\- ]+?)(?:\.|$)', caseSensitive: false),
      ];
      for (final pat in salPatterns) {
        final m = pat.firstMatch(text);
        if (m != null) {
          String v = m.group(1)!.trim();
          if (v.length > 2 && !_isBankName(v, bankKeywords) && !_isGenericNoise(v) && !RegExp(r'^[\d\s\-]+$').hasMatch(v)) {
            return _titleCase(v);
          }
        }
      }
    }

    // Fallback credit source (credited from / deposited by style for sender-based)
    final credMatch = RegExp(r'(?:credited|deposited|received|added)\s+(?:from|by|in)?\s*([A-Za-z0-9.&\- ]+?)(?=\s+on|\s+avl|\s+bal|\s+ref|$)', caseSensitive: false).firstMatch(text);
    if (credMatch != null) {
      String v = credMatch.group(1)!.trim();
      if (v.length > 2 && !_isBankName(v, bankKeywords) && !_isGenericNoise(v)) {
        return _titleCase(v);
      }
    }

    return 'Unknown';
  }

  static bool _isGenericNoise(String val) {
    if (val.trim().isEmpty) return true;
    final lower = val.toLowerCase().trim();
    const noise = [
      'clearing', 'credited', 'deposited', 'deposited in', 'received', 'received in',
      'balance', 'avl bal', 'avl', 'available', 'account', 'hdfc bank', 'sbi bank',
      'icici bank', 'axis bank', 'kotak bank', 'bank', 'a/c', 'xx', 'unknown',
      'tpt', 'neft', 'imps', 'rtgs', 'transfer', 'salary credit', 'payroll credit',
      'info', 'ref', 'tp t'
    ];
    return noise.any((g) => lower == g || lower.contains(g));
  }

  static String _extractStableSourceForCredit(String text) {
    final lowerText = text.toLowerCase();
    if (lowerText.contains('salary') || lowerText.contains('payroll')) {
      final pats = [
        RegExp(r'Salary[-:\s]+([A-Za-z0-9.&\- ]+?)(?:\.|$)', caseSensitive: false),
        RegExp(r'(?:salary|payroll)[^\w]*([A-Za-z0-9.&\- ]+?)(?:\.|$)', caseSensitive: false),
      ];
      for (final p in pats) {
        final m = p.firstMatch(text);
        if (m != null) {
          final v = m.group(1)!.trim();
          if (v.length > 2 && !_isGenericNoise(v)) return _titleCase(v);
        }
      }
    }
    final m = RegExp(r'(?:from|by)\s+([A-Za-z0-9.&\- ]+?)(?:\s+salary|\s+payroll|\.|$)', caseSensitive: false).firstMatch(text);
    if (m != null) {
      final v = m.group(1)!.trim();
      if (v.length > 2 && !_isGenericNoise(v)) return _titleCase(v);
    }
    return '';
  }

  static bool _isBankName(String val, List<String> keywords) {
    final lower = val.toLowerCase();
    if (keywords.any((k) => lower == k || lower.contains('bank') || lower.contains('account') || lower.contains(' a/c'))) return true;
    return _isGenericNoise(val);
  }

  static String _titleCase(String text) {
    if (text.isEmpty) return text;
    // Strip trailing dots or spaces
    String cleaned = text.replaceAll(RegExp(r'\.+$'), '').trim();
    if (cleaned.isEmpty) return "Unknown";

    return cleaned.split(' ').map((word) {
      if (word.isEmpty) return "";
      return word[0].toUpperCase() + word.substring(1).toLowerCase();
    }).join(' ');
  }

  static DateTime _extractDateTime(String text) {
    // Never guess: if year (4 digits) appears first in a date-like token, treat as YYYY-MM-DD always.
    // Supported:
    //   YYYY-MM-DD:HH:mm:ss
    //   YYYY-MM-DD HH:mm:ss
    //   DD-MM-YY HH:mm:ss
    //   DD/MM/YY HH:mm
    //   DD-MMM-YY
    // Use lookbehind/look ahead to avoid matching substrings inside YYYY-MM-DD (e.g. 26-06-08 from 2026-...).

    // 1) YYYY-MM-DD with time (colon or space sep) e.g. 2026-06-08:09:02:01 or 2026-06-08 09:02:01
    final ymdTimePattern = RegExp(
      r'(?<![0-9])(\d{4})-(\d{2})-(\d{2})(?:[T\s:]+)(\d{2}):(\d{2})(?::(\d{2}))?(?![0-9])',
      caseSensitive: false,
    );
    final ymdTimeMatch = ymdTimePattern.firstMatch(text);
    if (ymdTimeMatch != null) {
      try {
        return DateTime(
          int.parse(ymdTimeMatch.group(1)!),
          int.parse(ymdTimeMatch.group(2)!),
          int.parse(ymdTimeMatch.group(3)!),
          int.parse(ymdTimeMatch.group(4)!),
          int.parse(ymdTimeMatch.group(5)!),
          ymdTimeMatch.group(6) != null ? int.parse(ymdTimeMatch.group(6)!) : 0,
        );
      } catch (_) {}
    }

    // 2) YYYY-MM-DD (date only)
    final ymdPattern = RegExp(r'(?<![0-9])(\d{4})-(\d{2})-(\d{2})(?![0-9])');
    final ymdMatch = ymdPattern.firstMatch(text);
    if (ymdMatch != null) {
      try {
        final year = int.parse(ymdMatch.group(1)!);
        final month = int.parse(ymdMatch.group(2)!);
        final day = int.parse(ymdMatch.group(3)!);
        final now = DateTime.now();
        return DateTime(year, month, day, now.hour, now.minute, now.second);
      } catch (_) {}
    }

    // 3) DD-MMM-YY (with optional time) e.g. 08-Jun-26 or 08-Jun-2026 09:02
    final dmmmyPattern = RegExp(
      r'(?<![0-9])(\d{1,2})[- ]+([A-Za-z]{3})[- ]+(\d{2,4})(?![0-9])',
      caseSensitive: false,
    );
    final dmmmyMatch = dmmmyPattern.firstMatch(text);
    if (dmmmyMatch != null) {
      try {
        final day = int.parse(dmmmyMatch.group(1)!);
        final monStr = dmmmyMatch.group(2)!.toLowerCase();
        int month = _monthFromAbbr(monStr);
        if (month == 0) month = 1;
        var year = int.parse(dmmmyMatch.group(3)!);
        if (year < 100) year += 2000;

        final timePattern = RegExp(r'(\d{1,2}):(\d{2})(?::(\d{2}))?');
        final timeMatch = timePattern.firstMatch(text);
        if (timeMatch != null) {
          final hour = int.parse(timeMatch.group(1)!);
          final min = int.parse(timeMatch.group(2)!);
          final sec = timeMatch.group(3) != null ? int.parse(timeMatch.group(3)!) : 0;
          return DateTime(year, month, day, hour, min, sec);
        }
        final now = DateTime.now();
        return DateTime(year, month, day, now.hour, now.minute, now.second);
      } catch (_) {}
    }

    // 4) DD-MM-YY / DD/MM/YY (with optional time) — guarded so it doesn't substring YYYY dates
    final dmyPattern = RegExp(r'(?<![0-9])(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})(?![0-9])');
    final dmyMatch = dmyPattern.firstMatch(text);
    if (dmyMatch != null) {
      try {
        int day = int.parse(dmyMatch.group(1)!);
        int month = int.parse(dmyMatch.group(2)!);
        int year = int.parse(dmyMatch.group(3)!);
        if (year < 100) year += 2000;

        final timePattern = RegExp(r'(\d{1,2}):(\d{2})(?::(\d{2}))?');
        final timeMatch = timePattern.firstMatch(text);
        if (timeMatch != null) {
          int hour = int.parse(timeMatch.group(1)!);
          int min = int.parse(timeMatch.group(2)!);
          int sec = timeMatch.group(3) != null ? int.parse(timeMatch.group(3)!) : 0;
          return DateTime(year, month, day, hour, min, sec);
        }
        final now = DateTime.now();
        return DateTime(year, month, day, now.hour, now.minute, now.second);
      } catch (_) {}
    }

    return DateTime.now();
  }

  static int _monthFromAbbr(String abbr) {
    const months = {
      'jan': 1, 'feb': 2, 'mar': 3, 'apr': 4, 'may': 5, 'jun': 6,
      'jul': 7, 'aug': 8, 'sep': 9, 'oct': 10, 'nov': 11, 'dec': 12,
    };
    return months[abbr.toLowerCase()] ?? 0;
  }
}
