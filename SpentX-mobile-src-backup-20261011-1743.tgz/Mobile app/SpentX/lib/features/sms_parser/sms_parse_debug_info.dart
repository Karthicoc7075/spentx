class SmsParseDebugInfo {
  final String? detectedTitle;
  final String? detectedType;
  final String? matchedTemplate;
  final String? matchedRule;
  final String source;

  const SmsParseDebugInfo({
    this.detectedTitle,
    this.detectedType,
    this.matchedTemplate,
    this.matchedRule,
    this.source = 'none',
  });
}