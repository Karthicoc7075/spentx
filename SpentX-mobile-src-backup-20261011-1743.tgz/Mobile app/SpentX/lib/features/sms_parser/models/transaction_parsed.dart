enum TransactionDirection {
  expense,
  income,
  transfer
}

enum TransactionMode {
  upi,
  atm,
  card,
  cash,
  unknown
}

enum AccountFlow {
  personal,
  home,
  cash,
  external
}

class TransactionParsed {
  final double amount;
  final TransactionDirection direction;
  final String bank;
  final String accountLast4;
  final String name;
  final String rawIdentifier;
  final TransactionMode mode;
  final AccountFlow accountFlow;

  final String upiId;
  final String referenceId;
  final DateTime dateTime;
  final String rawMessage;

  TransactionParsed({
    required this.amount,
    required this.direction,
    required this.bank,
    required this.accountLast4,
    required this.name,
    required this.rawIdentifier,
    required this.mode,
    required this.accountFlow,
    this.upiId = '',
    this.referenceId = '',
    required this.dateTime,
    this.rawMessage = '',
  });

  Map<String, dynamic> toJson() {
    return {
      'amount': amount,
      'direction': direction.toString().split('.').last,
      'bank': bank,
      'accountLast4': accountLast4,
      'name': name,
      'rawIdentifier': rawIdentifier,
      'mode': mode.toString().split('.').last,
      'accountFlow': accountFlow.toString().split('.').last,
      'referenceId': referenceId,
      'upiId': upiId,
      'dateTime': dateTime.toIso8601String(),
      'rawMessage': rawMessage,
    };
  }

  @override
  String toString() {
    return 'TransactionParsed(amount: $amount, direction: $direction, bank: $bank, name: $name, mode: $mode, ref: $referenceId)';
  }
}
