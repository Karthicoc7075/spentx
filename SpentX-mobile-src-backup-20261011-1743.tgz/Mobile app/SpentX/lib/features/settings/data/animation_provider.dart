import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';

enum AppAnimationStyle {
  smooth,
  fast,
  premium,
  reduceMotion,
  material,
  iosStyle,
  androidNative,
  dynamicStyle,
  elegant,
  playful,
  batterySaver,
  minimal,
}

extension AppAnimationStyleX on AppAnimationStyle {
  String get label {
    switch (this) {
      case AppAnimationStyle.smooth:
        return 'Smooth (Recommended)';
      case AppAnimationStyle.fast:
        return 'Fast';
      case AppAnimationStyle.premium:
        return 'Premium ✨';
      case AppAnimationStyle.reduceMotion:
        return 'Reduce Motion';
      case AppAnimationStyle.material:
        return 'Material Motion';
      case AppAnimationStyle.iosStyle:
        return 'iOS Style';
      case AppAnimationStyle.androidNative:
        return 'Android Native';
      case AppAnimationStyle.dynamicStyle:
        return 'Dynamic';
      case AppAnimationStyle.elegant:
        return 'Elegant';
      case AppAnimationStyle.playful:
        return 'Playful';
      case AppAnimationStyle.batterySaver:
        return 'Battery Saver';
      case AppAnimationStyle.minimal:
        return 'Minimal';
    }
  }

  String get subtitle {
    switch (this) {
      case AppAnimationStyle.smooth:
        return 'Gentle fades & smooth slide transitions (Default)';
      case AppAnimationStyle.fast:
        return 'Short 100-150ms animations for power users';
      case AppAnimationStyle.premium:
        return 'Luxurious card lifts & count-up numbers';
      case AppAnimationStyle.reduceMotion:
        return 'Essential fades only, no zoom or bounce';
      case AppAnimationStyle.material:
        return 'Material Design container transforms';
      case AppAnimationStyle.iosStyle:
        return 'Apple-style spring transitions & elastic scrolling';
      case AppAnimationStyle.androidNative:
        return 'Native Android system transitions & ripples';
      case AppAnimationStyle.dynamicStyle:
        return 'Context-aware animation speeds';
      case AppAnimationStyle.elegant:
        return 'Refined, slower transitions for luxury feel';
      case AppAnimationStyle.playful:
        return 'Bouncy micro-interactions and celebration effects';
      case AppAnimationStyle.batterySaver:
        return 'Minimal GPU load for maximum battery life';
      case AppAnimationStyle.minimal:
        return 'Instant navigation with subtle crossfades';
    }
  }

  double get speedMultiplier {
    switch (this) {
      case AppAnimationStyle.fast:
      case AppAnimationStyle.batterySaver:
      case AppAnimationStyle.minimal:
        return 0.5;
      case AppAnimationStyle.elegant:
        return 1.4;
      case AppAnimationStyle.playful:
        return 1.2;
      default:
        return 1.0;
    }
  }
}

class AnimationSettingsState {
  final bool enabled;
  final AppAnimationStyle style;

  const AnimationSettingsState({
    required this.enabled,
    required this.style,
  });

  AnimationSettingsState copyWith({
    bool? enabled,
    AppAnimationStyle? style,
  }) {
    return AnimationSettingsState(
      enabled: enabled ?? this.enabled,
      style: style ?? this.style,
    );
  }

  bool get isAnimated => enabled && style != AppAnimationStyle.reduceMotion;

  Duration getDuration(Duration normalDuration) {
    if (!isAnimated) return Duration.zero;
    final ms = (normalDuration.inMilliseconds * style.speedMultiplier).round();
    return Duration(milliseconds: ms.clamp(50, 2000));
  }

  Curve getCurve([Curve defaultCurve = Curves.easeOutCubic]) {
    if (!isAnimated) return Curves.linear;
    switch (style) {
      case AppAnimationStyle.playful:
      case AppAnimationStyle.iosStyle:
        return Curves.easeOutBack;
      case AppAnimationStyle.fast:
        return Curves.easeOutQuad;
      case AppAnimationStyle.elegant:
        return Curves.easeInOutCubic;
      default:
        return defaultCurve;
    }
  }
}

class AnimationSettingsNotifier
    extends StateNotifier<AnimationSettingsState> {
  AnimationSettingsNotifier()
      : super(const AnimationSettingsState(
          enabled: true,
          style: AppAnimationStyle.smooth,
        )) {
    _loadFromStorage();
  }

  void _loadFromStorage() {
    try {
      final box = Hive.box('settings');
      final enabled = box.get('animations_enabled', defaultValue: true) as bool;
      final styleStr = box.get('animation_style', defaultValue: 'smooth') as String;

      final style = AppAnimationStyle.values.firstWhere(
        (e) => e.name == styleStr,
        orElse: () => AppAnimationStyle.smooth,
      );

      state = AnimationSettingsState(enabled: enabled, style: style);
    } catch (_) {}
  }

  Future<void> setEnabled(bool enabled) async {
    state = state.copyWith(enabled: enabled);
    try {
      final box = Hive.box('settings');
      await box.put('animations_enabled', enabled);
    } catch (_) {}
  }

  Future<void> setStyle(AppAnimationStyle style) async {
    state = state.copyWith(style: style);
    try {
      final box = Hive.box('settings');
      await box.put('animation_style', style.name);
    } catch (_) {}
  }
}

final animationSettingsProvider =
    StateNotifierProvider<AnimationSettingsNotifier, AnimationSettingsState>(
  (ref) => AnimationSettingsNotifier(),
);
