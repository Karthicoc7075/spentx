/// Built-in SMS detection rules shipped in Dart code (not stored in Hive).
class SmsDefaultRulesCatalog {
  SmsDefaultRulesCatalog._();

  static const String storageNote =
      'Built-in rules live in source code. User-trained template, regex, and block rules are stored in Hive on device.';

  static Map<String, dynamic> toJson() => {
        'type': 'built_in_defaults',
        'storage': 'dart_source_code',
        'note': storageNote,
        'parsePipelineOrder': [
          '0 SmsTransactionFilters — failed txn + advertisement (return null)',
          '1 Block rules — Hive block_rules_box (user)',
          '2 Template rules — Hive sms_template_rules_box (user)',
          '3 Regex rules — Hive detection_rules_box (user)',
          '4 UniversalSmsParser — fallback parser',
          '5 BankTitleExtractor.enrich — bank-specific title rules',
        ],
        'sourceFiles': [
          'lib/features/sms_parser/sms_transaction_filters.dart',
          'lib/features/sms/rules/engine/sms_rule_engine.dart',
          'lib/features/sms/rules/engine/sms_template_engine.dart',
          'lib/features/sms_parser/sms_parser.dart',
          'lib/features/sms_parser/bank_title_extractor.dart',
          'lib/features/sms_parser/sms_direction_helper.dart',
        ],
        'filters': {
          'failedTransaction': {
            'keywords': ['failed', 'unsuccessful', 'declined', 'insufficient funds'],
            'action': 'ignore',
          },
          'advertisement': {
            'keywords': ['reward', 'offer', 'cashback', 'delivery code', 'feedback call'],
            'action': 'ignore unless real bank txn keywords present',
          },
        },
        'bankTitleRules': [
          {
            'id': 'hdfc_card_at_on',
            'bank': 'HDFC',
            'pattern': 'Spent/Withdrawn Rs.X ... At {TITLE} On {DATE}',
            'type': 'debit',
            'titleSource': 'between At and On',
          },
          {
            'id': 'canara_upi_debit',
            'bank': 'Canara',
            'pattern': 'Rs.X paid thru A/C ... to {TITLE}',
            'type': 'debit',
            'titleSource': 'after to until comma or UPI Ref',
          },
          {
            'id': 'canara_credit',
            'bank': 'Canara',
            'pattern': 'credited ... from a/c no. XX{last4}',
            'type': 'credit',
            'titleSource': '**{last4}',
          },
          {
            'id': 'hdfc_salary',
            'bank': 'HDFC',
            'pattern': 'INR X deposited ... Salary-{TITLE}',
            'type': 'credit',
            'titleSource': 'after Salary- until .Avl or end',
          },
          {
            'id': 'hdfc_annual_fee',
            'bank': 'HDFC',
            'pattern': 'DEBIT CARD ANNUAL FEE',
            'type': 'debit',
            'title': 'HDFC Debit Card Annual Fee',
            'category': 'Bank Charges',
          },
          {
            'id': 'sbi_yono_atm',
            'bank': 'SBI',
            'pattern': 'Yono Cash Rs X w/d@SBI ATM',
            'type': 'transfer',
            'title': 'SBI ATM Withdraw',
            'mode': 'atm',
            'flow': 'bank_to_cash',
          },
        ],
        'directionHelper': {
          'creditKeywords': ['credited', 'received from', 'deposited', 'added to your account'],
          'transferKeywords': ['withdrawn', 'atm w/d', 'atm + withdraw/cash'],
          'debitKeywords': ['debited', 'spent at', 'paid to', 'sent to', 'purchase'],
        },
        'templateTrainingTags': [
          'amount',
          'title',
          'merchantName',
          'bankName',
          'accountLast4',
          'date',
          'time',
          'upiId',
          'referenceId',
          'debitType',
          'creditType',
          'transferType',
          'atmWithdraw',
          'cardPayment',
          'ignoreText',
        ],
        'addTemplateFlow': [
          'Bundled defaults: paste JSON into assets/sms/default_template_rules.json (auto-seeds on first install if box empty)',
          'On device: Settings → SMS Rules Storage → Stored tab → Import template JSON',
          'Manual UI: Developer Options → SMS Detection Rules → Add Template Rule',
          'Visual Tagging → tag fields → Save → Hive sms_template_rules_box',
          'Future SMS: SmsRuleEngine.parse → SmsTemplateEngine.tryMatch',
        ],
        'bundledJsonPath': 'assets/sms/default_template_rules.json',
        'hiveBox': 'sms_template_rules_box',
      };
}