import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../../../core/services/auth_service.dart';
import '../../../../models/purpose_share_model.dart';

class PurposeShareService {
  static SupabaseClient get _db => Supabase.instance.client;
  static final onSharesChanged = ValueNotifier<int>(0);

  static void notifySharesChanged() {
    onSharesChanged.value++;
  }

  static DateTime? calculateExpiresAt(String preset) {
    final now = DateTime.now();
    switch (preset.toLowerCase().trim()) {
      case '1 day':
      case '1-day':
        return now.add(const Duration(days: 1));
      case '7 days':
      case '7-days':
        return now.add(const Duration(days: 7));
      case '1 month':
      case '1-month':
        return DateTime(now.year, now.month + 1, now.day, now.hour, now.minute);
      case '6 months':
      case '6-months':
        return DateTime(now.year, now.month + 6, now.day, now.hour, now.minute);
      case 'always':
      case 'never':
      default:
        return null;
    }
  }

  /// List all shares for the current user (both owned and received, active and pending).
  /// Revoked shares are excluded from the main active list, but non-revoked remain
  /// even after the viewer claims them.
  static Future<List<PurposeShareModel>> fetchShares() async {
    final ownerId = AuthService.currentUserId;
    if (ownerId == null || ownerId.isEmpty) return [];

    try {
      final ownedRows = await _db
          .from('purpose_shares')
          .select('*')
          .eq('owner_id', ownerId)
          .neq('status', 'revoked')
          .order('created_at', ascending: false);

      final userEmail = AuthService.currentUserEmail?.trim().toLowerCase();
      List<dynamic> receivedRows = [];
      if (userEmail != null && userEmail.isNotEmpty) {
        receivedRows = await _db
            .from('purpose_shares')
            .select('*')
            .eq('viewer_email', userEmail)
            .neq('status', 'revoked')
            .order('created_at', ascending: false);
      }

      final Map<String, PurposeShareModel> sharesMap = {};
      for (final raw in [...(ownedRows as List<dynamic>), ...receivedRows]) {
        final m = PurposeShareModel.fromMap(raw as Map<String, dynamic>);
        sharesMap[m.id] = m;
      }

      final list = sharesMap.values.toList();
      list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      return list;
    } catch (e, stack) {
      debugPrint('Error fetching purpose shares: $e\n$stack');
      rethrow;
    }
  }

  /// Create a view link for a purpose.
  /// Rule: Maximum 3 active view links per purpose.
  static Future<PurposeShareModel> createViewLink({
    required String purposeId,
    required String purposeName,
    String? contributorId,
    String expiryPreset = 'always',
  }) async {
    final ownerId = AuthService.currentUserId;
    if (ownerId == null || ownerId.isEmpty) {
      throw Exception('Sign in before sharing purposes.');
    }

    // 1. Cap check: max 3 active links per purpose
    final existingLinks = await _db
        .from('purpose_shares')
        .select('id')
        .eq('owner_id', ownerId)
        .eq('purpose_id', purposeId)
        .eq('kind', 'link')
        .neq('status', 'revoked');

    if ((existingLinks as List).length >= 3) {
      throw Exception(
        'Maximum 3 active share links allowed for this purpose. Delete an existing link to generate a new one.',
      );
    }

    final expiresAt = calculateExpiresAt(expiryPreset);
    final expiresAtIso = expiresAt?.toUtc().toIso8601String();

    // 2. Insert into share_links table
    final shareLinkRes = await _db
        .from('share_links')
        .insert({
          'owner_id': ownerId,
          'purpose_id': purposeId,
          'purpose_name': purposeName,
          'viewer_email': null,
          'contributor_id': contributorId,
          'expires_at': expiresAtIso,
        })
        .select('token')
        .single();

    final linkToken = shareLinkRes['token'] as String;

    // 3. Insert into purpose_shares table
    final shareRes = await _db
        .from('purpose_shares')
        .insert({
          'owner_id': ownerId,
          'viewer_email': null,
          'purpose_id': purposeId,
          'role': 'viewer',
          'status': 'pending',
          'kind': 'link',
          'link_token': linkToken,
          'expires_at': expiresAtIso,
          'contributor_id': contributorId,
        })
        .select('*')
        .single();

    return PurposeShareModel.fromMap(shareRes);
  }

  /// Create an email invite for a purpose.
  /// Rule: One active email invite per email per purpose.
  static Future<PurposeShareModel> createEmailInvite({
    required String purposeId,
    required String purposeName,
    required String viewerEmail,
    String? contributorId,
    String expiryPreset = 'always',
  }) async {
    final ownerId = AuthService.currentUserId;
    if (ownerId == null || ownerId.isEmpty) {
      throw Exception('Sign in before sharing purposes.');
    }

    final normalizedEmail = viewerEmail.trim().toLowerCase();
    if (normalizedEmail.isEmpty || !normalizedEmail.contains('@')) {
      throw Exception('Please enter a valid email address.');
    }

    // 1. Check existing active invite for this email and purpose
    final existing = await _db
        .from('purpose_shares')
        .select('id')
        .eq('owner_id', ownerId)
        .eq('purpose_id', purposeId)
        .eq('viewer_email', normalizedEmail)
        .neq('status', 'revoked');

    if ((existing as List).isNotEmpty) {
      throw Exception(
        'This purpose is already shared with this email. Revoke the existing share first, then invite again.',
      );
    }

    final expiresAt = calculateExpiresAt(expiryPreset);
    final expiresAtIso = expiresAt?.toUtc().toIso8601String();

    // 2. Insert into share_links table
    final shareLinkRes = await _db
        .from('share_links')
        .insert({
          'owner_id': ownerId,
          'purpose_id': purposeId,
          'purpose_name': purposeName,
          'viewer_email': normalizedEmail,
          'contributor_id': contributorId,
          'expires_at': expiresAtIso,
        })
        .select('token')
        .single();

    final linkToken = shareLinkRes['token'] as String;

    // 3. Insert into purpose_shares table
    final shareRes = await _db
        .from('purpose_shares')
        .insert({
          'owner_id': ownerId,
          'viewer_email': normalizedEmail,
          'purpose_id': purposeId,
          'role': 'viewer',
          'status': 'pending',
          'kind': 'email',
          'link_token': linkToken,
          'expires_at': expiresAtIso,
          'contributor_id': contributorId,
        })
        .select('*')
        .single();

    return PurposeShareModel.fromMap(shareRes);
  }

  /// Revoke an active share.
  /// Rule: Revoked stays revoked. Delete the share_links row so the view link immediately stops working.
  static Future<void> revokeShare({
    required String shareId,
    required String purposeId,
    String? linkToken,
    String? viewerEmail,
  }) async {
    final ownerId = AuthService.currentUserId;
    if (ownerId == null || ownerId.isEmpty) {
      throw Exception('Sign in before modifying shares.');
    }

    final updateRes = await _db
        .from('purpose_shares')
        .update({'status': 'revoked'})
        .eq('owner_id', ownerId)
        .eq('id', shareId)
        .select('id, link_token');

    final updatedRows = updateRes as List;
    if (updatedRows.isEmpty) {
      throw Exception('Could not revoke access — the share may have already been removed.');
    }

    final resolvedToken = linkToken ?? (updatedRows.first['link_token'] as String?);

    if (resolvedToken != null && resolvedToken.isNotEmpty) {
      await _db
          .from('share_links')
          .delete()
          .eq('owner_id', ownerId)
          .eq('token', resolvedToken);
    } else if (viewerEmail != null && viewerEmail.isNotEmpty) {
      await _db
          .from('share_links')
          .delete()
          .eq('owner_id', ownerId)
          .eq('purpose_id', purposeId)
          .eq('viewer_email', viewerEmail.trim().toLowerCase());
    }
  }
}
