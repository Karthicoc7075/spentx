import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:uuid/uuid.dart';

import '../../../core/sync/sync_service.dart';

/// Income source person (web `contributors` table). Default "Me" cannot be deleted.
class Contributor {
  final String id;
  final String name;
  final bool isDefault;
  final bool canDelete;
  final bool isActive;

  const Contributor({
    required this.id,
    required this.name,
    this.isDefault = false,
    this.canDelete = true,
    this.isActive = true,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'isDefault': isDefault,
        'canDelete': canDelete,
        'isActive': isActive,
      };

  factory Contributor.fromJson(Map<dynamic, dynamic> json) => Contributor(
        id: (json['id'] ?? '').toString(),
        name: (json['name'] ?? '').toString(),
        isDefault: json['isDefault'] == true || json['is_default'] == true,
        canDelete: json['canDelete'] != false && json['can_delete'] != false,
        isActive: json['isActive'] != false && json['is_active'] != false,
      );

  Contributor copyWith({
    String? name,
    bool? isDefault,
    bool? canDelete,
    bool? isActive,
  }) {
    return Contributor(
      id: id,
      name: name ?? this.name,
      isDefault: isDefault ?? this.isDefault,
      canDelete: canDelete ?? this.canDelete,
      isActive: isActive ?? this.isActive,
    );
  }
}

class ContributorNotifier extends StateNotifier<List<Contributor>> {
  static const _storageKey = 'contributors';
  static const defaultMeName = 'Me';

  Box get _box => Hive.box('settings');

  ContributorNotifier() : super(const []) {
    _load();
  }

  void reloadFromStorage() => _load();

  void _load() {
    final raw = _box.get(_storageKey);
    if (raw is List && raw.isNotEmpty) {
      final list = raw
          .whereType<Map>()
          .map((e) => Contributor.fromJson(Map<dynamic, dynamic>.from(e)))
          .where((c) => c.isActive)
          .toList();
      state = _ensureMe(list);
      return;
    }
    state = _ensureMe(const []);
    _save();
  }

  List<Contributor> _ensureMe(List<Contributor> list) {
    final hasMe = list.any(
      (c) => c.isDefault || c.name.toLowerCase() == defaultMeName.toLowerCase(),
    );
    if (hasMe) {
      return [
        for (final c in list)
          if (c.isDefault || c.name.toLowerCase() == defaultMeName.toLowerCase())
            c.copyWith(isDefault: true, canDelete: false, isActive: true)
          else
            c,
      ];
    }
    return [
      Contributor(
        id: const Uuid().v4(),
        name: defaultMeName,
        isDefault: true,
        canDelete: false,
      ),
      ...list,
    ];
  }

  void _save() {
    _box.put(_storageKey, state.map((c) => c.toJson()).toList());
  }

  /// Replace from server pull (keeps Me invariant).
  void replaceFromServer(List<Contributor> remote) {
    final active = remote.where((c) => c.isActive).toList();
    state = _ensureMe(active);
    _save();
  }

  Contributor get defaultContributor =>
      state.firstWhere(
        (c) => c.isDefault,
        orElse: () => state.isNotEmpty
            ? state.first
            : const Contributor(
                id: 'me',
                name: defaultMeName,
                isDefault: true,
                canDelete: false,
              ),
      );

  String get defaultName => defaultContributor.name;

  Future<Contributor?> addContributor(String name) async {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return null;
    if (state.any((c) => c.name.toLowerCase() == trimmed.toLowerCase())) {
      return null;
    }
    final created = Contributor(
      id: const Uuid().v4(),
      name: trimmed,
      isDefault: false,
      canDelete: true,
    );
    state = [...state, created];
    _save();
    SyncService.queueContributorUpsert(created.toJson());
    return created;
  }

  Future<void> removeContributor(String id) async {
    final target = state.where((c) => c.id == id).firstOrNull;
    if (target == null) return;
    if (target.isDefault || !target.canDelete) return;
    if (target.name.toLowerCase() == defaultMeName.toLowerCase()) return;

    state = state.where((c) => c.id != id).toList();
    _save();
    SyncService.queueContributorDelete(id, name: target.name);
  }

  /// Resolve remote uuid for a contributor display name (for split push).
  String? remoteIdForName(String? name) {
    if (name == null || name.isEmpty) return null;
    final match = state
        .where((c) => c.name.toLowerCase() == name.toLowerCase())
        .firstOrNull;
    return match?.id;
  }

  String? nameForId(String? id) {
    if (id == null || id.isEmpty) return null;
    return state.where((c) => c.id == id).firstOrNull?.name;
  }
}

final contributorProvider =
    StateNotifierProvider<ContributorNotifier, List<Contributor>>(
  (_) => ContributorNotifier(),
);
