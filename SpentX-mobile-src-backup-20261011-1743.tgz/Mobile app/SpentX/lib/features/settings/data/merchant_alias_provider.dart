import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive/hive.dart';

class MerchantAliasNotifier extends StateNotifier<Map<String, String>> {
  final Box _box;

  MerchantAliasNotifier(this._box) : super({}) {
    _loadFromHive();
  }

  void _loadFromHive() {
    final Map<dynamic, dynamic> rawMap = _box.toMap();
    state = rawMap.map((key, value) => MapEntry(key.toString(), value.toString()));
  }

  void saveAlias(String rawName, String alias) {
    if (rawName.isEmpty || alias.isEmpty) return;
    state = {...state, rawName: alias};
    _box.put(rawName, alias);
  }

  void removeAlias(String rawName) {
    final newState = Map<String, String>.from(state);
    newState.remove(rawName);
    state = newState;
    _box.delete(rawName);
  }

  String getAlias(String rawName) {
    return state[rawName] ?? rawName;
  }
}

final merchantAliasProvider = StateNotifierProvider<MerchantAliasNotifier, Map<String, String>>((ref) {
  final box = Hive.box('merchant_aliases');
  return MerchantAliasNotifier(box);
});
