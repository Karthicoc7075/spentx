import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../../../core/models/merchant_rule.dart';
import '../../../core/services/merchant_rule_service.dart';
import '../../../core/services/auto_detection_native_sync.dart';
import '../../sms/v4/merchant_learning_service.dart';
import '../../sms/v4/payee_normalizer.dart';
import '../../../data/local/hive_service.dart';

final merchantProvider = StateNotifierProvider<MerchantNotifier, List<MerchantRule>>((ref) {
  return MerchantNotifier();
});

class MerchantNotifier extends StateNotifier<List<MerchantRule>> {
  MerchantNotifier() : super([]) {
    _init();
  }

  static const String _boxName = 'merchant_rules_box';

  void _init() async {
    if (!Hive.isBoxOpen(_boxName)) {
      await SecureHive.openBox(_boxName);
    }
    _loadFromBox();
  }

  void _loadFromBox() {
    final box = Hive.box(_boxName);
    state = box.values
        .map((e) => MerchantRule.fromMap(Map<dynamic, dynamic>.from(e)))
        .toList();
    AutoDetectionNativeSync.syncToNative();
  }

  MerchantRule? findRule(
    String identifier, {
    String? upiId,
    String? transactionType,
  }) {
    return MerchantRuleService.findRule(
      upiId: upiId ?? '',
      rawIdentifier: identifier,
      displayName: identifier,
      transactionType: transactionType ?? 'debit',
      logResult: false,
    );
  }

  Future<void> saveRule({
    required String identifier,
    required String name,
    required String category,
    required String accountType,
    String transactionType = 'debit',
  }) async {
    if (identifier.isEmpty) return;
    await MerchantRuleService.learnRule(
      identifier: identifier.trim(),
      displayName: name,
      category: category,
      purposeType: accountType,
      transactionType: transactionType,
    );
    // Mirror into the v4 merchants_box so the payee-based detection
    // pipeline (the one that actually auto-adds) sees this rule too.
    await _mirrorToV4(
      identifier: identifier.trim(),
      name: name,
      category: category,
      purpose: accountType,
    );
    _loadFromBox();
  }

  Future<void> updateRule(MerchantRule rule) async {
    final box = Hive.box(_boxName);
    await box.put(rule.id, rule.toMap());
    await _mirrorToV4(
      identifier: rule.identifier,
      name: rule.displayName,
      category: rule.defaultCategory,
      purpose: rule.defaultPurposeType,
    );
    _loadFromBox();
  }

  Future<void> deleteRule(String id) async {
    final box = Hive.box(_boxName);
    // Capture the rule before deleting so the v4 mirror can be cleaned too —
    // otherwise merchants_box keeps auto-applying a mapping the user removed.
    final raw = box.get(id);
    await box.delete(id);
    if (raw != null) {
      try {
        final rule = MerchantRule.fromMap(Map<dynamic, dynamic>.from(raw));
        await _deleteV4Mirror(rule);
      } catch (_) {}
    }
    _loadFromBox();
  }

  Future<void> _mirrorToV4({
    required String identifier,
    required String name,
    required String category,
    required String purpose,
  }) async {
    try {
      // mirrorLegacyRules: false — caller already wrote merchant_rules_box.
      await MerchantLearningService.saveVerified(
        payee: identifier,
        title: name,
        purpose: purpose,
        category: category,
        mirrorLegacyRules: false,
      );
    } catch (_) {}
  }

  Future<void> _deleteV4Mirror(MerchantRule rule) async {
    try {
      await MerchantLearningService.ensureOpen();
      final targets = <String>{
        PayeeNormalizer.normalize(rule.identifier),
        PayeeNormalizer.normalize(rule.normalizedIdentifierKey),
      }..removeWhere((e) => e.isEmpty);
      if (targets.isEmpty) return;
      for (final record in MerchantLearningService.listAll()) {
        if (targets.contains(record.normalizedPayee)) {
          await MerchantLearningService.delete(record.id);
        }
      }
    } catch (_) {}
  }

  // ALIAS FOR BACKWARD COMPATIBILITY
  Future<void> learnRule({
    required String identifier,
    required String name,
    required String category,
    required String accountType,
    String transactionType = 'debit',
    String linkedBankId = '',
  }) => saveRule(
    identifier: identifier,
    name: name,
    category: category,
    accountType: accountType,
    transactionType: transactionType,
  );
}

// Settings Provider — reads bool safely from Hive
bool readAutoDetectionSetting() {
  final v = Hive.box('settings').get('auto_detection', defaultValue: true);
  if (v is bool) return v;
  if (v == 'true' || v == 1) return true;
  if (v == 'false' || v == 0) return false;
  return true;
}

final autoDetectionProvider = StateProvider<bool>((ref) {
  return readAutoDetectionSetting();
});

/// SMS merchant auto-match. Default off so existing confirm flow stays.
bool readSmsMerchantAutoMatchSetting() {
  try {
    final v = Hive.box('settings').get(
      'sms_merchant_auto_match',
      defaultValue: false,
    );
    if (v is bool) return v;
    if (v == 'true' || v == 1) return true;
    if (v == 'false' || v == 0) return false;
  } catch (_) {}
  return false;
}

final smsMerchantAutoMatchProvider = StateProvider<bool>((ref) {
  return readSmsMerchantAutoMatchSetting();
});

extension AutoDetectionToggle on WidgetRef {
  void toggleAutoDetection() {
    final box = Hive.box('settings');
    final current = read(autoDetectionProvider);
    box.put('auto_detection', !current);
    read(autoDetectionProvider.notifier).state = !current;
  }
}
