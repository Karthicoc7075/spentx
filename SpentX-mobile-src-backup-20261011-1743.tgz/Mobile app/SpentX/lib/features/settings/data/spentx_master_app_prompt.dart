/// Full SpentX app specification for AI/developer reference.
/// Shown in Developer Options with one-tap copy.
class SpentxMasterAppPrompt {
  static const String version = '2.1.0';
  static const String title = 'SPENTX MASTER APP SPECIFICATION';

  static const String fullText = '''
═══════════════════════════════════════════════════════════════════════════════
$title
Version: $version | Platform: Flutter (Android primary) | Locale: India (₹, UPI, bank SMS)
Purpose: Privacy-focused personal finance + trip expense tracker with SMS/notification auto-detection
═══════════════════════════════════════════════════════════════════════════════

1. PRODUCT SUMMARY
──────────────────
SpentX is an offline-first Indian personal finance app. It tracks expenses/income from:
  (a) Manual quick-add
  (b) Bank SMS parsing (telephony + EventChannel)
  (c) Bank app notification listener (background_detection)
Users organize money by accounts, purpose types (Personal/Family/custom), categories, budgets,
investments, and multi-day outings (group trips) with friend splits and UPI repayments.
All data stays on-device in Hive — no cloud sync.

2. TECH STACK
─────────────
• Flutter 3.x + Dart 3.7+
• State: flutter_riverpod
• Routing: go_router (routes in lib/core/router/app_router.dart)
• Storage: hive_flutter (boxes listed in §8), flutter_secure_storage (encryption key)
• Auth: local_auth (biometric), custom PIN (hashed+salt in settings box)
• SMS: telephony, native EventChannel com.spentx.app/sms, MethodChannel permissions
• Notifications: flutter_local_notifications, NotificationListenerService (Android)
• UI: lucide_icons, google_fonts, fl_chart, shimmer, premium bottom sheets
• Other: permission_handler, share_plus, csv, url_launcher, flutter_contacts, uuid, intl

3. APP LAUNCH & NAVIGATION FLOW
───────────────────────────────
Splash (/) → checks onboarding, PIN, lock screen
  ├─ First time → Onboarding (/onboarding) → PIN setup (/pin-setup) → Home (/home)
  ├─ Returning + lock enabled → Lock screen (/lock) → Home
  └─ Returning + no lock → Home

Main shell: MainWrapper with bottom nav (5 tabs):
  [0] Home      — net worth, purpose spend, accounts summary, recent txs, active trip banner
  [1] Activity  — full transaction list, purpose/category filters
  [2] + FAB     — quick add expense or income (premium bottom sheet)
  [3] Analytics — savings, cash flow, categories, top spending
  [4] More      — SettingsScreen (profile, features, preferences, security)

Additional routes (go_router):
  /investments, /wealth, /outings, /outing-detail/:id, /budgets, /recurring,
  /notifications, /search, /calendar, /export, /accounts, /account-detail/:name,
  /transaction/:id, /outing-expense/:outingId/:expenseId, /friends,
  /sms-detection-lab, /app-guide, /merchant-names, /developer-options,
  /sms-activity, /detected-sms

4. ONBOARDING WORKFLOW
──────────────────────
Step 1: Account count selection
Step 2: Per-account forms (name, type bank/cash, opening balance, optional image)
Step 3: Purpose types (Personal, Family, custom purposes with colors)
Success screen → PIN setup (4-digit) → Home
Flags in settings: has_seen_onboarding, isFirstTimeUser
First launch prompts notification permission (SharedPreferences: has_prompted_notification_permission)

5. TRANSACTIONS — CORE DATA MODEL
─────────────────────────────────
Stored in Hive box "transactions" as list key "list" — each tx is Map JSON:
  id, title/merchant, amount, date (ISO), category, accountId/accountName,
  type (expense/income/transfer), purposeType, paymentMode (UPI/Cash/Card/etc),
  note, referenceId (UPI ref), upiId, bank, isPendingVerification,
  outingId (optional link), isAutoDetected, merchantRuleId, etc.

MANUAL ADD FLOW (center + button):
  1. User picks Expense or Income
  2. Enters amount, merchant/title, optional UPI/ref, note, category, account, purpose
  3. On save → TransactionProvider adds to Hive
  4. Merchant learning: if UPI or identifiable title → upsert merchant_rules_box
     (key priority: UPI > rawId > normalized name; stores displayName, defaultCategory,
      defaultPurposeType, transactionType debit/credit)
  5. If active outing + date in range + autoMode → OutingTransactionSync links expense
  6. BudgetAlertService checks category spend vs limits

EDIT/DELETE TX:
  Edit updates both transaction + linked merchant rule if applicable
  Unlink outing: transaction detail → change outing link
  Delete removes from list and syncs outing totals

6. MERCHANT LEARNING & AUTO-CATEGORIZATION
──────────────────────────────────────────
Box: merchant_rules_box
Rule fields: identifier, normalizedIdentifierKey, displayName, defaultCategory,
             defaultPurposeType, transactionType (debit/credit/any)
Lookup order in AutoRuleEngine._findMerchantRule:
  1) exact UPI id  2) exact phone digits  3) normalized identifier  4) display name
Sources that train rules:
  • Manual tx with UPI/title
  • User confirms pending SMS detection
  • Manage Merchants screen (/merchant-names) — edit aliases, categories
Manage Merchants UI lets user fix "SWIGGY*FOOD" → Swiggy + Food category for future auto-match.

7. SMS / NOTIFICATION AUTO-DETECTION — UPDATED PIPELINE (v2.1)
──────────────────────────────────────────────────────────────
CRITICAL: First-time ATM withdrawals + ALL unknown merchants MUST:
  • Save full record to detected_sms_box
  • Add ID to pending_detections queue
  • Create notification_history entry (type = sms_pending)
  • Show system notification: "New transaction detected. Tap to verify."
  • On app open OR notification tap OR foreground detect → PendingVerificationPresenter
    shows verification bottom sheet immediately

TWO INPUT CHANNELS:
  A) Foreground SMS: SmsService EventChannel + native queue flush on resume
  B) Notification listener: NotificationService.handlePayload (no SMS permission needed)

MASTER FLAG: settings.auto_detection — when OFF, log only, no tx/notification

PIPELINE: SmsDetectionPipeline.processInbound → SmsRuleEngine.parse → AutoRuleEngine

STEPS (unchanged): dedupe → block rules → parse → direction (credit/debit/transfer)

ATM-SPECIFIC (SmsAtmHelper + SmsMerchantMatcher):
  • ATM SMS classified as transfer via SmsDirectionHelper
  • Rule lookup uses exact key ATM_<bank> only (no fuzzy match)
  • First ATM per bank = UNKNOWN → pending verification (no auto-add)
  • After user verifies: learn merchant_rules_box rule:
      identifier: ATM_<bank>  displayName: ATM Withdrawal
      defaultCategory: Cash Withdrawal  transactionType: transfer
  • Subsequent same-bank ATM SMS: rule exists → auto-add, sms_auto history, no popup

UNKNOWN MERCHANT BRANCH (_commitUnknownMerchantPending):
  1. detected_sms_box ← full pending record
  2. pending_detections queue ← tx id
  3. notification_history ← sms_pending
  4. SmsNotificationService.showPendingNotification()
  5. Debug log: step: pending_detection_saved | queue: added | notification_history: sms_pending added

KNOWN MERCHANT / LEARNED ATM:
  → Auto-add to transactions, outing link if active, processed_sms_box, sms_auto notification

AFTER USER VERIFIES (DetectionPopup → confirmTransaction):
  → Create tx, learn merchant rule (mandatory), remove from queue, mark processed_sms_box

PRESENTER TRIGGERS (MainWrapper):
  • Cold start: processQueueIfNeeded after 400ms
  • openPendingVerificationOnHomeProvider (notification tap)
  • detectionQueueProvider listener (queue grows while app open)
  • handleForeground calls presenter after unknown merchant commit

FOREGROUND vs BACKGROUND:
  Foreground: handleForeground → commit pending → PendingVerificationPresenter
  Background: handleNativePayload → same commit path; tap notification → /home → presenter

SMS RULES MANAGER (Developer Options → SMS Detection Rules):
  • Template rules: train bank-specific SMS formats
  • Regex rules: custom patterns
  • Block rules: ignore OTP/promo patterns
  • Paste message screen for training
  • Template test screen for validation

SMS DETECTION LAB (/sms-detection-lab):
  Paste sample SMS → choose 5s/10s delay → simulate real notification
  → runs same SmsDetectionPipeline with source=lab, forceProcess optional
  Shows parse result, merchant match, rule stats

DETECTED SMS (/detected-sms):
  Lists pending + ignored detections; batch verify; reprocess

8. HIVE DATA STORAGE (ALL BOXES)
────────────────────────────────
settings          — profile_name, auto_detection, lock_screen_enabled, pin_hash, pin_salt,
                    has_seen_onboarding, isFirstTimeUser, disable_rotation, outing privacy flags
transactions      — key "list": all financial transactions
outings           — trip objects: members, expenses, settlements, dates, autoMode
merchant_rules_box — learned merchant auto-map rules
merchant_aliases  — display name aliases
friends           — friend contacts + linked UPI ids (friend_upi)
budgets           — per-category monthly limits
investments       — holdings by type (liquid, MF, FD, stocks, bonds, crypto, gold, RE, other)
categories        — custom categories
pending_detections — queue list of pending tx ids
detected_sms_box  — full pending detection records
ignored_detections — skipped SMS detections
notification_history — in-app notification log (sms_auto, sms_pending, budget_alert, etc.)
processed_sms_box — dedupe by referenceId
SMS rule boxes (SmsHiveBoxes):
  sms_template_rules_box, block_rules_box, detection_rules_box,
  ignored_sms_box, processed_sms_box
vault             — encrypted box (HiveService, optional secure data)
SharedPreferences — permission prompt flags, misc prefs

RESET (AppResetService.resetAll):
  Clears ALL boxes above + SharedPreferences + PIN
  Re-seeds: has_seen_onboarding=false, isFirstTimeUser=true, auto_detection=true
  User must close and reopen app → onboarding appears

9. OUTINGS / TRIPS / GROUP EXPENSES
───────────────────────────────────
Access: Settings → Manage Outing (/outings) or Home trip banner

CREATE TRIP:
  title, startDate, endDate, members (You + friends from friends box),
  autoAddMode (auto-link SMS expenses during trip dates)

ACTIVE TRIP BEHAVIOR:
  • Home shows trip banner with spend summary
  • New expenses (manual or SMS) within [startDate..endDate] auto-link if autoMode on
  • ActiveOutingHelper normalizes date boundaries for matching
  • expireEndedOutings() auto-ends trips past endDate

EXPENSE ON TRIP:
  Fields: title, amount, category, date, paymentMode, splitType (solo/equally),
          memberIds[], paidByMemberId, transactionId (if from SMS/manual tx)
  Split equally: amount / member count per person
  WHO PAID drives who owes whom

SETTLEMENTS:
  recordMemberSettlement — partial repayments supported (cash + UPI multiple payments)
  SettlementPayment: amount, mode, date per member
  Friend repayment SMS (credit from friend UPI) → FriendRepaymentMatcher auto-settles shares

PRIVACY:
  Outing Privacy Mode (only when trip active):
    ON → home/activity show trip-only data, hide net worth & non-trip balances
    OFF → requires PrivacyUnlockDialog (PIN or profile name confirm)
  Suppresses Private Mode while active

STATEMENT:
  Per-person share, pending return (friends owe you), settled amounts, trip total

10. FRIENDS & CREDITS
─────────────────────
Friends screen (/friends): add/edit friends, link UPI per friend
Friend UPI used by:
  • FriendRepaymentMatcher — credit SMS from friend UPI settles outing shares
  • FriendCreditHandler — links credits to pending trip balances
  • Manual repay sheets on trip detail
Contacts integration via flutter_contacts (optional pick)

11. BUDGETS
───────────
Budgets screen (/budgets): per-category monthly limits
BudgetAlertService: computes spend from transactions for current month
Alerts at 80% and 100% thresholds → notification_history (throttled per month/category)
Bell icon on Home shows unread notification_history count

12. INVESTMENTS
───────────────
Investments tab (/investments):
  Types: liquid, mutualFund, fixedDeposit, stocks, bonds, crypto, gold, realEstate, other
  Actions: add holding, invest more, withdraw, delete
  Wealth total computed from holdings
  Today's flow from linked transactions
  SMS auto-detect investment txs (groww, zerodha, etc.) → suggest allocation to holding
  url_launcher for external invest links (Groww, etc.)

Wealth screen (/wealth): aggregated net worth view

13. ACCOUNTS
────────────
Multiple bank + cash accounts with opening/current balances
Account Configuration (PremiumSettingsScreen): manage accounts, purposes, images
Account detail (/account-detail/:name): tx history per account
Transfers between accounts via transfer bottom sheet

14. ANALYTICS
─────────────
Analytics tab: spend by category, purpose, month; savings rate; cash flow charts (fl_chart)
Filters by purpose type (Personal/Family/custom)
Repayment tracking in analytics

15. OTHER FEATURES
──────────────────
• Search (/search) — find transactions
• Calendar (/calendar) — tx by date
• Recurring (/recurring) — recurring expense templates
• Export (/export) — CSV export via share_plus
• Notifications (/notifications) — full notification_history with read/unread
• Detected Messages (/detected-sms) — verify only uncertain live detections
• App Guide (/app-guide) — in-app how-to
• Cash reminder sheet — prompt when cash expense detected
• Loans screen — loan tracking
• Category selector + premium widgets throughout

16. PRIVACY MODES
─────────────────
PRIVATE MODE (Settings toggle):
  Masks amounts as ***** on Home & Accounts for Personal/Family sections
  Blocked while Outing Privacy is live

OUTING PRIVACY (Settings toggle, requires active trip):
  Hides net worth, shows only trip-related activity on Home/Activity
  Disable requires PIN or profile name (PrivacyUnlockDialog)

17. SECURITY & AUTH
───────────────────
PIN: 4-digit, hashed+salt stored in settings (PinService)
Biometric: local_auth fingerprint/face — BiometricUnlockBadge on lock screen
Lock Screen toggle: require PIN/bio on every app open
PIN setup (/pin-setup), Lock screen (/lock)
Reset App Data: requires PIN or profile name confirmation → AppResetService.resetAll

18. SETTINGS SCREEN SECTIONS
────────────────────────────
HELP: How to use SpentX (app guide)
CONFIGURATION: Account Configuration (accounts, purposes, images)
FEATURES: Manage Outing, Outing Privacy, Manage Friends, Manage Merchants
DEVELOPER: Developer Options (this screen — not for end users)
PREFERENCES: Private Mode, Automatic SMS Detection, Lock Screen, Biometric
SECURITY: Set/Change PIN, Reset App Data
Profile header: tap to edit profile_name

19. DEVELOPER OPTIONS SCREEN
────────────────────────────
Access: Settings → Developer Options (/developer-options)

SECTIONS:
  A) SMS DETECTION TOOLS
     • SMS Detection Rules → SmsRuleManagerScreen
     • Detected SMS → /detected-sms
     • SMS Detection Lab → /sms-detection-lab

  B) SMS DETECTION LAB QUICK TEST
     ExpansionTile: paste SMS, create test rule, launch full lab

  C) HOW SMS DETECTION WORKS
     Inline workflow documentation

  D) SMS DETECTION DEBUG LOG
     Live log panel (SmsDetectionDebugLog): success/warning/error/info
     Refresh + Clear log buttons

  E) APP SETTINGS (DEV)
     Disable App Rotation → locks portrait via SystemChrome + settings.disable_rotation

  F) FULL APP PROMPT / SPECIFICATION
     This master document — SelectableText + COPY button (clipboard)

20. NOTIFICATION FLOW
─────────────────────
SmsNotificationService: shows Android notifications for pending detections
NotificationService: background listener → pipeline
NotificationHistoryService: in-app history box (separate from system notifications)
Cold start from notification tap → openPendingVerificationOnHomeProvider → queue presenter
Home orange banner when pending detections exist

21. STATE MANAGEMENT (KEY PROVIDERS)
────────────────────────────────────
userStateProvider, transactionProvider, outingProvider, activeOutingProvider,
merchantProvider, autoDetectionProvider, privateModeProvider,
outingPrivacyModeProvider, isOutingPrivacyActiveProvider,
detectionQueueProvider, investmentProvider, budgetProvider (and related notifiers)

22. NATIVE ANDROID INTEGRATION
──────────────────────────────
• SmsReceiver (broadcast) → EventChannel → SmsService
• MethodChannel permissions: getPendingSms (historical inbox reads are disabled)
• NotificationListenerService for bank app notifications
• AutoDetectionNativeSync: mirrors auto_detection flag to native layer
• Workmanager for background tasks (if configured)

23. COMPLETE USER JOURNEY (HAPPY PATH)
──────────────────────────────────────
Day 0: Install → Onboarding (accounts + purposes) → PIN → grant notification/SMS permission
Day 1: Use normally — bank SMS/notifs auto-parse → confirm or auto-add
       Manage merchants for unknown payees → future txs auto-categorize
       Set budgets → get alerts in notification history
Day N: Start trip with friends → expenses auto-link during trip → friends repay via UPI
       → SMS credits auto-match settlements → end trip → history preserved
Ongoing: Analytics review, export CSV, investments tracking, privacy modes as needed

24. EDGE CASES & RULES
──────────────────────
• auto_detection OFF: SMS still captured in debug log but no tx/notification created
• Duplicate detection: referenceId in processed_sms_box; same amount+day fallback
• Pending items never treated as duplicates (user can always verify)
• Outing date matching uses normalized start/end (inclusive)
• Merchant rule type must match tx type (debit/credit) or be "any"
• Private mode suppressed during outing privacy
• After reset: must kill and reopen app for clean Hive/listener state
• Block rules prevent OTP/marketing SMS from entering pipeline
• Parse failure logged as error in debug log — user can train custom template

25. FILE STRUCTURE (KEY PATHS)
──────────────────────────────
lib/main.dart                          — Hive init, SMS/notification bootstrap
lib/core/router/app_router.dart        — all routes
lib/features/home/presentation/        — MainWrapper, HomeScreen
lib/features/sms/detected/             — pipeline, auto engine, lab, queue, popup
lib/features/sms/rules/                — rule engine, templates, manager UI
lib/features/background_detection/     — notification listener service
lib/features/groups/                   — outings screens (GroupsScreen = outings)
lib/features/settings/                 — settings, developer options, app guide
lib/core/providers/                    — Riverpod state
lib/core/services/                     — PIN, reset, budget alerts, friend matchers

26. FUTURE ROADMAP (from App Guide)
───────────────────────────────────
Must have: cloud backup, recurring bills, CSV/PDF export, multi-currency, widgets, biometric (partially done)
Good to have: shared trip links, smart insights, receipt photos, credit card cycles, goals, theme toggle

═══════════════════════════════════════════════════════════════════════════════
END OF MASTER SPEC — Use this document to reproduce, extend, debug, or provide AI context for SpentX.
All detection respects auto_detection. Rules learned from manual + confirmed SMS.
Data is 100% local Hive. Developer Options is the diagnostics + spec hub.
═══════════════════════════════════════════════════════════════════════════════
''';
}
