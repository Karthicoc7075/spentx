import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// App-wide theme mode (system / light / dark), persisted across restarts.
/// Set from Settings → Preferences → Appearance.
final themeModeProvider = StateNotifierProvider<ThemeModeNotifier, ThemeMode>((
  ref,
) {
  return ThemeModeNotifier();
});

class ThemeModeNotifier extends StateNotifier<ThemeMode> {
  static const _prefsKey = 'app_theme_mode';

  /// The reference mobile surfaces are light-first; users can still switch to
  /// dark mode from Settings and their choice is persisted.
  ThemeModeNotifier() : super(ThemeMode.light) {
    _load();
  }

  Future<void> _load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      state = switch (prefs.getString(_prefsKey)) {
        'light' => ThemeMode.light,
        'dark' => ThemeMode.dark,
        'system' => ThemeMode.system,
        // Unknown / missing → keep default dark.
        _ => state,
      };
    } catch (_) {
      // Non-fatal — keep current state.
    }
  }

  /// Set the mode explicitly. [ThemeMode.system] follows the OS setting.
  Future<void> setMode(ThemeMode mode) async {
    state = mode;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_prefsKey, mode.name);
    } catch (_) {}
  }

  Future<void> setDark(bool isDark) =>
      setMode(isDark ? ThemeMode.dark : ThemeMode.light);

  Future<void> toggle() => setDark(state != ThemeMode.dark);
}
