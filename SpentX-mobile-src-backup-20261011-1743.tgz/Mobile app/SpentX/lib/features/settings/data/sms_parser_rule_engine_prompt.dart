/// SMS Parser + Rule Engine — production spec (v3.0)
const String smsParserRuleEnginePrompt = '''
SMS PARSER + RULE ENGINE — PRODUCTION SPEC

PIPELINE ORDER (SmsRuleEngine.parse):
  0. SmsTransactionFilters — failed txn + advertisement (return null)
  1. Block rules (user Hive block_rules_box)
  2. Template rules (SmsTemplateEngine — tagged Title wins, no fallback title)
  3. Regex/keyword rules (user-trained SmsRule)
  4. UniversalSmsParser fallback
  5. BankTitleExtractor.enrich (skipped when template has Title/Merchant tag)

REQUIRED FIELDS PER DETECTION:
  amount, type, title (name), bank, accountLast4, dateTime, referenceId (if present)

TITLE PRIORITY:
  1. Template Title / Merchant Name tag (positional only — never fallback regex)
  2. BankTitleExtractor bank-specific rules
  3. UPI ID
  4. Sender account (**last4)
  5. UniversalSmsParser contextual patterns

BANK RULES (BankTitleExtractor):

HDFC CARD — At … On YYYY-MM-DD:
  Spent/Withdrawn Rs.X From HDFC Bank Card … At {TITLE} On {DATE}
  type=debit, title=between "At" and "On"

CANARA UPI DEBIT:
  Rs.X paid thru A/C … to {TITLE}
  title=after "to" until "," or "UPI Ref"

CANARA CREDIT:
  credited … from a/c no. XX{last4}
  type=credit, title=**{last4}

HDFC SALARY CREDIT:
  INR X deposited … Salary-{TITLE}
  title=after "Salary-" until ".Avl" or end
  never use: clearing, deposited, credited as title

HDFC ANNUAL FEE:
  For: DEBIT CARD ANNUAL FEE-…
  type=debit, title=HDFC Debit Card Annual Fee, category=Bank Charges

SBI YONO ATM:
  Yono Cash Rs X w/d@SBI ATM
  type=transfer, title=SBI ATM Withdraw, mode=atm, flow=bank_to_cash

FAILED TRANSACTION FILTER (ignore — no detection):
  failed, unsuccessful, declined, insufficient funds
  Example: txn of Rs.945.00 failed due to INSUFFICIENT FUNDS → null

ADVERTISEMENT FILTER (ignore):
  reward, rewards, claim now, offer, holiday, cashback,
  delivery code, feedback call, cylinder delivery, wakefit, bharatgas
  unless real bank txn keywords present

TEMPLATE TRAINING TAGS:
  Amount, Title, Bank Name, Account Last4, Date, Time, UPI,
  ReferenceId, Debit, Credit, Transfer, Merchant Name (alias of Title)

IF template contains Title or Merchant Name tag:
  use tagged positional value ONLY — do not run BankTitleExtractor title fallback

DEBUG (SmsRuleEngine.lastParseDebug):
  Detected Title, Detected Type, Matched Template, Matched Rule, Parse Source

FILES:
  lib/features/sms_parser/sms_transaction_filters.dart
  lib/features/sms_parser/bank_title_extractor.dart
  lib/features/sms_parser/sms_parser.dart
  lib/features/sms/rules/engine/sms_rule_engine.dart
  lib/features/sms/rules/engine/sms_template_engine.dart
''';