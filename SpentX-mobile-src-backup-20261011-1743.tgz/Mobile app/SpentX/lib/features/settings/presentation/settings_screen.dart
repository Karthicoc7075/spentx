import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:local_auth/local_auth.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../core/theme/spentx_tokens.dart';
import '../../../core/providers/user_state_provider.dart';
import '../../../core/providers/theme_mode_provider.dart';
import 'package:go_router/go_router.dart';

import 'package:hive_flutter/hive_flutter.dart';
import 'screens/premium_settings_screen.dart';
import '../../../core/services/auth_service.dart';
import '../../../core/services/pin_service.dart';
import '../../../core/services/app_reset_service.dart';
import '../../../core/providers/outing_privacy_provider.dart';
import '../../../core/providers/outing_provider.dart';
import '../../../core/providers/private_mode_provider.dart';
import '../../groups/presentation/widgets/privacy_unlock_dialog.dart';
import '../../auth/presentation/widgets/biometric_unlock_badge.dart';
import '../../sms/sms_service.dart';
import '../../transactions/data/sms_receiver_service.dart';
import '../../background_detection/notification_service.dart';
import '../../../core/providers/merchant_provider.dart';
import '../../../core/services/auto_detection_native_sync.dart';

import '../../../core/providers/animation_provider.dart';
import '../../../core/navigation/main_shell_navigation.dart';
import '../../../core/widgets/terminal_wrapper.dart';
import '../../../core/sync/sync_failure_log.dart';
import '../../../core/sync/sync_failure_actions.dart';

const _kAppVersion = '1.0.0';

class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key});

  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  @override
  void initState() {
    super.initState();
    SyncFailureLog.revision.addListener(_onSyncFailuresChanged);
  }

  @override
  void dispose() {
    SyncFailureLog.revision.removeListener(_onSyncFailuresChanged);
    super.dispose();
  }

  void _onSyncFailuresChanged() {
    if (mounted) setState(() {});
  }

  Future<void> _showSyncFailures(BuildContext context) async {
    final notes = SyncFailureLog.notes;
    final retry = await showDialog<bool>(
      context: context,
      builder:
          (ctx) => AlertDialog(
            title: const Text('Changes that could not sync'),
            content: SizedBox(
              width: double.maxFinite,
              child: ListView(
                shrinkWrap: true,
                children: [
                  const Text(
                    'The server rejected these changes, so they were set aside to '
                    'keep the rest of your data syncing. They are still on this phone.',
                  ),
                  const SizedBox(height: 12),
                  for (final n in notes)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Text('• ${n.area}: ${n.reason}'),
                    ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(ctx).pop(false),
                child: const Text('Close'),
              ),
              TextButton(
                onPressed: () => Navigator.of(ctx).pop(true),
                child: const Text('Retry now'),
              ),
            ],
          ),
    );
    if (retry != true) return;
    await SyncFailureActions.retryAll();
    if (mounted) setState(() {});
  }

  void _showAnimationStyleSheet(
    BuildContext context,
    WidgetRef ref,
    AppAnimationStyle currentStyle,
  ) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    showModalBottomSheet(
      context: context,
      backgroundColor: context.tokens.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Animation Style',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: context.tokens.textPrimary,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(LucideIcons.x, size: 20),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Flexible(
                child: ListView(
                  shrinkWrap: true,
                  physics: const BouncingScrollPhysics(),
                  children:
                      AppAnimationStyle.values.map((style) {
                        final selected = currentStyle == style;
                        return ListTile(
                          onTap: () {
                            ref
                                .read(animationSettingsProvider.notifier)
                                .setStyle(style);
                            Navigator.pop(context);
                          },
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                          tileColor:
                              selected
                                  ? AppColors.primary.withValues(
                                    alpha: isDark ? 0.16 : 0.1,
                                  )
                                  : null,
                          leading: Icon(
                            selected
                                ? LucideIcons.checkCircle
                                : LucideIcons.circle,
                            color:
                                selected
                                    ? AppColors.primary
                                    : (isDark
                                        ? Colors.white38
                                        : Colors.black38),
                            size: 20,
                          ),
                          title: Text(
                            style.label,
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight:
                                  selected ? FontWeight.w700 : FontWeight.w500,
                              color:
                                  selected
                                      ? AppColors.primary
                                      : (context.tokens.textPrimary),
                            ),
                          ),
                          subtitle: Text(
                            style.subtitle,
                            style: TextStyle(
                              fontSize: 12,
                              color: context.tokens.textSecondary,
                            ),
                          ),
                        );
                      }).toList(),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final userState = ref.watch(userStateProvider);
    final profileName = userState.profileName;
    final autoDetection = ref.watch(autoDetectionProvider);
    final hasPin = PinService.hasPin;
    final animSettings = ref.watch(animationSettingsProvider);

    final tone = _MoreTone.of(context);
    final themeMode = ref.watch(themeModeProvider);
    final lockEnabled =
        Hive.box('settings').get('lock_screen_enabled', defaultValue: true) ==
        true;

    return TerminalWrapper(
      screenName: 'Settings',
      child: Scaffold(
        backgroundColor: tone.canvas,
        body: ListView(
          physics: const BouncingScrollPhysics(),
          padding: EdgeInsets.fromLTRB(
            20,
            MediaQuery.of(context).padding.top + 12,
            20,
            96 + MediaQuery.of(context).padding.bottom,
          ),
          children: [
            Row(
              children: [
                Material(
                  color: tone.card,
                  shape: const CircleBorder(),
                  child: InkWell(
                    customBorder: const CircleBorder(),
                    onTap: () {
                      if (context.canPop()) {
                        context.pop();
                      } else {
                        MainShellNavigation.openTab(context, 0);
                      }
                    },
                    child: SizedBox(
                      width: 40,
                      height: 40,
                      child: Icon(
                        Icons.arrow_back_ios_new_rounded,
                        size: 16,
                        color: tone.ink,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Text(
                  'Settings',
                  style: tone.text(
                    20,
                    FontWeight.w800,
                    tone.ink,
                    letterSpacing: -0.3,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            _MoreProfileCard(
              name: profileName,
              email: AuthService.currentUserEmail,
              onEdit: () => _editProfileName(context, profileName),
            ),
            const SizedBox(height: 12),
            _SettingsGroup(
              title: 'EVERYDAY',
              children: [
                _SettingsItem(
                  icon: LucideIcons.calendar,
                  title: 'Calendar',
                  subtitle: 'Day-by-day spending view & cashflow',
                  onTap: () => context.push('/calendar'),
                ),
                _SettingsItem(
                  icon: LucideIcons.users,
                  title: 'Friends & Settlements',
                  subtitle: 'People you split with and shared trips',
                  onTap: () => _showFriendsOutingsChooser(context),
                ),
              ],
            ),
            _SettingsGroup(
              title: 'MONEY & DATA',
              children: [
                _SettingsSwitchItem(
                  icon: LucideIcons.zap,
                  title: 'Automatic SMS Detection',
                  subtitle:
                      autoDetection
                          ? 'Uses bank rules + default parser'
                          : 'Off — use manual add for UPI spends',
                  value: autoDetection,
                  onChanged: (v) async {
                    await Hive.box('settings').put('auto_detection', v);
                    ref.read(autoDetectionProvider.notifier).state = v;
                    await AutoDetectionNativeSync.syncToNative();
                    if (v) {
                      await SmsService.requestPermissions();
                      await SmsReceiverService.startListening();
                      await SmsService.flushPendingQueue();
                      await NotificationService.flushPendingPayloads();
                    } else {
                      await SmsService.flushPendingQueue();
                      await NotificationService.discardPendingPayloads();
                    }
                    if (mounted) setState(() {});
                  },
                ),
                _SettingsItem(
                  icon: LucideIcons.inbox,
                  title: 'Detected Messages',
                  subtitle: 'Verify SMS that could not be added automatically',
                  onTap: () => context.push('/detected-sms'),
                ),
                if (SyncFailureLog.notes.isNotEmpty)
                  _SettingsItem(
                    icon: LucideIcons.alertTriangle,
                    title: 'Changes that could not sync',
                    subtitle:
                        '${SyncFailureLog.notes.length} saved on this phone only — tap to review',
                    isDanger: true,
                    onTap: () => _showSyncFailures(context),
                  ),
                _SettingsItem(
                  icon: LucideIcons.pieChart,
                  title: 'Monthly Plan',
                  subtitle: 'Expected income and category limits',
                  onTap: () => context.push('/plan'),
                ),
                _SettingsItem(
                  icon: LucideIcons.wallet,
                  title: 'Accounts & Purposes',
                  subtitle: 'Manage accounts, purposes and sharing',
                  onTap:
                      () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const PremiumSettingsScreen(),
                        ),
                      ),
                ),
                _SettingsItem(
                  icon: LucideIcons.download,
                  title: 'Export & Backup',
                  subtitle: 'Export transactions and backup data',
                  onTap: () => context.push('/export'),
                ),
                _SettingsItem(
                  icon: LucideIcons.share2,
                  title: 'Purpose Sharing',
                  subtitle: 'View link or email invite',
                  onTap: () => context.push('/sharing'),
                ),
              ],
            ),
            _SettingsGroup(
              title: 'PRIVACY & SECURITY',
              children: [
                _SettingsSwitchItem(
                  icon: LucideIcons.key,
                  title: 'App PIN',
                  subtitle:
                      hasPin
                          ? 'Require PIN on startup'
                          : 'Protect app with PIN',
                  value: hasPin && lockEnabled,
                  onChanged: (v) async {
                    if (!hasPin) {
                      if (v) {
                        await context.push('/pin-setup');
                        if (mounted) setState(() {});
                      }
                      return;
                    }
                    await Hive.box('settings').put('lock_screen_enabled', v);
                    if (mounted) setState(() {});
                  },
                ),
                _SettingsItem(
                  icon: LucideIcons.fingerprint,
                  title: 'Biometric',
                  subtitle: 'PIN, biometric lock and protection',
                  pill: hasPin ? 'Protected' : null,
                  pillKind: _MorePillKind.mint,
                  onTap: () => _showSecuritySheet(context),
                ),
                _SettingsItem(
                  icon: LucideIcons.shield,
                  title: 'Privacy',
                  subtitle: 'Control amount visibility and privacy',
                  onTap: () => _showPrivacySheet(context),
                ),
              ],
            ),
            _SettingsGroup(
              title: 'APPEARANCE',
              children: [
                _SettingsItem(
                  icon: LucideIcons.moon,
                  title: 'Dark Mode',
                  subtitle: _themeCurrent(themeMode),
                  pill: _themeShort(themeMode),
                  onTap: () => _showThemeSheet(context),
                ),
                _SettingsSwitchItem(
                  icon: LucideIcons.sparkles,
                  title: 'Animations',
                  subtitle: 'Interface transitions & micro-motion',
                  value: animSettings.enabled,
                  onChanged: (val) {
                    ref
                        .read(animationSettingsProvider.notifier)
                        .setEnabled(val);
                  },
                ),
                if (animSettings.enabled)
                  _SettingsItem(
                    icon: LucideIcons.sliders,
                    title: 'Animation Style',
                    subtitle: animSettings.style.subtitle,
                    pill: animSettings.style.label,
                    onTap:
                        () => _showAnimationStyleSheet(
                          context,
                          ref,
                          animSettings.style,
                        ),
                  ),
              ],
            ),
            _SettingsGroup(
              title: 'NOTIFICATIONS',
              children: [
                _SettingsItem(
                  icon: LucideIcons.bell,
                  title: 'Notification History',
                  subtitle: 'SMS, budget and spending alerts',
                  onTap: () => context.push('/notifications'),
                ),
                _SettingsItem(
                  icon: LucideIcons.slidersHorizontal,
                  title: 'Notification Preferences',
                  subtitle: 'Control which alerts you receive',
                  onTap: () => context.push('/notification-preferences'),
                ),
              ],
            ),
            _SettingsGroup(
              title: 'HELP & SUPPORT',
              children: [
                _SettingsItem(
                  icon: LucideIcons.helpCircle,
                  title: 'App Guide',
                  subtitle: 'FAQ, user guides and support',
                  onTap: () => context.push('/app-guide'),
                ),
                _SettingsItem(
                  icon: LucideIcons.store,
                  title: 'Merchant Names',
                  subtitle: 'Auto-mapping & categorization rules',
                  onTap: () => context.push('/merchant-names'),
                ),
                _SettingsItem(
                  icon: LucideIcons.info,
                  title: 'About SpentX',
                  subtitle: 'Licenses, terms and telemetry',
                  pill: 'v$_kAppVersion',
                  onTap:
                      () => showAboutDialog(
                        context: context,
                        applicationName: 'SpentX',
                        applicationVersion: _kAppVersion,
                        applicationLegalese: 'Created by Karthi',
                      ),
                ),
              ],
            ),
            _SettingsGroup(
              title: 'DEVELOPER',
              children: [
                _SettingsItem(
                  icon: LucideIcons.terminal,
                  title: 'Developer Options',
                  subtitle: 'SMS parser debug & local storage inspect',
                  pill: 'Debug',
                  onTap: () => context.push('/developer-options'),
                ),
              ],
            ),
            _SettingsGroup(
              title: 'ACCOUNT ACTIONS',
              danger: true,
              children: [
                _SettingsItem(
                  icon: LucideIcons.trash2,
                  title: 'Reset App Data',
                  subtitle: 'Remove all SpentX records on this phone',
                  isDanger: true,
                  onTap: () => _handleResetApp(context),
                ),
                _SettingsItem(
                  icon: LucideIcons.logOut,
                  title: 'Sign Out',
                  subtitle: 'Keep cloud account, clear local session',
                  isDanger: true,
                  onTap: () => _handleSignOut(context),
                ),
              ],
            ),
            const _MoreVaultFooter(),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  String _themeCurrent(ThemeMode mode) => switch (mode) {
    ThemeMode.system => 'Current: System default',
    ThemeMode.light => 'Current: Light',
    ThemeMode.dark => 'Current: Dark',
  };

  String _themeShort(ThemeMode mode) => switch (mode) {
    ThemeMode.system => 'System Default',
    ThemeMode.light => 'Light',
    ThemeMode.dark => 'Dark',
  };

  void _showFriendsOutingsChooser(BuildContext context) {
    final t = context.tokens;
    showModalBottomSheet(
      context: context,
      backgroundColor: t.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder:
          (ctx) => SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: t.border,
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Friends & Outings',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                      color: t.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 12),
                  _SettingsItem(
                    icon: LucideIcons.users,
                    iconBg: SoftPalette.emeraldSoft,
                    iconColor: SoftPalette.emerald,
                    title: 'Friends',
                    subtitle: 'People you split with',
                    onTap: () {
                      Navigator.pop(ctx);
                      context.push('/friends');
                    },
                  ),
                  Divider(height: 1, color: t.border),
                  _SettingsItem(
                    icon: LucideIcons.map,
                    iconBg: SoftPalette.emeraldSoft,
                    iconColor: SoftPalette.emerald,
                    title: 'Outings',
                    subtitle: 'Trips and shared expenses',
                    onTap: () {
                      Navigator.pop(ctx);
                      context.push('/outings');
                    },
                  ),
                ],
              ),
            ),
          ),
    );
  }

  void _showThemeSheet(BuildContext context) {
    final t = context.tokens;
    showModalBottomSheet(
      context: context,
      backgroundColor: t.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder:
          (ctx) => SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: t.border,
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ),
                  const SizedBox(height: 8),
                  _AppearanceSelector(
                    mode: ref.watch(themeModeProvider),
                    onChanged: (m) {
                      ref.read(themeModeProvider.notifier).setMode(m);
                      Navigator.pop(ctx);
                    },
                  ),
                ],
              ),
            ),
          ),
    );
  }

  void _showPrivacySheet(BuildContext context) {
    final t = context.tokens;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: t.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setModal) {
            final activeTrip = ref.watch(activeOutingProvider);
            final canToggleOutingPrivacy = ref.watch(
              canToggleOutingPrivacyProvider,
            );
            final outingPrivacy = ref.watch(outingPrivacyModeProvider);
            final privacyLive = ref.watch(isOutingPrivacyActiveProvider);
            final privateMode = ref.watch(privateModeProvider);
            final privateModeBlocked = privacyLive;
            return SafeArea(
              child: Padding(
                padding: EdgeInsets.fromLTRB(
                  8,
                  12,
                  8,
                  24 + MediaQuery.of(ctx).viewInsets.bottom,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'Privacy',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: t.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 8),
                    _SettingsSwitchItem(
                      icon: LucideIcons.eyeOff,
                      title: 'Outing Privacy Mode',
                      enabled: canToggleOutingPrivacy,
                      subtitle:
                          !canToggleOutingPrivacy
                              ? 'Start an active trip to enable'
                              : privacyLive
                              ? 'Live — trip-only home & activity'
                              : outingPrivacy
                              ? 'On — hiding balances for ${activeTrip?.title ?? 'trip'}'
                              : 'Off — turn on to hide balances during this trip',
                      value: canToggleOutingPrivacy ? outingPrivacy : false,
                      onChanged:
                          canToggleOutingPrivacy
                              ? (v) async {
                                if (v) {
                                  await ref
                                      .read(outingPrivacyModeProvider.notifier)
                                      .setEnabled(true);
                                } else {
                                  final ok =
                                      await PrivacyUnlockDialog.confirmDisable(
                                        context,
                                        ref,
                                      );
                                  if (!ok) return;
                                  await ref
                                      .read(outingPrivacyModeProvider.notifier)
                                      .setEnabled(false);
                                }
                                setModal(() {});
                                if (mounted) setState(() {});
                              }
                              : null,
                    ),
                    Divider(height: 1, color: t.border),
                    _SettingsSwitchItem(
                      icon: LucideIcons.lock,
                      title: 'Private Mode',
                      enabled: !privateModeBlocked,
                      subtitle:
                          privateModeBlocked
                              ? 'Unavailable while outing privacy is on'
                              : privateMode
                              ? 'Amounts on home show *****'
                              : 'Hide money amounts on home',
                      value: privateModeBlocked ? false : privateMode,
                      onChanged:
                          privateModeBlocked
                              ? null
                              : (v) async {
                                if (v) {
                                  await PrivateModeService.setEnabled(true);
                                  ref.read(privateModeProvider.notifier).state =
                                      true;
                                } else {
                                  final ok =
                                      await PrivacyUnlockDialog.confirmDisable(
                                        context,
                                        ref,
                                      );
                                  if (!ok) return;
                                  await PrivateModeService.setEnabled(false);
                                  ref.read(privateModeProvider.notifier).state =
                                      false;
                                }
                                setModal(() {});
                                if (mounted) setState(() {});
                              },
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _showSecuritySheet(BuildContext context) {
    final t = context.tokens;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: t.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setModal) {
            final hasPin = PinService.hasPin;
            final lockEnabled =
                Hive.box(
                  'settings',
                ).get('lock_screen_enabled', defaultValue: true) ==
                true;
            return SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(8, 12, 8, 24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'Security',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: t.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 8),
                    _SettingsItem(
                      icon: LucideIcons.key,
                      title: hasPin ? 'Change PIN' : 'Set PIN',
                      subtitle:
                          hasPin
                              ? 'Update your 4-digit PIN'
                              : 'Protect app with PIN',
                      onTap: () async {
                        Navigator.pop(ctx);
                        await context.push('/pin-setup');
                        if (mounted) setState(() {});
                      },
                    ),
                    Divider(height: 1, color: t.border),
                    _SettingsSwitchItem(
                      icon: LucideIcons.shieldCheck,
                      title: 'Lock Screen',
                      subtitle:
                          hasPin
                              ? 'Require PIN on startup'
                              : 'Set a PIN first to enable',
                      value: lockEnabled && hasPin,
                      onChanged:
                          hasPin
                              ? (v) async {
                                await Hive.box(
                                  'settings',
                                ).put('lock_screen_enabled', v);
                                setModal(() {});
                                if (mounted) setState(() {});
                              }
                              : null,
                    ),
                    if (hasPin) ...[
                      Divider(height: 1, color: t.border),
                      _SettingsSwitchItem(
                        icon: LucideIcons.fingerprint,
                        title: 'Fingerprint Authentication',
                        subtitle: 'Use biometrics for unlock when supported',
                        value: PinService.fingerprintEnabled,
                        onChanged: (v) async {
                          if (v) {
                            await PinService.enableFingerprint();
                          } else {
                            await PinService.disableFingerprint();
                          }
                          setModal(() {});
                          if (mounted) setState(() {});
                        },
                      ),
                      Divider(height: 1, color: t.border),
                      _SettingsItem(
                        icon: LucideIcons.refreshCw,
                        title: 'Reset PIN',
                        subtitle:
                            'Clear PIN with biometrics — or forgot PIN? Web Settings → Security',
                        subtitleLines: 3,
                        onTap: () {
                          Navigator.pop(ctx);
                          _resetPinWithFingerprint(context);
                        },
                      ),
                    ],
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _editProfileName(BuildContext context, String current) {
    final ctrl = TextEditingController(text: current);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    showDialog(
      context: context,
      builder:
          (ctx) => AlertDialog(
            backgroundColor: context.tokens.card,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            title: Text(
              'Edit profile name',
              style: TextStyle(
                color: context.tokens.textPrimary,
                fontWeight: FontWeight.w500,
              ),
            ),
            content: TextField(
              controller: ctrl,
              autofocus: true,
              style: TextStyle(color: context.tokens.textPrimary),
              decoration: InputDecoration(
                hintText: 'Your name',
                hintStyle: TextStyle(
                  color:
                      isDark
                          ? Colors.white.withValues(alpha: 0.3)
                          : AppColors.lightTextTertiary,
                ),
                filled: true,
                fillColor:
                    isDark
                        ? Colors.white.withValues(alpha: 0.06)
                        : AppColors.lightElevated,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text(
                  'Cancel',
                  style: TextStyle(color: context.tokens.textSecondary),
                ),
              ),
              TextButton(
                onPressed: () {
                  ref
                      .read(userStateProvider.notifier)
                      .updateProfileName(ctrl.text);
                  Navigator.pop(ctx);
                  setState(() {});
                },
                child: const Text(
                  'Save',
                  style: TextStyle(
                    color: AppColors.primary,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
    );
  }

  /// Sign out: ends the Supabase session only. Local Hive data + PIN stay
  /// intact (distinct from Reset App Data). Returns to /auth.
  Color _dialogFg(BuildContext c) =>
      Theme.of(c).brightness == Brightness.dark
          ? Colors.white
          : AppColors.lightTextPrimary;
  Color _dialogMuted(BuildContext c) =>
      Theme.of(c).brightness == Brightness.dark
          ? Colors.white70
          : AppColors.lightTextSecondary;

  void _handleSignOut(BuildContext context) {
    showDialog(
      context: context,
      builder:
          (ctx) => AlertDialog(
            backgroundColor:
                Theme.of(context).brightness == Brightness.dark
                    ? AppColors.darkElevated
                    : AppColors.lightCard,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            title: Text(
              'Sign out?',
              style: TextStyle(
                color: _dialogFg(ctx),
                fontWeight: FontWeight.w500,
              ),
            ),
            content: Text(
              'This signs you out and clears the data saved on this phone. Your cloud account stays. The next sign-in starts empty on this device.',
              style: TextStyle(color: _dialogMuted(ctx)),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text(
                  'Cancel',
                  style: TextStyle(color: _dialogMuted(ctx)),
                ),
              ),
              TextButton(
                onPressed: () async {
                  Navigator.pop(ctx);
                  try {
                    await AuthService.signOut();
                    if (context.mounted) context.go('/auth');
                  } catch (error) {
                    if (context.mounted) {
                      ScaffoldMessenger.of(
                        context,
                      ).showSnackBar(SnackBar(content: Text(error.toString())));
                    }
                  }
                },
                child: const Text(
                  'Sign Out',
                  style: TextStyle(
                    color: AppColors.expense,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
    );
  }

  void _handleResetApp(BuildContext context) {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            backgroundColor:
                Theme.of(context).brightness == Brightness.dark
                    ? AppColors.darkElevated
                    : AppColors.lightCard,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            title: Text(
              'Reset App Data?',
              style: TextStyle(
                color: _dialogFg(context),
                fontWeight: FontWeight.w500,
              ),
            ),
            content: Text(
              'This will erase ALL app data when you confirm Erase. Simply closing the app does nothing. Cannot be undone.',
              style: TextStyle(color: _dialogMuted(context)),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text(
                  'Cancel',
                  style: TextStyle(color: _dialogMuted(context)),
                ),
              ),
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  if (PinService.hasPin) {
                    _showPinVerificationForReset(context);
                  } else {
                    _showFingerprintVerificationForReset(context);
                  }
                },
                child: const Text(
                  'Continue',
                  style: TextStyle(
                    color: AppColors.expense,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
    );
  }

  Future<void> _resetPinWithFingerprint(BuildContext context) async {
    // Password/PIN reset option: requires fingerprint (primary), then clears PIN so user can set fresh one.
    // If fingerprint disabled or fails, user can still use "Change PIN" (which sets without re-verifying current).
    try {
      final localAuth = LocalAuthentication();
      final canCheck =
          await localAuth.canCheckBiometrics ||
          await localAuth.isDeviceSupported();
      if (!canCheck) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                'Biometrics not available on this device. Use Change PIN instead.',
              ),
              backgroundColor: AppColors.expense,
            ),
          );
        }
        return;
      }
      final authenticated = await localAuth.authenticate(
        localizedReason: 'Verify fingerprint to reset your PIN',
        options: const AuthenticationOptions(
          biometricOnly: false,
          stickyAuth: true,
          useErrorDialogs: true,
        ),
      );
      if (!context.mounted) return;
      if (authenticated) {
        await PinService.clearPin();
        // Ensure lock flag is off until new PIN set
        await Hive.box('settings').put('lock_screen_enabled', false);
        if (!context.mounted) return;
        setState(() {});
        // Go to setup to create the new one (will be labeled "Create a PIN")
        await context.push('/pin-setup');
        if (mounted) setState(() {});
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Fingerprint verification failed'),
            backgroundColor: AppColors.expense,
          ),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Fingerprint error: $e'),
            backgroundColor: AppColors.expense,
          ),
        );
      }
    }
  }

  void _showPinVerificationForReset(BuildContext context) {
    final pinController = TextEditingController();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder:
          (context) => AlertDialog(
            backgroundColor:
                Theme.of(context).brightness == Brightness.dark
                    ? AppColors.darkElevated
                    : AppColors.lightCard,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            title: Text(
              'Enter PIN to reset',
              style: TextStyle(
                color: _dialogFg(context),
                fontWeight: FontWeight.w500,
              ),
            ),
            content: TextField(
              controller: pinController,
              obscureText: true,
              keyboardType: TextInputType.number,
              maxLength: 4,
              textAlign: TextAlign.center,
              autofocus: true,
              style: TextStyle(
                color: _dialogFg(context),
                fontSize: 24,
                letterSpacing: 16,
              ),
              decoration: InputDecoration(
                counterText: '',
                hintText: '••••',
                hintStyle: TextStyle(color: _dialogMuted(context)),
                border: InputBorder.none,
              ),
              onSubmitted: (val) {
                if (val.length == 4) {
                  if (PinService.verifyPin(val)) {
                    Navigator.pop(context);
                    _confirmFinalReset(context);
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Incorrect PIN'),
                        backgroundColor: AppColors.expense,
                      ),
                    );
                    pinController.clear();
                  }
                }
              },
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text(
                  'Cancel',
                  style: TextStyle(color: _dialogMuted(context)),
                ),
              ),
              TextButton(
                onPressed: () {
                  final val = pinController.text;
                  if (val.length != 4) return;
                  if (PinService.verifyPin(val)) {
                    Navigator.pop(context);
                    _confirmFinalReset(context);
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Incorrect PIN'),
                        backgroundColor: AppColors.expense,
                      ),
                    );
                    pinController.clear();
                  }
                },
                child: const Text(
                  'Verify',
                  style: TextStyle(
                    color: AppColors.expense,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
    );
  }

  void _showFingerprintVerificationForReset(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder:
          (ctx) => AlertDialog(
            backgroundColor:
                Theme.of(context).brightness == Brightness.dark
                    ? AppColors.darkElevated
                    : AppColors.lightCard,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            title: Text(
              'Verify with Fingerprint',
              style: TextStyle(
                color: _dialogFg(ctx),
                fontWeight: FontWeight.w500,
              ),
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const BiometricUnlockBadge(),
                const SizedBox(height: 16),
                Text(
                  'Verify with biometrics to proceed with reset.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: _dialogMuted(ctx),
                    fontSize: 14,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: () async {
                      try {
                        final localAuth = LocalAuthentication();
                        final authenticated = await localAuth.authenticate(
                          localizedReason:
                              'Verify fingerprint to reset app data',
                          options: const AuthenticationOptions(
                            biometricOnly: false,
                            stickyAuth: true,
                            useErrorDialogs: true,
                          ),
                        );
                        if (authenticated) {
                          if (!ctx.mounted || !context.mounted) return;
                          Navigator.pop(ctx);
                          _confirmFinalReset(context);
                        } else {
                          if (ctx.mounted) {
                            ScaffoldMessenger.of(ctx).showSnackBar(
                              const SnackBar(
                                content: Text(
                                  'Fingerprint verification failed',
                                ),
                                backgroundColor: AppColors.expense,
                              ),
                            );
                          }
                        }
                      } catch (e) {
                        if (ctx.mounted) {
                          ScaffoldMessenger.of(ctx).showSnackBar(
                            SnackBar(
                              content: Text('Fingerprint error: $e'),
                              backgroundColor: AppColors.expense,
                            ),
                          );
                        }
                      }
                    },
                    style: FilledButton.styleFrom(
                      backgroundColor: SoftColors.control,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text(
                      'Verify',
                      style: TextStyle(fontWeight: FontWeight.w500),
                    ),
                  ),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text(
                  'Cancel',
                  style: TextStyle(color: _dialogMuted(ctx)),
                ),
              ),
            ],
          ),
    );
  }

  void _disablePrivacyModes() {
    // Fire-and-forget; ensures both are off post-verification in reset flow.
    PrivateModeService.setEnabled(false);
    ref.read(privateModeProvider.notifier).state = false;
    ref.read(outingPrivacyModeProvider.notifier).setEnabled(false);
  }

  void _confirmFinalReset(BuildContext context) {
    // After successful verification (reached here), turn off both privacy modes automatically
    // (as part of reset flow; if user cancels Erase, modes remain off but data not erased)
    _disablePrivacyModes();

    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            backgroundColor:
                Theme.of(context).brightness == Brightness.dark
                    ? AppColors.darkElevated
                    : AppColors.lightCard,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            title: Text(
              'Last chance',
              style: TextStyle(
                color: _dialogFg(context),
                fontWeight: FontWeight.w500,
              ),
            ),
            content: Text(
              'Erase all data and restart first-time setup on next open?',
              style: TextStyle(color: _dialogMuted(context)),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text(
                  'Cancel',
                  style: TextStyle(color: _dialogMuted(context)),
                ),
              ),
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  _performReset(context);
                },
                child: const Text(
                  'Erase',
                  style: TextStyle(
                    color: AppColors.expense,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
    );
  }

  Future<void> _performReset(BuildContext context) async {
    await AppResetService.resetAll();
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'All data erased and signed out. Close the app completely and reopen to sign in again from scratch.',
          ),
          backgroundColor: SoftPalette.ink,
          duration: Duration(seconds: 4),
        ),
      );
      // Close app so that on explicit reopen, first-time popup appears (per requirements).
      // Note: normal close/close app does not trigger erase.
      await Future.delayed(const Duration(milliseconds: 800));
      SystemNavigator.pop();
    }
  }
}

enum _MorePillKind { mint, slate }

class _MoreTone {
  _MoreTone._(this.dark);

  factory _MoreTone.of(BuildContext context) {
    return _MoreTone._(Theme.of(context).brightness == Brightness.dark);
  }

  final bool dark;

  static const _cardShadow = [
    BoxShadow(
      color: Color(0x0A0F172A),
      offset: Offset(0, 4),
      blurRadius: 16,
      spreadRadius: -2,
    ),
  ];

  Color get canvas => dark ? SoftPalette.darkBg : const Color(0xFFF8FAFC);
  Color get card => dark ? SoftPalette.darkCard : const Color(0xFFFFFFFF);
  Color get border => dark ? SoftPalette.darkBorder : const Color(0xFFF1F5F9);
  Color get ink => dark ? SoftPalette.darkInk : const Color(0xFF0F172A);
  Color get slate => dark ? SoftPalette.darkMuted : const Color(0xFF64748B);
  Color get muted => dark ? SoftPalette.darkFaint : const Color(0xFF94A3B8);
  Color get emerald => const Color(0xFF10B981);
  Color get emeraldDeep =>
      dark ? SoftPalette.darkEmerald : const Color(0xFF059669);
  Color get mint =>
      dark ? SoftPalette.darkEmeraldSoft : const Color(0xFFECFDF5);
  Color get mintMid => dark ? const Color(0xFF064E3B) : const Color(0xFFD1FAE5);
  Color get mintRing =>
      dark ? const Color(0xFF065F46) : const Color(0xFFA7F3D0);
  Color get press => dark ? const Color(0xFF27272A) : const Color(0xFFF8FAFC);
  Color get rose => const Color(0xFFE11D48);
  Color get roseLabel => const Color(0xFFF43F5E);
  Color get roseSurface =>
      dark ? const Color(0xFF3F1219) : const Color(0xFFFFF1F2);
  Color get roseBorder =>
      dark ? const Color(0xFF7F1D2D) : const Color(0xFFFECDD3);
  Color get roseCardBorder =>
      dark ? const Color(0xFF4C1D28) : const Color(0xFFFFE4E6);
  Color get rosePress =>
      dark ? const Color(0xFF3F1219) : const Color(0xFFFFF1F2);
  Color get slateFill =>
      dark ? SoftPalette.darkBorder : const Color(0xFFF1F5F9);

  List<BoxShadow>? get cardShadow => dark ? null : _cardShadow;
  List<BoxShadow>? get roseShadow => cardShadow;

  TextStyle text(
    double size,
    FontWeight weight,
    Color color, {
    double? letterSpacing,
    double? height,
  }) {
    return GoogleFonts.plusJakartaSans(
      fontSize: size,
      fontWeight: weight,
      color: color,
      letterSpacing: letterSpacing,
      height: height,
    );
  }
}

class _MoreProfileCard extends StatelessWidget {
  const _MoreProfileCard({
    required this.name,
    required this.email,
    required this.onEdit,
  });

  final String name;
  final String? email;
  final VoidCallback onEdit;

  String _initials(String value) {
    final parts =
        value
            .trim()
            .split(RegExp(r'\s+'))
            .where((part) => part.isNotEmpty)
            .toList();
    if (parts.isEmpty) return 'KT';
    if (parts.length == 1) {
      final word = parts.first;
      if (word.length >= 2) return word.substring(0, 2).toUpperCase();
      return word.substring(0, 1).toUpperCase();
    }
    return '${parts.first[0]}${parts[1][0]}'.toUpperCase();
  }

  @override
  Widget build(BuildContext context) {
    final tone = _MoreTone.of(context);
    final shown = name.trim().isEmpty ? 'You' : name.trim();
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onEdit,
        borderRadius: BorderRadius.circular(24),
        highlightColor: tone.press,
        splashColor: tone.press,
        child: Ink(
          decoration: BoxDecoration(
            color: tone.card,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: tone.border),
            boxShadow: tone.cardShadow,
          ),
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              SizedBox(
                width: 48,
                height: 48,
                child: Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Container(
                      width: 48,
                      height: 48,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: tone.mint,
                        shape: BoxShape.circle,
                        border: Border.all(color: tone.mintRing, width: 2),
                      ),
                      child: Text(
                        _initials(name),
                        style: tone.text(14, FontWeight.w700, tone.emeraldDeep),
                      ),
                    ),
                    Positioned(
                      right: -2,
                      bottom: -2,
                      child: Container(
                        width: 18,
                        height: 18,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: tone.card,
                          shape: BoxShape.circle,
                        ),
                        child: Container(
                          width: 14,
                          height: 14,
                          decoration: BoxDecoration(
                            color: tone.emerald,
                            shape: BoxShape.circle,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      shown,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: tone.text(16, FontWeight.w700, tone.ink),
                    ),
                    if (email != null && email!.trim().isNotEmpty) ...[
                      const SizedBox(height: 2),
                      Text(
                        email!.trim(),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: tone.text(13, FontWeight.w500, tone.slate),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Icon(LucideIcons.chevronRight, size: 18, color: tone.muted),
            ],
          ),
        ),
      ),
    );
  }
}

class _MoreVaultFooter extends StatelessWidget {
  const _MoreVaultFooter();

  @override
  Widget build(BuildContext context) {
    final tone = _MoreTone.of(context);
    return Padding(
      padding: const EdgeInsets.only(top: 6, bottom: 8),
      child: Column(
        children: [
          Text(
            'SpentX v$_kAppVersion',
            style: tone.text(12, FontWeight.w600, tone.slate),
          ),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(LucideIcons.lock, size: 12, color: tone.muted),
              const SizedBox(width: 6),
              Text(
                'Locally encrypted on this device',
                style: tone.text(11, FontWeight.w500, tone.muted),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _MorePill extends StatelessWidget {
  const _MorePill({required this.label, required this.kind});

  final String label;
  final _MorePillKind kind;

  @override
  Widget build(BuildContext context) {
    final tone = _MoreTone.of(context);
    final mint = kind == _MorePillKind.mint;
    return Container(
      constraints: const BoxConstraints(maxWidth: 140),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: mint ? tone.mintMid : tone.slateFill,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        label,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: tone.text(
          11,
          FontWeight.w700,
          mint ? tone.emeraldDeep : tone.slate,
        ),
      ),
    );
  }
}

class _SettingsGroup extends StatelessWidget {
  final String title;
  final List<Widget> children;
  final bool danger;

  const _SettingsGroup({
    required this.title,
    required this.children,
    this.danger = false,
  });

  @override
  Widget build(BuildContext context) {
    final tone = _MoreTone.of(context);
    final borderColor = danger ? tone.roseCardBorder : tone.border;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 8),
          child: Text(
            title.toUpperCase(),
            style: tone.text(
              11,
              FontWeight.w700,
              danger ? tone.roseLabel : tone.muted,
              letterSpacing: 1.2,
            ),
          ),
        ),
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            boxShadow: danger ? tone.roseShadow : tone.cardShadow,
          ),
          child: Material(
            color: tone.card,
            clipBehavior: Clip.antiAlias,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24),
              side: BorderSide(color: borderColor),
            ),
            child: Column(
              children: [
                for (var i = 0; i < children.length; i++) ...[
                  if (i > 0)
                    Divider(
                      height: 1,
                      thickness: 1,
                      indent: 16,
                      endIndent: 16,
                      color: borderColor,
                    ),
                  children[i],
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 18),
      ],
    );
  }
}

class _SettingsItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;
  final VoidCallback onTap;
  final bool isDanger;
  final Color? iconBg;
  final Color? iconColor;
  final String? pill;
  final _MorePillKind pillKind;
  final int subtitleLines;

  const _SettingsItem({
    required this.icon,
    required this.title,
    this.subtitle,
    required this.onTap,
    this.isDanger = false,
    this.iconBg,
    this.iconColor,
    this.pill,
    this.pillKind = _MorePillKind.slate,
    this.subtitleLines = 1,
  });

  @override
  Widget build(BuildContext context) {
    final tone = _MoreTone.of(context);
    final tileBg = isDanger ? tone.roseSurface : (iconBg ?? tone.mint);
    final tileFg = isDanger ? tone.rose : (iconColor ?? tone.emeraldDeep);
    final tileBorder = isDanger ? tone.roseBorder : tone.mintMid;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        highlightColor: isDanger ? tone.rosePress : tone.press,
        splashColor: isDanger ? tone.rosePress : tone.press,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: tileBg,
                  borderRadius: BorderRadius.circular(14),
                  border: isDanger ? Border.all(color: tileBorder) : null,
                ),
                child: Icon(icon, color: tileFg, size: 18),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: tone.text(
                        15,
                        FontWeight.w600,
                        isDanger ? tone.rose : tone.ink,
                      ),
                    ),
                    if (subtitle != null) ...[
                      const SizedBox(height: 2),
                      Text(
                        subtitle!,
                        maxLines: subtitleLines,
                        overflow: TextOverflow.ellipsis,
                        style: tone.text(13, FontWeight.w500, tone.slate),
                      ),
                    ],
                  ],
                ),
              ),
              if (pill != null) ...[
                const SizedBox(width: 8),
                _MorePill(label: pill!, kind: pillKind),
              ],
              const SizedBox(width: 2),
              Icon(
                LucideIcons.chevronRight,
                size: 18,
                color: isDanger ? tone.rose.withValues(alpha: 0.6) : tone.muted,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SettingsSwitchItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;
  final bool value;
  final bool enabled;
  final ValueChanged<bool>? onChanged;

  const _SettingsSwitchItem({
    required this.icon,
    required this.title,
    this.subtitle,
    required this.value,
    this.enabled = true,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final tone = _MoreTone.of(context);
    final inactive = !enabled || onChanged == null;
    return Opacity(
      opacity: inactive ? 0.45 : 1,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: tone.mint,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, color: tone.emeraldDeep, size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: tone.text(15, FontWeight.w600, tone.ink),
                  ),
                  if (subtitle != null) ...[
                    const SizedBox(height: 2),
                    Text(
                      subtitle!,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: tone.text(13, FontWeight.w500, tone.slate),
                    ),
                  ],
                ],
              ),
            ),
            Switch.adaptive(
              value: value,
              onChanged: inactive ? null : onChanged,
              activeTrackColor: SoftColors.control,
              activeThumbColor: Colors.white,
              inactiveTrackColor: tone.border,
              inactiveThumbColor: tone.slate,
            ),
          ],
        ),
      ),
    );
  }
}

/// System / Light / Dark selector. Replaces the old binary "Dark Mode" switch,
/// which had no way to express "follow the OS".
class _AppearanceSelector extends StatelessWidget {
  const _AppearanceSelector({required this.mode, required this.onChanged});

  final ThemeMode mode;
  final ValueChanged<ThemeMode> onChanged;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    const options = [
      (ThemeMode.system, 'System', LucideIcons.smartphone),
      (ThemeMode.light, 'Light', LucideIcons.sun),
      (ThemeMode.dark, 'Dark', LucideIcons.moon),
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: AppSpacing.xs),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(LucideIcons.palette, size: 18, color: t.textSecondary),
              const SizedBox(width: AppSpacing.sm),
              Text(
                'Appearance',
                style: AppType.body(
                  t.textPrimary,
                ).copyWith(fontWeight: FontWeight.w600),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.sm),
          Container(
            padding: const EdgeInsets.all(AppSpacing.xxs),
            decoration: BoxDecoration(
              color: t.field,
              borderRadius: AppRadius.tileR,
            ),
            child: Row(
              children: [
                for (final (m, label, icon) in options)
                  Expanded(
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () => onChanged(m),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 180),
                        height: 44,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: m == mode ? t.card : Colors.transparent,
                          borderRadius: AppRadius.iconButtonR,
                          border:
                              m == mode
                                  ? Border.all(color: t.border, width: 1)
                                  : null,
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              icon,
                              size: 15,
                              color: m == mode ? t.primary : t.textSecondary,
                            ),
                            const SizedBox(width: AppSpacing.xxs + 2),
                            Text(
                              label,
                              style: AppType.label(
                                m == mode ? t.textPrimary : t.textSecondary,
                              ).copyWith(
                                fontWeight:
                                    m == mode
                                        ? FontWeight.w600
                                        : FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
