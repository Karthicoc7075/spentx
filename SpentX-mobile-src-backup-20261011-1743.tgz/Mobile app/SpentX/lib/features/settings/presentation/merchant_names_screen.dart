import 'package:flutter/material.dart';
import '../../../core/theme/soft_palette.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../core/models/merchant_rule.dart';
import '../../../core/providers/merchant_provider.dart';
import '../../../core/providers/transaction_provider.dart';
import '../../../core/providers/user_state_provider.dart';
import '../../../core/utils/transaction_display_utils.dart';
import '../../../core/widgets/category_selector.dart';
import 'widgets/soft_merchant_widgets.dart';

class MerchantNamesScreen extends ConsumerStatefulWidget {
  const MerchantNamesScreen({super.key});

  @override
  ConsumerState<MerchantNamesScreen> createState() =>
      _MerchantNamesScreenState();
}

class _MerchantNamesScreenState extends ConsumerState<MerchantNamesScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final tone = MerchantTone(context);
    final rules = ref.watch(merchantProvider);
    final transactions = ref.watch(transactionProvider);

    final filteredRules =
        rules.where((rule) {
          final search = _searchQuery.toLowerCase();
          return rule.merchantName.toLowerCase().contains(search) ||
              rule.normalizedMerchantKey.toLowerCase().contains(search);
        }).toList();

    return Scaffold(
      backgroundColor: tone.canvas,
      body: SafeArea(
        bottom: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
              child: Row(
                children: [
                  MerchantCircleButton(
                    icon: Icons.arrow_back_ios_new_rounded,
                    tooltip: 'Back',
                    onPressed: () => Navigator.maybePop(context),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Merchants',
                          style: tone.text(22, FontWeight.w800, tone.ink),
                        ),
                        Text(
                          'Where money goes',
                          style: tone.text(13, FontWeight.w500, tone.slate),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                physics: const BouncingScrollPhysics(),
                padding: EdgeInsets.fromLTRB(
                  16,
                  16,
                  16,
                  24 + MediaQuery.paddingOf(context).bottom,
                ),
                children: [
                  Row(
                    children: [
                      Expanded(child: _searchField(tone)),
                      const SizedBox(width: 10),
                      _countChip(tone, filteredRules.length),
                    ],
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton.icon(
                      onPressed: () => _MerchantEditSheet.show(context, ref),
                      icon: const Icon(LucideIcons.plus, size: 18),
                      label: Text(
                        'Add Merchant',
                        style: tone.text(14, FontWeight.w700, Colors.white),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: SoftColors.control,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  if (filteredRules.isEmpty)
                    MerchantEmptyState(
                      message:
                          _searchQuery.isEmpty
                              ? 'No mappings yet'
                              : 'No results found',
                    )
                  else
                    for (final rule in filteredRules)
                      MerchantListRow(
                        name: rule.merchantName,
                        meta: _merchantMeta(
                          rule,
                          _merchantSpend(rule, transactions),
                        ),
                        icon: merchantIconByName(
                          MerchantVisualStore.get(rule.id)?.icon ?? 'store',
                        ),
                        tint:
                            MerchantVisualStore.get(rule.id)?.color ??
                            tone.emerald,
                        onTap:
                            () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder:
                                    (_) =>
                                        MerchantDetailScreen(ruleId: rule.id),
                              ),
                            ),
                      ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _searchField(MerchantTone tone) {
    return TextField(
      controller: _searchController,
      onChanged: (value) => setState(() => _searchQuery = value),
      style: tone.text(14, FontWeight.w600, tone.ink),
      decoration: InputDecoration(
        hintText: 'Search merchant or identifier...',
        hintStyle: tone.text(14, FontWeight.w500, tone.muted),
        prefixIcon: Icon(LucideIcons.search, size: 18, color: tone.slate),
        filled: true,
        fillColor: tone.card,
        contentPadding: const EdgeInsets.symmetric(vertical: 12),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: tone.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: tone.emerald, width: 1.4),
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: tone.border),
        ),
      ),
    );
  }

  Widget _countChip(MerchantTone tone, int count) {
    return Container(
      height: 48,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: tone.mint,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: tone.border),
      ),
      child: Text('$count', style: tone.text(14, FontWeight.w800, tone.ink)),
    );
  }
}

bool _merchantTxMatches(Transaction tx, MerchantRule rule) {
  if (tx.isPendingVerification) return false;
  final keys = <String>{
    rule.displayName.trim().toLowerCase(),
    rule.merchantName.trim().toLowerCase(),
    rule.identifier.trim().toLowerCase(),
    rule.normalizedIdentifierKey.trim().toLowerCase(),
    rule.normalizedMerchantKey.trim().toLowerCase(),
  }..removeWhere((key) => key.isEmpty);

  bool hit(String? value) {
    final text = value?.trim().toLowerCase() ?? '';
    if (text.isEmpty) return false;
    return keys.contains(text);
  }

  return hit(tx.merchant) ||
      hit(tx.rawIdentifier) ||
      hit(tx.upiId) ||
      hit(tx.title);
}

double _merchantSpend(MerchantRule rule, List<Transaction> transactions) {
  var total = 0.0;
  for (final tx in transactions) {
    if (!_merchantTxMatches(tx, rule)) continue;
    if (tx.isExpense && !tx.isTransfer) total += tx.amount.abs();
  }
  return total;
}

String _merchantMoney(num value) {
  return NumberFormat.currency(
    locale: 'en_IN',
    symbol: '₹',
    decimalDigits: 0,
  ).format(value.abs());
}

String _merchantMeta(MerchantRule rule, double spend) {
  final category = rule.defaultCategory.trim();
  final key = rule.normalizedMerchantKey.trim();
  if (spend > 0) {
    final money = _merchantMoney(spend);
    return category.isEmpty ? money : '$money · $category';
  }
  if (category.isEmpty) return key;
  if (key.isEmpty) return category;
  return '$category · $key';
}

class MerchantDetailScreen extends ConsumerWidget {
  final String ruleId;
  const MerchantDetailScreen({super.key, required this.ruleId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final tone = MerchantTone(context);
    final rules = ref.watch(merchantProvider);
    final rule = rules.where((item) => item.id == ruleId).firstOrNull;
    if (rule == null) {
      return Scaffold(
        backgroundColor: tone.canvas,
        body: Center(
          child: Text(
            'Not found',
            style: tone.text(16, FontWeight.w700, tone.ink),
          ),
        ),
      );
    }

    final mark = MerchantVisualStore.get(rule.id);
    final transactions = ref.watch(transactionProvider);
    final matched =
        transactions.where((tx) => _merchantTxMatches(tx, rule)).toList()
          ..sort((a, b) => b.date.compareTo(a.date));
    final spend = _merchantSpend(rule, transactions);
    final notes = mark?.notes.trim() ?? '';

    return Scaffold(
      backgroundColor: tone.canvas,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
              child: Row(
                children: [
                  MerchantCircleButton(
                    icon: Icons.arrow_back_ios_new_rounded,
                    tooltip: 'Back',
                    onPressed: () => Navigator.maybePop(context),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Merchant Details',
                      style: tone.text(20, FontWeight.w800, tone.ink),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                physics: const BouncingScrollPhysics(),
                padding: EdgeInsets.fromLTRB(
                  16,
                  16,
                  16,
                  24 + MediaQuery.paddingOf(context).bottom,
                ),
                children: [
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: tone.cardBox(),
                    child: Column(
                      children: [
                        MerchantIconSquare(
                          icon: merchantIconByName(mark?.icon ?? 'store'),
                          tint: mark?.color ?? tone.emerald,
                          size: 64,
                          radius: 20,
                        ),
                        const SizedBox(height: 14),
                        Text(
                          rule.merchantName,
                          textAlign: TextAlign.center,
                          style: tone.text(22, FontWeight.w800, tone.ink),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          rule.normalizedMerchantKey,
                          textAlign: TextAlign.center,
                          style: tone.text(13, FontWeight.w600, tone.slate),
                        ),
                        if (notes.isNotEmpty) ...[
                          const SizedBox(height: 8),
                          Text(
                            notes,
                            textAlign: TextAlign.center,
                            style: tone.text(13, FontWeight.w500, tone.slate),
                          ),
                        ],
                        const SizedBox(height: 16),
                        Text(
                          'TOTAL SPENT',
                          style: tone.text(
                            11,
                            FontWeight.w700,
                            tone.slate,
                            letterSpacing: 0.6,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          _merchantMoney(spend),
                          style: tone.text(28, FontWeight.w800, tone.ink),
                        ),
                        const SizedBox(height: 16),
                        _InfoRow(
                          label: 'Category',
                          value: rule.defaultCategory,
                        ),
                        _InfoRow(
                          label: 'Target Account',
                          value: rule.defaultPurposeType,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    'LEDGER · ${matched.length}',
                    style: tone.text(
                      12,
                      FontWeight.w700,
                      tone.slate,
                      letterSpacing: 0.6,
                    ),
                  ),
                  const SizedBox(height: 12),
                  if (matched.isEmpty)
                    const MerchantEmptyState(
                      message: 'No transactions for this merchant',
                    )
                  else
                    for (final tx in matched) _LedgerRow(tx: tx),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: ElevatedButton.icon(
                      onPressed:
                          () =>
                              _MerchantEditSheet.show(context, ref, rule: rule),
                      icon: const Icon(LucideIcons.edit3, size: 18),
                      label: Text(
                        'Edit Mapping',
                        style: tone.text(15, FontWeight.w700, Colors.white),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: SoftColors.control,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  TextButton.icon(
                    onPressed: () => _confirmDelete(context, ref, rule),
                    icon: Icon(LucideIcons.trash2, size: 18, color: tone.rose),
                    label: Text(
                      'Delete Mapping',
                      style: tone.text(14, FontWeight.w700, tone.rose),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _confirmDelete(BuildContext context, WidgetRef ref, MerchantRule rule) {
    final tone = MerchantTone(context);
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            backgroundColor: tone.card,
            surfaceTintColor: Colors.transparent,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24),
              side: BorderSide(color: tone.border),
            ),
            title: Text(
              'Delete Merchant Mapping?',
              style: tone.text(18, FontWeight.w800, tone.ink),
            ),
            content: Text(
              'Future transactions from "${rule.normalizedMerchantKey}" will no longer be auto-detected as "${rule.merchantName}".',
              style: tone.text(14, FontWeight.w500, tone.slate),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text(
                  'Cancel',
                  style: tone.text(14, FontWeight.w700, tone.slate),
                ),
              ),
              TextButton(
                onPressed: () {
                  ref.read(merchantProvider.notifier).deleteRule(rule.id);
                  MerchantVisualStore.remove(rule.id);
                  Navigator.pop(context);
                  Navigator.pop(context);
                },
                child: Text(
                  'Delete',
                  style: tone.text(14, FontWeight.w700, tone.rose),
                ),
              ),
            ],
          ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label, value;
  const _InfoRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    final tone = MerchantTone(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: tone.text(13, FontWeight.w600, tone.slate),
            ),
          ),
          const SizedBox(width: 12),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.end,
              style: tone.text(14, FontWeight.w700, tone.ink),
            ),
          ),
        ],
      ),
    );
  }
}

class _LedgerRow extends StatelessWidget {
  const _LedgerRow({required this.tx});

  final Transaction tx;

  @override
  Widget build(BuildContext context) {
    final tone = MerchantTone(context);
    final title = TransactionDisplayUtils.merchantTitle(tx);
    final when = TransactionDisplayUtils.formatListDateTime(
      tx.date,
      legacyTime: tx.time,
    );
    final category = tx.category.trim();
    final meta = category.isEmpty ? when : '$category · $when';
    final amount = _merchantMoney(tx.amount);
    late final String signed;
    late final Color color;
    if (tx.isTransfer) {
      signed = amount;
      color = tone.ink;
    } else if (tx.isExpense) {
      signed = '−$amount';
      color = tone.rose;
    } else {
      signed = '+$amount';
      color = tone.emerald;
    }

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => context.push('/transaction/${tx.id}'),
          borderRadius: BorderRadius.circular(24),
          child: Ink(
            decoration: tone.cardBox(),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title.isEmpty ? 'Transaction' : title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: tone.text(14, FontWeight.w700, tone.ink),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        meta,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: tone.text(12, FontWeight.w600, tone.slate),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Text(signed, style: tone.text(14, FontWeight.w800, color)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _MerchantEditSheet extends StatefulWidget {
  final MerchantRule? rule;
  final WidgetRef ref;
  const _MerchantEditSheet({this.rule, required this.ref});

  static void show(BuildContext context, WidgetRef ref, {MerchantRule? rule}) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => _MerchantEditSheet(rule: rule, ref: ref),
    );
  }

  @override
  State<_MerchantEditSheet> createState() => _MerchantEditSheetState();
}

class _MerchantEditSheetState extends State<_MerchantEditSheet> {
  late TextEditingController _nameCtrl;
  late TextEditingController _idCtrl;
  late TextEditingController _notesCtrl;
  late String _category;
  late String _account;
  late String _icon;
  late Color _color;
  bool _showValidationError = false;

  @override
  void initState() {
    super.initState();
    _nameCtrl = TextEditingController(
      text: widget.rule?.displayName ?? widget.rule?.merchantName,
    );
    _idCtrl = TextEditingController(
      text: widget.rule?.identifier ?? widget.rule?.normalizedMerchantKey,
    );
    final mark =
        widget.rule == null ? null : MerchantVisualStore.get(widget.rule!.id);
    _notesCtrl = TextEditingController(text: mark?.notes ?? '');
    _icon = mark?.icon ?? 'store';
    _color = mark?.color ?? const Color(0xFF10B981);
    _category = widget.rule?.defaultCategory ?? 'Food';
    _account = widget.rule?.defaultPurposeType ?? '';
    _nameCtrl.addListener(_refreshPreview);

    final userState = widget.ref.read(userStateProvider);
    if (_account.isEmpty || !userState.purposeTypes.contains(_account)) {
      _account = userState.purposeTypes.firstOrNull ?? 'Personal';
    }
  }

  void _refreshPreview() {
    if (!mounted) return;
    setState(() {});
  }

  @override
  void dispose() {
    _nameCtrl.removeListener(_refreshPreview);
    _nameCtrl.dispose();
    _idCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final tone = MerchantTone(context);
    final userState = widget.ref.watch(userStateProvider);
    final purposeTypes = userState.purposeTypes;
    final showPurposeSelector = purposeTypes.length > 1;

    if (purposeTypes.length == 1 && _account != purposeTypes.first) {
      _account = purposeTypes.first;
    }

    return Align(
      alignment: Alignment.bottomCenter,
      child: Container(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.sizeOf(context).height * 0.92,
        ),
        decoration: BoxDecoration(
          color: tone.card,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          border: Border.all(color: tone.border),
          boxShadow: tone.shadow,
        ),
        padding: EdgeInsets.fromLTRB(
          20,
          10,
          20,
          MediaQuery.viewInsetsOf(context).bottom +
              MediaQuery.paddingOf(context).bottom +
              16,
        ),
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: tone.border,
                    borderRadius: BorderRadius.circular(999),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Text(
                widget.rule == null ? 'Add Merchant' : 'Edit Merchant',
                style: tone.text(20, FontWeight.w800, tone.ink),
              ),
              const SizedBox(height: 16),
              if (_showValidationError) ...[
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: tone.roseSoft,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: tone.border),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        LucideIcons.alertTriangle,
                        color: tone.rose,
                        size: 18,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          'Identifier, display name, and category are required.',
                          style: tone.text(12, FontWeight.w600, tone.rose),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
              ],
              MerchantField(
                label: 'Name',
                controller: _nameCtrl,
                hint: 'e.g. Zomato, Google Pay, Swiggy',
              ),
              const SizedBox(height: 16),
              MerchantField(
                label: 'Identifier',
                controller: _idCtrl,
                hint: 'e.g. zomato@paytm, 9876543210, SWIGGY',
              ),
              const SizedBox(height: 16),
              MerchantIconColorPicker(
                iconName: _icon,
                color: _color,
                preview: _nameCtrl.text,
                onIcon: (value) => setState(() => _icon = value),
                onColor: (value) => setState(() => _color = value),
              ),
              const SizedBox(height: 16),
              MerchantField(
                label: 'Notes',
                controller: _notesCtrl,
                hint: 'Optional',
                maxLines: 3,
              ),
              const SizedBox(height: 16),
              Text('Category', style: tone.text(13, FontWeight.w700, tone.ink)),
              const SizedBox(height: 8),
              CategorySelector(
                type: CategoryType.expense,
                selected: _category,
                onChanged: (value) => setState(() => _category = value),
              ),
              if (showPurposeSelector) ...[
                const SizedBox(height: 16),
                Text(
                  'Purpose Type',
                  style: tone.text(13, FontWeight.w700, tone.ink),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final purpose in purposeTypes)
                      _ChoiceButton(
                        label: purpose,
                        isSelected: _account == purpose,
                        onTap: () => setState(() => _account = purpose),
                      ),
                  ],
                ),
              ],
              const SizedBox(height: 22),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  onPressed: _save,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: SoftColors.control,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  child: Text(
                    'Save',
                    style: tone.text(15, FontWeight.w700, Colors.white),
                  ),
                ),
              ),
              Center(
                child: TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text(
                    'Cancel',
                    style: tone.text(14, FontWeight.w700, tone.slate),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _save() async {
    final name = _nameCtrl.text.trim();
    final id = _idCtrl.text.trim();
    if (name.isEmpty || id.isEmpty || _category.isEmpty) {
      setState(() => _showValidationError = true);
      return;
    }
    final notes = _notesCtrl.text.trim();
    final icon = _icon;
    final color = _color;
    final notifier = widget.ref.read(merchantProvider.notifier);
    if (widget.rule != null) {
      await notifier.updateRule(
        widget.rule!.copyWith(
          identifier: id,
          normalizedIdentifierKey: id.toLowerCase(),
          displayName: name,
          defaultCategory: _category,
          defaultPurposeType: _account,
        ),
      );
      if (!mounted) return;
      MerchantVisualStore.put(
        widget.rule!.id,
        icon: icon,
        color: color,
        notes: notes,
      );
    } else {
      await notifier.saveRule(
        identifier: id,
        name: name,
        category: _category,
        accountType: _account,
      );
      if (!mounted) return;
      final saved =
          widget.ref
              .read(merchantProvider)
              .where(
                (rule) =>
                    rule.identifier.trim().toLowerCase() == id.toLowerCase() ||
                    rule.normalizedIdentifierKey.trim().toLowerCase() ==
                        id.toLowerCase(),
              )
              .firstOrNull;
      if (saved != null) {
        MerchantVisualStore.put(
          saved.id,
          icon: icon,
          color: color,
          notes: notes,
        );
      }
    }
    if (!mounted) return;
    Navigator.pop(context);
  }
}

class _ChoiceButton extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;
  const _ChoiceButton({
    required this.label,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final tone = MerchantTone(context);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: isSelected ? tone.emerald : tone.canvas,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: isSelected ? tone.emerald : tone.border),
        ),
        child: Text(
          label,
          style: tone.text(
            13,
            FontWeight.w700,
            isSelected ? Colors.white : tone.slate,
          ),
        ),
      ),
    );
  }
}
