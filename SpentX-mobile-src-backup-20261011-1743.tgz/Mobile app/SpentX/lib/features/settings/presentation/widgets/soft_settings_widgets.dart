import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../core/theme/soft_palette.dart';

/// Soft card surface for Settings groups and banners.
class SoftSettingsCard extends StatelessWidget {
  const SoftSettingsCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.color,
    this.onTap,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color? color;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final card = Container(
      padding: padding,
      decoration: BoxDecoration(
        color: color ?? (dark ? SoftPalette.darkCard : const Color(0xFFFFFFFF)),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: dark ? SoftPalette.darkBorder : const Color(0xFFF1F5F9),
        ),
        boxShadow:
            dark
                ? null
                : const [
                  BoxShadow(
                    color: Color(0x0A0F172A),
                    blurRadius: 16,
                    spreadRadius: -2,
                    offset: Offset(0, 4),
                  ),
                ],
      ),
      child: child,
    );
    if (onTap == null) return card;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: const BorderRadius.all(Radius.circular(24)),
        child: card,
      ),
    );
  }
}

/// Soft muted section label.
class SoftSettingsSectionHeader extends StatelessWidget {
  const SoftSettingsSectionHeader(this.title, {super.key});

  final String title;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 8, bottom: 12),
      child: Text(
        title.toUpperCase(),
        style: GoogleFonts.plusJakartaSans(
          color: SoftPalette.faint,
          fontSize: 11,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.2,
        ),
      ),
    );
  }
}

/// Soft profile hero (emerald soft wash, ink name).
class SoftSettingsProfileHero extends StatelessWidget {
  const SoftSettingsProfileHero({
    super.key,
    required this.name,
    this.email,
    this.onTap,
  });

  final String name;
  final String? email;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final initial = name.isNotEmpty ? name[0].toUpperCase() : 'U';
    return SoftSettingsCard(
      onTap: onTap,
      color: SoftPalette.emeraldSoft,
      padding: const EdgeInsets.all(18),
      child: Row(
        children: [
          Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(
              color: SoftPalette.card,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: SoftPalette.mint.withValues(alpha: 0.35),
              ),
            ),
            child: Center(
              child: Text(
                initial,
                style: const TextStyle(
                  color: SoftPalette.emerald,
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        name.isEmpty ? 'You' : name,
                        style: const TextStyle(
                          color: SoftPalette.ink,
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color: SoftPalette.emerald,
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: const Text(
                        'PRO',
                        style: TextStyle(
                          color: SoftPalette.onEmerald,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ],
                ),
                if (email != null && email!.isNotEmpty)
                  Text(
                    email!,
                    style: const TextStyle(
                      color: SoftPalette.muted,
                      fontSize: 13,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                const SizedBox(height: 2),
                const Text(
                  'Tap to edit profile',
                  style: TextStyle(
                    color: SoftPalette.emerald,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          const Icon(Icons.chevron_right, color: SoftPalette.faint, size: 20),
        ],
      ),
    );
  }
}
