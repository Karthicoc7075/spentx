import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/theme/soft_palette.dart';
import 'configure_icon_catalog.dart';

/// Soft Soft tokens for Accounts & Purposes. Dark mode uses SoftPalette.
class ConfigureTone {
  ConfigureTone(this.context);

  final BuildContext context;

  bool get dark => Theme.of(context).brightness == Brightness.dark;

  Color get canvas => dark ? SoftPalette.darkBg : const Color(0xFFF8FAFC);
  Color get card => dark ? SoftPalette.darkCard : const Color(0xFFFFFFFF);
  Color get border => dark ? SoftPalette.darkBorder : const Color(0xFFF1F5F9);
  Color get ink => dark ? SoftPalette.darkInk : const Color(0xFF0F172A);
  Color get slate => dark ? SoftPalette.darkMuted : const Color(0xFF64748B);
  Color get muted => dark ? SoftPalette.darkFaint : const Color(0xFF94A3B8);
  Color get emerald => dark ? SoftPalette.darkEmerald : const Color(0xFF10B981);
  Color get emeraldDeep =>
      dark ? SoftPalette.darkEmerald : const Color(0xFF059669);
  Color get mint =>
      dark ? SoftPalette.darkEmeraldSoft : const Color(0xFFECFDF5);
  Color get rose => const Color(0xFFE11D48);
  Color get roseSoft =>
      dark ? const Color(0xFF3F1218) : const Color(0xFFFFF1F2);
  Color get transfer => const Color(0xFF0369A1);
  Color get transferSoft =>
      dark ? const Color(0xFF082F49) : const Color(0xFFE0F2FE);

  List<BoxShadow> get shadow =>
      dark
          ? const []
          : const [
            BoxShadow(
              color: Color.fromRGBO(15, 23, 42, 0.04),
              offset: Offset(0, 4),
              blurRadius: 16,
              spreadRadius: -2,
            ),
          ];

  TextStyle text(
    double size,
    FontWeight weight,
    Color color, {
    double? letterSpacing,
    double? height,
  }) {
    return GoogleFonts.plusJakartaSans(
      fontSize: size,
      fontWeight: weight,
      color: color,
      letterSpacing: letterSpacing,
      height: height,
    );
  }

  BoxDecoration cardBox({Color? fill, double radius = 24}) {
    return BoxDecoration(
      color: fill ?? card,
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: border),
      boxShadow: shadow,
    );
  }
}

/// Calm swatches. No indigo or violet.
const configureSwatches = <Color>[
  Color(0xFF10B981),
  Color(0xFF059669),
  Color(0xFF0D9488),
  Color(0xFF14B8A6),
  Color(0xFF84CC16),
  Color(0xFFF59E0B),
  Color(0xFFD97706),
  Color(0xFFF97316),
  Color(0xFFE11D48),
  Color(0xFFEC4899),
  Color(0xFF64748B),
  Color(0xFF0F172A),
];

const configurePurposeIcons = <String>[
  'user',
  'users',
  'home',
  'heart',
  'briefcase',
  'baby',
  'graduationCap',
  'plane',
  'car',
  'utensils',
  'shoppingBag',
  'wallet',
  'piggyBank',
  'landmark',
  'target',
  'gift',
  'dog',
  'cat',
  'bookOpen',
  'music',
  'film',
  'dumbbell',
  'stethoscope',
  'palmtree',
  'building2',
  'laptop',
  'gamepad2',
  'coffee',
  'sparkles',
  'heartHandshake',
];

const configureAccountIcons = <String>[
  'landmark',
  'building2',
  'wallet',
  'banknote',
  'creditCard',
  'piggyBank',
  'coins',
  'briefcase',
  'home',
  'smartphone',
  'store',
  'receipt',
];

const configureContributorIcons = <String>[
  'user',
  'users',
  'heart',
  'briefcase',
  'home',
  'baby',
  'smile',
  'gift',
];

/// Names that ship as the built-in category lists. Anything else is custom.
const configureDefaultExpense = <String>[
  'Food & Dining',
  'Groceries',
  'Transportation',
  'Rent / Housing',
  'Utilities',
  'Healthcare',
  'Entertainment',
  'Shopping',
  'Education',
  'Travel',
  'Bills & EMI',
  'Personal Care',
  'Gifts & Donations',
  'Miscellaneous',
  'Investment',
];

const configureDefaultIncome = <String>[
  'Salary',
  'Freelance / Business',
  'Investments',
  'Rental Income',
  'Bonus',
  'Gifts Received',
  'Interest',
  'Other Income',
  'Friend Returns',
];

bool configureIsDefaultCategory(String type, String name) {
  final key = name.trim().toLowerCase();
  final source =
      type == 'income' ? configureDefaultIncome : configureDefaultExpense;
  return source.any((n) => n.toLowerCase() == key);
}

IconData configureIconByName(
  String name, {
  IconData fallback = LucideIcons.tag,
}) {
  return configureIconCatalog[name] ?? fallback;
}

IconData configureCategoryFallbackIcon(String name) {
  final key = name.toLowerCase();
  if (key.contains('food') || key.contains('dining')) {
    return LucideIcons.utensils;
  }
  if (key.contains('groc') || key.contains('shop')) {
    return LucideIcons.shoppingBag;
  }
  if (key.contains('transport') ||
      key.contains('travel') ||
      key.contains('fuel')) {
    return LucideIcons.car;
  }
  if (key.contains('rent') || key.contains('hous')) {
    return LucideIcons.home;
  }
  if (key.contains('util') || key.contains('bill') || key.contains('emi')) {
    return LucideIcons.receipt;
  }
  if (key.contains('health') || key.contains('care')) {
    return LucideIcons.heart;
  }
  if (key.contains('entertain') || key.contains('movie')) {
    return LucideIcons.film;
  }
  if (key.contains('edu')) {
    return LucideIcons.graduationCap;
  }
  if (key.contains('salary') ||
      key.contains('freelance') ||
      key.contains('bonus')) {
    return LucideIcons.briefcase;
  }
  if (key.contains('invest') || key.contains('interest')) {
    return LucideIcons.trendingUp;
  }
  if (key.contains('gift')) {
    return LucideIcons.gift;
  }
  if (key.contains('friend') || key.contains('rental')) {
    return LucideIcons.users;
  }
  return LucideIcons.tag;
}

/// Local icon and color choices. They tint this screen only and are not synced.
class ConfigureMarkStore {
  static const _key = 'configure_visual_marks';

  static Map<String, dynamic> _read() {
    if (!Hive.isBoxOpen('settings')) return {};
    final raw = Hive.box('settings').get(_key);
    if (raw is Map) {
      return raw.map((k, v) => MapEntry(k.toString(), v));
    }
    return {};
  }

  static void _write(Map<String, dynamic> data) {
    if (!Hive.isBoxOpen('settings')) return;
    Hive.box('settings').put(_key, data);
  }

  static ({String icon, Color color})? get(String scope, String id) {
    final scopeMap = _read()[scope];
    if (scopeMap is! Map) return null;
    final raw = scopeMap[id];
    if (raw is! Map) return null;
    final icon = raw['icon']?.toString() ?? '';
    final color = raw['color'];
    if (icon.isEmpty || color is! int) return null;
    return (icon: icon, color: Color(color));
  }

  static void put(String scope, String id, String icon, Color color) {
    final all = _read();
    final scopeMap = <String, dynamic>{};
    final existing = all[scope];
    if (existing is Map) {
      for (final entry in existing.entries) {
        scopeMap[entry.key.toString()] = entry.value;
      }
    }
    scopeMap[id] = {'icon': icon, 'color': color.toARGB32()};
    all[scope] = scopeMap;
    _write(all);
  }

  static void remove(String scope, String id) {
    final all = _read();
    final existing = all[scope];
    if (existing is! Map) return;
    final scopeMap = <String, dynamic>{};
    for (final entry in existing.entries) {
      if (entry.key.toString() == id) continue;
      scopeMap[entry.key.toString()] = entry.value;
    }
    all[scope] = scopeMap;
    _write(all);
  }

  static void rename(String scope, String from, String to) {
    if (from == to) return;
    final mark = get(scope, from);
    if (mark == null) return;
    put(scope, to, mark.icon, mark.color);
    remove(scope, from);
  }

  static String categoryId(String type, String name) =>
      '$type|${name.trim().toLowerCase()}';
}

class ConfigureCircleButton extends StatelessWidget {
  const ConfigureCircleButton({
    super.key,
    required this.icon,
    required this.onPressed,
    this.tooltip,
    this.iconSize = 18,
  });

  final IconData icon;
  final VoidCallback onPressed;
  final String? tooltip;
  final double iconSize;

  @override
  Widget build(BuildContext context) {
    final tone = ConfigureTone(context);
    final btn = Material(
      color: tone.card,
      elevation: 0,
      shape: CircleBorder(side: BorderSide(color: tone.border)),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onPressed,
        child: SizedBox(
          width: 40,
          height: 40,
          child: Icon(icon, size: iconSize, color: tone.ink),
        ),
      ),
    );
    if (tooltip == null) return btn;
    return Tooltip(message: tooltip!, child: btn);
  }
}

class ConfigureIconSquare extends StatelessWidget {
  const ConfigureIconSquare({
    super.key,
    required this.icon,
    required this.tint,
  });

  final IconData icon;
  final Color tint;

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      width: 40,
      height: 40,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: tint.withValues(alpha: dark ? 0.22 : 0.14),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Icon(icon, size: 18, color: tint),
    );
  }
}

class ConfigureSaveButton extends StatelessWidget {
  const ConfigureSaveButton({
    super.key,
    required this.label,
    required this.onPressed,
  });

  final String label;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final tone = ConfigureTone(context);
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: SoftColors.control,
          foregroundColor: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
        child: Text(label, style: tone.text(15, FontWeight.w700, Colors.white)),
      ),
    );
  }
}

class ConfigureTextField extends StatelessWidget {
  const ConfigureTextField({
    super.key,
    required this.label,
    required this.hint,
    required this.controller,
    this.keyboardType = TextInputType.text,
  });

  final String label;
  final String hint;
  final TextEditingController controller;
  final TextInputType keyboardType;

  @override
  Widget build(BuildContext context) {
    final tone = ConfigureTone(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: tone.text(13, FontWeight.w700, tone.ink)),
        const SizedBox(height: 8),
        TextField(
          controller: controller,
          keyboardType: keyboardType,
          style: tone.text(14, FontWeight.w600, tone.ink),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: tone.text(14, FontWeight.w500, tone.muted),
            filled: true,
            fillColor: tone.card,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 14,
              vertical: 14,
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide(color: tone.border),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide(color: tone.emerald, width: 1.4),
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide(color: tone.border),
            ),
          ),
        ),
      ],
    );
  }
}

/// Icon grid, then color swatches, with a live preview above the grid.
class ConfigureIconColorPicker extends StatefulWidget {
  const ConfigureIconColorPicker({
    super.key,
    required this.selectedIcon,
    required this.selectedColor,
    required this.onIcon,
    required this.onColor,
    required this.previewText,
    this.icons,
    this.searchable = false,
  });

  final String selectedIcon;
  final Color selectedColor;
  final ValueChanged<String> onIcon;
  final ValueChanged<Color> onColor;
  final String previewText;

  /// Curated names. Null uses the full Lucide catalog.
  final List<String>? icons;
  final bool searchable;

  @override
  State<ConfigureIconColorPicker> createState() =>
      _ConfigureIconColorPickerState();
}

class _ConfigureIconColorPickerState extends State<ConfigureIconColorPicker> {
  final _search = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  List<String> get _source =>
      widget.icons ?? configureIconCatalog.keys.toList();

  List<String> get _visible {
    final q = _query.trim().toLowerCase().replaceAll(RegExp(r'[\s_\-]'), '');
    if (q.isEmpty) return _source;
    return _source.where((name) => name.toLowerCase().contains(q)).toList();
  }

  @override
  Widget build(BuildContext context) {
    final tone = ConfigureTone(context);
    final names = _visible;
    final icon = configureIconByName(widget.selectedIcon);
    final preview =
        widget.previewText.trim().isEmpty
            ? 'Preview'
            : widget.previewText.trim();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(14),
          decoration: tone.cardBox(radius: 20),
          child: Row(
            children: [
              ConfigureIconSquare(icon: icon, tint: widget.selectedColor),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      preview,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: tone.text(15, FontWeight.w700, tone.ink),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Live preview',
                      style: tone.text(12, FontWeight.w500, tone.slate),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Text('Icon', style: tone.text(13, FontWeight.w700, tone.ink)),
        const SizedBox(height: 8),
        if (widget.searchable) ...[
          TextField(
            controller: _search,
            onChanged: (value) => setState(() => _query = value),
            style: tone.text(14, FontWeight.w600, tone.ink),
            decoration: InputDecoration(
              hintText: 'Search icons',
              hintStyle: tone.text(14, FontWeight.w500, tone.muted),
              prefixIcon: Icon(LucideIcons.search, size: 16, color: tone.slate),
              filled: true,
              fillColor: tone.card,
              contentPadding: const EdgeInsets.symmetric(vertical: 12),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide(color: tone.border),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide(color: tone.emerald, width: 1.4),
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide(color: tone.border),
              ),
            ),
          ),
          const SizedBox(height: 8),
        ],
        Container(
          height: widget.searchable ? 220 : 168,
          decoration: tone.cardBox(radius: 20),
          child:
              names.isEmpty
                  ? Center(
                    child: Text(
                      'No icons found',
                      style: tone.text(13, FontWeight.w600, tone.slate),
                    ),
                  )
                  : GridView.builder(
                    padding: const EdgeInsets.all(10),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 6,
                          mainAxisSpacing: 8,
                          crossAxisSpacing: 8,
                        ),
                    itemCount: names.length,
                    itemBuilder: (context, index) {
                      final name = names[index];
                      final selected = name == widget.selectedIcon;
                      return Material(
                        color: selected ? tone.mint : Colors.transparent,
                        borderRadius: BorderRadius.circular(12),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(12),
                          onTap: () => widget.onIcon(name),
                          child: Ink(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color:
                                    selected
                                        ? tone.emerald
                                        : Colors.transparent,
                                width: 1.4,
                              ),
                            ),
                            child: Icon(
                              configureIconByName(name),
                              size: 18,
                              color:
                                  selected ? widget.selectedColor : tone.slate,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
        ),
        const SizedBox(height: 14),
        Text('Color', style: tone.text(13, FontWeight.w700, tone.ink)),
        const SizedBox(height: 8),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            for (final color in configureSwatches)
              GestureDetector(
                onTap: () => widget.onColor(color),
                child: Container(
                  width: 28,
                  height: 28,
                  decoration: BoxDecoration(
                    color: color,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color:
                          widget.selectedColor.toARGB32() == color.toARGB32()
                              ? tone.ink
                              : Colors.transparent,
                      width: 2,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ],
    );
  }
}

class ConfigureSheetFrame extends StatelessWidget {
  const ConfigureSheetFrame({
    super.key,
    required this.title,
    required this.child,
  });

  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final tone = ConfigureTone(context);
    final inset = MediaQuery.viewInsetsOf(context).bottom;
    return Padding(
      padding: EdgeInsets.only(bottom: inset),
      child: Container(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.sizeOf(context).height * 0.92,
        ),
        decoration: BoxDecoration(
          color: tone.canvas,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          boxShadow: tone.shadow,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 10),
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: tone.border,
                borderRadius: BorderRadius.circular(999),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 14, 12, 0),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      title,
                      style: tone.text(20, FontWeight.w800, tone.ink),
                    ),
                  ),
                  ConfigureCircleButton(
                    icon: LucideIcons.x,
                    tooltip: 'Close',
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
            ),
            Flexible(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
                child: child,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
