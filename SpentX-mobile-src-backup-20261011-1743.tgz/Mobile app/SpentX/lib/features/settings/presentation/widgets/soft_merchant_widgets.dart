import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/theme/soft_palette.dart';

/// Soft Soft tokens for Merchants. Dark mode uses [SoftPalette] surfaces.
class MerchantTone {
  MerchantTone(this.context);

  final BuildContext context;

  bool get dark => Theme.of(context).brightness == Brightness.dark;

  Color get canvas => dark ? SoftPalette.darkBg : const Color(0xFFF8FAFC);
  Color get card => dark ? SoftPalette.darkCard : const Color(0xFFFFFFFF);
  Color get border => dark ? SoftPalette.darkBorder : const Color(0xFFF1F5F9);
  Color get ink => dark ? SoftPalette.darkInk : const Color(0xFF0F172A);
  Color get slate => dark ? SoftPalette.darkMuted : const Color(0xFF64748B);
  Color get muted => dark ? SoftPalette.darkFaint : const Color(0xFF94A3B8);
  Color get emerald => dark ? SoftPalette.darkEmerald : const Color(0xFF10B981);
  Color get emeraldDeep =>
      dark ? SoftPalette.darkEmerald : const Color(0xFF059669);
  Color get mint =>
      dark ? SoftPalette.darkEmeraldSoft : const Color(0xFFECFDF5);
  Color get rose => dark ? const Color(0xFFFB7185) : const Color(0xFFE11D48);
  Color get roseSoft =>
      dark ? const Color(0xFF3F1218) : const Color(0xFFFFF1F2);

  List<BoxShadow> get shadow =>
      dark
          ? const []
          : const [
            BoxShadow(
              color: Color.fromRGBO(15, 23, 42, 0.04),
              offset: Offset(0, 4),
              blurRadius: 16,
              spreadRadius: -2,
            ),
          ];

  TextStyle text(
    double size,
    FontWeight weight,
    Color color, {
    double? letterSpacing,
    double? height,
  }) {
    return GoogleFonts.plusJakartaSans(
      fontSize: size,
      fontWeight: weight,
      color: color,
      letterSpacing: letterSpacing,
      height: height,
    );
  }

  BoxDecoration cardBox({Color? fill, double radius = 24}) {
    return BoxDecoration(
      color: fill ?? card,
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: border),
      boxShadow: shadow,
    );
  }
}

/// Local icon, color, and notes for a merchant row. Not part of the
/// mapping rule, so detection and save payloads stay unchanged.
class MerchantVisualStore {
  MerchantVisualStore._();

  static const _key = 'merchant_visual_marks';

  static Map<String, dynamic> _read() {
    if (!Hive.isBoxOpen('settings')) return {};
    final raw = Hive.box('settings').get(_key);
    if (raw is! Map) return {};
    return Map<String, dynamic>.from(
      raw.map((key, value) => MapEntry(key.toString(), value)),
    );
  }

  static void _write(Map<String, dynamic> data) {
    if (!Hive.isBoxOpen('settings')) return;
    Hive.box('settings').put(_key, data);
  }

  static ({String icon, Color color, String notes})? get(String id) {
    final raw = _read()[id];
    if (raw is! Map) return null;
    final icon = raw['icon']?.toString() ?? '';
    final color = raw['color'];
    final notes = raw['notes']?.toString() ?? '';
    if (icon.isEmpty || color is! int) return null;
    return (icon: icon, color: Color(color), notes: notes);
  }

  static void put(
    String id, {
    required String icon,
    required Color color,
    required String notes,
  }) {
    final all = _read();
    all[id] = {'icon': icon, 'color': color.toARGB32(), 'notes': notes};
    _write(all);
  }

  static void remove(String id) {
    final all = _read();
    if (!all.containsKey(id)) return;
    all.remove(id);
    _write(all);
  }
}

const merchantIcons = <String, IconData>{
  'store': LucideIcons.store,
  'shoppingBag': LucideIcons.shoppingBag,
  'shoppingCart': LucideIcons.shoppingCart,
  'utensils': LucideIcons.utensils,
  'coffee': LucideIcons.coffee,
  'car': LucideIcons.car,
  'fuel': LucideIcons.fuel,
  'film': LucideIcons.film,
  'home': LucideIcons.home,
  'smartphone': LucideIcons.smartphone,
  'receipt': LucideIcons.receipt,
  'wallet': LucideIcons.wallet,
  'landmark': LucideIcons.landmark,
  'plane': LucideIcons.plane,
  'heart': LucideIcons.heart,
  'gift': LucideIcons.gift,
  'briefcase': LucideIcons.briefcase,
  'stethoscope': LucideIcons.stethoscope,
  'music': LucideIcons.music,
  'gamepad2': LucideIcons.gamepad2,
  'shirt': LucideIcons.shirt,
  'droplets': LucideIcons.droplets,
  'zap': LucideIcons.zap,
  'building2': LucideIcons.building2,
};

const merchantSwatches = <Color>[
  Color(0xFF10B981),
  Color(0xFF059669),
  Color(0xFF0D9488),
  Color(0xFF14B8A6),
  Color(0xFF84CC16),
  Color(0xFFF59E0B),
  Color(0xFFD97706),
  Color(0xFFF97316),
  Color(0xFFE11D48),
  Color(0xFFEC4899),
  Color(0xFF64748B),
  Color(0xFF0F172A),
];

IconData merchantIconByName(String name) {
  return merchantIcons[name] ?? LucideIcons.store;
}

class MerchantCircleButton extends StatelessWidget {
  const MerchantCircleButton({
    super.key,
    required this.icon,
    required this.onPressed,
    this.tooltip,
  });

  final IconData icon;
  final VoidCallback onPressed;
  final String? tooltip;

  @override
  Widget build(BuildContext context) {
    final tone = MerchantTone(context);
    final button = Material(
      color: tone.card,
      elevation: 0,
      shape: CircleBorder(side: BorderSide(color: tone.border)),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onPressed,
        child: SizedBox(
          width: 40,
          height: 40,
          child: Icon(icon, size: 18, color: tone.ink),
        ),
      ),
    );
    if (tooltip == null) return button;
    return Tooltip(message: tooltip!, child: button);
  }
}

class MerchantIconSquare extends StatelessWidget {
  const MerchantIconSquare({
    super.key,
    required this.icon,
    required this.tint,
    this.size = 40,
    this.radius = 14,
  });

  final IconData icon;
  final Color tint;
  final double size;
  final double radius;

  @override
  Widget build(BuildContext context) {
    final tone = MerchantTone(context);
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: tone.mint,
        borderRadius: BorderRadius.circular(radius),
      ),
      child: Icon(icon, size: size * 0.46, color: tint),
    );
  }
}

class MerchantField extends StatelessWidget {
  const MerchantField({
    super.key,
    required this.label,
    required this.controller,
    this.hint,
    this.maxLines = 1,
  });

  final String label;
  final TextEditingController controller;
  final String? hint;
  final int maxLines;

  @override
  Widget build(BuildContext context) {
    final tone = MerchantTone(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: tone.text(13, FontWeight.w700, tone.ink)),
        const SizedBox(height: 8),
        TextField(
          controller: controller,
          maxLines: maxLines,
          style: tone.text(14, FontWeight.w600, tone.ink),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: tone.text(14, FontWeight.w500, tone.muted),
            filled: true,
            fillColor: tone.card,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 14,
              vertical: 14,
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide(color: tone.border),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide(color: tone.emerald, width: 1.4),
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide(color: tone.border),
            ),
          ),
        ),
      ],
    );
  }
}

class MerchantIconColorPicker extends StatelessWidget {
  const MerchantIconColorPicker({
    super.key,
    required this.iconName,
    required this.color,
    required this.preview,
    required this.onIcon,
    required this.onColor,
  });

  final String iconName;
  final Color color;
  final String preview;
  final ValueChanged<String> onIcon;
  final ValueChanged<Color> onColor;

  @override
  Widget build(BuildContext context) {
    final tone = MerchantTone(context);
    final label = preview.trim().isEmpty ? 'Merchant' : preview.trim();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Icon and color', style: tone.text(13, FontWeight.w700, tone.ink)),
        const SizedBox(height: 8),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(14),
          decoration: tone.cardBox(radius: 20),
          child: Row(
            children: [
              MerchantIconSquare(
                icon: merchantIconByName(iconName),
                tint: color,
                size: 44,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: tone.text(15, FontWeight.w700, tone.ink),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        Container(
          height: 196,
          decoration: tone.cardBox(radius: 20),
          child: GridView.builder(
            padding: const EdgeInsets.all(10),
            physics: const BouncingScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 6,
              mainAxisSpacing: 8,
              crossAxisSpacing: 8,
            ),
            itemCount: merchantIcons.length,
            itemBuilder: (context, index) {
              final name = merchantIcons.keys.elementAt(index);
              final selected = name == iconName;
              return Material(
                color: selected ? tone.mint : Colors.transparent,
                borderRadius: BorderRadius.circular(12),
                child: InkWell(
                  onTap: () => onIcon(name),
                  borderRadius: BorderRadius.circular(12),
                  child: Ink(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: selected ? tone.emerald : Colors.transparent,
                      ),
                    ),
                    child: Icon(
                      merchantIcons[name],
                      size: 18,
                      color: selected ? color : tone.slate,
                    ),
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final swatch in merchantSwatches)
              GestureDetector(
                onTap: () => onColor(swatch),
                child: Container(
                  width: 28,
                  height: 28,
                  decoration: BoxDecoration(
                    color: swatch,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color:
                          swatch.toARGB32() == color.toARGB32()
                              ? tone.ink
                              : Colors.transparent,
                      width: 2,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ],
    );
  }
}

class MerchantListRow extends StatelessWidget {
  const MerchantListRow({
    super.key,
    required this.name,
    required this.meta,
    required this.icon,
    required this.tint,
    required this.onTap,
  });

  final String name;
  final String meta;
  final IconData icon;
  final Color tint;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final tone = MerchantTone(context);
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(24),
          child: Ink(
            decoration: tone.cardBox(),
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                MerchantIconSquare(icon: icon, tint: tint),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: tone.text(15, FontWeight.w700, tone.ink),
                      ),
                      if (meta.isNotEmpty) ...[
                        const SizedBox(height: 2),
                        Text(
                          meta,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: tone.text(12, FontWeight.w600, tone.slate),
                        ),
                      ],
                    ],
                  ),
                ),
                Icon(LucideIcons.chevronRight, size: 18, color: tone.slate),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class MerchantEmptyState extends StatelessWidget {
  const MerchantEmptyState({super.key, required this.message});

  final String message;

  @override
  Widget build(BuildContext context) {
    final tone = MerchantTone(context);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 36),
      decoration: tone.cardBox(),
      child: Column(
        children: [
          MerchantIconSquare(
            icon: LucideIcons.store,
            tint: tone.emeraldDeep,
            size: 56,
            radius: 18,
          ),
          const SizedBox(height: 14),
          Text(
            message,
            textAlign: TextAlign.center,
            style: tone.text(14, FontWeight.w700, tone.ink),
          ),
        ],
      ),
    );
  }
}
