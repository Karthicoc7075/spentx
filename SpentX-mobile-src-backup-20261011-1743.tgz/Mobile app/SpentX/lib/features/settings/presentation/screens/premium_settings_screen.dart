import 'package:flutter/material.dart';
import '../../../../core/theme/soft_palette.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/providers/category_provider.dart';
import '../../../../core/providers/contributor_provider.dart';
import '../../../../core/providers/user_state_provider.dart';
import '../../../../models/account_model.dart';
import '../widgets/soft_configure_widgets.dart';

const _bankSuggestions = [
  'SBI',
  'HDFC',
  'ICICI',
  'Axis',
  'Kotak',
  'Yes Bank',
  'PNB',
  'BOB',
  'Canara',
  'Union Bank',
  'IndusInd',
  'Federal',
];

class PremiumSettingsScreen extends ConsumerStatefulWidget {
  const PremiumSettingsScreen({super.key});

  @override
  ConsumerState<PremiumSettingsScreen> createState() =>
      _PremiumSettingsScreenState();
}

class _PremiumSettingsScreenState extends ConsumerState<PremiumSettingsScreen> {
  String _categoryFilter = 'expense';

  @override
  Widget build(BuildContext context) {
    final us = ref.watch(userStateProvider);
    final accounts = us.accounts;
    final purposes = us.purposeTypes;
    final contributors = ref.watch(contributorProvider);
    final categories = ref.watch(categoryProvider);
    final firstBankIdx = accounts.indexWhere((a) => a.type != 'Cash');
    final tone = ConfigureTone(context);

    final source =
        _categoryFilter == 'income'
            ? categories.income
            : _categoryFilter == 'expense'
            ? categories.expense
            : const <String>[];
    final defaults =
        source
            .where((name) => configureIsDefaultCategory(_categoryFilter, name))
            .toList();
    final custom =
        source
            .where((name) => !configureIsDefaultCategory(_categoryFilter, name))
            .toList();

    return Scaffold(
      backgroundColor: tone.canvas,
      body: SafeArea(
        bottom: false,
        child: ListView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
          children: [
            Row(
              children: [
                ConfigureCircleButton(
                  icon: Icons.arrow_back_ios_new_rounded,
                  iconSize: 16,
                  tooltip: 'Back',
                  onPressed: () => Navigator.maybePop(context),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Accounts & Purposes',
                    style: tone.text(
                      20,
                      FontWeight.w800,
                      tone.ink,
                      letterSpacing: -0.3,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Text(
              'Manage your financial architecture and institutional connections.',
              style: tone.text(13, FontWeight.w500, tone.slate, height: 1.45),
            ),
            const SizedBox(height: 24),
            _SectionTitle(
              title: 'Bank Accounts',
              count: '${accounts.length} / ${UserState.maxAccounts}',
            ),
            const SizedBox(height: 6),
            Text(
              accounts.length >= UserState.maxAccounts
                  ? 'Account limit reached. Delete one to add another.'
                  : 'Up to ${UserState.maxAccounts} accounts (Cash + banks).',
              style: tone.text(12, FontWeight.w500, tone.slate),
            ),
            const SizedBox(height: 12),
            ...accounts.asMap().entries.map((entry) {
              final idx = entry.key;
              final acc = entry.value;
              final isCash = acc.type == 'Cash';
              final isFirstBank = idx == firstBankIdx;
              return _AccountCard(
                account: acc,
                showEdit: !isCash,
                showDelete: !isCash && !isFirstBank,
                onEdit: () => _showAccountSheet(context, existing: acc),
                onDelete: () => _confirmDelete(context, acc),
                onSetDefault:
                    acc.isDefault
                        ? null
                        : () => ref
                            .read(userStateProvider.notifier)
                            .setDefaultAccount(acc.id),
              );
            }),
            _AddRow(
              label:
                  accounts.length >= UserState.maxAccounts
                      ? 'Account limit reached (${UserState.maxAccounts})'
                      : 'Add Institutional Account',
              onTap: () {
                if (accounts.length >= UserState.maxAccounts) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        'Account limit reached — maximum ${UserState.maxAccounts} accounts.',
                      ),
                      behavior: SnackBarBehavior.floating,
                    ),
                  );
                  return;
                }
                _showAccountSheet(context);
              },
            ),
            const SizedBox(height: 28),
            _SectionTitle(
              title: 'Purpose Types',
              count: '${purposes.length} / ${UserState.maxPurposes}',
            ),
            const SizedBox(height: 6),
            Text(
              purposes.length >= UserState.maxPurposes
                  ? 'Purpose limit reached. Delete a custom purpose to add another.'
                  : 'Up to ${UserState.maxPurposes} purposes (Personal, Family, custom).',
              style: tone.text(12, FontWeight.w500, tone.slate),
            ),
            const SizedBox(height: 12),
            _PurposeItem(
              name: 'Personal',
              iconName: 'user',
              showSwitch: false,
              showActions: false,
            ),
            _PurposeItem(
              name: 'Family',
              iconName: 'home',
              showSwitch: true,
              enabled: purposes.contains('Family'),
              onChanged: (v) {
                final cur = ref.read(userStateProvider).purposeTypes;
                if (v) {
                  if (!cur.contains('Family')) {
                    ref.read(userStateProvider.notifier).updatePurposes([
                      ...cur,
                      'Family',
                    ]);
                  }
                } else {
                  ref
                      .read(userStateProvider.notifier)
                      .updatePurposes(cur.where((x) => x != 'Family').toList());
                }
              },
              showActions: false,
            ),
            ...purposes
                .where((p) => p != 'Personal' && p != 'Family')
                .map(
                  (p) => _PurposeItem(
                    name: p,
                    iconName: 'layers',
                    showSwitch: false,
                    showActions: true,
                    onEdit: () => _showPurposeSheet(context, existing: p),
                    onDelete: () => _confirmPurposeDelete(context, p),
                  ),
                ),
            _AddRow(
              label:
                  purposes.length >= UserState.maxPurposes
                      ? 'Purpose limit reached'
                      : 'Create Custom Purpose',
              onTap: () {
                if (purposes.length >= UserState.maxPurposes) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        'Purpose limit reached — maximum ${UserState.maxPurposes}.',
                      ),
                      behavior: SnackBarBehavior.floating,
                    ),
                  );
                  return;
                }
                _showPurposeSheet(context);
              },
            ),
            const SizedBox(height: 28),
            Text(
              'Contributors',
              style: tone.text(16, FontWeight.w800, tone.ink),
            ),
            const SizedBox(height: 6),
            Text(
              'Who income belongs to. Default “Me” cannot be deleted.',
              style: tone.text(13, FontWeight.w500, tone.slate, height: 1.4),
            ),
            const SizedBox(height: 12),
            ...contributors.map((c) {
              final locked =
                  c.isDefault || !c.canDelete || c.name.toLowerCase() == 'me';
              return _ContributorItem(
                contributor: c,
                isDefault: c.isDefault || c.name.toLowerCase() == 'me',
                showDelete: !locked,
                onDelete: () => _confirmContributorDelete(context, c),
              );
            }),
            _AddRow(
              label: 'Add Contributor',
              onTap: () => _showContributorSheet(context),
            ),
            const SizedBox(height: 28),
            Text('Categories', style: tone.text(16, FontWeight.w800, tone.ink)),
            const SizedBox(height: 6),
            Text(
              'Default categories are shared. Custom ones are yours.',
              style: tone.text(13, FontWeight.w500, tone.slate),
            ),
            const SizedBox(height: 12),
            _CategoryFilters(
              selected: _categoryFilter,
              onChanged: (value) => setState(() => _categoryFilter = value),
            ),
            const SizedBox(height: 14),
            if (_categoryFilter == 'transfer')
              _EmptyCard(message: 'No transfer categories')
            else ...[
              _Subhead(label: 'DEFAULT · READ ONLY'),
              const SizedBox(height: 8),
              if (defaults.isEmpty)
                const _EmptyCard(message: 'No default categories')
              else
                ...defaults.map(
                  (name) => _CategoryRow(name: name, type: _categoryFilter),
                ),
              const SizedBox(height: 16),
              _Subhead(label: 'MY CUSTOM'),
              const SizedBox(height: 8),
              if (custom.isEmpty)
                const _EmptyCard(message: 'No custom categories yet')
              else
                ...custom.map(
                  (name) => _CategoryRow(name: name, type: _categoryFilter),
                ),
            ],
            const SizedBox(height: 8),
            _AddRow(
              label: 'Add Category',
              onTap:
                  () => _showCategorySheet(
                    context,
                    initialType:
                        _categoryFilter == 'income' ? 'income' : 'expense',
                  ),
            ),
          ],
        ),
      ),
    );
  }

  void _showContributorSheet(BuildContext ctx) {
    showModalBottomSheet(
      context: ctx,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder:
          (c) => _ContributorSheet(
            onSave: (name, icon, color) async {
              final created = await ref
                  .read(contributorProvider.notifier)
                  .addContributor(name);
              if (!c.mounted) return;
              Navigator.pop(c);
              if (created == null) {
                if (!ctx.mounted) return;
                ScaffoldMessenger.of(ctx).showSnackBar(
                  SnackBar(
                    content: Text('$name already exists'),
                    backgroundColor: ConfigureTone(ctx).rose,
                    behavior: SnackBarBehavior.floating,
                  ),
                );
                return;
              }
              ConfigureMarkStore.put('contributor', created.id, icon, color);
            },
          ),
    );
  }

  void _confirmContributorDelete(BuildContext ctx, Contributor c) {
    if (c.isDefault || !c.canDelete) return;
    final tone = ConfigureTone(ctx);
    showDialog(
      context: ctx,
      builder:
          (d) => AlertDialog(
            backgroundColor: tone.card,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24),
            ),
            title: Text(
              'Remove ${c.name}?',
              style: tone.text(18, FontWeight.w800, tone.ink),
            ),
            content: Text(
              'They will no longer appear on the income form.',
              style: tone.text(14, FontWeight.w500, tone.slate, height: 1.4),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(d),
                child: Text(
                  'Cancel',
                  style: tone.text(14, FontWeight.w700, tone.slate),
                ),
              ),
              TextButton(
                onPressed: () {
                  ConfigureMarkStore.remove('contributor', c.id);
                  ref
                      .read(contributorProvider.notifier)
                      .removeContributor(c.id);
                  Navigator.pop(d);
                },
                child: Text(
                  'Remove',
                  style: tone.text(14, FontWeight.w700, tone.rose),
                ),
              ),
            ],
          ),
    );
  }

  void _confirmDelete(BuildContext ctx, AccountModel acc) {
    final tone = ConfigureTone(ctx);
    showDialog(
      context: ctx,
      builder:
          (c) => AlertDialog(
            backgroundColor: tone.card,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24),
            ),
            title: Text(
              'Delete ${acc.name}?',
              style: tone.text(18, FontWeight.w800, tone.ink),
            ),
            content: Text(
              'This action cannot be undone.',
              style: tone.text(14, FontWeight.w500, tone.slate),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(c),
                child: Text(
                  'Cancel',
                  style: tone.text(14, FontWeight.w700, tone.slate),
                ),
              ),
              TextButton(
                onPressed: () {
                  ConfigureMarkStore.remove('account', acc.id);
                  ref.read(userStateProvider.notifier).removeAccount(acc.name, accountId: acc.id);
                  Navigator.pop(c);
                },
                child: Text(
                  'Delete',
                  style: tone.text(14, FontWeight.w700, tone.rose),
                ),
              ),
            ],
          ),
    );
  }

  void _showAccountSheet(BuildContext ctx, {AccountModel? existing}) {
    showModalBottomSheet(
      context: ctx,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _AccountBottomSheet(existing: existing),
    );
  }

  void _showPurposeSheet(BuildContext ctx, {String? existing}) {
    showModalBottomSheet(
      context: ctx,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder:
          (c) => _PurposeSheet(
            existing: existing,
            onSave: (name, icon, color) {
              final notifier = ref.read(userStateProvider.notifier);
              final cur = ref.read(userStateProvider).purposeTypes;
              if (existing != null) {
                ConfigureMarkStore.rename('purpose', existing, name);
                ConfigureMarkStore.put('purpose', name, icon, color);
                notifier.updatePurposes(
                  cur.map((p) => p == existing ? name : p).toList(),
                );
                Navigator.pop(c);
                return;
              }
              if (cur.any((p) => p.toLowerCase() == name.toLowerCase())) {
                Navigator.pop(c);
                return;
              }
              final ok = notifier.addPurpose(name);
              if (!ok) {
                ScaffoldMessenger.of(ctx).showSnackBar(
                  SnackBar(
                    content: Text(
                      'Purpose limit reached — maximum ${UserState.maxPurposes}.',
                    ),
                    behavior: SnackBarBehavior.floating,
                  ),
                );
                return;
              }
              ConfigureMarkStore.put('purpose', name, icon, color);
              Navigator.pop(c);
            },
          ),
    );
  }

  void _confirmPurposeDelete(BuildContext ctx, String p) {
    final tone = ConfigureTone(ctx);
    showDialog(
      context: ctx,
      builder:
          (c) => AlertDialog(
            backgroundColor: tone.card,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24),
            ),
            title: Text(
              'Delete $p?',
              style: tone.text(18, FontWeight.w800, tone.ink),
            ),
            content: Text(
              'Transactions using this purpose may need reassignment.',
              style: tone.text(14, FontWeight.w500, tone.slate, height: 1.4),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(c),
                child: Text(
                  'Cancel',
                  style: tone.text(14, FontWeight.w700, tone.slate),
                ),
              ),
              TextButton(
                onPressed: () {
                  ConfigureMarkStore.remove('purpose', p);
                  final cur = ref.read(userStateProvider).purposeTypes;
                  ref
                      .read(userStateProvider.notifier)
                      .updatePurposes(cur.where((x) => x != p).toList());
                  Navigator.pop(c);
                },
                child: Text(
                  'Delete',
                  style: tone.text(14, FontWeight.w700, tone.rose),
                ),
              ),
            ],
          ),
    );
  }

  void _showCategorySheet(BuildContext ctx, {required String initialType}) {
    showModalBottomSheet(
      context: ctx,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder:
          (c) => _CategorySheet(
            initialType: initialType,
            onSave: (name, type, icon, color) {
              if (type == 'transfer') {
                ScaffoldMessenger.of(ctx).showSnackBar(
                  const SnackBar(
                    content: Text('Transfers don’t use categories.'),
                    behavior: SnackBarBehavior.floating,
                  ),
                );
                return;
              }
              final cats = ref.read(categoryProvider);
              final list = type == 'income' ? cats.income : cats.expense;
              if (list.any(
                (item) => item.toLowerCase() == name.toLowerCase(),
              )) {
                ScaffoldMessenger.of(ctx).showSnackBar(
                  SnackBar(
                    content: Text('$name already exists'),
                    behavior: SnackBarBehavior.floating,
                  ),
                );
                return;
              }
              ConfigureMarkStore.put(
                'category',
                ConfigureMarkStore.categoryId(type, name),
                icon,
                color,
              );
              final notifier = ref.read(categoryProvider.notifier);
              if (type == 'income') {
                notifier.addIncomeCategory(name);
              } else {
                notifier.addExpenseCategory(name);
              }
              Navigator.pop(c);
              if (mounted) setState(() => _categoryFilter = type);
            },
          ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.title, required this.count});

  final String title;
  final String count;

  @override
  Widget build(BuildContext context) {
    final tone = ConfigureTone(context);
    return Row(
      children: [
        Expanded(
          child: Text(title, style: tone.text(16, FontWeight.w800, tone.ink)),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            color: tone.mint,
            borderRadius: BorderRadius.circular(999),
          ),
          child: Text(
            count,
            style: tone.text(12, FontWeight.w700, tone.emeraldDeep),
          ),
        ),
      ],
    );
  }
}

class _Subhead extends StatelessWidget {
  const _Subhead({required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    final tone = ConfigureTone(context);
    return Text(
      label,
      style: tone.text(12, FontWeight.w700, tone.muted, letterSpacing: 0.6),
    );
  }
}

class _AddRow extends StatelessWidget {
  const _AddRow({required this.label, required this.onTap});

  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final tone = ConfigureTone(context);
    return Padding(
      padding: const EdgeInsets.only(top: 4),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(24),
          child: Ink(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: tone.cardBox(),
            child: Row(
              children: [
                ConfigureIconSquare(icon: LucideIcons.plus, tint: tone.emerald),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    label,
                    style: tone.text(14, FontWeight.w700, tone.emeraldDeep),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _EmptyCard extends StatelessWidget {
  const _EmptyCard({required this.message});

  final String message;

  @override
  Widget build(BuildContext context) {
    final tone = ConfigureTone(context);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
      decoration: tone.cardBox(),
      child: Text(
        message,
        textAlign: TextAlign.center,
        style: tone.text(13, FontWeight.w600, tone.slate),
      ),
    );
  }
}

class _AccountCard extends StatelessWidget {
  const _AccountCard({
    required this.account,
    required this.showEdit,
    required this.showDelete,
    required this.onEdit,
    required this.onDelete,
    this.onSetDefault,
  });

  final AccountModel account;
  final bool showEdit;
  final bool showDelete;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final VoidCallback? onSetDefault;

  @override
  Widget build(BuildContext context) {
    final tone = ConfigureTone(context);
    final isCash = account.type == 'Cash';
    final mark = ConfigureMarkStore.get('account', account.id);
    final tint = mark?.color ?? tone.emerald;
    final icon =
        mark != null
            ? configureIconByName(mark.icon, fallback: LucideIcons.landmark)
            : (isCash ? LucideIcons.wallet : LucideIcons.landmark);
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: tone.cardBox(),
      child: Row(
        children: [
          ConfigureIconSquare(icon: icon, tint: tint),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        account.name,
                        overflow: TextOverflow.ellipsis,
                        style: tone.text(15, FontWeight.w700, tone.ink),
                      ),
                    ),
                    if (account.isDefault) ...[
                      const SizedBox(width: 6),
                      Icon(LucideIcons.star, size: 13, color: tone.emerald),
                    ],
                  ],
                ),
                const SizedBox(height: 2),
                Text(
                  isCash
                      ? 'Manual Balance'
                      : '...${account.last4Digits} • ${account.type}',
                  style: tone.text(12, FontWeight.w500, tone.slate),
                ),
              ],
            ),
          ),
          if (onSetDefault != null)
            _IconTap(icon: LucideIcons.star, onTap: onSetDefault!),
          if (showEdit) _IconTap(icon: LucideIcons.pencil, onTap: onEdit),
          if (showDelete) _IconTap(icon: LucideIcons.trash2, onTap: onDelete),
        ],
      ),
    );
  }
}

class _PurposeItem extends StatelessWidget {
  const _PurposeItem({
    required this.name,
    required this.iconName,
    this.showSwitch = true,
    this.enabled = true,
    this.onChanged,
    this.showActions = false,
    this.onEdit,
    this.onDelete,
  });

  final String name;
  final String iconName;
  final bool showSwitch;
  final bool enabled;
  final ValueChanged<bool>? onChanged;
  final bool showActions;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;

  @override
  Widget build(BuildContext context) {
    final tone = ConfigureTone(context);
    final mark = ConfigureMarkStore.get('purpose', name);
    final tint = mark?.color ?? tone.emerald;
    final icon =
        mark != null
            ? configureIconByName(mark.icon, fallback: LucideIcons.layers)
            : configureIconByName(iconName, fallback: LucideIcons.layers);
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: tone.cardBox(),
      child: Row(
        children: [
          ConfigureIconSquare(icon: icon, tint: tint),
          const SizedBox(width: 12),
          Expanded(
            child: Text(name, style: tone.text(15, FontWeight.w700, tone.ink)),
          ),
          if (showSwitch)
            Switch(
              value: enabled,
              onChanged: onChanged,
              activeThumbColor: Colors.white,
              activeTrackColor: SoftColors.control,
            ),
          if (showActions) ...[
            _IconTap(icon: LucideIcons.pencil, onTap: onEdit),
            _IconTap(icon: LucideIcons.trash2, onTap: onDelete),
          ],
        ],
      ),
    );
  }
}

class _ContributorItem extends StatelessWidget {
  const _ContributorItem({
    required this.contributor,
    required this.isDefault,
    required this.showDelete,
    this.onDelete,
  });

  final Contributor contributor;
  final bool isDefault;
  final bool showDelete;
  final VoidCallback? onDelete;

  @override
  Widget build(BuildContext context) {
    final tone = ConfigureTone(context);
    final mark = ConfigureMarkStore.get('contributor', contributor.id);
    final tint = mark?.color ?? tone.emerald;
    final icon =
        mark != null
            ? configureIconByName(mark.icon, fallback: LucideIcons.user)
            : (isDefault ? LucideIcons.user : LucideIcons.users);
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: tone.cardBox(),
      child: Row(
        children: [
          ConfigureIconSquare(icon: icon, tint: tint),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  contributor.name,
                  style: tone.text(15, FontWeight.w700, tone.ink),
                ),
                if (isDefault) ...[
                  const SizedBox(height: 2),
                  Text(
                    'Default · cannot delete',
                    style: tone.text(11, FontWeight.w600, tone.slate),
                  ),
                ],
              ],
            ),
          ),
          if (showDelete && onDelete != null)
            _IconTap(icon: LucideIcons.trash2, onTap: onDelete!),
        ],
      ),
    );
  }
}

class _CategoryFilters extends StatelessWidget {
  const _CategoryFilters({required this.selected, required this.onChanged});

  final String selected;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _TypeChip(
          label: 'Expense',
          value: 'expense',
          selected: selected,
          onChanged: onChanged,
        ),
        const SizedBox(width: 8),
        _TypeChip(
          label: 'Income',
          value: 'income',
          selected: selected,
          onChanged: onChanged,
        ),
        const SizedBox(width: 8),
        _TypeChip(
          label: 'Transfer',
          value: 'transfer',
          selected: selected,
          onChanged: onChanged,
        ),
      ],
    );
  }
}

class _TypeChip extends StatelessWidget {
  const _TypeChip({
    required this.label,
    required this.value,
    required this.selected,
    this.onChanged,
  });

  final String label;
  final String value;
  final String selected;
  final ValueChanged<String>? onChanged;

  @override
  Widget build(BuildContext context) {
    final tone = ConfigureTone(context);
    final on = selected == value;
    final Color fill;
    final Color ink;
    if (value == 'income') {
      fill = on ? tone.emerald : tone.mint;
      ink = on ? Colors.white : tone.emeraldDeep;
    } else if (value == 'transfer') {
      fill = on ? tone.transfer : tone.transferSoft;
      ink = on ? Colors.white : tone.transfer;
    } else {
      fill = on ? tone.rose : tone.roseSoft;
      ink = on ? Colors.white : tone.rose;
    }
    return GestureDetector(
      onTap: onChanged == null ? null : () => onChanged!(value),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: fill,
          borderRadius: BorderRadius.circular(999),
        ),
        child: Text(label, style: tone.text(12, FontWeight.w700, ink)),
      ),
    );
  }
}

class _CategoryRow extends StatelessWidget {
  const _CategoryRow({required this.name, required this.type});

  final String name;
  final String type;

  @override
  Widget build(BuildContext context) {
    final tone = ConfigureTone(context);
    final mark = ConfigureMarkStore.get(
      'category',
      ConfigureMarkStore.categoryId(type, name),
    );
    final tint = mark?.color ?? (type == 'income' ? tone.emerald : tone.rose);
    final icon =
        mark != null
            ? configureIconByName(mark.icon)
            : configureCategoryFallbackIcon(name);
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: tone.cardBox(),
      child: Row(
        children: [
          ConfigureIconSquare(icon: icon, tint: tint),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: tone.text(15, FontWeight.w700, tone.ink),
            ),
          ),
          _TypeChip(
            label: type == 'income' ? 'Income' : 'Expense',
            value: type,
            selected: type,
          ),
        ],
      ),
    );
  }
}

class _IconTap extends StatelessWidget {
  const _IconTap({required this.icon, required this.onTap});

  final IconData icon;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final tone = ConfigureTone(context);
    return GestureDetector(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Icon(icon, size: 16, color: tone.slate),
      ),
    );
  }
}

class _ContributorSheet extends StatefulWidget {
  const _ContributorSheet({required this.onSave});

  final Future<void> Function(String name, String icon, Color color) onSave;

  @override
  State<_ContributorSheet> createState() => _ContributorSheetState();
}

class _ContributorSheetState extends State<_ContributorSheet> {
  final _name = TextEditingController();
  String _icon = 'user';
  Color _color = const Color(0xFF10B981);

  @override
  void initState() {
    super.initState();
    _name.addListener(_refresh);
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _name.removeListener(_refresh);
    _name.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ConfigureSheetFrame(
      title: 'Add Contributor',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ConfigureTextField(
            label: 'Name',
            hint: 'Contributor name',
            controller: _name,
          ),
          const SizedBox(height: 6),
          Builder(
            builder: (context) {
              final tone = ConfigureTone(context);
              return Text(
                'e.g. Father, Spouse, Friend — used on income entries.',
                style: tone.text(12, FontWeight.w500, tone.slate),
              );
            },
          ),
          const SizedBox(height: 16),
          ConfigureIconColorPicker(
            selectedIcon: _icon,
            selectedColor: _color,
            previewText: _name.text,
            icons: configureContributorIcons,
            onIcon: (value) => setState(() => _icon = value),
            onColor: (value) => setState(() => _color = value),
          ),
          const SizedBox(height: 20),
          ConfigureSaveButton(
            label: 'Add',
            onPressed: () {
              final name = _name.text.trim();
              if (name.isEmpty) return;
              widget.onSave(name, _icon, _color);
            },
          ),
        ],
      ),
    );
  }
}

class _PurposeSheet extends StatefulWidget {
  const _PurposeSheet({required this.onSave, this.existing});

  final String? existing;
  final void Function(String name, String icon, Color color) onSave;

  @override
  State<_PurposeSheet> createState() => _PurposeSheetState();
}

class _PurposeSheetState extends State<_PurposeSheet> {
  late final TextEditingController _name;
  late String _icon;
  late Color _color;

  @override
  void initState() {
    super.initState();
    _name = TextEditingController(text: widget.existing ?? '');
    final mark =
        widget.existing == null
            ? null
            : ConfigureMarkStore.get('purpose', widget.existing!);
    _icon = mark?.icon ?? 'target';
    _color = mark?.color ?? const Color(0xFF10B981);
    _name.addListener(_refresh);
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _name.removeListener(_refresh);
    _name.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final editing = widget.existing != null;
    return ConfigureSheetFrame(
      title: editing ? 'Edit Purpose' : 'Create Custom Purpose',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ConfigureTextField(
            label: 'Purpose Name',
            hint: 'e.g. Business, Investments',
            controller: _name,
          ),
          const SizedBox(height: 16),
          ConfigureIconColorPicker(
            selectedIcon: _icon,
            selectedColor: _color,
            previewText: _name.text,
            icons: configurePurposeIcons,
            onIcon: (value) => setState(() => _icon = value),
            onColor: (value) => setState(() => _color = value),
          ),
          const SizedBox(height: 20),
          ConfigureSaveButton(
            label: editing ? 'Save Changes' : 'Add Purpose',
            onPressed: () {
              final name = _name.text.trim();
              if (name.isEmpty) return;
              widget.onSave(name, _icon, _color);
            },
          ),
        ],
      ),
    );
  }
}

class _CategorySheet extends StatefulWidget {
  const _CategorySheet({required this.initialType, required this.onSave});

  final String initialType;
  final void Function(String name, String type, String icon, Color color)
  onSave;

  @override
  State<_CategorySheet> createState() => _CategorySheetState();
}

class _CategorySheetState extends State<_CategorySheet> {
  final _name = TextEditingController();
  late String _type;
  String _icon = 'shoppingBag';
  Color _color = const Color(0xFF10B981);

  @override
  void initState() {
    super.initState();
    _type = widget.initialType;
    _name.addListener(_refresh);
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _name.removeListener(_refresh);
    _name.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final tone = ConfigureTone(context);
    return ConfigureSheetFrame(
      title: 'Add Category',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Type', style: tone.text(13, FontWeight.w700, tone.ink)),
          const SizedBox(height: 8),
          _CategoryFilters(
            selected: _type,
            onChanged: (value) => setState(() => _type = value),
          ),
          const SizedBox(height: 16),
          ConfigureTextField(
            label: 'Name',
            hint: 'Category name',
            controller: _name,
          ),
          const SizedBox(height: 16),
          ConfigureIconColorPicker(
            selectedIcon: _icon,
            selectedColor: _color,
            previewText: _name.text,
            searchable: true,
            onIcon: (value) => setState(() => _icon = value),
            onColor: (value) => setState(() => _color = value),
          ),
          const SizedBox(height: 20),
          ConfigureSaveButton(
            label: 'Save',
            onPressed: () {
              final name = _name.text.trim();
              if (name.isEmpty) return;
              widget.onSave(name, _type, _icon, _color);
            },
          ),
        ],
      ),
    );
  }
}

class _AccountBottomSheet extends ConsumerStatefulWidget {
  const _AccountBottomSheet({this.existing});

  final AccountModel? existing;

  @override
  ConsumerState<_AccountBottomSheet> createState() =>
      _AccountBottomSheetState();
}

class _AccountBottomSheetState extends ConsumerState<_AccountBottomSheet> {
  late final TextEditingController _last4;
  late final TextEditingController _balance;
  late final TextEditingController _customName;
  String _selectedBank = '';
  bool _isCustom = false;
  late String _icon;
  late Color _color;

  bool get _isEdit => widget.existing != null;

  @override
  void initState() {
    super.initState();
    _last4 = TextEditingController(text: widget.existing?.last4Digits ?? '');
    _balance = TextEditingController(
      text:
          widget.existing != null
              ? widget.existing!.openingBalance.toStringAsFixed(0)
              : '',
    );
    _customName = TextEditingController();
    final mark =
        widget.existing == null
            ? null
            : ConfigureMarkStore.get('account', widget.existing!.id);
    _icon = mark?.icon ?? 'landmark';
    _color = mark?.color ?? const Color(0xFF10B981);
    if (_isEdit) {
      if (_bankSuggestions.contains(widget.existing!.name)) {
        _selectedBank = widget.existing!.name;
      } else {
        _isCustom = true;
        _customName.text = widget.existing!.name;
      }
    }
    _customName.addListener(_refreshPreview);
  }

  void _refreshPreview() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _customName.removeListener(_refreshPreview);
    _last4.dispose();
    _balance.dispose();
    _customName.dispose();
    super.dispose();
  }

  String get _accountName =>
      _isCustom ? _customName.text.trim() : _selectedBank;

  void _save() {
    if (_accountName.isEmpty) return;
    final notifier = ref.read(userStateProvider.notifier);
    final String? error;
    final AccountModel saved;
    if (_isEdit) {
      saved = widget.existing!.copyWith(
        name: _accountName,
        last4Digits: _last4.text.trim(),
        type: 'Bank',
        openingBalance: double.tryParse(_balance.text) ?? 0,
      );
      error = notifier.updateAccount(saved);
    } else {
      saved = AccountModel(
        name: _accountName,
        type: 'Bank',
        last4Digits: _last4.text.trim(),
        openingBalance: double.tryParse(_balance.text) ?? 0,
      );
      error = notifier.addAccount(saved);
    }
    if (error != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(error),
          behavior: SnackBarBehavior.floating,
          backgroundColor: ConfigureTone(context).rose,
        ),
      );
      return;
    }
    ConfigureMarkStore.put('account', saved.id, _icon, _color);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final tone = ConfigureTone(context);
    return ConfigureSheetFrame(
      title: _isEdit ? 'Edit Account' : 'Add Account',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ConfigureIconColorPicker(
            selectedIcon: _icon,
            selectedColor: _color,
            previewText: _accountName,
            icons: configureAccountIcons,
            onIcon: (value) => setState(() => _icon = value),
            onColor: (value) => setState(() => _color = value),
          ),
          const SizedBox(height: 16),
          Text(
            'Account Selection',
            style: tone.text(13, FontWeight.w700, tone.ink),
          ),
          const SizedBox(height: 8),
          GestureDetector(
            onTap: () => _showSelectionPopup(context),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
              decoration: tone.cardBox(radius: 16),
              child: Row(
                children: [
                  Icon(LucideIcons.landmark, color: tone.emerald, size: 18),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      _accountName.isEmpty ? 'Select Bank' : _accountName,
                      style: tone.text(
                        14,
                        FontWeight.w600,
                        _accountName.isEmpty ? tone.muted : tone.ink,
                      ),
                    ),
                  ),
                  Icon(LucideIcons.chevronDown, size: 18, color: tone.slate),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          ConfigureTextField(
            label: 'Last 4 Digits',
            hint: '1234',
            controller: _last4,
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 16),
          ConfigureTextField(
            label: 'Balance',
            hint: '0',
            controller: _balance,
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 20),
          ConfigureSaveButton(
            label: _isEdit ? 'Save Changes' : 'Create Account',
            onPressed: _save,
          ),
          const SizedBox(height: 8),
          Center(
            child: TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                'Cancel',
                style: tone.text(14, FontWeight.w700, tone.slate),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showSelectionPopup(BuildContext context) {
    final tone = ConfigureTone(context);
    showDialog(
      context: context,
      builder:
          (ctx) => StatefulBuilder(
            builder:
                (context, setPopupState) => AlertDialog(
                  backgroundColor: tone.card,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(24),
                  ),
                  title: Text(
                    'Select Details',
                    style: tone.text(18, FontWeight.w800, tone.ink),
                  ),
                  content: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Bank Name',
                          style: tone.text(12, FontWeight.w700, tone.slate),
                        ),
                        const SizedBox(height: 12),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            ..._bankSuggestions.map(
                              (b) => _BankPill(
                                label: b,
                                selected: !_isCustom && _selectedBank == b,
                                onTap:
                                    () => setPopupState(() {
                                      _selectedBank = b;
                                      _isCustom = false;
                                    }),
                              ),
                            ),
                            _BankPill(
                              label: 'Other',
                              selected: _isCustom,
                              onTap:
                                  () => setPopupState(() {
                                    _isCustom = true;
                                    _selectedBank = '';
                                  }),
                            ),
                          ],
                        ),
                        if (_isCustom) ...[
                          const SizedBox(height: 16),
                          TextField(
                            controller: _customName,
                            style: tone.text(14, FontWeight.w600, tone.ink),
                            decoration: InputDecoration(
                              hintText: 'Enter bank name',
                              hintStyle: tone.text(
                                14,
                                FontWeight.w500,
                                tone.muted,
                              ),
                              filled: true,
                              fillColor: tone.canvas,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(16),
                                borderSide: BorderSide(color: tone.border),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(16),
                                borderSide: BorderSide(color: tone.border),
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () {
                        setState(() {});
                        Navigator.pop(ctx);
                      },
                      child: Text(
                        'Done',
                        style: tone.text(14, FontWeight.w700, tone.emeraldDeep),
                      ),
                    ),
                  ],
                ),
          ),
    );
  }
}

class _BankPill extends StatelessWidget {
  const _BankPill({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final tone = ConfigureTone(context);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? tone.emerald : tone.canvas,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: selected ? tone.emerald : tone.border),
        ),
        child: Text(
          label,
          style: tone.text(
            12,
            FontWeight.w700,
            selected ? Colors.white : tone.slate,
          ),
        ),
      ),
    );
  }
}
