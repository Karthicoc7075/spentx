import 'package:flutter/material.dart';
import '../../../../core/theme/spentx_tokens.dart';
import '../../../../core/theme/soft_palette.dart';
import '../../../../core/widgets/reference_ui.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../settings/data/sms_default_rules_catalog.dart';
import '../../../settings/data/sms_parser_rule_engine_prompt.dart';
import '../../../sms/rules/sms_rules_storage_inspector.dart';
import '../../../sms/rules/sms_template_rules_importer.dart';

class SmsRulesStorageScreen extends StatefulWidget {
  const SmsRulesStorageScreen({super.key});

  @override
  State<SmsRulesStorageScreen> createState() => _SmsRulesStorageScreenState();
}

class _SmsRulesStorageScreenState extends State<SmsRulesStorageScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs;
  final _importCtrl = TextEditingController();
  bool _loading = true;
  bool _importing = false;
  Map<String, dynamic>? _snapshot;
  String? _error;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 4, vsync: this);
    _reload();
  }

  @override
  void dispose() {
    _tabs.dispose();
    _importCtrl.dispose();
    super.dispose();
  }

  Future<void> _importPastedJson() async {
    final raw = _importCtrl.text.trim();
    if (raw.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Paste template rules JSON first')),
      );
      return;
    }
    setState(() => _importing = true);
    final result = await SmsTemplateRulesImporter.importFromJsonString(raw);
    if (!mounted) return;
    setState(() => _importing = false);
    await _reload();
    if (!mounted) return;
    final msg =
        result.errors.isEmpty
            ? 'Imported ${result.imported} rule(s), skipped ${result.skipped}'
            : 'Imported ${result.imported}, skipped ${result.skipped}. ${result.errors.first}';
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _reload() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final data = await SmsRulesStorageInspector.loadFullSnapshot();
      if (!mounted) return;
      setState(() {
        _snapshot = data;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  Future<void> _copy(String label, String text) async {
    await Clipboard.setData(ClipboardData(text: text));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('$label copied'),
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final summary = _snapshot?['hiveBoxSummary'] as Map<String, dynamic>?;

    final t = context.tokens;
    return Scaffold(
      backgroundColor: t.background,
      appBar: AppBar(
        backgroundColor: context.softBg,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        leadingWidth: 56,
        leading: Padding(
          padding: const EdgeInsets.only(left: 8),
          child: Center(
            child: SoftCircleIconButton(
              icon: Icons.arrow_back_ios_new_rounded,
              tooltip: 'Back',
              onPressed: () => Navigator.maybePop(context),
            ),
          ),
        ),
        title: Text(
          'SMS Rules Storage',
          style: AppType.section(context.softInk),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 4),
            child: SoftCircleIconButton(
              tooltip: 'Refresh',
              onPressed: _loading ? () {} : _reload,
              icon: LucideIcons.refreshCw,
            ),
          ),
          if (_snapshot != null)
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: SoftCircleIconButton(
                tooltip: 'Copy full snapshot',
                onPressed:
                    () => _copy(
                      'Full snapshot',
                      SmsRulesStorageInspector.formatJson(_snapshot),
                    ),
                icon: LucideIcons.copy,
              ),
            ),
        ],
        bottom: TabBar(
          controller: _tabs,
          isScrollable: true,
          indicatorColor: context.softEmerald,
          labelColor: context.softEmerald,
          unselectedLabelColor: context.softMuted,
          tabs: const [
            Tab(text: 'Flow'),
            Tab(text: 'Defaults'),
            Tab(text: 'Stored'),
            Tab(text: 'Prompt'),
          ],
        ),
      ),
      body:
          _error != null
              ? _buildError()
              : _loading && _snapshot == null
              ? const Center(child: CircularProgressIndicator())
              : Column(
                children: [
                  if (summary != null) _buildSummaryBar(summary),
                  Expanded(
                    child: TabBarView(
                      controller: _tabs,
                      children: [
                        _buildFlowTab(),
                        _buildDefaultsTab(),
                        _buildStoredTab(),
                        _buildPromptTab(),
                      ],
                    ),
                  ),
                ],
              ),
    );
  }

  Widget _buildError() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              LucideIcons.alertTriangle,
              color: AppColors.warning,
              size: 40,
            ),
            const SizedBox(height: 12),
            Text(
              _error!,
              textAlign: TextAlign.center,
              style: TextStyle(color: context.softMuted),
            ),
            const SizedBox(height: 16),
            FilledButton(onPressed: _reload, child: const Text('Retry')),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryBar(Map<String, dynamic> summary) {
    final template = summary['sms_template_rules_box'] ?? 0;
    final regex = summary['detection_rules_box'] ?? 0;
    final block = summary['block_rules_box'] ?? 0;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      color: context.softCard,
      child: Row(
        children: [
          _chip('Templates', template, AppColors.primary),
          const SizedBox(width: 8),
          _chip('Regex', regex, AppColors.upi),
          const SizedBox(width: 8),
          _chip('Block', block, AppColors.warning),
          const Spacer(),
          Text(
            _snapshot?['generatedAt']?.toString().substring(0, 19) ?? '',
            style: TextStyle(color: context.softFaint, fontSize: 10),
          ),
        ],
      ),
    );
  }

  Widget _chip(String label, dynamic count, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withValues(alpha: 0.35)),
      ),
      child: Text(
        '$label: $count',
        style: TextStyle(
          color: color,
          fontSize: 11,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  Widget _buildFlowTab() {
    final defaults = SmsDefaultRulesCatalog.toJson();
    final pipeline = List<String>.from(defaults['parsePipelineOrder'] as List);
    final addFlow = List<String>.from(defaults['addTemplateFlow'] as List);

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        _sectionTitle('How detection works', LucideIcons.gitBranch),
        const SizedBox(height: 8),
        Text(
          SmsDefaultRulesCatalog.storageNote,
          style: TextStyle(
            color: context.softMuted,
            fontSize: 13,
            height: 1.45,
          ),
        ),
        const SizedBox(height: 16),
        _sectionTitle('Parse pipeline', LucideIcons.listOrdered),
        const SizedBox(height: 8),
        ...pipeline.map((step) => _flowStep(step)),
        const SizedBox(height: 20),
        _sectionTitle('Add template rule flow', LucideIcons.layers),
        const SizedBox(height: 8),
        ...addFlow.asMap().entries.map(
          (e) => _numberedStep(e.key + 1, e.value),
        ),
        const SizedBox(height: 20),
        _sectionTitle('Hive boxes (user rules)', LucideIcons.database),
        const SizedBox(height: 8),
        _jsonCard(
          label: 'Box summary',
          data: _snapshot?['hiveBoxSummary'],
          onCopy:
              () => _copy(
                'Box summary',
                SmsRulesStorageInspector.formatJson(
                  _snapshot?['hiveBoxSummary'],
                ),
              ),
        ),
        const SizedBox(height: 16),
        OutlinedButton.icon(
          onPressed: () => context.push('/sms-detection-lab'),
          icon: const Icon(LucideIcons.beaker, size: 16),
          label: const Text('Open SMS Detection Lab'),
        ),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: () => context.push('/developer-options'),
          icon: const Icon(LucideIcons.code, size: 16),
          label: const Text('Developer Options → Add Template'),
        ),
      ],
    );
  }

  Widget _buildDefaultsTab() {
    final defaults =
        _snapshot?['defaultRules'] ?? SmsDefaultRulesCatalog.toJson();
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        _sectionTitle('Built-in rules (code)', LucideIcons.cpu),
        const SizedBox(height: 8),
        Text(
          'These ship with the app. They are not in Hive. Shown as structured JSON for inspection.',
          style: TextStyle(color: context.softMuted, fontSize: 12),
        ),
        const SizedBox(height: 12),
        _jsonCard(
          label: 'Default rules catalog',
          data: defaults,
          onCopy:
              () => _copy(
                'Default rules',
                SmsRulesStorageInspector.formatJson(defaults),
              ),
        ),
      ],
    );
  }

  Widget _buildStoredTab() {
    final stored = _snapshot?['storedRules'] as Map<String, dynamic>?;
    if (stored == null) {
      return Center(
        child: Text('No data', style: TextStyle(color: context.softFaint)),
      );
    }

    final sections = [
      (
        'Template rules',
        stored['templateRules'],
        LucideIcons.layers,
        AppColors.primary,
      ),
      (
        'Regex rules',
        stored['regexRules'],
        LucideIcons.fileSearch,
        AppColors.upi,
      ),
      (
        'Block rules',
        stored['blockRules'],
        LucideIcons.shieldAlert,
        AppColors.warning,
      ),
      (
        'Ignored SMS log (last 50)',
        stored['ignoredSmsLog'],
        LucideIcons.ban,
        context.softFaint,
      ),
      (
        'Processed SMS log (last 50)',
        stored['processedSmsLog'],
        LucideIcons.check,
        AppColors.income,
      ),
    ];

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        _sectionTitle('Import template JSON', LucideIcons.upload),
        const SizedBox(height: 8),
        Text(
          'Paste your default template rules JSON here → saves to Hive sms_template_rules_box.',
          style: TextStyle(color: context.softMuted, fontSize: 12),
        ),
        const SizedBox(height: 4),
        Text(
          'Bundled file (first install): ${SmsTemplateRulesImporter.bundledAssetPath}',
          style: TextStyle(color: context.softFaint, fontSize: 11),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _importCtrl,
          maxLines: 8,
          style: TextStyle(
            fontFamily: 'monospace',
            fontSize: 11,
            color: context.softMuted,
          ),
          decoration: InputDecoration(
            hintText: '[{...}] or {"rules": [{...}]}',
            hintStyle: TextStyle(color: context.softFaint, fontSize: 11),
            filled: true,
            fillColor: context.softSurfaceVariant,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
          ),
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: _importing ? null : _importPastedJson,
                icon:
                    _importing
                        ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                        : const Icon(LucideIcons.upload, size: 16),
                label: const Text('Import to Hive'),
                style: FilledButton.styleFrom(
                  backgroundColor: SoftColors.control,
                ),
              ),
            ),
            const SizedBox(width: 8),
            OutlinedButton(
              onPressed:
                  () => _copy(
                    'Example schema',
                    SmsTemplateRulesImporter.exampleSchemaJson(),
                  ),
              child: const Text('Schema'),
            ),
          ],
        ),
        const SizedBox(height: 24),
        _sectionTitle('Live Hive data', LucideIcons.hardDrive),
        const SizedBox(height: 8),
        Text(
          'Real stored rules on this device after import or Add Template training.',
          style: TextStyle(color: context.softMuted, fontSize: 12),
        ),
        const SizedBox(height: 16),
        ...sections.map((s) {
          final data = s.$2 as Map<String, dynamic>?;
          final count = data?['count'] ?? 0;
          final hiveBox = data?['hiveBox'] ?? '';
          return Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: _storedSection(
              title: s.$1,
              icon: s.$3,
              color: s.$4,
              hiveBox: hiveBox.toString(),
              count: count,
              data: data,
            ),
          );
        }),
        FilledButton.icon(
          onPressed:
              () => _copy(
                'All stored rules',
                SmsRulesStorageInspector.formatJson(stored),
              ),
          icon: const Icon(LucideIcons.copy, size: 16),
          label: const Text('Copy all stored rules JSON'),
          style: FilledButton.styleFrom(backgroundColor: SoftColors.control),
        ),
      ],
    );
  }

  Widget _buildPromptTab() {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Row(
          children: [
            Expanded(
              child: _sectionTitle(
                'SMS parser spec prompt',
                LucideIcons.fileText,
              ),
            ),
            FilledButton.icon(
              onPressed:
                  () => _copy('Parser prompt', smsParserRuleEnginePrompt),
              icon: const Icon(LucideIcons.copy, size: 14),
              label: const Text('Copy'),
              style: FilledButton.styleFrom(
                backgroundColor: SoftColors.control,
                visualDensity: VisualDensity.compact,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          '${smsParserRuleEnginePrompt.length} characters • bank rules, filters, template tags, pipeline order',
          style: TextStyle(color: context.softFaint, fontSize: 11),
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: context.softSurfaceVariant,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: AppColors.primary.withValues(alpha: 0.25),
            ),
          ),
          child: SelectableText(
            smsParserRuleEnginePrompt,
            style: TextStyle(
              fontFamily: 'monospace',
              fontSize: 11,
              height: 1.4,
              color: context.softMuted,
            ),
          ),
        ),
        const SizedBox(height: 16),
        OutlinedButton.icon(
          onPressed:
              _snapshot == null
                  ? null
                  : () => _copy(
                    'Full snapshot',
                    SmsRulesStorageInspector.formatJson(_snapshot),
                  ),
          icon: const Icon(LucideIcons.clipboardCopy, size: 16),
          label: const Text('Copy full snapshot (prompt + defaults + stored)'),
        ),
      ],
    );
  }

  Widget _sectionTitle(String text, IconData icon) {
    return Row(
      children: [
        Icon(icon, size: 16, color: AppColors.primary),
        const SizedBox(width: 8),
        Text(
          text,
          style: TextStyle(
            color: context.softInk,
            fontSize: 15,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  Widget _flowStep(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(
            LucideIcons.chevronRight,
            size: 14,
            color: AppColors.primary,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: TextStyle(color: context.softMuted, fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }

  Widget _numberedStep(int n, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 22,
            height: 22,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: AppColors.primary.withValues(alpha: 0.2),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Text(
              '$n',
              style: const TextStyle(
                color: AppColors.primary,
                fontSize: 11,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: TextStyle(color: context.softMuted, fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }

  Widget _jsonCard({
    required String label,
    required dynamic data,
    required VoidCallback onCopy,
  }) {
    final text =
        data == null ? '{}' : SmsRulesStorageInspector.formatJson(data);
    final isEmpty = data is Map && data.isEmpty;

    return Container(
      decoration: BoxDecoration(
        color: context.softCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: context.softBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 8, 8),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    label,
                    style: TextStyle(
                      color: context.softInk,
                      fontWeight: FontWeight.w500,
                      fontSize: 13,
                    ),
                  ),
                ),
                IconButton(
                  visualDensity: VisualDensity.compact,
                  tooltip: 'Copy',
                  onPressed: onCopy,
                  icon: const Icon(
                    LucideIcons.copy,
                    size: 16,
                    color: AppColors.primary,
                  ),
                ),
              ],
            ),
          ),
          Container(
            constraints: const BoxConstraints(maxHeight: 360),
            margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: context.softBg,
              borderRadius: BorderRadius.circular(12),
            ),
            child: SingleChildScrollView(
              child: SelectableText(
                isEmpty ? '(empty)' : text,
                style: TextStyle(
                  fontFamily: 'monospace',
                  fontSize: 11.5,
                  height: 1.35,
                  color: isEmpty ? Colors.white30 : context.softMuted,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _storedSection({
    required String title,
    required IconData icon,
    required Color color,
    required String hiveBox,
    required dynamic count,
    required Map<String, dynamic>? data,
  }) {
    final rulesKey =
        data?.containsKey('rules') == true
            ? 'rules'
            : data?.containsKey('entries') == true
            ? 'entries'
            : null;
    final items = rulesKey != null ? data![rulesKey] : null;
    final isEmpty = count == 0 || (items is List && items.isEmpty);

    return Container(
      decoration: BoxDecoration(
        color: context.softCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withValues(alpha: 0.25)),
      ),
      child: ExpansionTile(
        tilePadding: const EdgeInsets.symmetric(horizontal: 14),
        childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
        leading: Icon(icon, color: color, size: 20),
        title: Text(
          title,
          style: TextStyle(
            color: context.softInk,
            fontWeight: FontWeight.w500,
            fontSize: 14,
          ),
        ),
        subtitle: Text(
          '$hiveBox • $count items',
          style: TextStyle(color: context.softFaint, fontSize: 11),
        ),
        children: [
          if (isEmpty)
            Padding(
              padding: const EdgeInsets.all(12),
              child: Text(
                'No rules stored yet. Add via Developer Options → SMS Detection Rules → Add Template.',
                style: TextStyle(color: context.softFaint, fontSize: 12),
              ),
            )
          else
            _jsonCard(
              label: '$title JSON',
              data: data,
              onCopy:
                  () => _copy(title, SmsRulesStorageInspector.formatJson(data)),
            ),
        ],
      ),
    );
  }
}
