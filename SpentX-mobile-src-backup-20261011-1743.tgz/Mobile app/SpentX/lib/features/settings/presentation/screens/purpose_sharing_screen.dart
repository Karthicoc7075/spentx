import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:share_plus/share_plus.dart';
import '../../../../core/providers/contributor_provider.dart';
import '../../../../core/providers/user_state_provider.dart';
import '../../../../core/services/auth_service.dart';
import '../../../../core/sync/supabase_schema_map.dart';
import '../../../../core/theme/soft_palette.dart';
import '../../../../models/purpose_share_model.dart';
import '../../data/purpose_share_service.dart';

final purposeSharesProvider =
    AsyncNotifierProvider<PurposeSharesNotifier, List<PurposeShareModel>>(
      PurposeSharesNotifier.new,
    );

class PurposeSharesNotifier extends AsyncNotifier<List<PurposeShareModel>> {
  @override
  Future<List<PurposeShareModel>> build() async {
    void listener() {
      unawaited(refresh(showLoading: false));
    }

    PurposeShareService.onSharesChanged.addListener(listener);
    ref.onDispose(() {
      PurposeShareService.onSharesChanged.removeListener(listener);
    });

    return PurposeShareService.fetchShares();
  }

  Future<void> refresh({bool showLoading = true}) async {
    if (showLoading) {
      state = const AsyncValue.loading();
    }
    state = await AsyncValue.guard(() => PurposeShareService.fetchShares());
  }

  Future<void> createViewLink({
    required String purposeId,
    required String purposeName,
    String? contributorId,
    required String expiryPreset,
  }) async {
    await PurposeShareService.createViewLink(
      purposeId: purposeId,
      purposeName: purposeName,
      contributorId: contributorId,
      expiryPreset: expiryPreset,
    );
    await refresh();
  }

  Future<void> createEmailInvite({
    required String purposeId,
    required String purposeName,
    required String viewerEmail,
    String? contributorId,
    required String expiryPreset,
  }) async {
    await PurposeShareService.createEmailInvite(
      purposeId: purposeId,
      purposeName: purposeName,
      viewerEmail: viewerEmail,
      contributorId: contributorId,
      expiryPreset: expiryPreset,
    );
    await refresh();
  }

  Future<void> revoke({
    required String shareId,
    required String purposeId,
    String? linkToken,
    String? viewerEmail,
  }) async {
    await PurposeShareService.revokeShare(
      shareId: shareId,
      purposeId: purposeId,
      linkToken: linkToken,
      viewerEmail: viewerEmail,
    );
    await refresh();
  }
}

class PurposeSharingScreen extends ConsumerStatefulWidget {
  const PurposeSharingScreen({super.key});

  @override
  ConsumerState<PurposeSharingScreen> createState() =>
      _PurposeSharingScreenState();
}

class _PurposeSharingScreenState extends ConsumerState<PurposeSharingScreen> {
  final List<String> _expiryOptions = [
    '1 day',
    '7 days',
    '1 month',
    '6 months',
    'always',
  ];

  void _showNewShareSheet(BuildContext context) {
    final userState = ref.read(userStateProvider);
    final purposes =
        userState.purposeTypes.isNotEmpty
            ? userState.purposeTypes
            : ['Personal'];
    final contributors = ref.read(contributorProvider);

    String selectedPurpose = purposes.first;
    String? selectedContributorId;
    String selectedExpiry = 'always';
    String shareType = 'link'; // 'link' or 'email'
    final emailController = TextEditingController();
    bool isSubmitting = false;
    String? errorMessage;

    final sheetTone = PurposeShareTone(context);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: sheetTone.canvas,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder:
          (ctx) => StatefulBuilder(
            builder: (modalContext, setSheetState) {
              final tone = PurposeShareTone(ctx);
              final viewInsets = MediaQuery.of(ctx).viewInsets;

              Widget fieldLabel(String text) =>
                  Text(text, style: tone.text(13, FontWeight.w700, tone.ink));

              Widget modeChip(String value, String label) {
                final selected = shareType == value;
                return Expanded(
                  child: GestureDetector(
                    onTap:
                        () => setSheetState(() {
                          shareType = value;
                          errorMessage = null;
                        }),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 160),
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      decoration: BoxDecoration(
                        color: selected ? tone.card : Colors.transparent,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: selected ? tone.shadow : null,
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        label,
                        style: tone.text(
                          14,
                          FontWeight.w700,
                          selected ? tone.emerald : tone.slate,
                        ),
                      ),
                    ),
                  ),
                );
              }

              return Padding(
                padding: EdgeInsets.only(
                  left: 20,
                  right: 20,
                  top: 16,
                  bottom: viewInsets.bottom + 24,
                ),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Container(
                          width: 40,
                          height: 4,
                          decoration: BoxDecoration(
                            color: tone.border,
                            borderRadius: BorderRadius.circular(999),
                          ),
                        ),
                      ),
                      const SizedBox(height: 14),
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              'Share a Purpose',
                              style: tone.text(20, FontWeight.w800, tone.ink),
                            ),
                          ),
                          _ShareCircleButton(
                            icon: LucideIcons.x,
                            tooltip: 'Close',
                            onPressed: () => Navigator.pop(ctx),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: tone.track,
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Row(
                          children: [
                            modeChip('link', 'View Link'),
                            modeChip('email', 'Email Invite'),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                      fieldLabel('Select Purpose'),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          for (final purpose in purposes)
                            _ShareChoicePill(
                              label: purpose,
                              selected: selectedPurpose == purpose,
                              onTap:
                                  () => setSheetState(
                                    () => selectedPurpose = purpose,
                                  ),
                            ),
                        ],
                      ),
                      if (shareType == 'email') ...[
                        const SizedBox(height: 16),
                        fieldLabel('Recipient Email'),
                        const SizedBox(height: 8),
                        TextField(
                          controller: emailController,
                          keyboardType: TextInputType.emailAddress,
                          style: tone.text(14, FontWeight.w600, tone.ink),
                          decoration: InputDecoration(
                            hintText: 'name@example.com',
                            hintStyle: tone.text(
                              14,
                              FontWeight.w500,
                              tone.muted,
                            ),
                            filled: true,
                            fillColor: tone.card,
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 14,
                              vertical: 14,
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(16),
                              borderSide: BorderSide(color: tone.border),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(16),
                              borderSide: BorderSide(
                                color: tone.emerald,
                                width: 1.4,
                              ),
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(16),
                              borderSide: BorderSide(color: tone.border),
                            ),
                          ),
                        ),
                      ],
                      const SizedBox(height: 16),
                      fieldLabel('Limit to Contributor'),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14),
                        decoration: tone.cardBox(radius: 16),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<String?>(
                            value: selectedContributorId,
                            isExpanded: true,
                            dropdownColor: tone.card,
                            icon: Icon(
                              LucideIcons.chevronDown,
                              size: 18,
                              color: tone.slate,
                            ),
                            items: [
                              DropdownMenuItem<String?>(
                                value: null,
                                child: Text(
                                  'All Contributors',
                                  style: tone.text(
                                    14,
                                    FontWeight.w600,
                                    tone.ink,
                                  ),
                                ),
                              ),
                              ...contributors.map((c) {
                                return DropdownMenuItem<String?>(
                                  value: c.id,
                                  child: Text(
                                    c.name,
                                    style: tone.text(
                                      14,
                                      FontWeight.w600,
                                      tone.ink,
                                    ),
                                  ),
                                );
                              }),
                            ],
                            onChanged: (val) {
                              setSheetState(() => selectedContributorId = val);
                            },
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      fieldLabel('Expires In'),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          for (final option in _expiryOptions)
                            _ShareChoicePill(
                              label: option == 'always' ? 'Always' : option,
                              selected: selectedExpiry == option,
                              onTap:
                                  () => setSheetState(
                                    () => selectedExpiry = option,
                                  ),
                            ),
                        ],
                      ),
                      if (shareType == 'link') ...[
                        const SizedBox(height: 12),
                        Text(
                          '• Up to 3 active view links allowed per purpose.\n• Public page is view-only.',
                          style: tone.text(
                            12,
                            FontWeight.w500,
                            tone.slate,
                            height: 1.4,
                          ),
                        ),
                      ],
                      if (errorMessage != null) ...[
                        const SizedBox(height: 12),
                        Text(
                          errorMessage!,
                          style: tone.text(13, FontWeight.w600, tone.rose),
                        ),
                      ],
                      const SizedBox(height: 20),
                      SizedBox(
                        width: double.infinity,
                        height: 52,
                        child: ElevatedButton(
                          onPressed:
                              isSubmitting
                                  ? null
                                  : () async {
                                    setSheetState(() {
                                      isSubmitting = true;
                                      errorMessage = null;
                                    });

                                    try {
                                      final uid = AuthService.currentUserId;
                                      if (uid == null) {
                                        throw Exception(
                                          'You must be signed in.',
                                        );
                                      }
                                      final pId =
                                          RemoteIdCache.purposeId(
                                            selectedPurpose,
                                          ) ??
                                          SyncIds.forPurpose(
                                            uid,
                                            selectedPurpose,
                                          );

                                      if (shareType == 'link') {
                                        await ref
                                            .read(
                                              purposeSharesProvider.notifier,
                                            )
                                            .createViewLink(
                                              purposeId: pId,
                                              purposeName: selectedPurpose,
                                              contributorId:
                                                  selectedContributorId,
                                              expiryPreset: selectedExpiry,
                                            );
                                      } else {
                                        final email =
                                            emailController.text.trim();
                                        if (email.isEmpty) {
                                          throw Exception(
                                            'Please enter an email address.',
                                          );
                                        }
                                        await ref
                                            .read(
                                              purposeSharesProvider.notifier,
                                            )
                                            .createEmailInvite(
                                              purposeId: pId,
                                              purposeName: selectedPurpose,
                                              viewerEmail: email,
                                              contributorId:
                                                  selectedContributorId,
                                              expiryPreset: selectedExpiry,
                                            );
                                      }

                                      if (context.mounted) {
                                        Navigator.pop(ctx);
                                        ScaffoldMessenger.of(
                                          context,
                                        ).showSnackBar(
                                          SnackBar(
                                            content: Text(
                                              shareType == 'link'
                                                  ? 'Share link generated successfully.'
                                                  : 'Invite created successfully.',
                                            ),
                                            behavior: SnackBarBehavior.floating,
                                          ),
                                        );
                                      }
                                    } catch (e) {
                                      setSheetState(() {
                                        isSubmitting = false;
                                        errorMessage = e.toString().replaceAll(
                                          'Exception: ',
                                          '',
                                        );
                                      });
                                    }
                                  },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: SoftColors.control,
                            foregroundColor: Colors.white,
                            disabledBackgroundColor: tone.emerald.withValues(
                              alpha: 0.5,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                            ),
                            elevation: 0,
                          ),
                          child:
                              isSubmitting
                                  ? const SizedBox(
                                    width: 20,
                                    height: 20,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      color: Colors.white,
                                    ),
                                  )
                                  : Text(
                                    shareType == 'link'
                                        ? 'Generate View Link'
                                        : 'Send Invite',
                                    style: tone.text(
                                      15,
                                      FontWeight.w700,
                                      Colors.white,
                                    ),
                                  ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
    );
  }

  void _confirmRevoke(PurposeShareModel share) {
    final tone = PurposeShareTone(context);
    showDialog(
      context: context,
      builder:
          (ctx) => AlertDialog(
            backgroundColor: tone.card,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24),
            ),
            title: Text(
              'Revoke Sharing?',
              style: tone.text(18, FontWeight.w800, tone.ink),
            ),
            content: Text(
              share.isLink
                  ? 'This view link will immediately stop working for anyone who has it.'
                  : 'Access for ${share.viewerEmail} will be revoked immediately.',
              style: tone.text(14, FontWeight.w500, tone.slate, height: 1.4),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text(
                  'Cancel',
                  style: tone.text(14, FontWeight.w700, tone.slate),
                ),
              ),
              ElevatedButton(
                onPressed: () async {
                  Navigator.pop(ctx);
                  try {
                    await ref
                        .read(purposeSharesProvider.notifier)
                        .revoke(
                          shareId: share.id,
                          purposeId: share.purposeId,
                          linkToken: share.linkToken,
                          viewerEmail: share.viewerEmail,
                        );
                    if (mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Access revoked successfully.'),
                          behavior: SnackBarBehavior.floating,
                        ),
                      );
                    }
                  } catch (e) {
                    if (mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            e.toString().replaceAll('Exception: ', ''),
                          ),
                          backgroundColor: tone.rose,
                          behavior: SnackBarBehavior.floating,
                        ),
                      );
                    }
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundBuilder: SoftColors.plainBackground,
                  backgroundColor: tone.rose,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                child: Text(
                  'Revoke',
                  style: tone.text(14, FontWeight.w700, Colors.white),
                ),
              ),
            ],
          ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final sharesAsync = ref.watch(purposeSharesProvider);
    final tone = PurposeShareTone(context);

    return Scaffold(
      backgroundColor: tone.canvas,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
              child: Row(
                children: [
                  _ShareCircleButton(
                    icon: Icons.arrow_back_ios_new_rounded,
                    iconSize: 16,
                    tooltip: 'Back',
                    onPressed: () => Navigator.maybePop(context),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Purpose Sharing',
                      style: tone.text(
                        20,
                        FontWeight.w800,
                        tone.ink,
                        letterSpacing: -0.3,
                      ),
                    ),
                  ),
                  _ShareCircleButton(
                    icon: LucideIcons.refreshCw,
                    tooltip: 'Refresh',
                    onPressed:
                        () =>
                            ref.read(purposeSharesProvider.notifier).refresh(),
                  ),
                ],
              ),
            ),
            Expanded(
              child: sharesAsync.when(
                loading:
                    () => Center(
                      child: CircularProgressIndicator(color: tone.emerald),
                    ),
                error:
                    (err, _) => Center(
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              LucideIcons.alertTriangle,
                              size: 36,
                              color: tone.rose,
                            ),
                            const SizedBox(height: 12),
                            Text(
                              'Failed to load shares',
                              style: tone.text(16, FontWeight.w700, tone.ink),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              err.toString(),
                              textAlign: TextAlign.center,
                              style: tone.text(13, FontWeight.w500, tone.slate),
                            ),
                            const SizedBox(height: 16),
                            ElevatedButton(
                              onPressed:
                                  () =>
                                      ref
                                          .read(purposeSharesProvider.notifier)
                                          .refresh(),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: SoftColors.control,
                                foregroundColor: Colors.white,
                                elevation: 0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(16),
                                ),
                              ),
                              child: Text(
                                'Retry',
                                style: tone.text(
                                  14,
                                  FontWeight.w700,
                                  Colors.white,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                data: (shares) {
                  final activeShares =
                      shares.where((s) => s.status != 'revoked').toList();

                  return RefreshIndicator(
                    color: tone.emerald,
                    backgroundColor: tone.card,
                    onRefresh:
                        () =>
                            ref.read(purposeSharesProvider.notifier).refresh(),
                    child: ListView(
                      physics: const AlwaysScrollableScrollPhysics(
                        parent: BouncingScrollPhysics(),
                      ),
                      padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
                      children: [
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: tone.cardBox(fill: tone.mint),
                          child: Row(
                            children: [
                              _MintIcon(
                                icon: LucideIcons.shield,
                                color: tone.emerald,
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Scoped & Safe Sharing',
                                      style: tone.text(
                                        15,
                                        FontWeight.w800,
                                        tone.ink,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      'Share specific purpose views via secure link or email. Revoke anytime.',
                                      style: tone.text(
                                        13,
                                        FontWeight.w500,
                                        tone.slate,
                                        height: 1.35,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 20),
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                'ACTIVE SHARES (${activeShares.length})',
                                style: tone.text(
                                  12,
                                  FontWeight.w700,
                                  tone.muted,
                                  letterSpacing: 0.6,
                                ),
                              ),
                            ),
                            GestureDetector(
                              onTap: () => _showNewShareSheet(context),
                              behavior: HitTestBehavior.opaque,
                              child: Text(
                                '+ Share Purpose',
                                style: tone.text(
                                  13,
                                  FontWeight.w700,
                                  tone.emerald,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        if (activeShares.isEmpty)
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(
                              vertical: 28,
                              horizontal: 16,
                            ),
                            decoration: tone.cardBox(),
                            child: Column(
                              children: [
                                _MintIcon(
                                  icon: LucideIcons.share2,
                                  color: tone.emerald,
                                ),
                                const SizedBox(height: 12),
                                Text(
                                  'No active shares',
                                  style: tone.text(
                                    15,
                                    FontWeight.w700,
                                    tone.ink,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  'Invite someone to view a purpose or create a view link.',
                                  textAlign: TextAlign.center,
                                  style: tone.text(
                                    13,
                                    FontWeight.w500,
                                    tone.slate,
                                  ),
                                ),
                              ],
                            ),
                          )
                        else
                          ...activeShares.map(
                            (share) => _buildShareCard(share, tone),
                          ),
                        const SizedBox(height: 4),
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(14),
                          decoration: tone.cardBox(fill: tone.mint),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Icon(
                                LucideIcons.info,
                                size: 16,
                                color: tone.emerald,
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  'Up to 3 active view links allowed per purpose. Public page is view-only.',
                                  style: tone.text(
                                    13,
                                    FontWeight.w500,
                                    tone.slate,
                                    height: 1.35,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildShareCard(PurposeShareModel share, PurposeShareTone tone) {
    final isLink = share.isLink;
    final displayLabel = share.displayLabel;
    final purposeDisplay = share.purposeName ?? 'Purpose';

    String expiryText = 'Never expires';
    if (share.expiresAt != null) {
      if (share.isExpired) {
        expiryText = 'Expired';
      } else {
        final diff = share.expiresAt!.difference(DateTime.now());
        if (diff.inDays > 0) {
          expiryText = 'Expires in ${diff.inDays}d';
        } else if (diff.inHours > 0) {
          expiryText = 'Expires in ${diff.inHours}h';
        } else {
          expiryText = 'Expires soon';
        }
      }
    }

    final statusLabel =
        share.isExpired
            ? 'Expired'
            : share.status == 'active'
            ? 'Active'
            : 'Pending';
    final statusFill =
        share.isExpired
            ? tone.roseSoft
            : share.status == 'active'
            ? tone.mint
            : tone.amberSoft;
    final statusInk =
        share.isExpired
            ? tone.rose
            : share.status == 'active'
            ? tone.emerald
            : tone.amber;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: tone.cardBox(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _MintIcon(
                icon: isLink ? LucideIcons.link : LucideIcons.mail,
                color: isLink ? tone.teal : tone.emerald,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      displayLabel,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: tone.text(15, FontWeight.w700, tone.ink),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      purposeDisplay +
                          (share.contributorName != null
                              ? ' • Only ${share.contributorName}'
                              : ''),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: tone.text(13, FontWeight.w500, tone.slate),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: statusFill,
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  statusLabel,
                  style: tone.text(11, FontWeight.w700, statusInk),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Divider(height: 1, color: tone.border),
          const SizedBox(height: 10),
          Row(
            children: [
              Icon(LucideIcons.clock, size: 14, color: tone.muted),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  expiryText,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: tone.text(12, FontWeight.w600, tone.slate),
                ),
              ),
              if (isLink && share.shareUrl.isNotEmpty) ...[
                _ShareTextPill(
                  label: 'Copy',
                  onTap: () {
                    Clipboard.setData(ClipboardData(text: share.shareUrl));
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Link copied to clipboard'),
                        behavior: SnackBarBehavior.floating,
                      ),
                    );
                  },
                ),
                const SizedBox(width: 6),
                _ShareTextPill(
                  label: 'Share',
                  onTap: () {
                    SharePlus.instance.share(
                      ShareParams(
                        text:
                            'View ${share.purposeName ?? 'Purpose'} expenses: ${share.shareUrl}',
                      ),
                    );
                  },
                ),
                const SizedBox(width: 6),
              ],
              _ShareTextPill(
                label: 'Revoke',
                rose: true,
                onTap: () => _confirmRevoke(share),
              ),
            ],
          ),
          if (share.lastViewedAt != null || share.totalViews > 0) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: tone.mint,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(LucideIcons.eye, size: 12, color: tone.emerald),
                  const SizedBox(width: 6),
                  Text(
                    share.lastViewedAt != null
                        ? 'Last viewed ${_formatRelativeTime(share.lastViewedAt!)} • ${share.totalViews} ${share.totalViews == 1 ? "view" : "views"}'
                        : '${share.totalViews} ${share.totalViews == 1 ? "view" : "views"}',
                    style: tone.text(11, FontWeight.w600, tone.emerald),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  String _formatRelativeTime(DateTime dt) {
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.isNegative || diff.inSeconds < 60) return 'Just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    if (diff.inDays < 7) return '${diff.inDays}d ago';
    return '${dt.day}/${dt.month}/${dt.year}';
  }
}

class PurposeShareTone {
  PurposeShareTone(this.context);

  final BuildContext context;

  bool get dark => Theme.of(context).brightness == Brightness.dark;

  Color get canvas => dark ? SoftPalette.darkBg : const Color(0xFFF8FAFC);
  Color get card => dark ? SoftPalette.darkCard : const Color(0xFFFFFFFF);
  Color get border => dark ? SoftPalette.darkBorder : const Color(0xFFF1F5F9);
  Color get ink => dark ? SoftPalette.darkInk : const Color(0xFF0F172A);
  Color get slate => dark ? SoftPalette.darkMuted : const Color(0xFF64748B);
  Color get muted => dark ? SoftPalette.darkFaint : const Color(0xFF94A3B8);
  Color get emerald => dark ? SoftPalette.darkEmerald : const Color(0xFF059669);
  Color get teal => dark ? SoftPalette.darkEmerald : const Color(0xFF008966);
  Color get mint =>
      dark ? SoftPalette.darkEmeraldSoft : const Color(0xFFECFDF5);
  Color get track => dark ? SoftPalette.darkBorder : const Color(0xFFF1F5F9);
  Color get rose => const Color(0xFFE11D48);
  Color get roseSoft =>
      dark ? const Color(0xFF3F1218) : const Color(0xFFFFF1F2);
  Color get amber => const Color(0xFFC2410C);
  Color get amberSoft =>
      dark ? const Color(0xFF3F2A12) : const Color(0xFFFFF7ED);

  List<BoxShadow> get shadow =>
      dark
          ? const []
          : const [
            BoxShadow(
              color: Color(0x0A0F172A),
              blurRadius: 16,
              spreadRadius: -2,
              offset: Offset(0, 4),
            ),
          ];

  TextStyle text(
    double size,
    FontWeight weight,
    Color color, {
    double? letterSpacing,
    double? height,
  }) {
    return GoogleFonts.plusJakartaSans(
      fontSize: size,
      fontWeight: weight,
      color: color,
      letterSpacing: letterSpacing,
      height: height,
    );
  }

  BoxDecoration cardBox({Color? fill, double radius = 24}) {
    return BoxDecoration(
      color: fill ?? card,
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: border),
      boxShadow: shadow,
    );
  }
}

class _ShareCircleButton extends StatelessWidget {
  const _ShareCircleButton({
    required this.icon,
    required this.onPressed,
    this.tooltip,
    this.iconSize = 18,
  });

  final IconData icon;
  final VoidCallback onPressed;
  final String? tooltip;
  final double iconSize;

  @override
  Widget build(BuildContext context) {
    final tone = PurposeShareTone(context);
    final btn = Material(
      color: tone.card,
      elevation: 0,
      shape: CircleBorder(side: BorderSide(color: tone.border)),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onPressed,
        child: SizedBox(
          width: 40,
          height: 40,
          child: Icon(icon, size: iconSize, color: tone.ink),
        ),
      ),
    );
    if (tooltip == null) return btn;
    return Tooltip(message: tooltip!, child: btn);
  }
}

class _MintIcon extends StatelessWidget {
  const _MintIcon({required this.icon, required this.color});

  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final tone = PurposeShareTone(context);
    return Container(
      width: 40,
      height: 40,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: tone.mint,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Icon(icon, size: 18, color: color),
    );
  }
}

class _ShareChoicePill extends StatelessWidget {
  const _ShareChoicePill({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final tone = PurposeShareTone(context);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? tone.emerald : tone.card,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: selected ? tone.emerald : tone.border),
        ),
        child: Text(
          label,
          style: tone.text(
            13,
            FontWeight.w700,
            selected ? Colors.white : tone.slate,
          ),
        ),
      ),
    );
  }
}

class _ShareTextPill extends StatelessWidget {
  const _ShareTextPill({
    required this.label,
    required this.onTap,
    this.rose = false,
  });

  final String label;
  final VoidCallback onTap;
  final bool rose;

  @override
  Widget build(BuildContext context) {
    final tone = PurposeShareTone(context);
    final fill = rose ? tone.roseSoft : tone.mint;
    final ink = rose ? tone.rose : tone.emerald;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: fill,
          borderRadius: BorderRadius.circular(999),
        ),
        child: Text(label, style: tone.text(12, FontWeight.w700, ink)),
      ),
    );
  }
}
