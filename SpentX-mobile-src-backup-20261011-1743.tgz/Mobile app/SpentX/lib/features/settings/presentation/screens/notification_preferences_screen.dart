import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../../../core/theme/soft_palette.dart';
import '../../../../core/widgets/soft_page_kit.dart';

class NotificationPreferencesScreen extends ConsumerStatefulWidget {
  const NotificationPreferencesScreen({super.key});

  @override
  ConsumerState<NotificationPreferencesScreen> createState() =>
      _NotificationPreferencesScreenState();
}

class _NotificationPreferencesScreenState
    extends ConsumerState<NotificationPreferencesScreen> {
  late final Box _settingsBox;

  final List<String> _allKeys = [
    'daily_summary_enabled',
    'weekly_summary_enabled',
    'monthly_summary_enabled',
    'salary_alerts_enabled',
    'budget_alerts_enabled',
    'daily_limit_alerts_enabled',
    'burn_rate_alerts_enabled',
    'settlement_reminders_enabled',
    'snapshot_reminders_enabled',
  ];

  @override
  void initState() {
    super.initState();
    _settingsBox = Hive.box('settings');
  }

  bool _getPref(String key) {
    return _settingsBox.get(key, defaultValue: true) == true;
  }

  Future<void> _setPref(String key, bool value) async {
    await _settingsBox.put(key, value);
    setState(() {});
  }

  Future<void> _setAllPrefs(bool value) async {
    for (final key in _allKeys) {
      await _settingsBox.put(key, value);
    }
    setState(() {});
  }

  Widget _buildCategoryHeader({
    required IconData icon,
    required String title,
    required Color color,
  }) {
    return SoftKitSectionLabel(title);
  }

  Widget _buildToggleTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required String prefKey,
    required Color iconColor,
    required bool isLast,
  }) {
    final isDark = SoftKit.dark(context);
    final value = _getPref(prefKey);

    return InkWell(
      onTap: () => _setPref(prefKey, !value),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 10, 12),
        child: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: iconColor.withValues(alpha: isDark ? 0.18 : 0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: iconColor, size: 18),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: SoftKit.text(
                      context,
                      14,
                      FontWeight.w700,
                      SoftKit.ink(context),
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: SoftKit.text(
                      context,
                      12,
                      FontWeight.w500,
                      SoftKit.slate(context),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            SoftKitSwitch(value: value, onChanged: (v) => _setPref(prefKey, v)),
          ],
        ),
      ),
    );
  }

  Widget _buildGroupCard(List<Widget> children, bool isDark) {
    return SoftKitCard(
      padding: EdgeInsets.zero,
      child: Column(children: children),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = SoftKit.dark(context);
    final enabledCount = _allKeys.where((k) => _getPref(k)).length;
    final allEnabled = enabledCount == _allKeys.length;
    const divider = SoftKitInsetDivider(indent: 68, endIndent: 16);

    return Scaffold(
      backgroundColor: SoftKit.canvas(context),
      body: SafeArea(
        bottom: false,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(0, 0, 0, 32),
          children: [
            SoftKitHeader(
              title: 'Notifications',
              subtitle: '$enabledCount of ${_allKeys.length} alerts on',
              onBack: () => Navigator.maybePop(context),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const SizedBox(height: 4),
                  SoftKitCard(
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Notification Rules',
                                style: SoftKit.text(
                                  context,
                                  15,
                                  FontWeight.w700,
                                  SoftKit.ink(context),
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                '$enabledCount of ${_allKeys.length} rules active',
                                style: SoftKit.text(
                                  context,
                                  12,
                                  FontWeight.w500,
                                  SoftKit.slate(context),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SoftKitButton.secondary(
                          label: allEnabled ? 'Disable all' : 'Enable all',
                          icon:
                              allEnabled
                                  ? LucideIcons.bellOff
                                  : LucideIcons.bellPlus,
                          height: 38,
                          expand: false,
                          onPressed: () => _setAllPrefs(!allEnabled),
                        ),
                      ],
                    ),
                  ),

                  // ── Group 1: Periodic Summaries ──
                  _buildCategoryHeader(
                    icon: LucideIcons.barChart2,
                    title: 'PERIODIC SUMMARIES',
                    color: context.softEmerald,
                  ),
                  _buildGroupCard([
                    _buildToggleTile(
                      icon: LucideIcons.sparkles,
                      title: 'Daily Spending Summary',
                      subtitle:
                          'Daily overview of expenses & top spending category',
                      prefKey: 'daily_summary_enabled',
                      iconColor: context.softEmerald,
                      isLast: false,
                    ),
                    divider,
                    _buildToggleTile(
                      icon: LucideIcons.calendar,
                      title: 'Weekly Spending Summary',
                      subtitle: 'Sunday evening summary of income & expenses',
                      prefKey: 'weekly_summary_enabled',
                      iconColor: context.softEmerald,
                      isLast: false,
                    ),
                    divider,
                    _buildToggleTile(
                      icon: LucideIcons.barChart2,
                      title: 'Monthly Spending Summary',
                      subtitle: 'End-of-month financial & savings overview',
                      prefKey: 'monthly_summary_enabled',
                      iconColor: context.softEmerald,
                      isLast: true,
                    ),
                  ], isDark),

                  // ── Group 2: Smart Budget & Expense Alerts ──
                  _buildCategoryHeader(
                    icon: LucideIcons.alertTriangle,
                    title: 'SMART BUDGET & EXPENSE ALERTS',
                    color: const Color(0xFFF59E0B),
                  ),
                  _buildGroupCard([
                    _buildToggleTile(
                      icon: LucideIcons.piggyBank,
                      title: 'Salary & Income Credited',
                      subtitle:
                          'Notify when salary or major income is received',
                      prefKey: 'salary_alerts_enabled',
                      iconColor:
                          isDark
                              ? SoftPalette.darkEmerald
                              : SoftPalette.positive,
                      isLast: false,
                    ),
                    divider,
                    _buildToggleTile(
                      icon: LucideIcons.alertTriangle,
                      title: 'Budget Limit Thresholds (80% / 100%)',
                      subtitle:
                          'Alert when category budget reaches 80% or 100%',
                      prefKey: 'budget_alerts_enabled',
                      iconColor: const Color(0xFFF59E0B),
                      isLast: false,
                    ),
                    divider,
                    _buildToggleTile(
                      icon: LucideIcons.shieldAlert,
                      title: 'Daily Safe Limit Exceeded',
                      subtitle:
                          "Alert when today's safe spending limit is breached",
                      prefKey: 'daily_limit_alerts_enabled',
                      iconColor: SoftPalette.negative,
                      isLast: false,
                    ),
                    divider,
                    _buildToggleTile(
                      icon: LucideIcons.flame,
                      title: 'High Burn Rate Warning',
                      subtitle:
                          'Warn when spending velocity projects overspend',
                      prefKey: 'burn_rate_alerts_enabled',
                      iconColor: SoftPalette.negative,
                      isLast: true,
                    ),
                  ], isDark),

                  // ── Group 3: Activity Reminders ──
                  _buildCategoryHeader(
                    icon: LucideIcons.bell,
                    title: 'ACTIVITY REMINDERS',
                    color:
                        (isDark ? SoftPalette.darkEmerald : SoftPalette.mint),
                  ),
                  _buildGroupCard([
                    _buildToggleTile(
                      icon: LucideIcons.users,
                      title: 'Friend Settlement Reminders',
                      subtitle: 'Remind when friend splits remain unsettled',
                      prefKey: 'settlement_reminders_enabled',
                      iconColor:
                          (isDark ? SoftPalette.darkEmerald : SoftPalette.mint),
                      isLast: false,
                    ),
                    divider,
                    _buildToggleTile(
                      icon: LucideIcons.wallet,
                      title: 'Daily Snapshot Reminders',
                      subtitle: 'Remind to log daily account balance in Wealth',
                      prefKey: 'snapshot_reminders_enabled',
                      iconColor:
                          (isDark ? SoftPalette.darkEmerald : SoftPalette.mint),
                      isLast: true,
                    ),
                  ], isDark),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
