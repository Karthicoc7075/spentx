import 'package:flutter/material.dart';
import '../../../../core/theme/soft_palette.dart';
import '../../../../core/theme/spentx_tokens.dart';
import '../../../../core/design/sx_primitives.dart';
import 'package:flutter/services.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/debug/master_debug_log.dart';
import '../../../../core/debug/master_debug_module.dart';
import '../../../../core/theme/app_colors.dart';

class MasterDebugLogScreen extends StatefulWidget {
  const MasterDebugLogScreen({super.key});

  @override
  State<MasterDebugLogScreen> createState() => _MasterDebugLogScreenState();
}

class _MasterDebugLogScreenState extends State<MasterDebugLogScreen> {
  List<MasterDebugLogEntry> _logs = [];
  String _search = '';
  MasterDebugLevel? _levelFilter;
  final Set<MasterDebugModule> _moduleFilters = {};
  bool _autoRefresh = true;
  bool _paused = false;
  MasterDebugLogEntry? _selected;
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _reload();
    _startAutoRefresh();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _startAutoRefresh() {
    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 2));
      if (!mounted) return false;
      if (_autoRefresh && !_paused && MasterDebugLog.isEnabled) {
        _reload(silent: true);
      }
      return mounted;
    });
  }

  Future<void> _reload({bool silent = false}) async {
    if (!MasterDebugLog.isEnabled) {
      if (!silent && mounted) setState(() => _logs = []);
      return;
    }
    await MasterDebugLog.ensureOpen();
    final all = MasterDebugLog.readAll();
    if (!silent && mounted) {
      setState(() => _logs = all);
    } else if (silent && mounted && all.length != _logs.length) {
      setState(() => _logs = all);
    } else if (silent && mounted) {
      // Update if newest id changed
      if (all.isNotEmpty && (_logs.isEmpty || all.first.id != _logs.first.id)) {
        setState(() => _logs = all);
      }
    }
  }

  List<MasterDebugLogEntry> get _filtered {
    return _logs.where((e) {
      if (_levelFilter != null && e.level != _levelFilter) {
        return false;
      }
      if (_moduleFilters.isNotEmpty && !_moduleFilters.contains(e.module)) {
        return false;
      }
      if (_search.isNotEmpty) {
        final q = _search.toLowerCase();
        final hay =
            '${e.title} ${e.message} ${e.module.label} ${e.dataJson ?? ''}'
                .toLowerCase();
        if (!hay.contains(q)) {
          return false;
        }
      }
      return true;
    }).toList();
  }

  Color _levelColor(MasterDebugLevel level) {
    switch (level) {
      case MasterDebugLevel.success:
        return AppColors.income;
      case MasterDebugLevel.warning:
        return AppColors.warning;
      case MasterDebugLevel.error:
        return AppColors.expense;
      case MasterDebugLevel.debug:
        return AppColors.darkTextSecondary;
      case MasterDebugLevel.info:
        return AppColors.info;
    }
  }

  Future<void> _export() async {
    final json = await MasterDebugLog.exportAsJson();
    final count = _logs.length;
    await Clipboard.setData(ClipboardData(text: json));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Exported $count logs to clipboard'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Future<void> _clear() async {
    final t = context.tokens;
    final confirm = await showDialog<bool>(
      context: context,
      builder:
          (ctx) => AlertDialog(
            backgroundColor: t.card,
            surfaceTintColor: Colors.transparent,
            shape: RoundedRectangleBorder(
              borderRadius: AppRadius.cardR,
              side: BorderSide(color: t.border),
            ),
            title: Text(
              'Clear all logs?',
              style: AppType.section(t.textPrimary),
            ),
            content: Text(
              'This permanently removes all master debug log entries.',
              style: AppType.body(t.textSecondary),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                style: TextButton.styleFrom(foregroundColor: t.textSecondary),
                child: const Text('Cancel'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                style: FilledButton.styleFrom(
                  backgroundBuilder: SoftColors.plainBackground,
                  backgroundColor: t.negative,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: AppRadius.buttonR,
                  ),
                ),
                child: const Text('Clear'),
              ),
            ],
          ),
    );
    if (confirm != true) return;
    await MasterDebugLog.clear();
    await _reload();
  }

  void _copySelected() {
    final e = _selected;
    if (e == null) return;
    Clipboard.setData(ClipboardData(text: e.copyText));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Log copied'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _filtered;
    final enabled = MasterDebugLog.isEnabled;

    final t = context.tokens;
    return Scaffold(
      backgroundColor: t.background,
      appBar: AppBar(
        backgroundColor: t.background,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        leadingWidth: 56,
        leading: Padding(
          padding: const EdgeInsets.only(left: 8),
          child: Center(
            child: SxIconButton(
              icon: Icons.arrow_back_ios_new_rounded,
              tooltip: 'Back',
              onPressed: () => Navigator.maybePop(context),
            ),
          ),
        ),
        title: Text('Master Debug Log', style: AppType.section(t.textPrimary)),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 2),
            child: SxIconButton(
              tooltip: 'Copy selected',
              icon: LucideIcons.copy,
              onPressed: _selected != null ? _copySelected : null,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 2),
            child: SxIconButton(
              tooltip: 'Export',
              icon: LucideIcons.download,
              onPressed: enabled ? _export : null,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: SxIconButton(
              tooltip: 'Clear',
              icon: LucideIcons.trash2,
              onPressed: enabled ? _clear : null,
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          if (!enabled)
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 4),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 14,
                ),
                decoration: BoxDecoration(
                  color: t.warningSoft,
                  borderRadius: AppRadius.tileR,
                  border: Border.all(color: t.warning.withValues(alpha: 0.22)),
                ),
                child: Row(
                  children: [
                    Icon(LucideIcons.info, size: 18, color: t.warning),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'Master Debug Logging is OFF. Enable it in Developer Options to record logs.',
                        style: AppType.caption(
                          t.warning,
                        ).copyWith(fontWeight: FontWeight.w600),
                      ),
                    ),
                  ],
                ),
              ),
            ),

          // Toolbar
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 6),
            child: Row(
              children: [
                _SoftToggleChip(
                  label: _paused ? 'Paused' : 'Live',
                  icon: _paused ? LucideIcons.pause : LucideIcons.radio,
                  selected: !_paused,
                  enabled: enabled,
                  onSelected: () => setState(() => _paused = !_paused),
                ),
                const SizedBox(width: 8),
                _SoftToggleChip(
                  label: 'Auto Refresh',
                  selected: _autoRefresh,
                  enabled: enabled,
                  onSelected:
                      () => setState(() => _autoRefresh = !_autoRefresh),
                ),
                const Spacer(),
                Text(
                  '${filtered.length} / ${_logs.length}',
                  style: AppType.caption(
                    t.textSecondary,
                  ).copyWith(fontWeight: FontWeight.w600),
                ),
                const SizedBox(width: 4),
                SxIconButton(
                  icon: LucideIcons.refreshCw,
                  tooltip: 'Refresh logs',
                  onPressed: _reload,
                ),
              ],
            ),
          ),

          // Search
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Container(
              height: 52,
              decoration: BoxDecoration(
                color: t.card,
                borderRadius: AppRadius.cardR,
                border: Border.all(color: t.border),
                boxShadow: context.isDarkMode ? null : AppShadows.subtle,
              ),
              child: TextField(
                controller: _searchController,
                style: AppType.body(t.textPrimary),
                decoration: InputDecoration(
                  hintText: 'Search logs…',
                  hintStyle: AppType.body(t.textDisabled),
                  prefixIcon: Icon(
                    LucideIcons.search,
                    size: 18,
                    color: t.textSecondary,
                  ),
                  isDense: true,
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 14,
                  ),
                ),
                onChanged: (v) => setState(() => _search = v.trim()),
              ),
            ),
          ),

          const SizedBox(height: 12),

          // Level filters
          SizedBox(
            height: 38,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 20),
              children: [
                _LevelChip(
                  label: 'All',
                  color: t.primary,
                  selected: _levelFilter == null,
                  onTap: () => setState(() => _levelFilter = null),
                ),
                ...MasterDebugLevel.values.map(
                  (l) => _LevelChip(
                    label: l.label,
                    color: _levelColor(l),
                    selected: _levelFilter == l,
                    onTap:
                        () => setState(
                          () => _levelFilter = _levelFilter == l ? null : l,
                        ),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 8),

          // Module filters
          SizedBox(
            height: 38,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 20),
              children:
                  MasterDebugModule.values.map((m) {
                    final selected = _moduleFilters.contains(m);
                    return Padding(
                      padding: const EdgeInsets.only(right: 6),
                      child: _SoftModuleChip(
                        label: m.label,
                        selected: selected,
                        onSelected: (v) {
                          setState(() {
                            if (v) {
                              _moduleFilters.add(m);
                            } else {
                              _moduleFilters.remove(m);
                            }
                          });
                        },
                      ),
                    );
                  }).toList(),
            ),
          ),

          const SizedBox(height: 10),

          // Log list
          Expanded(
            child:
                filtered.isEmpty
                    ? Center(
                      child: Text(
                        enabled
                            ? 'No logs match filters yet.'
                            : 'Enable Master Debug Logging to start recording.',
                        style: TextStyle(color: context.tokens.textSecondary),
                      ),
                    )
                    : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
                      itemCount: filtered.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 6),
                      itemBuilder: (context, i) {
                        final e = filtered[i];
                        final selected = _selected?.id == e.id;
                        final time =
                            '${e.timestamp.hour.toString().padLeft(2, '0')}:${e.timestamp.minute.toString().padLeft(2, '0')}:${e.timestamp.second.toString().padLeft(2, '0')}';

                        return Material(
                          color: Colors.transparent,
                          borderRadius: AppRadius.cardR,
                          child: InkWell(
                            borderRadius: AppRadius.cardR,
                            splashColor: t.pressed,
                            highlightColor: t.pressed,
                            onTap: () => setState(() => _selected = e),
                            onLongPress: () {
                              Clipboard.setData(
                                ClipboardData(text: e.copyText),
                              );
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('Copied'),
                                  behavior: SnackBarBehavior.floating,
                                ),
                              );
                            },
                            child: Container(
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                color: selected ? t.primarySoft : t.card,
                                borderRadius: AppRadius.cardR,
                                border: Border.all(
                                  color:
                                      selected
                                          ? t.primary.withValues(alpha: 0.48)
                                          : t.border,
                                ),
                                boxShadow:
                                    context.isDarkMode
                                        ? null
                                        : AppShadows.subtle,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 6,
                                          vertical: 2,
                                        ),
                                        decoration: BoxDecoration(
                                          color: _levelColor(
                                            e.level,
                                          ).withValues(alpha: 0.2),
                                          borderRadius: BorderRadius.circular(
                                            4,
                                          ),
                                        ),
                                        child: Text(
                                          e.level.label,
                                          style: TextStyle(
                                            fontSize: 11,
                                            fontWeight: FontWeight.w500,
                                            color: _levelColor(e.level),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(width: 6),
                                      Text(
                                        e.module.label,
                                        style: TextStyle(
                                          fontSize: 11,
                                          color: t.textSecondary,
                                        ),
                                      ),
                                      const Spacer(),
                                      Text(
                                        time,
                                        style: TextStyle(
                                          fontSize: 11,
                                          color: t.textSecondary,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    e.title,
                                    style: const TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  if (e.message.isNotEmpty) ...[
                                    const SizedBox(height: 2),
                                    Text(
                                      e.message,
                                      style: TextStyle(
                                        fontSize: 11,
                                        color: t.textSecondary,
                                      ),
                                      maxLines: 3,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ],
                                  if (e.dataJson != null &&
                                      e.dataJson!.isNotEmpty) ...[
                                    const SizedBox(height: 4),
                                    Text(
                                      e.dataJson!,
                                      style: AppType.caption(
                                        t.textDisabled,
                                      ).copyWith(fontFamily: 'monospace'),
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ],
                                  if (e.errorMessage != null) ...[
                                    const SizedBox(height: 4),
                                    Text(
                                      e.errorMessage!,
                                      style: AppType.caption(
                                        t.negative,
                                      ).copyWith(fontWeight: FontWeight.w600),
                                      maxLines: 2,
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
          ),
        ],
      ),
    );
  }
}

class _SoftToggleChip extends StatelessWidget {
  final String label;
  final IconData? icon;
  final bool selected;
  final bool enabled;
  final VoidCallback onSelected;

  const _SoftToggleChip({
    required this.label,
    this.icon,
    required this.selected,
    required this.enabled,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    return Material(
      color: selected ? t.primarySoft : t.card,
      borderRadius: AppRadius.pillR,
      child: InkWell(
        onTap: enabled ? onSelected : null,
        borderRadius: AppRadius.pillR,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            borderRadius: AppRadius.pillR,
            border: Border.all(
              color: selected ? t.primary.withValues(alpha: 0.35) : t.border,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (icon != null) ...[
                Icon(
                  icon,
                  size: 14,
                  color: selected ? t.primary : t.textSecondary,
                ),
                const SizedBox(width: 6),
              ],
              Text(
                label,
                style: AppType.caption(
                  selected ? t.primary : t.textSecondary,
                ).copyWith(fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SoftModuleChip extends StatelessWidget {
  final String label;
  final bool selected;
  final ValueChanged<bool> onSelected;

  const _SoftModuleChip({
    required this.label,
    required this.selected,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    return Material(
      color: selected ? t.primarySoft : t.card,
      borderRadius: AppRadius.pillR,
      child: InkWell(
        onTap: () => onSelected(!selected),
        borderRadius: AppRadius.pillR,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            borderRadius: AppRadius.pillR,
            border: Border.all(
              color: selected ? t.primary.withValues(alpha: 0.35) : t.border,
            ),
          ),
          child: Text(
            label,
            style: AppType.caption(
              selected ? t.primary : t.textSecondary,
            ).copyWith(fontWeight: FontWeight.w600),
          ),
        ),
      ),
    );
  }
}

class _LevelChip extends StatelessWidget {
  final String label;
  final Color color;
  final bool selected;
  final VoidCallback onTap;

  const _LevelChip({
    required this.label,
    required this.color,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: Material(
        color: selected ? color.withValues(alpha: 0.12) : t.card,
        borderRadius: AppRadius.pillR,
        child: InkWell(
          onTap: onTap,
          borderRadius: AppRadius.pillR,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 8),
            decoration: BoxDecoration(
              borderRadius: AppRadius.pillR,
              border: Border.all(
                color: selected ? color.withValues(alpha: 0.42) : t.border,
              ),
            ),
            child: Text(
              label,
              style: AppType.caption(
                selected ? color : t.textSecondary,
              ).copyWith(fontWeight: FontWeight.w600),
            ),
          ),
        ),
      ),
    );
  }
}
