import 'package:flutter/material.dart';
import '../../../../core/theme/spentx_tokens.dart';
import '../../../../core/design/sx_primitives.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/sync/sms_rules_refresh_service.dart';
import '../../../../core/sync/sync_service.dart';
import '../../../sms/detected/sms_pipeline_test_runner.dart';

class DeveloperOptionsScreen extends StatefulWidget {
  const DeveloperOptionsScreen({super.key});

  @override
  State<DeveloperOptionsScreen> createState() => _DeveloperOptionsScreenState();
}

class _DeveloperOptionsScreenState extends State<DeveloperOptionsScreen> {
  final _smsController = TextEditingController();
  SmsPipelineTestResult? _result;
  bool _testing = false;
  bool _refreshingRules = false;

  @override
  void dispose() {
    _smsController.dispose();
    super.dispose();
  }

  Future<void> _parseSms() async {
    final sms = _smsController.text.trim();
    if (sms.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Paste a real bank SMS first.'),
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    setState(() => _testing = true);
    final result = SmsPipelineTestRunner.run(sms);
    if (!mounted) return;
    setState(() {
      _result = result;
      _testing = false;
    });
  }

  Future<void> _refreshRules() async {
    setState(() => _refreshingRules = true);
    final counts = await SmsRulesRefreshService.refreshNow();
    if (!mounted) return;
    setState(() => _refreshingRules = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          counts == null
              ? 'Could not refresh rules. Check sign-in and internet.'
              : 'Rules refreshed: ${counts['templates']} templates.',
        ),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final cardColor = t.card;
    final borderColor = t.border;
    final muted = t.textSecondary;

    return Scaffold(
      backgroundColor: context.tokens.background,
      appBar: AppBar(
        backgroundColor: context.tokens.background,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        toolbarHeight: 72,
        leadingWidth: 56,
        leading: Padding(
          padding: const EdgeInsets.only(left: 8),
          child: Center(
            child: SxIconButton(
              icon: Icons.arrow_back_ios_new_rounded,
              tooltip: 'Back',
              onPressed: () => Navigator.maybePop(context),
            ),
          ),
        ),
        title: Text(
          'SMS Developer Tools',
          style: AppType.section(context.tokens.textPrimary),
        ),
      ),
      body: ListView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
        children: [
          _ToolCard(
            color: cardColor,
            borderColor: borderColor,
            icon: LucideIcons.messageSquare,
            title: 'Real SMS Parser',
            subtitle: 'Paste one real bank SMS and see what SpentX detects.',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextField(
                  controller: _smsController,
                  minLines: 4,
                  maxLines: 7,
                  textInputAction: TextInputAction.newline,
                  decoration: InputDecoration(
                    hintText:
                        'Example: Rs.250 debited from HDFC XX1234 at SWIGGY...',
                    hintStyle: AppType.body(t.textDisabled),
                    alignLabelWithHint: true,
                    filled: true,
                    fillColor: t.surfaceVariant,
                    contentPadding: const EdgeInsets.all(16),
                    border: OutlineInputBorder(
                      borderRadius: AppRadius.inputR,
                      borderSide: BorderSide(color: t.border),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: AppRadius.inputR,
                      borderSide: BorderSide(color: t.border),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: AppRadius.inputR,
                      borderSide: BorderSide(color: t.primary, width: 1.5),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: SxPrimaryButton(
                        onPressed: _testing ? null : _parseSms,
                        icon: LucideIcons.play,
                        label: _testing ? 'Parsing...' : 'Parse SMS',
                      ),
                    ),
                    const SizedBox(width: 10),
                    SxIconButton(
                      tooltip: 'Clear',
                      onPressed: () {
                        _smsController.clear();
                        setState(() => _result = null);
                      },
                      icon: LucideIcons.x,
                    ),
                  ],
                ),
                if (_result != null) ...[
                  const SizedBox(height: 14),
                  _ParseResultCard(result: _result!, muted: muted),
                ],
              ],
            ),
          ),
          const SizedBox(height: 16),
          _ToolCard(
            color: cardColor,
            borderColor: borderColor,
            icon: LucideIcons.radio,
            title: 'Real-Time SMS Test',
            subtitle:
                'Open SMS from this device, select one, and run the test pipeline. Test-only; nothing is imported automatically.',
            child: SizedBox(
              width: double.infinity,
              child: SxPrimaryButton(
                onPressed: () => context.push('/real-sms-test'),
                icon: LucideIcons.arrowRight,
                label: 'Open Real-Time Test',
              ),
            ),
          ),
          const SizedBox(height: 16),
          _ToolCard(
            color: cardColor,
            borderColor: borderColor,
            icon: LucideIcons.sliders,
            title: 'SMS Detect Rules & Templates',
            subtitle:
                'Manage custom detection rules, parser templates, and bank matching keywords.',
            child: SizedBox(
              width: double.infinity,
              child: SxPrimaryButton(
                onPressed: () => context.push('/sms-rules'),
                icon: LucideIcons.arrowRight,
                label: 'Manage Detect Rules',
              ),
            ),
          ),
          const SizedBox(height: 16),
          _ToolCard(
            color: cardColor,
            borderColor: borderColor,
            icon: LucideIcons.shieldAlert,
            title: 'SMS Block List & Spam Filter',
            subtitle:
                'Block promotional SMS, OTPs, or specific senders from auto-detection.',
            child: SizedBox(
              width: double.infinity,
              child: _SoftOutlineButton(
                onPressed: () => context.push('/block-sms'),
                icon: LucideIcons.shieldOff,
                label: 'Manage Blocked Senders & Rules',
              ),
            ),
          ),
          const SizedBox(height: 16),
          _ToolCard(
            color: cardColor,
            borderColor: borderColor,
            icon: LucideIcons.zap,
            title: 'Real-Time Sync & Power Optimizer',
            subtitle:
                'Event-driven instant background sync on Mobile Data / Wi-Fi. Minimal CPU, RAM & zero battery drain.',
            child: SizedBox(
              width: double.infinity,
              child: _SoftOutlineButton(
                onPressed: () async {
                  final messenger = ScaffoldMessenger.of(context);
                  await SyncService.fullSync(force: true);
                  if (!mounted) return;
                  messenger.showSnackBar(
                    const SnackBar(
                      content: Text(
                        'Sync completed. Power & memory optimized.',
                      ),
                      behavior: SnackBarBehavior.floating,
                    ),
                  );
                },
                icon: LucideIcons.refreshCw,
                label: 'Force Sync & Optimize',
              ),
            ),
          ),
          const SizedBox(height: 16),
          _ToolCard(
            color: cardColor,
            borderColor: borderColor,
            icon: LucideIcons.refreshCw,
            title: 'Refresh Remote Parser Templates',
            subtitle:
                'Pull latest parser templates before testing a new bank SMS.',
            child: SizedBox(
              width: double.infinity,
              child: _SoftOutlineButton(
                onPressed: _refreshingRules ? null : _refreshRules,
                icon: LucideIcons.refreshCw,
                label: _refreshingRules ? 'Refreshing...' : 'Refresh Rules',
                busy: _refreshingRules,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ToolCard extends StatelessWidget {
  final Color color;
  final Color borderColor;
  final IconData icon;
  final String title;
  final String subtitle;
  final Widget child;

  const _ToolCard({
    required this.color,
    required this.borderColor,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: color,
        borderRadius: AppRadius.cardR,
        border: Border.all(color: borderColor),
        boxShadow: context.isDarkMode ? null : AppShadows.bento,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: t.primarySoft,
                  borderRadius: AppRadius.tileR,
                ),
                child: Icon(icon, color: t.primary, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: AppType.section(t.textPrimary)),
                    const SizedBox(height: 2),
                    Text(subtitle, style: AppType.caption(t.textSecondary)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }
}

class _SoftOutlineButton extends StatelessWidget {
  final VoidCallback? onPressed;
  final IconData icon;
  final String label;
  final bool busy;

  const _SoftOutlineButton({
    required this.onPressed,
    required this.icon,
    required this.label,
    this.busy = false,
  });

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final enabled = onPressed != null;
    return SizedBox(
      height: 54,
      width: double.infinity,
      child: OutlinedButton.icon(
        onPressed: onPressed,
        icon:
            busy
                ? SizedBox(
                  width: 17,
                  height: 17,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: enabled ? t.primary : t.textDisabled,
                  ),
                )
                : Icon(icon, size: 18),
        label: Text(label),
        style: OutlinedButton.styleFrom(
          foregroundColor: enabled ? t.primary : t.textDisabled,
          backgroundColor: t.surface,
          side: BorderSide(color: enabled ? t.border : t.disabled),
          shape: const RoundedRectangleBorder(borderRadius: AppRadius.tileR),
          textStyle: AppType.body(
            enabled ? t.primary : t.textDisabled,
          ).copyWith(fontWeight: FontWeight.w600),
        ),
      ),
    );
  }
}

class _ParseResultCard extends StatelessWidget {
  final SmsPipelineTestResult result;
  final Color muted;

  const _ParseResultCard({required this.result, required this.muted});

  @override
  Widget build(BuildContext context) {
    final ok = result.detectionSuccess;
    final t = context.tokens;
    final accent = ok ? t.positive : t.negative;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: accent.withValues(alpha: 0.1),
        borderRadius: AppRadius.tileR,
        border: Border.all(color: accent.withValues(alpha: 0.25)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                ok ? LucideIcons.checkCircle2 : LucideIcons.alertTriangle,
                color: accent,
                size: 18,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  ok
                      ? 'Parsed successfully'
                      : (result.errors.isNotEmpty
                          ? result.errors.first
                          : 'Could not parse this SMS'),
                  style: AppType.label(
                    accent,
                  ).copyWith(fontWeight: FontWeight.w700),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          _ResultRow(label: 'Parser', value: result.parserUsed, muted: muted),
          _ResultRow(
            label: 'Type',
            value: result.parsedDirection?.toUpperCase() ?? '-',
            muted: muted,
          ),
          _ResultRow(
            label: 'Amount',
            value:
                result.parsedAmount == null
                    ? '-'
                    : '₹${result.parsedAmount!.toStringAsFixed(0)}',
            muted: muted,
          ),
          _ResultRow(
            label: 'Merchant',
            value: result.parsedMerchant ?? '-',
            muted: muted,
          ),
          _ResultRow(
            label: 'Bank',
            value: result.parsedBank ?? '-',
            muted: muted,
          ),
          _ResultRow(
            label: 'Reference',
            value: result.parsedReferenceId ?? '-',
            muted: muted,
          ),
          if (result.debugLogs.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text(
              result.debugLogs.take(3).join(' • '),
              style: AppType.caption(muted),
            ),
          ],
        ],
      ),
    );
  }
}

class _ResultRow extends StatelessWidget {
  final String label;
  final String value;
  final Color muted;

  const _ResultRow({
    required this.label,
    required this.value,
    required this.muted,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        children: [
          SizedBox(
            width: 86,
            child: Text(label, style: AppType.caption(muted)),
          ),
          Expanded(
            child: Text(
              value,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: AppType.label(
                context.tokens.textPrimary,
              ).copyWith(fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }
}
