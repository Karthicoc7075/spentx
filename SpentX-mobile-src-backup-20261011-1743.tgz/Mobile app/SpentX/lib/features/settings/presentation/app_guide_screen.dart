import 'package:flutter/material.dart';
import '../../../core/theme/spentx_tokens.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../core/widgets/reference_ui.dart';
import 'package:lucide_icons/lucide_icons.dart';

/// In-app guide: how SpentX works, tips & tricks.
class AppGuideScreen extends StatelessWidget {
  const AppGuideScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = isDark ? SoftPalette.darkBg : SoftPalette.bg;
    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: Column(
          children: [
            SoftPageHeader(title: 'App guide'),
            Expanded(
              child: ListView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
                children: const [
                  _IntroCard(),
                  SizedBox(height: 24),
                  _GuideSection(
                    title: 'Getting started',
                    icon: LucideIcons.rocket,
                    bullets: [
                      'Set your name on Settings — tap your profile card at the top.',
                      'Add bank & cash accounts under Account Configuration.',
                      'Turn on notification access when prompted so SpentX can read bank alerts (no SMS permission needed for that path).',
                      'SMS detection starts automatically after permission is granted; known alerts are added and uncertain ones go to SMS Review.',
                    ],
                  ),
                  _GuideSection(
                    title: 'Bottom navigation',
                    icon: LucideIcons.layoutGrid,
                    bullets: [
                      'Home — net worth, purpose spend, accounts, recent activity, trip banner.',
                      'Activity — full transaction list with purpose & category filters.',
                      'Center + button — quick add expense or income.',
                      'Analytics — savings, cash flow, categories, top spending.',
                      'Settings — appearance, notifications, trips, friends, SMS review, privacy & security.',
                    ],
                  ),
                  _GuideSection(
                    title: 'Track spending automatically',
                    icon: LucideIcons.zap,
                    bullets: [
                      'Bank/UPI notifications are parsed into pending items — tap the banner on Home to verify.',
                      'Confirm adds the transaction; Ignore skips it (stored under Detected SMS).',
                      'Manage Merchants maps payee names to categories & accounts.',
                      'SMS Detection Rules let you train custom parsers for your bank’s SMS format.',
                      'Developer Options — paste sample SMS and test parsers in real-time.',
                    ],
                  ),
                  _GuideSection(
                    title: 'Notifications & smart alerts',
                    icon: LucideIcons.bell,
                    bullets: [
                      'Notification Preferences — customize 3 categories under Settings → Notification Preferences:',
                      'Periodic Summaries (Daily spending summary & ₹0 no-spend milestone, Sunday weekly summary, Monthly summary).',
                      'Smart Alerts (Salary credited, 80%/100% budget threshold warnings, Daily safe limit exceeded, High burn rate).',
                      'Activity Reminders (Friend settlement reminders, Daily account balance snapshot reminders).',
                      'No-Spam Rate Limiting — non-SMS alerts are capped at max 8/day so you are never spammed. Bank SMS detection notifications are always uncapped.',
                      'Auto-Mark Read — opening Notification History or the top bar bell automatically marks unread notifications read.',
                    ],
                  ),
                  _GuideSection(
                    title: 'Trips & outings',
                    icon: LucideIcons.map,
                    bullets: [
                      'Manage Outing → Start Trip: set dates, friends, and auto-add mode.',
                      'While a trip is active, new expenses can attach to the trip automatically.',
                      'Add trip expenses from the trip banner or trip detail — split equally or solo.',
                      'Mark who paid and record friend repayments (cash/UPI, partial OK).',
                      'Trip statement shows your share, pending return, and settled amounts.',
                      'End the trip when done — auto-add stops and totals stay in history.',
                    ],
                  ),
                  _GuideSection(
                    title: 'Friends & splits',
                    icon: LucideIcons.users,
                    bullets: [
                      'Manage Friends — add people you split with often.',
                      'Friend UPI IDs help match repayment SMS to the right person.',
                      'WHO PAID on an expense drives who owes whom — fix it if you paid for the group.',
                      'Pending return only counts money friends still owe you when you paid.',
                      'Settlement Reminders notify you when net friend balances remain pending.',
                    ],
                  ),
                  _GuideSection(
                    title: 'Privacy modes',
                    icon: LucideIcons.eyeOff,
                    bullets: [
                      'Outing Privacy — only available during an active trip. Hides net worth & non-trip activity; home shows trip spend only. Turning it off needs PIN or your profile name.',
                      'Private Mode — masks amounts with ***** on Home & Accounts. Disabled automatically while outing privacy is on.',
                    ],
                  ),
                  _GuideSection(
                    title: 'Security & PIN',
                    icon: LucideIcons.shieldCheck,
                    bullets: [
                      'Set a 4-digit PIN under Settings → Set PIN.',
                      'Lock Screen — require PIN when opening the app.',
                      'Fingerprint Unlock — use biometrics for quick & secure unlock.',
                      'Reset App Data — wipes local data; requires explicit confirmation.',
                    ],
                  ),
                  _GuideSection(
                    title: 'Plan & investments',
                    icon: LucideIcons.pieChart,
                    bullets: [
                      'Monthly Plan (same as web Plan) — set expected income and category limits; track spend vs plan.',
                      'Investments tab — add holdings, track buy/sell flows, and monitor portfolio growth.',
                    ],
                  ),
                  _TipsSection(),
                  SizedBox(height: 8),
                  _FutureSection(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _IntroCard extends StatelessWidget {
  const _IntroCard();

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: isDark ? SoftPalette.darkCard : SoftPalette.card,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color:
              isDark
                  ? SoftPalette.darkBorder.withValues(alpha: 0.55)
                  : SoftPalette.border.withValues(alpha: 0.55),
        ),
        boxShadow: isDark ? null : AppShadows.subtle,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Welcome to SpentX',
            style: TextStyle(
              color: isDark ? SoftPalette.darkInk : SoftPalette.ink,
              fontSize: 20,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'SpentX tracks money from bank alerts & SMS, organizes by account and purpose, and splits trip costs with friends. Use this guide anytime from Settings.',
            style: TextStyle(
              color: isDark ? SoftPalette.darkMuted : SoftPalette.muted,
              fontSize: 14,
              height: 1.45,
            ),
          ),
        ],
      ),
    );
  }
}

class _GuideSection extends StatelessWidget {
  final String title;
  final IconData icon;
  final List<String> bullets;

  const _GuideSection({
    required this.title,
    required this.icon,
    required this.bullets,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: SoftPalette.emerald, size: 20),
              const SizedBox(width: 10),
              Text(
                title.toUpperCase(),
                style: TextStyle(
                  color:
                      isDark
                          ? Colors.white.withValues(alpha: 0.5)
                          : isDark
                          ? SoftPalette.darkFaint
                          : SoftPalette.faint,
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                  letterSpacing: 1.2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: isDark ? SoftPalette.darkCard : SoftPalette.card,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(
                color:
                    isDark
                        ? SoftPalette.darkBorder.withValues(alpha: 0.55)
                        : SoftPalette.border.withValues(alpha: 0.55),
              ),
              boxShadow: isDark ? null : AppShadows.subtle,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (var i = 0; i < bullets.length; i++) ...[
                  if (i > 0) const SizedBox(height: 10),
                  _Bullet(text: bullets[i]),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Bullet extends StatelessWidget {
  final String text;

  const _Bullet({required this.text});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(top: 6),
          child: Icon(LucideIcons.circle, size: 6, color: SoftPalette.emerald),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            text,
            style: TextStyle(
              color: context.tokens.textPrimary,
              fontSize: 14,
              height: 1.4,
            ),
          ),
        ),
      ],
    );
  }
}

class _TipsSection extends StatelessWidget {
  const _TipsSection();

  static const _tips = [
    _Tip(
      title: 'Verify SMS quickly',
      body:
          'When the orange banner appears on Home, tap it — batch-verify several detections in one flow.',
    ),
    _Tip(
      title: 'Purpose filters',
      body:
          'On Activity & Analytics, filter by Personal, Family, or your custom purposes to see where money goes.',
    ),
    _Tip(
      title: 'Unlink a wrong trip',
      body:
          'Open a transaction → change outing link — confirm unlink so totals stay correct.',
    ),
    _Tip(
      title: 'Merchant aliases',
      body:
          'If Swiggy shows as “SWIGGY*FOOD”, add a merchant rule once — future SMS maps automatically.',
    ),
    _Tip(
      title: 'Trip privacy in public',
      body:
          'On a group trip, turn on Outing Privacy so friends only see trip spend on your phone, not full net worth.',
    ),
    _Tip(
      title: 'Notification preferences',
      body:
          'Customize daily/weekly summaries, budget warnings, and friend settlement alerts under Settings → Notification Preferences.',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Icon(
              LucideIcons.lightbulb,
              color: SoftPalette.emerald,
              size: 20,
            ),
            const SizedBox(width: 10),
            Text(
              'TIPS & TRICKS',
              style: TextStyle(
                color: isDark ? SoftPalette.darkFaint : SoftPalette.faint,
                fontSize: 11,
                fontWeight: FontWeight.w500,
                letterSpacing: 1.2,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        for (final tip in _tips) ...[
          _TipCard(tip: tip),
          const SizedBox(height: 10),
        ],
      ],
    );
  }
}

class _Tip {
  final String title;
  final String body;

  const _Tip({required this.title, required this.body});
}

class _TipCard extends StatelessWidget {
  final _Tip tip;

  const _TipCard({required this.tip});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: isDark ? SoftPalette.darkCard : SoftPalette.card,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color:
              isDark
                  ? SoftPalette.darkBorder.withValues(alpha: 0.55)
                  : SoftPalette.border.withValues(alpha: 0.55),
        ),
        boxShadow: isDark ? null : AppShadows.subtle,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            tip.title,
            style: const TextStyle(
              color: SoftPalette.emerald,
              fontSize: 14,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            tip.body,
            style: TextStyle(
              color: isDark ? SoftPalette.darkMuted : SoftPalette.muted,
              fontSize: 13,
              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }
}

/// Planned & recommended features for future SpentX updates.
class _FutureSection extends StatelessWidget {
  const _FutureSection();

  static const _mustHave = [
    'Cloud sync across multiple devices — real-time web & mobile synchronization.',
    'Home screen widget — quick account balance view & one-tap expense logger.',
    'Multi-currency & forex card tracking for international travel.',
  ];

  static const _goodToHave = [
    'Shared read-only trip links — friends view trip balances without installing.',
    'Smart AI receipt scanning — attach photo receipt to transactions.',
    'Credit card billing cycle — due date & minimum payment alerts.',
  ];

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Icon(
              LucideIcons.sparkles,
              color: SoftPalette.emerald,
              size: 20,
            ),
            const SizedBox(width: 10),
            Text(
              'FUTURE ROADMAP',
              style: TextStyle(
                color: isDark ? SoftPalette.darkFaint : SoftPalette.faint,
                fontSize: 11,
                fontWeight: FontWeight.w500,
                letterSpacing: 1.2,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          'Planned additions for future SpentX updates:',
          style: TextStyle(
            color: isDark ? SoftPalette.darkMuted : SoftPalette.muted,
            fontSize: 12,
          ),
        ),
        const SizedBox(height: 12),
        _FutureList(
          label: 'Must have',
          color: SoftPalette.emerald,
          items: _mustHave,
        ),
        const SizedBox(height: 14),
        _FutureList(
          label: 'Good to have',
          color: SoftPalette.mintDark,
          items: _goodToHave,
        ),
        const SizedBox(height: 12),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: SoftPalette.emerald.withValues(alpha: 0.08),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(
              color: SoftPalette.emerald.withValues(alpha: 0.2),
            ),
          ),
          child: Text(
            'SpentX is built to grow with real daily use. Have an idea? Note it down!',
            style: TextStyle(
              color: isDark ? SoftPalette.darkMuted : SoftPalette.muted,
              fontSize: 12,
              height: 1.45,
              fontStyle: FontStyle.italic,
            ),
          ),
        ),
      ],
    );
  }
}

class _FutureList extends StatelessWidget {
  final String label;
  final Color color;
  final List<String> items;

  const _FutureList({
    required this.label,
    required this.color,
    required this.items,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: context.tokens.card,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: isDark ? SoftPalette.darkBorder : SoftPalette.border,
          width: 0.8,
        ),
        boxShadow: isDark ? null : AppShadows.subtle,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(999),
            ),
            child: Text(
              label.toUpperCase(),
              style: TextStyle(
                color: color,
                fontSize: 11,
                fontWeight: FontWeight.w500,
                letterSpacing: 1,
              ),
            ),
          ),
          const SizedBox(height: 12),
          for (var i = 0; i < items.length; i++) ...[
            if (i > 0) const SizedBox(height: 10),
            _Bullet(text: items[i]),
          ],
        ],
      ),
    );
  }
}
