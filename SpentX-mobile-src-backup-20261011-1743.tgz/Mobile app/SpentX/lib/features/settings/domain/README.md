# settings domain — preferences entities
