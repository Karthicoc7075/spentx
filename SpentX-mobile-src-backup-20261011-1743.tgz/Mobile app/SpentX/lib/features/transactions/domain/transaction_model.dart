import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';

part 'transaction_model.g.dart';

@HiveType(typeId: 1)
class Transaction extends HiveObject {
  @HiveField(0)
  final String id;

  @HiveField(1)
  double amount;

  @HiveField(2)
  String type; // 'income', 'expense', 'transfer'

  @HiveField(3)
  String accountId;

  @HiveField(4)
  String paymentMode; // 'cash', 'bank', 'upi', 'card'

  @HiveField(5)
  String category;

  @HiveField(6)
  String note;

  @HiveField(7)
  String merchant;

  @HiveField(8)
  bool isAutoDetected;

  @HiveField(9)
  DateTime date;

  @HiveField(10)
  DateTime createdAt;

  @HiveField(11)
  String? linkedTransactionId; // For transfers

  @HiveField(12)
  String? outingId;

  @HiveField(13)
  bool isAutoLinked;

  Transaction({
    String? id,
    required this.amount,
    required this.type,
    required this.accountId,
    required this.paymentMode,
    required this.category,
    this.note = '',
    this.merchant = '',
    this.isAutoDetected = false,
    required this.date,
    DateTime? createdAt,
    this.linkedTransactionId,
    this.outingId,
    this.isAutoLinked = false,
  })  : id = id ?? const Uuid().v4(),
        createdAt = createdAt ?? DateTime.now();

  Transaction copyWith({
    double? amount,
    String? type,
    String? accountId,
    String? paymentMode,
    String? category,
    String? note,
    String? merchant,
    bool? isAutoDetected,
    DateTime? date,
    DateTime? createdAt,
    String? linkedTransactionId,
    String? outingId,
    bool? isAutoLinked,
    bool clearOutingId = false,
  }) {
    final tx = Transaction(
      id: id,
      amount: amount ?? this.amount,
      type: type ?? this.type,
      accountId: accountId ?? this.accountId,
      paymentMode: paymentMode ?? this.paymentMode,
      category: category ?? this.category,
      note: note ?? this.note,
      merchant: merchant ?? this.merchant,
      isAutoDetected: isAutoDetected ?? this.isAutoDetected,
      date: date ?? this.date,
      createdAt: createdAt ?? this.createdAt,
      linkedTransactionId: linkedTransactionId ?? this.linkedTransactionId,
      outingId: clearOutingId ? null : (outingId ?? this.outingId),
      isAutoLinked: clearOutingId ? false : (isAutoLinked ?? this.isAutoLinked),
    );
    return tx;
  }
}
