// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'transaction_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class TransactionAdapter extends TypeAdapter<Transaction> {
  @override
  final int typeId = 1;

  @override
  Transaction read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return Transaction(
      id: fields[0] as String?,
      amount: fields[1] as double,
      type: fields[2] as String,
      accountId: fields[3] as String,
      paymentMode: fields[4] as String,
      category: fields[5] as String,
      note: fields[6] as String,
      merchant: fields[7] as String,
      isAutoDetected: fields[8] as bool,
      date: fields[9] as DateTime,
      createdAt: fields[10] as DateTime?,
      linkedTransactionId: fields[11] as String?,
      outingId: fields[12] as String?,
      isAutoLinked: fields[13] as bool,
    );
  }

  @override
  void write(BinaryWriter writer, Transaction obj) {
    writer
      ..writeByte(14)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.amount)
      ..writeByte(2)
      ..write(obj.type)
      ..writeByte(3)
      ..write(obj.accountId)
      ..writeByte(4)
      ..write(obj.paymentMode)
      ..writeByte(5)
      ..write(obj.category)
      ..writeByte(6)
      ..write(obj.note)
      ..writeByte(7)
      ..write(obj.merchant)
      ..writeByte(8)
      ..write(obj.isAutoDetected)
      ..writeByte(9)
      ..write(obj.date)
      ..writeByte(10)
      ..write(obj.createdAt)
      ..writeByte(11)
      ..write(obj.linkedTransactionId)
      ..writeByte(12)
      ..write(obj.outingId)
      ..writeByte(13)
      ..write(obj.isAutoLinked);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is TransactionAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
