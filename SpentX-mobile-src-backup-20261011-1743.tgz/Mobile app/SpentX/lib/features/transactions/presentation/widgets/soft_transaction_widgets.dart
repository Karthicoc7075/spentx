import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../core/theme/soft_palette.dart';
import '../../../../core/theme/spentx_tokens.dart';
import '../../../../core/widgets/reference_ui.dart';
import '../../../../core/widgets/soft_buttons.dart';

/// Soft filter chip for Activity ranges / purposes.
class SoftActivityChip extends StatelessWidget {
  const SoftActivityChip({
    super.key,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final selectedBg = isDark ? SoftPalette.darkEmerald : SoftPalette.ink;
    final selectedFg = isDark ? SoftPalette.darkOnEmerald : SoftPalette.card;
    return Padding(
      padding: const EdgeInsets.only(right: 7),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 8),
          decoration: BoxDecoration(
            color: selected ? selectedBg : t.card,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: selected ? selectedBg : t.border),
          ),
          child: Text(
            label,
            style: TextStyle(
              color: selected ? selectedFg : t.textSecondary,
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ),
    );
  }
}

/// Soft metric tile for cashflow summary strip.
class SoftCashflowMetric extends StatelessWidget {
  const SoftCashflowMetric({
    super.key,
    required this.label,
    required this.value,
    required this.color,
  });

  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: t.surfaceVariant,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              color: t.textSecondary,
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              color: color,
              fontSize: 15,
              fontWeight: FontWeight.w800,
              letterSpacing: -0.3,
            ),
          ),
        ],
      ),
    );
  }
}

/// Soft card wrapper for transaction list chrome.
class SoftTxCard extends StatelessWidget {
  const SoftTxCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.onTap,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final card = SxSoftCard(padding: padding, child: child);
    if (onTap == null) return card;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: const BorderRadius.all(Radius.circular(24)),
        child: card,
      ),
    );
  }
}

/// Soft sheet header chrome for Add Transaction.
class SoftSheetHeader extends StatelessWidget {
  const SoftSheetHeader({
    super.key,
    required this.title,
    this.subtitle,
    this.onClose,
  });

  final String title;
  final String? subtitle;
  final VoidCallback? onClose;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 12, 8),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.3,
                    color: t.textPrimary,
                  ),
                ),
                if (subtitle != null) ...[
                  const SizedBox(height: 2),
                  Text(
                    subtitle!,
                    style: TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w500,
                      color: t.textSecondary,
                    ),
                  ),
                ],
              ],
            ),
          ),
          if (onClose != null)
            SoftCircleIconButton(
              icon: Icons.close_rounded,
              tooltip: 'Close',
              onPressed: onClose!,
            ),
        ],
      ),
    );
  }
}

/// Soft Soft pale icon well (rounded square).
class SoftIconWell extends StatelessWidget {
  const SoftIconWell({
    super.key,
    required this.icon,
    this.size = 40,
    this.iconSize = 18,
    this.background,
    this.iconColor,
  });

  final IconData icon;
  final double size;
  final double iconSize;
  final Color? background;
  final Color? iconColor;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color:
            background ??
            (isDark ? SoftPalette.darkEmeraldSoft : SoftPalette.emeraldSoft),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Icon(
        icon,
        size: iconSize,
        color:
            iconColor ??
            (isDark ? SoftPalette.darkEmerald : SoftPalette.emerald),
      ),
    );
  }
}

/// Soft Soft tappable row: icon well + title/subtitle + chevron.
class SoftNavRow extends StatelessWidget {
  const SoftNavRow({
    super.key,
    required this.title,
    required this.subtitle,
    required this.icon,
    this.onTap,
    this.iconBackground,
    this.iconColor,
    this.showDivider = false,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback? onTap;
  final Color? iconBackground;
  final Color? iconColor;
  final bool showDivider;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final ink = isDark ? SoftPalette.darkInk : SoftPalette.ink;
    final muted = isDark ? SoftPalette.darkMuted : SoftPalette.muted;
    return Column(
      children: [
        Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(16),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              child: Row(
                children: [
                  SoftIconWell(
                    icon: icon,
                    background: iconBackground,
                    iconColor: iconColor,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            letterSpacing: -0.2,
                            color: ink,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          subtitle,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w500,
                            color: muted,
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (onTap != null)
                    Icon(Icons.chevron_right_rounded, size: 20, color: muted),
                ],
              ),
            ),
          ),
        ),
        if (showDivider)
          Divider(
            height: 1,
            thickness: 1,
            indent: 66,
            endIndent: 14,
            color: isDark ? SoftPalette.darkDivider : SoftPalette.divider,
          ),
      ],
    );
  }
}

/// Primary stadium button — shared green gradient (SoftColors).
class SoftPrimaryButton extends StatelessWidget {
  const SoftPrimaryButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.height = 54,
  });

  final String label;
  final VoidCallback? onPressed;
  final double height;

  @override
  Widget build(BuildContext context) {
    return SoftGradientButton(
      onPressed: onPressed,
      height: height,
      child: Text(
        label,
        style: const TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w800,
          letterSpacing: -0.2,
          color: Colors.white,
        ),
      ),
    );
  }
}

/// Secondary stadium button — white / #18181B with ink text + light outline.
class SoftSecondaryButton extends StatelessWidget {
  const SoftSecondaryButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.height = 54,
  });

  final String label;
  final VoidCallback? onPressed;
  final double height;

  @override
  Widget build(BuildContext context) {
    return SoftOutlineButton(
      onPressed: onPressed,
      height: height,
      child: Text(
        label,
        style: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w800,
          letterSpacing: -0.2,
          color: SoftColors.secondaryFg(context),
        ),
      ),
    );
  }
}

/// Add Transaction Soft Soft tokens from the form spec.
/// Light values match the mock. Dark mode keeps the same shapes.
abstract final class SoftAddTone {
  static bool _dark(BuildContext context) =>
      Theme.of(context).brightness == Brightness.dark;

  static Color canvas(BuildContext context) =>
      _dark(context) ? SoftPalette.darkBg : const Color(0xFFF4F7F6);

  static Color surfaceMint(BuildContext context) =>
      _dark(context) ? SoftPalette.darkSurface : const Color(0xFFF3F7F5);

  static Color card(BuildContext context) =>
      _dark(context) ? SoftPalette.darkCard : const Color(0xFFFFFFFF);

  /// White-card stroke. Field borders stay on [border].
  static Color cardBorder(BuildContext context) =>
      _dark(context) ? SoftPalette.darkBorder : const Color(0xFFF1F5F9);

  static Color border(BuildContext context) =>
      _dark(context) ? SoftPalette.darkBorder : const Color(0xFFE4EBE7);

  static Color ink(BuildContext context) =>
      _dark(context) ? SoftPalette.darkInk : SoftColors.ink;

  static Color secondary(BuildContext context) =>
      _dark(context) ? SoftPalette.darkMuted : const Color(0xFF5A6860);

  static Color variant(BuildContext context) =>
      _dark(context) ? SoftPalette.darkMuted : const Color(0xFF415147);

  static Color primary(BuildContext context) =>
      _dark(context) ? SoftPalette.darkEmerald : const Color(0xFF006C49);

  static Color emerald(BuildContext context) =>
      _dark(context) ? SoftPalette.darkEmerald : const Color(0xFF10B981);

  static Color brand(BuildContext context) =>
      _dark(context) ? SoftPalette.darkEmerald : const Color(0xFF059669);

  static Color primaryDark(BuildContext context) =>
      _dark(context) ? const Color(0xFF064E3B) : const Color(0xFF005236);

  static Color mintSubtle(BuildContext context) =>
      _dark(context) ? SoftPalette.darkEmeraldSoft : const Color(0xFFE8F5EE);

  static Color error(BuildContext context) =>
      _dark(context) ? const Color(0xFFF87171) : const Color(0xFFD92D20);

  static const onPrimary = Color(0xFFFFFFFF);

  /// `0 4px 16px -2px rgba(15,23,42,0.04)` — the only card shadow.
  static const cardShadow = [
    BoxShadow(
      color: Color.fromRGBO(15, 23, 42, 0.04),
      offset: Offset(0, 4),
      blurRadius: 16,
      spreadRadius: -2,
    ),
  ];

  static const elevatedShadow = cardShadow;

  static const actionShadow = cardShadow;

  static List<BoxShadow>? cardShadowOf(BuildContext context) =>
      _dark(context) ? null : cardShadow;

  static List<BoxShadow>? elevatedShadowOf(BuildContext context) =>
      _dark(context) ? null : elevatedShadow;

  static TextStyle text(
    BuildContext context, {
    required double fontSize,
    FontWeight fontWeight = FontWeight.w600,
    Color? color,
    double? letterSpacing,
    double? height,
  }) {
    return GoogleFonts.plusJakartaSans(
      fontSize: fontSize,
      fontWeight: fontWeight,
      color: color ?? ink(context),
      letterSpacing: letterSpacing,
      height: height,
    );
  }

  static BoxDecoration cardBox(BuildContext context, {double radius = 24}) {
    return BoxDecoration(
      color: card(context),
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: cardBorder(context)),
      boxShadow: cardShadowOf(context),
    );
  }

  static InputDecoration input(
    BuildContext context,
    String hint, {
    Widget? prefixIcon,
    TextStyle? errorStyle,
  }) {
    final radius = BorderRadius.circular(12);
    final side = BorderSide(color: border(context));
    return InputDecoration(
      hintText: hint,
      filled: true,
      fillColor: canvas(context),
      prefixIcon: prefixIcon,
      hintStyle: text(
        context,
        fontSize: 13,
        fontWeight: FontWeight.w500,
        color: secondary(context),
      ),
      border: OutlineInputBorder(borderRadius: radius, borderSide: side),
      enabledBorder: OutlineInputBorder(borderRadius: radius, borderSide: side),
      focusedBorder: OutlineInputBorder(
        borderRadius: radius,
        borderSide: BorderSide(color: primary(context), width: 1.4),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: radius,
        borderSide: BorderSide(color: error(context)),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: radius,
        borderSide: BorderSide(color: error(context), width: 1.4),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      errorStyle: errorStyle,
    );
  }
}

class SoftAddHeader extends StatelessWidget {
  const SoftAddHeader({super.key, required this.title, required this.onClose});

  final String title;
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 44,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: Material(
              color: SoftAddTone.card(context),
              borderRadius: BorderRadius.circular(12),
              child: InkWell(
                onTap: onClose,
                borderRadius: BorderRadius.circular(12),
                child: Ink(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: SoftAddTone.card(context),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: SoftAddTone.border(context)),
                    boxShadow: SoftAddTone.cardShadowOf(context),
                  ),
                  child: Icon(
                    Icons.close_rounded,
                    size: 22,
                    color: SoftAddTone.ink(context),
                  ),
                ),
              ),
            ),
          ),
          Text(
            title,
            style: SoftAddTone.text(
              context,
              fontSize: 16,
              fontWeight: FontWeight.w800,
              letterSpacing: -0.3,
            ),
          ),
        ],
      ),
    );
  }
}

class SoftAddTypeBar extends StatelessWidget {
  const SoftAddTypeBar({
    super.key,
    required this.index,
    required this.onChanged,
  });

  final int index;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    const labels = ['Expense', 'Income', 'Transfer'];
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(4),
      decoration: SoftAddTone.cardBox(context, radius: 12),
      child: Row(
        children: List.generate(labels.length, (i) {
          final selected = index == i;
          return Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 2),
              child: Material(
                color: Colors.transparent,
                borderRadius: BorderRadius.circular(8),
                child: InkWell(
                  onTap: () => onChanged(i),
                  borderRadius: BorderRadius.circular(8),
                  child: Ink(
                    height: 36,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: selected ? SoftColors.control : null,
                    ),
                    child: Center(
                      child: Text(
                        labels[i].toUpperCase(),
                        style: SoftAddTone.text(
                          context,
                          fontSize: 12,
                          fontWeight:
                              selected ? FontWeight.w800 : FontWeight.w600,
                          letterSpacing: 0.6,
                          color:
                              selected
                                  ? SoftAddTone.onPrimary
                                  : SoftAddTone.secondary(context),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}

class SoftAddSwitch extends StatelessWidget {
  const SoftAddSwitch({
    super.key,
    required this.value,
    required this.onChanged,
  });

  final bool value;
  final ValueChanged<bool>? onChanged;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      toggled: value,
      child: GestureDetector(
        onTap: onChanged == null ? null : () => onChanged!(!value),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          width: 48,
          height: 24,
          padding: const EdgeInsets.all(2),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(999),
            // Small control: solid green on, grey off (no gradient).
            color: value ? SoftColors.control : SoftColors.trackOff(context),
          ),
          child: AnimatedAlign(
            duration: const Duration(milliseconds: 180),
            alignment: value ? Alignment.centerRight : Alignment.centerLeft,
            child: Container(
              width: 20,
              height: 20,
              decoration: const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Color(0x33000000),
                    blurRadius: 4,
                    offset: Offset(0, 1),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class SoftAddPickerRow extends StatelessWidget {
  const SoftAddPickerRow({
    super.key,
    required this.title,
    required this.value,
    required this.icon,
    this.onTap,
    this.highlighted = false,
    this.labelTrailing,
  });

  final String title;
  final String value;
  final IconData icon;
  final VoidCallback? onTap;
  final bool highlighted;
  final Widget? labelTrailing;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                title,
                style: SoftAddTone.text(
                  context,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: SoftAddTone.secondary(context),
                ),
              ),
            ),
            if (labelTrailing != null) labelTrailing!,
          ],
        ),
        const SizedBox(height: 6),
        Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(12),
            child: Ink(
              decoration: BoxDecoration(
                color:
                    highlighted
                        ? SoftAddTone.mintSubtle(context).withValues(alpha: 0.7)
                        : SoftAddTone.canvas(context),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color:
                      highlighted
                          ? SoftAddTone.primary(context).withValues(alpha: 0.2)
                          : SoftAddTone.border(context),
                ),
              ),
              padding: const EdgeInsets.all(10),
              child: Row(
                children: [
                  Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: SoftAddTone.mintSubtle(context),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: SoftAddTone.border(context)),
                    ),
                    child: Icon(
                      icon,
                      size: 18,
                      color: SoftAddTone.primary(context),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      value,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: SoftAddTone.text(
                        context,
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  Icon(
                    Icons.unfold_more_rounded,
                    size: 18,
                    color: SoftAddTone.secondary(context),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class SoftAddSaveButton extends StatelessWidget {
  const SoftAddSaveButton({
    super.key,
    required this.label,
    required this.amount,
    required this.onPressed,
  });

  final String label;
  final String amount;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    final enabled = onPressed != null;
    return Opacity(
      opacity: enabled ? 1 : 0.45,
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          onTap: onPressed,
          borderRadius: BorderRadius.circular(18),
          child: Ink(
            height: 54,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              // Source of the app-wide primary gradient (SoftColors).
              gradient: SoftColors.primaryGradient,
              boxShadow:
                  enabled && !SoftAddTone._dark(context)
                      ? SoftAddTone.actionShadow
                      : null,
            ),
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                Icon(
                  Icons.lock_outline_rounded,
                  size: 18,
                  color: SoftAddTone.onPrimary,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    label,
                    style: SoftAddTone.text(
                      context,
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: SoftAddTone.onPrimary,
                    ),
                  ),
                ),
                Text(
                  amount,
                  style: SoftAddTone.text(
                    context,
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    color: SoftAddTone.onPrimary,
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  width: 24,
                  height: 24,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.2),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.check_rounded,
                    size: 16,
                    color: SoftAddTone.onPrimary,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Soft Soft green success pill (e.g. "Parsed successfully").
class SoftSuccessPill extends StatelessWidget {
  const SoftSuccessPill({super.key, required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: SoftPalette.emeraldSoft,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        label,
        style: const TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w700,
          color: SoftPalette.mintDark,
        ),
      ),
    );
  }
}
