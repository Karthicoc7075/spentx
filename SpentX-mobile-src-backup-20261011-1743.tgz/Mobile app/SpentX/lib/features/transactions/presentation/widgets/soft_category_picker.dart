import 'package:flutter/material.dart';

import '../../../../core/theme/soft_palette.dart';
import '../../../../core/widgets/category_icon.dart';
import '../../../../core/widgets/reference_ui.dart';
import 'soft_transaction_widgets.dart';

/// Soft Soft Categories picker used by the Add Transaction flow.
Future<String?> showSoftCategoryPicker({
  required BuildContext context,
  required List<String> categories,
  required String selected,
  required String entryTypeLabel,
  VoidCallback? onAdd,
}) {
  final isDark = Theme.of(context).brightness == Brightness.dark;
  return showModalBottomSheet<String>(
    context: context,
    isScrollControlled: true,
    backgroundColor: isDark ? SoftPalette.darkBg : SoftPalette.bg,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
    ),
    builder: (ctx) {
      return SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SoftPageHeader(
                title: 'Categories',
                onBack: () => Navigator.pop(ctx),
                trailing: onAdd == null
                    ? null
                    : SoftCircleIconButton(
                        icon: Icons.add_rounded,
                        tooltip: 'Add category',
                        onPressed: () {
                          Navigator.pop(ctx);
                          onAdd();
                        },
                      ),
              ),
              const SizedBox(height: 8),
              Flexible(
                child: SxSoftCard(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: ListView.separated(
                    shrinkWrap: true,
                    itemCount: categories.length,
                    separatorBuilder: (_, __) => Divider(
                      height: 1,
                      indent: 66,
                      endIndent: 14,
                      color: isDark
                          ? SoftPalette.darkDivider
                          : SoftPalette.divider,
                    ),
                    itemBuilder: (context, i) {
                      final cat = categories[i];
                      final data = CategoryIcon.resolve(cat);
                      return SoftNavRow(
                        title: cat,
                        subtitle: entryTypeLabel,
                        icon: data.icon,
                        iconBackground: SoftPalette.emeraldSoft,
                        iconColor: SoftPalette.emerald,
                        onTap: () => Navigator.pop(ctx, cat),
                        showDivider: false,
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
}

/// Soft Soft account picker (same chrome as Categories).
Future<String?> showSoftAccountPicker({
  required BuildContext context,
  required List<String> accounts,
  required String? selected,
  required IconData Function(String name) iconFor,
}) {
  final isDark = Theme.of(context).brightness == Brightness.dark;
  return showModalBottomSheet<String>(
    context: context,
    isScrollControlled: true,
    backgroundColor: isDark ? SoftPalette.darkBg : SoftPalette.bg,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
    ),
    builder: (ctx) {
      return SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SoftPageHeader(
                title: 'Accounts',
                onBack: () => Navigator.pop(ctx),
              ),
              const SizedBox(height: 8),
              Flexible(
                child: SxSoftCard(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: ListView.separated(
                    shrinkWrap: true,
                    itemCount: accounts.length,
                    separatorBuilder: (_, __) => Divider(
                      height: 1,
                      indent: 66,
                      endIndent: 14,
                      color: isDark
                          ? SoftPalette.darkDivider
                          : SoftPalette.divider,
                    ),
                    itemBuilder: (context, i) {
                      final name = accounts[i];
                      return SoftNavRow(
                        title: name,
                        subtitle: name == selected ? 'Selected' : 'Tap to select',
                        icon: iconFor(name),
                        onTap: () => Navigator.pop(ctx, name),
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
}
