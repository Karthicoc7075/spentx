import 'package:flutter/material.dart';
import '../../../core/theme/soft_palette.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:uuid/uuid.dart';
import '../../../core/utils/amount_input.dart';
import '../../../core/widgets/category_icon.dart';
import '../../../core/widgets/premium_bottom_sheet.dart';
import '../../../core/widgets/success_check_dialog.dart';
import '../../../core/widgets/animated_tap_card.dart';
import '../data/transaction_provider.dart' as model;
import '../../../core/providers/outing_provider.dart';
import '../../../core/providers/user_state_provider.dart';
import '../../../core/providers/merchant_provider.dart';
import '../../../core/providers/category_provider.dart';
import '../../../core/providers/contributor_provider.dart';
import '../../../core/providers/friends_provider.dart';
import '../../../core/providers/friend_split_provider.dart';
import '../../../core/services/merchant_identifier_resolver.dart';
import '../../../models/account_model.dart';
import '../../../models/transaction.dart'
    show Transaction, TransactionSplitRow, TransactionItemRow;
import '../../../models/friend_split.dart';
import '../../../core/widgets/terminal_wrapper.dart';
import 'widgets/soft_transaction_widgets.dart';
import 'widgets/soft_category_picker.dart';

/// Redesigned Add / Edit Expense & Income Sheet (Full parity with web AddTransactionSlideOver).
///
/// Fields:
/// 1. Title Header & Subtitle
/// 2. Expense / Income Segmented Toggle
/// 3. Amount Card (Sign + Currency symbol + Large Amount input + live subtitle)
/// 4. Merchant / Title
/// 5. Account Selector
/// 6. UPI / Identifier (optional)
/// 7. Outing Selection Card (when trip active or locked to outing)
/// 8. Split Expense Toggle (Switch: Purpose / Category / Purpose+Category Split rows with validation & duplicate keys guard)
/// 9. Split with Friends Toggle (Switch: Friend chips, Equal / Custom split share amounts & validation) - Mutually exclusive with Split Expense
/// 10. Category Selector (hidden when Category Split or Both Split is ON)
/// 11. Purpose Selector (hidden when Purpose Split or Both Split is ON, or in Trip mode)
/// 12. Contributor Selector (Income only, if >1 contributor)
/// 13. Past Transaction Switch (off = now; on = Date & Time pickers)
/// 14. Notes
/// 15. Action Footer: Save/Update button.

/// Bank/wallet/credit accounts before Cash — e.g. HDFC, Axis, Cash — same
/// order in the picker and for which account is picked by default. Stable
/// sort so accounts of the same type keep their existing relative order.
List<AccountModel> _accountsForPicker(List<AccountModel> accounts) {
  final sorted = [...accounts];
  sorted.sort((a, b) {
    final aCash = a.type.toLowerCase() == 'cash' ? 1 : 0;
    final bCash = b.type.toLowerCase() == 'cash' ? 1 : 0;
    return aCash - bCash;
  });
  return sorted;
}

List<String> _purposesForPicker(List<String> purposes) {
  final seen = <String>{};
  final ordered = <String>[];

  void addNamed(String target) {
    for (final purpose in purposes) {
      final normalized = purpose.trim().toLowerCase();
      if (normalized != target || seen.contains(normalized)) continue;
      seen.add(normalized);
      ordered.add(purpose);
      return;
    }
  }

  addNamed('personal');
  addNamed('family');

  for (final purpose in purposes) {
    final normalized = purpose.trim().toLowerCase();
    if (normalized.isEmpty || seen.contains(normalized)) continue;
    seen.add(normalized);
    ordered.add(purpose);
  }

  return ordered;
}

class AddTransactionSheet extends ConsumerStatefulWidget {
  /// When true starts on Expense; false starts on Income. User can still toggle.
  final bool initialIsExpense;

  /// Opens straight into Trip mode, locked to the currently open outing.
  final bool startInTripMode;

  /// Editing an existing transaction (pre-populates all fields & enables conversions).
  final Transaction? initialTransaction;

  /// Editing an existing trip expense.
  final OutingExpense? initialExpense;

  /// Initial Outing ID when editing a trip expense or passing a locked outing.
  final String? initialOutingId;

  /// Force split expense switch on.
  final bool forceSplitExpense;

  /// 0 = Expense, 1 = Income, 2 = Transfer. When set, overrides [initialIsExpense].
  final int? initialTypeIndex;

  const AddTransactionSheet({
    super.key,
    this.initialIsExpense = true,
    this.startInTripMode = false,
    this.initialTransaction,
    this.initialExpense,
    this.initialOutingId,
    this.forceSplitExpense = false,
    this.initialTypeIndex,
  });

  static bool _sheetOpen = false;

  /// Open the unified Add/Edit Expense sheet.
  static Future<void> show(
    BuildContext context, {
    bool initialIsExpense = true,
    bool startInTripMode = false,
    Transaction? initialTransaction,
    OutingExpense? initialExpense,
    String? initialOutingId,
    bool forceSplitExpense = false,
    int? initialTypeIndex,
  }) async {
    if (_sheetOpen) return;
    _sheetOpen = true;
    try {
      await PremiumBottomSheet.show(
        context: context,
        backgroundColor:
            Theme.of(context).brightness == Brightness.dark
                ? SoftPalette.darkBg
                : const Color(0xFFF8FAFC),
        child: AddTransactionSheet(
          initialIsExpense: initialIsExpense,
          startInTripMode: startInTripMode,
          initialTransaction: initialTransaction,
          initialExpense: initialExpense,
          initialOutingId: initialOutingId,
          forceSplitExpense: forceSplitExpense,
          initialTypeIndex: initialTypeIndex,
        ),
      );
    } finally {
      _sheetOpen = false;
    }
  }

  @override
  ConsumerState<AddTransactionSheet> createState() =>
      _AddTransactionSheetState();
}

class _AddTransactionSheetState extends ConsumerState<AddTransactionSheet> {
  final _formKey = GlobalKey<FormState>();
  bool _saving = false;

  late int _typeIndex; // 0 = Expense, 1 = Income, 2 = Transfer
  AccountModel? _selectedAccount;

  /// Transfer destination account — only used when [_typeIndex] == 2.
  AccountModel? _selectedToAccount;
  String _selectedCategory = 'Food & Dining';
  String? _selectedPurpose;
  String _paymentType = 'Online';
  DateTime _selectedDate = DateTime.now();
  TimeOfDay _selectedTime = TimeOfDay.now();
  bool _isPastTransaction = false;
  String _selectedContributor = ContributorNotifier.defaultMeName;

  final _amountController = TextEditingController();
  final _titleController = TextEditingController();
  final _upiController = TextEditingController();
  final _noteController = TextEditingController();
  final _descriptionController = TextEditingController();
  final List<TransactionItemRow> _itemRows = [];

  /// Optional custom display title — independent of [_titleController]
  /// (which is bound to Merchant, despite its name).
  final _customTitleController = TextEditingController();

  // ---- Outing / Trip Mode ----
  bool _isTripMode = false;
  String? _selectedOutingId;
  String? _paidByMemberId;
  SplitType _tripSplitType = SplitType.equally;
  final Map<String, TextEditingController> _customTripSplitControllers = {};

  // ---- Split Expense (Purpose / Category / Both Split) ----
  bool _splitExpenseEnabled = false;
  String _splitExpenseMode = 'purpose'; // 'purpose', 'category', 'both'
  final List<Map<String, dynamic>> _purposeSplitRows = [];
  final List<Map<String, dynamic>> _categorySplitRows = [];
  final List<Map<String, dynamic>> _bothSplitRows = [];

  // ---- Split with Friends ----
  bool _friendSplitEnabled = false;
  List<String> _selectedFriendNames = [];
  SplitType _friendSplitType = SplitType.equally;
  final Map<String, TextEditingController> _friendCustomSplitControllers = {};

  DateTime get _combinedDateTime {
    if (!_isPastTransaction) return DateTime.now();
    return DateTime(
      _selectedDate.year,
      _selectedDate.month,
      _selectedDate.day,
      _selectedTime.hour,
      _selectedTime.minute,
    );
  }

  double get _enteredAmount {
    return parsePositiveAmount(_amountController.text) ?? 0;
  }

  /// Indian-style comma grouping, rounded to whole rupees — matches
  /// `TransferBottomSheet._formatMoney` so both transfer surfaces agree.
  String _formatMoney(double value) {
    final rounded = value.round().toString();
    if (rounded.length <= 3) return rounded;
    final lastThree = rounded.substring(rounded.length - 3);
    final rest = rounded.substring(0, rounded.length - 3);
    final grouped = rest.replaceAllMapped(
      RegExp(r'\B(?=(\d{2})+(?!\d))'),
      (match) => ',',
    );
    return '$grouped,$lastThree';
  }

  @override
  void initState() {
    super.initState();
    final tx = widget.initialTransaction;
    final exp = widget.initialExpense;

    if (tx != null) {
      _typeIndex = tx.isTransfer ? 2 : (tx.isExpense ? 0 : 1);
      _amountController.text =
          tx.amount == tx.amount.truncateToDouble()
              ? tx.amount.toInt().toString()
              : tx.amount.toStringAsFixed(2);
      _titleController.text = tx.merchant;
      _customTitleController.text = tx.title ?? '';
      _upiController.text =
          tx.upiId.isNotEmpty
              ? tx.upiId
              : (tx.referenceId.isNotEmpty
                  ? tx.referenceId
                  : (tx.rawIdentifier ?? ''));
      _selectedCategory = tx.category;
      _selectedPurpose = tx.purpose;
      _selectedDate = tx.date;
      _selectedTime = TimeOfDay.fromDateTime(tx.date);
      _isPastTransaction = true;
      _noteController.text = tx.note;
      _descriptionController.text = tx.description;
      if (tx.items.isNotEmpty) {
        _itemRows.addAll(tx.items);
      }
      _selectedContributor =
          tx.contributorSource?.isNotEmpty == true
              ? tx.contributorSource!
              : ContributorNotifier.defaultMeName;
      _selectedOutingId = tx.outingId;

      if (tx.isSplitExpense) {
        _splitExpenseEnabled = true;
        _friendSplitEnabled = false;
        final distinctPurposes = tx.splits.map((s) => s.purposeId).toSet();
        final distinctCategories = tx.splits.map((s) => s.categoryId).toSet();

        if (distinctPurposes.length == 1 && distinctCategories.length > 1) {
          _splitExpenseMode = 'category';
          for (final s in tx.splits) {
            _categorySplitRows.add({
              'category': s.categoryId,
              'controller': TextEditingController(
                text:
                    s.amount == s.amount.truncateToDouble()
                        ? s.amount.toInt().toString()
                        : s.amount.toStringAsFixed(2),
              ),
            });
          }
        } else if (distinctPurposes.length > 1 &&
            distinctCategories.length > 1) {
          _splitExpenseMode = 'both';
          for (final s in tx.splits) {
            _bothSplitRows.add({
              'purpose': s.purposeId,
              'category': s.categoryId,
              'controller': TextEditingController(
                text:
                    s.amount == s.amount.truncateToDouble()
                        ? s.amount.toInt().toString()
                        : s.amount.toStringAsFixed(2),
              ),
            });
          }
        } else {
          _splitExpenseMode = 'purpose';
          for (final s in tx.splits) {
            _purposeSplitRows.add({
              'purpose': s.purposeId,
              'controller': TextEditingController(
                text:
                    s.amount == s.amount.truncateToDouble()
                        ? s.amount.toInt().toString()
                        : s.amount.toStringAsFixed(2),
              ),
            });
          }
        }
      }
    } else if (exp != null) {
      _typeIndex = 0;
      _isTripMode = true;
      _selectedOutingId = widget.initialOutingId;
      _amountController.text =
          exp.amount == exp.amount.truncateToDouble()
              ? exp.amount.toInt().toString()
              : exp.amount.toStringAsFixed(2);
      _titleController.text = exp.title;
      _selectedCategory = exp.category;
      _selectedDate = exp.date;
      _selectedTime = TimeOfDay.fromDateTime(exp.date);
      _isPastTransaction = true;
      _paidByMemberId = exp.paidByMemberId;
      _tripSplitType = exp.splitType;
      if (exp.customSplitAmounts != null) {
        for (final entry in exp.customSplitAmounts!.entries) {
          _customTripSplitControllers[entry.key] = TextEditingController(
            text:
                entry.value == entry.value.truncateToDouble()
                    ? entry.value.toInt().toString()
                    : entry.value.toStringAsFixed(2),
          );
        }
      }
    } else {
      _typeIndex = widget.initialTypeIndex ?? (widget.initialIsExpense ? 0 : 1);
      final now = DateTime.now();
      _selectedDate = DateTime(now.year, now.month, now.day);
      _selectedTime = TimeOfDay.fromDateTime(now);
      _isPastTransaction = false;

      if (widget.startInTripMode) {
        _isTripMode = true;
      }
      if (widget.forceSplitExpense) {
        _splitExpenseEnabled = true;
        _splitExpenseMode = 'purpose';
      }
    }

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadDefaultsAndLinkedRecords();
    });
  }

  void _loadDefaultsAndLinkedRecords() {
    if (!mounted) return;
    final accounts = _accountsForPicker(ref.read(userStateProvider).accounts);
    if (accounts.isNotEmpty && _selectedAccount == null) {
      final txAcc = widget.initialTransaction?.account;
      setState(() {
        _selectedAccount =
            accounts.where((a) => a.name == txAcc).firstOrNull ??
            accounts.where((a) => a.isDefault).firstOrNull ??
            accounts.first;
        _paymentType =
            _selectedAccount!.type.toLowerCase() == 'cash' ? 'Cash' : 'Online';
      });
    }
    if (accounts.isNotEmpty &&
        _selectedToAccount == null &&
        widget.initialTransaction?.isTransfer == true) {
      final toName = widget.initialTransaction!.transferTo;
      setState(() {
        _selectedToAccount =
            accounts.where((a) => a.name == toName).firstOrNull;
      });
    }

    final purposes = _purposesForPicker(
      ref.read(userStateProvider).purposeTypes,
    );
    if (purposes.isNotEmpty && _selectedPurpose == null) {
      // "Personal" by name, not by list position — matches web's
      // getDefaultPersonalPurpose so the default doesn't depend on
      // insertion order.
      setState(
        () =>
            _selectedPurpose = purposes.firstWhere(
              (p) => p.trim().toLowerCase() == 'personal',
              orElse: () => purposes.first,
            ),
      );
    }

    final cats = ref.read(categoryProvider);
    if (_typeIndex == 1) {
      if (cats.income.isNotEmpty &&
          widget.initialTransaction == null &&
          widget.initialExpense == null) {
        setState(() => _selectedCategory = cats.income.first);
      }
    } else {
      if (cats.expense.isNotEmpty &&
          widget.initialTransaction == null &&
          widget.initialExpense == null) {
        setState(() => _selectedCategory = cats.expense.first);
      }
    }

    // Editing an existing row: snap the restored values onto the real option
    // strings before they are compared.
    //
    // A synced transaction carries names resolved through RemoteIdCache, whose
    // reverse lookups (purposeName/contributorName/accountName) return the
    // map's *lowercased key* rather than the display name — so the row arrives
    // holding "personal" / "me" while the pickers list "Personal" / "Me". The
    // category chip compares case-insensitively and survives that, but the
    // purpose and contributor selectors compare with ==, so the form opened
    // with nothing selected and saving wrote the lowercased spelling back.
    if (widget.initialTransaction != null || widget.initialExpense != null) {
      String? snapToOption(String? value, Iterable<String> options) {
        final v = value?.trim() ?? '';
        if (v.isEmpty) return value;
        for (final option in options) {
          if (option.trim().toLowerCase() == v.toLowerCase()) return option;
        }
        return value;
      }

      final snappedCategory =
          snapToOption(
            _selectedCategory,
            _typeIndex == 1 ? cats.income : cats.expense,
          ) ??
          _selectedCategory;
      final snappedPurpose = snapToOption(_selectedPurpose, purposes);
      final snappedContributor =
          snapToOption(
            _selectedContributor,
            ref.read(contributorProvider).map((c) => c.name),
          ) ??
          _selectedContributor;

      if (snappedCategory != _selectedCategory ||
          snappedPurpose != _selectedPurpose ||
          snappedContributor != _selectedContributor) {
        setState(() {
          _selectedCategory = snappedCategory;
          _selectedPurpose = snappedPurpose;
          _selectedContributor = snappedContributor;
        });
      }
    }

    // Load linked FriendSplit when editing
    final tx = widget.initialTransaction;
    if (tx != null && !_splitExpenseEnabled) {
      final linkedSplit = ref
          .read(friendSplitProvider.notifier)
          .findForTransaction(tx.id);
      if (linkedSplit != null) {
        setState(() {
          _friendSplitEnabled = true;
          _splitExpenseEnabled = false;
          _selectedFriendNames =
              linkedSplit.members
                  .where(
                    (m) => !m.isCurrentUser && m.name.toLowerCase() != 'you',
                  )
                  .map((m) => m.name)
                  .toList();
          _friendSplitType = linkedSplit.splitType;
          for (final share in linkedSplit.splits) {
            final member =
                linkedSplit.members
                    .where((m) => m.id == share.memberId)
                    .firstOrNull;
            if (member != null) {
              final key = member.isCurrentUser ? 'You' : member.name;
              _friendCustomSplitControllers[key] = TextEditingController(
                text:
                    share.amount == share.amount.truncateToDouble()
                        ? share.amount.toInt().toString()
                        : share.amount.toStringAsFixed(2),
              );
            }
          }
        });
      }
    }

    if (_splitExpenseEnabled) {
      _seedSplitExpenseRows(_splitExpenseMode);
    }
  }

  @override
  void dispose() {
    _amountController.dispose();
    _titleController.dispose();
    _customTitleController.dispose();
    _upiController.dispose();
    _noteController.dispose();
    _descriptionController.dispose();
    for (final c in _customTripSplitControllers.values) {
      c.dispose();
    }
    for (final r in _purposeSplitRows) {
      (r['controller'] as TextEditingController).dispose();
    }
    for (final r in _categorySplitRows) {
      (r['controller'] as TextEditingController).dispose();
    }
    for (final r in _bothSplitRows) {
      (r['controller'] as TextEditingController).dispose();
    }
    for (final c in _friendCustomSplitControllers.values) {
      c.dispose();
    }
    super.dispose();
  }

  List<String> get _categoriesForType {
    final cats = ref.watch(categoryProvider);
    if (_typeIndex == 1) return cats.income;
    return cats.expense;
  }

  void _onTypeChanged(int i) {
    setState(() {
      _typeIndex = i;
      final cats = ref.read(categoryProvider);
      if (i == 2) {
        _selectedToAccount = null;
        _splitExpenseEnabled = false;
        _friendSplitEnabled = false;
      } else if (i == 1) {
        _selectedCategory =
            cats.income.isNotEmpty ? cats.income.first : 'Salary';
        _selectedContributor =
            ref.read(contributorProvider.notifier).defaultName;
        _splitExpenseEnabled = false;
        _friendSplitEnabled = false;
      } else {
        _selectedCategory =
            cats.expense.isNotEmpty ? cats.expense.first : 'Food & Dining';
      }
    });
  }

  void _handleToggleSplitExpense(bool val) {
    setState(() {
      _splitExpenseEnabled = val;
      if (val) {
        _friendSplitEnabled = false;
        _seedSplitExpenseRows(_splitExpenseMode);
      }
    });
  }

  void _handleToggleFriendSplit(bool val) {
    setState(() {
      _friendSplitEnabled = val;
      if (val) {
        _splitExpenseEnabled = false;
      }
    });
  }

  void _handleSetSplitExpenseMode(String mode) {
    setState(() {
      _splitExpenseMode = mode;
      _seedSplitExpenseRows(mode);
    });
  }

  void _seedSplitExpenseRows(String mode) {
    final purposes = _purposesForPicker(
      ref.read(userStateProvider).purposeTypes,
    );
    final cats = ref.read(categoryProvider).expense;
    final defaultP = purposes.isNotEmpty ? purposes.first : 'Personal';
    final defaultC = cats.isNotEmpty ? cats.first : 'Food & Dining';

    if (mode == 'purpose' && _purposeSplitRows.isEmpty) {
      _purposeSplitRows.addAll([
        {
          'purpose': _selectedPurpose ?? defaultP,
          'controller': TextEditingController(),
        },
        {'purpose': defaultP, 'controller': TextEditingController()},
      ]);
    } else if (mode == 'category' && _categorySplitRows.isEmpty) {
      _categorySplitRows.addAll([
        {'category': _selectedCategory, 'controller': TextEditingController()},
        {'category': defaultC, 'controller': TextEditingController()},
      ]);
    } else if (mode == 'both' && _bothSplitRows.isEmpty) {
      _bothSplitRows.addAll([
        {
          'purpose': _selectedPurpose ?? defaultP,
          'category': _selectedCategory,
          'controller': TextEditingController(),
        },
        {
          'purpose': defaultP,
          'category': defaultC,
          'controller': TextEditingController(),
        },
      ]);
    }
  }

  // ---- Split Expense Validation ----
  double get _allocatedSplitExpenseTotal {
    double sum = 0;
    if (_splitExpenseMode == 'purpose') {
      for (final r in _purposeSplitRows) {
        sum +=
            double.tryParse((r['controller'] as TextEditingController).text) ??
            0;
      }
    } else if (_splitExpenseMode == 'category') {
      for (final r in _categorySplitRows) {
        sum +=
            double.tryParse((r['controller'] as TextEditingController).text) ??
            0;
      }
    } else if (_splitExpenseMode == 'both') {
      for (final r in _bothSplitRows) {
        sum +=
            double.tryParse((r['controller'] as TextEditingController).text) ??
            0;
      }
    }
    return sum;
  }

  bool get _hasDuplicateKeys {
    if (_splitExpenseMode == 'purpose') {
      final keys =
          _purposeSplitRows.map((r) => r['purpose'] as String).toList();
      return keys.length != keys.toSet().length;
    } else if (_splitExpenseMode == 'category') {
      final keys =
          _categorySplitRows.map((r) => r['category'] as String).toList();
      return keys.length != keys.toSet().length;
    } else {
      final keys =
          _bothSplitRows
              .map((r) => '${r['purpose']}::${r['category']}')
              .toList();
      return keys.length != keys.toSet().length;
    }
  }

  bool get _isSplitExpenseValid {
    if (!_splitExpenseEnabled) return true;
    if (_enteredAmount <= 0) return false;
    if (_hasDuplicateKeys) return false;
    return (_allocatedSplitExpenseTotal - _enteredAmount).abs() < 0.01;
  }

  // ---- Friend Split Validation ----
  double get _allocatedFriendSplitTotal {
    if (_friendSplitType == SplitType.equally) return _enteredAmount;
    double sum = 0;
    final allNames = ['You', ..._selectedFriendNames];
    for (final name in allNames) {
      final ctrl = _friendCustomSplitControllers[name];
      if (ctrl != null) {
        sum += double.tryParse(ctrl.text) ?? 0;
      }
    }
    return sum;
  }

  bool get _isFriendSplitValid {
    if (!_friendSplitEnabled) return true;
    if (_selectedFriendNames.isEmpty) return false;
    if (_enteredAmount <= 0) return false;
    if (_friendSplitType == SplitType.custom) {
      return (_allocatedFriendSplitTotal - _enteredAmount).abs() < 0.01;
    }
    return true;
  }

  // ---- Outing Validation ----
  TextEditingController _tripCustomSplitController(String memberId) {
    return _customTripSplitControllers.putIfAbsent(
      memberId,
      () => TextEditingController(),
    );
  }

  bool get _tripCustomSplitValid {
    final outing = ref.read(openOutingProvider);
    if (outing == null) return false;
    var sum = 0.0;
    for (final m in outing.members) {
      final mId = m.name.toLowerCase() == 'you' ? 'you' : m.id;
      sum += double.tryParse(_tripCustomSplitController(mId).text) ?? 0;
    }
    return (sum - _enteredAmount).abs() < 0.01;
  }

  bool get _isTripFormValid {
    if (!_isTripMode) return true;
    final outing = ref.read(openOutingProvider);
    if (outing == null) return false;
    if (_paidByMemberId == null) return false;
    if (_tripSplitType == SplitType.custom) return _tripCustomSplitValid;
    return true;
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final date = await showDatePicker(
      context: context,
      initialDate: _selectedDate.isAfter(now) ? now : _selectedDate,
      firstDate: DateTime(2020),
      lastDate: now,
    );
    if (date == null || !mounted) return;
    setState(() {
      _selectedDate = DateTime(date.year, date.month, date.day);
    });
  }

  Future<void> _pickTime() async {
    final time = await showTimePicker(
      context: context,
      initialTime: _selectedTime,
    );
    if (time == null || !mounted) return;
    setState(() => _selectedTime = time);
  }

  void _onUpiIdentifierChanged(String value) {
    final id = value.trim();
    if (id.isEmpty) return;
    final txType = _typeIndex == 0 ? 'debit' : 'credit';
    final rule = ref
        .read(merchantProvider.notifier)
        .findRule(id, upiId: id, transactionType: txType);
    if (rule == null) return;
    setState(() {
      if (_titleController.text.trim().isEmpty &&
          rule.displayName.trim().isNotEmpty) {
        _titleController.text = rule.displayName;
      }
      if (rule.defaultCategory.trim().isNotEmpty) {
        _selectedCategory = rule.defaultCategory;
      }
      if (rule.defaultPurposeType.trim().isNotEmpty) {
        final purposes = _purposesForPicker(
          ref.read(userStateProvider).purposeTypes,
        );
        if (purposes.contains(rule.defaultPurposeType)) {
          _selectedPurpose = rule.defaultPurposeType;
        }
      }
    });
  }

  InputDecoration _softDialogInputDecoration({
    String? labelText,
    String? hintText,
  }) {
    final outline = OutlineInputBorder(
      borderRadius: BorderRadius.circular(16),
      borderSide: BorderSide(color: context.softBorder),
    );
    return InputDecoration(
      labelText: labelText,
      hintText: hintText,
      labelStyle: TextStyle(color: context.softMuted),
      hintStyle: TextStyle(color: context.softFaint),
      filled: true,
      fillColor: context.softSurfaceVariant,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: outline,
      enabledBorder: outline,
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(color: context.softEmerald, width: 1.5),
      ),
    );
  }

  ButtonStyle _softDialogCancelStyle() => TextButton.styleFrom(
    foregroundColor: context.softMuted,
    textStyle: const TextStyle(fontWeight: FontWeight.w600),
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
  );

  ButtonStyle _softDialogConfirmStyle() => ElevatedButton.styleFrom(
    backgroundColor: SoftColors.control,
    foregroundColor: Colors.white,
    elevation: 0,
    textStyle: const TextStyle(fontWeight: FontWeight.w700),
    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
  );

  Future<void> _promptAddCategory() async {
    final controller = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder:
          (ctx) => AlertDialog(
            backgroundColor: context.softCard,
            surfaceTintColor: Colors.transparent,
            elevation: 10,
            insetPadding: const EdgeInsets.symmetric(horizontal: 24),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24),
            ),
            title: Text(
              _typeIndex == 1 ? 'New income category' : 'New expense category',
              style: TextStyle(
                color: context.softInk,
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
            ),
            content: TextField(
              controller: controller,
              autofocus: true,
              style: TextStyle(color: context.softInk),
              decoration: _softDialogInputDecoration(hintText: 'Category name'),
              textCapitalization: TextCapitalization.words,
              onSubmitted: (v) => Navigator.pop(ctx, v.trim()),
            ),
            actionsPadding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
            actions: [
              TextButton(
                style: _softDialogCancelStyle(),
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Cancel'),
              ),
              ElevatedButton(
                style: _softDialogConfirmStyle(),
                onPressed: () => Navigator.pop(ctx, controller.text.trim()),
                child: const Text('Add'),
              ),
            ],
          ),
    );
    if (name == null || name.isEmpty || !mounted) return;
    final notifier = ref.read(categoryProvider.notifier);
    if (_typeIndex == 1) {
      notifier.addIncomeCategory(name);
    } else {
      notifier.addExpenseCategory(name);
    }
    setState(() => _selectedCategory = name);
  }

  List<TransactionSplitRow> _buildSplitRows() {
    List<Map<String, dynamic>> rows;
    switch (_splitExpenseMode) {
      case 'category':
        rows = _categorySplitRows;
        break;
      case 'both':
        rows = _bothSplitRows;
        break;
      case 'purpose':
      default:
        rows = _purposeSplitRows;
    }
    return rows
        .map(
          (r) => TransactionSplitRow(
            categoryId: (r['category'] as String?) ?? _selectedCategory,
            purposeId: (r['purpose'] as String?) ?? (_selectedPurpose ?? ''),
            amount:
                double.tryParse(
                  (r['controller'] as TextEditingController).text,
                ) ??
                0,
          ),
        )
        .where((r) => r.amount > 0)
        .toList();
  }

  void _showAddItemDialog() {
    final nameCtrl = TextEditingController();
    final amtCtrl = TextEditingController();
    final catCtrl = TextEditingController(text: _selectedCategory);

    showDialog(
      context: context,
      builder:
          (ctx) => AlertDialog(
            backgroundColor: context.softCard,
            surfaceTintColor: Colors.transparent,
            elevation: 10,
            insetPadding: const EdgeInsets.symmetric(horizontal: 24),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24),
            ),
            title: Text(
              'Add Purchased Line Item',
              style: TextStyle(
                color: context.softInk,
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameCtrl,
                  style: TextStyle(color: context.softInk),
                  decoration: _softDialogInputDecoration(
                    labelText: 'Item Name (e.g. Milk)',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: amtCtrl,
                  keyboardType: const TextInputType.numberWithOptions(
                    decimal: true,
                  ),
                  style: TextStyle(color: context.softInk),
                  decoration: _softDialogInputDecoration(
                    labelText: 'Amount (₹)',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: catCtrl,
                  style: TextStyle(color: context.softInk),
                  decoration: _softDialogInputDecoration(labelText: 'Category'),
                ),
              ],
            ),
            actionsPadding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
            actions: [
              TextButton(
                style: _softDialogCancelStyle(),
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Cancel'),
              ),
              ElevatedButton(
                style: _softDialogConfirmStyle(),
                onPressed: () {
                  final n = nameCtrl.text.trim();
                  final a = double.tryParse(amtCtrl.text.trim()) ?? 0;
                  final c = catCtrl.text.trim();
                  if (n.isNotEmpty && a > 0) {
                    setState(() {
                      _itemRows.add(
                        TransactionItemRow(name: n, categoryId: c, amount: a),
                      );
                    });
                    Navigator.pop(ctx);
                  }
                },
                child: const Text('Add'),
              ),
            ],
          ),
    );
  }

  void _save() {
    if (_saving) return;
    if (!_formKey.currentState!.validate() || _selectedAccount == null) return;
    if (_combinedDateTime.isAfter(DateTime.now())) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Future transactions cannot be added.'),
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }
    if (_splitExpenseEnabled && !_isSplitExpenseValid) return;
    if (_friendSplitEnabled && !_isFriendSplitValid) return;
    if (_isTripMode && !_isTripFormValid) return;

    _saving = true;
    if (mounted) setState(() {});

    if (_isTripMode) {
      _saveTripExpense();
      return;
    }

    if (_typeIndex == 2) {
      if (!_saveTransfer()) {
        _saving = false;
        if (mounted) setState(() {});
      }
      return;
    }

    try {
      final amount = double.parse(_amountController.text.replaceAll(',', ''));
      final merchantName = _titleController.text.trim();
      final upiOrId = _upiController.text.trim();
      final note = _noteController.text.trim();
      final description = _descriptionController.text.trim();
      final isExp = _typeIndex == 0;
      final when = _combinedDateTime;

      final paymentType =
          _selectedAccount!.type.toLowerCase() == 'cash' ? 'Cash' : 'Online';

      final contribs = ref.read(contributorProvider);
      final contributor =
          !isExp
              ? (contribs.length > 1
                  ? _selectedContributor
                  : ref.read(contributorProvider.notifier).defaultName)
              : null;

      final splits =
          _splitExpenseEnabled
              ? _buildSplitRows()
              : const <TransactionSplitRow>[];

      final items =
          _itemRows.isNotEmpty ? _itemRows : const <TransactionItemRow>[];
      final customTitle = _customTitleController.text.trim();

      final stableKey = MerchantIdentifierResolver.stableKey(
        upiId: upiOrId.isNotEmpty ? upiOrId : null,
        rawIdentifier: upiOrId.isNotEmpty ? upiOrId : null,
        parsedName: null,
        rawMessage: '',
      );

      final existingTx = widget.initialTransaction;

      if (existingTx != null) {
        // ── Edit Transaction Path ──
        if (!_friendSplitEnabled) {
          ref
              .read(friendSplitProvider.notifier)
              .removeSplitByTransactionId(existingTx.id);
        }

        final updatedTx = existingTx.copyWith(
          merchant: merchantName.isEmpty ? 'Transaction' : merchantName,
          category: _selectedCategory,
          account: _selectedAccount!.name,
          paymentType: paymentType,
          time: DateFormat('h:mm a').format(when),
          amount: amount,
          isExpense: isExp,
          date: when,
          purpose: _selectedPurpose,
          splits: splits,
          upiId: upiOrId,
          referenceId:
              upiOrId.isNotEmpty && !upiOrId.contains('@') ? upiOrId : '',
          rawIdentifier: stableKey.isNotEmpty ? stableKey : null,
          note: note,
          description: description,
          outingId: _selectedOutingId,
          clearOutingId: _selectedOutingId == null,
          contributorSource: contributor,
          clearContributorSource: contributor == null,
          title: customTitle.isNotEmpty ? customTitle : null,
          clearTitle: customTitle.isEmpty,
          items: items,
        );

        ref
            .read(model.transactionProvider.notifier)
            .updateTransaction(updatedTx);

        if (_friendSplitEnabled) {
          _saveFriendSplitRecord(updatedTx.id, amount, merchantName, when);
        }

        if (stableKey.isNotEmpty) {
          ref
              .read(merchantProvider.notifier)
              .learnRule(
                identifier: stableKey,
                name: updatedTx.merchant,
                category: updatedTx.category,
                accountType: _selectedPurpose ?? _selectedAccount!.name,
                transactionType: isExp ? 'debit' : 'credit',
              );
        }

        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Transaction updated'),
            behavior: SnackBarBehavior.floating,
          ),
        );
      } else {
        // ── Add New Transaction Path ──
        final tx = model.Transaction(
          merchant: merchantName.isEmpty ? 'Transaction' : merchantName,
          category: _selectedCategory,
          account: _selectedAccount!.name,
          paymentType: paymentType,
          time: DateFormat('h:mm a').format(when),
          amount: amount,
          isExpense: isExp,
          date: when,
          isTransfer: false,
          purpose: _selectedPurpose,
          isGroup: _friendSplitEnabled,
          groupCount: _friendSplitEnabled ? _selectedFriendNames.length + 1 : 0,
          splits: splits,
          upiId: upiOrId,
          referenceId:
              upiOrId.isNotEmpty && !upiOrId.contains('@') ? upiOrId : '',
          rawIdentifier: stableKey.isNotEmpty ? stableKey : null,
          note: note,
          description: description,
          rawMessage: '',
          isMerchantMapped: stableKey.isNotEmpty,
          outingId: _selectedOutingId,
          isAutoLinked: false,
          contributorSource: contributor,
          title: customTitle.isNotEmpty ? customTitle : null,
          items: items,
        );

        ref
            .read(model.transactionProvider.notifier)
            .addTransaction(tx, applyOutingAutoLink: false);

        if (_friendSplitEnabled) {
          _saveFriendSplitRecord(tx.id, amount, merchantName, when);
        }

        if (stableKey.isNotEmpty) {
          ref
              .read(merchantProvider.notifier)
              .learnRule(
                identifier: stableKey,
                name: tx.merchant,
                category: tx.category,
                accountType: _selectedPurpose ?? _selectedAccount!.name,
                transactionType: isExp ? 'debit' : 'credit',
              );
        }

        Navigator.pop(context);
        SuccessCheckDialog.show(
          context,
          message: isExp ? 'Expense Added' : 'Income Added',
        );
      }
    } catch (_) {
      _saving = false;
      if (mounted) setState(() {});
      rethrow;
    }
  }

  void _saveFriendSplitRecord(
    String txId,
    double amount,
    String merchantName,
    DateTime when,
  ) {
    final youMember = OutingMember(id: 'you', name: 'You', isCurrentUser: true);
    final friendMembers =
        _selectedFriendNames.map((n) => OutingMember(name: n)).toList();
    final allMembers = [youMember, ...friendMembers];

    List<FriendSplitShare> shares;
    if (_friendSplitType == SplitType.equally) {
      final per = amount / allMembers.length;
      shares =
          allMembers
              .map((m) => FriendSplitShare(memberId: m.id, amount: per))
              .toList();
    } else {
      shares =
          allMembers.map((m) {
            final key = m.isCurrentUser ? 'You' : m.name;
            final ctrl = _friendCustomSplitControllers[key];
            return FriendSplitShare(
              memberId: m.id,
              amount: double.tryParse(ctrl?.text ?? '') ?? 0,
            );
          }).toList();
    }

    final existingSplit = ref
        .read(friendSplitProvider.notifier)
        .findForTransaction(txId);

    final split = FriendSplit(
      id: existingSplit?.id ?? const Uuid().v4(),
      transactionId: txId,
      description: merchantName.isEmpty ? 'Transaction' : merchantName,
      amount: amount,
      category: _selectedCategory,
      date: when,
      members: allMembers,
      paidByMemberId: 'you',
      splitType: _friendSplitType,
      splits: shares,
      accountName: _selectedAccount!.name,
      paymentMode: _paymentType,
      note: _noteController.text.trim(),
    );

    ref.read(friendSplitProvider.notifier).addOrUpdateSplit(split);
  }

  /// Mirrors `TransferBottomSheet`'s submit logic (same validation, same
  /// `Transaction(...)` shape) but sourced from this sheet's own From/To
  /// account state instead of a separate chip picker.
  /// Returns false when validation failed and the sheet stayed open.
  bool _saveTransfer() {
    final from = _selectedAccount;
    final to = _selectedToAccount;
    if (from == null || to == null || to.name == from.name) return false;

    final amount = parsePositiveAmount(_amountController.text);
    if (amount == null) return false;

    final available = ref
        .read(model.transactionProvider.notifier)
        .getFullAccountBalance(from.name);
    if (amount > available) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Insufficient balance in ${from.name}. Available ₹${_formatMoney(available)}',
          ),
          backgroundColor: SoftAddTone.error(context),
          behavior: SnackBarBehavior.floating,
        ),
      );
      return false;
    }

    final transferType =
        from.isCash && !to.isCash
            ? 'cash_to_bank'
            : !from.isCash && to.isCash
            ? 'bank_to_cash'
            : 'bank_to_bank';
    final when = _combinedDateTime;

    final tx = model.Transaction(
      merchant: 'Transfer',
      category: 'Transfer',
      account: from.name,
      paymentType: from.isCash ? 'Cash' : 'Online',
      time: DateFormat('h:mm a').format(when),
      amount: amount,
      isExpense: true,
      isTransfer: true,
      transferTo: to.name,
      toAccountId: to.id,
      transferType: transferType,
      date: when,
      note: _noteController.text.trim(),
    );
    ref
        .read(model.transactionProvider.notifier)
        .addTransaction(tx, applyOutingAutoLink: false);

    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Transfer ₹${amount.toInt()} confirmed'),
        backgroundColor: const Color(0xFF006C49),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.fromLTRB(20, 0, 20, 20),
      ),
    );
    return true;
  }

  void _saveTripExpense() {
    final outing = ref.read(openOutingProvider);
    if (outing == null || !_isTripFormValid) {
      _saving = false;
      if (mounted) setState(() {});
      return;
    }

    final amount = double.parse(_amountController.text.replaceAll(',', ''));
    final title = _titleController.text.trim();
    final paymentMode =
        _selectedAccount!.isCash
            ? 'Cash'
            : (_selectedAccount!.type.toLowerCase() == 'wallet'
                ? 'Wallet'
                : 'Online');

    Map<String, double>? customSplitAmounts;
    List<String> memberIds;
    if (_tripSplitType == SplitType.custom) {
      customSplitAmounts = {
        for (final m in outing.members)
          (m.name.toLowerCase() == 'you' ? 'you' : m.id):
              double.tryParse(
                _tripCustomSplitController(
                  m.name.toLowerCase() == 'you' ? 'you' : m.id,
                ).text,
              ) ??
              0,
      };
      memberIds = customSplitAmounts.keys.toList();
    } else if (_tripSplitType == SplitType.solo) {
      memberIds = [_paidByMemberId!];
    } else {
      memberIds =
          outing.members
              .map((m) => m.name.toLowerCase() == 'you' ? 'you' : m.id)
              .toList();
    }

    final expense = OutingExpense(
      id: widget.initialExpense?.id,
      title: title.isEmpty ? 'Expense' : title,
      amount: amount,
      category: _selectedCategory,
      date: _combinedDateTime,
      accountId: _selectedAccount!.name,
      paymentMode: paymentMode,
      splitType: _tripSplitType,
      memberIds: memberIds,
      purpose: outing.purpose,
      paidByMemberId: _paidByMemberId,
      customSplitAmounts: customSplitAmounts,
    );

    if (widget.initialExpense != null && widget.initialOutingId != null) {
      ref
          .read(outingProvider.notifier)
          .updateExpense(widget.initialOutingId!, expense);
    } else {
      ref.read(outingProvider.notifier).addExpenseToOuting(outing.id, expense);
    }
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Trip expense saved'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final accounts = _accountsForPicker(ref.watch(userStateProvider).accounts);
    final purposes = _purposesForPicker(
      ref.watch(userStateProvider).purposeTypes,
    );
    final contributors = ref.watch(contributorProvider);
    final openOuting = ref.watch(openOutingProvider);
    final activeOutings =
        ref.watch(outingProvider).where((o) => o.isActive).toList();
    final categories = _categoriesForType;
    final friendsList = ref.watch(friendsProvider);
    final showContributor = _typeIndex == 1 && contributors.length > 1;
    // No transfer editing in v1 (matches the web AddTransactionSlideOver's
    // "no transfer editing" decision) — the sheet still opens read-only on
    // the Transfer tab so the row's shape is at least visible, instead of
    // silently mis-rendering as an Expense.
    final isEditingExistingTransfer =
        widget.initialTransaction?.isTransfer == true;
    final activeColor = SoftAddTone.primary(context);
    final quietBorder = SoftAddTone.border(context);

    final errorStyle = SoftAddTone.text(
      context,
      fontSize: 12,
      fontWeight: FontWeight.w500,
      color: SoftAddTone.error(context),
    );

    InputDecoration fieldDecoration(String hint) =>
        SoftAddTone.input(context, hint, errorStyle: errorStyle);

    final showCategory =
        _typeIndex != 2 &&
        !(_splitExpenseEnabled &&
            (_splitExpenseMode == 'category' || _splitExpenseMode == 'both'));
    final showPurpose =
        _typeIndex != 2 &&
        !_isTripMode &&
        !(_splitExpenseEnabled &&
            (_splitExpenseMode == 'purpose' || _splitExpenseMode == 'both'));

    return TerminalWrapper(
      screenName: 'AddExpenseForm',
      child: Padding(
        padding: EdgeInsets.fromLTRB(
          12,
          8,
          12,
          MediaQuery.paddingOf(context).bottom + 16,
        ),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SoftAddHeader(
                  title:
                      widget.initialTransaction != null ||
                              widget.initialExpense != null
                          ? 'Edit Transaction'
                          : (_isTripMode
                              ? 'Add Outing Expense'
                              : 'Add Transaction'),
                  onClose: () => Navigator.of(context).maybePop(),
                ),
                const SizedBox(height: 10),

                if (!_isTripMode) ...[
                  SoftAddTypeBar(index: _typeIndex, onChanged: _onTypeChanged),
                  const SizedBox(height: 16),
                ],

                Container(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 14),
                  decoration: BoxDecoration(
                    color: SoftAddTone.card(context),
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: SoftAddTone.cardBorder(context)),
                    boxShadow: SoftAddTone.cardShadowOf(context),
                  ),
                  child: Column(
                    children: [
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          'INR (₹)',
                          style: SoftAddTone.text(
                            context,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            color: SoftAddTone.secondary(context),
                          ),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            _typeIndex == 0
                                ? '−'
                                : (_typeIndex == 1 ? '+' : '↔'),
                            style: SoftAddTone.text(
                              context,
                              fontSize: 30,
                              fontWeight: FontWeight.w800,
                              color:
                                  _typeIndex == 0
                                      ? SoftAddTone.error(context)
                                      : SoftAddTone.brand(context),
                              height: 1,
                            ),
                          ),
                          const SizedBox(width: 4),
                          Text(
                            '₹',
                            style: SoftAddTone.text(
                              context,
                              fontSize: 32,
                              fontWeight: FontWeight.w800,
                              letterSpacing: -0.6,
                              height: 1,
                            ),
                          ),
                          SizedBox(
                            width: 150,
                            child: TextFormField(
                              controller: _amountController,
                              cursorColor: SoftAddTone.emerald(context),
                              keyboardType:
                                  const TextInputType.numberWithOptions(
                                    decimal: true,
                                  ),
                              style: SoftAddTone.text(
                                context,
                                fontSize: 32,
                                fontWeight: FontWeight.w800,
                                letterSpacing: -0.6,
                                height: 1,
                              ),
                              inputFormatters: [amountInputFormatter],
                              onChanged: (_) => setState(() {}),
                              validator:
                                  (v) =>
                                      parsePositiveAmount(v) == null
                                          ? 'Amount is required'
                                          : null,
                              decoration: InputDecoration(
                                border: InputBorder.none,
                                enabledBorder: InputBorder.none,
                                focusedBorder: InputBorder.none,
                                errorBorder: InputBorder.none,
                                focusedErrorBorder: InputBorder.none,
                                filled: true,
                                fillColor: Colors.transparent,
                                hintText: '0',
                                hintStyle: SoftAddTone.text(
                                  context,
                                  fontSize: 32,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: -0.6,
                                  color: SoftAddTone.secondary(context),
                                ),
                                isDense: true,
                                contentPadding: EdgeInsets.zero,
                              ),
                              textAlign: TextAlign.left,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children:
                              [100, 500, 1000, 2000, 5000].map((addVal) {
                                final label =
                                    addVal >= 1000
                                        ? '+₹${addVal ~/ 1000},${(addVal % 1000).toString().padLeft(3, '0')}'
                                        : '+₹$addVal';
                                return Padding(
                                  padding: const EdgeInsets.only(right: 8),
                                  child: InkWell(
                                    onTap: () {
                                      final current = _enteredAmount;
                                      final updated =
                                          (current + addVal).toInt();
                                      _amountController.text =
                                          updated.toString();
                                      setState(() {});
                                    },
                                    borderRadius: BorderRadius.circular(8),
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 10,
                                        vertical: 6,
                                      ),
                                      decoration: BoxDecoration(
                                        color: SoftAddTone.canvas(context),
                                        borderRadius: BorderRadius.circular(8),
                                        border: Border.all(color: quietBorder),
                                      ),
                                      child: Text(
                                        label,
                                        style: SoftAddTone.text(
                                          context,
                                          fontSize: 12,
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                    ),
                                  ),
                                );
                              }).toList(),
                        ),
                      ),
                    ],
                  ),
                ),
                if (_typeIndex == 2 && _selectedAccount != null) ...[
                  const SizedBox(height: 6),
                  Text(
                    'Available in ${_selectedAccount!.name}: ₹${_formatMoney(ref.read(model.transactionProvider.notifier).getFullAccountBalance(_selectedAccount!.name))}',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      color: SoftAddTone.secondary(context),
                    ),
                  ),
                ],
                const SizedBox(height: 20),

                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: SoftAddTone.cardBox(context),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            'Transaction Metadata',
                            style: SoftAddTone.text(
                              context,
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.8,
                              color: SoftAddTone.secondary(context),
                            ),
                          ),
                          const Spacer(),
                          Text(
                            'Required *',
                            style: SoftAddTone.text(
                              context,
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                              color: activeColor,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      if (_typeIndex != 2) ...[
                        _FormLabel(label: 'Title'),
                        const SizedBox(height: 8),
                        TextFormField(
                          controller: _titleController,
                          style: const TextStyle(fontWeight: FontWeight.w500),
                          onChanged: (val) {
                            _onUpiIdentifierChanged(val);
                            setState(() {});
                          },
                          validator:
                              (v) =>
                                  (v ?? '').trim().isEmpty
                                      ? 'Title is required'
                                      : null,
                          decoration: fieldDecoration(
                            _typeIndex == 1
                                ? 'e.g. Salary, Freelance, Bonus'
                                : 'e.g. Amazon, Uber, Dinner with friends',
                          ).copyWith(
                            prefixIcon: Icon(
                              LucideIcons.shoppingBag,
                              size: 18,
                              color: SoftAddTone.secondary(context),
                            ),
                            prefixIconConstraints: const BoxConstraints(
                              minWidth: 40,
                              minHeight: 40,
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),
                      ],

                      // ── Soft Soft Account row ──
                      SoftAddPickerRow(
                        title:
                            _typeIndex == 2
                                ? 'From account'
                                : 'Paid Through Account',
                        value:
                            accounts.isEmpty
                                ? 'No accounts available'
                                : (_selectedAccount?.name ?? 'Select...'),
                        icon:
                            (_selectedAccount?.type.toLowerCase() == 'cash')
                                ? LucideIcons.banknote
                                : LucideIcons.building2,
                        onTap:
                            accounts.isEmpty
                                ? null
                                : () async {
                                  final picked = await showSoftAccountPicker(
                                    context: context,
                                    accounts:
                                        accounts.map((a) => a.name).toList(),
                                    selected: _selectedAccount?.name,
                                    iconFor: (name) {
                                      final acc =
                                          accounts
                                              .where((a) => a.name == name)
                                              .firstOrNull;
                                      return acc?.type.toLowerCase() == 'cash'
                                          ? LucideIcons.banknote
                                          : LucideIcons.building2;
                                    },
                                  );
                                  if (picked == null || !mounted) return;
                                  final acc =
                                      accounts
                                          .where((a) => a.name == picked)
                                          .firstOrNull;
                                  if (acc == null) return;
                                  setState(() {
                                    _selectedAccount = acc;
                                    _paymentType =
                                        acc.type.toLowerCase() == 'cash'
                                            ? 'Cash'
                                            : 'Online';
                                  });
                                },
                      ),
                      const SizedBox(height: 12),

                      // ── Soft Soft To Account (Transfer only) ──
                      if (_typeIndex == 2) ...[
                        SoftAddPickerRow(
                          title: 'To account',
                          value: _selectedToAccount?.name ?? 'Select...',
                          icon: LucideIcons.building2,
                          onTap:
                              accounts.isEmpty
                                  ? null
                                  : () async {
                                    final picked = await showSoftAccountPicker(
                                      context: context,
                                      accounts:
                                          accounts.map((a) => a.name).toList(),
                                      selected: _selectedToAccount?.name,
                                      iconFor: (name) {
                                        final acc =
                                            accounts
                                                .where((a) => a.name == name)
                                                .firstOrNull;
                                        return acc?.type.toLowerCase() == 'cash'
                                            ? LucideIcons.banknote
                                            : LucideIcons.building2;
                                      },
                                    );
                                    if (picked == null || !mounted) return;
                                    final acc =
                                        accounts
                                            .where((a) => a.name == picked)
                                            .firstOrNull;
                                    if (acc == null) return;
                                    setState(() => _selectedToAccount = acc);
                                  },
                        ),
                        if (_selectedToAccount != null &&
                            _selectedAccount != null &&
                            _selectedToAccount!.name ==
                                _selectedAccount!.name) ...[
                          const SizedBox(height: 6),
                          Text(
                            'Please select a different destination account.',
                            style: errorStyle,
                          ),
                        ],
                        const SizedBox(height: 12),
                      ],

                      // ── Soft Soft Category Selector ──
                      if (showCategory) ...[
                        SoftAddPickerRow(
                          title: 'Category',
                          labelTrailing: TextButton(
                            onPressed: _promptAddCategory,
                            style: TextButton.styleFrom(
                              foregroundColor: SoftAddTone.primary(context),
                              visualDensity: VisualDensity.compact,
                              padding: EdgeInsets.zero,
                              minimumSize: Size.zero,
                              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            ),
                            child: Text(
                              'Add Category',
                              style: SoftAddTone.text(
                                context,
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                color: SoftAddTone.primary(context),
                              ),
                            ),
                          ),
                          value:
                              categories.isEmpty
                                  ? 'Syncing categories…'
                                  : _selectedCategory,
                          icon: CategoryIcon.resolve(_selectedCategory).icon,
                          onTap:
                              categories.isEmpty
                                  ? null
                                  : () async {
                                    final picked = await showSoftCategoryPicker(
                                      context: context,
                                      categories: categories,
                                      selected: _selectedCategory,
                                      entryTypeLabel:
                                          _typeIndex == 1
                                              ? 'Income'
                                              : 'Expense',
                                      onAdd: _promptAddCategory,
                                    );
                                    if (picked == null || !mounted) return;
                                    setState(() => _selectedCategory = picked);
                                  },
                        ),
                        const SizedBox(height: 8),
                      ],

                      // ── Purpose Selector ──
                      if (showPurpose) ...[
                        _FormLabel(label: 'Purpose'),
                        const SizedBox(height: 8),
                        if (purposes.isEmpty)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: Text(
                              'No purposes available.',
                              style: TextStyle(
                                fontSize: 12,
                                color: SoftAddTone.secondary(context),
                              ),
                            ),
                          )
                        else
                          _HorizontalSelector(
                            height: 48,
                            items:
                                purposes
                                    .map(
                                      (p) => _SelectorItem(
                                        label: p,
                                        id: p,
                                        icon: LucideIcons.layers,
                                        isSelected: _selectedPurpose == p,
                                        onTap:
                                            () => setState(
                                              () => _selectedPurpose = p,
                                            ),
                                        color: activeColor,
                                      ),
                                    )
                                    .toList(),
                          ),
                        const SizedBox(height: 16),
                      ],

                      // ── Contributor Selector (Income Only) ──
                      if (showContributor) ...[
                        _FormLabel(label: 'CONTRIBUTOR'),
                        const SizedBox(height: 8),
                        _HorizontalSelector(
                          height: 48,
                          items:
                              contributors
                                  .map(
                                    (c) => _SelectorItem(
                                      label: c.name,
                                      id: c.name,
                                      icon:
                                          c.isDefault
                                              ? LucideIcons.user
                                              : LucideIcons.users,
                                      isSelected:
                                          _selectedContributor == c.name,
                                      onTap:
                                          () => setState(
                                            () => _selectedContributor = c.name,
                                          ),
                                      color: SoftAddTone.primary(context),
                                    ),
                                  )
                                  .toList(),
                        ),
                        const SizedBox(height: 16),
                      ],

                      // ── Outing Selection Card ──
                      if (_isTripMode && openOuting != null) ...[
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: SoftAddTone.mintSubtle(context),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: SoftAddTone.primary(
                                context,
                              ).withValues(alpha: 0.2),
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Icon(
                                    LucideIcons.mapPin,
                                    color: SoftAddTone.primary(context),
                                    size: 18,
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Text(
                                      'Outing: ${openOuting.title}',
                                      style: SoftAddTone.text(
                                        context,
                                        fontSize: 14,
                                        fontWeight: FontWeight.w700,
                                        color: SoftAddTone.primary(context),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),
                              _FormLabel(label: 'PAID BY'),
                              const SizedBox(height: 8),
                              Wrap(
                                spacing: 8,
                                runSpacing: 8,
                                children:
                                    openOuting.members.map((m) {
                                      final mId =
                                          m.name.toLowerCase() == 'you'
                                              ? 'you'
                                              : m.id;
                                      final isSelected = _paidByMemberId == mId;
                                      return FilterChip(
                                        label: Text(m.name),
                                        selected: isSelected,
                                        onSelected:
                                            (_) => setState(
                                              () => _paidByMemberId = mId,
                                            ),
                                        selectedColor: SoftColors.control,
                                        checkmarkColor: Colors.white,
                                      );
                                    }).toList(),
                              ),
                              const SizedBox(height: 12),
                              _FormLabel(label: 'SPLIT'),
                              const SizedBox(height: 8),
                              Row(
                                children: [
                                  _ChipTab(
                                    label: 'Split',
                                    icon: LucideIcons.users,
                                    isSelected:
                                        _tripSplitType == SplitType.equally,
                                    onTap:
                                        () => setState(
                                          () =>
                                              _tripSplitType =
                                                  SplitType.equally,
                                        ),
                                  ),
                                  const SizedBox(width: 8),
                                  _ChipTab(
                                    label: 'Solo',
                                    icon: LucideIcons.user,
                                    isSelected:
                                        _tripSplitType == SplitType.solo,
                                    onTap:
                                        () => setState(
                                          () => _tripSplitType = SplitType.solo,
                                        ),
                                  ),
                                  const SizedBox(width: 8),
                                  _ChipTab(
                                    label: 'Custom',
                                    icon: LucideIcons.calculator,
                                    isSelected:
                                        _tripSplitType == SplitType.custom,
                                    onTap:
                                        () => setState(
                                          () =>
                                              _tripSplitType = SplitType.custom,
                                        ),
                                  ),
                                ],
                              ),
                              if (_tripSplitType == SplitType.custom) ...[
                                const SizedBox(height: 12),
                                ...openOuting.members.map((m) {
                                  final mId =
                                      m.name.toLowerCase() == 'you'
                                          ? 'you'
                                          : m.id;
                                  final ctrl = _tripCustomSplitController(mId);
                                  return Padding(
                                    padding: const EdgeInsets.only(bottom: 6),
                                    child: Row(
                                      children: [
                                        Expanded(child: Text(m.name)),
                                        SizedBox(
                                          width: 90,
                                          child: TextFormField(
                                            controller: ctrl,
                                            keyboardType: TextInputType.number,
                                            textAlign: TextAlign.right,
                                            onChanged: (_) => setState(() {}),
                                            decoration: InputDecoration(
                                              hintText: '0',
                                              prefixText: '₹',
                                              isDense: true,
                                              contentPadding:
                                                  const EdgeInsets.symmetric(
                                                    horizontal: 10,
                                                    vertical: 8,
                                                  ),
                                              border: OutlineInputBorder(
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                }),
                                const SizedBox(height: 4),
                                Text(
                                  'Allocated ₹${openOuting.members.fold(0.0, (s, m) => s + (double.tryParse(_tripCustomSplitController(m.name.toLowerCase() == 'you' ? 'you' : m.id).text) ?? 0)).toStringAsFixed(0)} / ₹${_enteredAmount.toStringAsFixed(0)}',
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                    color:
                                        _tripCustomSplitValid
                                            ? SoftAddTone.brand(context)
                                            : SoftAddTone.error(context),
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                      ],
                      if (!_isTripMode &&
                          activeOutings.isNotEmpty &&
                          !_splitExpenseEnabled &&
                          !_friendSplitEnabled) ...[
                        _FormLabel(label: 'Link to Outing / Trip'),
                        const SizedBox(height: 8),
                        DropdownButtonFormField<String?>(
                          initialValue: _selectedOutingId,
                          decoration: fieldDecoration('Select active outing'),
                          items: [
                            const DropdownMenuItem<String?>(
                              value: null,
                              child: Text('None — personal transaction'),
                            ),
                            ...activeOutings.map(
                              (o) => DropdownMenuItem<String?>(
                                value: o.id,
                                child: Text(o.title),
                              ),
                            ),
                          ],
                          onChanged:
                              (v) => setState(() => _selectedOutingId = v),
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // ── Split Expense Switch & Rows ──
                if (_typeIndex == 0 &&
                    !_isTripMode &&
                    !_friendSplitEnabled) ...[
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: SoftAddTone.cardBox(context),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(
                              LucideIcons.split,
                              size: 18,
                              color: activeColor,
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Text(
                                        'Split Expense',
                                        style: TextStyle(
                                          fontWeight: FontWeight.w700,
                                          fontSize: 13,
                                          color: SoftAddTone.ink(context),
                                        ),
                                      ),
                                      if (_splitExpenseEnabled) ...[
                                        const SizedBox(width: 6),
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 6,
                                            vertical: 2,
                                          ),
                                          decoration: BoxDecoration(
                                            color: SoftAddTone.brand(
                                              context,
                                            ).withValues(alpha: 0.12),
                                            borderRadius: BorderRadius.circular(
                                              99,
                                            ),
                                          ),
                                          child: Text(
                                            'ACTIVE',
                                            style: TextStyle(
                                              fontSize: 8,
                                              fontWeight: FontWeight.w800,
                                              color: SoftAddTone.brand(context),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ],
                                  ),
                                  Text(
                                    'Allocate between purposes or categories',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: SoftAddTone.secondary(context),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SoftAddSwitch(
                              value: _splitExpenseEnabled,
                              onChanged: _handleToggleSplitExpense,
                            ),
                          ],
                        ),

                        if (_splitExpenseEnabled) ...[
                          const SizedBox(height: 14),
                          Container(
                            padding: const EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              color: SoftAddTone.canvas(context),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: quietBorder),
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  child: _ChipTab(
                                    label: 'Purpose',
                                    icon: LucideIcons.target,
                                    isSelected: _splitExpenseMode == 'purpose',
                                    color: activeColor,
                                    expand: true,
                                    showIcon: false,
                                    onTap:
                                        () => _handleSetSplitExpenseMode(
                                          'purpose',
                                        ),
                                  ),
                                ),
                                Expanded(
                                  child: _ChipTab(
                                    label: 'Category',
                                    icon: LucideIcons.tag,
                                    isSelected: _splitExpenseMode == 'category',
                                    color: activeColor,
                                    expand: true,
                                    showIcon: false,
                                    onTap:
                                        () => _handleSetSplitExpenseMode(
                                          'category',
                                        ),
                                  ),
                                ),
                                Expanded(
                                  child: _ChipTab(
                                    label: 'Purpose + Cat',
                                    icon: LucideIcons.layers,
                                    isSelected: _splitExpenseMode == 'both',
                                    color: activeColor,
                                    expand: true,
                                    showIcon: false,
                                    onTap:
                                        () =>
                                            _handleSetSplitExpenseMode('both'),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 14),

                          // Purpose Split Rows
                          if (_splitExpenseMode == 'purpose') ...[
                            ..._purposeSplitRows.asMap().entries.map((entry) {
                              final idx = entry.key;
                              final row = entry.value;
                              final ctrl =
                                  row['controller'] as TextEditingController;
                              return Padding(
                                padding: const EdgeInsets.only(bottom: 8),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: DropdownButtonFormField<String>(
                                        initialValue:
                                            purposes.contains(row['purpose'])
                                                ? row['purpose'] as String
                                                : (purposes.isNotEmpty
                                                    ? purposes.first
                                                    : null),
                                        items:
                                            purposes
                                                .map(
                                                  (p) => DropdownMenuItem(
                                                    value: p,
                                                    child: Text(
                                                      p,
                                                      style: const TextStyle(
                                                        fontSize: 13,
                                                      ),
                                                    ),
                                                  ),
                                                )
                                                .toList(),
                                        onChanged:
                                            (v) => setState(
                                              () => row['purpose'] = v ?? '',
                                            ),
                                        decoration: InputDecoration(
                                          isDense: true,
                                          contentPadding:
                                              const EdgeInsets.symmetric(
                                                horizontal: 12,
                                                vertical: 10,
                                              ),
                                          border: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(
                                              12,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    SizedBox(
                                      width: 90,
                                      child: TextFormField(
                                        controller: ctrl,
                                        keyboardType: TextInputType.number,
                                        textAlign: TextAlign.right,
                                        onChanged: (_) => setState(() {}),
                                        decoration: InputDecoration(
                                          hintText: '0',
                                          prefixText: '₹',
                                          isDense: true,
                                          contentPadding:
                                              const EdgeInsets.symmetric(
                                                horizontal: 10,
                                                vertical: 10,
                                              ),
                                          border: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(
                                              12,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    if (_purposeSplitRows.length > 2)
                                      IconButton(
                                        icon: Icon(
                                          LucideIcons.trash2,
                                          size: 16,
                                          color: SoftAddTone.error(context),
                                        ),
                                        onPressed: () {
                                          setState(() {
                                            ctrl.dispose();
                                            _purposeSplitRows.removeAt(idx);
                                          });
                                        },
                                      ),
                                  ],
                                ),
                              );
                            }),
                            OutlinedButton.icon(
                              // Secondary button rule (white + ink + outline).
                              style: OutlinedButton.styleFrom(
                                foregroundColor: SoftColors.secondaryFg(
                                  context,
                                ),
                                backgroundColor: SoftColors.secondaryBg(
                                  context,
                                ),
                                side: BorderSide(
                                  color: SoftColors.secondaryOutline(context),
                                ),
                                minimumSize: const Size.fromHeight(40),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              onPressed: () {
                                setState(() {
                                  final defaultP =
                                      purposes.isNotEmpty
                                          ? purposes.first
                                          : 'Personal';
                                  _purposeSplitRows.add({
                                    'purpose': defaultP,
                                    'controller': TextEditingController(),
                                  });
                                });
                              },
                              icon: Icon(
                                LucideIcons.plusCircle,
                                size: 16,
                                color: SoftAddTone.primary(context),
                              ),
                              label: Text(
                                'Add Split Row',
                                style: SoftAddTone.text(
                                  context,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: SoftAddTone.primary(context),
                                ),
                              ),
                            ),
                          ],

                          // Category Split Rows
                          if (_splitExpenseMode == 'category') ...[
                            ..._categorySplitRows.asMap().entries.map((entry) {
                              final idx = entry.key;
                              final row = entry.value;
                              final ctrl =
                                  row['controller'] as TextEditingController;
                              final expCats =
                                  ref.watch(categoryProvider).expense;
                              return Padding(
                                padding: const EdgeInsets.only(bottom: 8),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: DropdownButtonFormField<String>(
                                        initialValue:
                                            expCats.contains(row['category'])
                                                ? row['category'] as String
                                                : (expCats.isNotEmpty
                                                    ? expCats.first
                                                    : null),
                                        items:
                                            expCats
                                                .map(
                                                  (c) => DropdownMenuItem(
                                                    value: c,
                                                    child: Text(
                                                      c,
                                                      style: const TextStyle(
                                                        fontSize: 13,
                                                      ),
                                                    ),
                                                  ),
                                                )
                                                .toList(),
                                        onChanged:
                                            (v) => setState(
                                              () => row['category'] = v ?? '',
                                            ),
                                        decoration: InputDecoration(
                                          isDense: true,
                                          contentPadding:
                                              const EdgeInsets.symmetric(
                                                horizontal: 12,
                                                vertical: 10,
                                              ),
                                          border: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(
                                              12,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    SizedBox(
                                      width: 90,
                                      child: TextFormField(
                                        controller: ctrl,
                                        keyboardType: TextInputType.number,
                                        textAlign: TextAlign.right,
                                        onChanged: (_) => setState(() {}),
                                        decoration: InputDecoration(
                                          hintText: '0',
                                          prefixText: '₹',
                                          isDense: true,
                                          contentPadding:
                                              const EdgeInsets.symmetric(
                                                horizontal: 10,
                                                vertical: 10,
                                              ),
                                          border: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(
                                              12,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    if (_categorySplitRows.length > 2)
                                      IconButton(
                                        icon: Icon(
                                          LucideIcons.trash2,
                                          size: 16,
                                          color: SoftAddTone.error(context),
                                        ),
                                        onPressed: () {
                                          setState(() {
                                            ctrl.dispose();
                                            _categorySplitRows.removeAt(idx);
                                          });
                                        },
                                      ),
                                  ],
                                ),
                              );
                            }),
                            OutlinedButton.icon(
                              // Secondary button rule (white + ink + outline).
                              style: OutlinedButton.styleFrom(
                                foregroundColor: SoftColors.secondaryFg(
                                  context,
                                ),
                                backgroundColor: SoftColors.secondaryBg(
                                  context,
                                ),
                                side: BorderSide(
                                  color: SoftColors.secondaryOutline(context),
                                ),
                                minimumSize: const Size.fromHeight(40),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              onPressed: () {
                                setState(() {
                                  final expCats =
                                      ref.read(categoryProvider).expense;
                                  final defaultC =
                                      expCats.isNotEmpty
                                          ? expCats.first
                                          : 'Food & Dining';
                                  _categorySplitRows.add({
                                    'category': defaultC,
                                    'controller': TextEditingController(),
                                  });
                                });
                              },
                              icon: Icon(
                                LucideIcons.plusCircle,
                                size: 16,
                                color: SoftAddTone.primary(context),
                              ),
                              label: Text(
                                'Add Split Row',
                                style: SoftAddTone.text(
                                  context,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: SoftAddTone.primary(context),
                                ),
                              ),
                            ),
                          ],

                          // Purpose + Category Rows
                          if (_splitExpenseMode == 'both') ...[
                            ..._bothSplitRows.asMap().entries.map((entry) {
                              final idx = entry.key;
                              final row = entry.value;
                              final ctrl =
                                  row['controller'] as TextEditingController;
                              final expCats =
                                  ref.watch(categoryProvider).expense;
                              return Padding(
                                padding: const EdgeInsets.only(bottom: 8),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    // Dropdowns stacked vertically to prevent overflow
                                    Expanded(
                                      child: Column(
                                        children: [
                                          DropdownButtonFormField<String>(
                                            isExpanded: true,
                                            initialValue:
                                                purposes.contains(
                                                      row['purpose'],
                                                    )
                                                    ? row['purpose'] as String
                                                    : (purposes.isNotEmpty
                                                        ? purposes.first
                                                        : null),
                                            items:
                                                purposes
                                                    .map(
                                                      (p) => DropdownMenuItem(
                                                        value: p,
                                                        child: Text(
                                                          p,
                                                          overflow:
                                                              TextOverflow
                                                                  .ellipsis,
                                                          style:
                                                              const TextStyle(
                                                                fontSize: 12,
                                                              ),
                                                        ),
                                                      ),
                                                    )
                                                    .toList(),
                                            onChanged:
                                                (v) => setState(
                                                  () =>
                                                      row['purpose'] = v ?? '',
                                                ),
                                            decoration: InputDecoration(
                                              hintText: 'Purpose',
                                              isDense: true,
                                              contentPadding:
                                                  const EdgeInsets.symmetric(
                                                    horizontal: 8,
                                                    vertical: 8,
                                                  ),
                                              border: OutlineInputBorder(
                                                borderRadius:
                                                    BorderRadius.circular(12),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(height: 6),
                                          DropdownButtonFormField<String>(
                                            isExpanded: true,
                                            initialValue:
                                                expCats.contains(
                                                      row['category'],
                                                    )
                                                    ? row['category'] as String
                                                    : (expCats.isNotEmpty
                                                        ? expCats.first
                                                        : null),
                                            items:
                                                expCats
                                                    .map(
                                                      (c) => DropdownMenuItem(
                                                        value: c,
                                                        child: Text(
                                                          c,
                                                          overflow:
                                                              TextOverflow
                                                                  .ellipsis,
                                                          style:
                                                              const TextStyle(
                                                                fontSize: 12,
                                                              ),
                                                        ),
                                                      ),
                                                    )
                                                    .toList(),
                                            onChanged:
                                                (v) => setState(
                                                  () =>
                                                      row['category'] = v ?? '',
                                                ),
                                            decoration: InputDecoration(
                                              hintText: 'Category',
                                              isDense: true,
                                              contentPadding:
                                                  const EdgeInsets.symmetric(
                                                    horizontal: 8,
                                                    vertical: 8,
                                                  ),
                                              border: OutlineInputBorder(
                                                borderRadius:
                                                    BorderRadius.circular(12),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    // Amount + delete column on the right
                                    Column(
                                      children: [
                                        SizedBox(
                                          width: 80,
                                          child: TextFormField(
                                            controller: ctrl,
                                            keyboardType: TextInputType.number,
                                            textAlign: TextAlign.right,
                                            onChanged: (_) => setState(() {}),
                                            decoration: InputDecoration(
                                              hintText: '0',
                                              prefixText: '₹',
                                              isDense: true,
                                              contentPadding:
                                                  const EdgeInsets.symmetric(
                                                    horizontal: 8,
                                                    vertical: 8,
                                                  ),
                                              border: OutlineInputBorder(
                                                borderRadius:
                                                    BorderRadius.circular(12),
                                              ),
                                            ),
                                          ),
                                        ),
                                        if (_bothSplitRows.length > 2)
                                          IconButton(
                                            padding: EdgeInsets.zero,
                                            constraints: const BoxConstraints(
                                              minWidth: 32,
                                              minHeight: 32,
                                            ),
                                            icon: Icon(
                                              LucideIcons.trash2,
                                              size: 16,
                                              color: SoftAddTone.error(context),
                                            ),
                                            onPressed: () {
                                              setState(() {
                                                ctrl.dispose();
                                                _bothSplitRows.removeAt(idx);
                                              });
                                            },
                                          ),
                                      ],
                                    ),
                                  ],
                                ),
                              );
                            }),
                            OutlinedButton.icon(
                              // Secondary button rule (white + ink + outline).
                              style: OutlinedButton.styleFrom(
                                foregroundColor: SoftColors.secondaryFg(
                                  context,
                                ),
                                backgroundColor: SoftColors.secondaryBg(
                                  context,
                                ),
                                side: BorderSide(
                                  color: SoftColors.secondaryOutline(context),
                                ),
                                minimumSize: const Size.fromHeight(40),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              onPressed: () {
                                setState(() {
                                  final defaultP =
                                      purposes.isNotEmpty
                                          ? purposes.first
                                          : 'Personal';
                                  final expCats =
                                      ref.read(categoryProvider).expense;
                                  final defaultC =
                                      expCats.isNotEmpty
                                          ? expCats.first
                                          : 'Food & Dining';
                                  _bothSplitRows.add({
                                    'purpose': defaultP,
                                    'category': defaultC,
                                    'controller': TextEditingController(),
                                  });
                                });
                              },
                              icon: Icon(
                                LucideIcons.plusCircle,
                                size: 16,
                                color: SoftAddTone.primary(context),
                              ),
                              label: Text(
                                'Add Split Row',
                                style: SoftAddTone.text(
                                  context,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: SoftAddTone.primary(context),
                                ),
                              ),
                            ),
                          ],

                          if (_hasDuplicateKeys) ...[
                            const SizedBox(height: 4),
                            Text(
                              'Two rows use the same combination — combine them into one row.',
                              style: TextStyle(
                                fontSize: 12,
                                color: SoftAddTone.error(context),
                              ),
                            ),
                          ],

                          const SizedBox(height: 6),
                          _SplitAllocationStatus(
                            allocated: _allocatedSplitExpenseTotal,
                            total: _enteredAmount,
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                ],

                // ── Split with Friends Switch & Roster ──
                if (_typeIndex == 0 && !_isTripMode) ...[
                  Opacity(
                    opacity: _splitExpenseEnabled ? 0.9 : 1,
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: SoftAddTone.cardBox(context),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                LucideIcons.users,
                                size: 18,
                                color: activeColor,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Split with Friends',
                                      style: TextStyle(
                                        fontWeight: FontWeight.w600,
                                        fontSize: 14,
                                        color: SoftAddTone.ink(context),
                                      ),
                                    ),
                                    Text(
                                      _splitExpenseEnabled
                                          ? 'Inactive while Split Expense is toggled'
                                          : 'Off = just you.',
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: SoftAddTone.secondary(context),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SoftAddSwitch(
                                value: _friendSplitEnabled,
                                onChanged: _handleToggleFriendSplit,
                              ),
                            ],
                          ),

                          if (_friendSplitEnabled) ...[
                            const SizedBox(height: 12),
                            if (friendsList.isEmpty)
                              Text(
                                'No friends added yet — add one from Friends first.',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: SoftAddTone.secondary(context),
                                ),
                              )
                            else
                              Wrap(
                                spacing: 8,
                                runSpacing: 8,
                                children:
                                    friendsList.map((f) {
                                      final isSel = _selectedFriendNames
                                          .contains(f.name);
                                      return FilterChip(
                                        label: Text(f.name),
                                        selected: isSel,
                                        onSelected: (selected) {
                                          setState(() {
                                            if (selected) {
                                              _selectedFriendNames.add(f.name);
                                              _friendCustomSplitControllers
                                                  .putIfAbsent(
                                                    f.name,
                                                    () =>
                                                        TextEditingController(),
                                                  );
                                            } else {
                                              _selectedFriendNames.remove(
                                                f.name,
                                              );
                                            }
                                          });
                                        },
                                        selectedColor: SoftColors.control,
                                        checkmarkColor: Colors.white,
                                      );
                                    }).toList(),
                              ),
                            if (_selectedFriendNames.isNotEmpty) ...[
                              const SizedBox(height: 12),
                              Row(
                                children: [
                                  _ChipTab(
                                    label: 'Equal',
                                    icon: LucideIcons.users,
                                    isSelected:
                                        _friendSplitType == SplitType.equally,
                                    color: activeColor,
                                    onTap:
                                        () => setState(
                                          () =>
                                              _friendSplitType =
                                                  SplitType.equally,
                                        ),
                                  ),
                                  const SizedBox(width: 8),
                                  _ChipTab(
                                    label: 'Custom',
                                    icon: LucideIcons.calculator,
                                    isSelected:
                                        _friendSplitType == SplitType.custom,
                                    color: activeColor,
                                    onTap:
                                        () => setState(() {
                                          _friendSplitType = SplitType.custom;
                                          _friendCustomSplitControllers
                                              .putIfAbsent(
                                                'You',
                                                () => TextEditingController(),
                                              );
                                        }),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 10),
                              if (_friendSplitType == SplitType.equally) ...[
                                Text(
                                  'Split equally across you + ${_selectedFriendNames.length} friend${_selectedFriendNames.length == 1 ? "" : "s"} — each pays ₹${(_selectedFriendNames.isEmpty ? 0 : _enteredAmount / (_selectedFriendNames.length + 1)).toStringAsFixed(0)}.',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: SoftAddTone.secondary(context),
                                  ),
                                ),
                              ] else ...[
                                ...['You', ..._selectedFriendNames].map((name) {
                                  final ctrl = _friendCustomSplitControllers
                                      .putIfAbsent(
                                        name,
                                        () => TextEditingController(),
                                      );
                                  return Padding(
                                    padding: const EdgeInsets.only(bottom: 6),
                                    child: Row(
                                      children: [
                                        Expanded(
                                          child: Text(
                                            name,
                                            style: const TextStyle(
                                              fontSize: 13,
                                            ),
                                          ),
                                        ),
                                        SizedBox(
                                          width: 90,
                                          child: TextFormField(
                                            controller: ctrl,
                                            keyboardType: TextInputType.number,
                                            textAlign: TextAlign.right,
                                            onChanged: (_) => setState(() {}),
                                            decoration: InputDecoration(
                                              hintText: '0',
                                              prefixText: '₹',
                                              isDense: true,
                                              contentPadding:
                                                  const EdgeInsets.symmetric(
                                                    horizontal: 10,
                                                    vertical: 8,
                                                  ),
                                              border: OutlineInputBorder(
                                                borderRadius:
                                                    BorderRadius.circular(12),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                }),
                                const SizedBox(height: 4),
                                Text(
                                  'Allocated ₹${_allocatedFriendSplitTotal.toStringAsFixed(0)} / ₹${_enteredAmount.toStringAsFixed(0)}',
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                    color:
                                        _isFriendSplitValid
                                            ? SoftAddTone.brand(context)
                                            : SoftAddTone.error(context),
                                  ),
                                ),
                              ],
                            ],
                          ],
                          if (!_friendSplitEnabled &&
                              friendsList.isNotEmpty) ...[
                            const SizedBox(height: 12),
                            Row(
                              children: [
                                Expanded(
                                  child: _ChipTab(
                                    label: 'Equal',
                                    icon: LucideIcons.users,
                                    isSelected: true,
                                    color: activeColor,
                                    onTap: () => _handleToggleFriendSplit(true),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: _ChipTab(
                                    label: 'Custom',
                                    icon: LucideIcons.calculator,
                                    isSelected: false,
                                    color: activeColor,
                                    onTap: () {
                                      _handleToggleFriendSplit(true);
                                      setState(
                                        () =>
                                            _friendSplitType = SplitType.custom,
                                      );
                                    },
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children:
                                  friendsList.take(3).map((friend) {
                                    return Container(
                                      width: 92,
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 9,
                                        vertical: 8,
                                      ),
                                      decoration: BoxDecoration(
                                        color: SoftAddTone.canvas(context),
                                        borderRadius: BorderRadius.circular(11),
                                        border: Border.all(color: quietBorder),
                                      ),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            friend.name,
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: const TextStyle(
                                              fontSize: 11,
                                              fontWeight: FontWeight.w700,
                                            ),
                                          ),
                                          const SizedBox(height: 3),
                                          Text(
                                            'Equal share',
                                            style: TextStyle(
                                              fontSize: 10,
                                              color: SoftAddTone.secondary(
                                                context,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    );
                                  }).toList(),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                ],

                // ── Past Transaction Switch ──
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: SoftAddTone.cardBox(context),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Past transaction',
                                  style: SoftAddTone.text(
                                    context,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  'Record an expenditure from earlier',
                                  style: SoftAddTone.text(
                                    context,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w500,
                                    color: SoftAddTone.secondary(context),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SoftAddSwitch(
                            value: _isPastTransaction,
                            onChanged: (v) {
                              setState(() {
                                _isPastTransaction = v;
                                if (v) {
                                  final now = DateTime.now();
                                  _selectedDate = DateTime(
                                    now.year,
                                    now.month,
                                    now.day,
                                  );
                                  _selectedTime = TimeOfDay.fromDateTime(now);
                                }
                              });
                            },
                          ),
                        ],
                      ),
                      if (_isPastTransaction) ...[
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  _FormLabel(label: 'DATE'),
                                  const SizedBox(height: 6),
                                  Material(
                                    color: SoftAddTone.canvas(context),
                                    borderRadius: BorderRadius.circular(12),
                                    child: InkWell(
                                      onTap: _pickDate,
                                      borderRadius: BorderRadius.circular(12),
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 10,
                                          vertical: 12,
                                        ),
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(
                                            12,
                                          ),
                                          border: Border.all(
                                            color: quietBorder,
                                          ),
                                        ),
                                        child: Row(
                                          children: [
                                            Icon(
                                              LucideIcons.calendar,
                                              size: 18,
                                              color: SoftAddTone.primary(
                                                context,
                                              ),
                                            ),
                                            const SizedBox(width: 8),
                                            Expanded(
                                              child: Text(
                                                DateFormat(
                                                  'd MMM yyyy',
                                                ).format(_selectedDate),
                                                style: SoftAddTone.text(
                                                  context,
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w700,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  _FormLabel(label: 'TIME'),
                                  const SizedBox(height: 6),
                                  Material(
                                    color: SoftAddTone.canvas(context),
                                    borderRadius: BorderRadius.circular(12),
                                    child: InkWell(
                                      onTap: _pickTime,
                                      borderRadius: BorderRadius.circular(12),
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 10,
                                          vertical: 12,
                                        ),
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(
                                            12,
                                          ),
                                          border: Border.all(
                                            color: quietBorder,
                                          ),
                                        ),
                                        child: Row(
                                          children: [
                                            Icon(
                                              LucideIcons.clock,
                                              size: 18,
                                              color: SoftAddTone.primary(
                                                context,
                                              ),
                                            ),
                                            const SizedBox(width: 8),
                                            Expanded(
                                              child: Text(
                                                _selectedTime.format(context),
                                                style: SoftAddTone.text(
                                                  context,
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w700,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // ── Description ──
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: SoftAddTone.cardBox(context),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _FormLabel(label: 'Description (Optional)'),
                      const SizedBox(height: 8),
                      TextFormField(
                        controller: _descriptionController,
                        maxLines: 1,
                        style: const TextStyle(fontWeight: FontWeight.w500),
                        decoration: fieldDecoration('Add brief note').copyWith(
                          prefixIcon: Icon(
                            LucideIcons.fileText,
                            size: 18,
                            color: SoftAddTone.secondary(context),
                          ),
                          prefixIconConstraints: const BoxConstraints(
                            minWidth: 36,
                            minHeight: 40,
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      _FormLabel(label: 'Additional Notes'),
                      const SizedBox(height: 8),
                      TextFormField(
                        controller: _noteController,
                        maxLines: 2,
                        style: const TextStyle(fontWeight: FontWeight.w500),
                        decoration: fieldDecoration(
                          'Mention tag or billing context...',
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // ── Line Items ──
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: SoftAddTone.cardBox(context),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (_itemRows.isNotEmpty) ...[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            _FormLabel(
                              label: 'Purchased Items (${_itemRows.length})',
                            ),
                            TextButton.icon(
                              onPressed: _showAddItemDialog,
                              icon: const Icon(LucideIcons.plus, size: 14),
                              label: const Text(
                                'Add item',
                                style: TextStyle(fontSize: 12),
                              ),
                              style: TextButton.styleFrom(
                                visualDensity: VisualDensity.compact,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        ..._itemRows.asMap().entries.map((entry) {
                          final idx = entry.key;
                          final itm = entry.value;
                          return Container(
                            margin: const EdgeInsets.only(bottom: 6),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 8,
                            ),
                            decoration: BoxDecoration(
                              color: SoftAddTone.canvas(context),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        itm.name,
                                        style: const TextStyle(
                                          fontSize: 13,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                      if (itm.categoryId.isNotEmpty)
                                        Text(
                                          itm.categoryId,
                                          style: TextStyle(
                                            fontSize: 11,
                                            color: SoftAddTone.secondary(
                                              context,
                                            ),
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                                Text(
                                  '₹${itm.amount.toStringAsFixed(0)}',
                                  style: const TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                GestureDetector(
                                  onTap:
                                      () => setState(
                                        () => _itemRows.removeAt(idx),
                                      ),
                                  child: Icon(
                                    LucideIcons.trash2,
                                    size: 16,
                                    color: SoftAddTone.error(context),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }),
                      ] else ...[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            _FormLabel(label: 'Purchased Items'),
                            TextButton.icon(
                              onPressed: _showAddItemDialog,
                              icon: const Icon(LucideIcons.plus, size: 14),
                              label: const Text(
                                'Add item',
                                style: TextStyle(fontSize: 12),
                              ),
                              style: TextButton.styleFrom(
                                visualDensity: VisualDensity.compact,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(height: 24),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      LucideIcons.shieldCheck,
                      size: 13,
                      color: SoftAddTone.brand(context),
                    ),
                    const SizedBox(width: 5),
                    Text(
                      'SMS Ledger Verified · Auto-synced with Trip Ledger',
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w500,
                        color: SoftAddTone.secondary(context),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                // ── Action Footer ──
                if (isEditingExistingTransfer) ...[
                  Text(
                    "Transfers can't be edited yet — delete and recreate.",
                    style: TextStyle(
                      fontSize: 12,
                      color: SoftAddTone.secondary(context),
                    ),
                  ),
                  const SizedBox(height: 12),
                ],
                SoftAddSaveButton(
                  label:
                      widget.initialTransaction != null ||
                              widget.initialExpense != null
                          ? 'Update'
                          : (_isTripMode
                              ? 'Save Outing Expense'
                              : (_typeIndex == 0
                                  ? 'Save Expense'
                                  : (_typeIndex == 1
                                      ? 'Save Income'
                                      : 'Transfer'))),
                  amount: '₹${_formatMoney(_enteredAmount)}',
                  onPressed:
                      (_saving ||
                              !_isTripFormValid ||
                              !_isSplitExpenseValid ||
                              !_isFriendSplitValid ||
                              isEditingExistingTransfer)
                          ? null
                          : _save,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Remaining/exceeded/fully-allocated indicator for purpose, category, and
/// purpose+category splits — replaces a hard validation error with a running
/// total so the user always knows how much is left without being interrupted.
class _SplitAllocationStatus extends StatelessWidget {
  final double allocated;
  final double total;

  const _SplitAllocationStatus({required this.allocated, required this.total});

  @override
  Widget build(BuildContext context) {
    final remaining = total - allocated;
    final matched = remaining.abs() < 0.01;
    final ratio = total <= 0 ? 0.0 : (allocated / total).clamp(0.0, 1.0);
    final exceeded = remaining < 0;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                'Allocation Fulfillment',
                style: SoftAddTone.text(
                  context,
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: SoftAddTone.secondary(context),
                ),
              ),
            ),
            Text(
              matched
                  ? '100% matched (₹${total.toStringAsFixed(0)})'
                  : (exceeded
                      ? 'Exceeded by ₹${remaining.abs().toStringAsFixed(0)}'
                      : 'Remaining ₹${remaining.toStringAsFixed(0)}'),
              style: SoftAddTone.text(
                context,
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color:
                    matched
                        ? SoftAddTone.brand(context)
                        : (exceeded
                            ? SoftAddTone.error(context)
                            : SoftAddTone.secondary(context)),
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(999),
          child: LinearProgressIndicator(
            value: ratio,
            minHeight: 8,
            backgroundColor: SoftAddTone.canvas(context),
            color:
                matched
                    ? SoftAddTone.emerald(context)
                    : SoftAddTone.primary(context),
          ),
        ),
        if (matched) ...[
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            decoration: BoxDecoration(
              color: SoftAddTone.mintSubtle(context),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: SoftAddTone.brand(context).withValues(alpha: 0.35),
              ),
            ),
            child: Row(
              children: [
                Icon(
                  LucideIcons.badgeCheck,
                  size: 16,
                  color: SoftAddTone.brand(context),
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    'Split matches total',
                    style: SoftAddTone.text(
                      context,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: SoftAddTone.primary(context),
                    ),
                  ),
                ),
                Text(
                  'Total ₹${total.toStringAsFixed(0)}',
                  style: SoftAddTone.text(
                    context,
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }
}

class _ChipTab extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool isSelected;
  final Color color;
  final VoidCallback onTap;

  const _ChipTab({
    required this.label,
    required this.icon,
    required this.isSelected,
    this.color = const Color(0xFF006C49),
    required this.onTap,
    this.showIcon = true,
    this.expand = false,
  });

  final bool showIcon;
  final bool expand;

  @override
  Widget build(BuildContext context) {
    final muted = SoftAddTone.secondary(context);
    final row = Row(
      mainAxisAlignment: MainAxisAlignment.center,
      mainAxisSize: expand ? MainAxisSize.max : MainAxisSize.min,
      children: [
        if (showIcon) ...[
          Icon(icon, size: 14, color: isSelected ? color : muted),
          const SizedBox(width: 6),
        ],
        if (expand)
          Flexible(
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: SoftAddTone.text(
                context,
                fontSize: 12,
                fontWeight: isSelected ? FontWeight.w800 : FontWeight.w600,
                color: isSelected ? SoftAddTone.primary(context) : muted,
              ),
            ),
          )
        else
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: SoftAddTone.text(
              context,
              fontSize: 12,
              fontWeight: isSelected ? FontWeight.w800 : FontWeight.w600,
              color: isSelected ? SoftAddTone.primary(context) : muted,
            ),
          ),
      ],
    );
    return AnimatedTapCard(
      onTap: onTap,
      scaleDown: 0.96,
      child: Container(
        width: expand ? double.infinity : null,
        padding: EdgeInsets.symmetric(
          horizontal: showIcon ? 12 : 4,
          vertical: 8,
        ),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: isSelected ? SoftAddTone.card(context) : Colors.transparent,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color:
                isSelected ? SoftAddTone.border(context) : Colors.transparent,
          ),
          boxShadow: isSelected ? SoftAddTone.cardShadowOf(context) : null,
        ),
        child: row,
      ),
    );
  }
}

class _FormLabel extends StatelessWidget {
  final String label;
  const _FormLabel({required this.label});
  @override
  Widget build(BuildContext context) => Text(
    label,
    style: SoftAddTone.text(
      context,
      fontSize: 12,
      fontWeight: FontWeight.w700,
      color: SoftAddTone.secondary(context),
    ),
  );
}

class _HorizontalSelector extends StatelessWidget {
  final double height;
  final List<_SelectorItem> items;
  const _HorizontalSelector({required this.height, required this.items});
  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: SoftAddTone.canvas(context),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: SoftAddTone.border(context)),
      ),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        itemCount: items.length,
        itemBuilder: (context, i) => items[i],
      ),
    );
  }
}

class _SelectorItem extends StatelessWidget {
  final String label, id;
  final IconData icon;
  final bool isSelected;
  final VoidCallback? onTap;
  final Color color;
  const _SelectorItem({
    required this.label,
    required this.id,
    required this.icon,
    required this.isSelected,
    required this.onTap,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedTapCard(
      key: ValueKey(id),
      onTap: onTap,
      scaleDown: 0.93,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOutCubic,
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.symmetric(horizontal: 12),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: isSelected ? SoftAddTone.card(context) : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color:
                isSelected ? SoftAddTone.border(context) : Colors.transparent,
          ),
          boxShadow: isSelected ? SoftAddTone.cardShadowOf(context) : null,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              size: 14,
              color: isSelected ? color : SoftAddTone.secondary(context),
            ),
            const SizedBox(width: 8),
            Text(
              label,
              style: SoftAddTone.text(
                context,
                fontSize: 13,
                fontWeight: isSelected ? FontWeight.w800 : FontWeight.w600,
                color:
                    isSelected
                        ? SoftAddTone.primary(context)
                        : SoftAddTone.ink(context),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
