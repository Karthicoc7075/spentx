import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/transaction_provider.dart' as model;
import 'add_transaction_sheet.dart';

/// Edit form for a saved transaction (opened from Transaction Details).
/// Uses the unified responsive [AddTransactionSheet] to provide identical layout,
/// fields, validation rules, and conversion capabilities (Normal ↔ Split Expense ↔ Friend Split).
class EditTransactionSheet {
  EditTransactionSheet._();

  static Future<void> show(
    BuildContext context,
    WidgetRef ref,
    model.Transaction tx,
  ) {
    return AddTransactionSheet.show(
      context,
      initialTransaction: tx,
    );
  }
}