import 'package:flutter/material.dart';
import '../../../core/theme/spentx_tokens.dart';
import '../../../core/theme/soft_palette.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:go_router/go_router.dart';
import '../../../core/theme/app_colors.dart';
import '../data/transaction_provider.dart' as model;
import '../../../core/providers/category_provider.dart';
import '../../../core/widgets/premium_bottom_sheet.dart';
import '../../../core/providers/outing_provider.dart';
import '../../../core/utils/outing_link_rules.dart';

import '../../groups/presentation/widgets/outing_unlink_dialog.dart';
import 'edit_transaction_sheet.dart';
import '../../../core/utils/transaction_display_utils.dart';
import '../../../core/providers/private_mode_provider.dart';
import '../../../core/widgets/animated_tap_card.dart';

const _softMuted = Color(0xFF63738C);
const _softInk = SoftPalette.ink;
const _softDelete = Color(0xFFDB2626);
const _softCardShadow = [
  BoxShadow(color: Color(0x0F050D1A), blurRadius: 24, offset: Offset(0, 8)),
];

String _formatDetailAmount(double value) {
  final intPart = value.truncate();
  final str = intPart.toString();
  if (str.length <= 3) return '₹$str';
  final lastThree = str.substring(str.length - 3);
  var remaining = str.substring(0, str.length - 3);
  remaining = remaining.replaceAllMapped(
    RegExp(r'\B(?=(\d{2})+(?!\d))'),
    (m) => '${m[0]},',
  );
  return '₹$remaining,$lastThree';
}

/// Soft Soft detail timestamp: "Today · 2:14 PM".
String _formatSoftDetailDateTime(DateTime date) {
  final local = date.toLocal();
  final now = DateTime.now();
  final today = DateTime(now.year, now.month, now.day);
  final day = DateTime(local.year, local.month, local.day);
  final time = TimeOfDay.fromDateTime(local);
  final hour = time.hourOfPeriod == 0 ? 12 : time.hourOfPeriod;
  final minute = time.minute.toString().padLeft(2, '0');
  final period = time.period == DayPeriod.am ? 'AM' : 'PM';
  final timeLabel = '$hour:$minute $period';
  if (day == today) return 'Today · $timeLabel';
  if (day == today.subtract(const Duration(days: 1))) {
    return 'Yesterday · $timeLabel';
  }
  const months = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];
  final dateLabel =
      local.year == now.year
          ? '${local.day.toString().padLeft(2, '0')} ${months[local.month - 1]}'
          : '${local.day.toString().padLeft(2, '0')} ${months[local.month - 1]} ${local.year}';
  return '$dateLabel · $timeLabel';
}

class TransactionDetailScreen extends ConsumerWidget {
  final String? id;
  final String? outingId;
  final String? expenseId;

  const TransactionDetailScreen({
    super.key,
    this.id,
    this.outingId,
    this.expenseId,
  });

  void _showOutingDeleteDialog(
    BuildContext context,
    WidgetRef ref,
    String oId,
    String eId,
  ) {
    showDialog(
      context: context,
      builder:
          (ctx) => AlertDialog(
            backgroundColor: ctx.softSurface,
            surfaceTintColor: Colors.transparent,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24),
            ),
            title: Text(
              'Delete Trip Expense?',
              style: TextStyle(color: ctx.softInk, fontWeight: FontWeight.w700),
            ),
            content: Text(
              'This will remove this item from the outing activity.',
              style: TextStyle(color: ctx.softMuted, height: 1.45),
            ),
            actionsPadding: const EdgeInsets.fromLTRB(20, 0, 20, 18),
            actions: [
              TextButton(
                style: TextButton.styleFrom(foregroundColor: ctx.softMuted),
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Cancel'),
              ),
              TextButton(
                style: TextButton.styleFrom(
                  foregroundColor: ctx.softEmerald,
                  textStyle: const TextStyle(fontWeight: FontWeight.w700),
                ),
                onPressed: () {
                  final outing =
                      ref
                          .read(outingProvider)
                          .where((o) => o.id == oId)
                          .firstOrNull;
                  final expense =
                      outing?.expenses.where((e) => e.id == eId).firstOrNull;
                  if (outing == null || expense == null) {
                    // Removed by a sync while the dialog was open.
                    Navigator.of(ctx).pop();
                    return;
                  }

                  // Unlink from transaction provider if linked
                  if (expense.transactionId != null) {
                    final txs = ref.read(model.transactionProvider);
                    final tx =
                        txs
                            .where((t) => t.id == expense.transactionId)
                            .firstOrNull;
                    if (tx != null) {
                      ref
                          .read(model.transactionProvider.notifier)
                          .updateTransaction(tx.copyWith(outingId: null));
                    }
                  }

                  ref.read(outingProvider.notifier).deleteExpense(oId, eId);
                  Navigator.pop(ctx);
                  context.pop();
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Trip expense deleted & unlinked'),
                      backgroundColor: AppColors.expense,
                    ),
                  );
                },
                child: const Text('Delete'),
              ),
            ],
          ),
    );
  }

  void _showOutingEditSheet(
    BuildContext context,
    WidgetRef ref,
    String oId,
    OutingExpense expense,
  ) {
    final titleCtrl = TextEditingController(text: expense.title);
    final amountCtrl = TextEditingController(
      text: expense.amount.toInt().toString(),
    );

    String category = expense.category;
    String paymentMode = expense.paymentMode;
    String? accountId = expense.accountId;
    SplitType splitType = expense.splitType;
    List<String> memberIds = List.from(expense.memberIds);

    PremiumBottomSheet.show(
      context: context,
      child: StatefulBuilder(
        builder: (context, setModalState) {
          final outing =
              ref.watch(outingProvider).where((o) => o.id == oId).firstOrNull;
          final tripCategories = ref.watch(categoryProvider).expense;
          final hasFriends =
              outing?.members.any((m) => m.name.toLowerCase() != 'you') ??
              false;

          return Padding(
            padding: const EdgeInsets.fromLTRB(24, 8, 24, 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'EDIT TRIP EXPENSE',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                    color: Colors.grey,
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  expense.title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 24),
                const Text(
                  'TITLE',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                    color: Colors.grey,
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: titleCtrl,
                  textCapitalization: TextCapitalization.sentences,
                  decoration: const InputDecoration(
                    hintText: 'What was this for?',
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  'AMOUNT',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                    color: Colors.grey,
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: amountCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    prefixText: '₹ ',
                    hintText: '0',
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  'CATEGORY',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                    color: Colors.grey,
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 10),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  physics: const BouncingScrollPhysics(),
                  child: Row(
                    children:
                        tripCategories.map((cat) {
                          final isSelected = category == cat;
                          return Padding(
                            padding: const EdgeInsets.only(right: 8),
                            child: FilterChip(
                              label: Text(cat),
                              selected: isSelected,
                              onSelected:
                                  (_) => setModalState(() => category = cat),
                            ),
                          );
                        }).toList(),
                  ),
                ),
                if (hasFriends) ...[
                  const SizedBox(height: 20),
                  const Text(
                    'SPLIT',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      color: Colors.grey,
                      letterSpacing: 1.2,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: _ChoiceButton(
                          label: 'Solo',
                          icon: LucideIcons.user,
                          isSelected: splitType == SplitType.solo,
                          onTap:
                              () => setModalState(() {
                                splitType = SplitType.solo;
                                memberIds = ['you'];
                              }),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _ChoiceButton(
                          label: 'Split',
                          icon: LucideIcons.users,
                          isSelected: splitType == SplitType.equally,
                          onTap:
                              () => setModalState(() {
                                splitType = SplitType.equally;
                                if (outing != null && memberIds.length <= 1) {
                                  memberIds = [
                                    for (final m in outing.members)
                                      m.name.toLowerCase() == 'you'
                                          ? 'you'
                                          : m.id,
                                  ];
                                }
                              }),
                        ),
                      ),
                    ],
                  ),
                  if (splitType == SplitType.equally && outing != null) ...[
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children:
                          outing.members.map((m) {
                            final mId =
                                m.name.toLowerCase() == 'you' ? 'you' : m.id;
                            final isSelected = memberIds.contains(mId);
                            return FilterChip(
                              label: Text(
                                m.name,
                                style: const TextStyle(fontSize: 12),
                              ),
                              selected: isSelected,
                              onSelected: (val) {
                                setModalState(() {
                                  if (val) {
                                    memberIds.add(mId);
                                  } else if (memberIds.length > 1) {
                                    memberIds.remove(mId);
                                  }
                                });
                              },
                            );
                          }).toList(),
                    ),
                  ],
                ],
                const SizedBox(height: 20),
                const Text(
                  'PAYMENT',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                    color: Colors.grey,
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: _ChoiceButton(
                        label: 'Cash',
                        icon: LucideIcons.banknote,
                        isSelected: paymentMode == 'Cash',
                        onTap: () => setModalState(() => paymentMode = 'Cash'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _ChoiceButton(
                        label: 'Online',
                        icon: LucideIcons.smartphone,
                        isSelected: paymentMode == 'Online',
                        onTap:
                            () => setModalState(() {
                              paymentMode = 'Online';
                              accountId = accountId ?? 'Personal';
                            }),
                      ),
                    ),
                  ],
                ),
                if (paymentMode == 'Online') ...[
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: _ChoiceButton(
                          label: 'Personal',
                          isSelected: accountId == 'Personal',
                          onTap:
                              () => setModalState(() => accountId = 'Personal'),
                          icon: LucideIcons.user,
                        ),
                      ),
                    ],
                  ),
                ],
                const SizedBox(height: 28),
                SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: ElevatedButton(
                    onPressed: () {
                      final resolvedMembers =
                          splitType == SplitType.solo ? ['you'] : memberIds;
                      final updated = OutingExpense(
                        id: expense.id,
                        title:
                            titleCtrl.text.trim().isEmpty
                                ? expense.title
                                : titleCtrl.text.trim(),
                        amount:
                            double.tryParse(amountCtrl.text) ?? expense.amount,
                        category: category,
                        date: expense.date,
                        memberIds: resolvedMembers,
                        splitType: splitType,
                        paymentMode: paymentMode,
                        accountId: paymentMode == 'Online' ? accountId : null,
                        transactionId: expense.transactionId,
                        purpose: expense.purpose,
                        settledMemberIds: expense.settledMemberIds,
                        settledModes: expense.settledModes,
                        // Everything this sheet does not edit must survive it —
                        // correcting a wrongly detected merchant is a rename,
                        // not a re-split. Rebuilding the row without these
                        // dropped the payer (a friend's bill silently became
                        // yours), any per-member custom amounts, part-payments
                        // already recorded, and a web-authored split payload.
                        paidByMemberId: expense.paidByMemberId,
                        settlementPayments: expense.settlementPayments,
                        customSplitAmounts:
                            splitType == expense.splitType
                                ? expense.customSplitAmounts
                                : null,
                        remoteSplitType: expense.remoteSplitType,
                        remoteSplits: expense.remoteSplits,
                      );
                      ref
                          .read(outingProvider.notifier)
                          .updateExpense(oId, updated);

                      if (expense.transactionId != null) {
                        final txs = ref.read(model.transactionProvider);
                        final tx =
                            txs
                                .where((t) => t.id == expense.transactionId)
                                .firstOrNull;
                        if (tx != null) {
                          ref
                              .read(model.transactionProvider.notifier)
                              .updateTransaction(
                                tx.copyWith(
                                  merchant: updated.title,
                                  amount: updated.amount,
                                  category: updated.category,
                                  paymentType: updated.paymentMode,
                                  account: updated.accountId ?? tx.account,
                                ),
                              );
                        }
                      }

                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Trip expense updated'),
                          backgroundColor: AppColors.income,
                        ),
                      );
                    },
                    child: const Text(
                      'Save Changes',
                      style: TextStyle(fontWeight: FontWeight.w500),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  void _openEditForItem(
    BuildContext context,
    WidgetRef ref, {
    required bool isOutingExpense,
    required dynamic item,
    String? outingId,
  }) {
    if (isOutingExpense) {
      _showOutingEditSheet(context, ref, outingId!, item as OutingExpense);
      return;
    }
    final tx = item as model.Transaction;
    if (tx.outingId != null) {
      final expense = ref
          .read(outingProvider.notifier)
          .expenseForTransaction(tx.outingId!, tx.id);
      if (expense != null) {
        _showOutingEditSheet(context, ref, tx.outingId!, expense);
        return;
      }
    }
    _showEditSheet(context, ref, tx);
  }

  void _showDeleteDialog(
    BuildContext context,
    WidgetRef ref,
    model.Transaction tx,
  ) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder:
          (dialogContext) => AlertDialog(
            backgroundColor: dialogContext.softSurface,
            surfaceTintColor: Colors.transparent,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24),
            ),
            title: Text(
              'Delete Transaction?',
              style: TextStyle(
                color: dialogContext.softInk,
                fontWeight: FontWeight.w700,
              ),
            ),
            content: Text(
              'This action cannot be undone and will update your balances.',
              style: TextStyle(color: dialogContext.softMuted, height: 1.45),
            ),
            actionsPadding: const EdgeInsets.fromLTRB(20, 0, 20, 18),
            actions: [
              TextButton(
                style: TextButton.styleFrom(
                  foregroundColor: dialogContext.softMuted,
                ),
                onPressed: () => Navigator.of(dialogContext).pop(),
                child: const Text('Cancel'),
              ),
              TextButton(
                style: TextButton.styleFrom(
                  foregroundColor: dialogContext.softEmerald,
                  textStyle: const TextStyle(fontWeight: FontWeight.w700),
                ),
                onPressed: () async {
                  final messenger = ScaffoldMessenger.maybeOf(context);
                  ref
                      .read(model.transactionProvider.notifier)
                      .removeTransaction(tx.id);
                  Navigator.of(dialogContext).pop();
                  if (context.mounted) {
                    context.pop();
                  }
                  Future.delayed(const Duration(milliseconds: 100), () {
                    messenger?.showSnackBar(
                      const SnackBar(
                        content: Text('Transaction deleted successfully'),
                        behavior: SnackBarBehavior.floating,
                      ),
                    );
                  });
                },
                child: const Text('Delete'),
              ),
            ],
          ),
    );
  }

  void _showEditSheet(
    BuildContext context,
    WidgetRef ref,
    model.Transaction tx,
  ) {
    EditTransactionSheet.show(context, ref, tx);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    dynamic item;
    bool isOutingExpense = false;

    if (id != null) {
      final transactions = ref.watch(model.transactionProvider);
      item = transactions.where((t) => t.id == id).firstOrNull;
      if (item == null) {
        final outings = ref.watch(outingProvider);
        for (final o in outings) {
          final exp = o.expenses.where((e) => e.id == id).firstOrNull;
          if (exp != null) {
            item = exp;
            isOutingExpense = true;
            break;
          }
        }
      }
    } else if (outingId != null && expenseId != null) {
      final outings = ref.watch(outingProvider);
      final outing = outings.where((o) => o.id == outingId).firstOrNull;
      item = outing?.expenses.where((e) => e.id == expenseId).firstOrNull;
      isOutingExpense = true;
    }

    if (item == null) {
      return Scaffold(
        backgroundColor: SoftPalette.bg,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(LucideIcons.arrowLeft),
            onPressed: () => Navigator.of(context).pop(),
          ),
        ),
        body: const Center(child: Text('Transaction no longer exists')),
      );
    }

    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = isDark ? SoftPalette.darkBg : SoftPalette.bg;
    final card = isDark ? SoftPalette.darkCard : SoftPalette.card;
    final ink = isDark ? SoftPalette.darkInk : _softInk;
    final muted = isDark ? SoftPalette.darkMuted : _softMuted;
    final emerald = isDark ? SoftPalette.darkEmerald : SoftPalette.emerald;
    final emeraldSoft =
        isDark ? SoftPalette.darkEmeraldSoft : SoftPalette.emeraldSoft;

    final String title =
        isOutingExpense
            ? item.title
            : TransactionDisplayUtils.merchantTitle(item as model.Transaction);
    final double amount = item.amount;
    final String category = item.category;
    final DateTime date = item.date;
    final String paymentMode =
        isOutingExpense ? item.paymentMode : item.paymentType;
    final String? account =
        isOutingExpense
            ? (item as OutingExpense).accountId
            : (item as model.Transaction).account;
    final String? purpose =
        isOutingExpense
            ? (item as OutingExpense).purpose
            : (item as model.Transaction).purpose;
    final bool isExpense = isOutingExpense ? true : item.isExpense;
    final bool isTransfer =
        !isOutingExpense && (item as model.Transaction).isTransfer;
    final bool isPrivate = ref.watch(privateModeProvider);

    String accountLabel = '—';
    if (!isOutingExpense) {
      final tx = item as model.Transaction;
      final bank =
          tx.bankName.trim().isNotEmpty
              ? tx.bankName.trim()
              : (tx.account.trim().isNotEmpty ? tx.account.trim() : '');
      final last4 = tx.accountLast4.trim();
      if (bank.isNotEmpty &&
          last4.isNotEmpty &&
          last4.toLowerCase() != 'unknown') {
        accountLabel = '$bank ****$last4';
      } else if (bank.isNotEmpty) {
        accountLabel = bank;
      } else if (account != null &&
          account.isNotEmpty &&
          account.toLowerCase() != 'unknown') {
        accountLabel = account;
      }
    } else if (account != null && account.isNotEmpty) {
      accountLabel = account;
    }

    final purposeLabel =
        (purpose != null &&
                purpose.isNotEmpty &&
                purpose.toLowerCase() != 'unknown')
            ? purpose
            : 'Personal';

    String notesLabel = '—';
    if (!isOutingExpense) {
      final tx = item as model.Transaction;
      final n =
          tx.note.trim().isNotEmpty ? tx.note.trim() : tx.description.trim();
      if (n.isNotEmpty) notesLabel = n;
    }

    String outingLabel = 'Not linked';
    final outings = ref.watch(outingProvider);
    if (!isOutingExpense) {
      final tx = item as model.Transaction;
      if (tx.outingId != null) {
        final o = outings.where((e) => e.id == tx.outingId).firstOrNull;
        if (o != null) outingLabel = o.title;
      }
    } else {
      final o = outings.where((e) => e.id == outingId).firstOrNull;
      outingLabel = o?.title ?? 'Trip expense';
    }

    String? smsPill;
    if (!isOutingExpense) {
      final tx = item as model.Transaction;
      if (tx.isAutoDetected) {
        final bank =
            tx.bankName.trim().isNotEmpty
                ? tx.bankName.trim()
                : (tx.account.trim().isNotEmpty ? tx.account.trim() : 'Bank');
        smsPill = 'Detected from SMS · $bank';
      }
    }

    final amountStr =
        isPrivate
            ? PrivateModeService.mask
            : '${isExpense ? '-' : '+'}${_formatDetailAmount(amount)}';

    String subtitleExtra = '';
    if (!isOutingExpense) {
      final extraTitle = (item as model.Transaction).title?.trim() ?? '';
      if (extraTitle.isNotEmpty) subtitleExtra = ' · $extraTitle';
    }

    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
              child: SizedBox(
                height: 44,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Text(
                      'Transaction details',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w600,
                        color: ink,
                        letterSpacing: -0.2,
                      ),
                    ),
                    Row(
                      children: [
                        _SoftCircleIconButton(
                          icon: Icons.arrow_back_ios_new_rounded,
                          ink: ink,
                          card: card,
                          isDark: isDark,
                          tooltip: 'Back',
                          onPressed: () {
                            if (context.canPop()) {
                              context.pop();
                            } else {
                              context.go('/activity');
                            }
                          },
                        ),
                        const Spacer(),
                        // Soft Soft header: pale mint "Edit" chip (same edit flow).
                        // PNG export shows a circular pencil; Soft Soft checklist prefers chip.
                        _SoftEditChip(
                          emerald: emerald,
                          emeraldSoft: emeraldSoft,
                          onPressed:
                              () => _openEditForItem(
                                context,
                                ref,
                                isOutingExpense: isOutingExpense,
                                item: item,
                                outingId: outingId,
                              ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                child: Column(
                  children: [
                    // Amount hero card
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.fromLTRB(20, 22, 20, 22),
                      decoration: BoxDecoration(
                        color: card,
                        borderRadius: BorderRadius.circular(24),
                        boxShadow: isDark ? null : _softCardShadow,
                        border:
                            isDark
                                ? Border.all(
                                  color: SoftPalette.darkBorder.withValues(
                                    alpha: 0.5,
                                  ),
                                )
                                : null,
                      ),
                      child: Column(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 5,
                            ),
                            decoration: BoxDecoration(
                              color: emeraldSoft,
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: Text(
                              category,
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: emerald,
                              ),
                            ),
                          ),
                          const SizedBox(height: 14),
                          Text(
                            amountStr,
                            style: TextStyle(
                              fontSize: 40,
                              fontWeight: FontWeight.w700,
                              color: ink,
                              letterSpacing: -1.0,
                              height: 1.1,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            '$title$subtitleExtra',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w500,
                              color: muted,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            _formatSoftDetailDateTime(date),
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w400,
                              color: muted,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),

                    // Details card
                    Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: card,
                        borderRadius: BorderRadius.circular(24),
                        boxShadow: isDark ? null : _softCardShadow,
                        border:
                            isDark
                                ? Border.all(
                                  color: SoftPalette.darkBorder.withValues(
                                    alpha: 0.5,
                                  ),
                                )
                                : null,
                      ),
                      child: Column(
                        children: [
                          _SoftDetailRow(
                            label: 'Account',
                            value: accountLabel,
                            muted: muted,
                            ink: ink,
                          ),
                          _SoftDetailRow(
                            label: 'Payment',
                            value: paymentMode,
                            muted: muted,
                            ink: ink,
                          ),
                          _SoftDetailRow(
                            label: 'Purpose',
                            value: purposeLabel,
                            muted: muted,
                            ink: ink,
                          ),
                          _SoftDetailRow(
                            label: 'Category',
                            value: category,
                            muted: muted,
                            ink: ink,
                          ),
                          _SoftDetailRow(
                            label: 'Notes',
                            value: notesLabel,
                            muted: muted,
                            ink: ink,
                          ),
                          _SoftDetailRow(
                            label: 'Outing',
                            value: outingLabel,
                            muted: muted,
                            ink: ink,
                            isLast: true,
                          ),
                        ],
                      ),
                    ),

                    if (smsPill != null) ...[
                      const SizedBox(height: 12),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 18,
                          vertical: 14,
                        ),
                        decoration: BoxDecoration(
                          color: emeraldSoft,
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Text(
                          smsPill,
                          textAlign: TextAlign.left,
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: emerald,
                          ),
                        ),
                      ),
                    ],

                    const SizedBox(height: 20),
                    SizedBox(
                      width: double.infinity,
                      height: 54,
                      child: FilledButton(
                        onPressed:
                            () => _openEditForItem(
                              context,
                              ref,
                              isOutingExpense: isOutingExpense,
                              item: item,
                              outingId: outingId,
                            ),
                        style: FilledButton.styleFrom(
                          backgroundColor: SoftColors.control,
                          foregroundColor:
                              Colors.white,
                          shape: const StadiumBorder(),
                          elevation: 0,
                        ),
                        child: const Text(
                          'Edit transaction',
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                            letterSpacing: -0.1,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    SizedBox(
                      width: double.infinity,
                      height: 54,
                      child: Material(
                        color: card,
                        shape: const StadiumBorder(),
                        elevation: 0,
                        child: InkWell(
                          onTap: () {
                            if (!isOutingExpense) {
                              _showDeleteDialog(
                                context,
                                ref,
                                item as model.Transaction,
                              );
                            } else {
                              _showOutingDeleteDialog(
                                context,
                                ref,
                                outingId!,
                                (item as OutingExpense).id,
                              );
                            }
                          },
                          customBorder: const StadiumBorder(),
                          child: Container(
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: card,
                              borderRadius: BorderRadius.circular(999),
                              boxShadow: isDark ? null : _softCardShadow,
                            ),
                            child: const Text(
                              'Delete',
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w700,
                                color: _softDelete,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),

                    // Keep existing advanced sections (items / splits / raw / link)
                    if (!isOutingExpense &&
                        (item as model.Transaction).items.isNotEmpty) ...[
                      const SizedBox(height: 12),
                      _SoftSecondaryCard(
                        card: card,
                        isDark: isDark,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'ITEMS',
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                letterSpacing: 1.2,
                                color: muted,
                              ),
                            ),
                            const SizedBox(height: 10),
                            ...item.items.map(
                              (row) => Padding(
                                padding: const EdgeInsets.symmetric(
                                  vertical: 5,
                                ),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        row.categoryId.isNotEmpty
                                            ? '${row.name} · ${row.categoryId}'
                                            : row.name,
                                        style: TextStyle(
                                          fontSize: 13,
                                          color: muted,
                                        ),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                    Text(
                                      _formatDetailAmount(row.amount),
                                      style: TextStyle(
                                        fontSize: 13,
                                        fontWeight: FontWeight.w600,
                                        color: ink,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],

                    if (!isOutingExpense &&
                        (item as model.Transaction).isSplitExpense) ...[
                      const SizedBox(height: 12),
                      _SoftSecondaryCard(
                        card: card,
                        isDark: isDark,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'SPLITS',
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                letterSpacing: 1.2,
                                color: muted,
                              ),
                            ),
                            const SizedBox(height: 10),
                            ...item.splits.map(
                              (row) => Padding(
                                padding: const EdgeInsets.symmetric(
                                  vertical: 5,
                                ),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        row.categoryId.isNotEmpty
                                            ? '${row.purposeId} · ${row.categoryId}'
                                            : row.purposeId,
                                        style: TextStyle(
                                          fontSize: 13,
                                          color: muted,
                                        ),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                    Text(
                                      _formatDetailAmount(row.amount),
                                      style: TextStyle(
                                        fontSize: 13,
                                        fontWeight: FontWeight.w600,
                                        color: ink,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],

                    if (item is model.Transaction &&
                        (item.rawMessage.isNotEmpty ||
                            item.rawIdentifier != null ||
                            item.note.isNotEmpty)) ...[
                      const SizedBox(height: 8),
                      Theme(
                        data: Theme.of(
                          context,
                        ).copyWith(dividerColor: Colors.transparent),
                        child: ExpansionTile(
                          title: Text(
                            item.isAutoDetected
                                ? 'RAW SMS MESSAGE'
                                : 'NOTE / IDENTIFIER',
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 1.2,
                              color: muted,
                            ),
                          ),
                          tilePadding: EdgeInsets.zero,
                          children: [
                            Container(
                              width: double.infinity,
                              padding: const EdgeInsets.all(14),
                              decoration: BoxDecoration(
                                color:
                                    isDark
                                        ? Colors.white.withValues(alpha: 0.05)
                                        : SoftPalette.surfaceVariant,
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: Text(
                                item.rawMessage.isNotEmpty
                                    ? item.rawMessage
                                    : (item.note.isNotEmpty
                                        ? item.note
                                        : (item.rawIdentifier ?? '')),
                                style: TextStyle(
                                  fontSize: 12,
                                  fontFamily: 'monospace',
                                  color: muted,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],

                    const SizedBox(height: 12),
                    Builder(
                      builder: (context) {
                        if (!isOutingExpense) {
                          final tx = item as model.Transaction;
                          if (tx.outingId != null &&
                              outings.any((o) => o.id == tx.outingId)) {
                            return _UnlinkTripButton(
                              onPressed:
                                  () => _unlinkFromTrip(context, ref, tx: tx),
                            );
                          }
                          final linkable = outingsAcceptingTransaction(
                            outings,
                            tx,
                          );
                          if (linkable.isEmpty) {
                            return const SizedBox.shrink();
                          }
                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'LINK TO OUTING',
                                style: TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 1.2,
                                  color: muted,
                                ),
                              ),
                              const SizedBox(height: 10),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 16,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: card,
                                  borderRadius: BorderRadius.circular(20),
                                  boxShadow: isDark ? null : _softCardShadow,
                                  border:
                                      isDark
                                          ? Border.all(
                                            color: SoftPalette.darkBorder
                                                .withValues(alpha: 0.5),
                                          )
                                          : null,
                                ),
                                child: DropdownButtonHideUnderline(
                                  child: DropdownButton<String>(
                                    isExpanded: true,
                                    hint: Text(
                                      'Add to outing...',
                                      style: TextStyle(
                                        fontSize: 14,
                                        color: muted,
                                      ),
                                    ),
                                    icon: Icon(
                                      Icons.keyboard_arrow_down_rounded,
                                      size: 20,
                                      color: muted,
                                    ),
                                    items:
                                        linkable.map((o) {
                                          return DropdownMenuItem<String>(
                                            value: o.id,
                                            child: Row(
                                              children: [
                                                Icon(
                                                  Icons.explore_outlined,
                                                  size: 16,
                                                  color: emerald,
                                                ),
                                                const SizedBox(width: 8),
                                                Text(
                                                  o.title,
                                                  style: TextStyle(
                                                    fontWeight: FontWeight.w500,
                                                    fontSize: 14,
                                                    color: ink,
                                                  ),
                                                ),
                                                const SizedBox(width: 6),
                                                if (o.isActive)
                                                  Container(
                                                    padding:
                                                        const EdgeInsets.symmetric(
                                                          horizontal: 6,
                                                          vertical: 2,
                                                        ),
                                                    decoration: BoxDecoration(
                                                      color: emeraldSoft,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                            6,
                                                          ),
                                                    ),
                                                    child: Text(
                                                      'ACTIVE',
                                                      style: TextStyle(
                                                        color: emerald,
                                                        fontSize: 11,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                      ),
                                                    ),
                                                  ),
                                              ],
                                            ),
                                          );
                                        }).toList(),
                                    onChanged: (oId) {
                                      if (oId == null) return;
                                      final o =
                                          linkable
                                              .where((e) => e.id == oId)
                                              .firstOrNull;
                                      if (o == null) return;
                                      ref
                                          .read(
                                            model.transactionProvider.notifier,
                                          )
                                          .updateTransactionOuting(tx.id, oId);
                                      ScaffoldMessenger.of(
                                        context,
                                      ).showSnackBar(
                                        SnackBar(
                                          content: Text(
                                            'Linked to ${o.title}!',
                                          ),
                                          backgroundColor: SoftPalette.emerald,
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ),
                            ],
                          );
                        }
                        final expense = item as OutingExpense;
                        return _UnlinkTripButton(
                          onPressed:
                              () => _unlinkOutingExpense(
                                context,
                                ref,
                                outingId!,
                                expense,
                              ),
                        );
                      },
                    ),

                    // Preserve transfer-aware extras when present
                    if (!isOutingExpense && isTransfer) ...[
                      const SizedBox(height: 4),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _unlinkFromTrip(
    BuildContext context,
    WidgetRef ref, {
    required model.Transaction tx,
  }) async {
    final ok = await OutingUnlinkDialog.confirm(
      context,
      itemName: TransactionDisplayUtils.merchantTitle(tx),
      amount: tx.amount,
    );
    if (!ok) return;

    // updateTransactionOuting preserves the member split as a Friend Split
    // before dropping the trip link — see _preserveSplitOnUnlink.
    ref
        .read(model.transactionProvider.notifier)
        .updateTransactionOuting(tx.id, null);
    if (context.mounted) {
      context.pop();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Unlinked from trip'),
          backgroundColor: AppColors.expense,
        ),
      );
    }
  }

  Future<void> _unlinkOutingExpense(
    BuildContext context,
    WidgetRef ref,
    String outingId,
    OutingExpense expense,
  ) async {
    final ok = await OutingUnlinkDialog.confirm(
      context,
      itemName: expense.title,
      amount: expense.amount,
    );
    if (!ok) return;

    if (expense.transactionId != null && expense.transactionId!.isNotEmpty) {
      final tx =
          ref
              .read(model.transactionProvider)
              .where((t) => t.id == expense.transactionId)
              .firstOrNull;
      if (tx != null) {
        ref
            .read(model.transactionProvider.notifier)
            .updateTransactionOuting(tx.id, null);
      } else {
        ref
            .read(outingProvider.notifier)
            .removeExpenseByTransactionId(outingId, expense.transactionId!);
      }
    } else {
      // Manual trip entry: becomes a normal ledger transaction rather than
      // being deleted with the trip link (see materialiseOutingExpense).
      final outing =
          ref.read(outingProvider).where((o) => o.id == outingId).firstOrNull;
      ref
          .read(model.transactionProvider.notifier)
          .materialiseOutingExpense(expense, outing: outing);
      ref.read(outingProvider.notifier).deleteExpense(outingId, expense.id);
    }
    if (context.mounted) {
      context.pop();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Removed from trip'),
          backgroundColor: AppColors.expense,
        ),
      );
    }
  }
}

class _UnlinkTripButton extends StatelessWidget {
  final VoidCallback onPressed;
  const _UnlinkTripButton({required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 48,
      child: OutlinedButton.icon(
        onPressed: onPressed,
        icon: const Icon(
          LucideIcons.unlink,
          size: 18,
          color: AppColors.expense,
        ),
        label: const Text(
          'Remove from Outing',
          style: TextStyle(
            fontWeight: FontWeight.w500,
            color: AppColors.expense,
          ),
        ),
        style: OutlinedButton.styleFrom(
          side: const BorderSide(color: AppColors.expense),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
      ),
    );
  }
}

class _SoftEditChip extends StatelessWidget {
  const _SoftEditChip({
    required this.emerald,
    required this.emeraldSoft,
    required this.onPressed,
  });

  final Color emerald;
  final Color emeraldSoft;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: emeraldSoft,
      borderRadius: BorderRadius.circular(999),
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(999),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          child: Text(
            'Edit',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: emerald,
            ),
          ),
        ),
      ),
    );
  }
}

class _SoftCircleIconButton extends StatelessWidget {
  const _SoftCircleIconButton({
    required this.icon,
    required this.ink,
    required this.card,
    required this.isDark,
    required this.onPressed,
    this.tooltip,
  });

  final IconData icon;
  final Color ink;
  final Color card;
  final bool isDark;
  final VoidCallback onPressed;
  final String? tooltip;

  @override
  Widget build(BuildContext context) {
    final btn = Material(
      color: card,
      shape: const CircleBorder(),
      elevation: 0,
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onPressed,
        child: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: card,
            boxShadow:
                isDark
                    ? null
                    : const [
                      BoxShadow(
                        color: Color(0x0F050D1A),
                        blurRadius: 16,
                        offset: Offset(0, 4),
                      ),
                    ],
            border:
                isDark
                    ? Border.all(
                      color: SoftPalette.darkBorder.withValues(alpha: 0.6),
                    )
                    : null,
          ),
          child: Icon(icon, size: 18, color: ink),
        ),
      ),
    );
    if (tooltip == null) return btn;
    return Tooltip(message: tooltip!, child: btn);
  }
}

class _SoftDetailRow extends StatelessWidget {
  const _SoftDetailRow({
    required this.label,
    required this.value,
    required this.muted,
    required this.ink,
    this.isLast = false,
  });

  final String label;
  final String value;
  final Color muted;
  final Color ink;
  final bool isLast;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 14, 16, isLast ? 14 : 0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w400,
              color: muted,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.end,
              overflow: TextOverflow.ellipsis,
              maxLines: 2,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: ink,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SoftSecondaryCard extends StatelessWidget {
  const _SoftSecondaryCard({
    required this.child,
    required this.card,
    required this.isDark,
  });

  final Widget child;
  final Color card;
  final bool isDark;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(24),
        boxShadow: isDark ? null : _softCardShadow,
        border:
            isDark
                ? Border.all(
                  color: SoftPalette.darkBorder.withValues(alpha: 0.5),
                )
                : null,
      ),
      child: child,
    );
  }
}

class _ChoiceButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool isSelected;
  final VoidCallback onTap;
  const _ChoiceButton({
    required this.label,
    required this.icon,
    required this.isSelected,
    required this.onTap,
  });
  @override
  Widget build(BuildContext context) {
    final border = context.tokens.border;
    final muted = context.tokens.textSecondary;
    return AnimatedTapCard(
      onTap: onTap,
      scaleDown: 0.93,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color:
              isSelected
                  ? AppColors.primary.withValues(alpha: 0.12)
                  : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color:
                isSelected ? AppColors.primary : border.withValues(alpha: 0.4),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 16, color: isSelected ? AppColors.primary : muted),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w500,
                color: isSelected ? AppColors.primary : null,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
