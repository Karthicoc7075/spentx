import 'dart:async';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../core/theme/spentx_tokens.dart';
import '../../../core/theme/app_fonts.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/design/sx_feedback.dart';
import '../../../core/widgets/category_icon.dart';
import '../../../core/widgets/soft_date_range_picker.dart';
import '../../../core/utils/transaction_display_utils.dart';
import '../data/transaction_provider.dart' as model;
import '../../../core/providers/category_provider.dart';
import '../../../core/providers/user_state_provider.dart';
import '../../../core/providers/outing_provider.dart';
import '../../../core/providers/outing_privacy_provider.dart';
import '../../../core/providers/friends_provider.dart';
import '../../../core/providers/friend_split_provider.dart';
import '../../../core/providers/contributor_provider.dart';
import '../../../models/friend_split.dart';
import '../../../core/sync/sync_service.dart';
import '../../../core/sync/supabase_schema_map.dart';
import '../../../core/widgets/animated_tap_card.dart';
import '../../../core/providers/private_mode_provider.dart';
import '../../sms/detected/detection_queue.dart';

/// Every filter chip on this screen is this tall, so the three chip rows line
/// up optically instead of each picking its own vertical padding.
const double _kChipHeight = 34.0;

/// Horizontal gap between two chips in a row. Applied as a separator rather
/// than as trailing padding on each chip, so a row's last chip ends exactly at
/// its container edge instead of leaving a phantom gutter that makes the row
/// look inset further on the right than on the left.
const double _kChipGap = AppSpacing.xs;

/// Badge label for a transaction card — Split Expense / Friend Split /
/// Outing / Settlement, or null for an ordinary transaction. Outing summary
/// rows keep their Outing badge even without an outingId. Shared by the list
/// and the search delegate so both render identically.
String? _badgeLabel(model.Transaction tx) {
  // A friend paying you back is checked before the Trip/Outing shortcut: a
  // return for a trip carries that trip's marker, and badging it "Outing"
  // made money coming back look like another trip expense.
  if (tx.isFriendReturn) return 'Friend Return';
  if (tx.time == 'OutingSummary' || tx.time == 'Trip') return 'Outing';
  return tx.badgeKind.label;
}

/// Summarizes list of categories/purposes to first item + overflow count (e.g. "Personal +1", "Food +2").
String _summariseNamesTop(List<String> names) {
  return TransactionDisplayUtils.summariseNames(names);
}

/// One category/purpose slice that matched the active filters — carries its
/// own amount so a card under a filter can total just the matching splits
/// instead of the whole transaction.
class _MatchedSplit {
  final String category;
  final String purpose;
  final double amount;
  const _MatchedSplit(this.category, this.purpose, this.amount);
}

double _sumMatched(List<_MatchedSplit> matched) =>
    matched.fold(0, (sum, m) => sum + m.amount);

List<String> _distinctInOrder(Iterable<String> values) {
  final seen = <String>{};
  final out = <String>[];
  for (final v in values) {
    final trimmed = v.trim();
    if (trimmed.isEmpty || !seen.add(trimmed.toLowerCase())) continue;
    out.add(trimmed);
  }
  return out;
}

/// Purpose types carry their own tint identity (matches the purpose badge on
/// transaction cards): Personal = purple, Family = amber, All = income green,
/// others = blue. Kept as a function so the chip row and any future consumer
/// resolve it the same way.
Color _purposeTint(String purpose) => switch (purpose.toLowerCase()) {
  'all' => AppColors.incomeTint,
  'personal' => AppColors.tintPurple,
  'family' => AppColors.tintAmber,
  _ => AppColors.tintBlue,
};

/// The four date scopes offered by the range menu. "All time" used to be
/// reachable only by re-tapping the already-active chip, which nobody
/// discovers — it's an explicit option now.
enum _DateScope { thisMonth, lastMonth, custom, all }

class TransactionsScreen extends ConsumerStatefulWidget {
  /// When opened from Home purpose cards, e.g. "Personal" / "Family".
  final String? initialPurpose;

  const TransactionsScreen({super.key, this.initialPurpose});

  @override
  ConsumerState<TransactionsScreen> createState() => _TransactionsScreenState();
}

class _TransactionsScreenState extends ConsumerState<TransactionsScreen> {
  late String _selectedPurpose;
  String _selectedCategory = 'All';
  DateTimeRange? _dateRange;
  String _selectedSpendType = 'All';

  /// Income source (the `contributors` table). Deliberately NOT a friend —
  /// see [_involvesFriend] for why these are two filters.
  String _selectedContributor = 'All';

  /// Split participant (the `friends` / `friend_splits` side).
  String _selectedFriend = 'All';

  /// Account filters are multi-select. A transfer matches when either its
  /// source or destination account is selected, but the ledger still renders
  /// the single stored transfer row only once.
  Set<String> _selectedSources = <String>{};

  final Map<String, List<model.Transaction>> _childrenByParentId = {};
  final Map<String, List<model.Transaction>> _childrenByOutingId = {};
  Map<String, FriendSplit> _splitsByTx = const {};
  Map<String, Outing> _outingsById = const {};
  List<model.Transaction>? _filteredCache;
  int? _filterKey;

  @override
  void initState() {
    super.initState();
    final initial = widget.initialPurpose?.trim();
    _selectedPurpose = (initial == null || initial.isEmpty) ? 'All' : initial;
    // Default scope is the current calendar month — matches the Summary
    // card's "Available/Remaining" math, which only makes sense relative to
    // the real current month (see _isCurrentMonthRange).
    _dateRange = _thisMonthRange();
  }

  // ═══════════════════ filtering / aggregation (unchanged) ═══════════════════

  static final _uuidPattern = RegExp(
    r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$',
  );

  static bool _isUuid(String s) => _uuidPattern.hasMatch(s.trim());

  static String _canonicalPurpose(String p) {
    final t = p.trim();
    if (t.isEmpty) return 'Personal';
    final lower = t.toLowerCase();
    if (lower == 'personal') return 'Personal';
    if (lower == 'family' || lower == 'home') return 'Family';
    if (lower == 'office' || lower == 'work') return 'Office';
    return t;
  }

  String _resolvePurpose(String? raw, {String fallback = 'Personal'}) {
    if (raw == null || raw.trim().isEmpty) return fallback;
    final trimmed = raw.trim();

    // 1. Check RemoteIdCache (UUID -> name or name -> name)
    final cached = RemoteIdCache.purposeName(trimmed);
    if (cached != null && cached.isNotEmpty && !_isUuid(cached)) {
      return _canonicalPurpose(cached);
    }

    // 2. Check against known user purposeTypes
    try {
      final userPurposes = ref.read(userStateProvider).purposeTypes;
      for (final p in userPurposes) {
        if (p.toLowerCase() == trimmed.toLowerCase()) {
          return _canonicalPurpose(p);
        }
      }
    } catch (_) {}

    return _canonicalPurpose(trimmed);
  }

  bool _purposeMatches(String candidate, String target) {
    final c = _resolvePurpose(candidate).toLowerCase();
    final t = _resolvePurpose(target).toLowerCase();
    if (c == t) return true;
    if ((c == 'family' || c == 'home') && (t == 'family' || t == 'home')) {
      return true;
    }
    return false;
  }

  /// Resolve purpose label for filter (null/empty ledger purpose → Personal).
  String _purposeOf(model.Transaction tx) {
    final p = tx.purpose?.trim();
    if (p == null || p.isEmpty) {
      if (tx.splits.isNotEmpty) {
        return _resolvePurpose(tx.splits.first.purposeId);
      }
      return 'Personal';
    }
    return _resolvePurpose(p);
  }

  /// The split rows (or the whole transaction as one implicit row) that
  /// satisfy BOTH the active Purpose and Category filters jointly — same
  /// rule as web `matchingTransactionSplits`. Empty when a filter is active
  /// and no single row satisfies both, in which case the transaction is
  /// hidden. With no filters active, returns every row unchanged so the
  /// card still shows the full transaction summary.
  List<_MatchedSplit> _matchingSplits(model.Transaction tx) {
    final purposeTarget =
        _selectedPurpose == 'All' ? null : _selectedPurpose.trim();
    final categoryTarget =
        _selectedCategory == 'All' ? null : _selectedCategory.trim().toLowerCase();

    if (!tx.isSplitExpense) {
      final p = _purposeOf(tx);
      final purposeOk =
          purposeTarget == null || _purposeMatches(p, purposeTarget);
      final categoryOk =
          categoryTarget == null || tx.category.trim().toLowerCase() == categoryTarget;
      if (!purposeOk || !categoryOk) return const [];
      return [_MatchedSplit(tx.category, p, tx.amount)];
    }

    return tx.splits
        .where((s) {
          final purposeOk =
              purposeTarget == null ||
              _purposeMatches(_splitPurpose(tx, s.purposeId), purposeTarget);
          final categoryOk =
              categoryTarget == null ||
              _splitCategory(tx, s.categoryId).trim().toLowerCase() == categoryTarget;
          return purposeOk && categoryOk;
        })
        .map(
          (s) => _MatchedSplit(
            _splitCategory(tx, s.categoryId),
            _splitPurpose(tx, s.purposeId),
            s.amount,
          ),
        )
        .toList();
  }

  /// Blank split purpose follows the row, then Personal — same as [_purposeOf].
  String _splitPurpose(model.Transaction tx, String raw) {
    final slice = raw.trim();
    if (slice.isNotEmpty) return _resolvePurpose(slice);
    return _purposeOf(tx);
  }

  String _splitCategory(model.Transaction tx, String raw) {
    final slice = raw.trim();
    if (slice.isNotEmpty) return slice;
    return tx.category;
  }

  /// Amount this row contributes to the summary. Outing summaries are already
  /// reduced to the slices that passed the filter. Every other row contributes
  /// only its matching purpose/category slices, never the full transaction
  /// when other purposes sit on the same row.
  double _scopedAmount(model.Transaction tx) {
    if (tx.time == 'OutingSummary') return tx.amount;
    return _sumMatched(_matchingSplits(tx));
  }

  bool _excludedFromCashflow(model.Transaction tx) {
    if (tx.isTransfer) return true;
    final cat = tx.category.trim().toLowerCase();
    if (cat == 'transfer' || cat == 'opening balance') return true;
    // A friend paying you back is not income and not a new expense.
    if (tx.isFriendReturn) return true;
    return false;
  }

  /// Total Out for the summary card. Uses the same filtered ledger as the
  /// transaction cards, netting off any money friends returned so Total Out
  /// shows the true net personal spend.
  double _totalMatchedExpense(List<model.Transaction> transactions) {
    var expenseSum = 0.0;
    var friendReturnsSum = 0.0;
    for (final tx in transactions) {
      if (tx.isTransfer) continue;
      final cat = tx.category.trim().toLowerCase();
      if (cat == 'transfer' || cat == 'opening balance') continue;
      if (tx.isFriendReturn) {
        friendReturnsSum += _scopedAmount(tx);
      } else if (tx.isExpense) {
        expenseSum += _scopedAmount(tx);
      }
    }
    return (expenseSum - friendReturnsSum).clamp(0.0, double.infinity);
  }

  /// Total In for the summary card. Same filtered ledger and slice rule.
  double _totalMatchedIncome(List<model.Transaction> transactions) {
    var sum = 0.0;
    for (final tx in transactions) {
      if (tx.isExpense || _excludedFromCashflow(tx)) continue;
      sum += _scopedAmount(tx);
    }
    return sum;
  }


  void _snack(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
    );
  }

  /// Whether [tx] involves [friendName] as a **split participant**.
  ///
  /// Friends and Contributors are separate financial concepts: a Friend
  /// shares an expense and may owe you money; a Contributor is where income
  /// came from. Nothing here reads `contributorSource`, and nothing in the
  /// contributor filter reads this — the two never cross.
  ///
  /// Participation is only ever read from an explicit roster (the Friend
  /// Split's members, or the outing's members), never inferred by searching
  /// the merchant or note text for a name.
  bool _involvesFriend(model.Transaction tx, String friendName) {
    final target = friendName.trim().toLowerCase();
    if (target.isEmpty) return false;

    bool rosterHas(Iterable<dynamic> members) =>
        members.any((m) => m.name.toString().trim().toLowerCase() == target);

    // Friend Split — one split per transaction, keyed by transaction id.
    final split = _splitsByTx[tx.id];
    if (split != null && rosterHas(split.members)) return true;

    // Outing-tagged row — the trip roster is the participant list.
    final outingId = tx.outingId;
    if (outingId != null && outingId.isNotEmpty) {
      final outing = _outingsById[outingId];
      if (outing != null && rosterHas(outing.members)) return true;
    }

    return false;
  }

  List<model.Transaction> _getFilteredTransactions() {
    final transactions = ref.watch(model.transactionProvider);
    final outings = ref.watch(outingProvider);
    final friendSplits = ref.watch(friendSplitProvider);
    final privacyActive = ref.watch(isOutingPrivacyActiveProvider);
    final activeOuting = ref.watch(activeOutingProvider);

    final key = Object.hashAll([
      identityHashCode(transactions),
      transactions.length,
      identityHashCode(outings),
      outings.length,
      identityHashCode(friendSplits),
      friendSplits.length,
      privacyActive,
      activeOuting?.id,
      _selectedPurpose,
      _selectedCategory,
      _selectedSpendType,
      _selectedContributor,
      _selectedFriend,
      ...(_selectedSources.toList()..sort()),
      _dateRange?.start.millisecondsSinceEpoch,
      _dateRange?.end.millisecondsSinceEpoch,
    ]);
    if (_filteredCache != null && _filterKey == key) return _filteredCache!;
    _splitsByTx = <String, FriendSplit>{};
    for (final split in friendSplits) {
      _splitsByTx.putIfAbsent(split.transactionId, () => split);
    }
    _outingsById = <String, Outing>{};
    for (final outing in outings) {
      _outingsById.putIfAbsent(outing.id, () => outing);
    }

    if (privacyActive && activeOuting != null) {
      final result =
          transactions.where((t) => t.outingId == activeOuting.id).toList();
      for (final e in activeOuting.expenses) {
        if (e.transactionId != null) continue;
        result.add(
          model.Transaction(
            merchant: '${activeOuting.title}: ${e.title}',
            category: e.category,
            account: e.accountId ?? 'Trip',
            time: 'Trip',
            // The ledger shows what was actually paid. Was
            // currentImpactExcludingYou (amount MINUS what friends had
            // returned), so a ₹1,200 trip bill silently became ₹800 once a
            // friend paid ₹400 back — rewriting history. The return is its
            // own +₹400 row; netting belongs in Analysis, not here.
            amount: e.amount,
            isExpense: true,
            date: e.date,
            purpose: 'Personal',
            outingId: activeOuting.id,
            id: e.id,
            note: '',
          ),
        );
      }
      result.sort((a, b) => b.date.compareTo(a.date));
      _filterKey = key;
      _filteredCache = result;
      return result;
    }

    final List<model.Transaction> result = [...transactions];

    // Add manual outing expenses
    for (var outing in outings) {
      for (var e in outing.expenses) {
        if (e.transactionId == null) {
          result.add(
            model.Transaction(
              merchant: '${outing.title}: ${e.title}',
              category: e.category,
              account: e.accountId ?? 'Default',
              time: 'Trip',
              // Gross, as paid — see the note on the privacy branch above.
              amount: e.amount,
              isExpense: true,
              date: e.date,
              purpose: 'Personal', // Outing expenses are Personal
              outingId: outing.id,
              id: e.id, // Use expense ID as transaction ID for detail navigation
              note: '',
            ),
          );
        }
      }
    }

    final selectedAccountNames =
        _selectedSources.map((source) => source.trim().toLowerCase()).toSet();
    final filtered =
        result.where((tx) {
          if (_selectedCategory != 'All' && !tx.isExpense) return false;
          if (_matchingSplits(tx).isEmpty) return false;

          if (_dateRange != null) {
            if (tx.date.isBefore(_dateRange!.start) ||
                tx.date.isAfter(_dateRange!.end.add(const Duration(days: 1)))) {
              return false;
            }
          }

          // ── Spend Type Filter ──
          if (_selectedSpendType != 'All') {
            final cat = tx.category.trim().toLowerCase();
            final isRepayment = cat == 'friend returns';
            final isTransfer = tx.isTransfer || cat == 'transfer';

            if (_selectedSpendType == 'Expense' &&
                (!tx.isExpense || isTransfer || isRepayment)) {
              return false;
            }
            if (_selectedSpendType == 'Income' &&
                (tx.isExpense ||
                    isTransfer ||
                    isRepayment ||
                    cat == 'opening balance')) {
              return false;
            }
            if (_selectedSpendType == 'Transfer' && !isTransfer) return false;
            if (_selectedSpendType == 'Repayment' && !isRepayment) return false;
          }

          // ── Contributor Filter (income source) ──
          // A contributor answers "whose money came in" and lives on
          // `contributorSource` (web `transaction_splits.contributor_id`). Only
          // credits carry one, so an expense simply never matches — that is
          // correct, not a gap to paper over.
          //
          // This used to be populated from the Friends list and fell back to
          // substring-matching the merchant and note, which silently merged two
          // unrelated financial concepts. Friends are filtered separately below.
          if (_selectedContributor != 'All') {
            final source = (tx.contributorSource ?? '').trim();
            if (source.isEmpty) return false;
            if (source.toLowerCase() != _selectedContributor.toLowerCase()) {
              return false;
            }
          }

          // ── Friend Filter (split participant) ──
          if (_selectedFriend != 'All' &&
              !_involvesFriend(tx, _selectedFriend)) {
            return false;
          }

          // ── Source / Account Filter ──
          if (_selectedSources.isNotEmpty) {
            final txAcc = tx.account.trim().toLowerCase();
            final transferDestination =
                (tx.transferTo ?? '').trim().toLowerCase();
            final isTransferLike =
                tx.isTransfer || tx.category.trim().toLowerCase() == 'transfer';
            if (!selectedAccountNames.contains(txAcc) &&
                (!isTransferLike ||
                    !selectedAccountNames.contains(transferDestination))) {
              return false;
            }
          }

          return true;
        }).toList();

    // ── Group by Outing ──
    // Skip web "Outing total · …" display rows (display-only; real spend is on
    // individual ledger + unlinked cash rows already in [filtered]).
    bool isWebOutingRollup(model.Transaction tx) {
      // Same rules as outing_totals / web (note prefix + trip-total marker).
      final note = tx.note.trim().toLowerCase();
      if (note.startsWith('outing total') ||
          note.startsWith('your share of ')) {
        return true;
      }
      if (tx.time.trim().toLowerCase() == 'trip total') return true;
      if (tx.outingId != null &&
          tx.outingId!.isNotEmpty &&
          tx.note.trim().isNotEmpty &&
          tx.note.trim() == tx.merchant.trim()) {
        return true;
      }
      return false;
    }

    _childrenByParentId.clear();
    _childrenByOutingId.clear();

    for (final tx in filtered) {
      if (tx.isFriendReturn) {
        if (tx.outingId != null && tx.outingId!.isNotEmpty) {
          _childrenByOutingId.putIfAbsent(tx.outingId!, () => []).add(tx);
        }
        if (tx.linkedExpenseId != null && tx.linkedExpenseId!.isNotEmpty) {
          _childrenByParentId.putIfAbsent(tx.linkedExpenseId!, () => []).add(tx);
        }
      }
    }

    _grossByOuting.clear();
    for (final tx in filtered) {
      if (tx.outingId != null && tx.isExpense && !tx.isFriendReturn) {
        _grossByOuting[tx.outingId!] =
            (_grossByOuting[tx.outingId!] ?? 0) + _scopedAmount(tx);
      }
    }

    final List<model.Transaction> finalized = [];

    for (var tx in filtered) {
      if (isWebOutingRollup(tx)) continue;
      finalized.add(tx);
    }

    finalized.sort((a, b) => b.date.compareTo(a.date));
    _filterKey = key;
    _filteredCache = finalized;
    return finalized;
  }

  /// Gross spend per trip for the rows currently on screen, kept so the trip
  /// row can show "of ₹1,200" beside its netted amount. Rebuilt on every
  /// filter pass — never read outside the build it was written in.
  final Map<String, double> _grossByOuting = {};

  Map<String, List<model.Transaction>> _groupTransactions(
    List<model.Transaction> txs,
  ) {
    final Map<String, List<model.Transaction>> groups = {};
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));

    for (var tx in txs) {
      final txDate = DateTime(tx.date.year, tx.date.month, tx.date.day);
      String header;
      if (txDate == today) {
        header = 'Today';
      } else if (txDate == yesterday) {
        header = 'Yesterday';
      } else {
        header = DateFormat('MMMM dd, yyyy').format(tx.date);
      }

      if (!groups.containsKey(header)) groups[header] = [];
      groups[header]!.add(tx);
    }
    return groups;
  }

  // ═══════════════════════════ date scope ═══════════════════════════

  DateTimeRange _thisMonthRange() {
    final now = DateTime.now();
    return DateTimeRange(
      start: DateTime(now.year, now.month, 1),
      // Day 0 of next month = last day of this month.
      end: DateTime(now.year, now.month + 1, 0),
    );
  }

  DateTimeRange _lastMonthRange() {
    final now = DateTime.now();
    return DateTimeRange(
      start: DateTime(now.year, now.month - 1, 1),
      end: DateTime(now.year, now.month, 0),
    );
  }

  /// Calendar month before the active filter starts. All-time has no start,
  /// so there is nothing to roll over.
  DateTimeRange? _previousMonthRange() {
    final range = _dateRange;
    if (range == null) return null;
    return DateTimeRange(
      start: DateTime(range.start.year, range.start.month - 1, 1),
      end: DateTime(range.start.year, range.start.month, 0),
    );
  }

  String? _rolloverMonthName() {
    final prev = _previousMonthRange();
    if (prev == null) return null;
    return DateFormat('MMMM').format(prev.start);
  }

  /// Previous month's own net (in − out) under the same purpose, category,
  /// spend type, account, and other filters as the list on screen. Not
  /// chained: that month's leftover is not added again. Clears the list cache
  /// so the visible period is rebuilt afterwards.
  double _previousMonthRollover() {
    final prev = _previousMonthRange();
    if (prev == null) return 0;
    final saved = _dateRange;
    _dateRange = prev;
    _filteredCache = null;
    _filterKey = null;
    final list = _getFilteredTransactions();
    final net = _totalMatchedIncome(list) - _totalMatchedExpense(list);
    _dateRange = saved;
    _filteredCache = null;
    _filterKey = null;
    return net.abs() < 0.5 ? 0 : net;
  }

  bool _sameRange(DateTimeRange a, DateTimeRange? b) {
    if (b == null) return false;
    return a.start.year == b.start.year &&
        a.start.month == b.start.month &&
        a.start.day == b.start.day &&
        a.end.year == b.end.year &&
        a.end.month == b.end.month &&
        a.end.day == b.end.day;
  }

  _DateScope get _scope {
    if (_dateRange == null) return _DateScope.all;
    if (_sameRange(_thisMonthRange(), _dateRange)) return _DateScope.thisMonth;
    if (_sameRange(_lastMonthRange(), _dateRange)) return _DateScope.lastMonth;
    return _DateScope.custom;
  }

  String get _scopeLabel {
    switch (_scope) {
      case _DateScope.thisMonth:
        return 'This month';
      case _DateScope.lastMonth:
        return 'Last month';
      case _DateScope.all:
        return 'All time';
      case _DateScope.custom:
        final f = DateFormat('d MMM');
        return '${f.format(_dateRange!.start)} – ${f.format(_dateRange!.end)}';
    }
  }

  DateTimeRange? _pickerInitialRange(DateTime lastDay) {
    final range = _dateRange;
    if (range == null) return null;
    var start = DateTime(range.start.year, range.start.month, range.start.day);
    var end = DateTime(range.end.year, range.end.month, range.end.day);
    if (end.isAfter(lastDay)) end = lastDay;
    if (start.isAfter(end)) start = end;
    if (start.isBefore(DateTime(2020))) start = DateTime(2020);
    return DateTimeRange(start: start, end: end);
  }

  Future<void> _selectDateRange() async {
    final now = DateTime.now();
    final lastDay = DateTime(now.year, now.month, now.day);
    final picked = await showSoftDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: lastDay,
      initialDateRange: _pickerInitialRange(lastDay),
    );
    if (picked != null) unawaited(_applyRangeFilter(picked));
  }

  /// Last month usually falls outside the ~35-day rolling sync window, so
  /// pull it in from the server first instead of silently showing a filter
  /// that looks "empty" because nothing that old is cached yet.
  Future<void> _applyRangeFilter(DateTimeRange range) async {
    final oldest = SyncService.oldestCachedTransactionDate();
    if (oldest == null || oldest.isAfter(range.start)) {
      final fetched = await SyncService.fetchTransactionRange(
        from: range.start,
        to: oldest ?? DateTime.now(),
      );
      if (!mounted) return;
      if (fetched == null) {
        _snack('Offline — only locally cached history is available.');
      }
    }
    if (!mounted) return;
    setState(() => _dateRange = range);
  }

  void _onScopeSelected(_DateScope scope) {
    switch (scope) {
      case _DateScope.thisMonth:
        unawaited(_applyRangeFilter(_thisMonthRange()));
        break;
      case _DateScope.lastMonth:
        unawaited(_applyRangeFilter(_lastMonthRange()));
        break;
      case _DateScope.all:
        setState(() => _dateRange = null);
        break;
      case _DateScope.custom:
        unawaited(_selectDateRange());
        break;
    }
  }

  // ═══════════════════════════ filter state ═══════════════════════════

  int get _advancedActiveCount =>
      [
        _selectedSpendType,
        _selectedContributor,
        _selectedFriend,
        ...(_selectedSources.toList()..sort()),
      ].where((v) => v != 'All').length;

  /// Newest transaction on record, ignoring every filter. Null when the
  /// ledger really is empty.
  DateTime? _newestLedgerDate() {
    DateTime? newest;
    for (final tx in ref.read(model.transactionProvider)) {
      if (tx.isPendingVerification) continue;
      if (newest == null || tx.date.isAfter(newest)) newest = tx.date;
    }
    return newest;
  }

  /// Whether the ledger holds anything at all outside what is on screen.
  bool _hasRowsOutsideRange() {
    final range = _dateRange;
    if (range == null) return false;
    for (final tx in ref.read(model.transactionProvider)) {
      if (tx.isPendingVerification) continue;
      if (tx.date.isBefore(range.start) ||
          tx.date.isAfter(range.end.add(const Duration(days: 1)))) {
        return true;
      }
    }
    return false;
  }

  /// The Activity list defaults to the current calendar month, and the date
  /// scope deliberately does NOT count as an "active filter" (see
  /// [_anyFilterActive]) — so an account whose activity is all in earlier
  /// months used to get a bare "No transactions in this period yet", with no
  /// clear-filters action and nothing to suggest the data still exists. That
  /// reads as "your transactions are gone". Name the period, say when the
  /// last activity actually was, and offer one tap to go see it.
  String _emptyStateMessage() {
    if (_anyFilterActive && !_hasRowsOutsideRange()) {
      return 'No transactions match these filters.';
    }
    if (_hasRowsOutsideRange()) {
      final newest = _newestLedgerDate();
      final when =
          newest == null ? null : DateFormat('d MMM yyyy').format(newest);
      return when == null
          ? 'Nothing in ${_scopeLabel.toLowerCase()} — your transactions are in another period.'
          : 'Nothing in ${_scopeLabel.toLowerCase()}. Your most recent activity was $when.';
    }
    if (_anyFilterActive) return 'No transactions match these filters.';
    return 'No transactions yet.';
  }

  String? _emptyStateActionLabel() {
    if (_anyFilterActive) return 'Clear filters';
    return null;
  }

  VoidCallback? _emptyStateAction() {
    if (_anyFilterActive) return _clearAllFilters;
    return null;
  }

  bool get _anyFilterActive =>
      _advancedActiveCount > 0 ||
      _selectedCategory != 'All' ||
      _selectedPurpose != 'All' ||
      _scope != _DateScope.thisMonth;

  /// Chip row under the cashflow card. Period pills already show the month,
  /// so a default "All" value is not a chip.
  bool get _customChipFiltersActive =>
      _selectedSpendType != 'All' ||
      _selectedContributor != 'All' ||
      _selectedFriend != 'All' ||
      _selectedSources.isNotEmpty ||
      _selectedCategory != 'All' ||
      _selectedPurpose != 'All';

  void _clearAllFilters() {
    setState(() {
      _selectedCategory = 'All';
      _selectedPurpose = 'All';
      _selectedSpendType = 'All';
      _selectedContributor = 'All';
      _selectedFriend = 'All';
      _selectedSources = <String>{};
      _dateRange = _thisMonthRange();
    });
  }

  void _showAdvancedFiltersSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      isDismissible: true,
      enableDrag: true,
      barrierColor: Colors.black.withValues(alpha: 0.58),
      builder: (context) {
        return _AdvancedFiltersSheet(
          selectedSpendType: _selectedSpendType,
          selectedContributor: _selectedContributor,
          selectedFriend: _selectedFriend,
          selectedSources: _selectedSources.toList(),
          selectedCategory: _selectedCategory,
          selectedPurpose: _selectedPurpose,
          onApply: (spendType, contributor, friend, source, category, purpose) {
            setState(() {
              _selectedSpendType = spendType;
              _selectedContributor = contributor;
              _selectedFriend = friend;
              _selectedSources = source.toSet();
              _selectedCategory = category;
              _selectedPurpose = purpose;
            });
          },
        );
      },
    );
  }

  // ═══════════════════════════════ build ═══════════════════════════════

  @override
  Widget build(BuildContext context) {
    final privacyActive = ref.watch(isOutingPrivacyActiveProvider);
    // Rollover first: it reuses the filter with another month, then drops
    // the cache so the list below is the period the user actually picked.
    // Always computed so provider watches stay in the same order.
    final rolloverRaw = _previousMonthRollover();
    final rollover = privacyActive ? 0.0 : rolloverRaw;
    final rolloverMonth = rollover == 0 ? null : _rolloverMonthName();
    final filtered = _getFilteredTransactions();
    final grouped = _groupTransactions(filtered);
    final headers = grouped.keys.toList();
    final activeOuting = ref.watch(activeOutingProvider);
    final income = _totalMatchedIncome(filtered);
    final expense = _totalMatchedExpense(filtered);
    final outings = ref.watch(outingProvider);

    // inflow = total in + rollover; net = inflow − total out.
    final inflow = income + rollover;
    final net = inflow - expense;
    final netLabel =
        net >= 0 ? '+${_activityMoney(net)}' : '-${_activityMoney(net)}';
    final retained =
        inflow <= 0 ? 0 : ((inflow - expense) / inflow * 100).round();
    final spent = inflow <= 0 ? 0 : (expense / inflow * 100).round();
    final pendingSms = ref.watch(detectionQueueProvider).length;
    final tiles = _activityTiles(
      privacyActive: privacyActive,
      activeOuting: activeOuting,
      pendingSms: pendingSms,
      netLabel: netLabel,
      net: net,
      income: income,
      expense: expense,
      retained: retained,
      spent: spent,
      rollover: rollover,
      rolloverMonth: rolloverMonth,
      filtered: filtered,
      headers: headers,
      grouped: grouped,
      outings: outings,
    );
    return Scaffold(
      backgroundColor: _Act.canvas(context),
      body: Column(
        children: [
          _activityHeader(context),
          Expanded(
            child: ListView.builder(
              physics: const BouncingScrollPhysics(),
              padding: EdgeInsets.fromLTRB(
                16,
                12,
                16,
                96 + MediaQuery.paddingOf(context).bottom,
              ),
              itemCount: tiles.length,
              itemBuilder: (context, index) => tiles[index](),
            ),
          ),
        ],
      ),
    );
  }

  Widget Function() _lazyDateGroup(
    String header,
    List<model.Transaction> rows,
    List<Outing> outings,
    bool gap,
  ) {
    return () => Padding(
      padding: EdgeInsets.only(top: gap ? 16 : 0),
      child: _buildDateGroup(header, rows, outings),
    );
  }

  List<Widget Function()> _activityTiles({
    required bool privacyActive,
    required Outing? activeOuting,
    required int pendingSms,
    required String netLabel,
    required double net,
    required double income,
    required double expense,
    required int retained,
    required int spent,
    required double rollover,
    required String? rolloverMonth,
    required List<model.Transaction> filtered,
    required List<String> headers,
    required Map<String, List<model.Transaction>> grouped,
    required List<Outing> outings,
  }) {
    return [
      if (privacyActive && activeOuting != null)
        () => _PrivacyNotice(tripTitle: activeOuting.title),
      if (!privacyActive && pendingSms > 0) ...[
        () => _smsReviewPill(context, pendingSms),
        () => const SizedBox(height: 16),
      ],
      if (!privacyActive) ...[
        () => _periodPills(context),
        () => const SizedBox(height: 8),
      ],
      () => _heroCard(
        context,
        netLabel: netLabel,
        net: net,
        income: income,
        expense: expense,
        retained: retained,
        spent: spent,
        rollover: rollover,
        rolloverMonth: rolloverMonth,
      ),
      if (_customChipFiltersActive) ...[
        () => const SizedBox(height: 16),
        () => _filterTokenRow(context),
      ],
      () => const SizedBox(height: 16),
      () => Row(
        children: [
          Text(
            'ALL LEDGER ENTRIES',
            style: _Act.text(
              context,
              fontSize: 12,
              fontWeight: FontWeight.w700,
              letterSpacing: 0.6,
              color: _Act.muted(context),
            ),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(
              color: const Color(0xFFE2E8F0).withValues(alpha: 0.7),
              borderRadius: BorderRadius.circular(999),
            ),
            child: Text(
              '${filtered.length} records',
              style: _Act.text(
                context,
                fontSize: 10,
                fontWeight: FontWeight.w700,
                color: const Color(0xFF334155),
              ),
            ),
          ),
        ],
      ),
      () => const SizedBox(height: 12),
      if (filtered.isEmpty)
        () => _Act.cardBox(
          context,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 28),
            child: SxEmptyState(
              icon: LucideIcons.receipt,
              message: _emptyStateMessage(),
              actionLabel: _emptyStateActionLabel(),
              onAction: _emptyStateAction(),
            ),
          ),
        )
      else
        for (var hi = 0; hi < headers.length; hi++)
          _lazyDateGroup(headers[hi], grouped[headers[hi]]!, outings, hi > 0),
    ];
  }

  Widget _activityHeader(BuildContext context) {
    final top = MediaQuery.paddingOf(context).top;
    return ClipRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          padding: EdgeInsets.fromLTRB(20, top + 12, 16, 12),
          decoration: BoxDecoration(
            color: _Act.canvas(context).withValues(alpha: 0.9),
            border: Border(
              bottom: BorderSide(
                color: _Act.border(context).withValues(alpha: 0.6),
              ),
            ),
          ),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Activity',
                      style: _Act.text(
                        context,
                        fontSize: 24,
                        fontWeight: FontWeight.w800,
                        letterSpacing: -0.4,
                        color: _Act.inkDeep(context),
                        height: 1.1,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Categorized cashflow & ledger',
                      style: _Act.text(
                        context,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: _Act.slate(context),
                      ),
                    ),
                  ],
                ),
              ),
              _roundIconButton(
                context,
                icon: LucideIcons.search,
                tooltip: 'Search',
                onTap:
                    () => showSearch(
                      context: context,
                      delegate: TransactionSearchDelegate(ref),
                    ),
              ),
              const SizedBox(width: 8),
              _roundIconButton(
                context,
                icon: LucideIcons.slidersHorizontal,
                tooltip: 'Filters',
                showDot: _customChipFiltersActive,
                onTap: () => _showAdvancedFiltersSheet(context),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _roundIconButton(
    BuildContext context, {
    required IconData icon,
    required String tooltip,
    required VoidCallback onTap,
    bool showDot = false,
  }) {
    return Tooltip(
      message: tooltip,
      child: Material(
        color: _Act.card(context),
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: Ink(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _Act.card(context),
              border: Border.all(
                color: _Act.border(context).withValues(alpha: 0.8),
              ),
              boxShadow: _Act.controlShadow(context),
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                Icon(icon, size: 16, color: _Act.slate(context)),
                if (showDot)
                  Positioned(
                    top: 8,
                    right: 8,
                    child: Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        color: _Act.emerald,
                        shape: BoxShape.circle,
                        border: Border.all(color: _Act.card(context), width: 2),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _smsReviewPill(BuildContext context, int count) {
    final title = count == 1 ? '1 new transaction' : '$count new transactions';
    return Material(
      color: _Act.mint,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => context.push('/detected-sms'),
        child: Ink(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: _Act.mint,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _Act.mintBorder.withValues(alpha: 0.9)),
          ),
          child: Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: _Act.card(context),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: _Act.mintBorder.withValues(alpha: 0.7),
                  ),
                ),
                child: const Icon(
                  LucideIcons.messageCircle,
                  size: 16,
                  color: _Act.emeraldDeep,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: _Act.text(
                              context,
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: _Act.inkDeep(context),
                            ),
                          ),
                        ),
                        const SizedBox(width: 6),
                        Container(
                          width: 6,
                          height: 6,
                          decoration: const BoxDecoration(
                            color: _Act.emerald,
                            shape: BoxShape.circle,
                          ),
                        ),
                      ],
                    ),
                    Text(
                      'Auto-detected from bank SMS & UPI',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: _Act.text(
                        context,
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                        color: _Act.slate(context),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: _Act.emeraldDeep,
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'Review',
                      style: _Act.text(
                        context,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                    const Icon(
                      LucideIcons.chevronRight,
                      size: 14,
                      color: Colors.white,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _periodPills(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      physics: const BouncingScrollPhysics(),
      child: Row(
        children: [
          _periodPill(
            context,
            label: 'This Month',
            selected: _scope == _DateScope.thisMonth,
            onTap: () => _onScopeSelected(_DateScope.thisMonth),
          ),
          _periodPill(
            context,
            label: 'Previous Month',
            selected: _scope == _DateScope.lastMonth,
            onTap: () => _onScopeSelected(_DateScope.lastMonth),
          ),
          _periodPill(
            context,
            label: 'All time',
            selected: _scope == _DateScope.all,
            onTap: () => _onScopeSelected(_DateScope.all),
          ),
          _periodPill(
            context,
            label: _scope == _DateScope.custom ? _scopeLabel : 'Custom',
            selected: _scope == _DateScope.custom,
            icon: LucideIcons.calendar,
            onTap: () => _onScopeSelected(_DateScope.custom),
          ),
        ],
      ),
    );
  }

  Widget _periodPill(
    BuildContext context, {
    required String label,
    required bool selected,
    required VoidCallback onTap,
    IconData? icon,
  }) {
    return Padding(
      padding: const EdgeInsets.only(right: 6),
      child: Material(
        color: selected ? _Act.emerald : _Act.card(context),
        borderRadius: BorderRadius.circular(999),
        child: InkWell(
          borderRadius: BorderRadius.circular(999),
          onTap: onTap,
          child: Ink(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              color: selected ? _Act.emerald : _Act.card(context),
              borderRadius: BorderRadius.circular(999),
              border:
                  selected
                      ? null
                      : Border.all(
                        color: _Act.border(context).withValues(alpha: 0.8),
                      ),
              boxShadow: selected ? null : _Act.controlShadow(context),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (icon != null) ...[
                  Icon(
                    icon,
                    size: 14,
                    color: selected ? Colors.white : _Act.slate(context),
                  ),
                  const SizedBox(width: 4),
                ],
                Text(
                  label,
                  style: _Act.text(
                    context,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: selected ? Colors.white : _Act.slate(context),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _heroCard(
    BuildContext context, {
    required String netLabel,
    required double net,
    required double income,
    required double expense,
    required int retained,
    required int spent,
    required double rollover,
    required String? rolloverMonth,
  }) {
    final showRollover = rollover != 0 && rolloverMonth != null;
    final retainedFlex = retained <= 0 ? 0 : retained;
    final spentFlex = spent <= 0 ? 0 : spent;
    return _Act.cardBox(
      context,
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      net >= 0 ? 'NET CASHFLOW (SURPLUS)' : 'NET CASHFLOW',
                      style: _Act.text(
                        context,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.6,
                        color: _Act.muted(context),
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      netLabel,
                      style: _Act.text(
                        context,
                        fontSize: 30,
                        fontWeight: FontWeight.w800,
                        letterSpacing: -0.6,
                        color: _Act.inkDeep(context),
                        height: 1,
                      ),
                    ),
                    if (showRollover) ...[
                      const SizedBox(height: 10),
                      _rolloverPill(context, rollover, rolloverMonth),
                    ],
                  ],
                ),
              ),
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color:
                      _Act._dark(context)
                          ? _Act.emerald.withValues(alpha: 0.16)
                          : _Act.mint,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  net >= 0 ? LucideIcons.trendingUp : LucideIcons.trendingDown,
                  size: 20,
                  color: net >= 0 ? _Act.emeraldDeep : const Color(0xFFE11D48),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Text(
                'Retained ($retained%)',
                style: _Act.text(
                  context,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: _Act.emeraldDeep,
                ),
              ),
              const Spacer(),
              Text(
                'Spent ($spent%)',
                style: _Act.text(
                  context,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: const Color(0xFFE11D48),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: SizedBox(
              height: 6,
              child: Row(
                children: [
                  if (retainedFlex > 0)
                    Expanded(
                      flex: retainedFlex,
                      child: const ColoredBox(color: Color(0xFF34D399)),
                    ),
                  if (spentFlex > 0)
                    Expanded(
                      flex: spentFlex,
                      child: const ColoredBox(color: Color(0xFFFB7185)),
                    ),
                  if (retainedFlex == 0 && spentFlex == 0)
                    const Expanded(child: ColoredBox(color: Color(0xFFE2E8F0))),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          Container(height: 1, color: _Act.borderSoft(context)),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: _flowCell(
                  context,
                  label: 'Total In',
                  value: '+${_activityMoney(income)}',
                  valueColor: _Act.emeraldDeep,
                  icon: LucideIcons.arrowUp,
                  iconBg: _Act.emerald.withValues(alpha: 0.1),
                  iconColor: _Act.emeraldDeep,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _flowCell(
                  context,
                  label: 'Total Out',
                  value: '-${_activityMoney(expense)}',
                  valueColor:
                      CategoryToneLookup.resolve(
                        isExpense: true,
                        isTransfer: false,
                      ).fg,
                  icon: LucideIcons.arrowDown,
                  iconBg: const Color(0xFFE2E8F0).withValues(alpha: 0.7),
                  iconColor: _Act.slate(context),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _rolloverPill(BuildContext context, double rollover, String month) {
    final positive = rollover >= 0;
    final amountColor = positive ? _Act.emeraldDeep : const Color(0xFFE11D48);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color:
            _Act._dark(context)
                ? _Act.emerald.withValues(alpha: 0.14)
                : const Color(0xFFF0FDF4),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(LucideIcons.refreshCw, size: 14, color: amountColor),
          const SizedBox(width: 6),
          Flexible(
            child: Text.rich(
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              TextSpan(
                style: _Act.text(
                  context,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: _Act.slate(context),
                ),
                children: [
                  const TextSpan(text: 'Includes '),
                  TextSpan(
                    text: '${positive ? '+' : '-'}${_activityMoney(rollover)}',
                    style: _Act.text(
                      context,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: amountColor,
                    ),
                  ),
                  TextSpan(text: ' rollover from $month'),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _flowCell(
    BuildContext context, {
    required String label,
    required String value,
    required Color valueColor,
    required IconData icon,
    required Color iconBg,
    required Color iconColor,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color:
            Theme.of(context).brightness == Brightness.dark
                ? SoftPalette.darkSurface
                : const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _Act.borderSoft(context)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label.toUpperCase(),
                  style: _Act.text(
                    context,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.4,
                    color: _Act.muted(context),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: _Act.text(
                    context,
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    color: valueColor,
                  ),
                ),
              ],
            ),
          ),
          Container(
            width: 28,
            height: 28,
            decoration: BoxDecoration(color: iconBg, shape: BoxShape.circle),
            child: Icon(icon, size: 14, color: iconColor),
          ),
        ],
      ),
    );
  }

  Widget _filterTokenRow(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            child: Row(
              children: [
                if (_selectedSources.isNotEmpty)
                  _dismissChip(
                    context,
                    label: 'Accounts: ${_selectedSources.join(', ')}',
                    onDismiss:
                        () => setState(() => _selectedSources = <String>{}),
                  ),
                if (_selectedCategory != 'All')
                  _dismissChip(
                    context,
                    label: 'Category: $_selectedCategory',
                    onDismiss: () => setState(() => _selectedCategory = 'All'),
                  ),
                if (_selectedPurpose != 'All')
                  _dismissChip(
                    context,
                    label: 'Purpose: $_selectedPurpose',
                    onDismiss: () => setState(() => _selectedPurpose = 'All'),
                  ),
                if (_selectedSpendType != 'All')
                  _dismissChip(
                    context,
                    label: _selectedSpendType,
                    onDismiss: () => setState(() => _selectedSpendType = 'All'),
                  ),
                if (_selectedContributor != 'All')
                  _dismissChip(
                    context,
                    label: _selectedContributor,
                    onDismiss:
                        () => setState(() => _selectedContributor = 'All'),
                  ),
                if (_selectedFriend != 'All')
                  _dismissChip(
                    context,
                    label: _selectedFriend,
                    onDismiss: () => setState(() => _selectedFriend = 'All'),
                  ),
              ],
            ),
          ),
        ),
        TextButton(
          onPressed: _clearAllFilters,
          style: TextButton.styleFrom(
            foregroundColor: _Act.emerald,
            padding: const EdgeInsets.only(left: 12),
            minimumSize: Size.zero,
            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
          ),
          child: Text(
            'Reset',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: _Act.emerald,
            ),
          ),
        ),
      ],
    );
  }

  Widget _dismissChip(
    BuildContext context, {
    required String label,
    required VoidCallback onDismiss,
  }) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => _showAdvancedFiltersSheet(context),
          borderRadius: BorderRadius.circular(999),
          child: Ink(
            padding: const EdgeInsets.fromLTRB(12, 6, 6, 6),
            decoration: BoxDecoration(
              color: _Act.card(context),
              borderRadius: BorderRadius.circular(999),
              border: Border.all(color: _Act.borderSoft(context)),
              boxShadow:
                  dark
                      ? null
                      : const [
                        BoxShadow(
                          color: Color.fromRGBO(15, 23, 42, 0.04),
                          offset: Offset(0, 4),
                          blurRadius: 16,
                          spreadRadius: -2,
                        ),
                      ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  label,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: _Act.inkDeep(context),
                  ),
                ),
                const SizedBox(width: 2),
                GestureDetector(
                  onTap: onDismiss,
                  child: Padding(
                    padding: const EdgeInsets.all(4),
                    child: Icon(
                      LucideIcons.x,
                      size: 12,
                      color: _Act.muted(context),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  String _activityMoney(num value) => NumberFormat.currency(
    locale: 'en_IN',
    symbol: '₹',
    decimalDigits: 0,
  ).format(value.abs());

  double _dayNet(List<model.Transaction> txs) {
    var net = 0.0;
    for (final tx in txs) {
      if (tx.isTransfer) continue;
      final amount = _sumMatched(_matchingSplits(tx));
      net += tx.isExpense ? -amount : amount;
    }
    return net;
  }

  Widget _buildDateGroup(
    String header,
    List<model.Transaction> txs,
    List<Outing> outings,
  ) {
    final day = txs.first.date;
    final dateLabel = DateFormat('d MMM').format(day);
    final net = _dayNet(txs);
    final positive = net >= 0;
    final netText =
        positive
            ? 'Net: +${_activityMoney(net)}'
            : 'Net: -${_activityMoney(net)}';
    return _Act.cardBox(
      context,
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Row(
              children: [
                Text(
                  header == 'Today' || header == 'Yesterday'
                      ? header
                      : dateLabel,
                  style: _Act.text(
                    context,
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.2,
                    color: _Act.inkDeep(context),
                  ),
                ),
                if (header == 'Today' || header == 'Yesterday') ...[
                  const SizedBox(width: 8),
                  Text(
                    dateLabel,
                    style: _Act.text(
                      context,
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      color: _Act.muted(context),
                    ),
                  ),
                ],
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 2,
                  ),
                  decoration: BoxDecoration(
                    color: positive ? _Act.mint : const Color(0xFFF1F5F9),
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(
                      color:
                          positive
                              ? _Act.mintBorder.withValues(alpha: 0.8)
                              : _Act.border(context),
                    ),
                  ),
                  child: Text(
                    netText,
                    style: _Act.text(
                      context,
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      color:
                          positive ? _Act.emeraldDeep : const Color(0xFF334155),
                    ),
                  ),
                ),
              ],
            ),
          ),
          for (var i = 0; i < txs.length; i++) ...[
            if (i > 0)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Divider(
                  height: 1,
                  thickness: 1,
                  color:
                      _Act._dark(context)
                          ? const Color(0xFF3F3F46)
                          : _Act.border(context).withValues(alpha: 0.72),
                ),
              ),
            _buildTileOrGroup(txs[i], outings),
          ],
        ],
      ),
    );
  }

  Widget _buildTileOrGroup(model.Transaction tx, List<Outing> outings) {
    // A friend return is a leaf, never a parent. It carries its trip's
    // outingId, so the lookup below found it in its own trip's return list and
    // made it its own parent — _buildParentGroupTile then rendered it with the
    // trip's netted total (₹800 left of a ₹1,200 trip) instead of the ₹400 that
    // actually came back.
    if (tx.isFriendReturn) return _buildTile(tx, outings);

    List<model.Transaction> children = [];
    if (tx.time == 'OutingSummary' && tx.outingId != null) {
      children = _childrenByOutingId[tx.outingId!] ?? [];
    } else {
      children = _childrenByParentId[tx.id] ?? [];
    }

    if (children.isEmpty) {
      return _buildTile(tx, outings);
    }

    return _buildParentGroupTile(tx, children, outings);
  }

  Widget _buildParentGroupTile(
    model.Transaction parentTx,
    List<model.Transaction> children,
    List<Outing> outings,
  ) {
    final gross = parentTx.time == 'OutingSummary'
        ? (_grossByOuting[parentTx.outingId] ?? parentTx.amount)
        : parentTx.amount;
    final totalReturned = children.fold<double>(0, (sum, c) => sum + c.amount);
    final net = (gross - totalReturned).clamp(0.0, double.infinity);

    Outing? outing;
    if (parentTx.outingId != null && parentTx.outingId!.isNotEmpty) {
      outing = outings.where((o) => o.id == parentTx.outingId).firstOrNull;
    }

    final totalMembers = outing != null ? outing.members.length : 4;
    final friendsCount = totalMembers > 1 ? (totalMembers - 1) : 3;

    final List<({String friendName, double amount})> returnedRows = [];
    final List<({String friendName, double amount})> pendingRows = [];

    for (final c in children) {
      String m = c.merchant.trim();
      if (m.toLowerCase().startsWith('from ')) m = m.substring(5).trim();
      if (m.toLowerCase().endsWith(' returned')) {
        m = m.substring(0, m.length - 9).trim();
      }
      returnedRows.add((friendName: m, amount: c.amount));
    }

    if (outing != null && gross > 0) {
      final perMemberShare = gross / totalMembers;
      for (final member in outing.members) {
        if (member.name.toLowerCase() == 'you') continue;
        final memberName = member.name.trim();
        final returnedByMember = children
            .where(
              (c) =>
                  c.merchant.toLowerCase().contains(memberName.toLowerCase()),
            )
            .fold<double>(0, (s, c) => s + c.amount);
        final pending = (perMemberShare - returnedByMember).clamp(
          0.0,
          double.infinity,
        );
        if (pending >= 1.0) {
          pendingRows.add((friendName: memberName, amount: pending));
        }
      }
    }

    final subtitle = 'Split with $friendsCount friends';

    // Only what is NOT its own transaction stays inside the parent card.
    // A friend return IS a real ledger row, so folding it in here put two
    // transactions on one card; it gets its own card below instead. Pending
    // amounts are not transactions — nobody has paid them yet — so they stay
    // as context on the expense they belong to.
    return _buildTile(
      parentTx,
      outings,
      overrideAmount: net,
      overrideGrossAmount: gross > net ? gross : null,
      overrideSubtitle: subtitle,
      dropdownChild: null,
    );
  }

  Widget _buildTile(
    model.Transaction tx,
    List<Outing> outings, {
    double? overrideAmount,
    double? overrideGrossAmount,
    String? overrideSubtitle,
    Widget? dropdownChild,
  }) {
    // Friend returns carry an outingId but should render as normal cards,
    // not as outing/Trip cards.
    final isFriendReturn = tx.isFriendReturn;

    double? outingTotal = overrideGrossAmount;
    String? outingName;
    Outing? outing;
    if (tx.outingId != null && !isFriendReturn) {
      outing = outings.where((o) => o.id == tx.outingId).firstOrNull;
      if (outing != null) {
        outingName = outing.title;
        if (outingTotal == null) {
          final gross = _grossByOuting[tx.outingId];
          if (tx.time == 'OutingSummary' &&
              gross != null &&
              gross > tx.amount + 0.009) {
            outingTotal = gross;
          }
        }
      }
    }

    final isOuting =
        !isFriendReturn &&
        (tx.time == 'OutingSummary' ||
            tx.time == 'Trip' ||
            tx.outingId != null);
    final matched = _matchingSplits(tx);
    final matchedCategory = _summariseNamesTop(
      _distinctInOrder(matched.map((m) => m.category)),
    );
    final matchedPurpose = _summariseNamesTop(
      _distinctInOrder(matched.map((m) => m.purpose)),
    );
    final matchedAmount = overrideAmount ?? _sumMatched(matched);
    final displayTitle = TransactionDisplayUtils.displayTitle(tx);
    final headline = TransactionDisplayUtils.listHeadline(tx);
    final isTransfer =
        tx.isTransfer || tx.category.trim().toLowerCase() == 'transfer';
    final tileCategory =
        isOuting ? (outing?.category ?? 'Trip') : matchedCategory;

    // ── Return info for friend return cards ──
    String? returnInfo;
    if (isFriendReturn && tx.outingId != null) {
      final outingReturns = _childrenByOutingId[tx.outingId!] ?? [];
      final totalReturns = outingReturns.length;
      final thisIndex = outingReturns.indexWhere((r) => r.id == tx.id);
      final returnNumber = thisIndex >= 0 ? thisIndex + 1 : totalReturns;

      // Find total members (excluding 'you') to show "X of Y returns"
      final returnOuting =
          outings.where((o) => o.id == tx.outingId).firstOrNull;
      final totalExpected =
          returnOuting != null
              ? returnOuting.members
                  .where((m) => m.name.toLowerCase() != 'you')
                  .length
              : totalReturns;
      returnInfo = '$returnNumber of $totalExpected returns';
    }

    final accountLabel =
        tx.bankName.trim().isNotEmpty
            ? tx.bankName.trim()
            : (tx.accountLast4.trim().isNotEmpty
                ? '${tx.account} •••• ${tx.accountLast4}'
                : tx.account);
    final transferTo = tx.isAtmTransfer ? '' : (tx.transferTo ?? '');
    final filterActive =
        _selectedPurpose != 'All' || _selectedCategory != 'All';
    final isPartialMatch =
        tx.isSplitExpense &&
        filterActive &&
        (tx.amount - matchedAmount).abs() >= 0.01;

    return _ActivityLedgerRow(
      merchant: headline,
      category: tileCategory,
      timeLabel: DateFormat('h:mm a').format(tx.date.toLocal()),
      accountLabel: accountLabel,
      amount: matchedAmount,
      parentTotal: isPartialMatch ? tx.amount : null,
      isExpense: tx.isExpense,
      isTransfer: isTransfer,
      purpose: matchedPurpose,
      splitBadge: _badgeLabel(tx),
      itemsLabel: displayTitle.itemsLabel,
      outingName: outingName,
      outingTotal: outingTotal,
      returnInfo: returnInfo,
      transferTo: transferTo,
      overrideSubtitle: overrideSubtitle,
      dropdownChild: dropdownChild,
      onTap: () {
        if (tx.time == 'OutingSummary') {
          context.push('/outing-detail/${tx.outingId}');
        } else if (tx.outingId != null && tx.time == 'Trip') {
          context.push('/outing-expense/${tx.outingId}/${tx.id}');
        } else {
          context.push('/transaction/${tx.id}');
        }
      },
    );
  }
}

class _ActivityLedgerRow extends ConsumerStatefulWidget {
  const _ActivityLedgerRow({
    required this.merchant,
    required this.category,
    required this.timeLabel,
    required this.accountLabel,
    required this.amount,
    required this.isExpense,
    required this.isTransfer,
    required this.onTap,
    this.parentTotal,
    this.purpose,
    this.splitBadge,
    this.itemsLabel,
    this.outingName,
    this.outingTotal,
    this.returnInfo,
    this.transferTo = '',
    this.overrideSubtitle,
    this.dropdownChild,
  });

  final String merchant;
  final String category;
  final String timeLabel;
  final String accountLabel;
  final double amount;
  final double? parentTotal;
  final bool isExpense;
  final bool isTransfer;
  final VoidCallback onTap;
  final String? purpose;
  final String? splitBadge;
  final String? itemsLabel;
  final String? outingName;
  final double? outingTotal;
  final String? returnInfo;
  final String transferTo;
  final String? overrideSubtitle;
  final Widget? dropdownChild;

  @override
  ConsumerState<_ActivityLedgerRow> createState() => _ActivityLedgerRowState();
}

class _ActivityLedgerRowState extends ConsumerState<_ActivityLedgerRow> {
  bool _revealed = false;

  @override
  Widget build(BuildContext context) {
    final isPrivate = ref.watch(privateModeProvider);
    final mask = isPrivate && !_revealed;
    final storedColor = ref
        .watch(categoryProvider)
        .colorHexFor(widget.category);
    final tone = CategoryToneLookup.resolve(
      storedHex: storedColor,
      isExpense: widget.isExpense,
      isTransfer: widget.isTransfer,
      isDark: Theme.of(context).brightness == Brightness.dark,
    );
    final icon =
        CategoryIcon.resolve(
          widget.isTransfer ? 'Transfer' : widget.category,
        ).icon;
    final money = NumberFormat.currency(
      locale: 'en_IN',
      symbol: '₹',
      decimalDigits: 0,
    ).format(widget.amount.abs());
    final String amountText;
    final String kind;
    final Color amountColor;
    if (mask) {
      amountText = PrivateModeService.mask;
      kind =
          widget.isTransfer
              ? 'Internal'
              : (widget.isExpense ? 'Debit' : 'Credit');
      amountColor = _Act.muted(context);
    } else if (widget.isTransfer) {
      amountText = money;
      kind = 'Internal';
      amountColor = const Color(0xFF334155);
    } else if (widget.isExpense) {
      amountText = '-$money';
      kind = 'Debit';
      amountColor = _Act.inkDeep(context);
    } else {
      amountText = '+$money';
      kind = 'Credit';
      amountColor = _Act.emeraldDeep;
    }

    final purpose = (widget.purpose ?? '').trim();
    final account = widget.accountLabel.trim();
    final metaParts = <String>[
      widget.timeLabel,
      if (widget.overrideSubtitle != null &&
          widget.overrideSubtitle!.trim().isNotEmpty)
        widget.overrideSubtitle!.trim()
      else ...[
        if (!widget.isTransfer && purpose.isNotEmpty)
          (widget.parentTotal != null ? 'Matched: $purpose' : purpose),
        if (widget.isTransfer && widget.transferTo.isNotEmpty)
          '$account → ${widget.transferTo}'
        else if (account.isNotEmpty)
          account,
      ],
    ];
    final extras = <String>[
      if (widget.itemsLabel != null && widget.itemsLabel!.isNotEmpty)
        widget.itemsLabel!,
      if (widget.outingName != null && widget.outingName!.isNotEmpty)
        widget.outingName!,
      if (widget.returnInfo != null && widget.returnInfo!.isNotEmpty)
        widget.returnInfo!,
      if (!mask && widget.outingTotal != null)
        'of ${NumberFormat.currency(locale: 'en_IN', symbol: '₹', decimalDigits: 0).format(widget.outingTotal)}',
    ];

    final catLower = widget.category.trim().toLowerCase();
    final badgeLower = (widget.splitBadge ?? '').trim().toLowerCase();
    final isFriendReturn = badgeLower == 'friend return' ||
        badgeLower == 'friend returns' ||
        catLower == 'friend returns' ||
        catLower == 'friend return';

    return GestureDetector(
      onLongPressStart:
          isPrivate
              ? (_) {
                HapticFeedback.mediumImpact();
                setState(() => _revealed = true);
              }
              : null,
      onLongPressEnd:
          isPrivate ? (_) => setState(() => _revealed = false) : null,
      onLongPressCancel:
          isPrivate ? () => setState(() => _revealed = false) : null,
      child: AnimatedTapCard(
        onTap: widget.onTap,
        child: Container(
          margin: const EdgeInsets.only(top: 8),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: _Act.card(context),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: tone.bg,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, size: 18, color: tone.fg),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            widget.merchant,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: _Act.text(
                              context,
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                              color: _Act.inkDeep(context),
                            ),
                          ),
                        ),

                        if (isFriendReturn) ...[
                          const SizedBox(width: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 6,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: _Act.mint,
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              'Friend Return',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: _Act.text(
                                context,
                                fontSize: 10,
                                fontWeight: FontWeight.w700,
                                color: _Act.emeraldDeep,
                              ),
                            ),
                          ),
                        ] else ...[
                          if (widget.category.trim().isNotEmpty) ...[
                            const SizedBox(width: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 6,
                                vertical: 2,
                              ),
                              decoration: BoxDecoration(
                                color: tone.bg,
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                widget.category,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: _Act.text(
                                  context,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w700,
                                  color: tone.fg,
                                ),
                              ),
                            ),
                          ],
                          if (widget.splitBadge != null &&
                              widget.splitBadge!.isNotEmpty &&
                              badgeLower != catLower) ...[
                            const SizedBox(width: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 6,
                                vertical: 2,
                              ),
                              decoration: BoxDecoration(
                                color: _Act.mint,
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                widget.splitBadge!,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: _Act.text(
                                  context,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w700,
                                  color: _Act.emeraldDeep,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      metaParts.join(' · '),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: _Act.text(
                        context,
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                        color: _Act.slate(context),
                      ),
                    ),
                    if (extras.isNotEmpty)
                      Text(
                        extras.join(' · '),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: _Act.text(
                          context,
                          fontSize: 11,
                          fontWeight: FontWeight.w500,
                          color: _Act.muted(context),
                        ),
                      ),
                    if (widget.dropdownChild != null) widget.dropdownChild!,
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    amountText,
                    style: _Act.text(
                      context,
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.3,
                      color: amountColor,
                    ),
                  ),
                  if (!mask && widget.parentTotal != null)
                    Text(
                      'of ${NumberFormat.currency(locale: 'en_IN', symbol: '₹', decimalDigits: 0).format(widget.parentTotal)}',
                      style: _Act.text(
                        context,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        color: _Act.muted(context),
                      ),
                    )
                  else
                    Text(
                      kind,
                      style: _Act.text(
                        context,
                        fontSize: 10,
                        fontWeight: FontWeight.w500,
                        color:
                            widget.isTransfer
                                ? _Act.muted(context)
                                : (widget.isExpense
                                    ? _Act.muted(context)
                                    : _Act.emeraldDeep),
                      ),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

abstract final class _Act {
  static const emerald = Color(0xFF10B981);
  static const emeraldDeep = Color(0xFF059669);
  static const mint = Color(0xFFECFDF5);
  static const mintBorder = Color(0xFFA7F3D0);

  static bool _dark(BuildContext context) =>
      Theme.of(context).brightness == Brightness.dark;

  static Color canvas(BuildContext context) =>
      _dark(context) ? SoftPalette.darkBg : const Color(0xFFF8F9FC);

  static Color card(BuildContext context) =>
      _dark(context) ? SoftPalette.darkCard : const Color(0xFFFFFFFF);

  static Color border(BuildContext context) =>
      _dark(context) ? SoftPalette.darkBorder : const Color(0xFFE2E8F0);

  static Color borderSoft(BuildContext context) =>
      _dark(context) ? SoftPalette.darkBorder : const Color(0xFFF1F5F9);

  static Color inkDeep(BuildContext context) =>
      _dark(context) ? SoftPalette.darkInk : const Color(0xFF020617);

  static Color slate(BuildContext context) =>
      _dark(context) ? SoftPalette.darkMuted : const Color(0xFF64748B);

  static Color muted(BuildContext context) =>
      _dark(context) ? SoftPalette.darkMuted : const Color(0xFF94A3B8);

  static List<BoxShadow>? controlShadow(BuildContext context) =>
      _dark(context)
          ? null
          : const [
            BoxShadow(
              color: Color.fromRGBO(0, 0, 0, 0.02),
              offset: Offset(0, 1),
              blurRadius: 2,
            ),
          ];

  static List<BoxShadow>? cardShadow(BuildContext context) =>
      _dark(context)
          ? null
          : const [
            BoxShadow(
              color: Color.fromRGBO(15, 23, 42, 0.03),
              offset: Offset(0, 4),
              blurRadius: 16,
            ),
          ];

  static TextStyle text(
    BuildContext context, {
    required double fontSize,
    FontWeight fontWeight = FontWeight.w600,
    Color? color,
    double? letterSpacing,
    double? height,
  }) {
    return GoogleFonts.plusJakartaSans(
      fontSize: fontSize,
      fontWeight: fontWeight,
      color: color,
      letterSpacing: letterSpacing,
      height: height,
    );
  }

  static Widget cardBox(
    BuildContext context, {
    required Widget child,
    EdgeInsetsGeometry? padding,
  }) {
    return Container(
      width: double.infinity,
      padding: padding ?? const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: card(context),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: borderSoft(context)),
        boxShadow: cardShadow(context),
      ),
      child: child,
    );
  }
}

// ═══════════════════════════ shared chip ═══════════════════════════

/// The one chip on this screen.
///
/// Purpose, date, and category rows used to be three different widgets with
/// three different heights, radii, borders, and selection treatments — the
/// category row even used a solid brand fill plus a coloured glow, which made
/// a filter louder than the money on the cards below it. Selection is now
/// expressed as a soft tinted fill with a matching border, everywhere.
class _FilterChip extends StatelessWidget {
  const _FilterChip({
    required this.label,
    required this.selected,
    required this.onTap,
    this.icon,
    this.tint,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;
  final IconData? icon;

  /// Optional identity colour (purpose chips). Defaults to the brand accent.
  final Color? tint;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final accent = tint ?? t.primary;
    final ink =
        selected
            ? (tint != null ? AppColors.onTint(tint!) : t.primary)
            : t.textSecondary;

    // Spacing between chips is the row's job (see [_kChipGap]) — a chip that
    // pads itself leaves a trailing gutter after the last one.
    return AnimatedTapCard(
      onTap: onTap,
      scaleDown: 0.94,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        curve: Curves.easeOutCubic,
        height: _kChipHeight,
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm),
        decoration: BoxDecoration(
          color: selected ? (tint ?? t.primarySoft) : t.card,
          borderRadius: AppRadius.pillR,
          border: Border.all(
            color:
                selected
                    ? (tint != null
                        ? Colors.transparent
                        : accent.withValues(alpha: 0.45))
                    : t.border,
            width: 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null) ...[
              Icon(icon, size: 14, color: ink),
              const SizedBox(width: AppSpacing.xxs + 2),
            ],
            Text(
              label,
              style: AppType.label(ink).copyWith(
                fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Sliver delegate for the pinned category bar.

/// The period selector, rendered as a tappable subtitle under the screen
/// title.
///
/// It began as three pills in a row of their own, which cost a full line of
/// vertical space, offered no way to reach "all time" except re-tapping the
/// active pill, and competed visually with the purpose and category rows
/// beneath it. As a title subtitle it reads as *scope* — the frame the whole
/// screen is viewed through — rather than as a fourth peer filter.

/// Purpose picker.
///
/// Purpose is a *mode* — you are looking at Personal money or Family money —
/// not one of many optional tags, so it gets a segmented control with a
/// sliding indicator rather than a row of loose scrolling pills. A segmented
/// track also shows every option at once, so you can see there IS a Family
/// view without discovering it by swiping sideways.
///
/// Above four purposes the segments would get too narrow to read, so it falls
/// back to the scrolling chip row at that point.
class PurposeSelector extends StatelessWidget {
  final List<String> purposes;
  final String selected;
  final ValueChanged<String> onChanged;

  const PurposeSelector({
    super.key,
    required this.purposes,
    required this.selected,
    required this.onChanged,
  });

  static const double _height = 38.0;
  static const double _inset = 3.0;

  @override
  Widget build(BuildContext context) {
    if (purposes.length > 4) {
      return _PurposeChipRow(
        purposes: purposes,
        selected: selected,
        onChanged: onChanged,
      );
    }

    final t = context.tokens;
    final index = purposes.indexOf(selected);
    final activeIndex = index < 0 ? 0 : index;
    final tint = _purposeTint(purposes[activeIndex]);

    return LayoutBuilder(
      builder: (context, constraints) {
        final segmentWidth =
            (constraints.maxWidth - _inset * 2) / purposes.length;

        return Container(
          height: _height,
          padding: const EdgeInsets.all(_inset),
          decoration: BoxDecoration(
            color: t.field,
            borderRadius: AppRadius.pillR,
            border: Border.all(color: t.border),
          ),
          child: Stack(
            children: [
              // Sliding indicator — one moving object instead of N chips
              // independently changing colour, so the eye tracks the switch.
              AnimatedPositioned(
                duration: const Duration(milliseconds: 220),
                curve: Curves.easeOutCubic,
                left: segmentWidth * activeIndex,
                top: 0,
                bottom: 0,
                width: segmentWidth,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 220),
                  decoration: BoxDecoration(
                    color: tint,
                    borderRadius: AppRadius.pillR,
                  ),
                ),
              ),
              Row(
                children: [
                  for (final p in purposes)
                    Expanded(
                      child: GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: () => onChanged(p),
                        child: Center(
                          child: AnimatedDefaultTextStyle(
                            duration: const Duration(milliseconds: 220),
                            style: AppType.label(
                              p == selected
                                  ? AppColors.onTint(tint)
                                  : t.textSecondary,
                            ).copyWith(
                              fontWeight:
                                  p == selected
                                      ? FontWeight.w600
                                      : FontWeight.w500,
                            ),
                            child: Text(
                              p,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

/// Overflow form of [PurposeSelector] for users with many purpose types.
class _PurposeChipRow extends StatelessWidget {
  const _PurposeChipRow({
    required this.purposes,
    required this.selected,
    required this.onChanged,
  });

  final List<String> purposes;
  final String selected;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    // No padding of its own — the caller already insets this row by screenH on
    // both sides, so the chips start on the same line as the summary card.
    return SizedBox(
      height: _kChipHeight,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        itemCount: purposes.length,
        separatorBuilder: (_, __) => const SizedBox(width: _kChipGap),
        itemBuilder: (context, i) {
          final p = purposes[i];
          return _FilterChip(
            label: p,
            selected: selected == p,
            tint: selected == p ? _purposeTint(p) : null,
            onTap: () => onChanged(p),
          );
        },
      ),
    );
  }
}

class CategoryFilterChips extends ConsumerWidget {
  final String selected;
  final ValueChanged<String> onChanged;

  const CategoryFilterChips({
    super.key,
    required this.selected,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final categories = ['All', ...ref.watch(categoryProvider).expense];

    // Leading gutter only: this row is full-bleed on the right so chips scroll
    // up to the advanced-filter button, which supplies its own gap.
    return SizedBox(
      height: _kChipHeight,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.only(left: AppSpacing.screenH),
        physics: const BouncingScrollPhysics(),
        itemCount: categories.length,
        separatorBuilder: (_, __) => const SizedBox(width: _kChipGap),
        itemBuilder: (context, i) {
          final cat = categories[i];
          final data =
              cat == 'All'
                  ? const CategoryData(
                    LucideIcons.layoutGrid,
                    AppColors.tintBlue,
                    'All',
                  )
                  : CategoryIcon.resolve(cat);
          return _FilterChip(
            label: cat,
            icon: data.icon,
            selected: selected == cat,
            onTap: () => onChanged(cat),
          );
        },
      ),
    );
  }
}

class _PrivacyNotice extends StatelessWidget {
  const _PrivacyNotice({required this.tripTitle});

  final String tripTitle;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.sm,
        vertical: AppSpacing.xs + 2,
      ),
      decoration: BoxDecoration(
        color: t.primarySoft,
        borderRadius: AppRadius.tileR,
        border: Border.all(color: t.primary.withValues(alpha: 0.25)),
      ),
      child: Row(
        children: [
          Icon(LucideIcons.eyeOff, size: 15, color: t.primary),
          const SizedBox(width: AppSpacing.xs),
          Expanded(
            child: Text(
              'Trip privacy — only $tripTitle transactions shown',
              style: AppType.caption(t.textSecondary),
            ),
          ),
        ],
      ),
    );
  }
}

class TransactionSearchDelegate extends SearchDelegate {
  final WidgetRef ref;
  TransactionSearchDelegate(this.ref);

  @override
  ThemeData appBarTheme(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final canvas = _SoftSearchTone.canvas(context);
    final ink = _SoftSearchTone.ink(context);
    final muted = _SoftSearchTone.muted(context);
    final emerald = _SoftSearchTone.emerald(context);
    final radius = BorderRadius.circular(20);
    final idleBorder = OutlineInputBorder(
      borderRadius: radius,
      borderSide: BorderSide(color: _SoftSearchTone.border(context)),
    );

    return theme.copyWith(
      scaffoldBackgroundColor: canvas,
      canvasColor: canvas,
      splashColor: _SoftSearchTone.mint(context),
      highlightColor: _SoftSearchTone.mint(context).withValues(alpha: 0.55),
      textSelectionTheme: TextSelectionThemeData(
        cursorColor: emerald,
        selectionHandleColor: emerald,
        selectionColor: _SoftSearchTone.mintDeep(context),
      ),
      appBarTheme: AppBarTheme(
        systemOverlayStyle:
            isDark ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark,
        backgroundColor: canvas,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        toolbarHeight: 64,
        titleSpacing: 0,
        iconTheme: IconThemeData(color: ink, size: 20),
        actionsIconTheme: IconThemeData(color: muted, size: 18),
      ),
      textTheme: theme.textTheme.copyWith(
        titleLarge: _SoftSearchTone.text(
          context,
          fontSize: 16,
          fontWeight: FontWeight.w600,
          color: ink,
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        isDense: true,
        filled: true,
        fillColor: _SoftSearchTone.card(context),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 14,
          vertical: 10,
        ),
        hintStyle: _SoftSearchTone.text(
          context,
          fontSize: 15,
          fontWeight: FontWeight.w500,
          color: muted,
        ),
        border: idleBorder,
        enabledBorder: idleBorder,
        focusedBorder: OutlineInputBorder(
          borderRadius: radius,
          borderSide: BorderSide(color: emerald, width: 1.4),
        ),
        disabledBorder: idleBorder,
      ),
    );
  }

  @override
  List<Widget>? buildActions(BuildContext context) {
    final name = ref.watch(userStateProvider).profileName.trim();
    final initials = _searchInitials(name);
    return [
      Padding(
        padding: const EdgeInsets.only(right: 4),
        child: Center(
          child: _SoftSearchIconButton(
            icon: LucideIcons.x,
            iconSize: 16,
            tooltip: 'Clear',
            onPressed: () => query = '',
          ),
        ),
      ),
      if (initials.isNotEmpty)
        Padding(
          padding: const EdgeInsets.only(right: 12),
          child: Center(child: _SearchAvatar(initials: initials)),
        ),
    ];
  }

  @override
  Widget? buildLeading(BuildContext context) => Padding(
    padding: const EdgeInsets.only(left: 8),
    child: Center(
      child: _SoftSearchIconButton(
        icon: LucideIcons.arrowLeft,
        iconSize: 18,
        tooltip: 'Close',
        onPressed: () => close(context, null),
      ),
    ),
  );

  @override
  Widget buildResults(BuildContext context) => _buildSearchResults(context);

  @override
  Widget buildSuggestions(BuildContext context) => _buildSearchResults(context);

  Widget _buildSearchResults(BuildContext context) {
    final txs = ref.watch(model.transactionProvider);
    return _SearchPage(delegate: this, query: query, transactions: txs);
  }
}

enum _SearchPill { all, personal, outing, upi }

class _SearchPage extends StatefulWidget {
  const _SearchPage({
    required this.delegate,
    required this.query,
    required this.transactions,
  });

  final TransactionSearchDelegate delegate;
  final String query;
  final List<model.Transaction> transactions;

  @override
  State<_SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<_SearchPage> {
  _SearchPill _pill = _SearchPill.all;
  bool _loadingOlder = false;

  List<String> _popularTerms() {
    final counts = <String, int>{};
    for (final tx in widget.transactions) {
      final name = tx.merchant.trim();
      if (name.isEmpty || name.toLowerCase() == 'unknown') continue;
      counts[name] = (counts[name] ?? 0) + 1;
    }
    final ranked =
        counts.keys.toList()..sort((a, b) => counts[b]!.compareTo(counts[a]!));
    return ranked.take(8).toList();
  }

  bool _textMatch(model.Transaction tx, String q) {
    return tx.merchant.toLowerCase().contains(q) ||
        (tx.title ?? '').toLowerCase().contains(q) ||
        tx.categoryNames.any((c) => c.toLowerCase().contains(q)) ||
        tx.account.toLowerCase().contains(q) ||
        tx.items.any((i) => i.name.toLowerCase().contains(q));
  }

  bool _pillMatch(model.Transaction tx) {
    switch (_pill) {
      case _SearchPill.all:
        return true;
      case _SearchPill.personal:
        final purpose = (tx.purpose ?? '').trim().toLowerCase();
        final personal = purpose.isEmpty || purpose == 'personal';
        final outing = tx.outingId != null && tx.outingId!.isNotEmpty;
        return personal && !outing;
      case _SearchPill.outing:
        return (tx.outingId != null && tx.outingId!.isNotEmpty) ||
            tx.time == 'Trip' ||
            tx.time == 'OutingSummary';
      case _SearchPill.upi:
        return tx.paymentType.toLowerCase().contains('upi') ||
            tx.upiId.trim().isNotEmpty;
    }
  }

  Future<void> _loadOlder() async {
    if (_loadingOlder) return;
    setState(() => _loadingOlder = true);
    final oldest = SyncService.oldestCachedTransactionDate() ?? DateTime.now();
    final fetched = await SyncService.fetchTransactionRange(
      from: oldest.subtract(const Duration(days: 30)),
      to: oldest,
    );
    if (!mounted) return;
    setState(() => _loadingOlder = false);
    final messenger = ScaffoldMessenger.of(context);
    if (fetched == null) {
      messenger.showSnackBar(
        const SnackBar(
          content: Text(
            'Offline — only the locally cached history is available. Connect to load older transactions.',
          ),
          behavior: SnackBarBehavior.floating,
        ),
      );
    } else if (fetched == 0) {
      messenger.showSnackBar(
        const SnackBar(
          content: Text('No older transactions found on the server.'),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final q = widget.query.toLowerCase();
    final results =
        widget.transactions
            .where((tx) => _textMatch(tx, q) && _pillMatch(tx))
            .toList();
    final noun = results.length == 1 ? 'transaction' : 'transactions';

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                'Found ${results.length} matching $noun',
                style: _SoftSearchTone.text(
                  context,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: _SoftSearchTone.slate(context),
                ),
              ),
            ),
            if (widget.query.trim().isNotEmpty)
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 4,
                ),
                decoration: BoxDecoration(
                  color: _SoftSearchTone.mint(context),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  widget.query.trim(),
                  style: _SoftSearchTone.text(
                    context,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: _SoftSearchTone.emeraldDeep(context),
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 34,
          child: ListView(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            children: [
              _SearchPillChip(
                label: 'All',
                selected: _pill == _SearchPill.all,
                onTap: () => setState(() => _pill = _SearchPill.all),
              ),
              const SizedBox(width: 8),
              _SearchPillChip(
                label: 'Personal',
                selected: _pill == _SearchPill.personal,
                onTap: () => setState(() => _pill = _SearchPill.personal),
              ),
              const SizedBox(width: 8),
              _SearchPillChip(
                label: 'Outing',
                selected: _pill == _SearchPill.outing,
                onTap: () => setState(() => _pill = _SearchPill.outing),
              ),
              const SizedBox(width: 8),
              _SearchPillChip(
                label: 'UPI',
                selected: _pill == _SearchPill.upi,
                onTap: () => setState(() => _pill = _SearchPill.upi),
              ),
              const SizedBox(width: 8),
              const _SearchFilterMark(),
            ],
          ),
        ),
        const SizedBox(height: 14),
        if (results.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 28),
            child: _SoftSearchEmpty(
              icon: q.isEmpty ? LucideIcons.search : LucideIcons.searchX,
              message:
                  q.isEmpty
                      ? 'Search merchants, categories, accounts or items.'
                      : 'Nothing cached on this device matches “${widget.query}”.',
            ),
          )
        else
          for (var i = 0; i < results.length; i++) ...[
            if (i > 0) const SizedBox(height: 10),
            _SearchResultCard(tx: results[i]),
          ],
        const SizedBox(height: 16),
        const _SearchCacheCard(),
        const SizedBox(height: 8),
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton(
            onPressed: _loadingOlder ? null : _loadOlder,
            style: TextButton.styleFrom(
              foregroundColor: _SoftSearchTone.emeraldDeep(context),
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            ),
            child: Text(
              _loadingOlder ? 'Loading…' : 'Load older transactions →',
              style: _SoftSearchTone.text(
                context,
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: _SoftSearchTone.emeraldDeep(context),
              ),
            ),
          ),
        ),
        const SizedBox(height: 8),
        if (_popularTerms().isNotEmpty) ...[
          Text(
            'POPULAR SEARCHES',
            style: _SoftSearchTone.text(
              context,
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: _SoftSearchTone.muted(context),
              letterSpacing: 0.8,
            ),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final term in _popularTerms())
                _SearchPillChip(
                  label: term,
                  selected:
                      widget.query.trim().toLowerCase() == term.toLowerCase(),
                  onTap: () => widget.delegate.query = term,
                ),
            ],
          ),
        ],
      ],
    );
  }
}

class _SearchCacheCard extends StatelessWidget {
  const _SearchCacheCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: _SoftSearchTone.cardBox(
        context,
        fill: _SoftSearchTone.mint(context),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            LucideIcons.hardDrive,
            size: 18,
            color: _SoftSearchTone.emeraldDeep(context),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Local Device Cache',
                  style: _SoftSearchTone.text(
                    context,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: _SoftSearchTone.ink(context),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Search covers transactions cached on this device (roughly the '
                  'last 30 days plus anything you\'ve loaded).',
                  style: _SoftSearchTone.text(
                    context,
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    color: _SoftSearchTone.slate(context),
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Home Soft Soft tokens for the transaction search page.
abstract final class _SoftSearchTone {
  static bool _dark(BuildContext context) =>
      Theme.of(context).brightness == Brightness.dark;

  static Color canvas(BuildContext context) =>
      _dark(context) ? SoftPalette.darkBg : const Color(0xFFF8FAFC);

  static Color card(BuildContext context) =>
      _dark(context) ? SoftPalette.darkCard : const Color(0xFFFFFFFF);

  static Color border(BuildContext context) =>
      _dark(context) ? SoftPalette.darkBorder : const Color(0xFFF1F5F9);

  static Color ink(BuildContext context) =>
      _dark(context) ? SoftPalette.darkInk : const Color(0xFF0F172A);

  static Color muted(BuildContext context) =>
      _dark(context) ? SoftPalette.darkFaint : const Color(0xFF94A3B8);

  static Color slate(BuildContext context) =>
      _dark(context) ? SoftPalette.darkMuted : const Color(0xFF64748B);

  static Color emerald(BuildContext context) =>
      _dark(context) ? SoftPalette.darkEmerald : const Color(0xFF10B981);

  static Color emeraldDeep(BuildContext context) =>
      _dark(context) ? SoftPalette.darkEmerald : const Color(0xFF059669);

  static Color mint(BuildContext context) =>
      _dark(context) ? SoftPalette.darkEmeraldSoft : const Color(0xFFECFDF5);

  static Color mintDeep(BuildContext context) =>
      _dark(context)
          ? SoftPalette.darkEmerald.withValues(alpha: 0.35)
          : const Color(0xFFD1FAE5);

  static const shadow = [
    BoxShadow(
      color: Color.fromRGBO(15, 23, 42, 0.04),
      offset: Offset(0, 4),
      blurRadius: 16,
      spreadRadius: -2,
    ),
  ];

  static BoxDecoration cardBox(
    BuildContext context, {
    Color? fill,
    double radius = 22,
  }) {
    return BoxDecoration(
      color: fill ?? card(context),
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: border(context)),
      boxShadow: _dark(context) ? null : shadow,
    );
  }

  static TextStyle text(
    BuildContext context, {
    required double fontSize,
    FontWeight fontWeight = FontWeight.w500,
    Color? color,
    double? letterSpacing,
    double? height,
  }) {
    return GoogleFonts.plusJakartaSans(
      fontSize: fontSize,
      fontWeight: fontWeight,
      color: color ?? ink(context),
      letterSpacing: letterSpacing,
      height: height,
    );
  }
}

class _SoftSearchIconButton extends StatelessWidget {
  const _SoftSearchIconButton({
    required this.icon,
    required this.onPressed,
    this.tooltip,
    this.iconSize = 18,
  });

  final IconData icon;
  final VoidCallback onPressed;
  final String? tooltip;
  final double iconSize;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final btn = Material(
      color: _SoftSearchTone.card(context),
      shape: const CircleBorder(),
      elevation: 0,
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onPressed,
        child: Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _SoftSearchTone.card(context),
            border: Border.all(color: _SoftSearchTone.border(context)),
            boxShadow: isDark ? null : _SoftSearchTone.shadow,
          ),
          child: Icon(
            icon,
            size: iconSize,
            color: _SoftSearchTone.ink(context),
          ),
        ),
      ),
    );
    if (tooltip == null) return btn;
    return Tooltip(message: tooltip!, child: btn);
  }
}

String _searchInitials(String name) {
  final trimmed = name.trim();
  if (trimmed.isEmpty) return '';
  final parts = trimmed.split(RegExp(r'\s+'));
  if (parts.length >= 2 && parts[0].isNotEmpty && parts[1].isNotEmpty) {
    return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
  }
  return trimmed.length >= 2
      ? trimmed.substring(0, 2).toUpperCase()
      : trimmed.toUpperCase();
}

class _SearchAvatar extends StatelessWidget {
  const _SearchAvatar({required this.initials});

  final String initials;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => context.push('/settings'),
      child: Container(
        width: 36,
        height: 36,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: _SoftSearchTone.mint(context),
          shape: BoxShape.circle,
          border: Border.all(color: _SoftSearchTone.border(context)),
        ),
        child: Text(
          initials,
          style: _SoftSearchTone.text(
            context,
            fontSize: 12,
            fontWeight: FontWeight.w700,
            color: _SoftSearchTone.emeraldDeep(context),
          ),
        ),
      ),
    );
  }
}

class _SearchPillChip extends StatelessWidget {
  const _SearchPillChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final bg =
        selected
            ? _SoftSearchTone.emeraldDeep(context)
            : _SoftSearchTone.card(context);
    final fg = selected ? Colors.white : _SoftSearchTone.slate(context);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(horizontal: 14),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(
            color:
                selected
                    ? _SoftSearchTone.emeraldDeep(context)
                    : _SoftSearchTone.border(context),
          ),
        ),
        child: Text(
          label,
          style: _SoftSearchTone.text(
            context,
            fontSize: 13,
            fontWeight: selected ? FontWeight.w700 : FontWeight.w600,
            color: fg,
          ),
        ),
      ),
    );
  }
}

class _SearchFilterMark extends StatelessWidget {
  const _SearchFilterMark();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 34,
      height: 34,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: _SoftSearchTone.card(context),
        shape: BoxShape.circle,
        border: Border.all(color: _SoftSearchTone.border(context)),
      ),
      child: Icon(
        LucideIcons.slidersHorizontal,
        size: 15,
        color: _SoftSearchTone.slate(context),
      ),
    );
  }
}

class _SearchResultCard extends ConsumerStatefulWidget {
  const _SearchResultCard({required this.tx});

  final model.Transaction tx;

  @override
  ConsumerState<_SearchResultCard> createState() => _SearchResultCardState();
}

class _SearchResultCardState extends ConsumerState<_SearchResultCard> {
  bool _revealed = false;

  @override
  Widget build(BuildContext context) {
    final tx = widget.tx;
    final isPrivate = ref.watch(privateModeProvider);
    final mask = isPrivate && !_revealed;
    final display = TransactionDisplayUtils.displayTitle(tx);
    final category = _summariseNamesTop(tx.categoryNames);
    final when = TransactionDisplayUtils.formatListDateTime(
      tx.date,
      legacyTime: tx.time,
    );
    final money = NumberFormat.currency(
      locale: 'en_IN',
      symbol: '₹',
      decimalDigits: 0,
    ).format(tx.amount.abs().toInt());
    final String amountText;
    final String status;
    final Color amountColor;
    if (mask) {
      amountText = PrivateModeService.mask;
      status = tx.isTransfer ? 'Transfer' : (tx.isExpense ? 'Debit' : 'Credit');
      amountColor = _SoftSearchTone.muted(context);
    } else if (tx.isTransfer) {
      amountText = money;
      status = 'Transfer';
      amountColor = _SoftSearchTone.ink(context);
    } else if (tx.isExpense) {
      amountText = '-$money';
      status = 'Debit';
      amountColor = _SoftSearchTone.ink(context);
    } else {
      amountText = '+$money';
      status = 'Credit';
      amountColor = _SoftSearchTone.emeraldDeep(context);
    }
    final tone = _searchCatTone(context, category);
    final tags = _searchTags(tx, category);

    return GestureDetector(
      onLongPressStart:
          isPrivate
              ? (_) {
                HapticFeedback.mediumImpact();
                setState(() => _revealed = true);
              }
              : null,
      onLongPressEnd:
          isPrivate ? (_) => setState(() => _revealed = false) : null,
      onLongPressCancel:
          isPrivate ? () => setState(() => _revealed = false) : null,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => context.push('/transaction/${tx.id}'),
          borderRadius: BorderRadius.circular(22),
          child: Ink(
            padding: const EdgeInsets.all(14),
            decoration: _SoftSearchTone.cardBox(context),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 42,
                      height: 42,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: tone.$1,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(tone.$3, size: 18, color: tone.$2),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Flexible(
                                child: Text(
                                  display.primary,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: _SoftSearchTone.text(
                                    context,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w700,
                                    color: _SoftSearchTone.ink(context),
                                  ),
                                ),
                              ),
                              if (tx.isAutoDetected) ...[
                                const SizedBox(width: 4),
                                Icon(
                                  LucideIcons.badgeCheck,
                                  size: 14,
                                  color: _SoftSearchTone.emerald(context),
                                ),
                              ],
                            ],
                          ),
                          const SizedBox(height: 2),
                          Text(
                            [
                              if (category.isNotEmpty) category,
                              when,
                            ].join(' · '),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: _SoftSearchTone.text(
                              context,
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                              color: _SoftSearchTone.slate(context),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          amountText,
                          style: _SoftSearchTone.text(
                            context,
                            fontSize: 15,
                            fontWeight: FontWeight.w800,
                            color: amountColor,
                          ),
                        ),
                        Text(
                          status,
                          style: _SoftSearchTone.text(
                            context,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            color:
                                tx.isExpense && !tx.isTransfer
                                    ? _SoftSearchTone.muted(context)
                                    : _SoftSearchTone.emeraldDeep(context),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                if (tags.isNotEmpty) ...[
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [for (final tag in tags) _SearchTag(label: tag)],
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SearchTag extends StatelessWidget {
  const _SearchTag({required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    final pastel = _searchTagColors(label, context);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: pastel.$1,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        label,
        style: _SoftSearchTone.text(
          context,
          fontSize: 11,
          fontWeight: FontWeight.w700,
          color: pastel.$2,
        ),
      ),
    );
  }
}

List<String> _searchTags(model.Transaction tx, String category) {
  final tags = <String>[];
  void add(String value) {
    final trimmed = value.trim();
    if (trimmed.isEmpty) return;
    if (tags.any((t) => t.toLowerCase() == trimmed.toLowerCase())) return;
    tags.add(trimmed);
  }

  add(category);
  if (tx.bankName.trim().isNotEmpty) {
    final last4 = tx.accountLast4.trim();
    add(last4.isEmpty ? tx.bankName.trim() : '${tx.bankName.trim()} ···$last4');
  } else if (tx.account.trim().isNotEmpty) {
    final last4 = tx.accountLast4.trim();
    add(last4.isEmpty ? tx.account.trim() : '${tx.account.trim()} ···$last4');
  }
  if (tx.isAutoDetected) add('SMS Verified');
  final purpose =
      tx.isSplitExpense
          ? _summariseNamesTop(tx.purposeNames)
          : (tx.purpose ?? '');
  add(purpose);
  final badge = _badgeLabel(tx);
  if (badge != null) add(badge);
  if (tx.paymentType.toLowerCase() == 'cash') add('Cash');
  if (tx.paymentType.toLowerCase().contains('upi') ||
      tx.upiId.trim().isNotEmpty) {
    add('UPI');
  }
  return tags;
}

(Color, Color) _searchTagColors(String label, BuildContext context) {
  final key = label.toLowerCase();
  if (key.contains('sms') || key == 'outing' || key.contains('split')) {
    return (
      _SoftSearchTone.mint(context),
      _SoftSearchTone.emeraldDeep(context),
    );
  }
  if (key.contains('food') ||
      key.contains('restaurant') ||
      key.contains('dining') ||
      key == 'rent') {
    return (
      Theme.of(context).brightness == Brightness.dark
          ? const Color(0xFF3F2214)
          : const Color(0xFFFFF7ED),
      const Color(0xFFEA580C),
    );
  }
  return (
    Theme.of(context).brightness == Brightness.dark
        ? SoftPalette.darkCard
        : const Color(0xFFF8FAFC),
    _SoftSearchTone.slate(context),
  );
}

(Color, Color, IconData) _searchCatTone(BuildContext context, String category) {
  final dark = Theme.of(context).brightness == Brightness.dark;
  final key = category.toLowerCase();
  if (key.contains('food') ||
      key.contains('restaurant') ||
      key.contains('dining')) {
    return (
      dark ? const Color(0xFF3F2214) : const Color(0xFFFFF7ED),
      const Color(0xFFEA580C),
      LucideIcons.utensils,
    );
  }
  if (key.contains('shop') || key.contains('groc')) {
    return (
      dark ? const Color(0xFF3F2A12) : const Color(0xFFFFFBEB),
      const Color(0xFFD97706),
      LucideIcons.shoppingBag,
    );
  }
  if (key.contains('entertain') || key.contains('movie')) {
    return (
      dark ? const Color(0xFF3F1218) : const Color(0xFFFFF1F2),
      const Color(0xFFE11D48),
      LucideIcons.film,
    );
  }
  final mint = dark ? SoftPalette.darkEmeraldSoft : const Color(0xFFECFDF5);
  final ink = dark ? SoftPalette.darkEmerald : const Color(0xFF059669);
  if (key.contains('salary') || key.contains('income')) {
    return (mint, ink, LucideIcons.briefcase);
  }
  if (key.contains('transport') || key.contains('travel')) {
    return (mint, ink, LucideIcons.car);
  }
  return (mint, ink, LucideIcons.receipt);
}

class _SoftSearchEmpty extends StatelessWidget {
  const _SoftSearchEmpty({required this.icon, required this.message});

  final IconData icon;
  final String message;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: _SoftSearchTone.mint(context),
              borderRadius: BorderRadius.circular(18),
            ),
            child: Icon(
              icon,
              size: 28,
              color: _SoftSearchTone.emeraldDeep(context),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            message,
            textAlign: TextAlign.center,
            style: _SoftSearchTone.text(
              context,
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: _SoftSearchTone.slate(context),
              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════ advanced filters sheet ═══════════════════════

class _AdvancedFiltersSheet extends ConsumerStatefulWidget {
  final String selectedSpendType;
  final String selectedContributor;
  final String selectedFriend;
  final List<String> selectedSources;
  final String selectedCategory;
  final String selectedPurpose;
  final void Function(
    String spendType,
    String contributor,
    String friend,
    List<String> sources,
    String category,
    String purpose,
  )
  onApply;

  const _AdvancedFiltersSheet({
    required this.selectedSpendType,
    required this.selectedContributor,
    required this.selectedFriend,
    required this.selectedSources,
    required this.selectedCategory,
    required this.selectedPurpose,
    required this.onApply,
  });

  @override
  ConsumerState<_AdvancedFiltersSheet> createState() =>
      _AdvancedFiltersSheetState();
}

class _AdvancedFiltersSheetState extends ConsumerState<_AdvancedFiltersSheet> {
  late String _tempSpendType;
  late String _tempContributor;
  late String _tempFriend;
  late Set<String> _tempSources;
  late String _tempCategory;
  late String _tempPurpose;

  @override
  void initState() {
    super.initState();
    _tempSpendType = widget.selectedSpendType;
    _tempContributor = widget.selectedContributor;
    _tempFriend = widget.selectedFriend;
    _tempSources = widget.selectedSources.toSet();
    _tempCategory = widget.selectedCategory;
    _tempPurpose = widget.selectedPurpose;
  }

  bool get _anyActive =>
      _tempSpendType != 'All' ||
      _tempContributor != 'All' ||
      _tempFriend != 'All' ||
      _tempSources.isNotEmpty ||
      _tempCategory != 'All' ||
      _tempPurpose != 'All';

  void _resetTemps() {
    setState(() {
      _tempSpendType = 'All';
      _tempContributor = 'All';
      _tempFriend = 'All';
      _tempSources = <String>{};
      _tempCategory = 'All';
      _tempPurpose = 'All';
    });
  }

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final card = dark ? SoftPalette.darkCard : const Color(0xFFFFFFFF);
    final border = dark ? SoftPalette.darkBorder : const Color(0xFFF1F5F9);
    final ink = dark ? SoftPalette.darkInk : const Color(0xFF0F172A);
    final slate = dark ? SoftPalette.darkMuted : const Color(0xFF64748B);
    final canvas = dark ? SoftPalette.darkBg : const Color(0xFFF8F9FC);

    // Two separate rosters on purpose. Contributors come from the
    // `contributors` table (income sources, always including the permanent
    // "Me"); friends come from the friends/splits side.
    final contributors = [
      'All',
      ...ref.watch(contributorProvider).map((c) => c.name),
    ];
    final friends = ['All', ...ref.watch(friendsProvider).map((f) => f.name)];
    final accounts = ref.watch(userStateProvider).accounts;
    final sources = ['All', ...accounts.map((a) => a.name)];
    final purposes = [
      'All',
      ...ref
          .watch(userStateProvider)
          .purposeTypes
          .where((p) => p.trim().isNotEmpty),
    ];
    final cats = ref.watch(categoryProvider);
    final categoryNames = <String>['All'];
    final seenCats = <String>{'all'};
    for (final name in [...cats.expense, ...cats.income]) {
      final trimmed = name.trim();
      if (trimmed.isEmpty || !seenCats.add(trimmed.toLowerCase())) continue;
      categoryNames.add(trimmed);
    }

    TextStyle labelStyle(
      Color color, {
      double size = 13,
      FontWeight weight = FontWeight.w700,
    }) {
      return GoogleFonts.plusJakartaSans(
        fontSize: size,
        fontWeight: weight,
        color: color,
      );
    }

    return Align(
      alignment: Alignment.bottomCenter,
      child: Container(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.sizeOf(context).height * 0.88,
        ),
        decoration: BoxDecoration(
          color: card,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          border: Border.all(color: border),
          boxShadow:
              dark
                  ? null
                  : const [
                    BoxShadow(
                      color: Color.fromRGBO(15, 23, 42, 0.04),
                      offset: Offset(0, 4),
                      blurRadius: 16,
                      spreadRadius: -2,
                    ),
                  ],
        ),
        padding: EdgeInsets.fromLTRB(
          0,
          10,
          0,
          MediaQuery.viewInsetsOf(context).bottom +
              MediaQuery.paddingOf(context).bottom +
              16,
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: border,
                    borderRadius: BorderRadius.circular(999),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        'Filters',
                        style: labelStyle(
                          ink,
                          size: 20,
                          weight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              _sectionLabel('Transaction type', slate),
              _chipRow(
                options: const [
                  'All',
                  'Expense',
                  'Income',
                  'Transfer',
                  'Repayment',
                ],
                selected: _tempSpendType,
                onSelected: (v) => setState(() => _tempSpendType = v),
                canvas: canvas,
                border: border,
                slate: slate,
              ),
              const SizedBox(height: 16),
              _sectionLabel('Category', slate),
              _chipRow(
                options: categoryNames,
                selected: _tempCategory,
                onSelected: (v) => setState(() => _tempCategory = v),
                canvas: canvas,
                border: border,
                slate: slate,
              ),
              const SizedBox(height: 16),
              _sectionLabel('Purpose', slate),
              _chipRow(
                options: purposes,
                selected: _tempPurpose,
                onSelected: (v) => setState(() => _tempPurpose = v),
                canvas: canvas,
                border: border,
                slate: slate,
              ),
              const SizedBox(height: 16),
              _sectionLabel('Accounts', slate, hint: 'Select one or more'),
              _chipRow(
                options: sources,
                selected: _tempSources.isEmpty ? 'All' : '',
                multiSelected: _tempSources,
                onSelected: (v) {
                  setState(() {
                    if (v == 'All') {
                      _tempSources.clear();
                    } else if (!_tempSources.add(v)) {
                      _tempSources.remove(v);
                    }
                  });
                },
                canvas: canvas,
                border: border,
                slate: slate,
              ),
              const SizedBox(height: 16),
              _sectionLabel(
                'Contributor',
                slate,
                hint: 'Who the income came from',
              ),
              _chipRow(
                options: contributors,
                selected: _tempContributor,
                onSelected: (v) => setState(() => _tempContributor = v),
                canvas: canvas,
                border: border,
                slate: slate,
              ),
              const SizedBox(height: 16),
              _sectionLabel('Friend', slate, hint: 'Who shared the expense'),
              _chipRow(
                options: friends,
                selected: _tempFriend,
                onSelected: (v) => setState(() => _tempFriend = v),
                canvas: canvas,
                border: border,
                slate: slate,
              ),
              const SizedBox(height: 22),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 0),
                child: Row(
                  children: [
                    Expanded(
                      child: SizedBox(
                        height: 52,
                        child: OutlinedButton(
                          onPressed: _anyActive ? _resetTemps : null,
                          style: OutlinedButton.styleFrom(
                            backgroundColor:
                                dark ? canvas : const Color(0xFFFFFFFF),
                            disabledBackgroundColor:
                                dark ? canvas : const Color(0xFFFFFFFF),
                            foregroundColor: ink,
                            disabledForegroundColor: slate,
                            elevation: 0,
                            side: BorderSide(color: border),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(24),
                            ),
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                          ),
                          child: Text(
                            'Clear',
                            style: AppFonts.text(
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                              color: _anyActive ? ink : slate,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: SizedBox(
                        height: 52,
                        child: ElevatedButton(
                          onPressed: () {
                            widget.onApply(
                              _tempSpendType,
                              _tempContributor,
                              _tempFriend,
                              _tempSources.toList(),
                              _tempCategory,
                              _tempPurpose,
                            );
                            Navigator.pop(context);
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: SoftColors.control,
                            foregroundColor: Colors.white,
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(24),
                            ),
                          ),
                          child: Text(
                            'Apply',
                            style: AppFonts.text(
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// [hint] disambiguates the two people-shaped filters. Contributor and
  /// Friend look alike in a chip row but mean different things, so each says
  /// which question it answers.
  Widget _sectionLabel(String title, Color slate, {String? hint}) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
      child: Row(
        children: [
          Text(
            title,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: slate,
            ),
          ),
          if (hint != null) ...[
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                hint,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  color: slate,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _chipRow({
    required List<String> options,
    required String selected,
    Set<String>? multiSelected,
    required ValueChanged<String> onSelected,
    required Color canvas,
    required Color border,
    required Color slate,
  }) {
    return SizedBox(
      height: 44,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        physics: const BouncingScrollPhysics(),
        itemCount: options.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (context, i) {
          final label = options[i];
          final on =
              multiSelected == null
                  ? selected == label
                  : (label == 'All'
                      ? multiSelected.isEmpty
                      : multiSelected.contains(label));
          final dark = Theme.of(context).brightness == Brightness.dark;
          return Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: () => onSelected(label),
              borderRadius: BorderRadius.circular(24),
              child: Ink(
                height: 44,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  color:
                      on
                          ? _Act.emerald
                          : (dark ? canvas : const Color(0xFFFFFFFF)),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: on ? _Act.emerald : border),
                ),
                child: Center(
                  child: Text(
                    label,
                    style: AppFonts.text(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: on ? Colors.white : slate,
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
