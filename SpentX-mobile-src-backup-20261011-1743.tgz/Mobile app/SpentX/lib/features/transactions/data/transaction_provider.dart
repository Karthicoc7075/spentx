import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../../../core/providers/friend_split_provider.dart';
import '../../../models/friend_split.dart';
import '../../../core/providers/outing_provider.dart';
import '../../../core/providers/user_state_provider.dart';
import '../../../core/services/friend_repayment_matcher.dart';
import '../../../core/sync/sync_service.dart';
import '../../../core/services/budget_alert_service.dart';
import '../../../core/services/notification_history_service.dart';
import '../../../core/services/plan_alert_service.dart';
import '../../../core/utils/outing_total_refresh.dart';
import '../../../core/utils/budget_spend.dart';
import '../../../core/utils/outing_totals.dart';
import '../../../core/utils/reimbursement.dart';
import '../../../core/utils/activity_purpose_cashflow.dart';
export '../../../core/utils/activity_purpose_cashflow.dart'
    show
        ActivityPurposeBreakdown,
        ActivityPurposeCashflow,
        activityPurposeBreakdown,
        activityPurposeCashflow;

import '../../../models/transaction.dart';
export '../../../models/transaction.dart';

class TransactionNotifier extends StateNotifier<List<Transaction>> {
  final Ref _ref;
  Box get _box => Hive.box('transactions');

  TransactionNotifier(this._ref) : super([]) {
    _loadFromStorage();
  }

  void _loadFromStorage() {
    final List<dynamic>? rawData = _box.get('list');
    if (rawData != null) {
      state =
          rawData
              .map((e) => Transaction.fromJson(Map<dynamic, dynamic>.from(e)))
              .toList();
      Future.microtask(_reconcileFriendRepaymentsFromLedger);
    } else {
      state = [];
    }
  }

  /// Reload ledger from Hive — call after background SMS auto-adds while app was paused.
  void reloadFromStorage() => _loadFromStorage();

  void _reconcileFriendRepaymentsFromLedger() {
    if (!mounted) return;
    for (final tx in state) {
      _tryFriendAutoSettle(tx);
    }
  }

  void _saveToStorage() {
    final data = state.map((e) => e.toJson()).toList();
    _box.put('list', data);
  }

  /// [applyOutingAutoLink] — when true (default), active auto-mode trip tags
  /// expenses in the trip date range. Manual add/edit sheets pass false and
  /// set [Transaction.outingId] themselves (or leave null for "None").
  void addTransaction(
    Transaction transaction, {
    bool applyOutingAutoLink = true,
  }) {
    if (transaction.isPendingVerification) {
      final sameId = state.where((t) => t.id == transaction.id).firstOrNull;
      if (sameId != null) {
        state = [transaction, ...state.where((t) => t.id != transaction.id)];
        _saveToStorage();
        return;
      }
    }

    // Duplicate guard. Must compare direction and account too — otherwise the
    // second leg of a transfer pair (same merchant/amount/minute, opposite
    // direction) is silently dropped and the destination is never credited.
    final dup =
        state
            .where(
              (t) =>
                  t.id != transaction.id &&
                  !t.isPendingVerification &&
                  t.merchant == transaction.merchant &&
                  t.amount == transaction.amount &&
                  t.isExpense == transaction.isExpense &&
                  t.account == transaction.account &&
                  t.date.year == transaction.date.year &&
                  t.date.month == transaction.date.month &&
                  t.date.day == transaction.date.day &&
                  t.date.hour == transaction.date.hour &&
                  t.date.minute == transaction.date.minute,
            )
            .firstOrNull;

    if (dup != null) {
      if (transaction.isPendingVerification || dup.isPendingVerification) {
        return;
      }
      return;
    }

    // ── Auto Mode (SMS / bank only) ──
    // Manual "Add expense" stays a normal ledger row unless the form sets outingId.
    // Do not pull normal spends into a trip (was: 1000 normal + 2000 trip = 3000 total).
    final allowAutoLink =
        applyOutingAutoLink &&
        (transaction.isAutoDetected || transaction.isPendingVerification);
    if (allowAutoLink && transaction.outingId == null) {
      final activeOuting = _ref.read(activeOutingProvider);
      if (activeOuting != null) {
        final date = transaction.date;
        final start = DateTime(
          activeOuting.startDate.year,
          activeOuting.startDate.month,
          activeOuting.startDate.day,
        );
        final end = DateTime(
          activeOuting.endDate.year,
          activeOuting.endDate.month,
          activeOuting.endDate.day,
          23,
          59,
          59,
        );

        final isInOutingPeriod =
            date.isAfter(start.subtract(const Duration(seconds: 1))) &&
            date.isBefore(end.add(const Duration(seconds: 1)));

        if (transaction.isExpense) {
          if (isInOutingPeriod) {
            transaction = transaction.copyWith(
              outingId: activeOuting.id,
              isAutoLinked: true,
            );
          }
        } else if (!transaction.isTransfer) {
          // Credit (income/repayment) during active outing: friend repayments only.
          if (isInOutingPeriod) {
            final friendName = FriendRepaymentMatcher.resolveFriendName(
              ref: _ref,
              merchant: transaction.merchant,
              upiId: transaction.upiId,
              rawIdentifier: transaction.rawIdentifier,
            );
            if (friendName != null) {
              transaction = transaction.copyWith(
                outingId: activeOuting.id,
                isAutoLinked: true,
              );
            }
          }
        }
      }
    }

    // Always replace same id (verify confirm / re-save) — never duplicate rows.
    state = [transaction, ...state.where((t) => t.id != transaction.id)];
    _saveToStorage();
    // Don't queue cloud upsert for still-pending verify rows.
    if (!transaction.isPendingVerification) {
      SyncService.queueTransactionUpsert(transaction.toJson());
    }
    _syncOutingExpenseIfNeeded(transaction);
    _tryFriendAutoSettle(transaction);
    _checkSpendAlerts(transaction);
  }

  /// Category budget alerts, then the three plan alerts, after the row is saved.
  void _checkSpendAlerts(Transaction transaction) {
    final isSpend = transaction.isExpense && !transaction.isTransfer;
    if (!isSpend) {
      _ref.invalidate(notificationHistoryProvider);
      return;
    }
    final note = transaction.note.trim().toLowerCase();
    final rollup =
        note.startsWith('outing total') || note.startsWith('your share of ');
    () async {
      try {
        if (Hive.isBoxOpen('budgets')) {
          final raw =
              Hive.box('budgets').get('list', defaultValue: <dynamic>[])
                  as List;
          final budgets =
              raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
          final now = DateTime.now();
          await BudgetAlertService.checkAfterExpense(
            category: transaction.category,
            budgets: budgets,
            monthlySpent: (cat) {
              return state
                  .where(
                    (t) => t.date.year == now.year && t.date.month == now.month,
                  )
                  .fold(0.0, (s, t) => s + amountForBudgetCategory(t, cat));
            },
          );
        }
        if (!transaction.isPendingVerification && !rollup) {
          await PlanAlertService.check(transactions: state);
        }
      } finally {
        _ref.invalidate(notificationHistoryProvider);
      }
    }();
  }

  void _tryFriendAutoSettle(Transaction transaction) {
    if (!transaction.isExpense && !transaction.isTransfer) {
      FriendRepaymentMatcher.trySettleCreditWithFeedback(_ref, transaction);
    } else if (transaction.isExpense && !transaction.isTransfer) {
      FriendRepaymentMatcher.trySettleDebitToFriend(_ref, transaction);
    }
  }

  void _syncOutingExpenseIfNeeded(Transaction t) {
    if (t.outingId == null || !t.isExpense || t.isTransfer) return;
    // Never turn the display "Outing total" row into a real outing expense.
    final note = t.note.trim().toLowerCase();
    if (note.startsWith('outing total') || note.startsWith('your share of ')) {
      return;
    }
    // A divided amount — Friend Split, Purpose Split, Category Split or a
    // per-item allocation — has no single amount + category + purpose to
    // carry into a trip, so it is never turned into a trip expense on its
    // own. A row that is already on the trip keeps syncing: it was linked
    // while it was still simple, and dropping out here would strand its
    // expense at a stale title and amount.
    final alreadyOnTrip =
        _ref
            .read(outingProvider.notifier)
            .expenseForTransaction(t.outingId!, t.id) !=
        null;
    if (!alreadyOnTrip && !t.isSimpleTransaction) return;
    _ref
        .read(outingProvider.notifier)
        .syncTransactionExpense(
          outingId: t.outingId!,
          transactionId: t.id,
          title: t.merchant,
          amount: t.amount,
          category: t.category,
          date: t.date,
          paymentMode: t.paymentType,
          accountId: t.account,
          purpose: t.purpose ?? 'Personal',
        );
  }

  void addTransactionsFromSms(List<Transaction> transactions) {
    state = [...transactions, ...state];
    _saveToStorage();
    for (final t in transactions) {
      if (!t.isPendingVerification) {
        SyncService.queueTransactionUpsert(t.toJson());
      }
    }
  }

  void syncFromSms(List<Transaction> transactions) {
    final existingIds =
        state
            .map(
              (t) => '${t.merchant}_${t.amount}_${t.date.day}_${t.date.month}',
            )
            .toSet();
    final newTxs =
        transactions.where((t) {
          final id = '${t.merchant}_${t.amount}_${t.date.day}_${t.date.month}';
          return !existingIds.contains(id);
        }).toList();

    if (newTxs.isNotEmpty) {
      state = [...newTxs, ...state];
      _saveToStorage();
      for (final t in newTxs) {
        if (!t.isPendingVerification) {
          SyncService.queueTransactionUpsert(t.toJson());
        }
      }
    }
  }

  void removeTransaction(String id) {
    final tx = state.where((t) => t.id == id).firstOrNull;

    // If deleting a friend return / repayment transaction:
    // Reopen the debt so friend balance & claim cards show up again!
    if (tx != null && tx.isFriendReturn) {
      _ref
          .read(friendSplitProvider.notifier)
          .revertSettlementByTransaction(
            transactionId: id,
            friendName: tx.merchant,
            amount: tx.amount,
          );
      _ref
          .read(outingProvider.notifier)
          .revertSettlementByFriendOrTx(
            outingId: tx.outingId,
            friendName: tx.merchant,
            amount: tx.amount,
          );
      FriendRepaymentMatcher.unmarkApplied(id);
    }

    // Don't cascade-refresh when removing the display rollup itself.
    final isRollup =
        tx != null && tx.note.trim().toLowerCase().startsWith('outing total');
    if (tx?.outingId != null && !isRollup) {
      _ref
          .read(outingProvider.notifier)
          .removeExpenseByTransactionId(tx!.outingId!, id);
    }
    // Friend Split is linked 1:1 to this ledger row — drop it so Friends no
    // longer shows a balance for a deleted payment (this transaction only).
    _ref.read(friendSplitProvider.notifier).removeSplitByTransactionId(id);
    state = state.where((t) => t.id != id).toList();
    _saveToStorage();
    // Offline delete: Hive cleared now; server delete when online (same as add/update).
    SyncService.queueTransactionDelete(id, remoteId: tx?.remoteId);
    if (tx?.outingId != null && !isRollup) {
      Future.microtask(() => refreshOutingTotalSpent(_ref, tx!.outingId!));
    }
  }

  /// Developer-only bulk clear. Returns how many transactions were removed.
  int clearTransactions(bool Function(Transaction tx) shouldRemove) {
    final toRemove = state.where(shouldRemove).toList();
    if (toRemove.isEmpty) return 0;

    for (final tx in toRemove) {
      if (tx.outingId != null) {
        _ref
            .read(outingProvider.notifier)
            .removeExpenseByTransactionId(tx.outingId!, tx.id);
      }
      _ref.read(friendSplitProvider.notifier).removeSplitByTransactionId(tx.id);
    }

    final removeIds = toRemove.map((t) => t.id).toSet();
    state = state.where((t) => !removeIds.contains(t.id)).toList();
    _saveToStorage();
    for (final tx in toRemove) {
      SyncService.queueTransactionDelete(tx.id, remoteId: tx.remoteId);
    }
    _ref.invalidate(notificationHistoryProvider);
    return toRemove.length;
  }

  int countMatching(bool Function(Transaction tx) predicate) =>
      state.where(predicate).length;

  void updateTransaction(Transaction transaction) {
    // Preserve remoteId if edit sheet dropped it — critical for offline→server update.
    final prev = state.where((t) => t.id == transaction.id).firstOrNull;
    final toSave =
        (transaction.remoteId == null || transaction.remoteId!.isEmpty) &&
                prev?.remoteId != null &&
                prev!.remoteId!.isNotEmpty
            ? transaction.copyWith(remoteId: prev.remoteId)
            : transaction;

    // Outing changed or cleared → drop old linked outing expense.
    if (prev?.outingId != null && prev!.outingId != toSave.outingId) {
      _preserveSplitOnUnlink(toSave.id, prev.outingId!);
      _ref
          .read(outingProvider.notifier)
          .removeExpenseByTransactionId(prev.outingId!, toSave.id);
    }

    state = [
      for (final t in state)
        if (t.id == toSave.id) toSave else t,
    ];
    _saveToStorage();
    // Offline update: Hive now; server upsert when online.
    SyncService.queueTransactionUpsert(toSave.toJson());
    _syncOutingExpenseIfNeeded(toSave);
    // Amount/category edit on an outing-linked row → refresh trip total rollup.
    final noteLower = toSave.note.trim().toLowerCase();
    final isRollup = noteLower.startsWith('outing total');
    if (!isRollup && toSave.outingId != null && toSave.outingId!.isNotEmpty) {
      Future.microtask(() => refreshOutingTotalSpent(_ref, toSave.outingId!));
    } else if (!isRollup &&
        prev?.outingId != null &&
        prev!.outingId!.isNotEmpty) {
      Future.microtask(() => refreshOutingTotalSpent(_ref, prev.outingId!));
    }
    _checkSpendAlerts(toSave);
  }

  /// Looks up the outing expense behind [txId] and re-homes its member split
  /// as a Friend Split. Called from every path that drops a trip link, so no
  /// caller has to remember to do it.
  void _preserveSplitOnUnlink(String txId, String outingId) {
    final outing =
        _ref.read(outingProvider).where((o) => o.id == outingId).firstOrNull;
    if (outing == null) return;
    final expense =
        outing.expenses.where((e) => e.transactionId == txId).firstOrNull;
    if (expense == null) return;
    preserveOutingSplitAsFriendSplit(
      outing: outing,
      expense: expense,
      transactionId: txId,
    );
  }

  /// Preserves an outing expense's member split as a standalone Friend Split
  /// before the trip link is dropped.
  ///
  /// A trip expense shared between members is split *by the trip* — the shares
  /// live on the `OutingExpense`, not on the transaction. Unlinking used to
  /// discard all of that, so a ₹1,200 bill split three ways came back as a
  /// plain ₹1,200 expense and the two friends simply stopped owing anything.
  /// Re-homing it as a Friend Split keeps the same people and the same amounts
  /// in a structure that does not need the trip to exist.
  ///
  /// Safe to call for any expense: solo and single-member rows convert to
  /// nothing and are left alone.
  void preserveOutingSplitAsFriendSplit({
    required Outing outing,
    required OutingExpense expense,
    required String transactionId,
  }) {
    final splitNotifier = _ref.read(friendSplitProvider.notifier);
    // One split per transaction (the remote schema enforces this with a unique
    // index). Every factory call mints a fresh id, so without this guard an
    // unlink reached twice would leave two records describing one bill.
    if (splitNotifier.findForTransaction(transactionId) != null) return;

    final split = FriendSplit.fromOutingExpense(
      outing: outing,
      expense: expense,
      transactionId: transactionId,
    );
    if (split == null) return;

    splitNotifier.addOrUpdateSplit(split);

    // Flag the row itself as shared. `badgeKind` would already infer this from
    // the friend_splits record, but the flags make it true independently of
    // Hive state — which is what `isSimpleTransaction` reads when deciding
    // whether the row may be linked to a trip again.
    final tx = state.where((t) => t.id == transactionId).firstOrNull;
    if (tx == null) return;
    state = [
      for (final t in state)
        if (t.id == transactionId)
          t.copyWith(isGroup: true, groupCount: split.members.length)
        else
          t,
    ];
    _saveToStorage();
  }

  /// Turns a manual outing expense into a standalone ledger transaction.
  ///
  /// A manual trip entry has no ledger row behind it — the `OutingExpense`
  /// *is* the record of that spend. Unlinking one used to call
  /// `deleteExpense()`, which destroyed it outright: the money disappeared
  /// from the app instead of becoming a normal transaction. Both unlink
  /// entry points (trip detail and transaction detail) call this first.
  ///
  /// Every field is carried across unchanged — unlinking changes the trip
  /// association and nothing else.
  /// Pass [outing] so a shared manual entry keeps its member split as a
  /// Friend Split; omit it only when the expense is known to be solo.
  void materialiseOutingExpense(OutingExpense expense, {Outing? outing}) {
    final accountName = () {
      final acc = (expense.accountId ?? '').trim();
      if (acc.isNotEmpty) return acc;
      final mode = expense.paymentMode.trim();
      return mode.isNotEmpty ? mode : 'Cash';
    }();
    final isCash =
        accountName.toLowerCase() == 'cash' ||
        expense.paymentMode.trim().toLowerCase() == 'cash';

    addTransaction(
      Transaction(
        // Reuse the expense id: addTransaction replaces a same-id row, so a
        // double unlink cannot leave two ledger rows for one spend.
        id: expense.id,
        merchant: expense.title,
        category: expense.category,
        account: accountName,
        paymentType: isCash ? 'Cash' : 'Online',
        time: '',
        amount: expense.amount,
        isExpense: true,
        date: expense.date,
        purpose: expense.purpose,
        note: '',
      ),
      // The trip is usually still active, and the auto-linker attaches any new
      // in-period expense to it — which would immediately re-link the row
      // being unlinked.
      applyOutingAutoLink: false,
    );

    // The ledger row reuses the expense id, so the split attaches to it.
    if (outing != null) {
      preserveOutingSplitAsFriendSplit(
        outing: outing,
        expense: expense,
        transactionId: expense.id,
      );
    }
  }

  void updateTransactionOuting(String txId, String? outingId) {
    final prev = state.where((t) => t.id == txId).firstOrNull;
    final prevOutingId = prev?.outingId;
    if (prevOutingId != null && prevOutingId != outingId) {
      _preserveSplitOnUnlink(txId, prevOutingId);
      _ref
          .read(outingProvider.notifier)
          .removeExpenseByTransactionId(prevOutingId, txId);
    }

    state = [
      for (final t in state)
        if (t.id == txId)
          t.copyWith(outingId: outingId, clearOutingId: outingId == null)
        else
          t,
    ];
    _saveToStorage();

    final updated = state.where((t) => t.id == txId).firstOrNull;
    if (updated != null) {
      SyncService.queueTransactionUpsert(updated.toJson());
      _syncOutingExpenseIfNeeded(updated);
    }
    // Unlink or re-link → recompute trip totals for both old and new outing.
    Future.microtask(() {
      if (prevOutingId != null && prevOutingId.isNotEmpty) {
        refreshOutingTotalSpent(_ref, prevOutingId);
      }
      if (outingId != null && outingId.isNotEmpty) {
        refreshOutingTotalSpent(_ref, outingId);
      }
    });
  }

  // Computed Balances — same formula as web (`src/lib/wealth.ts`):
  //   openingBalance + income − expense on that account
  // Skip: Opening Balance rows, outing-rollup display rows (web Transactions total).
  // Unlinked outing cash still reduces Cash (once).
  // Net worth = bank + cash + wallet − |credit|  (credit is debt).
  static const openingBalanceCategory = 'opening balance';

  bool _isBalanceExcluded(Transaction tx) {
    if (tx.category.trim().toLowerCase() == openingBalanceCategory) return true;
    // Web `isOutingRollupTransaction` — display-only Transactions total line.
    if (_isOutingRollup(tx)) return true;
    return false;
  }

  /// Mirrors web + [isOutingRollupTransaction] in outing_totals.dart.
  bool _isOutingRollup(Transaction tx) {
    return isOutingRollupTransaction(tx);
  }

  double get totalCashBalance {
    final cash = _ref
        .read(userStateProvider)
        .accounts
        .where((a) => a.isActive && a.isCash);
    if (cash.isEmpty) return getFullAccountBalance('Cash');
    return cash.fold(0.0, (sum, a) => sum + getFullAccountBalance(a.name));
  }

  double get personalBankBalance => getFullAccountBalance('Personal');
  double get homeBankBalance => getFullAccountBalance('Home');

  /// Net movement on [accountName] from the ledger only (excludes opening seed).
  double getAccountBalance(String accountName) {
    double balance = 0;
    final target = accountName.trim().toLowerCase();
    if (target.isEmpty) return 0;

    for (final tx in state) {
      if (tx.isPendingVerification) continue;
      if (_isBalanceExcluded(tx)) continue;

      final txAcc = tx.account.trim().toLowerCase();

      // New-style single-row transfer (transferType set): the destination
      // side is a different account than tx.account (the FROM side), so it
      // needs its own credit here. Gated on transferType (never set on
      // legacy two-row transfers) so a legacy transfer's second physical
      // row — which already provides its own credit — is never double-counted.
      if (tx.transferType != null) {
        final destTarget = (tx.transferTo ?? '').trim().toLowerCase();
        if (destTarget.isNotEmpty && destTarget == target && txAcc != target) {
          balance += tx.amount;
          continue;
        }
      }

      if (txAcc != target) continue;

      // Transfer + normal: expense leaves the account, income enters it.
      if (tx.isExpense) {
        balance -= tx.amount;
      } else {
        balance += tx.amount;
      }
    }

    // Manual outing cash rows that never got a ledger transaction still
    // reduce the paying account (web unlinkedOutingCashImpact).
    final accounts = _ref.read(userStateProvider).accounts;
    final isCashAccount =
        target == 'cash' ||
        accounts.any((a) => a.name.trim().toLowerCase() == target && a.isCash);
    final outings = _ref.read(outingProvider);
    for (final o in outings) {
      for (final e in o.expenses) {
        if (e.transactionId != null && e.transactionId!.isNotEmpty) continue;
        final expAcc = (e.accountId ?? '').trim().toLowerCase();
        final matchNamed = expAcc.isNotEmpty && expAcc == target;
        // Default unlinked manual outing cash → Cash account (web parity).
        final matchCashDefault =
            isCashAccount && (expAcc.isEmpty || expAcc == 'cash');
        if (matchNamed || matchCashDefault) {
          balance -= e.amount;
        }
      }
    }

    return balance;
  }

  double getRolloverDelta(String accountName) {
    if (!Hive.isBoxOpen('settings')) return 0.0;
    final raw = Hive.box('settings').get('account_rollover_deltas');
    if (raw is Map) {
      return (raw[accountName.trim().toLowerCase()] as num? ?? 0).toDouble();
    }
    return 0.0;
  }

  /// Full balance including opening seed and rollover baseline for one account.
  double getFullAccountBalance(String accountName) {
    final accounts = _ref.read(userStateProvider).accounts;
    final target = accountName.trim().toLowerCase();
    double opening = 0;
    for (final a in accounts) {
      if (a.name.trim().toLowerCase() == target) {
        opening = a.openingBalance;
        break;
      }
    }
    return opening +
        getRolloverDelta(accountName) +
        getAccountBalance(accountName);
  }

  /// Net worth shown on Home / Accounts (outside the Wealth page):
  ///   bank + cash + wallet − credit card dues.
  /// Goals and investments are NOT included here — they only show on the
  /// Wealth page with their own totals. Investment-type accounts are skipped.
  /// Credit card with positive starting balance never increases net worth upon spending.
  double get netWorth {
    final accounts = _ref
        .read(userStateProvider)
        .accounts
        .where((a) => a.isActive);

    var bank = 0.0;
    var cash = 0.0;
    var creditDebt = 0.0;

    void addBalance(String name, String type, double opening) {
      final t = type.trim().toLowerCase();
      final ledgerDelta = getAccountBalance(name) + getRolloverDelta(name);

      if (t == 'cash') {
        cash += opening + ledgerDelta;
      } else if (t == 'credit') {
        // For credit card, positive opening balance represents starting debt.
        // Spending decreases getAccountBalance, so debt increases.
        // Spending must NEVER increase net worth.
        final debt =
            opening > 0
                ? (opening - ledgerDelta).clamp(0.0, double.infinity)
                : (-(opening + ledgerDelta)).clamp(0.0, double.infinity);
        creditDebt += debt;
      } else if (t == 'investment' ||
          t == 'mutual_fund' ||
          t == 'mutual_funds' ||
          t == 'stocks' ||
          t == 'equity' ||
          t == 'crypto') {
        // Investments live on the Wealth page only.
      } else {
        // bank, wallet, and generic accounts
        bank += opening + ledgerDelta;
      }
    }

    final list = accounts.toList();
    if (list.isEmpty) {
      final accountsBox = Hive.box('settings');
      final List<dynamic>? accountsRaw = accountsBox.get('onboardingAccounts');
      if (accountsRaw != null) {
        for (final a in accountsRaw) {
          if (a is! Map) continue;
          if (a['isActive'] == false) continue;
          final name = (a['name'] ?? '').toString();
          if (name.isEmpty) continue;
          final opening = (a['openingBalance'] as num? ?? 0).toDouble();
          final type = (a['type'] ?? 'Bank').toString();
          addBalance(name, type, opening);
        }
      }
    } else {
      for (final account in list) {
        addBalance(account.name, account.type, account.openingBalance);
      }
    }

    return bank + cash - creditDebt;
  }

  /// Net worth by purpose — per-purpose ledger with opening balances only on Personal.
  Map<String, double> netWorthByPurpose(List<String> purposes) {
    final map = <String, double>{for (final p in purposes) p: 0.0};
    if (map.isEmpty) return map;

    final personalKey = purposes.firstWhere(
      (p) => p.trim().toLowerCase() == 'personal',
      orElse: () => purposes.first,
    );

    final accounts =
        _ref.read(userStateProvider).accounts.where((a) => a.isActive).toList();

    String resolvePurpose(String? raw) {
      final purpose =
          (raw == null || raw.trim().isEmpty) ? personalKey : raw.trim();
      if (map.containsKey(purpose)) return purpose;
      return purposes.firstWhere(
        (p) => p.toLowerCase() == purpose.toLowerCase(),
        orElse: () => personalKey,
      );
    }

    for (final purposeName in purposes) {
      final isPersonal =
          purposeName.trim().toLowerCase() == personalKey.trim().toLowerCase();

      var bank = 0.0;
      var cash = 0.0;
      var creditDebt = 0.0;

      for (final account in accounts) {
        final target = account.name.trim().toLowerCase();
        var bal = isPersonal ? account.openingBalance : 0.0;
        var ledgerDelta = 0.0;

        for (final tx in state) {
          if (tx.isPendingVerification) continue;
          if (_isBalanceExcluded(tx)) continue;
          if (tx.account.trim().toLowerCase() != target) continue;
          final txP = resolvePurpose(tx.purpose);
          if (txP.toLowerCase() != purposeName.toLowerCase()) continue;
          final d = tx.isExpense ? -tx.amount : tx.amount;
          bal += d;
          ledgerDelta += d;
        }

        if (isPersonal) {
          final isCashAccount = account.isCash || target == 'cash';
          final outings = _ref.read(outingProvider);
          for (final o in outings) {
            for (final e in o.expenses) {
              if (e.transactionId != null && e.transactionId!.isNotEmpty) {
                continue;
              }
              final expAcc = (e.accountId ?? '').trim().toLowerCase();
              final matchNamed = expAcc.isNotEmpty && expAcc == target;
              final matchCashDefault =
                  isCashAccount && (expAcc.isEmpty || expAcc == 'cash');
              if (matchNamed || matchCashDefault) {
                bal -= e.amount;
                ledgerDelta -= e.amount;
              }
            }
          }
        }

        final t = account.type.trim().toLowerCase();
        if (t == 'cash') {
          cash += bal;
        } else if (t == 'credit') {
          final debt =
              isPersonal && account.openingBalance > 0
                  ? (account.openingBalance - ledgerDelta).clamp(
                    0.0,
                    double.infinity,
                  )
                  : (-bal).clamp(0.0, double.infinity);
          creditDebt += debt;
        } else if (t == 'investment' ||
            t == 'mutual_fund' ||
            t == 'mutual_funds' ||
            t == 'stocks' ||
            t == 'equity' ||
            t == 'crypto') {
          // Investments are shown on the Wealth page only.
        } else {
          bank += bal;
        }
      }

      map[purposeName] = bank + cash - creditDebt;
    }

    return map;
  }
}

final transactionProvider =
    StateNotifierProvider<TransactionNotifier, List<Transaction>>(
      (ref) => TransactionNotifier(ref),
    );

/// Fingerprint so net worth / home KPIs recompute on any add/edit/delete
/// (not only list length — amount, account, and outing cash all matter).
int _ledgerFingerprint(List<Transaction> t) {
  var h = t.length;
  for (final x in t) {
    h = Object.hash(
      h,
      x.id,
      x.amount.round(),
      x.isExpense,
      x.account,
      x.category,
      x.outingId,
      x.isPendingVerification,
    );
  }
  return h;
}

int _accountsFingerprint(UserState u) {
  var h = 0;
  for (final a in u.accounts) {
    h = Object.hash(
      h,
      a.id,
      a.name,
      a.type,
      a.openingBalance.round(),
      a.isActive,
    );
  }
  return h;
}

int _outingCashFingerprint(List<Outing> outings) {
  var h = outings.length;
  for (final o in outings) {
    h = Object.hash(h, o.id, o.isActive);
    for (final e in o.expenses) {
      h = Object.hash(
        h,
        e.id,
        e.amount.round(),
        e.transactionId,
        e.accountId,
        e.paidByMemberId,
      );
    }
  }
  return h;
}

final netWorthProvider = Provider<double>((ref) {
  ref.watch(transactionProvider.select(_ledgerFingerprint));
  ref.watch(userStateProvider.select(_accountsFingerprint));
  ref.watch(outingProvider.select(_outingCashFingerprint));
  return ref.read(transactionProvider.notifier).netWorth;
});

final netWorthByPurposeProvider = Provider<Map<String, double>>((ref) {
  ref.watch(transactionProvider.select(_ledgerFingerprint));
  ref.watch(userStateProvider.select((u) => u.purposeTypes.join(',')));
  ref.watch(outingProvider.select(_outingCashFingerprint));
  final purposes = ref.read(userStateProvider).purposeTypes;
  return ref.read(transactionProvider.notifier).netWorthByPurpose(purposes);
});

/// This-month income, spent, rollover, and net per purpose.
/// Same Activity rules as the Activity summary card, including previous-month
/// leftover (not chained). Used by Accounts By Purpose.
final activityPurposeBreakdownProvider =
    Provider<Map<String, ActivityPurposeBreakdown>>((ref) {
      final txs = ref.watch(transactionProvider);
      final outings = ref.watch(outingProvider);
      final purposes = ref.watch(
        userStateProvider.select((u) => u.purposeTypes),
      );
      final now = DateTime.now();
      final monthStart = DateTime(now.year, now.month, 1);
      return {
        for (final purpose in purposes)
          purpose: activityPurposeBreakdown(
            transactions: txs,
            outings: outings,
            purpose: purpose,
            monthStart: monthStart,
          ),
      };
    });

/// Net only (income + rollover − spent). Kept for callers that need a map of
/// doubles; prefer [activityPurposeBreakdownProvider] for the full row.
final activityPurposeNetProvider = Provider<Map<String, double>>((ref) {
  final rows = ref.watch(activityPurposeBreakdownProvider);
  return {for (final e in rows.entries) e.key: e.value.net};
});

/// This-month income (excludes transfers, opening balance, repayments).
final monthlyIncomeProvider = Provider<double>((ref) {
  ref.watch(transactionProvider.select(_ledgerFingerprint));
  final txs = ref.read(transactionProvider);
  final now = DateTime.now();
  final thisMonthTxs =
      txs.where((t) {
        if (t.isPendingVerification) return false;
        return t.date.year == now.year && t.date.month == now.month;
      }).toList();

  return computeReimbursementTotals(thisMonthTxs).income;
});

/// This-month spend (excludes transfers, opening balance, outing rollups;
/// includes unlinked outing cash you paid).
final monthlyExpenseProvider = Provider<double>((ref) {
  ref.watch(transactionProvider.select(_ledgerFingerprint));
  ref.watch(outingProvider.select(_outingCashFingerprint));
  final txs = ref.read(transactionProvider);
  final outings = ref.read(outingProvider);
  final now = DateTime.now();

  final thisMonthTxs =
      txs.where((t) {
        if (t.isPendingVerification) return false;
        return t.date.year == now.year && t.date.month == now.month;
      }).toList();

  final List<Transaction> allMonthRows = [...thisMonthTxs];

  final linkedTxIds =
      txs.where((t) => t.outingId != null).map((t) => t.id).toSet();

  for (final outing in outings) {
    for (final e in outing.expenses) {
      if (e.transactionId != null && linkedTxIds.contains(e.transactionId)) {
        continue;
      }
      if (e.date.year != now.year || e.date.month != now.month) continue;
      // GROSS, exactly as the Activity list adds a manual trip entry. Using
      // `shareForMember` here meant Home already removed the friends' portion
      // and then `computeReimbursementTotals` removed their returns on top —
      // reducing the same money twice, and disagreeing with Activity, which
      // starts from what was actually paid.
      if (e.amount > 0) {
        allMonthRows.add(
          Transaction(
            merchant: outing.title,
            category: outing.category.isNotEmpty ? outing.category : 'Trip',
            account: 'Mixed',
            time: 'Trip',
            amount: e.amount,
            isExpense: true,
            date: e.date,
            purpose: 'Personal',
            outingId: outing.id,
            note: 'Outing · ${outing.category}',
          ),
        );
      }
    }
  }

  return computeReimbursementTotals(allMonthRows).netSpend;
});

void _addRelated(
  Map<String, Map<String?, double>> related,
  String purpose,
  String? outingId,
  double amount,
) {
  final key = (outingId?.trim().isNotEmpty ?? false) ? outingId!.trim() : null;
  final byOuting = related.putIfAbsent(purpose, () => <String?, double>{});
  byOuting[key] = (byOuting[key] ?? 0) + amount;
}

/// This-month expense total per purpose (Personal, Family, …).
/// Used on Home instead of account balances.
final monthlyExpenseByPurposeProvider = Provider<Map<String, double>>((ref) {
  ref.watch(transactionProvider.select(_ledgerFingerprint));
  ref.watch(userStateProvider.select((u) => u.purposeTypes.join(',')));
  ref.watch(outingProvider.select(_outingCashFingerprint));
  final purposes = ref.read(userStateProvider).purposeTypes;
  final txs = ref.read(transactionProvider);
  final outings = ref.read(outingProvider);
  final now = DateTime.now();

  final map = <String, double>{
    for (final p in purposes)
      if (p.trim().isNotEmpty) p: 0.0,
  };
  if (map.isEmpty) {
    map['Personal'] = 0.0;
  }

  // Gross expense per purpose, split by the trip it belongs to (null = no
  // trip). Lets a return be netted only against spending it is related to.
  final related = <String, Map<String?, double>>{};

  String resolvePurpose(String? raw) {
    final p = (raw ?? 'Personal').trim();
    if (p.isEmpty) return map.keys.first;
    if (map.containsKey(p)) return p;
    final match = map.keys.firstWhere(
      (k) => k.toLowerCase() == p.toLowerCase(),
      orElse: () => map.keys.first,
    );
    return match;
  }

  // Track linked transaction IDs so we skip them in the outing loop.
  final linkedTxIds =
      txs.where((t) => t.outingId != null).map((t) => t.id).toSet();

  for (final t in txs) {
    if (t.isPendingVerification) continue;
    if (t.date.year != now.year || t.date.month != now.month) continue;
    if (!t.isExpense) continue;
    final cat = t.category.trim().toLowerCase();
    if (t.isTransfer || cat == 'transfer' || cat == 'settlements') continue;
    if (cat == 'opening balance') continue;
    final note = t.note.trim().toLowerCase();
    if (note.startsWith('outing total') || note.startsWith('your share of ')) {
      continue;
    }

    if (t.isSplitExpense && t.splits.isNotEmpty) {
      // For split transactions, distribute each slice's amount to its purpose.
      for (final s in t.splits) {
        final key = resolvePurpose(
          s.purposeId.isEmpty ? t.purpose : s.purposeId,
        );
        map[key] = (map[key] ?? 0) + s.amount;
        _addRelated(related, key, t.outingId, s.amount);
      }
    } else {
      // Normal transaction — use the top-level purpose.
      final key = resolvePurpose(t.purpose);
      map[key] = (map[key] ?? 0) + t.amount;
      _addRelated(related, key, t.outingId, t.amount);
    }
  }

  // ── Unlinked outing expenses (cash / manual entries with no bank SMS) ──
  for (final outing in outings) {
    for (final e in outing.expenses) {
      if (e.transactionId != null && linkedTxIds.contains(e.transactionId)) {
        continue;
      }
      if (e.date.year != now.year || e.date.month != now.month) continue;
      if (e.amount <= 0) continue;
      final key = resolvePurpose('Personal');
      map[key] = (map[key] ?? 0) + e.amount;
      _addRelated(related, key, outing.id, e.amount);
    }
  }

  // Friend returns reduce the purpose they were spent under — but ONLY up to
  // the spending in that purpose they actually relate to.
  for (final t in txs) {
    if (t.isPendingVerification) continue;
    if (t.date.year != now.year || t.date.month != now.month) continue;
    if (!t.isFriendReturn) continue;
    final key = resolvePurpose(t.purpose);
    final outingKey =
        (t.outingId?.trim().isNotEmpty ?? false) ? t.outingId!.trim() : null;
    final available = related[key]?[outingKey] ?? 0;
    if (available <= 0) continue; // nothing here for it to reduce
    final applied = t.amount <= available ? t.amount : available;
    related[key]![outingKey] = available - applied;
    map[key] = ((map[key] ?? 0) - applied).clamp(0.0, double.infinity);
  }

  return map;
});

/// Previous months carry forward balance (income minus expenses prior to this month).
/// Returns unspent surplus (positive) or overspent deficit (negative).
/// Family key: which purpose slice, and the first day of whichever
/// month/period is currently selected in the UI (This Month, Last Month, a
/// historical month, or a custom range's start month).
typedef CarryForwardArgs = ({String? purpose, DateTime periodStart});

/// "Previous Month" carry-forward, relative to whatever period is selected.
///
/// Closing Balance is defined recursively:
///   ClosingBalance(M) = ClosingBalance(M-1) + Income(M) - Expense(M)
/// By induction this equals the net (income - expense) of every transaction
/// dated before the first day of M — so "Previous Month Balance" for the
/// selected period is simply the cumulative net of all transactions before
/// that period's start month, not just the single prior calendar month's
/// transactions in isolation. A brand-new account (nothing before the
/// period) naturally nets to 0, never null/N/A.
final previousMonthCarryForwardProvider =
    Provider.family<double, CarryForwardArgs>((ref, args) {
      ref.watch(transactionProvider.select(_ledgerFingerprint));
      final txs = ref.read(transactionProvider);
      final firstOfPeriod = DateTime(
        args.periodStart.year,
        args.periodStart.month,
        1,
      );
      final purposeFilter = args.purpose;

      double priorIncome = 0.0;
      double priorExpense = 0.0;

      bool matchesPurpose(Transaction t, String? slicePurpose) {
        if (purposeFilter == null ||
            purposeFilter.trim().isEmpty ||
            purposeFilter.trim().toLowerCase() == 'all') {
          return true;
        }
        final target = purposeFilter.trim().toLowerCase();
        final p = (slicePurpose ?? t.purpose ?? '').trim().toLowerCase();
        if (p == target) return true;
        // Canonical check for Family / Home
        if ((target == 'family' || target == 'home') &&
            (p == 'family' || p == 'home')) {
          return true;
        }
        return false;
      }

      for (final t in txs) {
        if (t.isPendingVerification) continue;
        // Only include transactions before the selected period's start month.
        if (!t.date.isBefore(firstOfPeriod)) continue;

        final cat = t.category.trim().toLowerCase();
        if (t.isTransfer || cat == 'transfer' || cat == 'settlements') continue;
        if (cat == 'opening balance') continue;

        if (t.isFriendReturn) {
          if (matchesPurpose(t, t.purpose)) {
            priorExpense -= t.amount;
          }
        } else if (!t.isExpense) {
          if (matchesPurpose(t, t.purpose)) {
            priorIncome += t.amount;
          }
        } else {
          final note = t.note.trim().toLowerCase();
          if (note.startsWith('outing total') ||
              note.startsWith('your share of ')) {
            continue;
          }

          if (t.isSplitExpense && t.splits.isNotEmpty) {
            for (final s in t.splits) {
              if (matchesPurpose(t, s.purposeId)) {
                priorExpense += s.amount;
              }
            }
          } else {
            if (matchesPurpose(t, t.purpose)) {
              priorExpense += t.amount;
            }
          }
        }
      }

      return priorIncome - priorExpense;
    });
