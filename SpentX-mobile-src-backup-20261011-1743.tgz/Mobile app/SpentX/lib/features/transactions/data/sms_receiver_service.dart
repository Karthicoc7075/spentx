import 'package:permission_handler/permission_handler.dart';

/// Live SMS arrives through the native `SmsReceiver` (EventChannel
/// `com.spentx.app/sms`, or the encrypted queue + WorkManager when the app is
/// closed). Missed messages are recovered by `SmsInboxCatchUp`.
///
/// This used to also register the `telephony` plugin's listener with
/// `listenInBackground: true`. That path never fired — the plugin's
/// IncomingSmsReceiver was not declared in the manifest — and its background
/// handler could not see the session anyway, so it was removed together with
/// the dependency. The class keeps its old API so callers only ensure the SMS
/// permission is granted.
class SmsReceiverService {
  SmsReceiverService._();

  /// Kept for API compatibility; nothing to stop.
  static Future<void> stopListening() async {}

  /// Ensures RECEIVE_SMS / READ_SMS are granted. Returns the grant result.
  static Future<bool> startListening() async {
    final status = await Permission.sms.request();
    return status.isGranted;
  }
}
