import 'dart:io' show Platform;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/providers/pending_account_provider.dart';
import '../../../../core/theme/spentx_tokens.dart';

/// Entry point to account discovery from the Accounts screen.
///
/// Two states, one row: a nudge when SMS has found accounts the user has not
/// added, and an ordinary "scan" affordance when it has not. Hidden entirely
/// on iOS, where there is no SMS to read.
class AccountDiscoveryBanner extends ConsumerWidget {
  const AccountDiscoveryBanner({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (!Platform.isAndroid) return const SizedBox.shrink();

    final t = context.tokens;
    final pending = ref.watch(pendingAccountProvider);
    final hasFindings = pending.isNotEmpty;

    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: InkWell(
        borderRadius: BorderRadius.circular(AppRadius.tile),
        onTap: () => context.push('/account-discovery'),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: hasFindings ? t.primarySoft : t.surfaceVariant,
            borderRadius: BorderRadius.circular(AppRadius.tile),
            border: Border.all(
              color: hasFindings ? t.primary.withValues(alpha: 0.35) : t.border,
            ),
          ),
          child: Row(
            children: [
              Icon(
                hasFindings ? LucideIcons.sparkles : LucideIcons.search,
                size: 18,
                color: hasFindings ? t.primary : t.textSecondary,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  hasFindings
                      ? (pending.length == 1
                          ? '1 account found in your SMS'
                          : '${pending.length} accounts found in your SMS')
                      : 'Scan SMS for accounts',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: hasFindings ? t.primary : t.textSecondary,
                  ),
                ),
              ),
              Icon(
                LucideIcons.chevronRight,
                size: 18,
                color: hasFindings ? t.primary : t.textSecondary,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
