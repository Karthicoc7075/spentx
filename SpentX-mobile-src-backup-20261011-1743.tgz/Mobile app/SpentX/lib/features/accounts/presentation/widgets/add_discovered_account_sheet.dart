import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/design/sx_inputs.dart';
import '../../../../core/design/sx_primitives.dart';
import '../../../../core/providers/pending_account_provider.dart';
import '../../../../core/theme/spentx_tokens.dart';
import '../../../../core/widgets/reference_ui.dart';
import '../../../../core/widgets/premium_bottom_sheet.dart';
import '../../../../models/pending_account.dart';

/// Confirm a discovered account before it becomes real.
///
/// The whole point of the feature lives in this sheet: SMS filled in the bank,
/// the last-4 and a guess at the type, and the user supplies the two things
/// SMS can never know — what to call it, and what it actually started with.
///
/// The balance quoted in their latest SMS is shown, clearly labelled, and is
/// never pre-filled into the opening balance field. Today's balance is not the
/// balance the ledger should start from, and prefilling it would launder a
/// guess into a number the user believes they entered.
class AddDiscoveredAccountSheet extends ConsumerStatefulWidget {
  const AddDiscoveredAccountSheet({super.key, required this.pending});

  final PendingAccount pending;

  static Future<void> show({
    required BuildContext context,
    required PendingAccount pending,
  }) {
    return PremiumBottomSheet.show(
      context: context,
      child: AddDiscoveredAccountSheet(pending: pending),
    );
  }

  @override
  ConsumerState<AddDiscoveredAccountSheet> createState() =>
      _AddDiscoveredAccountSheetState();
}

class _AddDiscoveredAccountSheetState
    extends ConsumerState<AddDiscoveredAccountSheet> {
  late final TextEditingController _name = TextEditingController(
    text: widget.pending.suggestedName,
  );
  final TextEditingController _balance = TextEditingController();

  late String _type = widget.pending.suggestedType;
  String? _error;
  bool _saving = false;

  static const _types = ['Bank', 'Credit', 'Wallet'];

  @override
  void dispose() {
    _name.dispose();
    _balance.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_saving) return;
    setState(() {
      _saving = true;
      _error = null;
    });

    final error = ref
        .read(pendingAccountProvider.notifier)
        .convert(
          pending: widget.pending,
          name: _name.text,
          type: _type,
          openingBalance: double.tryParse(_balance.text.trim()) ?? 0,
        );

    if (!mounted) return;

    if (error != null) {
      setState(() {
        _saving = false;
        _error = error;
      });
      return;
    }

    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          '${_name.text.trim()} added — future SMS will be tracked',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final p = widget.pending;

    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 8,
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Add ${p.displayBank}',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                        color: t.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Account ending ${p.last4} · seen in ${p.hitCount} '
                      '${p.hitCount == 1 ? "message" : "messages"}',
                      style: TextStyle(fontSize: 13, color: t.textSecondary),
                    ),
                  ],
                ),
              ),
              SoftCircleIconButton(
                icon: Icons.close_rounded,
                tooltip: 'Close',
                onPressed: () => Navigator.maybePop(context),
              ),
            ],
          ),
          const SizedBox(height: 20),

          SxTextField(
            controller: _name,
            label: 'Account name',
            hint: 'e.g. HDFC Credit Card',
          ),
          const SizedBox(height: 16),

          Text(
            'Type',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: t.textSecondary,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              for (final type in _types) ...[
                Expanded(
                  child: _TypeChip(
                    label: type,
                    selected: _type == type,
                    onTap: () => setState(() => _type = type),
                  ),
                ),
                if (type != _types.last) const SizedBox(width: 8),
              ],
            ],
          ),
          const SizedBox(height: 16),

          SxTextField(
            controller: _balance,
            label: 'Opening balance (optional)',
            hint: '0',
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
          ),
          const SizedBox(height: 8),
          Text(
            p.lastSeenBalance != null
                ? 'Your latest SMS mentioned ₹${p.lastSeenBalance!.toStringAsFixed(0)}. '
                    'That is the balance today, not what this account started '
                    'with — enter your own opening balance, or leave it blank.'
                : 'What this account started with. Leave blank if you are '
                    'not sure — you can set it later in Accounts.',
            style: TextStyle(fontSize: 12, color: t.textDisabled, height: 1.4),
          ),

          if (_error != null) ...[
            const SizedBox(height: 12),
            Text(_error!, style: TextStyle(fontSize: 13, color: t.negative)),
          ],

          const SizedBox(height: 24),
          SxPrimaryButton(
            label: _saving ? 'Adding…' : 'Add account',
            onPressed: _saving ? null : _save,
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }
}

class _TypeChip extends StatelessWidget {
  const _TypeChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 42,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: selected ? t.primarySoft : t.surfaceVariant,
          borderRadius: BorderRadius.circular(AppRadius.tile),
          border: Border.all(color: selected ? t.primary : t.border),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: selected ? t.primary : t.textSecondary,
          ),
        ),
      ),
    );
  }
}
