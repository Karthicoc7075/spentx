import 'package:flutter/material.dart';

import '../../../../core/theme/soft_palette.dart';
import '../../../../core/theme/spentx_tokens.dart';
import '../../../../core/widgets/reference_ui.dart';

/// Soft account list tile surface.
class SoftAccountCard extends StatelessWidget {
  const SoftAccountCard({
    super.key,
    required this.child,
    this.onTap,
    this.padding = const EdgeInsets.all(16),
  });

  final Widget child;
  final VoidCallback? onTap;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    final card = SxSoftCard(padding: padding, child: child);
    if (onTap == null) return card;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: const BorderRadius.all(Radius.circular(24)),
        child: card,
      ),
    );
  }
}

/// Soft section label for Accounts groups (Bank / Cash / Wallet).
class SoftAccountSectionTitle extends StatelessWidget {
  const SoftAccountSectionTitle({
    super.key,
    required this.title,
    this.trailing,
  });

  final String title;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    return Padding(
      padding: const EdgeInsets.only(top: 8, bottom: 10),
      child: Row(
        children: [
          Expanded(
            child: Text(
              title,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.2,
                color: t.textSecondary,
              ),
            ),
          ),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}

/// Soft emerald pill used on Accounts hero chrome.
class SoftAccountPill extends StatelessWidget {
  const SoftAccountPill({
    super.key,
    required this.label,
    this.icon,
  });

  final String label;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    return SxPill(
      color: SoftPalette.emerald.withValues(alpha: 0.18),
      textColor: SoftPalette.mint,
      side: BorderSide(color: SoftPalette.mint.withValues(alpha: 0.45)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 12, color: SoftPalette.mint),
            const SizedBox(width: 4),
          ],
          Text(label),
        ],
      ),
    );
  }
}
