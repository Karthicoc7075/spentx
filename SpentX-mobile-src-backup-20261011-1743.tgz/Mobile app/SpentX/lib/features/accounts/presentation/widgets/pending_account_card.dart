import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/design/sx_primitives.dart';
import '../../../../core/providers/pending_account_provider.dart';
import '../../../../core/theme/spentx_tokens.dart';
import '../../../../models/pending_account.dart';
import 'add_discovered_account_sheet.dart';

/// One "we think you have this account" suggestion.
///
/// Deliberately a card in a list, never a modal: this is information the user
/// can act on later, and interrupting a session to demand an answer about an
/// account is exactly the pushiness the feature is meant to avoid. Two equal
/// actions, no default, because neither answer is the one we want.
class PendingAccountCard extends ConsumerWidget {
  const PendingAccountCard({
    super.key,
    required this.pending,
    this.dense = false,
  });

  final PendingAccount pending;

  /// Inline placement (Home nudge, Detected SMS) — drops the evidence line.
  final bool dense;

  IconData get _icon => switch (pending.suggestedType) {
        'Credit' => LucideIcons.creditCard,
        'Wallet' => LucideIcons.wallet,
        _ => LucideIcons.landmark,
      };

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.tokens;

    return SxCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              SxIconCircle(
                icon: _icon,
                background: t.primarySoft,
                foreground: t.primary,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${pending.displayBank} · XX${pending.last4}',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: t.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Looks like a ${_typeLabel(pending.suggestedType)}',
                      style: TextStyle(fontSize: 13, color: t.textSecondary),
                    ),
                  ],
                ),
              ),
              if (!dense)
                SxBadge(
                  label: pending.hitCount == 1
                      ? '1 msg'
                      : '${pending.hitCount} msgs',
                ),
            ],
          ),
          if (!dense && pending.lastSeenBalance != null) ...[
            const SizedBox(height: 10),
            Text(
              // Labelled as coming from the message, because it is not the
              // opening balance and must never be mistaken for one.
              'Last SMS balance ₹${pending.lastSeenBalance!.toStringAsFixed(0)}'
              ' — from your SMS, not your opening balance',
              style: TextStyle(fontSize: 12, color: t.textDisabled),
            ),
          ],
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: SxSecondaryButtonLike(
                  label: 'Ignore',
                  onTap: () => _confirmIgnore(context, ref),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                flex: 2,
                child: SxPrimaryButton(
                  label: 'Add account',
                  onPressed: () => AddDiscoveredAccountSheet.show(
                    context: context,
                    pending: pending,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  static String _typeLabel(String type) => switch (type) {
        'Credit' => 'credit card',
        'Wallet' => 'wallet',
        _ => 'bank account',
      };

  void _confirmIgnore(BuildContext context, WidgetRef ref) {
    ref.read(pendingAccountProvider.notifier).ignore(pending.id);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${pending.displayBank} XX${pending.last4} ignored'),
        action: SnackBarAction(
          label: 'Undo',
          onPressed: () =>
              ref.read(pendingAccountProvider.notifier).restore(pending.id),
        ),
      ),
    );
  }
}

/// Outline button matching [SxPrimaryButton]'s height, for the paired
/// Ignore/Add row. [SxSecondaryButton] is icon-led and sized for toolbars.
class SxSecondaryButtonLike extends StatelessWidget {
  const SxSecondaryButtonLike({
    super.key,
    required this.label,
    required this.onTap,
  });

  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    return SizedBox(
      height: 46,
      child: OutlinedButton(
        onPressed: onTap,
        style: OutlinedButton.styleFrom(
          side: BorderSide(color: t.border),
          foregroundColor: t.textSecondary,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppRadius.tile),
          ),
        ),
        child: Text(
          label,
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
        ),
      ),
    );
  }
}
