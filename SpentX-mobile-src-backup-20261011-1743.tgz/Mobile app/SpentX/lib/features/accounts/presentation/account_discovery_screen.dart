import 'dart:io' show Platform;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../core/design/sx_feedback.dart';
import '../../../core/providers/pending_account_provider.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../core/widgets/reference_ui.dart';
import '../../../models/pending_account.dart';
import 'widgets/pending_account_card.dart';
import 'widgets/soft_account_widgets.dart';

/// "Accounts we found" — the review list for accounts inferred from SMS.
class AccountDiscoveryScreen extends ConsumerStatefulWidget {
  const AccountDiscoveryScreen({super.key});

  @override
  ConsumerState<AccountDiscoveryScreen> createState() =>
      _AccountDiscoveryScreenState();
}

class _AccountDiscoveryScreenState
    extends ConsumerState<AccountDiscoveryScreen> {
  bool _showIgnored = false;

  bool get _smsAvailable => Platform.isAndroid;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) ref.read(pendingAccountProvider.notifier).reconcile();
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = isDark ? SoftPalette.darkBg : SoftPalette.bg;
    final muted = isDark ? SoftPalette.darkMuted : SoftPalette.muted;
    final suggestions = ref.watch(pendingAccountProvider);
    final ignored = ref.read(pendingAccountProvider.notifier).ignored;

    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: Column(
          children: [
            SoftPageHeader(title: 'Accounts we found'),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
                children: [
                  Text(
                    _smsAvailable
                        ? 'New bank alerts are detected as they arrive. Nothing is '
                            'added until you say so — review accounts here.'
                        : 'Reading SMS is not available on this platform, so accounts '
                            'have to be added by hand.',
                    style: TextStyle(
                      fontSize: 14,
                      color: muted,
                      height: 1.45,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 20),
                  if (_smsAvailable) const SizedBox(height: 24),
                  if (suggestions.isEmpty)
                    SoftAccountCard(
                      child: SxEmptyState(
                        icon: LucideIcons.landmark,
                        message:
                            'Nothing to review yet.\nNew bank alerts for accounts '
                            'you have not added will show up here.',
                      ),
                    )
                  else ...[
                    SoftAccountSectionTitle(
                      title:
                          suggestions.length == 1
                              ? '1 account to review'
                              : '${suggestions.length} accounts to review',
                    ),
                    for (final pending in suggestions) ...[
                      PendingAccountCard(pending: pending),
                      const SizedBox(height: 12),
                    ],
                  ],
                  if (ignored.isNotEmpty) ...[
                    const SizedBox(height: 12),
                    InkWell(
                      onTap: () => setState(() => _showIgnored = !_showIgnored),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        child: Row(
                          children: [
                            Icon(
                              _showIgnored
                                  ? LucideIcons.chevronDown
                                  : LucideIcons.chevronRight,
                              size: 16,
                              color: muted,
                            ),
                            const SizedBox(width: 6),
                            Text(
                              'Ignored (${ignored.length})',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: muted,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    if (_showIgnored)
                      for (final pending in ignored)
                        _IgnoredRow(pending: pending),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _IgnoredRow extends ConsumerWidget {
  const _IgnoredRow({required this.pending});

  final PendingAccount pending;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final muted =
        Theme.of(context).brightness == Brightness.dark
            ? SoftPalette.darkMuted
            : SoftPalette.muted;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: SoftAccountCard(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        child: Row(
          children: [
            Expanded(
              child: Text(
                '${pending.displayBank} · XX${pending.last4}',
                style: TextStyle(fontSize: 14, color: muted),
              ),
            ),
            TextButton(
              onPressed:
                  () => ref
                      .read(pendingAccountProvider.notifier)
                      .restore(pending.id),
              child: const Text(
                'Restore',
                style: TextStyle(
                  color: SoftPalette.emerald,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
