import 'package:flutter/material.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../core/theme/spentx_tokens.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:intl/intl.dart';
import 'package:go_router/go_router.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/widgets/premium_bottom_sheet.dart';
import '../../../core/providers/transaction_provider.dart' as model;
import '../../../core/providers/user_state_provider.dart';
import '../../../models/account_model.dart';
import '../../../core/widgets/reference_ui.dart';
import '../../transactions/presentation/add_transaction_sheet.dart';
import '../../wealth/data/daily_snapshot_provider.dart';
import '../../wealth/presentation/wealth_screen.dart';
import '../../wealth/presentation/widgets/daily_snapshot_card.dart';
import '../../wealth/presentation/widgets/soft_wealth_widgets.dart';

void _showAddFundsSheet(BuildContext context) {
  PremiumBottomSheet.show(context: context, child: const _AddFundsFlow());
}

class AccountsScreen extends ConsumerStatefulWidget {
  const AccountsScreen({super.key, this.initialWealth = false});

  final bool initialWealth;

  @override
  ConsumerState<AccountsScreen> createState() => _AccountsScreenState();
}

class _AccountsScreenState extends ConsumerState<AccountsScreen> {
  bool _byPurpose = false;
  bool _hideAmounts = false;
  late bool _showWealth;

  @override
  void initState() {
    super.initState();
    _showWealth = widget.initialWealth;
  }

  @override
  void didUpdateWidget(covariant AccountsScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.initialWealth != widget.initialWealth) {
      _showWealth = widget.initialWealth;
    }
  }

  String _money(double value) {
    if (_hideAmounts) return '•••••';
    return NumberFormat.currency(
      symbol: '₹',
      decimalDigits: 0,
      locale: 'en_IN',
    ).format(value);
  }

  @override
  Widget build(BuildContext context) {
    final rawAccounts =
        ref.watch(userStateProvider).accounts.where((a) => a.isActive).toList();
    final accounts = UserStateNotifier.deduplicate(rawAccounts);
    final purposes = ref.watch(userStateProvider).purposeTypes;
    final tx = ref.read(model.transactionProvider.notifier);
    // Watch ledger so balances refresh.
    ref.watch(model.transactionProvider);
    // Net worth here = bank + cash + wallet − credit card dues.
    // Goals and investments only show on the Wealth tab.
    final total = ref.watch(model.netWorthProvider);
    final bank = accounts.where((a) => a.isBank).toList();
    final cash = accounts.where((a) => a.isCash).toList();
    final wallets = accounts.where((a) => a.isWallet).toList();
    final credit = accounts.where((a) => a.isCredit).toList();
    final byPurpose = ref.watch(model.netWorthByPurposeProvider);
    final purposeRows = [
      for (final p in purposes)
        MapEntry(p, byPurpose[p] ?? 0.0),
    ];

    final topPad = MediaQuery.paddingOf(context).top;
    // Scaffold adds the status-bar inset on top of preferredSize.
    // Keep preferredSize to the toolbar + switch only so the segment is not clipped.
    const switchBlock = 112.0;
    final headerHeight = topPad + switchBlock;

    final tone = SoftTone(context);
    final spark =
        ref
            .watch(dailySnapshotProvider)
            .history
            .reversed
            .map((row) => row.netWorth)
            .toList();
    return Scaffold(
      backgroundColor: tone.canvas,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(switchBlock),
        child: _AccountsHeader(
          height: headerHeight,
          wealthSelected: _showWealth,
          onAccounts: () {
            if (_showWealth) setState(() => _showWealth = false);
          },
          onWealth: () {
            if (!_showWealth) setState(() => _showWealth = true);
          },
          onBack: context.canPop() ? () => context.pop() : null,
        ),
      ),
      bottomNavigationBar: SxReferenceBottomBar(
        active: 'accounts',
        onAdd: () => AddTransactionSheet.show(context),
      ),
      body: IndexedStack(
        index: _showWealth ? 1 : 0,
        sizing: StackFit.expand,
        children: [
          ListView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
            children: [
              SoftForestHero(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          'TOTAL LIQUIDITY',
                          style: tone.text(
                            10,
                            FontWeight.w700,
                            Colors.white.withValues(alpha: 0.7),
                            letterSpacing: 0.6,
                          ),
                        ),
                        Tooltip(
                          message:
                              _hideAmounts ? 'Show amounts' : 'Hide amounts',
                          child: Material(
                            color: Colors.transparent,
                            child: InkWell(
                              onTap:
                                  () => setState(
                                    () => _hideAmounts = !_hideAmounts,
                                  ),
                              borderRadius: BorderRadius.circular(20),
                              child: Padding(
                                padding: const EdgeInsets.all(6),
                                child: Icon(
                                  _hideAmounts
                                      ? LucideIcons.eyeOff
                                      : LucideIcons.eye,
                                  size: 16,
                                  color: Colors.white.withValues(alpha: 0.7),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Expanded(
                          child: FittedBox(
                            fit: BoxFit.scaleDown,
                            alignment: Alignment.centerLeft,
                            child: Text(
                              _money(total),
                              style: tone.text(
                                32,
                                FontWeight.w800,
                                Colors.white,
                                letterSpacing: -0.8,
                              ),
                            ),
                          ),
                        ),
                        if (spark.length >= 2) ...[
                          const SizedBox(width: 8),
                          SoftSparkline(
                            values:
                                spark.length <= 12
                                    ? spark
                                    : spark.sublist(spark.length - 12),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Liquid liquidity as of today',
                      style: tone.text(
                        12,
                        FontWeight.w500,
                        Colors.white.withValues(alpha: 0.72),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.08),
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Row(
                        children: [
                          _HeroMode(
                            label: 'Combined',
                            selected: !_byPurpose,
                            onTap: () => setState(() => _byPurpose = false),
                          ),
                          _HeroMode(
                            label: 'By Purpose',
                            selected: _byPurpose,
                            onTap: () => setState(() => _byPurpose = true),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),
                    if (!_byPurpose)
                      Row(
                        children: [
                          Expanded(
                            child: _HeroBalanceChip(
                              label: 'Bank',
                              value: _money(_sum(bank, tx)),
                              icon: LucideIcons.landmark,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: _HeroBalanceChip(
                              label: 'Cash',
                              value: _money(_sum(cash, tx)),
                              icon: LucideIcons.banknote,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: _HeroBalanceChip(
                              label: 'Wallets',
                              value: _money(_sum(wallets, tx)),
                              icon: LucideIcons.wallet,
                            ),
                          ),
                        ],
                      )
                    else
                      _ByPurposeHeroBreakdown(
                        rows: purposeRows,
                        money: _money,
                        total: total,
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Text(
                    'My Accounts',
                    style: tone.text(
                      20,
                      FontWeight.w700,
                      tone.ink,
                      letterSpacing: -0.3,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    '(${accounts.length})',
                    style: tone.text(14, FontWeight.w600, tone.slate),
                  ),
                  const Spacer(),
                  InkWell(
                    onTap: () => _showAddFundsSheet(context),
                    borderRadius: BorderRadius.circular(8),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 4,
                        vertical: 4,
                      ),
                      child: Text(
                        '+ Add',
                        style: tone.text(14, FontWeight.w700, tone.emeraldDeep),
                      ),
                    ),
                  ),
                ],
              ),
              if (bank.isNotEmpty) ...[
                _ReferenceSectionLabel('BANKS'),
                ...bank.map((a) {
                  final amount = tx.getFullAccountBalance(a.name);
                  return _ReferenceAccountTile(
                    account: a,
                    amount: amount,
                    balance: _money(amount),
                    icon: LucideIcons.landmark,
                    onTap:
                        () => context.push(
                          '/account-detail/${Uri.encodeComponent(a.name)}',
                        ),
                  );
                }),
              ],
              if (cash.isNotEmpty) ...[
                _ReferenceSectionLabel('CASH'),
                ...cash.map((a) {
                  final amount = tx.getFullAccountBalance(a.name);
                  return _ReferenceAccountTile(
                    account: a,
                    amount: amount,
                    balance: _money(amount),
                    icon: LucideIcons.banknote,
                    onTap:
                        () => context.push(
                          '/account-detail/${Uri.encodeComponent(a.name)}',
                        ),
                  );
                }),
              ],
              if (wallets.isNotEmpty) ...[
                _ReferenceSectionLabel('WALLETS & UPI'),
                ...wallets.map((a) {
                  final amount = tx.getFullAccountBalance(a.name);
                  return _ReferenceAccountTile(
                    account: a,
                    amount: amount,
                    balance: _money(amount),
                    icon: LucideIcons.wallet,
                    onTap:
                        () => context.push(
                          '/account-detail/${Uri.encodeComponent(a.name)}',
                        ),
                  );
                }),
              ],
              if (credit.isNotEmpty) ...[
                _ReferenceSectionLabel('CREDIT CARDS'),
                ...credit.map((a) {
                  final amount = tx.getFullAccountBalance(a.name);
                  return _ReferenceAccountTile(
                    account: a,
                    amount: amount,
                    balance: _money(amount),
                    icon: LucideIcons.creditCard,
                    onTap:
                        () => context.push(
                          '/account-detail/${Uri.encodeComponent(a.name)}',
                        ),
                  );
                }),
              ],
              const SizedBox(height: 10),
              const DailySnapshotCard(),
            ],
          ),
          const WealthContent(),
        ],
      ),
    );
  }

  double _sum(Iterable<AccountModel> source, dynamic tx) =>
      source.fold(0, (sum, a) => sum + tx.getFullAccountBalance(a.name));
}

class _AccountsHeader extends StatelessWidget {
  final bool wealthSelected;
  final VoidCallback onAccounts;
  final VoidCallback onWealth;
  final VoidCallback? onBack;
  final double height;
  const _AccountsHeader({
    required this.wealthSelected,
    required this.onAccounts,
    required this.onWealth,
    required this.height,
    this.onBack,
  });

  @override
  Widget build(BuildContext context) {
    final tone = SoftTone(context);
    final top = MediaQuery.paddingOf(context).top;
    return Material(
      color: tone.canvas,
      child: SizedBox(
        height: height,
        child: Column(
          children: [
            SizedBox(height: top),
            SizedBox(
              height: 64,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    if (onBack != null) ...[
                      Material(
                        color: tone.card,
                        shape: const CircleBorder(),
                        child: InkWell(
                          customBorder: const CircleBorder(),
                          onTap: onBack,
                          child: SizedBox(
                            width: 40,
                            height: 40,
                            child: Icon(
                              Icons.arrow_back_ios_new_rounded,
                              size: 16,
                              color: tone.ink,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                    ],
                    Expanded(
                      child: Text(
                        'Accounts & Wealth',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: tone.text(
                          18,
                          FontWeight.w800,
                          tone.ink,
                          letterSpacing: -0.3,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: Container(
                height: 40,
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: tone.track,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _SegmentSide(
                      label: 'Accounts',
                      icon: LucideIcons.landmark,
                      selected: !wealthSelected,
                      onTap: onAccounts,
                    ),
                    _SegmentSide(
                      label: 'Wealth',
                      icon: LucideIcons.trendingUp,
                      selected: wealthSelected,
                      onTap: onWealth,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SegmentSide extends StatelessWidget {
  const _SegmentSide({
    required this.label,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final tone = SoftTone(context);
    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: selected ? tone.card : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
            boxShadow: selected ? tone.shadow : null,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 15, color: selected ? tone.emerald : tone.slate),
              const SizedBox(width: 6),
              Flexible(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: tone.text(
                    13,
                    selected ? FontWeight.w700 : FontWeight.w600,
                    selected ? tone.emeraldDeep : tone.slate,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ByPurposeHeroBreakdown extends StatelessWidget {
  const _ByPurposeHeroBreakdown({
    required this.rows,
    required this.money,
    required this.total,
  });

  final List<MapEntry<String, double>> rows;
  final String Function(double) money;
  final double total;

  @override
  Widget build(BuildContext context) {
    final tone = SoftTone(context);
    if (rows.isEmpty) {
      return Text(
        'No purposes yet',
        style: tone.text(
          12,
          FontWeight.w600,
          Colors.white.withValues(alpha: 0.72),
        ),
      );
    }
    // Find the max absolute value for proportional bar widths.
    final maxAbs = rows.fold<double>(
      0,
      (prev, e) => e.value.abs() > prev ? e.value.abs() : prev,
    );
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'All time',
          style: tone.text(
            11,
            FontWeight.w700,
            Colors.white.withValues(alpha: 0.72),
            letterSpacing: 0.4,
          ),
        ),
        const SizedBox(height: 8),
        for (var i = 0; i < rows.length; i++) ...[
          if (i > 0) const SizedBox(height: 8),
          _ByPurposeHeroRow(
            name: rows[i].key,
            amount: rows[i].value,
            money: money,
            barFraction: maxAbs > 0 ? rows[i].value.abs() / maxAbs : 0,
          ),
        ],
      ],
    );
  }
}

class _ByPurposeHeroRow extends StatelessWidget {
  const _ByPurposeHeroRow({
    required this.name,
    required this.amount,
    required this.money,
    required this.barFraction,
  });

  final String name;
  final double amount;
  final String Function(double) money;
  final double barFraction;

  @override
  Widget build(BuildContext context) {
    final tone = SoftTone(context);
    final positive = amount >= 0;
    final amountColor =
        positive ? const Color(0xFF34D399) : const Color(0xFFFB7185);
    final label = positive ? '+${money(amount)}' : '-${money(amount.abs())}';
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: tone.text(13, FontWeight.w800, Colors.white),
                ),
              ),
              Text(
                label,
                style: tone.text(13, FontWeight.w800, amountColor),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: SizedBox(
              height: 6,
              child: FractionallySizedBox(
                alignment: Alignment.centerLeft,
                widthFactor: barFraction.clamp(0.04, 1.0),
                child: Container(
                  decoration: BoxDecoration(
                    color: amountColor.withValues(alpha: 0.7),
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _HeroMode extends StatelessWidget {
  const _HeroMode({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final tone = SoftTone(context);
    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(999),
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: selected ? Colors.white : Colors.transparent,
            borderRadius: BorderRadius.circular(999),
          ),
          child: Center(
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: tone.text(
                12,
                FontWeight.w700,
                selected
                    ? const Color(0xFF0F172A)
                    : Colors.white.withValues(alpha: 0.72),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _HeroBalanceChip extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  const _HeroBalanceChip({
    required this.label,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return SoftHeroMiniTile(label: label, value: value, icon: icon);
  }
}

class _ReferenceSectionLabel extends StatelessWidget {
  final String label;
  const _ReferenceSectionLabel(this.label);

  @override
  Widget build(BuildContext context) {
    final tone = SoftTone(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(6, 16, 6, 8),
      child: Text(
        label,
        style: tone.text(11, FontWeight.w800, tone.slate, letterSpacing: 0.8),
      ),
    );
  }
}

class _ReferenceAccountTile extends StatelessWidget {
  final AccountModel account;
  final double amount;
  final String balance;
  final IconData icon;
  final VoidCallback onTap;
  const _ReferenceAccountTile({
    required this.account,
    required this.amount,
    required this.balance,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final tone = SoftTone(context);
    final last4 = account.last4Digits.trim();
    final active = amount != 0;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(24),
          child: Ink(
            padding: const EdgeInsets.all(14),
            decoration: tone.cardBox(),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: tone.mint,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(icon, color: tone.emeraldDeep, size: 18),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Flexible(
                            child: Text(
                              account.name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: tone.text(15, FontWeight.w700, tone.ink),
                            ),
                          ),
                          if (account.isDefault) ...[
                            const SizedBox(width: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 7,
                                vertical: 3,
                              ),
                              decoration: BoxDecoration(
                                color: tone.mint,
                                borderRadius: BorderRadius.circular(999),
                              ),
                              child: Text(
                                'Primary',
                                style: tone.text(
                                  10,
                                  FontWeight.w700,
                                  tone.emeraldDeep,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                      if (last4.isNotEmpty) ...[
                        const SizedBox(height: 3),
                        Text(
                          '•••• $last4',
                          style: tone.text(12, FontWeight.w500, tone.slate),
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      balance,
                      style: tone.text(16, FontWeight.w800, tone.ink),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      active ? 'Active' : 'Zero balance',
                      style: tone.text(
                        11,
                        FontWeight.w600,
                        active ? tone.emeraldDeep : tone.muted,
                      ),
                    ),
                  ],
                ),
                const SizedBox(width: 4),
                Icon(Icons.chevron_right, color: tone.muted, size: 18),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _AddFundsFlow extends ConsumerStatefulWidget {
  const _AddFundsFlow();

  @override
  ConsumerState<_AddFundsFlow> createState() => _AddFundsFlowState();
}

class _AddFundsFlowState extends ConsumerState<_AddFundsFlow> {
  final _formKey = GlobalKey<FormState>();
  final _amountController = TextEditingController();
  final _titleController = TextEditingController();
  AccountModel? _selectedAccount;
  String? _selectedPurpose;

  @override
  void initState() {
    super.initState();
    // Default select first account
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final userState = ref.read(userStateProvider);
      final accounts = userState.accounts;
      final purposes = userState.purposeTypes;
      setState(() {
        if (accounts.isNotEmpty) {
          _selectedAccount = accounts.first;
        }
        if (purposes.isNotEmpty) {
          _selectedPurpose = purposes.first;
        }
      });
    });
  }

  @override
  void dispose() {
    _amountController.dispose();
    _titleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final userState = ref.watch(userStateProvider);
    final accounts = userState.accounts;
    final purposes = userState.purposeTypes;
    final errorStyle = TextStyle(
      color: Colors.red.shade400,
      fontSize: 12,
      fontWeight: FontWeight.w500,
    );

    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.all(24),
      child: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Add Funds',
              style: Theme.of(
                context,
              ).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 24),

            // Amount
            TextFormField(
              controller: _amountController,
              keyboardType: TextInputType.number,
              style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 24),
              validator:
                  (v) =>
                      (double.tryParse(v ?? '') ?? 0) <= 0
                          ? 'Enter amount'
                          : null,
              decoration: InputDecoration(
                labelText: 'Amount',
                prefixText: '₹ ',
                hintText: '0.00',
                errorStyle: errorStyle,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Account selection (Horizontal Scroll)
            _SectionLabel(label: 'SOURCE ACCOUNT', isDark: isDark),
            const SizedBox(height: 12),
            SizedBox(
              height: 54, // Reduced height
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                child: Row(
                  children:
                      accounts.map((acc) {
                        final isSelected = _selectedAccount?.name == acc.name;
                        return GestureDetector(
                          onTap: () => setState(() => _selectedAccount = acc),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 300),
                            curve: Curves.easeOutCubic,
                            margin: const EdgeInsets.only(right: 10),
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color:
                                  isSelected
                                      ? SoftColors.control
                                      : (isDark
                                          ? Colors.white.withValues(alpha: 0.05)
                                          : Colors.black.withValues(
                                            alpha: 0.03,
                                          )),
                              borderRadius: BorderRadius.circular(
                                20,
                              ), // Pill shaped
                              border: Border.all(
                                color:
                                    isSelected
                                        ? Colors.transparent
                                        : (isDark
                                            ? Colors.white10
                                            : Colors.black12),
                                width: 1,
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  acc.type == 'Cash'
                                      ? LucideIcons.banknote
                                      : LucideIcons.building,
                                  size: 14,
                                  color:
                                      isSelected
                                          ? const Color(0xFF161613)
                                          : (isDark
                                              ? Colors.white54
                                              : Colors.black54),
                                ),
                                const SizedBox(width: 8),
                                Text(
                                  acc.name,
                                  style: TextStyle(
                                    fontSize: 13,
                                    fontWeight:
                                        isSelected
                                            ? FontWeight.w500
                                            : FontWeight.w500,
                                    color:
                                        isSelected
                                            ? const Color(0xFF161613)
                                            : (isDark
                                                ? Colors.white70
                                                : Colors.black87),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      }).toList(),
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Purpose Type
            if (purposes.isNotEmpty) ...[
              _SectionLabel(label: 'PURPOSE TYPE', isDark: isDark),
              const SizedBox(height: 12),
              SizedBox(
                height: 54,
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  physics: const BouncingScrollPhysics(),
                  child: Row(
                    children:
                        purposes.map((p) {
                          final isSelected = _selectedPurpose == p;
                          return GestureDetector(
                            onTap: () => setState(() => _selectedPurpose = p),
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 300),
                              curve: Curves.easeOutCubic,
                              margin: const EdgeInsets.only(right: 10),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 12,
                              ),
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                color:
                                    isSelected
                                        ? SoftColors.control
                                        : (isDark
                                            ? Colors.white.withValues(
                                              alpha: 0.05,
                                            )
                                            : Colors.black.withValues(
                                              alpha: 0.03,
                                            )),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                  color:
                                      isSelected
                                          ? Colors.transparent
                                          : (isDark
                                              ? Colors.white10
                                              : Colors.black12),
                                  width: 1,
                                ),
                              ),
                              child: Text(
                                p,
                                style: TextStyle(
                                  fontSize: 13,
                                  fontWeight:
                                      isSelected
                                          ? FontWeight.w500
                                          : FontWeight.w500,
                                  color:
                                      isSelected
                                          ? const Color(0xFF161613)
                                          : (isDark
                                              ? Colors.white70
                                              : Colors.black87),
                                ),
                              ),
                            ),
                          );
                        }).toList(),
                  ),
                ),
              ),
              const SizedBox(height: 24),
            ],

            // Title
            TextFormField(
              controller: _titleController,
              decoration: InputDecoration(
                labelText: 'Title / Reason',
                hintText: 'e.g. Salary, Part-time income...',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
            ),
            const SizedBox(height: 32),

            // Add Fund Button
            SizedBox(
              width: double.infinity,
              height: 60,
              child: ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate() &&
                      _selectedAccount != null) {
                    final amount = double.parse(_amountController.text);
                    final tx = model.Transaction(
                      merchant:
                          _titleController.text.isEmpty
                              ? 'Added Funds'
                              : _titleController.text,
                      category: 'Income',
                      account: _selectedAccount!.name,
                      paymentType:
                          _selectedAccount!.type == 'Cash' ? 'Cash' : 'Online',
                      time: 'Just now',
                      amount: amount,
                      isExpense: false,
                      date: DateTime.now(),
                      note: '',
                      purpose: _selectedPurpose,
                    );

                    ref
                        .read(model.transactionProvider.notifier)
                        .addTransaction(tx);
                    Navigator.pop(context);
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: SoftColors.control,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  elevation: 8,
                  shadowColor: AppColors.primary.withValues(alpha: 0.3),
                ),
                child: const Text(
                  'Add Funds',
                  style: TextStyle(fontWeight: FontWeight.w500, fontSize: 16),
                ),
              ),
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String label;
  final bool isDark;
  const _SectionLabel({required this.label, required this.isDark});

  @override
  Widget build(BuildContext context) {
    return Text(
      label,
      style: TextStyle(
        fontSize: 11,
        fontWeight: FontWeight.w500,
        letterSpacing: 1.2,
        color: context.tokens.textSecondary,
      ),
    );
  }
}
