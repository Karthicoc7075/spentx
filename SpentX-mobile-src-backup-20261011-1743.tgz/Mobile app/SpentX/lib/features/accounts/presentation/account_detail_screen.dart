import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../core/design/sx_components.dart';
import '../../../core/design/sx_feedback.dart';
import '../../../core/providers/outing_provider.dart';
import '../../../core/providers/transaction_provider.dart' as model;
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../core/utils/transaction_display_utils.dart';
import '../../../core/widgets/reference_ui.dart';
import '../../../core/widgets/transaction_tile.dart';
import '../../wealth/presentation/widgets/soft_wealth_widgets.dart';
import 'widgets/soft_account_widgets.dart';

class AccountDetailScreen extends ConsumerStatefulWidget {
  final String accountName;
  const AccountDetailScreen({super.key, required this.accountName});

  @override
  ConsumerState<AccountDetailScreen> createState() =>
      _AccountDetailScreenState();
}

class _AccountDetailScreenState extends ConsumerState<AccountDetailScreen> {
  int _timeRange = 1; // 0=Day, 1=Week, 2=Month, 3=Custom
  int _filterType = 0; // 0=All, 1=Credit, 2=Debit
  DateTimeRange? _customRange;

  bool _resolveIsExpense(dynamic item) {
    if (item is! model.Transaction) return true;
    if (_isIncomingTransferForAccount(item)) return false;
    return item.isExpense;
  }

  DateTime _startOfWeek(DateTime now) {
    final weekday = now.weekday;
    return DateTime(
      now.year,
      now.month,
      now.day,
    ).subtract(Duration(days: weekday - 1));
  }

  bool _isIncomingTransferForAccount(model.Transaction tx) {
    final isTransfer =
        tx.isTransfer || tx.category.trim().toLowerCase() == 'transfer';
    if (!isTransfer || tx.transferType?.trim().isEmpty != false) {
      return false;
    }
    final target = widget.accountName.trim().toLowerCase();
    final destination = (tx.transferTo ?? '').trim().toLowerCase();
    final source = tx.account.trim().toLowerCase();
    return destination.isNotEmpty && destination == target && source != target;
  }

  bool _belongsToAccount(model.Transaction tx) {
    final target = widget.accountName.trim().toLowerCase();
    if (tx.account.trim().toLowerCase() == target) return true;
    return _isIncomingTransferForAccount(tx);
  }

  List<dynamic> _getFilteredTransactions() {
    final allTxs = ref.watch(model.transactionProvider);
    final outings = ref.watch(outingProvider);
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final target = widget.accountName.trim().toLowerCase();

    final pool = <dynamic>[];
    for (final t in allTxs) {
      if (_belongsToAccount(t)) pool.add(t);
    }
    for (final o in outings) {
      for (final e in o.expenses) {
        if (e.transactionId == null || e.transactionId!.isEmpty) {
          final expAcc = (e.accountId ?? '').trim().toLowerCase();
          final matchAccount =
              expAcc == target ||
              (target == 'cash' && e.paymentMode.toLowerCase() == 'cash');
          if (matchAccount) pool.add(e);
        }
      }
    }

    final filtered =
        pool
            .where((item) {
              final date =
                  item is model.Transaction
                      ? item.date
                      : (item as OutingExpense).date;
              if (_timeRange == 0) {
                return date.year == now.year &&
                    date.month == now.month &&
                    date.day == now.day;
              }
              if (_timeRange == 1) {
                final start = _startOfWeek(now);
                return !date.isBefore(start);
              }
              if (_timeRange == 2) {
                return date.year == now.year && date.month == now.month;
              }
              if (_timeRange == 3 && _customRange != null) {
                final start = DateTime(
                  _customRange!.start.year,
                  _customRange!.start.month,
                  _customRange!.start.day,
                );
                final endExclusive = DateTime(
                  _customRange!.end.year,
                  _customRange!.end.month,
                  _customRange!.end.day,
                ).add(const Duration(days: 1));
                return !date.isBefore(start) && date.isBefore(endExclusive);
              }
              return !date.isBefore(today.subtract(const Duration(days: 365)));
            })
            .where((item) {
              final isExp = _resolveIsExpense(item);
              if (_filterType == 1) return !isExp;
              if (_filterType == 2) return isExp;
              return true;
            })
            .toList();

    filtered.sort((a, b) {
      final da = a is model.Transaction ? a.date : (a as OutingExpense).date;
      final db = b is model.Transaction ? b.date : (b as OutingExpense).date;
      return db.compareTo(da);
    });
    return filtered;
  }

  Future<void> _showCustomDatePicker() async {
    final now = DateTime.now();
    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(now.year - 3),
      lastDate: now,
      initialDateRange:
          _customRange ??
          DateTimeRange(
            start: now.subtract(const Duration(days: 30)),
            end: now,
          ),
    );
    if (picked != null) setState(() => _customRange = picked);
  }

  String _monthLabel() {
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    return months[DateTime.now().month - 1];
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = isDark ? SoftPalette.darkBg : SoftPalette.bg;
    final ink = isDark ? SoftPalette.darkInk : SoftPalette.ink;
    final muted = isDark ? SoftPalette.darkMuted : SoftPalette.muted;
    final filtered = _getFilteredTransactions();
    final balance = ref
        .read(model.transactionProvider.notifier)
        .getFullAccountBalance(widget.accountName);

    var credit = 0.0;
    var debit = 0.0;
    for (final item in filtered) {
      final amount =
          item is model.Transaction
              ? item.amount
              : (item as OutingExpense).amount;
      if (_resolveIsExpense(item)) {
        debit += amount;
      } else {
        credit += amount;
      }
    }

    final month = _monthLabel();

    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: Column(
          children: [
            SoftPageHeader(
              title: widget.accountName,
              onBack: () {
                if (context.canPop()) {
                  context.pop();
                } else {
                  context.go('/accounts');
                }
              },
              trailing: SoftCircleIconButton(
                icon: LucideIcons.bell,
                tooltip: 'Notifications',
                onPressed: () => context.push('/notifications'),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
              child: SxSegmentedControl(
                segments: const ['Day', 'Week', 'Month', 'Custom'],
                selectedIndex: _timeRange,
                onChanged: (i) {
                  if (i == 3) _showCustomDatePicker();
                  setState(() => _timeRange = i);
                },
              ),
            ),
            Expanded(
              child: ListView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 32),
                children: [
                  SoftAccountCard(
                    padding: const EdgeInsets.fromLTRB(18, 18, 18, 18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SoftAccountPill(
                          label: 'Account · ${widget.accountName}',
                          icon: LucideIcons.landmark,
                        ),
                        const SizedBox(height: 14),
                        SxMoney(amount: balance, size: 32, color: ink),
                        const SizedBox(height: 4),
                        Text(
                          'Available balance',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                            color: muted,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: SoftAccountCard(
                          padding: const EdgeInsets.fromLTRB(14, 14, 14, 14),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'In ($month)',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: muted,
                                ),
                              ),
                              const SizedBox(height: 6),
                              SxMoney(
                                amount: credit,
                                size: 18,
                                color: SoftPalette.emerald,
                                signed: true,
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: SoftAccountCard(
                          padding: const EdgeInsets.fromLTRB(14, 14, 14, 14),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Out ($month)',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: muted,
                                ),
                              ),
                              const SizedBox(height: 6),
                              SxMoney(amount: debit, size: 18, color: ink),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  SxSegmentedControl(
                    segments: const ['All', 'Credit', 'Debit'],
                    selectedIndex: _filterType,
                    onChanged: (i) => setState(() => _filterType = i),
                  ),
                  const SizedBox(height: 14),
                  if (filtered.isEmpty)
                    SoftAccountCard(
                      child: const SxEmptyState(
                        icon: LucideIcons.receipt,
                        message: 'No transactions for this range',
                      ),
                    )
                  else
                    for (var i = 0; i < filtered.length; i++) ...[
                      if (i > 0) const SizedBox(height: 10),
                      Builder(
                        builder: (context) {
                          final tone = SoftTone(context);
                          final item = filtered[i];
                          final Widget tile;
                          if (item is model.Transaction) {
                            final tx = item;
                            final txDisplayTitle =
                                TransactionDisplayUtils.displayTitle(tx);
                            tile = TransactionTile(
                              merchant: txDisplayTitle.primary,
                              category: tx.category,
                              account: tx.account,
                              paymentType: tx.paymentType,
                              date: DateFormat(
                                'MMM dd, hh:mm a',
                              ).format(tx.date),
                              amount: tx.amount,
                              isExpense: _resolveIsExpense(tx),
                              purpose: tx.purpose,
                              splitBadge:
                                  tx.isGroup
                                      ? (tx.groupCount == 1
                                          ? 'Friend Split'
                                          : 'Split Expense')
                                      : null,
                              splitBadgeTint:
                                  tx.isGroup
                                      ? (tx.groupCount == 1
                                          ? AppColors.tintGreen
                                          : AppColors.tintPurple)
                                      : null,
                              itemsLabel: txDisplayTitle.itemsLabel,
                              isTransfer: tx.isTransfer,
                              transferTo: tx.transferTo ?? '',
                              softListRow: true,
                              onTap:
                                  () => context.push('/transaction/${tx.id}'),
                            );
                          } else {
                            final expense = item as OutingExpense;
                            final account =
                                expense.accountId?.trim().isNotEmpty == true
                                    ? expense.accountId!.trim()
                                    : widget.accountName;
                            tile = TransactionTile(
                              merchant: expense.title,
                              category: 'Trip Expense',
                              account: account,
                              paymentType: expense.paymentMode,
                              date: DateFormat(
                                'MMM dd, hh:mm a',
                              ).format(expense.date),
                              amount: expense.amount,
                              isExpense: true,
                              softListRow: true,
                              onTap: null,
                            );
                          }
                          return DecoratedBox(
                            decoration: tone.cardBox(radius: 24),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(24),
                              child: tile,
                            ),
                          );
                        },
                      ),
                    ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
