import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../models/account_model.dart';
import '../../../models/pending_account.dart';
import '../../../core/services/account_discovery_service.dart';
import '../../../core/services/auto_detection_native_sync.dart';
import '../../../core/providers/user_state_provider.dart';

/// Accounts inferred from SMS that the user has not decided on yet.
///
/// Thin Riverpod skin over [AccountDiscoveryService]: the service is the
/// source of truth (it has to be — the WorkManager isolate writes to it with
/// no container alive), and this exists so the UI rebuilds when it changes.
class PendingAccountNotifier extends StateNotifier<List<PendingAccount>> {
  PendingAccountNotifier(this.ref) : super(const []) {
    refresh();
  }

  final Ref ref;

  /// Re-read from Hive. Call after a background pass may have written.
  void refresh() {
    state = AccountDiscoveryService.suggestions();
  }

  /// Everything ever discovered, including ignored — for "show ignored".
  List<PendingAccount> get all => AccountDiscoveryService.getAll();

  List<PendingAccount> get ignored => all
      .where((p) => p.status == PendingAccountStatus.ignored)
      .toList(growable: false);

  /// User said no. The row stays as the ignore entry, so it never asks again.
  ///
  /// The native mirror is refreshed too: without it the notification listener
  /// would keep forwarding this account's SMS for discovery while the app is
  /// killed, and the user would be asked again by a path that never saw the
  /// refusal.
  void ignore(String id) {
    AccountDiscoveryService.ignore(id);
    AutoDetectionNativeSync.syncAllowedBanksToNative();
    refresh();
  }

  void restore(String id) {
    AccountDiscoveryService.restore(id);
    AutoDetectionNativeSync.syncAllowedBanksToNative();
    refresh();
  }

  /// Turn a suggestion into a real account.
  ///
  /// [openingBalance] is whatever the user typed — never the balance parsed
  /// from their SMS. Returns an error message on failure (duplicate name,
  /// account cap), or null on success.
  ///
  /// On success the account's last-4 joins the native allowlist via
  /// [UserStateNotifier.addAccount], so the next SMS for it is detected
  /// normally instead of re-proposed.
  String? convert({
    required PendingAccount pending,
    required String name,
    required String type,
    double openingBalance = 0,
    String? openingBalanceDate,
  }) {
    final account = AccountModel(
      name: name.trim().isEmpty ? pending.suggestedName : name.trim(),
      type: type,
      last4Digits: pending.last4,
      openingBalance: openingBalance,
      openingBalanceDate: openingBalanceDate,
    );

    final error = ref.read(userStateProvider.notifier).addAccount(account);
    if (error != null) return error;

    // addAccount already mirrored the new last-4; this second call publishes
    // the converted key so native stops treating it as undiscovered.
    AccountDiscoveryService.markConverted(pending.id);
    AutoDetectionNativeSync.syncAllowedBanksToNative();
    refresh();
    return null;
  }

  /// Clear suggestions the user satisfied by adding the account by hand.
  void reconcile() {
    final accounts = ref.read(userStateProvider).accounts;
    AccountDiscoveryService.reconcileAgainstAccounts(
      accounts
          .map((a) => a.last4Digits.trim())
          .where((l) => l.length >= 3)
          .toList(),
    );
    refresh();
  }
}

final pendingAccountProvider =
    StateNotifierProvider<PendingAccountNotifier, List<PendingAccount>>(
  (ref) => PendingAccountNotifier(ref),
);

/// Number of accounts awaiting a decision — for badges and the Home nudge.
final pendingAccountCountProvider = Provider<int>(
  (ref) => ref.watch(pendingAccountProvider).length,
);
