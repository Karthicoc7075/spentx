import 'package:hive_flutter/hive_flutter.dart';

import '../../../core/services/account_discovery_service.dart';
import '../../../core/services/bank_allowlist_service.dart';
import '../../sms/rules/engine/sms_rule_engine.dart';
import '../../sms/sms_service.dart';
import '../../sms/v4/bank_sms_v4_parser.dart';

/// One-off scan of the SMS inbox to find accounts the user has, but has not
/// added — Moment 2 in docs/ACCOUNT_DISCOVERY.md.
///
/// Reuses the live parser rather than a second set of patterns: a message only
/// becomes a candidate if [SmsRuleEngine.parse] agrees it is a real bank
/// transaction, which is what keeps OTPs, promos and delivery codes out of the
/// results without a single extra filter here.
///
/// **Writes no accounts and no transactions.** It only fills the suggestion
/// list the user then ticks through.
class AccountDiscoveryScanService {
  AccountDiscoveryScanService._();

  /// Settings key marking that the inbox has been scanned once, so the
  /// discovery screen is offered on first permission grant and not again.
  static const scannedKey = 'account_discovery_scanned_at';

  /// How far back to look. Long enough to catch a card used monthly, short
  /// enough that a long-closed account does not resurface.
  static const lookback = Duration(days: 90);

  static bool get hasScanned {
    if (!Hive.isBoxOpen('settings')) return false;
    return Hive.box('settings').get(scannedKey) != null;
  }

  static Future<void> markScanned() async {
    if (!Hive.isBoxOpen('settings')) return;
    await Hive.box('settings').put(scannedKey, DateTime.now().toIso8601String());
  }

  /// Scan the inbox and record every proposable account.
  ///
  /// Returns how many messages were examined. Read the results from
  /// [AccountDiscoveryService.suggestions].
  static Future<AccountScanSummary> scanInbox({
    Duration? lookbackOverride,
  }) async {
    await AccountDiscoveryService.ensureOpen();
    await BankSmsV4Parser.ensureLoaded();

    final rows = await SmsService.readInboxRaw();
    if (rows.isEmpty) {
      await markScanned();
      return const AccountScanSummary(scanned: 0, matched: 0, discovered: 0);
    }

    final cutoff = DateTime.now().subtract(lookbackOverride ?? lookback);
    var scanned = 0;
    var matched = 0;
    final found = <String>{};

    for (final row in rows) {
      if (row.date.isBefore(cutoff)) continue;
      scanned++;

      // Only messages for an account the user does not have.
      if (BankAllowlistService.evaluate(row.body) != AllowResult.discovery) {
        continue;
      }

      // ...and only ones that are genuinely transactions.
      final parsed = SmsRuleEngine.parse(row.body, smsReceivedTime: row.date);
      if (parsed == null) continue;
      matched++;

      final pending = AccountDiscoveryService.record(
        rawMessage: row.body,
        seenAt: row.date,
      );
      if (pending != null) found.add(pending.id);
    }

    await markScanned();
    return AccountScanSummary(
      scanned: scanned,
      matched: matched,
      discovered: found.length,
    );
  }
}

class AccountScanSummary {
  /// Messages inside the lookback window.
  final int scanned;

  /// Messages that parsed as a transaction for an unknown account.
  final int matched;

  /// Distinct accounts proposed.
  final int discovered;

  const AccountScanSummary({
    required this.scanned,
    required this.matched,
    required this.discovered,
  });
}
