import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';

part 'account_model.g.dart';

@HiveType(typeId: 0)
class Account extends HiveObject {
  @HiveField(0)
  final String id;

  @HiveField(1)
  String name;

  @HiveField(2)
  String type; // 'own' or 'home'

  @HiveField(3)
  double cashBalance;

  @HiveField(4)
  double bankBalance;

  @HiveField(5)
  String colorHex;

  @HiveField(6)
  String iconName;

  Account({
    String? id,
    required this.name,
    required this.type,
    this.cashBalance = 0.0,
    this.bankBalance = 0.0,
    this.colorHex = '#25252A',
    this.iconName = 'user',
  }) : id = id ?? const Uuid().v4();

  double get totalBalance => cashBalance + bankBalance;
}
