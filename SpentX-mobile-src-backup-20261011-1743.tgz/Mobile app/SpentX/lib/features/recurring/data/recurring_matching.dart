/// Pure matching rules for recurring bills (unit-tested).
abstract final class RecurringMatching {
  /// Lower-case, letters/digits only: "Netflix.com " -> "netflixcom".
  static String normalizeName(String raw) =>
      raw.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

  /// Same bill when normalized names are equal or one contains the other
  /// (both at least 3 chars, so "tv" doesn't swallow everything).
  static bool sameBill(String a, String b) {
    final x = normalizeName(a);
    final y = normalizeName(b);
    if (x.isEmpty || y.isEmpty) return false;
    if (x == y) return true;
    if (x.length < 3 || y.length < 3) return false;
    return x.contains(y) || y.contains(x);
  }

  /// Amount within ±10% or ±₹10 (whichever is larger). A bill with no amount
  /// set (<= 0) can't be compared, so any amount matches.
  static bool amountMatches(double billAmount, double txAmount) {
    if (!billAmount.isFinite || billAmount <= 0) return true;
    if (!txAmount.isFinite) return false;
    final tolerance = (billAmount * 0.10) > 10 ? billAmount * 0.10 : 10.0;
    return (txAmount - billAmount).abs() <= tolerance;
  }

  /// Whether a ledger transaction pays a manual bill this period.
  static bool paysBill({
    required String billName,
    required double billAmount,
    required String merchant,
    required double amount,
    required bool isExpense,
    required bool isTransfer,
    required bool isPendingVerification,
    required DateTime date,
    required DateTime now,
  }) {
    if (!isExpense || isTransfer || isPendingVerification) return false;
    if (date.year != now.year || date.month != now.month) return false;
    final bill = normalizeName(billName);
    if (bill.isEmpty) return false;
    if (!normalizeName(merchant).contains(bill)) return false;
    return amountMatches(billAmount, amount);
  }

  /// Drops auto-detected names that duplicate a manual bill.
  static List<T> dedupeDetected<T>(
    List<T> detected,
    Iterable<String> manualNames,
    String Function(T) nameOf,
  ) {
    final manual = manualNames.toList();
    return [
      for (final d in detected)
        if (!manual.any((m) => sameBill(m, nameOf(d)))) d,
    ];
  }
}
