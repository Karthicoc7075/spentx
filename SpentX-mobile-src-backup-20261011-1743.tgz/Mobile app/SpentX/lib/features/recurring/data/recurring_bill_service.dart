import 'dart:async';
import 'dart:convert';
import 'dart:developer' as dev;
import 'package:hive_flutter/hive_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../../core/services/auth_service.dart';
import '../../../core/sync/durable_collection.dart';

class RecurringBillService {
  static final Map<String, Future<void>> _inFlight = {};
  static int _generation = 0;
  static void resetSession() {
    _generation++;
    _inFlight.clear();
  }

  static DurableCollection _store(String uid) => DurableCollection(
    Hive.box('settings'),
    'recurring_bills_v2:$uid',
    area: 'Recurring bills',
  );
  static List<Map<String, dynamic>> _legacy(String uid) {
    final box = Hive.box('settings');
    if (box.get(AuthService.lastUserIdKey) != uid) return [];
    final raw = box.get('recurring_bills');
    return raw is List
        ? raw.whereType<Map>().map((r) => Map<String, dynamic>.from(r)).toList()
        : [];
  }

  static bool get hasPendingChanges {
    final uid = AuthService.currentUserId;
    if (uid == null || !Hive.isBoxOpen('settings')) return false;
    return _store(uid).hasPending ||
        (!_store(uid).initialized && _legacy(uid).isNotEmpty);
  }

  static List<Map<String, dynamic>> cachedBills() {
    final uid = AuthService.currentUserId;
    if (uid == null || AuthService.syncHeldForAccountSwitch) return [];
    final store = _store(uid);
    return store.initialized ? store.rows : _legacy(uid);
  }

  static Future<void> saveBills(List<Map<String, dynamic>> bills) async {
    final uid = AuthService.currentUserId;
    final generation = _generation;
    if (uid == null || AuthService.syncHeldForAccountSwitch) {
      throw StateError('Sign in before changing recurring bills');
    }
    final store = _store(uid);
    final imported = store.importRows(_legacy(uid), upload: true);
    final ids = bills.map((r) => r['id'].toString()).toSet();
    final existing = {for (final row in store.rows) row['id'].toString(): row};
    // Issue all local writes before yielding so logout sees every pending bill.
    await Future.wait([
      imported,
      for (final row in store.rows)
        if (!ids.contains(row['id'].toString()))
          store.stage(row['id'].toString(), null),
      for (final row in bills)
        if (jsonEncode(existing[row['id'].toString()]) != jsonEncode(row))
          store.stage(row['id'].toString(), row),
    ]);
    if (AuthService.currentUserId == uid && generation == _generation) {
      unawaited(sync());
    }
  }

  static Future<void> sync() async {
    try {
      await flushPending();
    } catch (e) {
      dev.log('Recurring bills retained for retry: $e');
    }
  }

  static Future<void> flushPending() async {
    final uid = AuthService.currentUserId;
    if (uid == null || AuthService.syncHeldForAccountSwitch) return;
    final future = _inFlight.putIfAbsent(uid, () => _synchronize(uid));
    try {
      await future;
    } finally {
      if (identical(_inFlight[uid], future)) _inFlight.remove(uid);
    }
  }

  static Future<void> _synchronize(String uid) async {
    final generation = _generation;
    bool current() =>
        generation == _generation &&
        AuthService.currentUserId == uid &&
        !AuthService.syncHeldForAccountSwitch;
    final store = _store(uid);
    await store.importRows(_legacy(uid), upload: true);
    if (!current()) return;
    final db = Supabase.instance.client;
    await store.synchronize(
      isCurrent: current,
      write: (id, row) async {
        if (!current()) {
          throw StateError('Account changed during recurring sync');
        }
        if (row == null) {
          await db
              .from('recurring_bills')
              .delete()
              .eq('user_id', uid)
              .eq('id', id);
        } else {
          await db.from('recurring_bills').upsert({
            'user_id': uid,
            'id': id,
            'data': row,
          });
        }
      },
      read:
          () async =>
              (await db
                      .from('recurring_bills')
                      .select('id, data')
                      .eq('user_id', uid))
                  .map(
                    (r) => {
                      ...Map<String, dynamic>.from(r['data'] as Map),
                      'id': r['id'],
                    },
                  )
                  .toList(),
    );
  }
}
