import 'package:flutter/material.dart';

import '../../../../core/widgets/reference_ui.dart';

class SoftRecurringCard extends StatelessWidget {
  const SoftRecurringCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.onTap,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final card = SxSoftCard(padding: padding, child: child);
    if (onTap == null) return card;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: const BorderRadius.all(Radius.circular(18)),
        child: card,
      ),
    );
  }
}
