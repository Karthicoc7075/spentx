import 'package:flutter/material.dart';
import '../../../../core/theme/soft_palette.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/widgets/soft_page_kit.dart';

/// Choice returned by [MarkPaidSheet].
class MarkPaidChoice {
  const MarkPaidChoice({required this.account, required this.purpose});
  final String account;
  final String purpose;
}

/// Small picker: which account paid the bill and under which purpose.
/// Active accounts only (falls back to Cash when there are none); the
/// default purpose is preselected.
class MarkPaidSheet extends StatefulWidget {
  const MarkPaidSheet({
    super.key,
    required this.billName,
    required this.amountLabel,
    required this.accounts,
    required this.purposes,
    this.initialAccount,
    this.initialPurpose,
  });

  final String billName;
  final String amountLabel;
  final List<String> accounts;
  final List<String> purposes;
  final String? initialAccount;
  final String? initialPurpose;

  @override
  State<MarkPaidSheet> createState() => _MarkPaidSheetState();
}

class _MarkPaidSheetState extends State<MarkPaidSheet> {
  late List<String> _accounts;
  late List<String> _purposes;
  late String _account;
  late String _purpose;

  @override
  void initState() {
    super.initState();
    _accounts = widget.accounts.isEmpty ? const ['Cash'] : widget.accounts;
    _purposes = widget.purposes.isEmpty ? const ['Personal'] : widget.purposes;
    _account =
        _accounts.contains(widget.initialAccount)
            ? widget.initialAccount!
            : _accounts.first;
    _purpose =
        _purposes.contains(widget.initialPurpose)
            ? widget.initialPurpose!
            : _purposes.first;
  }

  Widget _chips(List<String> values, String selected, ValueChanged<String> on) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final v in values)
          ChoiceChip(
            label: Text(v),
            selected: v == selected,
            showCheckmark: false,
            onSelected: (_) => on(v),
            backgroundColor: SoftKit.field(context),
            selectedColor: SoftColors.control,
            side: BorderSide(
              color:
                  v == selected
                      ? SoftKit.primaryGreen
                      : SoftKit.fieldBorder(context),
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            labelStyle: SoftKit.text(
              context,
              13,
              FontWeight.w600,
              v == selected ? Colors.white : SoftKit.ink(context),
            ),
          ),
      ],
    );
  }

  Widget _label(String t) => Padding(
    padding: const EdgeInsets.only(bottom: 8, top: 16),
    child: Text(
      t,
      style: SoftKit.text(
        context,
        11,
        FontWeight.w700,
        SoftKit.slate(context),
        letterSpacing: 1.1,
      ),
    ),
  );

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'Mark ${widget.billName} paid',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: SoftKit.text(
                    context,
                    20,
                    FontWeight.w800,
                    SoftKit.ink(context),
                  ),
                ),
              ),
              SoftKitCircleButton(
                icon: Icons.close_rounded,
                tooltip: 'Close',
                onPressed: () => Navigator.maybePop(context),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            'Logs a ${widget.amountLabel} expense today.',
            style: SoftKit.text(
              context,
              12,
              FontWeight.w500,
              SoftKit.slate(context),
            ),
          ),
          _label('PAID FROM'),
          _chips(_accounts, _account, (v) => setState(() => _account = v)),
          _label('PURPOSE'),
          _chips(_purposes, _purpose, (v) => setState(() => _purpose = v)),
          const SizedBox(height: 24),
          SoftKitButton(
            label: 'Log payment',
            icon: LucideIcons.check,
            height: 52,
            onPressed:
                () => Navigator.pop(
                  context,
                  MarkPaidChoice(account: _account, purpose: _purpose),
                ),
          ),
        ],
      ),
    );
  }
}
