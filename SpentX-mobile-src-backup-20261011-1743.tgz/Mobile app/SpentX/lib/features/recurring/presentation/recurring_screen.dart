import 'dart:async';
import '../data/recurring_bill_service.dart';
import '../data/recurring_matching.dart';
import 'widgets/mark_paid_sheet.dart';
import '../../investments/presentation/widgets/investment_form_sheet.dart'
    show defaultPurposeOf;
import 'package:flutter/material.dart';
import '../../../core/theme/spentx_tokens.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:intl/intl.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../core/widgets/reference_ui.dart';
import 'widgets/soft_recurring_widgets.dart';
import '../../../core/widgets/category_icon.dart';
import '../../../core/widgets/category_selector.dart';
import '../../../core/widgets/premium_bottom_sheet.dart';
import '../../../core/providers/transaction_provider.dart' as model;
import '../../../core/providers/category_provider.dart';
import '../../../core/providers/user_state_provider.dart';

/// Recurring bills — real data only.
///
/// Two sources:
/// 1. Detected patterns: merchants with 2+ expenses at a roughly monthly
///    cadence in the real transaction ledger.
/// 2. Manual bills the user defines (persisted in Hive `settings` under
///    `recurring_bills`).
class RecurringScreen extends ConsumerStatefulWidget {
  const RecurringScreen({super.key});

  @override
  ConsumerState<RecurringScreen> createState() => _RecurringScreenState();
}

class _RecurringEntry {
  final String name;
  final String category;
  final double amount;
  final DateTime nextDue;
  final bool paidThisPeriod;
  final bool isManual;
  final String? manualId;
  final int dayOfMonth;

  _RecurringEntry({
    required this.name,
    required this.category,
    required this.amount,
    required this.nextDue,
    required this.paidThisPeriod,
    this.isManual = false,
    this.manualId,
    this.dayOfMonth = 1,
  });
}

class _RecurringScreenState extends ConsumerState<RecurringScreen> {
  StreamSubscription<BoxEvent>? _billChanges;

  @override
  void initState() {
    super.initState();
    _billChanges = Hive.box('settings').watch().listen((event) {
      if (event.key.toString().startsWith('recurring_bills_v2:') && mounted) {
        setState(() {});
      }
    });
    unawaited(RecurringBillService.sync());
  }

  @override
  void dispose() {
    _billChanges?.cancel();
    super.dispose();
  }

  List<Map<String, dynamic>> _manualBills() =>
      RecurringBillService.cachedBills();

  Future<void> _saveManualBills(List<Map<String, dynamic>> bills) =>
      RecurringBillService.saveBills(bills);

  /// Detect roughly-monthly repeated merchants from the real ledger.
  List<_RecurringEntry> _derivedEntries(List<model.Transaction> txs) {
    final now = DateTime.now();
    final byMerchant = <String, List<model.Transaction>>{};
    for (final t in txs) {
      if (!t.isExpense || t.isTransfer || t.isPendingVerification) continue;
      final key = t.merchant.trim().toLowerCase();
      if (key.isEmpty || key.startsWith('tr ')) continue;
      byMerchant.putIfAbsent(key, () => []).add(t);
    }

    final entries = <_RecurringEntry>[];
    for (final list in byMerchant.values) {
      if (list.length < 2) continue;
      list.sort((a, b) => a.date.compareTo(b.date));

      final intervals = <int>[];
      for (var i = 1; i < list.length; i++) {
        intervals.add(list[i].date.difference(list[i - 1].date).inDays);
      }
      intervals.sort();
      final median = intervals[intervals.length ~/ 2];
      // Roughly monthly cadence only (20–40 day median gap).
      if (median < 20 || median > 40) continue;

      final last = list.last;
      final nextDue = last.date.add(Duration(days: median));
      final paidThisMonth =
          last.date.year == now.year && last.date.month == now.month;

      entries.add(
        _RecurringEntry(
          name: last.merchant,
          category: last.category,
          amount: last.amount,
          nextDue: nextDue,
          paidThisPeriod: paidThisMonth && nextDue.isAfter(now),
          dayOfMonth: last.date.day.clamp(1, 28),
        ),
      );
    }
    return entries;
  }

  List<_RecurringEntry> _manualEntries(List<model.Transaction> txs) {
    final now = DateTime.now();
    final entries = <_RecurringEntry>[];
    for (final bill in _manualBills()) {
      final day = (bill['dayOfMonth'] as num? ?? 1).toInt().clamp(1, 28);
      var due = DateTime(now.year, now.month, day);
      final name = bill['name']?.toString() ?? 'Bill';
      // Paid this month if a matching expense exists this month.
      final billAmount = (bill['amount'] as num? ?? 0).toDouble();
      // Verified expense this month, merchant matches, amount within ±10%/₹10.
      final paid = txs.any(
        (t) => RecurringMatching.paysBill(
          billName: name,
          billAmount: billAmount,
          merchant: t.merchant,
          amount: t.amount,
          isExpense: t.isExpense,
          isTransfer: t.isTransfer,
          isPendingVerification: t.isPendingVerification,
          date: t.date,
          now: now,
        ),
      );
      if (due.isBefore(DateTime(now.year, now.month, now.day)) && paid) {
        due = DateTime(now.year, now.month + 1, day);
      } else if (due.isBefore(DateTime(now.year, now.month, now.day)) &&
          !paid) {
        // keep overdue this month
      }
      entries.add(
        _RecurringEntry(
          name: name,
          category: bill['category']?.toString() ?? 'Bills & EMI',
          amount: (bill['amount'] as num? ?? 0).toDouble(),
          nextDue: due,
          paidThisPeriod: paid,
          isManual: true,
          manualId: bill['id']?.toString(),
          dayOfMonth: day,
        ),
      );
    }
    return entries;
  }

  void _openBillSheet({Map<String, dynamic>? existing}) {
    PremiumBottomSheet.show(
      context: context,
      child: _AddRecurringBillSheet(
        existing: existing,
        onSave: (bill) async {
          final bills = _manualBills();
          final id = bill['id']?.toString();
          if (id != null && bills.any((b) => b['id']?.toString() == id)) {
            final idx = bills.indexWhere((b) => b['id']?.toString() == id);
            bills[idx] = bill;
          } else {
            bills.add(bill);
          }
          await _saveManualBills(bills);
          if (mounted) setState(() {});
        },
      ),
    );
  }

  Future<void> _deleteManualBill(String id) async {
    final bills = _manualBills()..removeWhere((b) => b['id']?.toString() == id);
    await _saveManualBills(bills);
    if (mounted) setState(() {});
  }

  Future<void> _markPaidAndLogExpense(_RecurringEntry e) async {
    final userState = ref.read(userStateProvider);
    final active = [
      for (final a in userState.accounts)
        if (a.isActive) a.name,
    ];
    final purposes = userState.purposeTypes;
    final savedDefault =
        Hive.isBoxOpen('settings')
            ? Hive.box('settings').get('default_account')?.toString()
            : null;
    final choice = await PremiumBottomSheet.show<MarkPaidChoice>(
      context: context,
      child: MarkPaidSheet(
        billName: e.name,
        amountLabel: '₹${e.amount.toInt()}',
        accounts: active,
        purposes: purposes,
        initialAccount: savedDefault,
        initialPurpose: defaultPurposeOf(purposes),
      ),
    );
    if (choice == null || !mounted) return;
    final account = choice.account;
    final purpose = choice.purpose;

    final tx = model.Transaction(
      merchant: e.name,
      category: e.category,
      account: account,
      paymentType: account.toLowerCase() == 'cash' ? 'Cash' : 'Online',
      time: DateFormat('h:mm a').format(DateTime.now()),
      amount: e.amount,
      isExpense: true,
      date: DateTime.now(),
      purpose: purpose,
      note: 'Recurring bill',
      rawMessage: '',
    );
    ref.read(model.transactionProvider.notifier).addTransaction(tx);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Logged ₹${e.amount.toInt()} for ${e.name}'),
        behavior: SnackBarBehavior.floating,
        backgroundColor: SoftPalette.negative,
      ),
    );
    setState(() {});
  }

  void _confirmDelete(String id, String name) {
    showDialog(
      context: context,
      builder:
          (ctx) => AlertDialog(
            backgroundColor: ctx.softSurface,
            surfaceTintColor: Colors.transparent,
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24),
            ),
            title: Text(
              'Remove recurring bill?',
              style: TextStyle(
                color: ctx.softInk,
                fontSize: 20,
                fontWeight: FontWeight.w600,
              ),
            ),
            content: Text(
              'Remove $name? This removes the manual recurring bill only.',
              style: TextStyle(
                color: ctx.softMuted,
                fontSize: 14,
                height: 1.45,
              ),
            ),
            actionsPadding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                style: TextButton.styleFrom(
                  foregroundColor: ctx.softMuted,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 12,
                  ),
                ),
                child: const Text('Cancel'),
              ),
              FilledButton(
                onPressed: () {
                  Navigator.pop(ctx);
                  _deleteManualBill(id);
                },
                style: FilledButton.styleFrom(
                  backgroundColor: SoftColors.control,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 18,
                    vertical: 12,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                child: const Text('Remove'),
              ),
            ],
          ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final txs = ref.watch(model.transactionProvider);

    final manual = _manualEntries(txs);
    // A manual bill that also shows a monthly pattern must appear once.
    final all = [
      ...manual,
      ...RecurringMatching.dedupeDetected(
        _derivedEntries(txs),
        manual.map((m) => m.name),
        (d) => d.name,
      ),
    ];
    final upcoming =
        all.where((e) => !e.paidThisPeriod).toList()
          ..sort((a, b) => a.nextDue.compareTo(b.nextDue));
    final completed = all.where((e) => e.paidThisPeriod).toList();
    final fmt = NumberFormat.currency(
      symbol: '₹',
      decimalDigits: 0,
      locale: 'en_IN',
    );
    final now = DateTime.now();

    return Scaffold(
      backgroundColor: context.softBg,
      body: SafeArea(
        child: Column(
          children: [
            const SoftPageHeader(title: 'Recurring'),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                children: [
                  const SizedBox(height: 20),
                  if (all.isEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 60),
                      child: Column(
                        children: [
                          Icon(
                            LucideIcons.repeat,
                            size: 44,
                            color: context.tokens.textSecondary,
                          ),
                          const SizedBox(height: 12),
                          const Text(
                            'No recurring bills yet',
                            style: TextStyle(fontWeight: FontWeight.w500),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            'Bills you pay monthly are detected automatically from your transactions. Tap + to add one manually.',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 12,
                              color: context.tokens.textSecondary,
                            ),
                          ),
                        ],
                      ),
                    ),
                  if (upcoming.isNotEmpty) ...[
                    Text(
                      'UPCOMING',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                        letterSpacing: 1.2,
                        color: context.tokens.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 16),
                    ...upcoming.map((e) {
                      final daysLeft =
                          e.nextDue
                              .difference(
                                DateTime(now.year, now.month, now.day),
                              )
                              .inDays;
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: _RecurringItem(
                          name: e.name,
                          category: e.category,
                          amount: fmt.format(e.amount),
                          frequency:
                              e.isManual
                                  ? 'Monthly • Due ${DateFormat('d MMM').format(e.nextDue)}'
                                  : 'Detected monthly • Next ~${DateFormat('d MMM').format(e.nextDue)}',
                          daysLeft: daysLeft,
                          isDark: isDark,
                          isManual: e.isManual,
                          onMarkPaid: () => _markPaidAndLogExpense(e),
                          onEdit:
                              e.isManual && e.manualId != null
                                  ? () {
                                    final bill = _manualBills().firstWhere(
                                      (b) => b['id']?.toString() == e.manualId,
                                      orElse:
                                          () => {
                                            'id': e.manualId,
                                            'name': e.name,
                                            'amount': e.amount,
                                            'category': e.category,
                                            'dayOfMonth': e.dayOfMonth,
                                          },
                                    );
                                    _openBillSheet(existing: bill);
                                  }
                                  : null,
                          onDelete:
                              e.isManual && e.manualId != null
                                  ? () => _confirmDelete(e.manualId!, e.name)
                                  : null,
                        ),
                      );
                    }),
                  ],
                  if (completed.isNotEmpty) ...[
                    const SizedBox(height: 28),
                    Text(
                      'COMPLETED THIS MONTH',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                        letterSpacing: 1.2,
                        color: context.tokens.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 16),
                    ...completed.map(
                      (e) => Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: _RecurringItem(
                          name: e.name,
                          category: e.category,
                          amount: fmt.format(e.amount),
                          frequency: 'Paid this month',
                          daysLeft: -1,
                          isDark: isDark,
                          isPaid: true,
                          isManual: e.isManual,
                          onDelete:
                              e.isManual && e.manualId != null
                                  ? () => _confirmDelete(e.manualId!, e.name)
                                  : null,
                        ),
                      ),
                    ),
                  ],
                  const SizedBox(height: 80),
                ],
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _openBillSheet(),
        child: const Icon(LucideIcons.plus),
      ),
    );
  }
}

// ── Add / Edit recurring bill sheet ───────────────────────────────────────

class _AddRecurringBillSheet extends ConsumerStatefulWidget {
  final Map<String, dynamic>? existing;
  final void Function(Map<String, dynamic> bill) onSave;

  const _AddRecurringBillSheet({this.existing, required this.onSave});

  @override
  ConsumerState<_AddRecurringBillSheet> createState() =>
      _AddRecurringBillSheetState();
}

class _AddRecurringBillSheetState
    extends ConsumerState<_AddRecurringBillSheet> {
  late final TextEditingController _nameCtrl;
  late final TextEditingController _amountCtrl;
  late int _dayOfMonth;
  late String _category;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _nameCtrl = TextEditingController(text: e?['name']?.toString() ?? '');
    final amt = e?['amount'];
    _amountCtrl = TextEditingController(
      text:
          amt == null
              ? ''
              : (amt is num
                  ? (amt == amt.roundToDouble()
                      ? amt.toInt().toString()
                      : amt.toString())
                  : amt.toString()),
    );
    _dayOfMonth = (e?['dayOfMonth'] as num? ?? DateTime.now().day)
        .toInt()
        .clamp(1, 28);
    _category = e?['category']?.toString() ?? '';
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final cats = ref.read(categoryProvider).expense;
      if (_category.isEmpty ||
          !cats.any((c) => c.toLowerCase() == _category.toLowerCase())) {
        setState(() {
          _category =
              cats.isNotEmpty
                  ? (cats.firstWhere(
                    (c) => c.toLowerCase().contains('bill'),
                    orElse: () => cats.first,
                  ))
                  : 'Bills & EMI';
        });
      }
    });
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _amountCtrl.dispose();
    super.dispose();
  }

  void _save() {
    final name = _nameCtrl.text.trim();
    final amount = double.tryParse(_amountCtrl.text.replaceAll(',', '')) ?? 0;
    if (name.isEmpty || amount <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Enter a name and amount greater than 0'),
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }
    widget.onSave({
      'id':
          widget.existing?['id']?.toString() ??
          DateTime.now().millisecondsSinceEpoch.toString(),
      'name': name,
      'amount': amount,
      'category': _category.isEmpty ? 'Bills & EMI' : _category,
      'dayOfMonth': _dayOfMonth,
    });
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final cats = ref.watch(categoryProvider).expense;
    final isEdit = widget.existing != null;
    final fieldFill =
        isDark
            ? Colors.white.withValues(alpha: 0.05)
            : Colors.black.withValues(alpha: 0.03);

    return SingleChildScrollView(
      padding: EdgeInsets.fromLTRB(
        24,
        8,
        24,
        MediaQuery.paddingOf(context).bottom + 16,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            isEdit ? 'Edit recurring bill' : 'Add recurring bill',
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
          ),
          const SizedBox(height: 6),
          Text(
            'Rent, Netflix, EMI — due every month on a fixed day.',
            style: TextStyle(fontSize: 13, color: context.tokens.textSecondary),
          ),
          const SizedBox(height: 24),
          Text(
            'NAME',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w500,
              letterSpacing: 1.1,
              color: isDark ? Colors.white38 : Colors.black38,
            ),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _nameCtrl,
            textCapitalization: TextCapitalization.words,
            decoration: InputDecoration(
              hintText: 'e.g. Rent, Netflix, Car EMI',
              filled: true,
              fillColor: fieldFill,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'AMOUNT (₹)',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w500,
              letterSpacing: 1.1,
              color: isDark ? Colors.white38 : Colors.black38,
            ),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _amountCtrl,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(
              prefixText: '₹ ',
              hintText: '0',
              filled: true,
              fillColor: fieldFill,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'DUE DAY OF MONTH',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w500,
              letterSpacing: 1.1,
              color: isDark ? Colors.white38 : Colors.black38,
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            height: 44,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: 28,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, i) {
                final day = i + 1;
                final selected = _dayOfMonth == day;
                return GestureDetector(
                  onTap: () => setState(() => _dayOfMonth = day),
                  child: Container(
                    width: 44,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: selected ? SoftPalette.emerald : fieldFill,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      '$day',
                      style: TextStyle(
                        fontWeight: FontWeight.w500,
                        color:
                            selected
                                ? Colors.white
                                : (isDark ? Colors.white70 : Colors.black87),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 20),
          Text(
            'CATEGORY',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w500,
              letterSpacing: 1.1,
              color: isDark ? Colors.white38 : Colors.black38,
            ),
          ),
          const SizedBox(height: 10),
          if (cats.isEmpty)
            Text(
              'No categories — add one from transactions first.',
              style: TextStyle(
                fontSize: 12,
                color: context.tokens.textSecondary,
              ),
            )
          else
            CategorySelector(
              type: CategoryType.expense,
              selected: _category.isEmpty ? cats.first : _category,
              onChanged: (c) => setState(() => _category = c),
            ),
          const SizedBox(height: 28),
          SizedBox(
            height: 54,
            child: ElevatedButton(
              onPressed: _save,
              style: ElevatedButton.styleFrom(
                backgroundColor: SoftColors.control,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              child: Text(
                isEdit ? 'Save changes' : 'Add bill',
                style: const TextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: 16,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _RecurringItem extends StatelessWidget {
  final String name, category, amount, frequency;
  final int daysLeft;
  final bool isDark, isPaid, isManual;
  final VoidCallback? onMarkPaid;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;

  const _RecurringItem({
    required this.name,
    required this.category,
    required this.amount,
    required this.frequency,
    required this.daysLeft,
    required this.isDark,
    this.isPaid = false,
    this.isManual = false,
    this.onMarkPaid,
    this.onEdit,
    this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final cat = CategoryIcon.resolve(category);

    return SoftRecurringCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: cat.color,
                  shape: BoxShape.circle,
                ),
                child: Icon(cat.icon, color: cat.onColor, size: 18),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                        color: Theme.of(context).colorScheme.onSurface,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      frequency,
                      style: TextStyle(
                        fontSize: 12,
                        color: context.tokens.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    amount,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                      color: Theme.of(context).colorScheme.onSurface,
                    ),
                  ),
                  const SizedBox(height: 4),
                  if (!isPaid)
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color:
                            daysLeft <= 3
                                ? SoftPalette.negative.withValues(alpha: 0.12)
                                : SoftPalette.emerald.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        daysLeft < 0
                            ? '${-daysLeft} days overdue'
                            : daysLeft == 0
                            ? 'due today'
                            : 'in $daysLeft days',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w500,
                          color:
                              daysLeft <= 3
                                  ? SoftPalette.negative
                                  : SoftPalette.emerald,
                        ),
                      ),
                    )
                  else
                    const Icon(
                      LucideIcons.checkCircle,
                      color: SoftPalette.positive,
                      size: 16,
                    ),
                ],
              ),
            ],
          ),
          if (!isPaid || onEdit != null || onDelete != null) ...[
            const SizedBox(height: 12),
            Row(
              children: [
                if (!isPaid && onMarkPaid != null)
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: onMarkPaid,
                      icon: const Icon(LucideIcons.check, size: 14),
                      label: const Text('Mark paid'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: SoftPalette.positive,
                        side: BorderSide(
                          color: SoftPalette.positive.withValues(alpha: 0.4),
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 10),
                      ),
                    ),
                  ),
                if (!isPaid &&
                    onMarkPaid != null &&
                    (onEdit != null || onDelete != null))
                  const SizedBox(width: 8),
                if (onEdit != null)
                  IconButton(
                    onPressed: onEdit,
                    icon: const Icon(LucideIcons.pencil, size: 16),
                    tooltip: 'Edit',
                  ),
                if (onDelete != null)
                  IconButton(
                    onPressed: onDelete,
                    icon: const Icon(LucideIcons.trash2, size: 16),
                    color: SoftPalette.negative,
                    tooltip: 'Delete',
                  ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}
