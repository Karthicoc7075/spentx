import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:uuid/uuid.dart';

import '../../../core/sync/sync_service.dart';
import '../../../core/providers/category_provider.dart';
import '../../../core/providers/transaction_provider.dart' as model;
import '../../../core/utils/ledger_month_index.dart';
import '../../../data/local/hive_service.dart';

/// One category line in a monthly plan (matches web `PlanAllocation`).
class PlanAllocation {
  final String id;
  final String category;
  final double plannedAmount;
  final String? color;
  final bool rollover;

  const PlanAllocation({
    required this.id,
    required this.category,
    required this.plannedAmount,
    this.color,
    this.rollover = false,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'category': category,
    'plannedAmount': plannedAmount,
    'planned_amount': plannedAmount,
    if (color != null) 'color': color,
    'rollover': rollover,
  };

  factory PlanAllocation.fromJson(Map<dynamic, dynamic> json) => PlanAllocation(
    id: (json['id'] ?? const Uuid().v4()).toString(),
    category: (json['category'] ?? 'Other').toString(),
    plannedAmount:
        (json['plannedAmount'] as num? ?? json['planned_amount'] as num? ?? 0)
            .toDouble(),
    color: json['color']?.toString(),
    rollover: json['rollover'] == true,
  );

  PlanAllocation copyWith({
    String? category,
    double? plannedAmount,
    String? color,
    bool? rollover,
  }) {
    return PlanAllocation(
      id: id,
      category: category ?? this.category,
      plannedAmount: plannedAmount ?? this.plannedAmount,
      color: color ?? this.color,
      rollover: rollover ?? this.rollover,
    );
  }
}

/// Monthly plan — same concept as web Plan page (`monthly_plans` table).
class MonthlyPlan {
  final String id;
  final String month; // yyyy-MM
  final String? title;
  final String? purposeName; // mobile uses purpose name; sync resolves uuid
  final double expectedIncome;
  final List<PlanAllocation> allocations;
  final String? remoteId;
  final double? dailySafeLimit;
  final double? savingsTarget;
  final bool isBudgetLocked;
  final double bufferAmount;
  final String bufferChoice;
  final String? createdAt;
  final String? updatedAt;

  /// Hidden row stored inside the synced allocations JSON so buffer fields
  /// survive a server pull. It is never a category limit.
  static const bufferMetaId = '_spentx_plan_meta';

  /// One synced category row for the plan's outing limit. Not a real expense
  /// category, and never split into outing expense categories.
  static const outingLimitCategory = 'Outings';

  static bool isOutingLimit(String category) =>
      category.trim().toLowerCase() == outingLimitCategory.toLowerCase();

  const MonthlyPlan({
    required this.id,
    required this.month,
    this.title,
    this.purposeName,
    required this.expectedIncome,
    required this.allocations,
    this.remoteId,
    this.dailySafeLimit,
    this.savingsTarget,
    this.isBudgetLocked = false,
    this.bufferAmount = 0,
    this.bufferChoice = 'buffer',
    this.createdAt,
    this.updatedAt,
  });

  double get totalPlanned =>
      allocations.fold(0.0, (s, a) => s + a.plannedAmount);

  Map<String, dynamic> toJson() => {
    'id': id,
    'month': month,
    'title': title,
    'purposeName': purposeName,
    'expectedIncome': expectedIncome,
    'expected_income': expectedIncome,
    'allocations': allocations.map((a) => a.toJson()).toList(),
    'remoteId': remoteId,
    'dailySafeLimit': dailySafeLimit,
    'daily_safe_limit': dailySafeLimit,
    'savingsTarget': savingsTarget,
    'savings_target': savingsTarget,
    'isBudgetLocked': isBudgetLocked,
    'is_budget_locked': isBudgetLocked,
    'bufferAmount': bufferAmount,
    'bufferChoice': bufferChoice,
    'createdAt': createdAt,
    'updatedAt': updatedAt,
    'updated_at': updatedAt,
  };

  factory MonthlyPlan.fromJson(Map<dynamic, dynamic> json) {
    final rawAlloc = json['allocations'];
    final allocs = <PlanAllocation>[];
    double? metaBuffer;
    String? metaChoice;
    String? metaCreated;
    if (rawAlloc is List) {
      for (final e in rawAlloc) {
        if (e is! Map) continue;
        final map = Map<dynamic, dynamic>.from(e);
        final id = (map['id'] ?? '').toString();
        final category = (map['category'] ?? '').toString();
        if (id == bufferMetaId || category == bufferMetaId) {
          metaBuffer = (map['bufferAmount'] as num?)?.toDouble();
          metaChoice = map['bufferChoice']?.toString();
          metaCreated = map['createdAt']?.toString();
          continue;
        }
        allocs.add(PlanAllocation.fromJson(map));
      }
    }
    final choice = (json['bufferChoice'] ?? metaChoice ?? 'buffer').toString();
    return MonthlyPlan(
      id: (json['id'] ?? const Uuid().v4()).toString(),
      month: (json['month'] ?? '').toString(),
      title: json['title']?.toString(),
      purposeName:
          json['purposeName']?.toString() ?? json['purpose']?.toString(),
      expectedIncome:
          (json['expectedIncome'] as num? ??
                  json['expected_income'] as num? ??
                  0)
              .toDouble(),
      allocations: allocs,
      remoteId: json['remoteId']?.toString(),
      dailySafeLimit:
          (json['dailySafeLimit'] as num? ?? json['daily_safe_limit'] as num?)
              ?.toDouble(),
      savingsTarget:
          (json['savingsTarget'] as num? ?? json['savings_target'] as num?)
              ?.toDouble(),
      isBudgetLocked:
          json['isBudgetLocked'] == true || json['is_budget_locked'] == true,
      bufferAmount:
          (json['bufferAmount'] as num?)?.toDouble() ?? metaBuffer ?? 0,
      bufferChoice: choice == 'savings' ? 'savings' : 'buffer',
      createdAt: json['createdAt']?.toString() ?? metaCreated,
      updatedAt:
          json['updatedAt']?.toString() ?? json['updated_at']?.toString(),
    );
  }

  MonthlyPlan copyWith({
    String? title,
    String? purposeName,
    double? expectedIncome,
    List<PlanAllocation>? allocations,
    String? remoteId,
    double? dailySafeLimit,
    double? savingsTarget,
    bool? isBudgetLocked,
    double? bufferAmount,
    String? bufferChoice,
    String? createdAt,
    String? updatedAt,
  }) {
    return MonthlyPlan(
      id: id,
      month: month,
      title: title ?? this.title,
      purposeName: purposeName ?? this.purposeName,
      expectedIncome: expectedIncome ?? this.expectedIncome,
      allocations: allocations ?? this.allocations,
      remoteId: remoteId ?? this.remoteId,
      dailySafeLimit: dailySafeLimit ?? this.dailySafeLimit,
      savingsTarget: savingsTarget ?? this.savingsTarget,
      isBudgetLocked: isBudgetLocked ?? this.isBudgetLocked,
      bufferAmount: bufferAmount ?? this.bufferAmount,
      bufferChoice: bufferChoice ?? this.bufferChoice,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}

String currentPlanMonth() {
  final now = DateTime.now();
  return '${now.year.toString().padLeft(4, '0')}-${now.month.toString().padLeft(2, '0')}';
}

/// Planning is intentionally limited to the current and immediately
/// upcoming month. Older months remain available for history and edits.
String latestCreatablePlanMonth() => shiftPlanMonth(currentPlanMonth(), 1);

bool isPlanMonthCreatable(String month) =>
    month.compareTo(latestCreatablePlanMonth()) <= 0;

String shiftPlanMonth(String month, int delta) {
  final parts = month.split('-');
  if (parts.length != 2) return currentPlanMonth();
  final y = int.tryParse(parts[0]) ?? DateTime.now().year;
  final m = int.tryParse(parts[1]) ?? DateTime.now().month;
  final d = DateTime(y, m + delta, 1);
  return '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}';
}

String formatPlanMonth(String month) {
  final parts = month.split('-');
  if (parts.length != 2) return month;
  final y = int.tryParse(parts[0]) ?? 0;
  final m = int.tryParse(parts[1]) ?? 1;
  const names = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ];
  final name = (m >= 1 && m <= 12) ? names[m - 1] : month;
  return '$name $y';
}

/// Default plan display title, e.g. "July Smart 2026" (matches web formatDefaultPlanTitle).
String formatDefaultPlanTitle(String month) {
  final parts = month.split('-');
  if (parts.length != 2) return formatPlanMonth(month);
  final y = int.tryParse(parts[0]) ?? 0;
  final m = int.tryParse(parts[1]) ?? 1;
  const names = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ];
  final name = (m >= 1 && m <= 12) ? names[m - 1] : month;
  return '$name Smart $y';
}

String getPlanDisplayTitle(MonthlyPlan plan) {
  if (plan.title != null && plan.title!.trim().isNotEmpty) {
    return plan.title!.trim();
  }
  return formatDefaultPlanTitle(plan.month);
}

class PlanNotifier extends StateNotifier<List<MonthlyPlan>> {
  PlanNotifier(this._ref) : super([]) {
    _load();
  }

  final Ref _ref;
  static const boxName = 'monthly_plans';
  static const listKey = 'list';

  Box get _box {
    if (!Hive.isBoxOpen(boxName)) {
      // Open lazily if main didn't open yet.
      // ignore: discarded_futures
      SecureHive.openBox(boxName);
    }
    return Hive.box(boxName);
  }

  void _load() {
    try {
      if (!Hive.isBoxOpen(boxName)) return;
      final raw = _box.get(listKey, defaultValue: <dynamic>[]) as List;
      state =
          raw
              .whereType<Map>()
              .map((e) => MonthlyPlan.fromJson(Map<dynamic, dynamic>.from(e)))
              .toList();
      // One-time migrate local category budgets → current month plan.
      state = _withoutDemoSeed(state);
      if (state.isEmpty) {
        _migrateFromBudgetsIfAny();
      }
    } catch (_) {
      state = [];
    }
  }

  void reloadFromStorage() => _load();

  void _persist() {
    if (!Hive.isBoxOpen(boxName)) return;
    _box.put(listKey, state.map((p) => p.toJson()).toList());
  }

  static const _demoBudgetLimits = {
    'food': 12000.0,
    'transport': 8000.0,
    'shopping': 5000.0,
    'entertainment': 6000.0,
    'bills': 10000.0,
  };

  bool _rawBudgetsAreDemoSeed(List raw) {
    if (raw.length != _demoBudgetLimits.length) return false;
    final seen = <String>{};
    for (final e in raw) {
      if (e is! Map) return false;
      final key = (e['category'] ?? '').toString().trim().toLowerCase();
      final limit = (e['limit'] as num?)?.toDouble() ?? -1;
      if (_demoBudgetLimits[key] != limit || seen.contains(key)) return false;
      seen.add(key);
    }
    return seen.length == _demoBudgetLimits.length;
  }

  bool _isDemoSeedPlan(MonthlyPlan plan) {
    if (plan.isBudgetLocked) return false;
    if (plan.savingsTarget != null && plan.savingsTarget! > 0) return false;
    final allocs =
        plan.allocations
            .where((a) => a.id != MonthlyPlan.bufferMetaId)
            .toList();
    if (allocs.length != _demoBudgetLimits.length) return false;
    final seen = <String>{};
    for (final a in allocs) {
      final key = a.category.trim().toLowerCase();
      if (_demoBudgetLimits[key] != a.plannedAmount || seen.contains(key)) {
        return false;
      }
      seen.add(key);
    }
    return seen.length == _demoBudgetLimits.length;
  }

  List<MonthlyPlan> _withoutDemoSeed(List<MonthlyPlan> plans) {
    final demo = plans.where(_isDemoSeedPlan).toList();
    if (demo.isEmpty) return plans;
    final kept = plans.where((p) => !_isDemoSeedPlan(p)).toList();
    _box.put(listKey, kept.map((p) => p.toJson()).toList());
    for (final plan in demo) {
      SyncService.queuePlanDelete(
        plan.remoteId ?? plan.id,
        localId: plan.id,
        month: plan.month,
        purposeName: plan.purposeName,
      );
    }
    return kept;
  }

  void _migrateFromBudgetsIfAny() {
    try {
      if (!Hive.isBoxOpen('budgets')) return;
      final raw =
          Hive.box('budgets').get('list', defaultValue: <dynamic>[]) as List;
      if (raw.isEmpty) return;
      if (_rawBudgetsAreDemoSeed(raw)) return;
      final allocs = <PlanAllocation>[];
      for (final e in raw) {
        if (e is! Map) continue;
        final m = Map<String, dynamic>.from(e);
        final cat = (m['category'] ?? '').toString();
        final limit = (m['limit'] as num?)?.toDouble() ?? 0;
        if (cat.isEmpty || limit <= 0) continue;
        allocs.add(
          PlanAllocation(
            id: const Uuid().v4(),
            category: cat,
            plannedAmount: limit,
          ),
        );
      }
      if (allocs.isEmpty) return;
      final now = DateTime.now().toUtc().toIso8601String();
      final plan = MonthlyPlan(
        id: const Uuid().v4(),
        month: currentPlanMonth(),
        title: '${formatPlanMonth(currentPlanMonth())} Plan',
        purposeName: 'Personal',
        expectedIncome: allocs.fold(0.0, (s, a) => s + a.plannedAmount),
        allocations: allocs,
        createdAt: now,
        updatedAt: now,
      );
      state = [plan];
      _persist();
      SyncService.queuePlanUpsert(plan.toJson());
    } catch (_) {}
  }

  static String purposeKey(String? name) {
    final n = (name ?? '').trim().toLowerCase();
    return n.isEmpty ? 'personal' : n;
  }

  MonthlyPlan? planFor({required String month, String? purposeName}) {
    final purpose = purposeKey(purposeName);
    return state
        .where((p) => p.month == month && purposeKey(p.purposeName) == purpose)
        .firstOrNull;
  }

  /// Saved plans for one purpose, newest month first.
  List<MonthlyPlan> historyForPurpose(String purposeName) =>
      plansForPurpose(state, purposeName);

  /// Spent this month for a category (optionally purpose-filtered).
  double spentForCategory({
    required String month,
    required String category,
    String? purposeName,
  }) {
    return LedgerMonthIndex.of(
      _ref.read(model.transactionProvider),
    ).categorySpend(month, category, purposeName: purposeName);
  }

  double incomeForMonth({required String month, String? purposeName}) {
    return LedgerMonthIndex.of(
      _ref.read(model.transactionProvider),
    ).incomeFor(month, purposeName: purposeName);
  }

  /// Sum of auto-detected credit alerts for [month] on [purposeName].
  /// Manual income is not included. An empty result is 0.
  double creditAlertsForMonth({required String month, String? purposeName}) {
    return LedgerMonthIndex.of(
      _ref.read(model.transactionProvider),
    ).creditAlertsFor(month, purposeName: purposeName);
  }

  /// Calculates unspent budget headroom from the previous month for rollover.
  /// Overspending never carries over as negative (clamped at 0.0).
  double rolloverHeadroomForCategory({
    required String month,
    required String category,
    String? purposeName,
  }) {
    final prevMonth = shiftPlanMonth(month, -1);
    final prevPlan = planFor(month: prevMonth, purposeName: purposeName);
    if (prevPlan == null) return 0.0;
    final alloc =
        prevPlan.allocations
            .where((a) => a.category.toLowerCase() == category.toLowerCase())
            .firstOrNull;
    if (alloc == null || alloc.plannedAmount <= 0) return 0.0;
    final prevSpent = spentForCategory(
      month: prevMonth,
      category: category,
      purposeName: purposeName,
    );
    final unused = alloc.plannedAmount - prevSpent;
    return unused > 0 ? unused : 0.0;
  }

  MonthlyPlan ensureDraft({
    required String month,
    String purposeName = 'Personal',
  }) {
    final existing = planFor(month: month, purposeName: purposeName);
    if (existing != null) return existing;

    final cats = _ref.read(categoryProvider).expense;
    final allocs =
        cats
            .map(
              (c) => PlanAllocation(
                id: const Uuid().v4(),
                category: c,
                plannedAmount: 0,
              ),
            )
            .toList();
    // Seed from legacy budgets if present
    if (Hive.isBoxOpen('budgets')) {
      final raw =
          Hive.box('budgets').get('list', defaultValue: <dynamic>[]) as List;
      for (final e in raw) {
        if (e is! Map) continue;
        final m = Map<String, dynamic>.from(e);
        final cat = (m['category'] ?? '').toString();
        final limit = (m['limit'] as num?)?.toDouble() ?? 0;
        if (cat.isEmpty || limit <= 0) continue;
        final idx = allocs.indexWhere(
          (a) => a.category.toLowerCase() == cat.toLowerCase(),
        );
        if (idx >= 0) {
          allocs[idx] = allocs[idx].copyWith(plannedAmount: limit);
        } else {
          allocs.add(
            PlanAllocation(
              id: const Uuid().v4(),
              category: cat,
              plannedAmount: limit,
            ),
          );
        }
      }
    }

    final plan = MonthlyPlan(
      id: const Uuid().v4(),
      month: month,
      title: '${formatPlanMonth(month)} Plan',
      purposeName: purposeName,
      expectedIncome: incomeForMonth(month: month, purposeName: purposeName),
      allocations: allocs,
    );
    state = [plan, ...state.where((p) => p.id != plan.id)];
    _persist();
    return plan;
  }

  Future<void> savePlan(MonthlyPlan plan) async {
    if (!isPlanMonthCreatable(plan.month)) return;
    final now = DateTime.now().toUtc().toIso8601String();
    final cleaned = plan.copyWith(
      allocations:
          plan.allocations
              .where(
                (a) =>
                    a.category.trim().isNotEmpty &&
                    a.category != MonthlyPlan.bufferMetaId &&
                    a.id != MonthlyPlan.bufferMetaId,
              )
              .toList(),
      createdAt:
          (plan.createdAt == null || plan.createdAt!.trim().isEmpty)
              ? now
              : plan.createdAt,
      updatedAt: now,
    );
    final target = '${cleaned.month}|${purposeKey(cleaned.purposeName)}';
    final next = <MonthlyPlan>[cleaned];
    final seenIds = <String>{cleaned.id};
    for (final p in state) {
      if (!seenIds.add(p.id)) continue;
      final key = '${p.month}|${purposeKey(p.purposeName)}';
      if (key == target) continue;
      next.add(p);
    }
    state = next;
    _persist();
    SyncService.queuePlanUpsert(cleaned.toJson());
  }

  Future<void> deletePlan(String id) async {
    final plan = state.where((p) => p.id == id).firstOrNull;
    state = state.where((p) => p.id != id).toList();
    _persist();
    if (plan != null) {
      SyncService.queuePlanDelete(
        plan.remoteId ?? plan.id,
        localId: plan.id,
        month: plan.month,
        purposeName: plan.purposeName,
      );
    }
  }

  /// Replace local list from server pull.
  void replaceFromServer(List<MonthlyPlan> remote) {
    // Simple merge: server wins for same month+purpose unless queued
    final map = <String, MonthlyPlan>{};
    for (final p in remote) {
      final key = '${p.month}|${purposeKey(p.purposeName)}';
      map[key] = p;
    }
    for (final p in state) {
      final key = '${p.month}|${purposeKey(p.purposeName)}';
      // keep local if not on server and has non-zero plan
      if (!map.containsKey(key) && p.totalPlanned > 0) {
        map[key] = p;
      }
    }
    state = _withoutDemoSeed(
      map.values.toList()..sort((a, b) => b.month.compareTo(a.month)),
    );
    _persist();
  }
}

bool planPurposeIsPersonal(MonthlyPlan plan) =>
    PlanNotifier.purposeKey(plan.purposeName) == 'personal';

/// This month only. Personal wins when another purpose also has a plan.
MonthlyPlan? pickHomePlan(Iterable<MonthlyPlan> plans, String month) {
  MonthlyPlan? fallback;
  for (final plan in plans) {
    if (plan.month != month) continue;
    if (planPurposeIsPersonal(plan)) return plan;
    fallback ??= plan;
  }
  return fallback;
}

List<MonthlyPlan> plansForPurpose(
  Iterable<MonthlyPlan> plans,
  String purposeName,
) {
  final want = PlanNotifier.purposeKey(purposeName);
  final rows =
      plans
          .where((p) => PlanNotifier.purposeKey(p.purposeName) == want)
          .toList();
  rows.sort((a, b) {
    final byMonth = b.month.compareTo(a.month);
    if (byMonth != 0) return byMonth;
    return (b.createdAt ?? '').compareTo(a.createdAt ?? '');
  });
  return rows;
}

final planProvider = StateNotifierProvider<PlanNotifier, List<MonthlyPlan>>(
  (ref) => PlanNotifier(ref),
);
