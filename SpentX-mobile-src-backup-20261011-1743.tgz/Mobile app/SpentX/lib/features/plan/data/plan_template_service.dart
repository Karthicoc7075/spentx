import 'dart:developer' as dev;
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../../../core/services/auth_service.dart';
import 'plan_provider.dart';
import '../../../../models/plan_template_model.dart';

class PlanTemplateService {
  static SupabaseClient get _db => Supabase.instance.client;

  static Future<List<PlanTemplateModel>> fetchTemplates() async {
    final userId = AuthService.currentUserId;
    if (userId == null || userId.isEmpty) return [];

    try {
      final rows = await _db
          .from('budget_templates')
          .select('*')
          .eq('user_id', userId)
          .order('created_at', ascending: true);

      return (rows as List<dynamic>)
          .cast<Map<String, dynamic>>()
          .where((r) => r['deleted_at'] == null) // soft-deleted
          .map(PlanTemplateModel.fromMap)
          .toList();
    } catch (e, stack) {
      dev.log('Error fetching budget templates: $e', stackTrace: stack);
      return [];
    }
  }

  static Future<PlanTemplateModel> saveTemplate({
    String? id,
    required String name,
    required double expectedIncome,
    required List<PlanAllocation> allocations,
  }) async {
    final userId = AuthService.currentUserId;
    if (userId == null || userId.isEmpty) {
      throw Exception('Sign in before saving templates.');
    }

    final payload = <String, dynamic>{
      'user_id': userId,
      'template_name': name,
      'expected_income': expectedIncome,
      'allocations': allocations.map((a) => a.toJson()).toList(),
    };
    if (id != null && id.isNotEmpty) {
      payload['id'] = id;
    }

    final res =
        await _db.from('budget_templates').upsert(payload).select('*').single();

    return PlanTemplateModel.fromMap(res);
  }

  static Future<void> deleteTemplate(String templateId) async {
    final userId = AuthService.currentUserId;
    if (userId == null || userId.isEmpty) return;

    // Soft delete (deleted_at, migration 20261011_security_audit_fixes);
    // hard delete only if that column does not exist yet.
    try {
      await _db
          .from('budget_templates')
          .update({'deleted_at': DateTime.now().toUtc().toIso8601String()})
          .eq('user_id', userId)
          .eq('id', templateId);
    } on PostgrestException catch (e) {
      final missing =
          e.code == '42703' ||
          e.code == 'PGRST204' ||
          e.message.contains('deleted_at');
      if (!missing) rethrow;
      await _db
          .from('budget_templates')
          .delete()
          .eq('user_id', userId)
          .eq('id', templateId);
    }
  }
}
