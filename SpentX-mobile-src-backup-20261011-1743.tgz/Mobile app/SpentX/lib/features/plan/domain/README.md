# plan domain — monthly plan / budget entities
