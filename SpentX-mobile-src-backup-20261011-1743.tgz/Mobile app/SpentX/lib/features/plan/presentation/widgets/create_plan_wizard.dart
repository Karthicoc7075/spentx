import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';
import 'package:intl/intl.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/providers/category_provider.dart';
import '../../../../core/theme/soft_palette.dart';
import '../../../../core/widgets/category_icon.dart';
import '../../data/plan_provider.dart';
import 'soft_plan_widgets.dart';

/// SpentX Create Plan Logic Flow v1.
///
/// One draft moves through the three steps. Create plan on Step 3 is the
/// first save. Amounts are read from the draft, not from field text.
class CreatePlanWizard extends ConsumerStatefulWidget {
  const CreatePlanWizard({
    super.key,
    required this.month,
    required this.purposeId,
    required this.onSave,
  });

  final String month;
  final String purposeId;
  final Future<void> Function(MonthlyPlan updated) onSave;

  @override
  ConsumerState<CreatePlanWizard> createState() => _CreatePlanWizardState();
}

enum _DraftBuffer { keep, savings }

class _CreatePlanDraft {
  _CreatePlanDraft({
    required this.month,
    required this.purposeId,
    required this.expectedIncome,
    required this.categoryLimits,
  });

  final String month;
  final String purposeId;
  double expectedIncome;
  final Map<String, double> categoryLimits;
  _DraftBuffer bufferChoice = _DraftBuffer.keep;

  double get totalPlanned =>
      categoryLimits.values.fold(0.0, (sum, value) => sum + value);

  double get buffer => expectedIncome - totalPlanned;
}

class _CreatePlanWizardState extends ConsumerState<CreatePlanWizard> {
  final _incomeFocus = FocusNode();
  late final TextEditingController _incomeCtrl;
  late final List<PlanAllocation> _allocs;
  late final Map<String, TextEditingController> _amountCtrls;
  late final Map<String, bool> _rolloverMap;
  late final _CreatePlanDraft _draft;
  late final double _suggestion;
  late final double _initialIncome;
  late final Map<String, double> _initialLimits;
  int _step = 0;
  bool _isSaving = false;
  final bool _showOver = false;
  bool _leaving = false;
  bool _confirming = false;

  static const _cardShadow = [
    BoxShadow(
      color: Color.fromRGBO(2, 6, 23, 0.05),
      offset: Offset(0, 8),
      blurRadius: 24,
      spreadRadius: -4,
    ),
  ];

  static const _buttonShadow = [
    BoxShadow(
      color: Color.fromRGBO(16, 185, 129, 0.35),
      offset: Offset(0, 10),
      blurRadius: 20,
      spreadRadius: -5,
    ),
  ];

  @override
  void initState() {
    super.initState();
    final purpose =
        widget.purposeId.trim().isEmpty ? 'Personal' : widget.purposeId.trim();
    final notifier = ref.read(planProvider.notifier);
    _suggestion = notifier.creditAlertsForMonth(
      month: shiftPlanMonth(widget.month, -1),
      purposeName: purpose,
    );
    final cats = ref.read(categoryProvider).expense;
    final ordered = <String>[
      for (final cat in cats)
        if (!MonthlyPlan.isOutingLimit(cat)) cat,
      MonthlyPlan.outingLimitCategory,
    ];
    final limits = <String, double>{for (final cat in ordered) cat: 0};
    _draft = _CreatePlanDraft(
      month: widget.month,
      purposeId: purpose,
      expectedIncome: _suggestion > 0 ? _suggestion : 0,
      categoryLimits: limits,
    );
    _initialIncome = _draft.expectedIncome;
    _initialLimits = Map<String, double>.from(limits);
    _incomeCtrl = TextEditingController(text: _plain(_draft.expectedIncome));
    _allocs = [
      for (final cat in limits.keys)
        PlanAllocation(
          id: 'alloc-${widget.month}-$cat',
          category: cat,
          plannedAmount: 0,
          rollover: false,
        ),
    ];
    _amountCtrls = {
      for (final allocation in _allocs)
        allocation.id: TextEditingController(text: ''),
    };
    _rolloverMap = {for (final allocation in _allocs) allocation.id: false};
  }

  String _plain(double value) {
    if (value == 0) return '';
    if (value == value.roundToDouble()) return value.round().toString();
    return value.toString();
  }

  @override
  void dispose() {
    _incomeFocus.dispose();
    _incomeCtrl.dispose();
    for (final controller in _amountCtrls.values) {
      controller.dispose();
    }
    super.dispose();
  }

  double get _income => _draft.expectedIncome;

  double get _totalPlanned => _draft.totalPlanned;

  bool get _over => _totalPlanned > _income;

  double get _buffer => _draft.buffer;

  bool get _edited {
    if ((_draft.expectedIncome - _initialIncome).abs() > 0.001) return true;
    for (final entry in _draft.categoryLimits.entries) {
      final initial = _initialLimits[entry.key] ?? 0;
      if ((entry.value - initial).abs() > 0.001) return true;
    }
    return false;
  }

  String get _purposeLabel => _draft.purposeId;

  String get _monthWord {
    final label = formatPlanMonth(_draft.month);
    final space = label.indexOf(' ');
    return space < 0 ? label : label.substring(0, space);
  }

  String get _previousMonthWord {
    final label = formatPlanMonth(shiftPlanMonth(_draft.month, -1));
    final space = label.indexOf(' ');
    return space < 0 ? label : label.substring(0, space);
  }

  String _money(num value) => NumberFormat.currency(
    locale: 'en_IN',
    symbol: '₹',
    decimalDigits: 0,
  ).format(value);

  void _adjustIncome(int delta) {
    final next = (_draft.expectedIncome + delta).clamp(0, 100000000).toDouble();
    _draft.expectedIncome = next;
    _incomeCtrl.text = _plain(next);
    _incomeCtrl.selection = TextSelection.collapsed(
      offset: _incomeCtrl.text.length,
    );
    setState(() {});
  }

  void _clearIncome() {
    _draft.expectedIncome = 0;
    _incomeCtrl.clear();
    setState(() {});
  }

  void _setIncomeText(String raw) {
    _draft.expectedIncome =
        double.tryParse(raw.replaceAll(',', '').trim()) ?? 0;
    setState(() {});
  }

  void _setLimit(String categoryId, double amount) {
    _draft.categoryLimits[categoryId] = amount;
    setState(() {});
  }

  void _openReview() {
    FocusManager.instance.primaryFocus?.unfocus();
    setState(() => _step = 2);
  }

  Future<void> _discard() async {
    if (_confirming || _leaving) return;
    FocusManager.instance.primaryFocus?.unfocus();
    if (_edited) {
      _confirming = true;
      final discard = await showDialog<bool>(
        context: context,
        builder:
            (ctx) => AlertDialog(
              backgroundColor: SoftPalette.card,
              surfaceTintColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(24),
              ),
              title: const Text(
                'Discard this plan?',
                style: TextStyle(
                  color: SoftPalette.ink,
                  fontWeight: FontWeight.w700,
                ),
              ),
              content: const Text(
                'The income and limits you edited will be discarded.',
                style: TextStyle(color: SoftPalette.muted),
              ),
              actions: [
                TextButton(
                  style: TextButton.styleFrom(
                    foregroundColor: SoftPalette.muted,
                  ),
                  onPressed: () => Navigator.pop(ctx, false),
                  child: const Text('Keep editing'),
                ),
                TextButton(
                  style: TextButton.styleFrom(
                    foregroundColor: SoftPalette.emerald,
                  ),
                  onPressed: () => Navigator.pop(ctx, true),
                  child: const Text('Discard'),
                ),
              ],
            ),
      );
      _confirming = false;
      if (discard != true || !mounted) return;
    }
    _leave();
  }

  void _leave() {
    if (!mounted || _leaving) return;
    setState(() => _leaving = true);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) Navigator.of(context).pop();
    });
  }

  Future<void> _save() async {
    if (_isSaving) return;
    setState(() => _isSaving = true);
    try {
      final existing = ref
          .read(planProvider.notifier)
          .planFor(month: _draft.month, purposeName: _draft.purposeId);
      final allocations = <PlanAllocation>[
        for (final entry in _draft.categoryLimits.entries)
          PlanAllocation(
            id:
                existing?.allocations
                    .where(
                      (a) =>
                          a.category.toLowerCase() == entry.key.toLowerCase(),
                    )
                    .firstOrNull
                    ?.id ??
                'alloc-${_draft.month}-${entry.key}',
            category: entry.key,
            plannedAmount: entry.value,
            color:
                existing?.allocations
                    .where(
                      (a) =>
                          a.category.toLowerCase() == entry.key.toLowerCase(),
                    )
                    .firstOrNull
                    ?.color,
            rollover:
                existing?.allocations
                    .where(
                      (a) =>
                          a.category.toLowerCase() == entry.key.toLowerCase(),
                    )
                    .firstOrNull
                    ?.rollover ??
                false,
          ),
      ];
      final now = DateTime.now().toUtc().toIso8601String();
      final saved = MonthlyPlan(
        id: existing?.id ?? const Uuid().v4(),
        month: _draft.month,
        purposeName: _draft.purposeId,
        title: existing?.title ?? '${formatPlanMonth(_draft.month)} Plan',
        expectedIncome: _draft.expectedIncome,
        allocations: allocations,
        remoteId: existing?.remoteId,
        dailySafeLimit: existing?.dailySafeLimit,
        savingsTarget: existing?.savingsTarget,
        isBudgetLocked: existing?.isBudgetLocked ?? false,
        bufferAmount: _draft.buffer < 0 ? 0 : _draft.buffer,
        bufferChoice:
            _draft.bufferChoice == _DraftBuffer.savings ? 'savings' : 'buffer',
        createdAt: existing?.createdAt ?? now,
        updatedAt: now,
      );
      if (_over) {
        if (mounted) {
          showPlanToast(
            context,
            'Total planned exceeds expected income. Adjust limits before saving.',
          );
        }
        return;
      }
      await widget.onSave(saved);
      if (!mounted) return;
      _leave();
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  Widget _body(bool dark) {
    final shadow = dark ? null : _cardShadow;
    if (_step == 0) {
      return _StepOne(
        purpose: _purposeLabel,
        monthWord: _monthWord,
        previousMonthWord: _previousMonthWord,
        suggestion: _suggestion,
        controller: _incomeCtrl,
        focusNode: _incomeFocus,
        shadow: shadow,
        onIncome: _setIncomeText,
        onAdd: _adjustIncome,
        onClear: _clearIncome,
      );
    }
    if (_step == 1) {
      return _StepTwo(
        purpose: _purposeLabel,
        income: _income,
        total: _totalPlanned,
        over: _over,
        showOver: _showOver,
        allocs: _allocs,
        amountCtrls: _amountCtrls,
        rolloverMap: _rolloverMap,
        month: _draft.month,
        purposeName: _draft.purposeId,
        shadow: shadow,
        money: _money,
        onLimit: _setLimit,
      );
    }
    return _StepThree(
      purpose: _purposeLabel,
      monthWord: _monthWord,
      income: _income,
      total: _totalPlanned,
      buffer: _buffer,
      over: _over,
      allocs: _allocs,
      limits: _draft.categoryLimits,
      rolloverMap: _rolloverMap,
      month: _draft.month,
      purposeName: _draft.purposeId,
      shadow: shadow,
      money: _money,
      onEditLimits: () => setState(() => _step = 1),
    );
  }

  @override
  Widget build(BuildContext context) {
    final dark = PlanSoft.dark(context);
    return PopScope(
      canPop: _leaving,
      onPopInvokedWithResult: (didPop, _) {
        if (didPop) return;
        if (_step > 0) {
          FocusManager.instance.primaryFocus?.unfocus();
          setState(() => _step -= 1);
          return;
        }
        _discard();
      },
      child: Scaffold(
        backgroundColor: PlanSoft.canvas(context),
        resizeToAvoidBottomInset: true,
        body: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
                child: _WizardHeader(
                  step: _step,
                  title: 'Create $_monthWord Plan',
                  onBack: () {
                    if (_step == 0) {
                      _discard();
                    } else {
                      FocusManager.instance.primaryFocus?.unfocus();
                      setState(() => _step -= 1);
                    }
                  },
                  onClose: _discard,
                ),
              ),
              const SizedBox(height: 14),
              Expanded(child: _body(dark)),
              _footer(context),
            ],
          ),
        ),
      ),
    );
  }

  Widget _footer(BuildContext context) {
    final laterStyle = PlanSoft.text(
      context,
      13,
      FontWeight.w600,
      PlanSoft.slate(context),
    );
    final pinned = _step == 1;
    final hasLimit = _draft.categoryLimits.values.any((value) => value > 0);
    final canContinue = !_isSaving && (_step != 1 || hasLimit);
    return Material(
      color:
          pinned
              ? PlanSoft.card(context).withValues(alpha: 0.95)
              : Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (_step == 1) ...[
              Text(
                'Total planned ${_money(_totalPlanned)} · Unallocated ${_money(_buffer)}',
                textAlign: TextAlign.center,
                style: PlanSoft.text(
                  context,
                  12,
                  FontWeight.w600,
                  PlanSoft.slate(context),
                ),
              ),
              const SizedBox(height: 10),
            ],
            SizedBox(
              width: double.infinity,
              height: _step == 1 ? 52 : 56,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(_step == 1 ? 16 : 20),
                  gradient:
                      !canContinue || _step == 1
                          ? null
                          : SoftColors.primaryGradient,
                  color:
                      !canContinue
                          ? (PlanSoft.dark(context)
                              ? const Color(0xFF3F3F46)
                              : const Color(0xFFCBD5E1))
                          : (_step == 1 ? PlanSoft.emerald : null),
                  boxShadow:
                      !canContinue || PlanSoft.dark(context) || _step == 1
                          ? null
                          : _buttonShadow,
                ),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundBuilder: SoftColors.plainBackground,
                    backgroundColor: Colors.transparent,
                    disabledBackgroundColor: Colors.transparent,
                    shadowColor: Colors.transparent,
                    foregroundColor: Colors.white,
                    disabledForegroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(_step == 1 ? 16 : 20),
                    ),
                  ),
                  onPressed:
                      canContinue
                          ? () {
                            if (_step == 0) {
                              setState(() => _step = 1);
                            } else if (_step == 1) {
                              _openReview();
                            } else {
                              _save();
                            }
                          }
                          : null,
                  child: Text(
                    _isSaving
                        ? 'Saving...'
                        : (_step == 2 ? 'Create plan →' : 'Continue →'),
                    style: PlanSoft.text(
                      context,
                      15,
                      FontWeight.w700,
                      Colors.white,
                    ),
                  ),
                ),
              ),
            ),
            if (_step != 1)
              TextButton(
                onPressed:
                    _isSaving
                        ? null
                        : () {
                          if (_step == 0) {
                            _draft.expectedIncome = 0;
                            _incomeCtrl.clear();
                            setState(() => _step = 1);
                          } else {
                            setState(() => _step = 1);
                          }
                        },
                child: Text(
                  _step == 0
                      ? "I'll set my expected income later"
                      : 'Back to limits',
                  style: laterStyle,
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _WizardHeader extends StatelessWidget {
  const _WizardHeader({
    required this.step,
    required this.title,
    required this.onBack,
    required this.onClose,
  });

  final int step;
  final String title;
  final VoidCallback onBack;
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    final fill = step == 0 ? 0.33 : (step == 1 ? 0.66 : 1.0);
    return Column(
      children: [
        Row(
          children: [
            _CircleButton(
              icon: Icons.arrow_back_ios_new_rounded,
              onTap: onBack,
            ),
            Expanded(
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: PlanSoft.mint(context),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      'STEP ${step + 1} OF 3',
                      style: PlanSoft.text(
                        context,
                        10,
                        FontWeight.w700,
                        PlanSoft.emeraldDeep(context),
                        letterSpacing: 0.6,
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    title,
                    textAlign: TextAlign.center,
                    style: PlanSoft.text(
                      context,
                      16,
                      FontWeight.w700,
                      PlanSoft.ink(context),
                    ),
                  ),
                ],
              ),
            ),
            _CircleButton(icon: LucideIcons.x, onTap: onClose),
          ],
        ),
        const SizedBox(height: 14),
        ClipRRect(
          borderRadius: BorderRadius.circular(99),
          child: SizedBox(
            height: 6,
            child: Stack(
              children: [
                Container(
                  color:
                      PlanSoft.dark(context)
                          ? PlanSoft.track(context)
                          : const Color(0xFFE2E8F0).withValues(alpha: 0.7),
                ),
                FractionallySizedBox(
                  widthFactor: fill,
                  // Progress accent: solid control green (no gradient).
                  child: const DecoratedBox(
                    decoration: BoxDecoration(color: SoftColors.control),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _CircleButton extends StatelessWidget {
  const _CircleButton({required this.icon, required this.onTap});

  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final dark = PlanSoft.dark(context);
    return Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(
        color: PlanSoft.backFill(context),
        shape: BoxShape.circle,
        border: Border.all(
          color: dark ? PlanSoft.border(context) : const Color(0xFFE2E8F0),
        ),
        boxShadow:
            dark
                ? null
                : const [
                  BoxShadow(
                    color: Color.fromRGBO(2, 6, 23, 0.06),
                    offset: Offset(0, 2),
                    blurRadius: 8,
                  ),
                ],
      ),
      child: Material(
        color: Colors.transparent,
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: Icon(icon, size: 16, color: PlanSoft.slate(context)),
        ),
      ),
    );
  }
}

class _StepOne extends StatelessWidget {
  const _StepOne({
    required this.purpose,
    required this.monthWord,
    required this.previousMonthWord,
    required this.suggestion,
    required this.controller,
    required this.focusNode,
    required this.shadow,
    required this.onIncome,
    required this.onAdd,
    required this.onClear,
  });

  final String purpose;
  final String monthWord;
  final String previousMonthWord;
  final double suggestion;
  final TextEditingController controller;
  final FocusNode focusNode;
  final List<BoxShadow>? shadow;
  final ValueChanged<String> onIncome;
  final void Function(int delta) onAdd;
  final VoidCallback onClear;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
      children: [
        Container(
          decoration: BoxDecoration(
            color: PlanSoft.card(context),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: PlanSoft.border(context)),
            boxShadow: shadow,
          ),
          clipBehavior: Clip.antiAlias,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(height: 4, color: PlanSoft.emerald),
              Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: PlanSoft.mint(context),
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 8,
                            height: 8,
                            decoration: const BoxDecoration(
                              color: PlanSoft.emerald,
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: 6),
                          Flexible(
                            child: Text(
                              '$purpose Purpose Plan',
                              style: PlanSoft.text(
                                context,
                                12,
                                FontWeight.w600,
                                PlanSoft.ink(context),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'Expected income',
                      style: PlanSoft.text(
                        context,
                        24,
                        FontWeight.w800,
                        PlanSoft.ink(context),
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'How much do you expect to receive this month?',
                      style: PlanSoft.text(
                        context,
                        14,
                        FontWeight.w500,
                        PlanSoft.slate(context),
                      ),
                    ),
                    const SizedBox(height: 18),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
                      decoration: BoxDecoration(
                        color: PlanSoft.canvas(context),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: PlanSoft.mint(context),
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: Text(
                              'MONTHLY INFLOW',
                              style: PlanSoft.text(
                                context,
                                10,
                                FontWeight.w700,
                                PlanSoft.dark(context)
                                    ? PlanSoft.emeraldDeep(context)
                                    : const Color(0xFF047857),
                                letterSpacing: 0.5,
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.baseline,
                            textBaseline: TextBaseline.alphabetic,
                            children: [
                              Text(
                                '₹',
                                style: PlanSoft.text(
                                  context,
                                  30,
                                  FontWeight.w700,
                                  PlanSoft.emerald,
                                ),
                              ),
                              const SizedBox(width: 4),
                              Expanded(
                                child: TextField(
                                  controller: controller,
                                  focusNode: focusNode,
                                  autofocus: true,
                                  showCursor: true,
                                  cursorColor: PlanSoft.emerald,
                                  cursorWidth: 2,
                                  keyboardType:
                                      const TextInputType.numberWithOptions(
                                        decimal: true,
                                      ),
                                  style: PlanSoft.text(
                                    context,
                                    40,
                                    FontWeight.w800,
                                    PlanSoft.ink(context),
                                    height: 1.1,
                                  ),
                                  decoration: InputDecoration(
                                    isCollapsed: true,
                                    border: InputBorder.none,
                                    enabledBorder: InputBorder.none,
                                    focusedBorder: InputBorder.none,
                                    disabledBorder: InputBorder.none,
                                    hintText: '0',
                                    hintStyle: PlanSoft.text(
                                      context,
                                      40,
                                      FontWeight.w800,
                                      PlanSoft.ink(context),
                                      height: 1.1,
                                    ),
                                  ),
                                  onChanged: onIncome,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    if (suggestion > 0) ...[
                      const SizedBox(height: 10),
                      Text(
                        'Auto-suggested from $previousMonthWord credit alerts',
                        style: PlanSoft.text(
                          context,
                          12,
                          FontWeight.w500,
                          PlanSoft.slate(context),
                        ),
                      ),
                    ],
                    const SizedBox(height: 14),
                    Divider(height: 1, color: PlanSoft.border(context)),
                    const SizedBox(height: 14),
                    Text(
                      'Quick adjust:',
                      style: PlanSoft.text(
                        context,
                        12,
                        FontWeight.w600,
                        PlanSoft.slate(context),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        _MintChip(label: '+₹5,000', onTap: () => onAdd(5000)),
                        _MintChip(label: '+₹10,000', onTap: () => onAdd(10000)),
                        _MintChip(label: 'Clear', onTap: onClear),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 22,
                          height: 22,
                          decoration: BoxDecoration(
                            color: PlanSoft.mint(context),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            LucideIcons.check,
                            size: 12,
                            color: PlanSoft.emerald,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'This establishes your spending ceiling for $monthWord. You can fine-tune or roll over unused funds anytime.',
                            style: PlanSoft.text(
                              context,
                              12,
                              FontWeight.w500,
                              PlanSoft.slate(context),
                              height: 1.4,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _MintChip extends StatelessWidget {
  const _MintChip({required this.label, required this.onTap});

  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: PlanSoft.mint(context),
      borderRadius: BorderRadius.circular(999),
      child: InkWell(
        borderRadius: BorderRadius.circular(999),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Text(
            label,
            style: PlanSoft.text(
              context,
              12,
              FontWeight.w700,
              PlanSoft.emeraldDeep(context),
            ),
          ),
        ),
      ),
    );
  }
}

class _StepTwo extends ConsumerWidget {
  const _StepTwo({
    required this.purpose,
    required this.income,
    required this.total,
    required this.over,
    required this.showOver,
    required this.allocs,
    required this.amountCtrls,
    required this.rolloverMap,
    required this.month,
    required this.purposeName,
    required this.shadow,
    required this.money,
    required this.onLimit,
  });

  final String purpose;
  final double income;
  final double total;
  final bool over;
  final bool showOver;
  final List<PlanAllocation> allocs;
  final Map<String, TextEditingController> amountCtrls;
  final Map<String, bool> rolloverMap;
  final String month;
  final String? purposeName;
  final List<BoxShadow>? shadow;
  final String Function(num value) money;
  final void Function(String categoryId, double amount) onLimit;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final pct = income <= 0 ? 0 : ((total / income) * 100).round();
    final buffer = income - total;
    final bar = income <= 0 ? 0.0 : (total / income).clamp(0.0, 1.0);
    final accent = over ? PlanSoft.overBar(context) : PlanSoft.emerald;
    final pillColor =
        over ? PlanSoft.slate(context) : PlanSoft.emeraldDeep(context);
    final pillFill = over ? PlanSoft.slate100(context) : PlanSoft.mint(context);

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
      children: [
        _PurposeChip(purpose: purpose),
        const SizedBox(height: 14),
        Text(
          'Set your spending limits',
          style: PlanSoft.text(
            context,
            22,
            FontWeight.w800,
            PlanSoft.ink(context),
          ),
        ),
        const SizedBox(height: 6),
        Text(
          'Allocate limits across your key purposes and categories. You can adjust anytime.',
          style: PlanSoft.text(
            context,
            12,
            FontWeight.w500,
            PlanSoft.slate(context),
            height: 1.4,
          ),
        ),
        const SizedBox(height: 16),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: PlanSoft.card(context),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: PlanSoft.border(context)),
            boxShadow: shadow,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'TOTAL PLANNED',
                style: PlanSoft.text(
                  context,
                  11,
                  FontWeight.w700,
                  PlanSoft.muted(context),
                  letterSpacing: 0.6,
                ),
              ),
              const SizedBox(height: 4),
              FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.baseline,
                  textBaseline: TextBaseline.alphabetic,
                  children: [
                    Text(
                      money(total),
                      style: PlanSoft.text(
                        context,
                        24,
                        FontWeight.w800,
                        PlanSoft.ink(context),
                      ),
                    ),
                    Text(
                      ' of ${money(income)}',
                      style: PlanSoft.text(
                        context,
                        13,
                        FontWeight.w600,
                        PlanSoft.slate(context),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 6,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: pillFill,
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      '$pct% allocated',
                      style: PlanSoft.text(
                        context,
                        12,
                        FontWeight.w700,
                        pillColor,
                      ),
                    ),
                  ),
                  Text(
                    'Expected: ${money(income)}',
                    style: PlanSoft.text(
                      context,
                      12,
                      FontWeight.w600,
                      PlanSoft.slate(context),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(99),
                child: LinearProgressIndicator(
                  value: bar,
                  minHeight: 8,
                  backgroundColor: PlanSoft.track(context),
                  color: accent,
                ),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      'Unallocated Buffer',
                      style: PlanSoft.text(
                        context,
                        12,
                        FontWeight.w600,
                        PlanSoft.slate(context),
                      ),
                    ),
                  ),
                  Text(
                    over
                        ? '${money(total - income)} over'
                        : '${money(buffer.clamp(0, double.infinity))} remaining',
                    style: PlanSoft.text(
                      context,
                      12,
                      FontWeight.w700,
                      over
                          ? PlanSoft.slate(context)
                          : PlanSoft.emeraldDeep(context),
                    ),
                  ),
                ],
              ),
              if (showOver) ...[
                const SizedBox(height: 8),
                Text(
                  'Total planned (${money(total)}) exceeds expected income (${money(income)}). Save is blocked until allocations fit income.',
                  style: PlanSoft.text(
                    context,
                    12,
                    FontWeight.w600,
                    PlanSoft.slate(context),
                    height: 1.35,
                  ),
                ),
              ],
            ],
          ),
        ),
        const SizedBox(height: 14),
        for (final allocation in allocs) ...[
          _AllocationRow(
            allocation: allocation,
            controller: amountCtrls[allocation.id]!,
            rollover: rolloverMap[allocation.id] ?? false,
            month: month,
            purposeName: purposeName,
            onChanged: (amount) => onLimit(allocation.category, amount),
          ),
          const SizedBox(height: 10),
        ],
      ],
    );
  }
}

class _PurposeChip extends StatelessWidget {
  const _PurposeChip({required this.purpose});

  final String purpose;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: PlanSoft.mint(context),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: const BoxDecoration(
              color: PlanSoft.emerald,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 6),
          Flexible(
            child: Text(
              '$purpose Purpose Plan',
              style: PlanSoft.text(
                context,
                12,
                FontWeight.w600,
                PlanSoft.ink(context),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _AllocationRow extends ConsumerWidget {
  const _AllocationRow({
    required this.allocation,
    required this.controller,
    required this.rollover,
    required this.month,
    required this.purposeName,
    required this.onChanged,
  });

  final PlanAllocation allocation;
  final TextEditingController controller;
  final bool rollover;
  final String month;
  final String? purposeName;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final accent = _wizardCategoryColor(allocation.category);
    final icon = CategoryIcon.resolve(allocation.category);
    final rolled =
        rollover
            ? ref
                .read(planProvider.notifier)
                .rolloverHeadroomForCategory(
                  month: month,
                  category: allocation.category,
                  purposeName: purposeName,
                )
            : 0.0;
    final subtitle =
        MonthlyPlan.isOutingLimit(allocation.category)
            ? 'Outing limit'
            : rolled > 0
            ? '+₹${rolled.round()} unspent from last month'
            : 'Monthly limit';

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: PlanSoft.card(context),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: PlanSoft.border(context)),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: accent.withValues(alpha: 0.14),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon.icon, color: accent, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  allocation.category,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: PlanSoft.text(
                    context,
                    14,
                    FontWeight.w700,
                    PlanSoft.ink(context),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: PlanSoft.text(
                    context,
                    11,
                    FontWeight.w500,
                    PlanSoft.slate(context),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          SizedBox(
            width: 108,
            child: TextField(
              controller: controller,
              keyboardType: TextInputType.number,
              textAlign: TextAlign.right,
              style: PlanSoft.text(
                context,
                14,
                FontWeight.w700,
                PlanSoft.ink(context),
              ),
              decoration: InputDecoration(
                prefixText: '₹',
                prefixStyle: PlanSoft.text(
                  context,
                  14,
                  FontWeight.w700,
                  PlanSoft.slate(context),
                ),
                isDense: true,
                filled: true,
                fillColor:
                    PlanSoft.dark(context)
                        ? PlanSoft.slate100(context)
                        : const Color(0xFFF8FAFC),
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 10,
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(
                    color:
                        PlanSoft.dark(context)
                            ? const Color(0xFF3F3F46)
                            : const Color(0xFFE2E8F0),
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(
                    color:
                        PlanSoft.dark(context)
                            ? const Color(0xFF3F3F46)
                            : const Color(0xFFE2E8F0),
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(
                    color: PlanSoft.emerald,
                    width: 1.5,
                  ),
                ),
              ),
              onChanged: (text) {
                final amount =
                    double.tryParse(text.replaceAll(',', '').trim()) ?? 0;
                onChanged(amount);
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _StepThree extends StatelessWidget {
  const _StepThree({
    required this.purpose,
    required this.monthWord,
    required this.income,
    required this.total,
    required this.buffer,
    required this.over,
    required this.allocs,
    required this.limits,
    required this.rolloverMap,
    required this.month,
    required this.purposeName,
    required this.shadow,
    required this.money,
    required this.onEditLimits,
  });

  final String purpose;
  final String monthWord;
  final double income;
  final double total;
  final double buffer;
  final bool over;
  final List<PlanAllocation> allocs;
  final Map<String, double> limits;
  final Map<String, bool> rolloverMap;
  final String month;
  final String? purposeName;
  final List<BoxShadow>? shadow;
  final String Function(num value) money;
  final VoidCallback onEditLimits;

  @override
  Widget build(BuildContext context) {
    final pct = income <= 0 ? 0 : ((total / income) * 100).round();
    final bar = income <= 0 ? 0.0 : (total / income).clamp(0.0, 1.0);
    final accent = over ? PlanSoft.overBar(context) : PlanSoft.emerald;
    final rows = [
      for (final allocation in allocs)
        if ((limits[allocation.category] ?? 0) > 0) allocation,
    ];

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
      children: [
        _PurposeChip(purpose: purpose),
        const SizedBox(height: 14),
        Text(
          'Review $monthWord plan',
          style: PlanSoft.text(
            context,
            22,
            FontWeight.w800,
            PlanSoft.ink(context),
          ),
        ),
        const SizedBox(height: 6),
        Text(
          'Check income, limits, and the buffer before saving.',
          style: PlanSoft.text(
            context,
            12,
            FontWeight.w500,
            PlanSoft.slate(context),
            height: 1.4,
          ),
        ),
        const SizedBox(height: 16),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: PlanSoft.card(context),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: PlanSoft.border(context)),
            boxShadow: shadow,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Expected income',
                style: PlanSoft.text(
                  context,
                  13,
                  FontWeight.w600,
                  PlanSoft.slate(context),
                ),
              ),
              const SizedBox(height: 4),
              Text(
                money(income),
                style: PlanSoft.text(
                  context,
                  28,
                  FontWeight.w800,
                  PlanSoft.ink(context),
                ),
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: _SummaryCell(
                      label: 'Allocated',
                      value: money(total),
                      valueColor: PlanSoft.ink(context),
                    ),
                  ),
                  Container(
                    width: 1,
                    height: 36,
                    color: PlanSoft.border(context),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(left: 12),
                      child: _SummaryCell(
                        label: 'Buffer',
                        value: money(buffer),
                        valueColor:
                            over
                                ? PlanSoft.slate(context)
                                : PlanSoft.emeraldDeep(context),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              ClipRRect(
                borderRadius: BorderRadius.circular(99),
                child: LinearProgressIndicator(
                  value: bar,
                  minHeight: 8,
                  backgroundColor: PlanSoft.track(context),
                  color: accent,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                '$pct% allocated',
                style: PlanSoft.text(
                  context,
                  12,
                  FontWeight.w700,
                  over
                      ? PlanSoft.slate(context)
                      : PlanSoft.emeraldDeep(context),
                ),
              ),
            ],
          ),
        ),
        if (rows.isNotEmpty) ...[
          const SizedBox(height: 18),
          for (final allocation in rows) ...[
            _ReviewLimitRow(
              allocation: allocation,
              amount: limits[allocation.category] ?? 0,
              rollover: rolloverMap[allocation.id] ?? false,
              month: month,
              purposeName: purposeName,
              money: money,
              onTap: onEditLimits,
            ),
            const SizedBox(height: 10),
          ],
        ],
        const SizedBox(height: 8),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 22,
              height: 22,
              decoration: BoxDecoration(
                color: PlanSoft.mint(context),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                LucideIcons.check,
                size: 12,
                color: PlanSoft.emerald,
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                'You can edit limits after the plan is created.',
                style: PlanSoft.text(
                  context,
                  12,
                  FontWeight.w500,
                  PlanSoft.slate(context),
                  height: 1.4,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _SummaryCell extends StatelessWidget {
  const _SummaryCell({
    required this.label,
    required this.value,
    required this.valueColor,
  });

  final String label;
  final String value;
  final Color valueColor;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: PlanSoft.text(
            context,
            12,
            FontWeight.w600,
            PlanSoft.slate(context),
          ),
        ),
        const SizedBox(height: 2),
        Text(
          value,
          style: PlanSoft.text(context, 14, FontWeight.w800, valueColor),
        ),
      ],
    );
  }
}

class _ReviewLimitRow extends ConsumerWidget {
  const _ReviewLimitRow({
    required this.allocation,
    required this.amount,
    required this.rollover,
    required this.month,
    required this.purposeName,
    required this.money,
    required this.onTap,
  });

  final PlanAllocation allocation;
  final double amount;
  final bool rollover;
  final String month;
  final String? purposeName;
  final String Function(num value) money;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final accent = _wizardCategoryColor(allocation.category);
    final icon = CategoryIcon.resolve(allocation.category);
    final rolled =
        rollover
            ? ref
                .read(planProvider.notifier)
                .rolloverHeadroomForCategory(
                  month: month,
                  category: allocation.category,
                  purposeName: purposeName,
                )
            : 0.0;
    final subtitle =
        rolled > 0
            ? '+₹${rolled.round()} unspent from last month'
            : 'Monthly limit';

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Ink(
          decoration: BoxDecoration(
            color: PlanSoft.card(context),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: PlanSoft.border(context)),
          ),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: accent.withValues(alpha: 0.14),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(icon.icon, color: accent, size: 18),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        allocation.category,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: PlanSoft.text(
                          context,
                          14,
                          FontWeight.w700,
                          PlanSoft.ink(context),
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        subtitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: PlanSoft.text(
                          context,
                          11,
                          FontWeight.w500,
                          PlanSoft.slate(context),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  money(amount),
                  style: PlanSoft.text(
                    context,
                    14,
                    FontWeight.w700,
                    PlanSoft.ink(context),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

Color _wizardCategoryColor(String name) {
  final n = name.toLowerCase();
  if (n.contains('housing')) return const Color(0xFF6366F1);
  if (n.contains('transport') ||
      n.contains('transit') ||
      n.contains('cab') ||
      n.contains('fuel')) {
    return const Color(0xFF06B6D4);
  }
  return PlanSoft.category(name);
}
