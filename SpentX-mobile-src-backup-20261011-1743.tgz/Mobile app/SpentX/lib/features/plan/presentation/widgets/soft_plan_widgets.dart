import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../core/theme/soft_palette.dart';

/// Soft Soft plan surfaces. Light tokens follow the Plan spec.
/// Dark mode keeps [SoftPalette] dark surfaces.
abstract final class PlanSoft {
  static bool dark(BuildContext context) =>
      Theme.of(context).brightness == Brightness.dark;

  static const emerald = Color(0xFF10B981);
  static const rose = Color(0xFFFB7185);
  static const amber = Color(0xFFF59E0B);
  static const sky = Color(0xFF38BDF8);
  static const teal = Color(0xFF14B8A6);
  static const violet = Color(0xFF8B5CF6);

  static const _shadow = [
    BoxShadow(
      color: Color.fromRGBO(15, 23, 42, 0.04),
      offset: Offset(0, 10),
      blurRadius: 30,
      spreadRadius: -4,
    ),
  ];

  static Color canvas(BuildContext context) =>
      dark(context) ? SoftPalette.darkBg : const Color(0xFFF8F9FC);

  static Color card(BuildContext context) =>
      dark(context) ? SoftPalette.darkCard : const Color(0xFFFFFFFF);

  static Color border(BuildContext context) =>
      dark(context) ? SoftPalette.darkBorder : const Color(0xFFF1F5F9);

  static Color ink(BuildContext context) =>
      dark(context) ? SoftPalette.darkInk : const Color(0xFF020617);

  static Color slate(BuildContext context) =>
      dark(context) ? SoftPalette.darkMuted : const Color(0xFF64748B);

  static Color muted(BuildContext context) =>
      dark(context) ? SoftPalette.darkFaint : const Color(0xFF94A3B8);

  static Color mint(BuildContext context) =>
      dark(context) ? SoftPalette.darkEmeraldSoft : const Color(0xFFECFDF5);

  static Color slate100(BuildContext context) =>
      dark(context) ? SoftPalette.darkBorder : const Color(0xFFF1F5F9);

  static Color track(BuildContext context) => slate100(context);

  static Color emeraldDeep(BuildContext context) =>
      dark(context) ? SoftPalette.darkEmerald : const Color(0xFF059669);

  /// Over-target bar. Light uses slate-800. Dark stays light so it stays visible.
  static Color overBar(BuildContext context) =>
      dark(context) ? const Color(0xFFE2E8F0) : const Color(0xFF1E293B);

  static Color backFill(BuildContext context) =>
      dark(context) ? SoftPalette.darkCard : const Color(0xFFFFFFFF);

  static List<BoxShadow>? shadow(BuildContext context) =>
      dark(context) ? null : _shadow;

  static TextStyle text(
    BuildContext context,
    double size,
    FontWeight weight,
    Color color, {
    double? letterSpacing,
    double? height,
  }) {
    return GoogleFonts.plusJakartaSans(
      fontSize: size,
      fontWeight: weight,
      color: color,
      letterSpacing: letterSpacing,
      height: height,
    );
  }

  static BoxDecoration heroBox(BuildContext context) => BoxDecoration(
    color: card(context),
    borderRadius: BorderRadius.circular(24),
    border: Border.all(color: border(context)),
    boxShadow: shadow(context),
  );

  static BoxDecoration rowBox(BuildContext context) => BoxDecoration(
    color: card(context),
    borderRadius: BorderRadius.circular(16),
    border: Border.all(color: border(context)),
    boxShadow: shadow(context),
  );

  static BoxDecoration emptyBox(BuildContext context) => BoxDecoration(
    color: card(context),
    borderRadius: BorderRadius.circular(28),
    border: Border.all(color: border(context)),
    boxShadow: shadow(context),
  );

  /// One accent per category. Distribution, icon tile, bar, and pill share it.
  static Color category(String name) {
    final n = name.toLowerCase();
    if (n.contains('food') ||
        n.contains('dining') ||
        n.contains('restaurant') ||
        n.contains('grocer') ||
        n.contains('coffee')) {
      return amber;
    }
    if (n.contains('shop')) return rose;
    if (n.contains('transport') ||
        n.contains('transit') ||
        n.contains('fuel') ||
        n.contains('cab') ||
        n.contains('metro')) {
      return sky;
    }
    if (n.contains('bill') ||
        n.contains('util') ||
        n.contains('recharge') ||
        n.contains('rent') ||
        n.contains('emi')) {
      return emerald;
    }
    if (n.contains('health')) return teal;
    if (n.contains('entertain') ||
        n.contains('movie') ||
        n.contains('game') ||
        n.contains('leisure')) {
      return violet;
    }
    const palette = <Color>[amber, rose, sky, emerald, teal, violet];
    var hash = 0;
    for (final unit in n.codeUnits) {
      hash = (hash * 31 + unit) & 0x7fffffff;
    }
    return palette[hash % palette.length];
  }
}

/// Ink pill toast. Lock, edit, and delete messages stay on this surface.
void showPlanToast(
  BuildContext context,
  String message, {
  Duration duration = const Duration(seconds: 2),
}) {
  final dark = Theme.of(context).brightness == Brightness.dark;
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(
        message,
        style: GoogleFonts.plusJakartaSans(
          color: dark ? const Color(0xFF020617) : Colors.white,
          fontSize: 13,
          fontWeight: FontWeight.w600,
        ),
      ),
      backgroundColor: dark ? Colors.white : const Color(0xFF020617),
      behavior: SnackBarBehavior.floating,
      elevation: 0,
      duration: duration,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(999)),
      ),
    ),
  );
}
