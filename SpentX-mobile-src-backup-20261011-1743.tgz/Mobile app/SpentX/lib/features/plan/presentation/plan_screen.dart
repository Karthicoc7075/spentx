import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

import '../../../core/providers/category_provider.dart';
import '../../../core/providers/outing_provider.dart';
import '../../../core/providers/transaction_provider.dart' as model;
import '../../../core/utils/budget_spend.dart';
import '../data/plan_provider.dart';
import '../../../core/providers/user_state_provider.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../core/theme/spentx_tokens.dart';
import '../../../core/widgets/category_icon.dart';
import '../../../core/widgets/premium_bottom_sheet.dart';
import '../../../core/widgets/reference_ui.dart';
import 'widgets/create_plan_wizard.dart';
import 'widgets/soft_plan_widgets.dart';
import '../../transactions/presentation/add_transaction_sheet.dart';

/// SpentX Plan Shared Chrome v1.
class PlanScreen extends ConsumerStatefulWidget {
  const PlanScreen({super.key});

  @override
  ConsumerState<PlanScreen> createState() => _PlanScreenState();
}

class _PlanScreenState extends ConsumerState<PlanScreen> {
  late String _month;
  String _purpose = 'Personal';

  @override
  void initState() {
    super.initState();
    _month = currentPlanMonth();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final userPurposes = ref.read(userStateProvider).purposeTypes;
      final Set<String> allPurposes = {'Personal', 'Family', ...userPurposes};
      final ordered = [
        if (allPurposes.contains('Personal')) 'Personal',
        if (allPurposes.contains('Family')) 'Family',
        ...allPurposes.where((p) => p != 'Personal' && p != 'Family'),
      ];
      if (ordered.isNotEmpty && mounted) {
        setState(() => _purpose = ordered.first);
      }
    });
  }

  void _openEditPlan(MonthlyPlan plan) {
    PremiumBottomSheet.show(
      context: context,
      child: _EditPlanSheet(
        plan: plan,
        onSave: (updated) async {
          await ref.read(planProvider.notifier).savePlan(updated);
          if (mounted) setState(() {});
        },
      ),
    );
  }

  void _onChromeEdit() {
    final plan = _savedPlan();
    if (plan == null) {
      showPlanToast(context, 'Create a plan before editing limits.');
      return;
    }
    _openEditPlan(plan);
  }

  Future<void> _onChromeDelete() async {
    final plan = _savedPlan();
    if (plan == null) {
      showPlanToast(context, 'No plan to delete for this month.');
      return;
    }
    final confirmed = await showDialog<bool>(
      context: context,
      builder:
          (ctx) => AlertDialog(
            backgroundColor: ctx.softCard,
            surfaceTintColor: Colors.transparent,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24),
            ),
            title: Text(
              'Delete this plan?',
              style: TextStyle(color: ctx.softInk, fontWeight: FontWeight.w700),
            ),
            content: Text(
              'Delete the ${formatPlanMonth(plan.month)} $_purpose plan?',
              style: TextStyle(color: ctx.softMuted),
            ),
            actions: [
              TextButton(
                style: TextButton.styleFrom(foregroundColor: ctx.softMuted),
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('Cancel'),
              ),
              TextButton(
                style: TextButton.styleFrom(foregroundColor: ctx.softEmerald),
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('Delete'),
              ),
            ],
          ),
    );
    if (confirmed != true || !mounted) return;
    await ref.read(planProvider.notifier).deletePlan(plan.id);
    if (mounted) setState(() {});
  }

  List<String> _orderedPurposes() {
    final userPurposes = ref.read(userStateProvider).purposeTypes;
    final allPurposes = {'Personal', 'Family', ...userPurposes};
    return [
      if (allPurposes.contains('Personal')) 'Personal',
      if (allPurposes.contains('Family')) 'Family',
      ...allPurposes.where((p) => p != 'Personal' && p != 'Family'),
    ];
  }

  String _purposeMeta(MonthlyPlan? plan) {
    if (plan == null) return 'No plan';
    final count = plan.allocations.where((a) => a.plannedAmount > 0).length;
    final noun = count == 1 ? 'category' : 'categories';
    return '$count $noun · ${_money(plan.totalPlanned)}';
  }

  /// Null when this month has no planned total, so the pace pill stays hidden.
  bool? _healthyPace(double spent, double planned) {
    if (planned <= 0) return null;
    if (_month == currentPlanMonth()) {
      final now = DateTime.now();
      final days = DateTime(now.year, now.month + 1, 0).day;
      final allowed = planned * (now.day / days);
      return spent <= allowed + 0.5;
    }
    return spent <= planned + 0.5;
  }

  String _pctLabel(double value) {
    if (value.isNaN || value.isInfinite) return '0';
    final rounded = (value * 10).round() / 10;
    if ((rounded - rounded.roundToDouble()).abs() < 0.001) {
      return rounded.round().toString();
    }
    return rounded.toStringAsFixed(1);
  }

  void _shiftMonth(int delta) {
    final next = shiftPlanMonth(_month, delta);
    if (delta > 0 && !isPlanMonthCreatable(next)) {
      showPlanToast(context, 'Plans can be created up to next month.');
      return;
    }
    setState(() => _month = next);
  }

  IconData _purposeIcon(String name) {
    final n = name.toLowerCase();
    if (n.contains('family')) return LucideIcons.users;
    if (n.contains('work') || n.contains('freelance')) {
      return LucideIcons.briefcase;
    }
    return LucideIcons.user;
  }

  void _openPurposeSheet() {
    final notifier = ref.read(planProvider.notifier);
    final purposes = _orderedPurposes();
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        final bottom = MediaQuery.of(ctx).padding.bottom;
        return Container(
          decoration: BoxDecoration(
            color: PlanSoft.card(ctx),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
          ),
          child: ListView(
            shrinkWrap: true,
            padding: EdgeInsets.fromLTRB(16, 10, 16, 16 + bottom),
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  margin: const EdgeInsets.only(bottom: 16),
                  decoration: BoxDecoration(
                    color: PlanSoft.slate100(ctx),
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
              ),
              Text(
                'Select Ledger Purpose',
                style: PlanSoft.text(
                  ctx,
                  18,
                  FontWeight.w800,
                  PlanSoft.ink(ctx),
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'Isolate limits and categories per spending context',
                style: PlanSoft.text(
                  ctx,
                  12,
                  FontWeight.w500,
                  PlanSoft.slate(ctx),
                ),
              ),
              const SizedBox(height: 16),
              for (final name in purposes) ...[
                _PurposeOption(
                  name: name,
                  meta: _purposeMeta(
                    notifier.planFor(month: _month, purposeName: name),
                  ),
                  icon: _purposeIcon(name),
                  selected: name.toLowerCase() == _purpose.toLowerCase(),
                  onTap: () {
                    Navigator.pop(ctx);
                    if (!mounted) return;
                    setState(() => _purpose = name);
                  },
                ),
                const SizedBox(height: 8),
              ],
            ],
          ),
        );
      },
    );
  }

  MonthlyPlan? _savedPlan() {
    return ref
        .read(planProvider.notifier)
        .planFor(month: _month, purposeName: _purpose);
  }

  bool _showFilled(MonthlyPlan? plan) => plan != null;

  void _openHistory() {
    final plans = ref.read(planProvider.notifier).historyForPurpose(_purpose);
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return _PlanHistorySheet(
          purpose: _purpose,
          monthLabel: formatPlanMonth(_month),
          plans: plans,
          openMonth: _month,
          onApply: (plan) async {
            Navigator.pop(ctx);
            await _setHistoryPlan(plan);
          },
        );
      },
    );
  }

  Future<void> _setHistoryPlan(MonthlyPlan source) async {
    if (source.month == _month) return;
    final existing = _savedPlan();
    if (existing != null && mounted) {
      final confirmed = await showDialog<bool>(
        context: context,
        builder:
            (ctx) => AlertDialog(
              backgroundColor: ctx.softCard,
              surfaceTintColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(24),
              ),
              title: Text(
                'Apply this plan?',
                style: TextStyle(
                  color: ctx.softInk,
                  fontWeight: FontWeight.w700,
                ),
              ),
              content: Text(
                'Copy the ${formatPlanMonth(source.month)} limits onto ${formatPlanMonth(_month)} $_purpose?',
                style: TextStyle(color: ctx.softMuted),
              ),
              actions: [
                TextButton(
                  style: TextButton.styleFrom(foregroundColor: ctx.softMuted),
                  onPressed: () => Navigator.pop(ctx, false),
                  child: const Text('Cancel'),
                ),
                TextButton(
                  style: TextButton.styleFrom(foregroundColor: ctx.softEmerald),
                  onPressed: () => Navigator.pop(ctx, true),
                  child: const Text('Apply'),
                ),
              ],
            ),
      );
      if (confirmed != true || !mounted) return;
    }
    await _copyPreviousPlan(source);
    if (!mounted) return;
    showPlanToast(
      context,
      'Applied ${formatPlanMonth(source.month)} to ${formatPlanMonth(_month)}.',
    );
  }

  void _createPlan() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder:
            (_) => CreatePlanWizard(
              month: _month,
              purposeId: _purpose,
              onSave:
                  (updated) =>
                      ref.read(planProvider.notifier).savePlan(updated),
            ),
      ),
    );
  }

  Future<void> _copyPreviousPlan(MonthlyPlan previous) async {
    final existing = _savedPlan();
    final stamp = DateTime.now().microsecondsSinceEpoch;
    final limits = [
      for (var i = 0; i < previous.allocations.length; i++)
        if (previous.allocations[i].category != MonthlyPlan.bufferMetaId)
          PlanAllocation(
            id: 'alloc-$stamp-$i-${previous.allocations[i].category}',
            category: previous.allocations[i].category,
            plannedAmount: previous.allocations[i].plannedAmount,
            color: previous.allocations[i].color,
            rollover: previous.allocations[i].rollover,
          ),
    ];
    final income = previous.expectedIncome;
    final planned = limits.fold<double>(0, (sum, a) => sum + a.plannedAmount);
    final now = DateTime.now().toUtc().toIso8601String();
    final copy = MonthlyPlan(
      id: existing?.id ?? const Uuid().v4(),
      month: _month,
      purposeName: _purpose,
      title: existing?.title ?? '${formatPlanMonth(_month)} Plan',
      expectedIncome: income,
      allocations: limits,
      remoteId: existing?.remoteId,
      dailySafeLimit: existing?.dailySafeLimit,
      savingsTarget: existing?.savingsTarget,
      isBudgetLocked: false,
      bufferAmount: income - planned,
      bufferChoice: 'buffer',
      createdAt: existing?.createdAt ?? now,
      updatedAt: now,
    );
    await ref.read(planProvider.notifier).savePlan(copy);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    ref.watch(planProvider);
    final txs = ref.watch(model.transactionProvider);
    final outings = ref.watch(outingProvider);
    final saved = _savedPlan();
    final showFilled = _showFilled(saved);
    final envelopes = [
      if (saved != null)
        for (final allocation in saved.allocations)
          if (allocation.plannedAmount > 0 &&
              !MonthlyPlan.isOutingLimit(allocation.category))
            allocation,
    ];
    final outingLimit =
        saved == null
            ? 0.0
            : saved.allocations
                .where((a) => MonthlyPlan.isOutingLimit(a.category))
                .fold<double>(0, (sum, a) => sum + a.plannedAmount);
    final outingLines = _outingLines(outings);
    final spendByCategory = _purposeSpend(txs, outingLines);
    final outingSpent = _purposeOutingSpend(txs, outingLines);
    final spent =
        spendByCategory.values.fold<double>(0, (sum, value) => sum + value) +
        outingSpent;
    final planned = saved?.totalPlanned ?? 0;
    final remaining = (planned - spent).clamp(0.0, double.infinity);
    final progress = planned <= 0 ? 0.0 : (spent / planned).clamp(0.0, 1.0);
    final usedPct = planned <= 0 ? 0.0 : (spent / planned) * 100;
    final pastTarget = planned > 0 && spent > planned;
    final healthy = _healthyPace(spent, planned);
    final segments = <_DistSeg>[
      for (final allocation in envelopes)
        _DistSeg(
          name: allocation.category,
          amount: allocation.plannedAmount,
          color: PlanSoft.category(allocation.category),
        ),
      if (outingLimit > 0)
        _DistSeg(
          name: MonthlyPlan.outingLimitCategory,
          amount: outingLimit,
          color: PlanSoft.category(MonthlyPlan.outingLimitCategory),
        ),
    ];

    final categoryCount = envelopes.length + (outingLimit > 0 ? 1 : 0);
    final categoryLabel =
        categoryCount == 1 ? '1 category' : '$categoryCount categories';
    return Scaffold(
      backgroundColor: PlanSoft.canvas(context),
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            _PlanHeader(
              hasPlan: saved != null,
              onBack: () {
                if (context.canPop()) {
                  context.pop();
                } else {
                  context.go('/home');
                }
              },
              onHistory: _openHistory,
              onEdit: _onChromeEdit,
              onDelete: _onChromeDelete,
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              child: _MonthBar(
                label: formatPlanMonth(_month),
                onPrevious: () => _shiftMonth(-1),
                onNext: () => _shiftMonth(1),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
              child: _PurposeRow(
                purpose: _purpose,
                active: saved != null,
                subtitle:
                    saved == null
                        ? 'No plan this month'
                        : '$categoryLabel · ${_money(planned)}',
                onChange: _openPurposeSheet,
              ),
            ),
            Expanded(
              child: ListView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
                children:
                    showFilled && saved != null
                        ? _filledChildren(
                          saved: saved,
                          spent: spent,
                          planned: planned,
                          remaining: remaining,
                          progress: progress,
                          usedPct: usedPct,
                          pastTarget: pastTarget,
                          healthy: healthy,
                          segments: segments,
                          envelopes: envelopes,
                          spendByCategory: spendByCategory,
                          outingSpent: outingSpent,
                          outingLimit: outingLimit,
                        )
                        : [
                          _EmptyPlanCard(
                            monthLabel: formatPlanMonth(_month),
                            onCreate: _createPlan,
                          ),
                        ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: SxReferenceBottomBar(
        onAdd: () => AddTransactionSheet.show(context),
        active: 'plan',
        planMode: true,
      ),
    );
  }

  List<Widget> _filledChildren({
    required MonthlyPlan saved,
    required double spent,
    required double planned,
    required double remaining,
    required double progress,
    required double usedPct,
    required bool pastTarget,
    required bool? healthy,
    required List<_DistSeg> segments,
    required List<PlanAllocation> envelopes,
    required Map<String, double> spendByCategory,
    required double outingSpent,
    required double outingLimit,
  }) {
    final plannedKeys = {
      for (final allocation in envelopes)
        allocation.category.trim().toLowerCase(),
    };
    final outingTotal = outingSpent + (spendByCategory['outings'] ?? 0);
    final unplanned = [
      for (final entry in spendByCategory.entries)
        if (entry.value > 0 &&
            entry.key != 'outings' &&
            !plannedKeys.contains(entry.key))
          entry,
    ]..sort((a, b) => b.value.compareTo(a.value));
    return [
      Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: PlanSoft.heroBox(context),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    formatPlanMonth(_month),
                    style: PlanSoft.text(
                      context,
                      13,
                      FontWeight.w700,
                      PlanSoft.ink(context),
                    ),
                  ),
                ),
                if (healthy != null) _PacePill(healthy: healthy),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              getPlanDisplayTitle(saved),
              style: PlanSoft.text(
                context,
                18,
                FontWeight.w800,
                PlanSoft.ink(context),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'RECORDED OUTFLOW',
                        style: PlanSoft.text(
                          context,
                          11,
                          FontWeight.w700,
                          PlanSoft.muted(context),
                          letterSpacing: 0.6,
                        ),
                      ),
                      const SizedBox(height: 4),
                      FittedBox(
                        fit: BoxFit.scaleDown,
                        alignment: Alignment.centerLeft,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.baseline,
                          textBaseline: TextBaseline.alphabetic,
                          children: [
                            Text(
                              _money(spent),
                              style: PlanSoft.text(
                                context,
                                32,
                                FontWeight.w800,
                                PlanSoft.ink(context),
                                height: 1.05,
                              ),
                            ),
                            Text(
                              ' of ${_money(planned)}',
                              style: PlanSoft.text(
                                context,
                                13,
                                FontWeight.w600,
                                PlanSoft.slate(context),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Padding(
                  padding: const EdgeInsets.only(top: 18),
                  child: Text(
                    pastTarget
                        ? '${_money(spent - planned)} over'
                        : '${_money(remaining)} safe',
                    style: PlanSoft.text(
                      context,
                      13,
                      FontWeight.w700,
                      pastTarget
                          ? PlanSoft.slate(context)
                          : PlanSoft.emeraldDeep(context),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            ClipRRect(
              borderRadius: BorderRadius.circular(99),
              child: LinearProgressIndicator(
                value: progress,
                minHeight: 8,
                backgroundColor: PlanSoft.track(context),
                color: PlanSoft.emerald,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: Text(
                    '${_pctLabel(usedPct)}% used',
                    style: PlanSoft.text(
                      context,
                      11,
                      FontWeight.w600,
                      PlanSoft.slate(context),
                    ),
                  ),
                ),
                Text(
                  '${_money(remaining)} left',
                  style: PlanSoft.text(
                    context,
                    11,
                    FontWeight.w600,
                    PlanSoft.slate(context),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      const SizedBox(height: 16),
      Text(
        'CATEGORY BREAKDOWN',
        style: PlanSoft.text(
          context,
          11,
          FontWeight.w700,
          PlanSoft.muted(context),
          letterSpacing: 0.6,
        ),
      ),
      if (segments.isNotEmpty) ...[
        const SizedBox(height: 10),
        _LedgerDistributionBar(segments: segments),
        const SizedBox(height: 10),
        Wrap(
          spacing: 12,
          runSpacing: 6,
          children: [
            for (final seg in segments)
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 6,
                    height: 6,
                    decoration: BoxDecoration(
                      color: seg.color,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    seg.name,
                    style: PlanSoft.text(
                      context,
                      11,
                      FontWeight.w600,
                      PlanSoft.slate(context),
                    ),
                  ),
                ],
              ),
          ],
        ),
      ],
      const SizedBox(height: 12),
      for (final allocation in envelopes)
        Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: _envelopeCard(
            category: allocation.category,
            categorySpent:
                spendByCategory[allocation.category.trim().toLowerCase()] ?? 0,
            limit: allocation.plannedAmount,
            inPlan: true,
          ),
        ),
      for (final entry in unplanned)
        Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: _envelopeCard(
            category: _categoryLabel(entry.key),
            categorySpent: entry.value,
            limit: 0,
            inPlan: false,
          ),
        ),
      if (outingLimit > 0 || outingTotal > 0)
        Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: _envelopeCard(
            category: MonthlyPlan.outingLimitCategory,
            categorySpent: outingTotal,
            limit: outingLimit,
            inPlan: outingLimit > 0,
          ),
        ),
    ];
  }

  List<PurposeOutingSpend> _outingLines(List<Outing> outings) => [
    for (final outing in outings)
      for (final expense in outing.expenses)
        PurposeOutingSpend(
          category: expense.category,
          amount: expense.amount,
          date: expense.date,
          purpose: expense.purpose,
          transactionId: expense.transactionId,
          isCancelled: outing.status == 'cancelled',
        ),
  ];

  Map<String, double> _purposeSpend(
    List<model.Transaction> txs,
    List<PurposeOutingSpend> outings,
  ) {
    return purposeCategorySpendTotals(
      transactions: txs,
      month: _month,
      purposeName: _purpose,
      excludedTransactionIds: {
        for (final line in outings)
          if ((line.transactionId ?? '').trim().isNotEmpty)
            line.transactionId!.trim(),
      },
    );
  }

  double _purposeOutingSpend(
    List<model.Transaction> txs,
    List<PurposeOutingSpend> outings,
  ) {
    return purposeOutingTotal(
      transactions: txs,
      outings: outings,
      month: _month,
      purposeName: _purpose,
    );
  }

  String _categoryLabel(String key) {
    final names = ref.read(categoryProvider).expense;
    for (final name in names) {
      if (name.trim().toLowerCase() == key) return name;
    }
    if (key.isEmpty) return 'Other';
    return key[0].toUpperCase() + key.substring(1);
  }

  Widget _envelopeCard({
    required String category,
    required double categorySpent,
    required double limit,
    required bool inPlan,
  }) {
    final over = inPlan && limit > 0 && categorySpent > limit;
    final rawPct = !inPlan || limit <= 0 ? 0.0 : (categorySpent / limit) * 100;
    final barValue =
        !inPlan
            ? (categorySpent > 0 ? 1.0 : 0.0)
            : (limit <= 0 ? 0.0 : (categorySpent / limit).clamp(0.0, 1.0));
    final accent = PlanSoft.category(category);
    final barColor = !inPlan || over ? PlanSoft.overBar(context) : accent;
    final cat = CategoryIcon.resolve(category);
    final meta =
        !inPlan
            ? 'Not in plan'
            : (over ? 'Past the planned target' : 'Inside the planned target');
    final left =
        !inPlan
            ? _money(categorySpent)
            : over
            ? '${_money(categorySpent - limit)} over'
            : '${_money((limit - categorySpent).clamp(0, double.infinity))} left';
    final limitLabel = inPlan ? 'limit ${_money(limit)}' : 'No limit';
    final badge = inPlan ? '${_pctLabel(rawPct)}% spent' : 'Not in plan';

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: PlanSoft.rowBox(context),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: accent.withValues(alpha: 0.14),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(cat.icon, color: accent, size: 18),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      category,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: PlanSoft.text(
                        context,
                        14,
                        FontWeight.w700,
                        PlanSoft.ink(context),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      meta,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: PlanSoft.text(
                        context,
                        11,
                        FontWeight.w500,
                        PlanSoft.slate(context),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    _money(categorySpent),
                    style: PlanSoft.text(
                      context,
                      13,
                      FontWeight.w700,
                      PlanSoft.ink(context),
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    limitLabel,
                    style: PlanSoft.text(
                      context,
                      11,
                      FontWeight.w500,
                      PlanSoft.muted(context),
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(99),
            child: LinearProgressIndicator(
              value: barValue,
              minHeight: 6,
              backgroundColor: PlanSoft.track(context),
              color: barColor,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: Text(
                  left,
                  style: PlanSoft.text(
                    context,
                    11,
                    FontWeight.w600,
                    PlanSoft.slate(context),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color:
                      inPlan && !over
                          ? accent.withValues(alpha: 0.14)
                          : PlanSoft.slate100(context),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  badge,
                  style: PlanSoft.text(
                    context,
                    11,
                    FontWeight.w700,
                    inPlan && !over ? accent : PlanSoft.slate(context),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _money(num value) => NumberFormat.currency(
    locale: 'en_IN',
    symbol: '₹',
    decimalDigits: 0,
  ).format(value);
}

class _PacePill extends StatelessWidget {
  const _PacePill({required this.healthy});

  final bool healthy;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: healthy ? PlanSoft.mint(context) : PlanSoft.slate100(context),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        healthy ? 'Healthy Pace' : 'Over Pace',
        style: PlanSoft.text(
          context,
          11,
          FontWeight.w700,
          healthy ? PlanSoft.emeraldDeep(context) : PlanSoft.slate(context),
        ),
      ),
    );
  }
}

class _PlanHeader extends StatelessWidget {
  const _PlanHeader({
    required this.hasPlan,
    required this.onBack,
    required this.onHistory,
    required this.onEdit,
    required this.onDelete,
  });

  final bool hasPlan;
  final VoidCallback onBack;
  final VoidCallback onHistory;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      child: Row(
        children: [
          _ChromeCircle(icon: Icons.arrow_back_ios_new_rounded, onTap: onBack),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Plan',
                  style: PlanSoft.text(
                    context,
                    18,
                    FontWeight.w700,
                    PlanSoft.ink(context),
                  ),
                ),
              ],
            ),
          ),
          _ChromeCircle(icon: LucideIcons.history, onTap: onHistory),
          if (hasPlan) ...[
            const SizedBox(width: 8),
            _ChromeCircle(icon: LucideIcons.pencil, onTap: onEdit),
            const SizedBox(width: 8),
            _DeleteCircle(onTap: onDelete),
          ],
        ],
      ),
    );
  }
}

class _ChromeCircle extends StatelessWidget {
  const _ChromeCircle({required this.icon, required this.onTap});

  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: PlanSoft.card(context),
      shape: CircleBorder(side: BorderSide(color: PlanSoft.border(context))),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: 40,
          height: 40,
          child: Icon(icon, size: 16, color: PlanSoft.ink(context)),
        ),
      ),
    );
  }
}

class _DeleteCircle extends StatefulWidget {
  const _DeleteCircle({required this.onTap});

  final VoidCallback onTap;

  @override
  State<_DeleteCircle> createState() => _DeleteCircleState();
}

class _DeleteCircleState extends State<_DeleteCircle> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      onTap: widget.onTap,
      child: Container(
        width: 40,
        height: 40,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: PlanSoft.card(context),
          shape: BoxShape.circle,
          border: Border.all(color: PlanSoft.border(context)),
        ),
        child: Icon(
          LucideIcons.trash2,
          size: 16,
          color: _pressed ? PlanSoft.rose : PlanSoft.ink(context),
        ),
      ),
    );
  }
}

class _MonthBar extends StatelessWidget {
  const _MonthBar({
    required this.label,
    required this.onPrevious,
    required this.onNext,
  });

  final String label;
  final VoidCallback onPrevious;
  final VoidCallback onNext;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 48,
      padding: const EdgeInsets.symmetric(horizontal: 4),
      decoration: BoxDecoration(
        color: PlanSoft.card(context),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: PlanSoft.border(context)),
      ),
      child: Row(
        children: [
          _barChevron(context, LucideIcons.chevronLeft, onPrevious),
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  LucideIcons.calendar,
                  size: 16,
                  color: PlanSoft.ink(context),
                ),
                const SizedBox(width: 6),
                Flexible(
                  child: Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: PlanSoft.text(
                      context,
                      13,
                      FontWeight.w700,
                      PlanSoft.ink(context),
                    ),
                  ),
                ),
              ],
            ),
          ),
          _barChevron(context, LucideIcons.chevronRight, onNext),
        ],
      ),
    );
  }

  Widget _barChevron(BuildContext context, IconData icon, VoidCallback onTap) {
    return InkWell(
      customBorder: const CircleBorder(),
      onTap: onTap,
      child: SizedBox(
        width: 36,
        height: 36,
        child: Icon(icon, size: 18, color: PlanSoft.ink(context)),
      ),
    );
  }
}

class _PurposeRow extends StatelessWidget {
  const _PurposeRow({
    required this.purpose,
    required this.active,
    required this.subtitle,
    required this.onChange,
  });

  final String purpose;
  final bool active;
  final String subtitle;
  final VoidCallback onChange;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: PlanSoft.card(context),
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onChange,
        child: Ink(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: PlanSoft.border(context)),
          ),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 10, 12),
            child: Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: const BoxDecoration(
                    color: PlanSoft.emerald,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Flexible(
                            child: Text(
                              purpose,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: PlanSoft.text(
                                context,
                                14,
                                FontWeight.w700,
                                PlanSoft.ink(context),
                              ),
                            ),
                          ),
                          if (active) ...[
                            const SizedBox(width: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 3,
                              ),
                              decoration: BoxDecoration(
                                color: PlanSoft.mint(context),
                                borderRadius: BorderRadius.circular(999),
                              ),
                              child: Text(
                                'ACTIVE',
                                style: PlanSoft.text(
                                  context,
                                  10,
                                  FontWeight.w700,
                                  PlanSoft.emeraldDeep(context),
                                  letterSpacing: 0.4,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                      const SizedBox(height: 2),
                      Text(
                        subtitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: PlanSoft.text(
                          context,
                          12,
                          FontWeight.w500,
                          PlanSoft.slate(context),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  'CHANGE',
                  style: PlanSoft.text(
                    context,
                    11,
                    FontWeight.w700,
                    PlanSoft.emeraldDeep(context),
                    letterSpacing: 0.4,
                  ),
                ),
                Icon(
                  LucideIcons.chevronRight,
                  size: 16,
                  color: PlanSoft.slate(context),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _EmptyPlanCard extends StatelessWidget {
  const _EmptyPlanCard({required this.monthLabel, required this.onCreate});

  final String monthLabel;
  final VoidCallback onCreate;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 28, 20, 24),
      decoration: PlanSoft.emptyBox(context),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: PlanSoft.mint(context),
              borderRadius: BorderRadius.circular(999),
            ),
            child: Text(
              'PLAN NEEDED',
              style: PlanSoft.text(
                context,
                11,
                FontWeight.w700,
                PlanSoft.emeraldDeep(context),
                letterSpacing: 0.6,
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'No plan yet',
            textAlign: TextAlign.center,
            style: PlanSoft.text(
              context,
              24,
              FontWeight.w700,
              PlanSoft.ink(context),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Create a plan for $monthLabel',
            textAlign: TextAlign.center,
            style: PlanSoft.text(
              context,
              15,
              FontWeight.w600,
              PlanSoft.ink(context),
            ),
          ),
          const SizedBox(height: 8),
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 250),
            child: Text(
              'Set your expected income and spending limits to keep your finances balanced.',
              textAlign: TextAlign.center,
              style: PlanSoft.text(
                context,
                13,
                FontWeight.w500,
                PlanSoft.slate(context),
                height: 1.4,
              ),
            ),
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            height: 48,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: SoftColors.control,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              onPressed: onCreate,
              child: Text(
                '+ Create New Plan',
                style: PlanSoft.text(
                  context,
                  15,
                  FontWeight.w700,
                  Colors.white,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _DistSeg {
  const _DistSeg({
    required this.name,
    required this.amount,
    required this.color,
  });

  final String name;
  final double amount;
  final Color color;
}

class _LedgerDistributionBar extends StatelessWidget {
  const _LedgerDistributionBar({required this.segments});

  final List<_DistSeg> segments;

  @override
  Widget build(BuildContext context) {
    final total = segments.fold<double>(0, (sum, seg) => sum + seg.amount);
    return SizedBox(
      height: 8,
      child: Row(
        children: [
          for (var i = 0; i < segments.length; i++) ...[
            if (i > 0) const SizedBox(width: 2),
            Expanded(
              flex: _flex(segments[i].amount, total),
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: segments[i].color,
                  borderRadius: BorderRadius.circular(99),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  int _flex(double amount, double total) {
    if (total <= 0) return 1;
    return ((amount / total) * 1000).round().clamp(1, 1000);
  }
}

class _PurposeOption extends StatelessWidget {
  const _PurposeOption({
    required this.name,
    required this.meta,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  final String name;
  final String meta;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final border = selected ? PlanSoft.emerald : PlanSoft.border(context);
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Ink(
          decoration: BoxDecoration(
            color: selected ? PlanSoft.mint(context) : PlanSoft.card(context),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: border, width: selected ? 1.5 : 1),
          ),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: PlanSoft.mint(context),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    icon,
                    size: 18,
                    color: PlanSoft.emeraldDeep(context),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        name,
                        style: PlanSoft.text(
                          context,
                          14,
                          FontWeight.w700,
                          PlanSoft.ink(context),
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        meta,
                        style: PlanSoft.text(
                          context,
                          11,
                          FontWeight.w500,
                          PlanSoft.slate(context),
                        ),
                      ),
                    ],
                  ),
                ),
                if (selected)
                  const Icon(
                    LucideIcons.check,
                    size: 18,
                    color: PlanSoft.emerald,
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _PlanHistorySheet extends StatefulWidget {
  const _PlanHistorySheet({
    required this.purpose,
    required this.monthLabel,
    required this.openMonth,
    required this.plans,
    required this.onApply,
  });

  final String purpose;
  final String monthLabel;
  final String openMonth;
  final List<MonthlyPlan> plans;
  final ValueChanged<MonthlyPlan> onApply;

  @override
  State<_PlanHistorySheet> createState() => _PlanHistorySheetState();
}

class _PlanHistorySheetState extends State<_PlanHistorySheet> {
  String? _selectedId;

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).padding.bottom;
    final maxHeight = MediaQuery.of(context).size.height * 0.78;
    return Container(
      constraints: BoxConstraints(maxHeight: maxHeight),
      decoration: BoxDecoration(
        color: PlanSoft.card(context),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: ListView(
        shrinkWrap: true,
        padding: EdgeInsets.fromLTRB(16, 10, 16, 16 + bottom),
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(
                color: PlanSoft.slate100(context),
                borderRadius: BorderRadius.circular(99),
              ),
            ),
          ),
          Text(
            'Saved plans',
            style: PlanSoft.text(
              context,
              18,
              FontWeight.w800,
              PlanSoft.ink(context),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Tap a month to see its limits. Apply plan copies it onto ${widget.monthLabel}.',
            style: PlanSoft.text(
              context,
              12,
              FontWeight.w500,
              PlanSoft.slate(context),
            ),
          ),
          const SizedBox(height: 16),
          if (widget.plans.isEmpty)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: PlanSoft.rowBox(context),
              child: Text(
                'No saved plans for ${widget.purpose} yet.',
                style: PlanSoft.text(
                  context,
                  14,
                  FontWeight.w600,
                  PlanSoft.slate(context),
                ),
              ),
            )
          else
            for (final plan in widget.plans) ...[
              _historyCard(context, plan),
              const SizedBox(height: 8),
            ],
        ],
      ),
    );
  }

  Widget _historyCard(BuildContext context, MonthlyPlan plan) {
    final selected = _selectedId == plan.id;
    final limits = plan.allocations.where((a) => a.plannedAmount > 0).toList();
    final sameMonth = plan.month == widget.openMonth;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => setState(() => _selectedId = selected ? null : plan.id),
        child: Ink(
          decoration: BoxDecoration(
            color: selected ? PlanSoft.mint(context) : PlanSoft.card(context),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: selected ? PlanSoft.emerald : PlanSoft.border(context),
              width: selected ? 1.5 : 1,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            formatPlanMonth(plan.month),
                            style: PlanSoft.text(
                              context,
                              14,
                              FontWeight.w700,
                              PlanSoft.ink(context),
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            getPlanDisplayTitle(plan),
                            style: PlanSoft.text(
                              context,
                              12,
                              FontWeight.w500,
                              PlanSoft.slate(context),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Text(
                      '₹${plan.totalPlanned.toStringAsFixed(0)}',
                      style: PlanSoft.text(
                        context,
                        14,
                        FontWeight.w800,
                        PlanSoft.emeraldDeep(context),
                      ),
                    ),
                  ],
                ),
                if (selected) ...[
                  const SizedBox(height: 12),
                  if (limits.isEmpty)
                    Text(
                      'No category limits on this plan.',
                      style: PlanSoft.text(
                        context,
                        12,
                        FontWeight.w500,
                        PlanSoft.slate(context),
                      ),
                    )
                  else
                    for (final allocation in limits)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 6),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(
                                allocation.category,
                                style: PlanSoft.text(
                                  context,
                                  13,
                                  FontWeight.w600,
                                  PlanSoft.ink(context),
                                ),
                              ),
                            ),
                            Text(
                              '₹${allocation.plannedAmount.toStringAsFixed(0)}',
                              style: PlanSoft.text(
                                context,
                                13,
                                FontWeight.w700,
                                PlanSoft.ink(context),
                              ),
                            ),
                          ],
                        ),
                      ),
                  const SizedBox(height: 8),
                  if (sameMonth)
                    Text(
                      'This is the month you are viewing.',
                      style: PlanSoft.text(
                        context,
                        12,
                        FontWeight.w600,
                        PlanSoft.slate(context),
                      ),
                    )
                  else
                    SizedBox(
                      width: double.infinity,
                      height: 44,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: SoftColors.control,
                          foregroundColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(24),
                          ),
                        ),
                        onPressed: () => widget.onApply(plan),
                        child: Text(
                          'Apply plan',
                          style: PlanSoft.text(
                            context,
                            13,
                            FontWeight.w700,
                            Colors.white,
                          ),
                        ),
                      ),
                    ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _EditPlanSheet extends ConsumerStatefulWidget {
  final MonthlyPlan plan;
  final Future<void> Function(MonthlyPlan updated) onSave;

  const _EditPlanSheet({required this.plan, required this.onSave});

  @override
  ConsumerState<_EditPlanSheet> createState() => _EditPlanSheetState();
}

class _EditPlanSheetState extends ConsumerState<_EditPlanSheet> {
  late TextEditingController _incomeCtrl;

  List<PlanAllocation> _withOutingLimitLast(List<PlanAllocation> allocs) {
    PlanAllocation? outing;
    final rest = <PlanAllocation>[];
    for (final allocation in allocs) {
      if (!MonthlyPlan.isOutingLimit(allocation.category)) {
        rest.add(allocation);
        continue;
      }
      if (outing == null ||
          (outing.plannedAmount <= 0 && allocation.plannedAmount > 0)) {
        outing = allocation.copyWith(category: MonthlyPlan.outingLimitCategory);
      }
    }
    outing ??= PlanAllocation(
      id: 'alloc-outings-${widget.plan.id}',
      category: MonthlyPlan.outingLimitCategory,
      plannedAmount: 0,
    );
    return [...rest, outing];
  }

  late TextEditingController _titleCtrl;
  late List<PlanAllocation> _allocs;
  late Map<String, TextEditingController> _amountCtrls;
  late Map<String, bool> _rolloverMap;
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    _incomeCtrl = TextEditingController(
      text:
          widget.plan.expectedIncome > 0
              ? widget.plan.expectedIncome.toStringAsFixed(0)
              : '',
    );
    _titleCtrl = TextEditingController(
      text: widget.plan.title ?? formatDefaultPlanTitle(widget.plan.month),
    );
    _allocs = List.from(widget.plan.allocations);
    if (_allocs.isEmpty) {
      final cats = ref.read(categoryProvider).expense;
      _allocs =
          cats
              .map(
                (c) => PlanAllocation(
                  id: DateTime.now().microsecondsSinceEpoch.toString() + c,
                  category: c,
                  plannedAmount: 0,
                  rollover: false,
                ),
              )
              .toList();
    }
    _allocs = _withOutingLimitLast(_allocs);
    _amountCtrls = {
      for (final a in _allocs)
        a.id: TextEditingController(
          text: a.plannedAmount > 0 ? a.plannedAmount.toStringAsFixed(0) : '',
        ),
    };
    _rolloverMap = {for (final a in _allocs) a.id: a.rollover};
  }

  @override
  void dispose() {
    _incomeCtrl.dispose();
    _titleCtrl.dispose();
    for (final c in _amountCtrls.values) {
      c.dispose();
    }
    super.dispose();
  }

  double get _totalPlanned {
    var s = 0.0;
    for (final a in _allocs) {
      final v = double.tryParse(_amountCtrls[a.id]?.text ?? '') ?? 0;
      s += v;
    }
    return s;
  }

  InputDecoration _fieldDecoration({
    String? label,
    String? prefix,
    String? hint,
  }) {
    final radius = BorderRadius.circular(16);
    final enabled = BorderSide(
      color:
          PlanSoft.dark(context)
              ? const Color(0xFF3F3F46)
              : const Color(0xFFE2E8F0),
    );
    return InputDecoration(
      labelText: label,
      hintText: hint,
      labelStyle: PlanSoft.text(
        context,
        13,
        FontWeight.w600,
        PlanSoft.slate(context),
      ),
      hintStyle: PlanSoft.text(
        context,
        13,
        FontWeight.w500,
        PlanSoft.muted(context),
      ),
      prefixText: prefix,
      prefixStyle: PlanSoft.text(
        context,
        15,
        FontWeight.w700,
        PlanSoft.ink(context),
      ),
      filled: true,
      fillColor:
          PlanSoft.dark(context)
              ? const Color(0xFF09090B)
              : const Color(0xFFF8FAFC),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      border: OutlineInputBorder(borderRadius: radius, borderSide: enabled),
      enabledBorder: OutlineInputBorder(
        borderRadius: radius,
        borderSide: enabled,
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: radius,
        borderSide: const BorderSide(color: PlanSoft.emerald, width: 1.5),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final income = double.tryParse(_incomeCtrl.text.replaceAll(',', '')) ?? 0;
    final over = income > 0 && _totalPlanned > income;
    final notifier = ref.read(planProvider.notifier);

    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 12,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.85,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 36,
                height: 4,
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(
                  color: isDark ? Colors.white24 : Colors.black12,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Edit plan',
                        style: PlanSoft.text(
                          context,
                          18,
                          FontWeight.w800,
                          PlanSoft.ink(context),
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '${formatPlanMonth(widget.plan.month)} · ${widget.plan.purposeName ?? 'Personal'}',
                        style: PlanSoft.text(
                          context,
                          12,
                          FontWeight.w600,
                          PlanSoft.slate(context),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color:
                        over
                            ? SoftPalette.negative.withValues(alpha: 0.12)
                            : SoftPalette.emerald.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    '₹${_totalPlanned.toStringAsFixed(0)} total',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: over ? SoftPalette.negative : SoftPalette.emerald,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Expanded(
              child: ListView(
                children: [
                  TextField(
                    controller: _titleCtrl,
                    minLines: 1,
                    maxLines: 3,
                    style: PlanSoft.text(
                      context,
                      15,
                      FontWeight.w700,
                      PlanSoft.ink(context),
                    ),
                    decoration: _fieldDecoration(label: 'Plan title'),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _incomeCtrl,
                    keyboardType: const TextInputType.numberWithOptions(
                      decimal: true,
                    ),
                    style: PlanSoft.text(
                      context,
                      28,
                      FontWeight.w800,
                      PlanSoft.ink(context),
                    ),
                    decoration: _fieldDecoration(
                      label: 'Expected income',
                      prefix: '₹ ',
                      hint: '0',
                    ).copyWith(
                      hintStyle: PlanSoft.text(
                        context,
                        28,
                        FontWeight.w800,
                        PlanSoft.muted(context),
                      ),
                      prefixStyle: PlanSoft.text(
                        context,
                        28,
                        FontWeight.w800,
                        PlanSoft.ink(context),
                      ),
                      border: InputBorder.none,
                      enabledBorder: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      disabledBorder: InputBorder.none,
                      errorBorder: InputBorder.none,
                      focusedErrorBorder: InputBorder.none,
                    ),
                    onChanged: (_) => setState(() {}),
                  ),
                  if (over) ...[
                    const SizedBox(height: 10),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: SoftPalette.negative.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: SoftPalette.negative.withValues(alpha: 0.3),
                        ),
                      ),
                      child: Text(
                        '⚠️ Total planned (₹${_totalPlanned.toStringAsFixed(0)}) exceeds expected income (₹${income.toStringAsFixed(0)}). Save is blocked until allocations fit income.',
                        style: const TextStyle(
                          fontSize: 11.5,
                          fontWeight: FontWeight.w600,
                          color: SoftPalette.negative,
                        ),
                      ),
                    ),
                  ],
                  const SizedBox(height: 16),
                  Text(
                    'Category Allocations & Rollover',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.5,
                      color: PlanSoft.slate(context),
                    ),
                  ),
                  const SizedBox(height: 10),
                  ..._allocs.map((a) {
                    final cat = CategoryIcon.resolve(a.category);
                    final isRollover = _rolloverMap[a.id] ?? false;
                    final rolled =
                        isRollover
                            ? notifier.rolloverHeadroomForCategory(
                              month: widget.plan.month,
                              category: a.category,
                              purposeName: widget.plan.purposeName,
                            )
                            : 0.0;

                    return Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 14,
                        vertical: 10,
                      ),
                      decoration: BoxDecoration(
                        color: context.tokens.field,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color:
                              isDark
                                  ? Colors.white.withValues(alpha: 0.05)
                                  : Colors.black.withValues(alpha: 0.05),
                        ),
                      ),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Container(
                                width: 34,
                                height: 34,
                                decoration: BoxDecoration(
                                  color: cat.color,
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(
                                  cat.icon,
                                  color: cat.onColor,
                                  size: 16,
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      a.category,
                                      style: PlanSoft.text(
                                        context,
                                        14,
                                        FontWeight.w700,
                                        PlanSoft.ink(context),
                                      ),
                                    ),
                                    if (MonthlyPlan.isOutingLimit(a.category))
                                      Text(
                                        'Outing limit',
                                        style: PlanSoft.text(
                                          context,
                                          11,
                                          FontWeight.w500,
                                          PlanSoft.slate(context),
                                        ),
                                      ),
                                    if (rolled > 0 && isRollover)
                                      Text(
                                        '+₹${rolled.toStringAsFixed(0)} unspent from last month',
                                        style: const TextStyle(
                                          fontSize: 11,
                                          color: SoftPalette.positive,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                width: 128,
                                child: TextField(
                                  controller: _amountCtrls[a.id],
                                  keyboardType: TextInputType.number,
                                  textAlign: TextAlign.right,
                                  style: PlanSoft.text(
                                    context,
                                    14,
                                    FontWeight.w700,
                                    PlanSoft.ink(context),
                                  ),
                                  decoration: _fieldDecoration(
                                    prefix: '₹ ',
                                  ).copyWith(
                                    isDense: true,
                                    contentPadding: const EdgeInsets.symmetric(
                                      horizontal: 12,
                                      vertical: 12,
                                    ),
                                  ),
                                  onChanged: (_) => setState(() {}),
                                ),
                              ),
                            ],
                          ),
                          if (!MonthlyPlan.isOutingLimit(a.category)) ...[
                            const SizedBox(height: 6),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Text(
                                  'Rollover unspent:',
                                  style: TextStyle(
                                    fontSize: 11.5,
                                    color: PlanSoft.slate(context),
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Switch(
                                  value: isRollover,
                                  activeThumbColor: Colors.white,
                                  activeTrackColor: SoftPalette.emerald,
                                  inactiveThumbColor: PlanSoft.slate(context),
                                  inactiveTrackColor: Colors.transparent,
                                  trackOutlineColor: WidgetStatePropertyAll(
                                    isDark
                                        ? const Color(0xFF71717A)
                                        : const Color(0xFFCBD5E1),
                                  ),
                                  trackOutlineWidth:
                                      const WidgetStatePropertyAll(1.5),
                                  onChanged: (val) {
                                    setState(() {
                                      _rolloverMap[a.id] = val;
                                    });
                                  },
                                ),
                              ],
                            ),
                          ],
                        ],
                      ),
                    );
                  }),
                ],
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 52,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: SoftColors.control,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(24),
                  ),
                ),
                onPressed:
                    (over || _isSaving)
                        ? null
                        : () async {
                          final nav = Navigator.of(context);
                          setState(() => _isSaving = true);
                          try {
                            final next = <PlanAllocation>[];
                            for (final a in _allocs) {
                              final v =
                                  double.tryParse(
                                    _amountCtrls[a.id]?.text ?? '',
                                  ) ??
                                  0;
                              next.add(
                                a.copyWith(
                                  plannedAmount: v,
                                  rollover: _rolloverMap[a.id] ?? false,
                                ),
                              );
                            }
                            final incomeVal =
                                double.tryParse(
                                  _incomeCtrl.text.replaceAll(',', ''),
                                ) ??
                                0;

                            await widget.onSave(
                              widget.plan.copyWith(
                                title:
                                    _titleCtrl.text.trim().isEmpty
                                        ? null
                                        : _titleCtrl.text.trim(),
                                expectedIncome: incomeVal,
                                allocations: next,
                              ),
                            );
                            if (mounted) nav.pop();
                          } finally {
                            if (mounted) setState(() => _isSaving = false);
                          }
                        },
                icon: const Icon(LucideIcons.check, size: 18),
                label: Text(
                  _isSaving ? 'Saving...' : 'Save plan',
                  style: PlanSoft.text(
                    context,
                    15,
                    FontWeight.w700,
                    Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
