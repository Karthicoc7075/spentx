import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';
import '../../../core/providers/transaction_provider.dart' as model;
import '../../../core/providers/user_state_provider.dart';
import '../../../core/services/auth_service.dart';
import 'investment_math.dart';
import 'investment_service.dart';

export 'investment_math.dart';

enum InvestmentType {
  liquid,
  mutualFund,
  fixedDeposit,
  stocks,
  bonds,
  crypto,
  gold,
  realEstate,
  other,
}

extension InvestmentTypeDb on InvestmentType {
  /// Value stored in `public.investments.type` (same list on the website).
  String get dbValue {
    switch (this) {
      case InvestmentType.mutualFund:
        return 'mutual_fund';
      case InvestmentType.fixedDeposit:
        return 'fixed_deposit';
      case InvestmentType.realEstate:
        return 'real_estate';
      default:
        return name;
    }
  }

  String get label {
    switch (this) {
      case InvestmentType.mutualFund:
        return 'Mutual Fund';
      case InvestmentType.stocks:
        return 'Stocks & Equity';
      case InvestmentType.fixedDeposit:
        return 'Fixed Deposit';
      case InvestmentType.gold:
        return 'Gold / Commodities';
      case InvestmentType.bonds:
        return 'Bonds / Debt';
      case InvestmentType.crypto:
        return 'Cryptocurrency';
      case InvestmentType.realEstate:
        return 'Real Estate';
      case InvestmentType.liquid:
        return 'Liquid / Cash Fund';
      case InvestmentType.other:
        return 'Other Investment';
    }
  }

  static InvestmentType fromDb(String? raw) {
    final db = investmentTypeDbValue(raw);
    return InvestmentType.values.firstWhere(
      (t) => t.dbValue == db,
      orElse: () => InvestmentType.other,
    );
  }
}

class InvestmentHolding {
  final String id;
  final String name;
  final InvestmentType type;
  final double investedAmount;
  final double currentValue;
  final String? accountId;
  final String? purpose;
  final String? notes;
  final List<String> sourceTransactionIds;
  final String? createdAt;

  /// Server updated_at (null until first pull) — the conflict base.
  final String? updatedAt;

  InvestmentHolding({
    String? id,
    required this.name,
    required this.type,
    required this.investedAmount,
    required this.currentValue,
    this.accountId,
    this.purpose,
    this.notes,
    this.sourceTransactionIds = const [],
    this.createdAt,
    this.updatedAt,
  }) : id = id ?? const Uuid().v4();

  /// Current value — what the holding is worth now.
  double get amount => currentValue;
  double get gain => currentValue - investedAmount;
  double get gainPercent => gainPercentOf(investedAmount, currentValue);

  /// Kept for older call sites; same as [gainPercent].
  double get growthPercent => gainPercent;

  Map<String, dynamic> toRow() => {
    'id': id,
    'name': name,
    'type': type.dbValue,
    'invested_amount': double.parse(investedAmount.toStringAsFixed(2)),
    'current_value': double.parse(currentValue.toStringAsFixed(2)),
    'account_id': accountId,
    'purpose': purpose,
    'notes': notes,
    'source_transaction_ids': sourceTransactionIds,
    'created_at': createdAt ?? DateTime.now().toUtc().toIso8601String(),
    if (updatedAt != null) 'updated_at': updatedAt,
  };

  static double _n(Object? v) =>
      v is num ? v.toDouble() : double.tryParse('${v ?? ''}') ?? 0;

  factory InvestmentHolding.fromRow(Map<String, dynamic> m) =>
      InvestmentHolding(
        id: m['id']?.toString(),
        name: m['name']?.toString() ?? 'Investment',
        type: InvestmentTypeDb.fromDb(m['type']?.toString()),
        investedAmount: _n(m['invested_amount']),
        currentValue: _n(m['current_value']),
        accountId: m['account_id']?.toString(),
        purpose: m['purpose']?.toString(),
        notes: m['notes']?.toString(),
        sourceTransactionIds:
            (m['source_transaction_ids'] as List?)
                ?.map((e) => e.toString())
                .toList() ??
            const [],
        createdAt: m['created_at']?.toString(),
        updatedAt: m['updated_at']?.toString(),
      );

  InvestmentHolding copyWith({
    String? name,
    InvestmentType? type,
    double? investedAmount,
    double? currentValue,
    String? purpose,
    String? notes,
    bool clearNotes = false,
    String? accountId,
    bool clearAccountId = false,
    List<String>? sourceTransactionIds,
  }) {
    return InvestmentHolding(
      id: id,
      name: name ?? this.name,
      type: type ?? this.type,
      investedAmount: investedAmount ?? this.investedAmount,
      currentValue: currentValue ?? this.currentValue,
      accountId: clearAccountId ? null : (accountId ?? this.accountId),
      purpose: purpose ?? this.purpose,
      notes: clearNotes ? null : (notes ?? this.notes),
      sourceTransactionIds: sourceTransactionIds ?? this.sourceTransactionIds,
      createdAt: createdAt,
      updatedAt: updatedAt,
    );
  }
}

class InvestmentNotifier extends StateNotifier<List<InvestmentHolding>> {
  InvestmentNotifier(this._ref) : super(const []) {
    _load();
    _userId = AuthService.currentUserId;
    _authSubscription = AuthService.onAuthStateChange((_) {
      final next = AuthService.currentUserId;
      if (next == _userId) return;
      _userId = next;
      InvestmentService.resetSession();
      state = const [];
      if (next != null) unawaited(refresh());
    });
    unawaited(refresh());
  }

  final Ref _ref;
  String? _userId;
  StreamSubscription<dynamic>? _authSubscription;

  @override
  void dispose() {
    _authSubscription?.cancel();
    super.dispose();
  }

  void reloadFromStorage() => _load();

  void _load() {
    state =
        InvestmentService.cachedRows().map(InvestmentHolding.fromRow).toList();
  }

  Future<void> refresh() async {
    try {
      await _importLegacyInvestmentAccounts();
      await InvestmentService.fetch();
    } catch (_) {}
    if (mounted) _load();
  }

  /// Investment-typed local accounts (older builds) become investments rows
  /// once. Ids match the SQL migration, so the server never gets duplicates.
  /// The account itself is left alone but no longer counted in wealth totals.
  Future<void> _importLegacyInvestmentAccounts() async {
    final uid = AuthService.currentUserId;
    if (uid == null) return;
    final done = InvestmentService.migratedAccountIds();
    final legacy =
        _ref
            .read(userStateProvider)
            .accounts
            .where((a) => a.isActive && a.isInvestment && !done.contains(a.id))
            .toList();
    if (legacy.isEmpty) return;
    final txNotifier = _ref.read(model.transactionProvider.notifier);
    for (final a in legacy) {
      final balance = txNotifier.getFullAccountBalance(a.name);
      final value =
          balance > 0
              ? balance
              : (a.openingBalance > 0 ? a.openingBalance : 0.0);
      final h = InvestmentHolding(
        id: InvestmentIds.legacy(uid, 'account', a.id),
        name: a.name,
        type: InvestmentTypeDb.fromDb(a.type),
        investedAmount: value,
        currentValue: value,
        notes: 'Moved from an investment account',
        createdAt: DateTime.now().toUtc().toIso8601String(),
      );
      if (!state.any((x) => x.id == h.id)) {
        await InvestmentService.save(h.toRow());
      }
      await InvestmentService.markAccountMigrated(a.id);
    }
  }

  /// Linked-aware portfolio totals (no double counting).
  PortfolioTotals portfolio() {
    final txs = _ref.read(model.transactionProvider);
    return computePortfolio(
      holdings: state.map(
        (h) => (
          invested: h.investedAmount,
          current: h.currentValue,
          linkedTxIds: h.sourceTransactionIds.toSet(),
        ),
      ),
      transactions: txs.map(
        (t) => InvestmentTxView(
          id: t.id,
          remoteId: t.remoteId,
          amount: t.amount,
          isExpense: t.isExpense,
          category: t.category,
          isTransfer: t.isTransfer,
          isPendingVerification: t.isPendingVerification,
        ),
      ),
    );
  }

  /// Current value of everything (holdings + unlinked investment spends).
  double get totalWealth => portfolio().current;

  /// All transaction ids (local and remote) already linked to a holding.
  Set<String> get linkedTransactionIds => {
    for (final h in state) ...h.sourceTransactionIds,
  };

  ({double income, double expense}) todayFlow() {
    final now = DateTime.now();
    final txs = _ref.read(model.transactionProvider);
    double inc = 0, exp = 0;
    for (final t in txs) {
      if (t.date.year != now.year ||
          t.date.month != now.month ||
          t.date.day != now.day ||
          t.isTransfer) {
        continue;
      }
      if (t.isExpense) {
        exp += t.amount;
      } else {
        inc += t.amount;
      }
    }
    return (income: inc, expense: exp);
  }

  Future<void> _save(InvestmentHolding h, {String? base}) async {
    final next = [...state.where((x) => x.id != h.id), h];
    state = next;
    await InvestmentService.save(h.toRow(), baseUpdatedAt: base);
    if (mounted) _load();
  }

  Future<InvestmentHolding> addHolding({
    required String name,
    required InvestmentType type,
    required double investedAmount,
    double? currentValue,
    String? purpose,
    String? notes,
    String? accountId,
    List<String> sourceTransactionIds = const [],
  }) async {
    if (name.trim().isEmpty) throw ArgumentError('Enter a name');
    if (investedAmount <= 0) throw ArgumentError('Amount must be more than 0');
    final h = InvestmentHolding(
      name: name.trim(),
      type: type,
      investedAmount: investedAmount,
      currentValue: currentValue ?? investedAmount,
      accountId: accountId,
      purpose: purpose,
      notes: (notes ?? '').trim().isEmpty ? null : notes!.trim(),
      sourceTransactionIds: sourceTransactionIds,
      createdAt: DateTime.now().toUtc().toIso8601String(),
    );
    await _save(h);
    return h;
  }

  Future<void> updateHolding(InvestmentHolding h) async {
    final before = state.where((x) => x.id == h.id).toList();
    await _save(h, base: before.isEmpty ? h.updatedAt : before.first.updatedAt);
  }

  Future<void> removeHolding(String id) async {
    state = state.where((h) => h.id != id).toList();
    await InvestmentService.delete(id);
    if (mounted) _load();
  }

  InvestmentHolding _find(String id) => state.firstWhere(
    (h) => h.id == id,
    orElse: () => throw StateError('Holding not found'),
  );

  /// Adds money: invested and current value both go up by [delta].
  Future<void> investMore(
    String id,
    double delta, {
    String? linkTransactionId,
  }) async {
    if (delta <= 0) throw ArgumentError('Amount must be more than 0');
    final h = _find(id);
    await updateHolding(
      h.copyWith(
        investedAmount: h.investedAmount + delta,
        currentValue: h.currentValue + delta,
        sourceTransactionIds:
            linkTransactionId == null ||
                    h.sourceTransactionIds.contains(linkTransactionId)
                ? null
                : [...h.sourceTransactionIds, linkTransactionId],
      ),
    );
  }

  /// Takes money out at today's value. Blocks withdrawing more than the
  /// current value; invested amount shrinks in the same proportion.
  Future<void> withdraw(String id, double delta) async {
    if (delta <= 0) throw ArgumentError('Amount must be more than 0');
    final h = _find(id);
    if (delta > h.currentValue + 0.004) {
      throw ArgumentError(
        'You can withdraw at most ${h.currentValue.toStringAsFixed(2)}',
      );
    }
    final share =
        h.currentValue <= 0 ? 1.0 : (delta / h.currentValue).clamp(0.0, 1.0);
    await updateHolding(
      h.copyWith(
        currentValue:
            (h.currentValue - delta).clamp(0, double.infinity).toDouble(),
        investedAmount:
            (h.investedAmount * (1 - share))
                .clamp(0, double.infinity)
                .toDouble(),
      ),
    );
  }
}

final investmentProvider =
    StateNotifierProvider<InvestmentNotifier, List<InvestmentHolding>>(
      (ref) => InvestmentNotifier(ref),
    );
