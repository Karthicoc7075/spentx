import 'dart:convert';
import 'dart:developer' as dev;

import 'package:crypto/crypto.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/services/auth_service.dart';
import '../../../core/sync/conflict_row_writer.dart';
import '../../../core/services/device_user_state.dart';
import '../../../core/sync/durable_collection.dart';
import '../../../core/sync/sync_error_kind.dart';

final _uuidRe = RegExp(
  r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
  caseSensitive: false,
);

/// Ids shared with `public.spentx_legacy_uuid()` in
/// supabase/migrations/20261011_investments_goals.sql, so a holding moved by
/// the SQL migration and the same holding uploaded by the phone get the same
/// row (no duplicates).
class InvestmentIds {
  InvestmentIds._();

  static String legacy(String uid, String kind, String legacyId) {
    if (_uuidRe.hasMatch(legacyId)) return legacyId.toLowerCase();
    final hex = md5.convert(utf8.encode('$uid:$kind:$legacyId')).toString();
    return '${hex.substring(0, 8)}-${hex.substring(8, 12)}-'
        '${hex.substring(12, 16)}-${hex.substring(16, 20)}-${hex.substring(20)}';
  }
}

/// Local-first investments: Hive outbox ([DurableCollection]) + Supabase
/// `public.investments`, soft delete only, updated_at conflict check.
class InvestmentService {
  InvestmentService._();

  static SupabaseClient get _db => Supabase.instance.client;
  static Future<void>? _inFlight;
  static int _generation = 0;
  static const _localOwner = 'local_user';

  /// Mirror of the visible rows, also read by AuthService's local-data check.
  static const mirrorKey = 'holdings';
  static const boxName = 'investments';

  static void resetSession() {
    _generation++;
    _inFlight = null;
  }

  static String get _owner => AuthService.currentUserId ?? _localOwner;

  static Box get _box => Hive.box(boxName);
  static DurableCollection _store(String owner) =>
      DurableCollection(_box, 'store_v1:$owner', area: 'Investments');

  static bool get hasPendingChanges {
    if (!Hive.isBoxOpen(boxName)) return false;
    final uid = AuthService.currentUserId;
    if (uid == null) return false;
    // Server not migrated yet: keep the changes (parked across logout) but
    // never block sign-out over them.
    if (SyncSchemaStatus.isMissing(schemaKey)) return false;
    return _store(uid).hasPending;
  }

  /// [SyncSchemaStatus] key (public.investments).
  static const schemaKey = 'investments';

  /// Called right before the logout wipe: keeps unsynced investment changes
  /// for this user so they upload after the next sign-in.
  static Future<void> parkUnsynced(String uid) async {
    if (!Hive.isBoxOpen(boxName)) return;
    await DeviceUserState.park(schemaKey, uid, _store(uid));
  }

  static List<Map<String, dynamic>> cachedRows() {
    if (!Hive.isBoxOpen(boxName)) return [];
    if (AuthService.currentUserId != null &&
        AuthService.syncHeldForAccountSwitch) {
      return [];
    }
    final rows =
        _store(_owner).rows.where((r) => r['deleted_at'] == null).toList()
          ..sort(
            (a, b) => '${a['created_at'] ?? ''}'.compareTo(
              '${b['created_at'] ?? ''}',
            ),
          );
    return rows;
  }

  static Future<void> _mirror() async {
    await _box.put(mirrorKey, cachedRows());
  }

  /// Old builds kept holdings as one list under [mirrorKey] with
  /// `amount` + `growthPercent`. Convert them once into outbox rows.
  static List<Map<String, dynamic>> _legacyRows(String uid) {
    final raw = _box.get(mirrorKey);
    if (raw is! List) return [];
    final out = <Map<String, dynamic>>[];
    for (final item in raw.whereType<Map>()) {
      final m = Map<String, dynamic>.from(item);
      if (m.containsKey('invested_amount')) continue; // already new format
      final amount = (m['amount'] as num?)?.toDouble() ?? 0;
      final growth = (m['growthPercent'] as num?)?.toDouble() ?? 0;
      out.add({
        'id': InvestmentIds.legacy(uid, 'holding', m['id']?.toString() ?? ''),
        'user_id': uid,
        'name':
            (m['name']?.toString().trim().isNotEmpty ?? false)
                ? m['name'].toString().trim()
                : 'Investment',
        'type': investmentTypeDbValue(m['type']?.toString()),
        'invested_amount': _round2(amount < 0 ? 0 : amount),
        'current_value': _round2(
          (amount * (1 + growth / 100)).clamp(0, double.infinity).toDouble(),
        ),
        'account_id': null,
        'purpose': null,
        'notes': 'Moved from the old holdings list',
        'source_transaction_ids': <String>[],
        'created_at':
            DateTime.tryParse(
              m['updatedAt']?.toString() ?? '',
            )?.toUtc().toIso8601String() ??
            DateTime.now().toUtc().toIso8601String(),
      });
    }
    return out;
  }

  /// Prepares the store for the signed-in user: imports legacy holdings once
  /// and adopts anything added while signed out.
  static Future<void> ensureReady() async {
    if (!Hive.isBoxOpen(boxName)) return;
    final owner = _owner;
    final store = _store(owner);
    if (!store.initialized) {
      await store.importRows(_legacyRows(owner), upload: owner != _localOwner);
    }
    if (owner != _localOwner) {
      await DeviceUserState.restoreParked(schemaKey, owner, store);
      await store.adoptFrom(_store(_localOwner));
    }
    await _mirror();
  }

  static Future<void> flushPending() async {
    final uid = AuthService.currentUserId;
    if (uid == null || AuthService.syncHeldForAccountSwitch) return;
    final pending = _inFlight ??= _synchronize(uid);
    try {
      await pending;
      SyncSchemaStatus.markPresent(schemaKey);
    } catch (e) {
      if (SyncErrors.classify(e) == SyncErrorKind.schemaMissing) {
        SyncSchemaStatus.markMissing(schemaKey);
        dev.log('investments table missing on server; changes kept: $e');
        return;
      }
      rethrow;
    } finally {
      if (identical(_inFlight, pending)) _inFlight = null;
    }
  }

  static Map<String, dynamic> _payload(
    Map<String, dynamic> row,
    bool isInsert,
  ) {
    final clean = ConflictRowWriter.stripLocal(row);
    return {
      'name': clean['name'],
      'type': investmentTypeDbValue(clean['type']?.toString()),
      'invested_amount': clean['invested_amount'] ?? 0,
      'current_value': clean['current_value'] ?? 0,
      'account_id': clean['account_id'],
      'purpose': clean['purpose'],
      'notes': clean['notes'],
      'source_transaction_ids':
          (clean['source_transaction_ids'] as List?)
              ?.map((e) => e.toString())
              .toList() ??
          <String>[],
      if (isInsert && clean['created_at'] != null)
        'created_at': clean['created_at'],
    };
  }

  static Future<void> _synchronize(String uid) async {
    final generation = _generation;
    bool current() =>
        generation == _generation &&
        AuthService.currentUserId == uid &&
        !AuthService.syncHeldForAccountSwitch;
    await ensureReady();
    final store = _store(uid);
    await store.synchronize(
      isCurrent: current,
      write: (id, row) async {
        if (!current())
          throw StateError('Account changed during investment sync');
        await ConflictRowWriter.write(
          _db,
          table: 'investments',
          uid: uid,
          id: id,
          row: row,
          deletePatch: {'deleted_at': DateTime.now().toUtc().toIso8601String()},
          payload: _payload,
        );
        try {
          _db
              .channel('user-sync:$uid')
              .sendBroadcastMessage(
                event: 'investment-changed',
                payload: {
                  'op': row == null ? 'delete' : 'upsert',
                  'id': id,
                  'source': 'mobile',
                  'time': DateTime.now().millisecondsSinceEpoch,
                },
              );
        } catch (_) {}
      },
      read: () async {
        final rows = await _db
            .from('investments')
            .select('*')
            .eq('user_id', uid)
            .isFilter('deleted_at', null)
            .order('created_at');
        return rows.map((r) => Map<String, dynamic>.from(r)).toList();
      },
    );
    if (current()) await _mirror();
  }

  static Future<void> _trySync() async {
    if (AuthService.currentUserId == null) return;
    try {
      await flushPending();
    } catch (e) {
      dev.log('Investment changes retained for retry: $e');
    }
  }

  static Set<String> migratedAccountIds() {
    if (!Hive.isBoxOpen(boxName)) return const {};
    final raw = _box.get('migrated_accounts:$_owner');
    return raw is List ? raw.map((e) => e.toString()).toSet() : <String>{};
  }

  static Future<void> markAccountMigrated(String accountId) async {
    if (!Hive.isBoxOpen(boxName)) return;
    await _box.put(
      'migrated_accounts:$_owner',
      {...migratedAccountIds(), accountId}.toList(),
    );
  }

  static Future<void> save(
    Map<String, dynamic> row, {
    String? baseUpdatedAt,
  }) async {
    await ensureReady();
    final owner = _owner;
    final staged = ConflictRowWriter.stampEdit({
      ...row,
      'user_id': owner,
    }, baseUpdatedAt: baseUpdatedAt);
    await _store(owner).stage(row['id'].toString(), staged);
    await _mirror();
    await _trySync();
  }

  static Future<void> delete(String id) async {
    await ensureReady();
    await _store(_owner).stage(id, null);
    await _mirror();
    await _trySync();
  }

  static Future<List<Map<String, dynamic>>> fetch() async {
    await ensureReady();
    await _trySync();
    return cachedRows();
  }
}

double _round2(double v) => double.parse(v.toStringAsFixed(2));

/// Accepts db values, old Dart enum names and labels.
String investmentTypeDbValue(String? raw) {
  final t = (raw ?? '').toLowerCase().replaceAll(RegExp(r'[^a-z]'), '');
  switch (t) {
    case 'mutualfund':
    case 'mutualfunds':
    case 'mf':
    case 'sip':
      return 'mutual_fund';
    case 'stocks':
    case 'stock':
    case 'equity':
      return 'stocks';
    case 'fixeddeposit':
    case 'fd':
      return 'fixed_deposit';
    case 'bonds':
    case 'bond':
      return 'bonds';
    case 'gold':
      return 'gold';
    case 'crypto':
      return 'crypto';
    case 'realestate':
      return 'real_estate';
    case 'liquid':
      return 'liquid';
    default:
      return 'other';
  }
}
