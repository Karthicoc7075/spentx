/// Shared investment maths for the Wealth and Investments screens and the
/// daily snapshot. Mirrors `src/lib/investments.ts` on the website and the
/// `investment_totals` view in Supabase so all three show the same numbers.
library;

/// Expense categories that mean "money moved into an investment".
const investmentCategoryNames = {
  'investment',
  'investments',
  'mutual fund',
  'mutual funds',
  'stocks',
  'sip',
};

bool isInvestmentCategoryName(String category) =>
    investmentCategoryNames.contains(category.trim().toLowerCase());

/// Minimal view of a transaction so this file stays free of Flutter/Hive.
class InvestmentTxView {
  const InvestmentTxView({
    required this.id,
    this.remoteId,
    required this.amount,
    required this.isExpense,
    required this.category,
    this.isTransfer = false,
    this.isPendingVerification = false,
  });
  final String id;
  final String? remoteId;
  final double amount;
  final bool isExpense;
  final String category;
  final bool isTransfer;
  final bool isPendingVerification;
}

class PortfolioTotals {
  const PortfolioTotals({
    required this.invested,
    required this.current,
    required this.unlinkedSpend,
    required this.holdingCount,
  });
  final double invested;
  final double current;

  /// Investment-category spends not linked to any holding.
  final double unlinkedSpend;
  final int holdingCount;

  double get gain => current - invested;
  double get gainPercent => invested > 0 ? gain / invested * 100 : 0;
}

/// Gain % for one holding. Zero when nothing was invested.
double gainPercentOf(double invested, double current) =>
    invested > 0 ? (current - invested) / invested * 100 : 0;

/// Holdings count once. An investment-category spend counts only when it is
/// NOT already linked to a holding (otherwise "add investment + deduct from
/// bank" would be counted twice).
PortfolioTotals computePortfolio({
  required Iterable<({double invested, double current, Set<String> linkedTxIds})>
  holdings,
  required Iterable<InvestmentTxView> transactions,
}) {
  double invested = 0, current = 0;
  final linked = <String>{};
  var count = 0;
  for (final h in holdings) {
    invested += h.invested;
    current += h.current;
    linked.addAll(h.linkedTxIds);
    count++;
  }
  double unlinked = 0;
  for (final t in transactions) {
    if (!t.isExpense || t.isTransfer || t.isPendingVerification) continue;
    if (!isInvestmentCategoryName(t.category)) continue;
    if (linked.contains(t.id) || (t.remoteId != null && linked.contains(t.remoteId))) {
      continue;
    }
    unlinked += t.amount;
  }
  return PortfolioTotals(
    invested: invested + unlinked,
    current: current + unlinked,
    unlinkedSpend: unlinked,
    holdingCount: count,
  );
}

/// Parses user input like "25,000", " 1,20,000.50 ", "₹500". Null when empty
/// or not a number.
double? parseAmountInput(String raw) {
  final cleaned = raw.replaceAll(RegExp(r'[₹,\s]'), '');
  if (cleaned.isEmpty) return null;
  return double.tryParse(cleaned);
}

/// Word-boundary keyword match for the SMS "looks like an investment" list.
/// Short tokens (mf, sip, fd, nse, bse) must be whole words so merchants
/// like "FDMart" or "Gossip Cafe" are not picked up.
final _investmentWordRe = RegExp(
  r'\b(mf|sip|fd|nse|bse|mutual|stocks?|investment|fixed deposit)\b',
  caseSensitive: false,
);
const _investmentBrands = [
  'groww',
  'zerodha',
  'upstox',
  'kuvera',
  'etmoney',
  'et money',
  'coin by zerodha',
  'smallcase',
  'paytm money',
  'indmoney',
  'angel one',
  'mf central',
];

bool looksLikeInvestmentText(String text) {
  final t = text.toLowerCase();
  if (_investmentWordRe.hasMatch(t)) return true;
  return _investmentBrands.any(t.contains);
}
