import 'package:flutter/material.dart';
import '../../../../core/theme/soft_palette.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/providers/transaction_provider.dart' as model;
import '../../../../core/providers/user_state_provider.dart';
import '../../../../core/widgets/premium_bottom_sheet.dart';
import '../../../wealth/presentation/widgets/soft_wealth_widgets.dart';
import '../../data/investment_provider.dart';

/// Category used for the bank transaction recorded when money moves into an
/// investment (same name on the website).
const investmentTxCategory = 'Investment';

/// "Personal" by name (matches the website's default purpose), else the first
/// purpose the user has.
String? defaultPurposeOf(List<String> purposes) {
  if (purposes.isEmpty) return null;
  return purposes.firstWhere(
    (p) => p.trim().toLowerCase() == 'personal',
    orElse: () => purposes.first,
  );
}

InputDecoration investmentInputDecoration(String label, SoftTone tone) {
  final outline = OutlineInputBorder(
    borderRadius: BorderRadius.circular(14),
    borderSide: BorderSide(color: tone.border),
  );
  return InputDecoration(
    labelText: label,
    labelStyle: tone.text(13, FontWeight.w600, tone.slate),
    filled: true,
    fillColor: tone.track,
    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
    enabledBorder: outline,
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: BorderSide(color: tone.emerald, width: 1.5),
    ),
    errorBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: const BorderSide(color: Color(0xFFDC2626)),
    ),
    focusedErrorBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: const BorderSide(color: Color(0xFFDC2626), width: 1.5),
    ),
  );
}

List<({String id, String name})> _linkableAccounts(WidgetRef ref) {
  final raw =
      ref.read(userStateProvider).accounts.where((a) => a.isActive).toList();
  final seen = <String>{};
  return [
    for (final a in UserStateNotifier.deduplicate(raw))
      if (a.id.isNotEmpty && seen.add(a.id)) (id: a.id, name: a.name),
  ];
}

String _plain(double v) =>
    v % 1 == 0 ? v.toInt().toString() : v.toStringAsFixed(2);

List<String> _fundingAccounts(WidgetRef ref) {
  final raw =
      ref
          .read(userStateProvider)
          .accounts
          .where((a) => a.isActive && (a.isBank || a.isWallet))
          .toList();
  final seen = <String>{};
  return UserStateNotifier.deduplicate(
    raw,
  ).map((a) => a.name).where(seen.add).toList();
}

/// Records the bank outflow for money put into an investment and returns its
/// id, which is stored on the holding so totals never count it twice.
String _recordBankOutflow(
  WidgetRef ref, {
  required String name,
  required double amount,
  required String account,
  required String? purpose,
}) {
  final now = DateTime.now();
  final tx = model.Transaction(
    merchant: name,
    amount: amount,
    isExpense: true,
    time: DateFormat('hh:mm a').format(now),
    category: investmentTxCategory,
    account: account,
    purpose: purpose,
    date: now,
    note: 'Investment in $name',
  );
  ref.read(model.transactionProvider.notifier).addTransaction(tx);
  return tx.id;
}

void _toast(BuildContext context, String text, {bool error = false}) {
  final tone = SoftTone(context);
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(text),
      backgroundColor: error ? const Color(0xFFDC2626) : tone.emeraldDeep,
      duration: const Duration(seconds: 2),
    ),
  );
}

/// One add/edit form for investments, used by the Wealth tab and the
/// Investments screen. Validation errors show inline under each field.
///
/// [linkTransaction] pre-fills the form from an existing (e.g. SMS-detected)
/// transaction and links it instead of creating a new bank outflow.
Future<InvestmentHolding?> showInvestmentFormSheet(
  BuildContext context,
  WidgetRef ref, {
  InvestmentHolding? existing,
  model.Transaction? linkTransaction,
  InvestmentType? initialType,
}) async {
  final isEditing = existing != null;
  final purposes = ref.read(userStateProvider).purposeTypes.toSet().toList();
  final accounts = _fundingAccounts(ref);

  final nameCtrl = TextEditingController(
    text: existing?.name ?? linkTransaction?.merchant ?? '',
  );
  final investedCtrl = TextEditingController(
    text:
        existing != null
            ? _plain(existing.investedAmount)
            : (linkTransaction != null ? _plain(linkTransaction.amount) : ''),
  );
  final currentCtrl = TextEditingController(
    text: existing != null ? _plain(existing.currentValue) : '',
  );
  final notesCtrl = TextEditingController(text: existing?.notes ?? '');
  InvestmentType type =
      existing?.type ?? initialType ?? InvestmentType.mutualFund;
  String? purpose =
      existing?.purpose ??
      linkTransaction?.purpose ??
      defaultPurposeOf(purposes);
  if (purpose != null && !purposes.contains(purpose)) purposes.add(purpose);
  String? bank = accounts.isNotEmpty ? accounts.first : null;
  // Optional linked account (accounts.id) — prefilled when editing.
  final linkable = _linkableAccounts(ref);
  String? linkedAccountId = existing?.accountId;
  if (linkedAccountId != null &&
      linkedAccountId.isNotEmpty &&
      !linkable.any((a) => a.id == linkedAccountId)) {
    linkable.add((id: linkedAccountId, name: 'Linked account'));
  }
  if (linkedAccountId != null && linkedAccountId.isEmpty)
    linkedAccountId = null;
  bool deduct = !isEditing && linkTransaction == null && accounts.isNotEmpty;
  String? nameError, investedError, currentError;

  final ok = await PremiumBottomSheet.show<bool>(
    context: context,
    child: StatefulBuilder(
      builder: (ctx, setModal) {
        final tone = SoftTone(ctx);
        final hint = tone.text(
          13,
          FontWeight.w400,
          tone.slate.withValues(alpha: 0.6),
        );
        return Padding(
          padding: EdgeInsets.fromLTRB(
            20,
            8,
            20,
            20 + MediaQuery.of(ctx).viewInsets.bottom,
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: tone.mint,
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Icon(
                        LucideIcons.trendingUp,
                        color: tone.emeraldDeep,
                        size: 22,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            isEditing ? 'Edit Investment' : 'Add Investment',
                            style: tone.text(18, FontWeight.w800, tone.ink),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            isEditing
                                ? 'Update what you put in and what it is worth now'
                                : 'Track stocks, mutual funds, gold & deposits',
                            style: tone.text(12, FontWeight.w500, tone.slate),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                TextField(
                  controller: nameCtrl,
                  textCapitalization: TextCapitalization.words,
                  style: tone.text(14, FontWeight.w600, tone.ink),
                  decoration: investmentInputDecoration(
                    'Investment / Asset Name *',
                    tone,
                  ).copyWith(
                    errorText: nameError,
                    hintText: 'e.g., Tata Digital India, Apple, Gold ETF',
                    hintStyle: hint,
                  ),
                  onChanged: (_) {
                    if (nameError != null) setModal(() => nameError = null);
                  },
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<InvestmentType>(
                  initialValue: type,
                  dropdownColor: tone.card,
                  isExpanded: true,
                  decoration: investmentInputDecoration('Asset Class', tone),
                  items: [
                    for (final t in InvestmentType.values)
                      DropdownMenuItem(
                        value: t,
                        child: Text(
                          t.label,
                          style: tone.text(13, FontWeight.w600, tone.ink),
                        ),
                      ),
                  ],
                  onChanged: (v) {
                    if (v != null) setModal(() => type = v);
                  },
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: investedCtrl,
                  keyboardType: const TextInputType.numberWithOptions(
                    decimal: true,
                  ),
                  style: tone.text(14, FontWeight.w600, tone.ink),
                  decoration: investmentInputDecoration(
                    'Amount Invested (₹) *',
                    tone,
                  ).copyWith(
                    errorText: investedError,
                    hintText: 'e.g., 25,000',
                    hintStyle: hint,
                  ),
                  onChanged: (_) {
                    if (investedError != null)
                      setModal(() => investedError = null);
                  },
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: currentCtrl,
                  keyboardType: const TextInputType.numberWithOptions(
                    decimal: true,
                  ),
                  style: tone.text(14, FontWeight.w600, tone.ink),
                  decoration: investmentInputDecoration(
                    'Current Value (₹)',
                    tone,
                  ).copyWith(
                    errorText: currentError,
                    helperText: 'Leave empty if it is the same as invested',
                    helperStyle: tone.text(11, FontWeight.w500, tone.slate),
                    hintText: 'e.g., 27,500',
                    hintStyle: hint,
                  ),
                  onChanged: (_) {
                    if (currentError != null)
                      setModal(() => currentError = null);
                  },
                ),
                if (purposes.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    initialValue: purpose,
                    dropdownColor: tone.card,
                    isExpanded: true,
                    decoration: investmentInputDecoration('Purpose', tone),
                    items: [
                      for (final p in purposes)
                        DropdownMenuItem(
                          value: p,
                          child: Text(
                            p,
                            style: tone.text(13, FontWeight.w600, tone.ink),
                          ),
                        ),
                    ],
                    onChanged: (v) => setModal(() => purpose = v),
                  ),
                ],
                if (linkable.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String?>(
                    initialValue: linkedAccountId,
                    dropdownColor: tone.card,
                    isExpanded: true,
                    decoration: investmentInputDecoration(
                      'Linked account (optional)',
                      tone,
                    ),
                    items: [
                      DropdownMenuItem<String?>(
                        value: null,
                        child: Text(
                          'None',
                          style: tone.text(13, FontWeight.w600, tone.slate),
                        ),
                      ),
                      for (final a in linkable)
                        DropdownMenuItem<String?>(
                          value: a.id,
                          child: Text(
                            a.name,
                            style: tone.text(13, FontWeight.w600, tone.ink),
                          ),
                        ),
                    ],
                    onChanged: (v) => setModal(() => linkedAccountId = v),
                  ),
                ],
                const SizedBox(height: 12),
                TextField(
                  controller: notesCtrl,
                  maxLines: 2,
                  style: tone.text(14, FontWeight.w500, tone.ink),
                  decoration: investmentInputDecoration(
                    'Notes (optional)',
                    tone,
                  ),
                ),
                if (!isEditing && linkTransaction == null && bank != null) ...[
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: tone.track,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: tone.border),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Checkbox(
                              value: deduct,
                              activeColor: SoftColors.control,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(5),
                              ),
                              onChanged:
                                  (v) => setModal(() => deduct = v ?? false),
                            ),
                            Expanded(
                              child: GestureDetector(
                                onTap: () => setModal(() => deduct = !deduct),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Deduct from bank balance',
                                      style: tone.text(
                                        13,
                                        FontWeight.w700,
                                        tone.ink,
                                      ),
                                    ),
                                    Text(
                                      'Records a linked transaction (counted once)',
                                      style: tone.text(
                                        11,
                                        FontWeight.w500,
                                        tone.slate,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                        if (deduct) ...[
                          const SizedBox(height: 8),
                          DropdownButtonFormField<String>(
                            initialValue: bank,
                            dropdownColor: tone.card,
                            isExpanded: true,
                            decoration: investmentInputDecoration(
                              'Paid from',
                              tone,
                            ),
                            items: [
                              for (final a in accounts)
                                DropdownMenuItem(
                                  value: a,
                                  child: Text(
                                    a,
                                    style: tone.text(
                                      13,
                                      FontWeight.w600,
                                      tone.ink,
                                    ),
                                  ),
                                ),
                            ],
                            onChanged: (v) => setModal(() => bank = v),
                          ),
                          const SizedBox(height: 4),
                        ],
                      ],
                    ),
                  ),
                ],
                if (linkTransaction != null) ...[
                  const SizedBox(height: 12),
                  Text(
                    'Linked to "${linkTransaction.merchant}" on '
                    '${DateFormat('d MMM yyyy').format(linkTransaction.date)} — no new transaction is created.',
                    style: tone.text(11, FontWeight.w500, tone.slate),
                  ),
                ],
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(ctx, false),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: tone.slate,
                          side: BorderSide(color: tone.border),
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                        child: const Text('Cancel'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton(
                        onPressed: () {
                          final invested = parseAmountInput(investedCtrl.text);
                          final currentRaw = currentCtrl.text.trim();
                          final current = parseAmountInput(currentRaw);
                          setModal(() {
                            nameError =
                                nameCtrl.text.trim().isEmpty
                                    ? 'Please enter investment name'
                                    : null;
                            investedError =
                                invested == null
                                    ? 'Enter a number, e.g. 25,000'
                                    : (invested <= 0
                                        ? 'Enter amount greater than 0'
                                        : null);
                            currentError =
                                currentRaw.isEmpty
                                    ? null
                                    : (current == null
                                        ? 'Enter a number, e.g. 27,500'
                                        : (current < 0
                                            ? 'Value cannot be negative'
                                            : null));
                          });
                          if (nameError != null ||
                              investedError != null ||
                              currentError != null) {
                            return;
                          }
                          FocusScope.of(ctx).unfocus();
                          Navigator.pop(ctx, true);
                        },
                        style: FilledButton.styleFrom(
                          backgroundColor: SoftColors.control,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                        child: Text(isEditing ? 'Update' : 'Save Investment'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    ),
  );

  if (ok != true || !context.mounted) return null;
  final name = nameCtrl.text.trim();
  final invested = parseAmountInput(investedCtrl.text) ?? 0;
  final current = parseAmountInput(currentCtrl.text) ?? invested;
  final notes = notesCtrl.text.trim();
  final notifier = ref.read(investmentProvider.notifier);
  try {
    InvestmentHolding result;
    if (existing != null) {
      result = existing.copyWith(
        name: name,
        type: type,
        investedAmount: invested,
        currentValue: current,
        purpose: purpose,
        notes: notes.isEmpty ? null : notes,
        clearNotes: notes.isEmpty,
        accountId: linkedAccountId,
        clearAccountId: linkedAccountId == null,
      );
      await notifier.updateHolding(result);
    } else {
      final links = <String>[];
      if (linkTransaction != null) {
        links.add(linkTransaction.id);
        final rid = linkTransaction.remoteId;
        if (rid != null && rid.isNotEmpty && rid != linkTransaction.id)
          links.add(rid);
      } else if (deduct && bank != null) {
        links.add(
          _recordBankOutflow(
            ref,
            name: name,
            amount: invested,
            account: bank!,
            purpose: purpose,
          ),
        );
      }
      result = await notifier.addHolding(
        name: name,
        type: type,
        investedAmount: invested,
        currentValue: current,
        purpose: purpose,
        notes: notes,
        accountId: linkedAccountId,
        sourceTransactionIds: links,
      );
    }
    if (context.mounted) {
      _toast(
        context,
        isEditing ? 'Investment updated ✨' : 'Investment recorded 🚀',
      );
    }
    return result;
  } catch (e) {
    if (context.mounted)
      _toast(context, 'Could not save investment: $e', error: true);
    return null;
  }
}

/// Invest more / withdraw with inline validation. Withdrawing more than the
/// current value is blocked in the form (and again in the notifier).
Future<void> showInvestWithdrawSheet(
  BuildContext context,
  WidgetRef ref,
  InvestmentHolding holding, {
  required bool isInvest,
}) async {
  final ctrl = TextEditingController();
  final accounts = _fundingAccounts(ref);
  String? bank = accounts.isNotEmpty ? accounts.first : null;
  bool deduct = isInvest && bank != null;
  String? error;
  final fmt = NumberFormat.currency(
    symbol: '₹',
    decimalDigits: 0,
    locale: 'en_IN',
  );

  final ok = await PremiumBottomSheet.show<bool>(
    context: context,
    child: StatefulBuilder(
      builder: (ctx, setModal) {
        final tone = SoftTone(ctx);
        return Padding(
          padding: EdgeInsets.fromLTRB(
            20,
            8,
            20,
            20 + MediaQuery.of(ctx).viewInsets.bottom,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                isInvest ? 'Invest more' : 'Withdraw',
                style: tone.text(18, FontWeight.w800, tone.ink),
              ),
              const SizedBox(height: 4),
              Text(
                '${holding.name} · worth ${fmt.format(holding.currentValue)}',
                style: tone.text(12, FontWeight.w500, tone.slate),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: ctrl,
                autofocus: true,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                style: tone.text(14, FontWeight.w600, tone.ink),
                decoration: investmentInputDecoration(
                  'Amount (₹)',
                  tone,
                ).copyWith(
                  errorText: error,
                  helperText:
                      isInvest
                          ? null
                          : 'Up to ${fmt.format(holding.currentValue)}',
                  helperStyle: tone.text(11, FontWeight.w500, tone.slate),
                ),
                onChanged: (_) {
                  if (error != null) setModal(() => error = null);
                },
              ),
              if (isInvest && bank != null) ...[
                const SizedBox(height: 8),
                Row(
                  children: [
                    Checkbox(
                      value: deduct,
                      activeColor: SoftColors.control,
                      onChanged: (v) => setModal(() => deduct = v ?? false),
                    ),
                    Expanded(
                      child: Text(
                        'Deduct from bank balance',
                        style: tone.text(13, FontWeight.w600, tone.ink),
                      ),
                    ),
                  ],
                ),
                if (deduct)
                  DropdownButtonFormField<String>(
                    initialValue: bank,
                    dropdownColor: tone.card,
                    isExpanded: true,
                    decoration: investmentInputDecoration('Paid from', tone),
                    items: [
                      for (final a in accounts)
                        DropdownMenuItem(
                          value: a,
                          child: Text(
                            a,
                            style: tone.text(13, FontWeight.w600, tone.ink),
                          ),
                        ),
                    ],
                    onChanged: (v) => setModal(() => bank = v),
                  ),
              ],
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  style: FilledButton.styleFrom(
                    backgroundColor: SoftColors.control,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  onPressed: () {
                    final v = parseAmountInput(ctrl.text);
                    String? e;
                    if (v == null) {
                      e = 'Enter a number, e.g. 5,000';
                    } else if (v <= 0) {
                      e = 'Enter amount greater than 0';
                    } else if (!isInvest && v > holding.currentValue + 0.004) {
                      e = 'You can withdraw at most ${fmt.format(holding.currentValue)}';
                    }
                    if (e != null) {
                      setModal(() => error = e);
                      return;
                    }
                    Navigator.pop(ctx, true);
                  },
                  child: Text(isInvest ? 'Add funds' : 'Withdraw'),
                ),
              ),
            ],
          ),
        );
      },
    ),
  );
  if (ok != true || !context.mounted) return;
  final delta = parseAmountInput(ctrl.text) ?? 0;
  final n = ref.read(investmentProvider.notifier);
  try {
    if (isInvest) {
      String? link;
      if (deduct && bank != null) {
        link = _recordBankOutflow(
          ref,
          name: holding.name,
          amount: delta,
          account: bank!,
          purpose: holding.purpose,
        );
      }
      await n.investMore(holding.id, delta, linkTransactionId: link);
    } else {
      await n.withdraw(holding.id, delta);
    }
    if (context.mounted)
      _toast(context, isInvest ? 'Funds added' : 'Withdrawal saved');
  } catch (e) {
    if (context.mounted) _toast(context, 'Could not save: $e', error: true);
  }
}

/// Ledger transactions linked to [holding] (by local id or remote id).
List<model.Transaction> _linkedTransactions(
  WidgetRef ref,
  InvestmentHolding holding,
) {
  final ids = holding.sourceTransactionIds.where((e) => e.isNotEmpty).toSet();
  if (ids.isEmpty) return const [];
  final seen = <String>{};
  return [
    for (final tx in ref.read(model.transactionProvider))
      if ((ids.contains(tx.id) ||
              (tx.remoteId != null && ids.contains(tx.remoteId))) &&
          seen.add(tx.id))
        tx,
  ];
}

/// Confirm + soft delete (deleted_at, synced through the outbox). When the
/// holding has linked bank transactions the user can delete those too, via
/// the normal transaction delete path.
Future<void> confirmDeleteInvestment(
  BuildContext context,
  WidgetRef ref,
  InvestmentHolding holding,
) async {
  final linked = _linkedTransactions(ref, holding);
  var alsoDeleteTx = false;
  final confirmed = await showDialog<bool>(
    context: context,
    builder: (ctx) {
      return StatefulBuilder(
        builder: (ctx, setDialog) {
          final tone = SoftTone(ctx);
          final linkedTotal = linked.fold<double>(0, (s, t) => s + t.amount);
          return AlertDialog(
            backgroundColor: tone.card,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            title: Text(
              'Delete Investment?',
              style: tone.text(18, FontWeight.w800, tone.ink),
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  linked.isEmpty
                      ? 'Remove "${holding.name}" from your portfolio?'
                      : 'Remove "${holding.name}" from your portfolio? Linked bank transactions are kept unless you tick the box below.',
                  style: tone.text(13, FontWeight.w500, tone.slate),
                ),
                if (linked.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  InkWell(
                    borderRadius: BorderRadius.circular(12),
                    onTap: () => setDialog(() => alsoDeleteTx = !alsoDeleteTx),
                    child: Container(
                      padding: const EdgeInsets.fromLTRB(4, 4, 10, 4),
                      decoration: BoxDecoration(
                        color: tone.track,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: tone.border),
                      ),
                      child: Row(
                        children: [
                          Checkbox(
                            value: alsoDeleteTx,
                            activeColor: const Color(0xFFDC2626),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5),
                            ),
                            onChanged:
                                (v) =>
                                    setDialog(() => alsoDeleteTx = v ?? false),
                          ),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Also delete linked bank transaction',
                                  style: tone.text(
                                    13,
                                    FontWeight.w700,
                                    tone.ink,
                                  ),
                                ),
                                Text(
                                  '${linked.length} transaction${linked.length == 1 ? '' : 's'} · ₹${_plain(linkedTotal)}',
                                  style: tone.text(
                                    11,
                                    FontWeight.w500,
                                    tone.slate,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: Text(
                  'Cancel',
                  style: tone.text(14, FontWeight.w600, tone.slate),
                ),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                style: FilledButton.styleFrom(
                  backgroundBuilder: SoftColors.plainBackground,
                  backgroundColor: const Color(0xFFDC2626),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: const Text('Delete'),
              ),
            ],
          );
        },
      );
    },
  );
  if (confirmed != true || !context.mounted) return;
  try {
    await ref.read(investmentProvider.notifier).removeHolding(holding.id);
    if (alsoDeleteTx) {
      final txNotifier = ref.read(model.transactionProvider.notifier);
      for (final tx in linked) {
        txNotifier.removeTransaction(tx.id);
      }
    }
    if (context.mounted) {
      _toast(
        context,
        alsoDeleteTx && linked.isNotEmpty
            ? 'Removed "${holding.name}" and its bank transaction'
            : 'Removed "${holding.name}"',
      );
    }
  } catch (e) {
    if (context.mounted) _toast(context, 'Could not delete: $e', error: true);
  }
}

/// ⋮ menu on investment cards (Investments screen + Wealth page).
class InvestmentCardMenu extends StatelessWidget {
  const InvestmentCardMenu({
    super.key,
    required this.onEdit,
    required this.onDelete,
  });

  final VoidCallback onEdit;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    final tone = SoftTone(context);
    return PopupMenuButton<String>(
      tooltip: 'More',
      icon: Icon(LucideIcons.moreVertical, size: 18, color: tone.slate),
      padding: EdgeInsets.zero,
      splashRadius: 18,
      color: tone.card,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(color: tone.border),
      ),
      onSelected: (v) {
        if (v == 'edit') onEdit();
        if (v == 'delete') onDelete();
      },
      itemBuilder:
          (_) => [
            PopupMenuItem(
              value: 'edit',
              child: Row(
                children: [
                  Icon(LucideIcons.pencil, size: 16, color: tone.ink),
                  const SizedBox(width: 10),
                  Text('Edit', style: tone.text(14, FontWeight.w600, tone.ink)),
                ],
              ),
            ),
            PopupMenuItem(
              value: 'delete',
              child: Row(
                children: [
                  const Icon(
                    LucideIcons.trash2,
                    size: 16,
                    color: Color(0xFFDC2626),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    'Delete',
                    style: tone.text(
                      14,
                      FontWeight.w600,
                      const Color(0xFFDC2626),
                    ),
                  ),
                ],
              ),
            ),
          ],
    );
  }
}
