import 'package:flutter/material.dart';

import '../../../../core/theme/soft_palette.dart';
import '../../../../core/widgets/reference_ui.dart';

class SoftInvestmentCard extends StatelessWidget {
  const SoftInvestmentCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.borderColor,
    this.color,
    this.onTap,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color? borderColor;
  final Color? color;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final card = borderColor != null
        ? Container(
            padding: padding,
            decoration: BoxDecoration(
              color: color ?? (dark ? SoftPalette.darkCard : SoftPalette.card),
              borderRadius: const BorderRadius.all(Radius.circular(18)),
              border: Border.all(color: borderColor!),
            ),
            child: child,
          )
        : SxSoftCard(padding: padding, color: color, child: child);
    if (onTap == null) return card;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: const BorderRadius.all(Radius.circular(18)),
        child: card,
      ),
    );
  }
}

class SoftInvestmentHero extends StatelessWidget {
  const SoftInvestmentHero({
    super.key,
    required this.totalText,
    required this.actions,
  });

  final String totalText;
  final Widget actions;

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return SoftInvestmentCard(
      padding: const EdgeInsets.all(24),
      color: dark ? SoftPalette.darkEmeraldSoft : SoftPalette.emeraldSoft,
      borderColor: (dark ? SoftPalette.darkEmerald : SoftPalette.mint)
          .withValues(alpha: 0.35),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'TOTAL WEALTH',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.2,
              color: dark ? SoftPalette.darkMuted : SoftPalette.muted,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            totalText,
            style: TextStyle(
              fontSize: 36,
              fontWeight: FontWeight.w800,
              letterSpacing: -2,
              color: dark ? SoftPalette.darkInk : SoftPalette.ink,
            ),
          ),
          const SizedBox(height: 24),
          actions,
        ],
      ),
    );
  }
}

class SoftInvestmentProgress extends StatelessWidget {
  const SoftInvestmentProgress({super.key, required this.value});

  final double value;

  @override
  Widget build(BuildContext context) {
    final clamped = value.isNaN ? 0.0 : value.clamp(0.0, 1.0);
    return ClipRRect(
      borderRadius: BorderRadius.circular(999),
      child: LinearProgressIndicator(
        value: clamped,
        minHeight: 6,
        backgroundColor: Theme.of(context).brightness == Brightness.dark
            ? SoftPalette.darkBorder
            : SoftPalette.surfaceVariant,
        valueColor: const AlwaysStoppedAnimation(SoftPalette.emerald),
      ),
    );
  }
}
