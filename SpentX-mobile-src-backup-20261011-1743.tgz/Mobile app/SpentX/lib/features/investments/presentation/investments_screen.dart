import 'package:flutter/material.dart';
import '../../../core/theme/spentx_tokens.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../core/theme/soft_palette.dart';
import 'widgets/soft_investment_widgets.dart';
import 'widgets/investment_form_sheet.dart';
import '../../../core/providers/investment_provider.dart';
import '../../../core/providers/transaction_provider.dart' as model;
import '../../../core/widgets/reference_ui.dart';

class InvestmentsScreen extends ConsumerStatefulWidget {
  const InvestmentsScreen({super.key});

  @override
  ConsumerState<InvestmentsScreen> createState() => _InvestmentsScreenState();
}

class _InvestmentsScreenState extends ConsumerState<InvestmentsScreen> {
  String _fmt(double v) {
    return NumberFormat.currency(
      symbol: '₹',
      decimalDigits: 0,
      locale: 'en_IN',
    ).format(v);
  }

  IconData _iconFor(InvestmentType type) {
    switch (type) {
      case InvestmentType.liquid:
        return LucideIcons.wallet;
      case InvestmentType.mutualFund:
        return LucideIcons.trendingUp;
      case InvestmentType.fixedDeposit:
        return LucideIcons.landmark;
      case InvestmentType.stocks:
        return LucideIcons.lineChart;
      case InvestmentType.bonds:
        return LucideIcons.fileText;
      case InvestmentType.crypto:
        return LucideIcons.bitcoin;
      case InvestmentType.gold:
        return LucideIcons.award;
      case InvestmentType.realEstate:
        return LucideIcons.home;
      case InvestmentType.other:
        return LucideIcons.pieChart;
    }
  }

  Future<void> _launchLink(String url) async {
    try {
      final uri = Uri.parse(url);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      } else {
        if (mounted) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text('Could not open $url')));
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Error opening link: $e')));
      }
    }
  }

  Map<InvestmentType, double> _getBreakdown(List<InvestmentHolding> holdings) {
    final map = <InvestmentType, double>{};
    final total = holdings.fold(0.0, (s, h) => s + h.amount);
    if (total == 0) return map;
    for (final h in holdings) {
      map[h.type] = (map[h.type] ?? 0) + h.amount;
    }
    return map;
  }

  /// Recent expense transactions that look like money going into an
  /// investment and are not linked to a holding yet.
  List<model.Transaction> _detectInvestmentTxs(
    List<model.Transaction> txs,
    Set<String> linked,
  ) {
    return txs
        .where((t) {
          if (!t.isExpense || t.isTransfer || t.isPendingVerification) {
            return false;
          }
          if (linked.contains(t.id) ||
              (t.remoteId != null && linked.contains(t.remoteId))) {
            return false;
          }
          return isInvestmentCategoryName(t.category) ||
              looksLikeInvestmentText('${t.merchant} ${t.note}');
        })
        .take(10)
        .toList();
  }

  void _showHoldingSheet(
    BuildContext context,
    WidgetRef ref, {
    InvestmentHolding? existing,
  }) {
    showInvestmentFormSheet(context, ref, existing: existing);
  }

  Future<void> _confirmDeleteHolding(
    BuildContext ctx,
    InvestmentHolding holding,
  ) => confirmDeleteInvestment(ctx, ref, holding);

  /// Invest / Withdraw from the hero: ask which holding when there are several.
  Future<void> _pickAndInvestWithdraw(
    BuildContext context,
    List<InvestmentHolding> holdings, {
    required bool isInvest,
  }) async {
    if (holdings.isEmpty) return;
    InvestmentHolding? target = holdings.length == 1 ? holdings.first : null;
    target ??= await showDialog<InvestmentHolding>(
      context: context,
      builder:
          (ctx) => SimpleDialog(
            title: Text(isInvest ? 'Invest into' : 'Withdraw from'),
            children: [
              for (final h in holdings)
                SimpleDialogOption(
                  onPressed: () => Navigator.pop(ctx, h),
                  child: Text('${h.name} · ${_fmt(h.currentValue)}'),
                ),
            ],
          ),
    );
    if (target == null || !context.mounted) return;
    await showInvestWithdrawSheet(context, ref, target, isInvest: isInvest);
  }

  /// Allocate a detected transaction: add it to an existing holding (linked
  /// by transaction id, so it is never counted twice) or create a new one.
  void _showAllocateFromSms(
    BuildContext context,
    WidgetRef ref,
    model.Transaction tx,
  ) {
    final holdings = ref.read(investmentProvider);
    if (holdings.isEmpty) {
      showInvestmentFormSheet(context, ref, linkTransaction: tx);
      return;
    }
    showDialog<String>(
      context: context,
      builder:
          (ctx) => SimpleDialog(
            title: Text('Allocate ${_fmt(tx.amount)} from ${tx.merchant}'),
            children: [
              for (final h in holdings)
                SimpleDialogOption(
                  onPressed: () => Navigator.pop(ctx, h.id),
                  child: Text('Add to ${h.name}'),
                ),
              SimpleDialogOption(
                onPressed: () => Navigator.pop(ctx, '__new__'),
                child: const Text('Create a new holding…'),
              ),
            ],
          ),
    ).then((choice) async {
      if (choice == null || !context.mounted) return;
      if (choice == '__new__') {
        await showInvestmentFormSheet(context, ref, linkTransaction: tx);
        return;
      }
      try {
        await ref
            .read(investmentProvider.notifier)
            .investMore(choice, tx.amount, linkTransactionId: tx.id);
        if (!context.mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Allocated to investment')),
        );
      } catch (e) {
        if (!context.mounted) return;
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Could not allocate: $e')));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final holdings = ref.watch(investmentProvider);
    final notifier = ref.read(investmentProvider.notifier);
    final portfolio = notifier.portfolio();
    final total = portfolio.current;
    final flow = notifier.todayFlow();
    final linked = notifier.linkedTransactionIds;

    return Scaffold(
      backgroundColor: isDark ? SoftPalette.darkBg : SoftPalette.bg,
      body: SafeArea(
        child: Column(
          children: [
            SoftPageHeader(
              title: 'Investments',
              trailing: SoftCircleIconButton(
                icon: LucideIcons.plus,
                tooltip: 'Add investment',
                onPressed: () => _showHoldingSheet(context, ref),
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 16),
                    SoftInvestmentCard(
                      padding: const EdgeInsets.all(24),
                      borderColor:
                          isDark
                              ? SoftPalette.darkEmerald.withValues(alpha: 0.35)
                              : SoftPalette.mint.withValues(alpha: 0.35),
                      color:
                          isDark
                              ? SoftPalette.darkEmeraldSoft
                              : SoftPalette.emeraldSoft,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'TOTAL WEALTH',
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w500,
                              letterSpacing: 1.2,
                              color: context.tokens.textSecondary,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            _fmt(total),
                            style: TextStyle(
                              fontSize: 36,
                              fontWeight: FontWeight.w500,
                              letterSpacing: -2,
                              color: Theme.of(context).colorScheme.onSurface,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Invested ${_fmt(portfolio.invested)} · '
                            '${portfolio.gain >= 0 ? '+' : ''}${_fmt(portfolio.gain)} '
                            '(${portfolio.gainPercent.toStringAsFixed(1)}%)',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                              color:
                                  portfolio.gain >= 0
                                      ? SoftPalette.positive
                                      : SoftPalette.negative,
                            ),
                          ),
                          const SizedBox(height: 24),
                          Row(
                            children: [
                              Expanded(
                                child: ElevatedButton.icon(
                                  onPressed:
                                      holdings.isEmpty
                                          ? null
                                          : () => _pickAndInvestWithdraw(
                                            context,
                                            holdings,
                                            isInvest: true,
                                          ),
                                  icon: const Icon(LucideIcons.plus, size: 18),
                                  label: const Text('Invest'),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: OutlinedButton.icon(
                                  onPressed:
                                      holdings.isEmpty
                                          ? null
                                          : () => _pickAndInvestWithdraw(
                                            context,
                                            holdings,
                                            isInvest: false,
                                          ),
                                  icon: const Icon(
                                    LucideIcons.arrowRightLeft,
                                    size: 18,
                                  ),
                                  label: const Text('Withdraw'),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),

                    // SMS Detection for Investments - max integration
                    SoftInvestmentCard(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Icon(
                                LucideIcons.zap,
                                color: SoftPalette.emerald,
                              ),
                              const SizedBox(width: 8),
                              const Text(
                                'SMS DETECTED INVESTMENT TXS',
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 13,
                                ),
                              ),
                              const Spacer(),
                              TextButton(
                                onPressed: () {
                                  // Re-trigger detect
                                  setState(() {});
                                },
                                child: const Text('Refresh Detect'),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Builder(
                            builder: (ctx) {
                              final txs = ref.watch(model.transactionProvider);
                              final detected = _detectInvestmentTxs(
                                txs,
                                linked,
                              );
                              if (detected.isEmpty) {
                                return Text(
                                  'No recent investment-like SMS/tx detected (e.g. groww, zerodha, MF SIP, stocks). Add via manual or wait for bank alerts.',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: context.tokens.textSecondary,
                                  ),
                                );
                              }
                              return Column(
                                children:
                                    detected.map((tx) {
                                      return ListTile(
                                        dense: true,
                                        leading: Icon(
                                          LucideIcons.trendingUp,
                                          color:
                                              tx.isExpense
                                                  ? SoftPalette.negative
                                                  : SoftPalette.positive,
                                        ),
                                        title: Text(
                                          '${tx.merchant} • ₹${tx.amount.toInt()}',
                                        ),
                                        subtitle: Text(
                                          '${tx.date.toString().substring(0, 10)} • ${tx.note.isNotEmpty ? tx.note : tx.paymentType}',
                                        ),
                                        trailing: ElevatedButton(
                                          onPressed: () {
                                            _showAllocateFromSms(ctx, ref, tx);
                                          },
                                          child: const Text(
                                            'Select / Allocate',
                                          ),
                                        ),
                                      );
                                    }).toList(),
                              );
                            },
                          ),
                          const SizedBox(height: 8),
                          Wrap(
                            spacing: 8,
                            children: [
                              ActionChip(
                                avatar: const Icon(
                                  LucideIcons.externalLink,
                                  size: 14,
                                ),
                                label: const Text('Open Groww'),
                                onPressed:
                                    () => _launchLink('https://groww.in/'),
                              ),
                              ActionChip(
                                avatar: const Icon(
                                  LucideIcons.externalLink,
                                  size: 14,
                                ),
                                label: const Text('Zerodha Coin'),
                                onPressed:
                                    () => _launchLink(
                                      'https://coin.zerodha.com/',
                                    ),
                              ),
                              ActionChip(
                                avatar: const Icon(
                                  LucideIcons.externalLink,
                                  size: 14,
                                ),
                                label: const Text('Upstox'),
                                onPressed:
                                    () => _launchLink('https://upstox.com/'),
                              ),
                              ActionChip(
                                avatar: const Icon(
                                  LucideIcons.externalLink,
                                  size: 14,
                                ),
                                label: const Text('MF Central'),
                                onPressed:
                                    () => _launchLink(
                                      'https://www.mfcentral.com/',
                                    ),
                              ),
                            ],
                          ),
                          Text(
                            'Tip: Detected txs from SMS (bank alerts to investment apps) can be allocated to holdings above. Max detection via auto SMS + manual txs.',
                            style: TextStyle(
                              fontSize: 11,
                              color: context.tokens.textSecondary,
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 24),

                    // Additional feature: Portfolio Breakdown by type (support for multiple holding types)
                    if (holdings.isNotEmpty)
                      SoftInvestmentCard(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'PORTFOLIO BREAKDOWN',
                              style: TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: 13,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Builder(
                              builder: (_) {
                                final breakdown = _getBreakdown(holdings);
                                final total = holdings.fold(
                                  0.0,
                                  (s, h) => s + h.amount,
                                );
                                return Column(
                                  children:
                                      breakdown.entries.map((e) {
                                        final pct =
                                            total > 0
                                                ? (e.value / total * 100)
                                                : 0;
                                        return Padding(
                                          padding: const EdgeInsets.symmetric(
                                            vertical: 4,
                                          ),
                                          child: Row(
                                            children: [
                                              SizedBox(
                                                width: 80,
                                                child: Text(
                                                  e.key.label,
                                                  style: const TextStyle(
                                                    fontSize: 12,
                                                  ),
                                                ),
                                              ),
                                              Expanded(
                                                child: LinearProgressIndicator(
                                                  value: pct / 100,
                                                  backgroundColor:
                                                      isDark
                                                          ? SoftPalette
                                                              .darkBorder
                                                          : null,
                                                  valueColor:
                                                      const AlwaysStoppedAnimation(
                                                        SoftPalette.emerald,
                                                      ),
                                                ),
                                              ),
                                              const SizedBox(width: 8),
                                              Text(
                                                '${pct.toStringAsFixed(0)}% (${_fmt(e.value)})',
                                                style: const TextStyle(
                                                  fontSize: 11,
                                                ),
                                              ),
                                            ],
                                          ),
                                        );
                                      }).toList(),
                                );
                              },
                            ),
                          ],
                        ),
                      ),

                    const SizedBox(height: 24),
                    ...holdings.map(
                      (h) => Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: GestureDetector(
                          onTap:
                              () =>
                                  _showHoldingSheet(context, ref, existing: h),
                          onLongPress:
                              () => showInvestWithdrawSheet(
                                context,
                                ref,
                                h,
                                isInvest: true,
                              ),
                          child: _AssetCard(
                            title:
                                '${h.name} · invested ${_fmt(h.investedAmount)}',
                            amount: _fmt(h.currentValue),
                            growth:
                                '${h.gainPercent >= 0 ? '+' : ''}${h.gainPercent.toStringAsFixed(1)}%',
                            isGain: h.gain >= 0,
                            icon: _iconFor(h.type),
                            isDark: isDark,
                            onEdit:
                                () => _showHoldingSheet(
                                  context,
                                  ref,
                                  existing: h,
                                ),
                            onDelete: () => _confirmDeleteHolding(context, h),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 28),
                    Text(
                      "Today's Flow",
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 16),
                    _FlowRow(
                      label: 'Income',
                      amount: _fmt(flow.income),
                      icon: LucideIcons.arrowDownLeft,
                      color: SoftPalette.positive,
                      isDark: isDark,
                    ),
                    const SizedBox(height: 10),
                    _FlowRow(
                      label: 'Expenses',
                      amount: _fmt(flow.expense),
                      icon: LucideIcons.arrowUpRight,
                      color: SoftPalette.negative,
                      isDark: isDark,
                    ),
                    const SizedBox(height: 80),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _AssetCard extends StatelessWidget {
  final String title, amount, growth;
  final IconData icon;
  final bool isDark;
  final bool isGain;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const _AssetCard({
    required this.title,
    required this.amount,
    required this.growth,
    this.isGain = true,
    required this.icon,
    required this.isDark,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return SoftInvestmentCard(
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: SoftPalette.emerald.withValues(alpha: 0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: SoftPalette.emerald, size: 20),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 12,
                    color: context.tokens.textSecondary,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  amount,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w500,
                    color: Theme.of(context).colorScheme.onSurface,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: (isGain ? SoftPalette.positive : SoftPalette.negative)
                  .withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  isGain ? LucideIcons.trendingUp : LucideIcons.trendingDown,
                  color: isGain ? SoftPalette.positive : SoftPalette.negative,
                  size: 12,
                ),
                const SizedBox(width: 4),
                Text(
                  growth,
                  style: TextStyle(
                    color: isGain ? SoftPalette.positive : SoftPalette.negative,
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          InvestmentCardMenu(onEdit: onEdit, onDelete: onDelete),
        ],
      ),
    );
  }
}

class _FlowRow extends StatelessWidget {
  final String label, amount;
  final IconData icon;
  final Color color;
  final bool isDark;

  const _FlowRow({
    required this.label,
    required this.amount,
    required this.icon,
    required this.color,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    return SoftInvestmentCard(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: color, size: 18),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w500,
                color: Theme.of(context).colorScheme.onSurface,
              ),
            ),
          ),
          Text(
            amount,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}
