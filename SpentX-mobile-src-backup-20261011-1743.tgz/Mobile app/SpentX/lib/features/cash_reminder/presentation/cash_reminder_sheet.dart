import 'package:flutter/material.dart';
import '../../../core/theme/spentx_tokens.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../../core/theme/soft_palette.dart';

class CashReminderSheet extends StatelessWidget {
  const CashReminderSheet({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 16, 24, 24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: SoftPalette.warning.withValues(alpha: 0.12),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              LucideIcons.coins,
              color: SoftPalette.warning,
              size: 28,
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'Daily Cash Entry',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: SoftPalette.ink,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            "Did you spend cash today? Let's keep track.",
            style: const TextStyle(fontSize: 13, color: SoftPalette.muted),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 28),
          TextField(
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            style: TextStyle(
              fontSize: 36,
              fontWeight: FontWeight.w500,
              letterSpacing: -2,
              color: SoftPalette.ink,
            ),
            textAlign: TextAlign.center,
            decoration: InputDecoration(
              prefixText: '₹ ',
              prefixStyle: const TextStyle(
                fontSize: 36,
                fontWeight: FontWeight.w500,
                color: SoftPalette.warning,
              ),
              hintText: '0',
              hintStyle: TextStyle(color: context.tokens.textSecondary),
              border: InputBorder.none,
              fillColor: Colors.transparent,
              filled: true,
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            decoration: InputDecoration(
              hintText: 'What did you spend on?',
              prefixIcon: Icon(
                LucideIcons.edit3,
                size: 18,
                color: context.tokens.textSecondary,
              ),
            ),
          ),
          const SizedBox(height: 28),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('No Cash Spent'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: SoftColors.control,
                    foregroundColor: Colors.white,
                  ),
                  child: const Text('Save'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
