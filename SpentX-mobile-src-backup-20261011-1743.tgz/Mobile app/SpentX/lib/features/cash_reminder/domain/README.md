# cash_reminder domain — migrate entities from lib/models + core/providers here
