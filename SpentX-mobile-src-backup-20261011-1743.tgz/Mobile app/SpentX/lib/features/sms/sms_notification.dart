import 'dart:convert';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../../core/services/pending_verification_history_service.dart';
import '../../core/debug/master_debug_log.dart';
import 'sms_notification_copy.dart';

class SmsNotificationService {
  static final FlutterLocalNotificationsPlugin _notificationsPlugin = FlutterLocalNotificationsPlugin();
  static Function(String)? _onNotificationTap;

  static bool get _autoDetectionOn =>
      Hive.isBoxOpen('settings') &&
      Hive.box('settings').get('auto_detection', defaultValue: true) == true;

  /// One tray slot per SMS. Native [SmsNotificationListenerService] uses the
  /// same FNV-1a 32-bit of the trimmed message, so the second post replaces
  /// the first instead of stacking a second notification for one spend.
  static int notificationIdForSms(String rawMessage) {
    var hash = 0x811C9DC5;
    for (final b in utf8.encode(rawMessage.trim())) {
      hash ^= b;
      hash = (hash * 0x01000193) & 0xFFFFFFFF;
    }
    return hash & 0x7FFFFFFF;
  }

  static int _notificationId({String? rawMessage, String? transactionId}) {
    final sms = rawMessage?.trim();
    if (sms != null && sms.isNotEmpty) return notificationIdForSms(sms);
    if (transactionId != null) return transactionId.hashCode & 0x7FFFFFFF;
    return DateTime.now().millisecondsSinceEpoch % 100000;
  }

  static Future<void> init(Function(String) onNotificationTap) async {
    _onNotificationTap = onNotificationTap;
    
    const AndroidInitializationSettings initializationSettingsAndroid = AndroidInitializationSettings('@mipmap/ic_launcher');
    const darwinSettings = DarwinInitializationSettings(
      requestAlertPermission: false,
      requestBadgePermission: false,
      requestSoundPermission: false,
    );
    const InitializationSettings initializationSettings = InitializationSettings(
      android: initializationSettingsAndroid,
      iOS: darwinSettings,
      macOS: darwinSettings,
    );
    
    await _notificationsPlugin.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse: (NotificationResponse response) {
        if (response.payload != null && _onNotificationTap != null) {
          _onNotificationTap!(response.payload!);
        }
      },
    );
  }

  /// Pending verification — unknown / first-time merchant (incl. first ATM per bank).
  static Future<void> showPendingNotification({
    required double amount,
    required String merchant,
    required String bank,
    required String type,
    String? payload,
    String? transactionId,
    String? titleOverride,
    String? bodyOverride,
    String? rawMessage,
  }) async {
    if (!_autoDetectionOn) return;

    final copy = SmsNotificationCopy.build(
      type: type,
      amount: amount,
      merchantExists: false,
      merchantTitle: null,
      payee: merchant.isNotEmpty ? merchant : null,
      bank: bank,
    );
    // Never allow empty body — Android often shows only the title then.
    final title = titleOverride ?? copy.title;
    final body = (bodyOverride != null && bodyOverride.trim().isNotEmpty)
        ? bodyOverride.trim()
        : (copy.body.isNotEmpty
            ? copy.body
            : '${merchant.isNotEmpty ? merchant : 'Unknown payee'} • ${bank.isNotEmpty ? bank : 'Bank'}');

    final notificationDetails = NotificationDetails(
      android: AndroidNotificationDetails(
        'sms_transactions',
        'SMS Transactions',
        channelDescription: 'Notifications for auto-detected SMS transactions',
        importance: Importance.max,
        priority: Priority.high,
        styleInformation: BigTextStyleInformation(body),
      ),
    );

    final int notifId = _notificationId(
      rawMessage: rawMessage,
      transactionId: transactionId,
    );

    final String finalPayload = (payload != null && payload.isNotEmpty)
        ? payload
        : (transactionId != null
            ? jsonEncode({'transactionId': transactionId, 'pending': true})
            : 'sms_detected');

    await _notificationsPlugin.show(
      notifId,
      title,
      body,
      notificationDetails,
      payload: finalPayload,
    );

    if (transactionId != null && transactionId.isNotEmpty) {
      await PendingVerificationHistoryService.recordPending(
        transactionId: transactionId,
        amount: amount,
        merchant: merchant,
        bank: bank,
        type: type,
        notificationShown: true,
      );
    }

    await MasterDebugLog.notification(
      title: 'Notification Displayed',
      message: '$title — $body',
      payload: {'transactionId': transactionId, 'type': type, 'pending': true},
    );
  }

  /// Shows a type-aware notification for a detected transaction.
  /// [type] must be one of: 'debit', 'credit', 'transfer'
  static Future<void> showTransactionDetected({
    required double amount,
    required String merchant,
    required String bank,
    required String type,
    String? payload,
    String? transactionId,
    bool pending = true,
    String? rawMessage,
  }) async {
    if (!_autoDetectionOn) return;
    // Pass payee/merchant so body is not empty (amount-only notification bug).
    final copy = SmsNotificationCopy.build(
      type: type,
      amount: amount,
      merchantExists: !pending && merchant.trim().isNotEmpty,
      merchantTitle: !pending ? merchant : null,
      payee: merchant.isNotEmpty ? merchant : null,
      bank: bank,
    );
    final title = copy.title;
    final body = copy.body.isNotEmpty
        ? copy.body
        : '${merchant.isNotEmpty ? merchant : 'Unknown payee'} • ${bank.isNotEmpty ? bank : 'Bank'}';

    final notificationDetails = NotificationDetails(
      android: AndroidNotificationDetails(
        'sms_transactions',
        'SMS Transactions',
        channelDescription: 'Notifications for auto-detected SMS transactions',
        importance: Importance.max,
        priority: Priority.high,
        styleInformation: BigTextStyleInformation(body),
      ),
    );

    final int notifId = _notificationId(
      rawMessage: rawMessage,
      transactionId: transactionId,
    );

    final String finalPayload = (payload != null && payload.isNotEmpty)
        ? payload
        : (transactionId != null
            ? jsonEncode({'transactionId': transactionId, 'pending': pending})
            : 'sms_detected');

    await _notificationsPlugin.show(
      notifId,
      title,
      body,
      notificationDetails,
      payload: finalPayload,
    );
  }

  static Future<void> showTransactionAutoAdded({
    required double amount,
    required String merchant,
    required String bank,
    required String type,
    String? outingTitle,
    String? transactionId,
    String? titleOverride,
    String? bodyOverride,
    String? rawMessage,
  }) async {
    if (!_autoDetectionOn) return;
    final copy = SmsNotificationCopy.build(
      type: type,
      amount: amount,
      merchantExists: true,
      merchantTitle: merchant,
      payee: null,
      bank: bank,
      outingTitle: outingTitle,
    );
    final title = titleOverride ?? copy.title;
    final body = (bodyOverride != null && bodyOverride.trim().isNotEmpty)
        ? bodyOverride.trim()
        : (copy.body.isNotEmpty
            ? copy.body
            : '${merchant.isNotEmpty ? merchant : 'Merchant'} • ${bank.isNotEmpty ? bank : 'Bank'}');

    // Same channel + id as pending notifications so native "Verify" is replaced
    // by "Added" when Flutter processes a known merchant (one notification per SMS).
    final notificationDetails = NotificationDetails(
      android: AndroidNotificationDetails(
        'sms_transactions',
        'SMS Transactions',
        channelDescription: 'Notifications for auto-detected SMS transactions',
        importance: Importance.max,
        priority: Priority.high,
        styleInformation: BigTextStyleInformation(body),
      ),
    );

    final int notifId = _notificationId(
      rawMessage: rawMessage,
      transactionId: transactionId,
    );

    final String finalPayload = transactionId != null
        ? jsonEncode({'transactionId': transactionId, 'pending': false})
        : 'sms_auto_added';

    await _notificationsPlugin.show(
      notifId,
      title,
      body,
      notificationDetails,
      payload: finalPayload,
    );
  }

  /// Notification for unknown merchant auto-added to outing (needs verification later)
  static Future<void> showOutingPendingVerification({
    required double amount,
    required String merchant,
    required String outingTitle,
    required String bank,
    required String type,
    String? payload,
    String? transactionId,
    String? rawMessage,
  }) async {
    if (!_autoDetectionOn) return;
    final copy = SmsNotificationCopy.build(
      type: type,
      amount: amount,
      merchantExists: false,
      merchantTitle: null,
      payee: merchant,
      bank: bank,
    );
    final title = copy.title;
    final body = copy.body;

    const AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      'sms_transactions_outing',
      'Outing Transactions',
      channelDescription: 'Notifications for transactions auto-added to outings',
      importance: Importance.high,
      priority: Priority.high,
    );

    const NotificationDetails notificationDetails = NotificationDetails(android: androidDetails);

    final int notifId = _notificationId(
      rawMessage: rawMessage,
      transactionId: transactionId,
    );

    final String finalPayload = (payload != null && payload.isNotEmpty)
        ? payload
        : (transactionId != null
            ? jsonEncode({'transactionId': transactionId, 'pending': true})
            : 'outing_pending_verify');

    await _notificationsPlugin.show(
      notifId,
      title,
      body,
      notificationDetails,
      payload: finalPayload,
    );
  }

  static Future<void> simulateSmsDetection() async {
    await showPendingNotification(
      amount: 500.0,
      merchant: 'Sample Payee',
      bank: 'HDFC',
      type: 'debit',
      payload: '{"amount": 500.0, "merchant": "Sample Payee", "bank": "HDFC", "type": "debit"}',
    );
  }

  /// Cancels / dismisses all active system notifications from the phone status bar when user opens or enters the app.
  static Future<void> cancelAllNotifications() async {
    try {
      await _notificationsPlugin.cancelAll();
      await MasterDebugLog.notification(
        title: 'All Notifications Cleared',
        message: 'System notifications dismissed as user entered app',
      );
    } catch (_) {}
  }
}
