import 'package:flutter/services.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../core/services/auth_service.dart';
import '../../core/services/device_user_state.dart';
import '../sms_parser/models/transaction_parsed.dart';
import 'detected/sms_detection_pipeline.dart';

/// Listens for inbound SMS via EventChannel (native [SmsReceiver]) and processes
/// through [SmsDetectionPipeline] — same engine as SMS Detection Lab.
class SmsService {
  static const activityStartKey = 'sms_activity_started_at';
  static const EventChannel _channel = EventChannel('com.spentx.app/sms');
  static const MethodChannel _permissionsChannel = MethodChannel(
    'com.spentx.app/permissions',
  );

  static bool _initialized = false;

  static void init() {
    if (_initialized) return;
    _initialized = true;

    _channel.receiveBroadcastStream().listen((dynamic event) {
      if (!SmsDetectionPipeline.isAutoDetectionEnabled) return;
      if (event is Map) {
        final body = event['body'] as String?;
        final sender = event['sender'] as String?;
        if (body != null && body.trim().isNotEmpty) {
          SmsDetectionPipeline.processInbound(
            rawMessage: body,
            sender: sender,
            source: SmsDetectionSource.smsBroadcast,
          );
        }
      }
    });

    _flushPendingFromNative();
  }

  /// SMS queued while app was killed / Flutter engine not ready.
  static Future<void> _flushPendingFromNative() async {
    try {
      final List<dynamic>? pending = await _permissionsChannel
          .invokeMethod<List<dynamic>>('getPendingSms');
      if (pending == null || pending.isEmpty) return;

      final process = SmsDetectionPipeline.isAutoDetectionEnabled;
      for (final item in pending) {
        if (item is! Map) continue;
        if (!process) continue;
        final body = item['body'] as String? ?? '';
        final sender = item['sender'] as String?;
        if (body.trim().isEmpty) continue;
        final ts = item['timestamp'];
        await SmsDetectionPipeline.processInbound(
          rawMessage: body,
          sender: sender,
          source: SmsDetectionSource.pendingFlush,
          receivedAt:
              ts is int && ts > 0
                  ? DateTime.fromMillisecondsSinceEpoch(ts)
                  : null,
        );
      }
    } catch (_) {}
  }

  static Future<bool> requestPermissions() async {
    final smsStatus = await Permission.sms.request();
    final notificationStatus = await Permission.notification.request();
    return smsStatus.isGranted && notificationStatus.isGranted;
  }

  /// Boundary for SMS import (the inbox catch-up never reads older texts).
  ///
  /// Kept per user in [DeviceUserState], which survives the logout wipe, so
  /// signing out and back in does not move it forward and hide the last few
  /// days. With no record on this phone (first use, reinstall) an existing
  /// account starts at the catch-up window (3 days) or its creation time,
  /// whichever is later; messages from before the account existed are never
  /// imported.
  static Future<DateTime> ensureActivityStartTime() async {
    final box = Hive.box('settings');
    final uid = AuthService.currentUserId;
    final existing = DateTime.tryParse(
      box.get(activityStartKey)?.toString() ?? '',
    );
    if (existing != null) {
      if (uid != null)
        await DeviceUserState.rememberSmsActivityStart(uid, existing);
      return existing;
    }
    DateTime? start =
        uid == null ? null : await DeviceUserState.smsActivityStart(uid);
    if (start == null) {
      final now = DateTime.now();
      start = now;
      final created = AuthService.currentUserCreatedAt?.toLocal();
      if (uid != null && created != null && created.isBefore(now)) {
        final floor = now.subtract(catchUpWindow);
        start = created.isAfter(floor) ? created : floor;
      }
    }
    await box.put(activityStartKey, start.toIso8601String());
    if (uid != null) await DeviceUserState.rememberSmsActivityStart(uid, start);
    return start;
  }

  /// Same window as SmsInboxCatchUp.lookback.
  static const catchUpWindow = Duration(days: 3);

  static DateTime? activityStartTime() {
    if (!Hive.isBoxOpen('settings')) return null;
    return DateTime.tryParse(
      Hive.box('settings').get(activityStartKey)?.toString() ?? '',
    );
  }

  /// Inbox messages (newest first), read natively from content://sms/inbox.
  ///
  /// Returns nothing unless READ_SMS is already granted — this never asks for
  /// the permission. [since] limits the read to messages received after that
  /// moment (the inbox catch-up passes the last 3 days); [limit] caps rows.
  static Future<List<({String body, String sender, DateTime date})>>
  readInboxRaw({DateTime? since, int limit = 500}) async {
    try {
      if (!await Permission.sms.isGranted) return const [];
      final List<dynamic>? messages = await _permissionsChannel.invokeMethod(
        'getInboxSms',
        {'sinceMillis': since?.millisecondsSinceEpoch ?? 0, 'limit': limit},
      );
      if (messages == null) return const [];
      final rows = <({String body, String sender, DateTime date})>[];
      for (final msg in messages) {
        if (msg is! Map) continue;
        final body = (msg['body'] as String? ?? '').trim();
        if (body.isEmpty) continue;
        final timestamp = msg['date'];
        rows.add((
          body: body,
          sender: msg['sender'] as String? ?? '',
          date: DateTime.fromMillisecondsSinceEpoch(
            timestamp is int ? timestamp : 0,
          ),
        ));
      }
      return rows;
    } catch (_) {
      return const [];
    }
  }

  /// Developer-only inbox access for the Real-Time SMS Test screen. This is
  /// deliberately separate from the app's live detection path, so old device
  /// messages can be inspected for parser testing without becoming activity
  /// or transaction records.
  static Future<List<({String body, String sender, DateTime date})>>
  readInboxRawForDeveloperTest() async {
    try {
      final List<dynamic>? messages = await _permissionsChannel.invokeMethod(
        'getDeveloperInboxSms',
      );
      if (messages == null) return const [];

      final rows = <({String body, String sender, DateTime date})>[];
      for (final msg in messages) {
        if (msg is! Map) continue;
        final body = (msg['body'] as String? ?? '').trim();
        if (body.isEmpty) continue;
        final sender = msg['sender'] as String? ?? '';
        final timestamp = msg['date'] as int? ?? 0;
        rows.add((
          body: body,
          sender: sender,
          date: DateTime.fromMillisecondsSinceEpoch(timestamp),
        ));
      }
      return rows;
    } catch (_) {
      return const [];
    }
  }

  /// Compatibility API for removed inbox tools. It never reads historical
  /// messages; callers must use the live receiver/pending queue instead.
  static Future<List<TransactionParsed>> readInbox({DateTime? since}) async {
    return const [];
  }

  /// Re-process any SMS queued natively (e.g. after resume). Always drains; processes only if auto detection is on.
  static Future<void> flushPendingQueue() => _flushPendingFromNative();
}
