/// SpentX background SMS + Merchant pipeline
///
/// ## Architecture
///
/// ```
/// ┌─────────────────────────────────────────────────────────────────────┐
/// │ ANDROID (runs when app killed / background)                         │
/// ├─────────────────────────────────────────────────────────────────────┤
/// │ SmsReceiver          → SmsPendingQueue (raw SMS body)               │
/// │ NotificationListener → TransactionPendingQueue (parsed JSON)        │
/// │                      → System notification (Verify → Added)           │
/// └─────────────────────────────────────────────────────────────────────┘
///                                    │
///                                    ▼
/// ┌─────────────────────────────────────────────────────────────────────┐
/// │ WORKMANAGER (Dart isolate, no UI)                                 │
/// │ BackgroundSmsProcessor.processAllQueued()                           │
/// │   • Parse via bank_sms_templates_v4.json                            │
/// │   • MerchantMatchResolver (normalized payee)                          │
/// │   • Known payee  → auto-add Transaction to Hive                     │
/// │   • New payee    → PendingTransaction (never auto-add)              │
/// └─────────────────────────────────────────────────────────────────────┘
///                                    │
///                                    ▼
/// ┌─────────────────────────────────────────────────────────────────────┐
/// │ APP OPEN / NOTIFICATION TAP (Flutter UI)                            │
/// │ PendingVerificationBootstrap → Verification Popup (new payees)      │
/// │ DetectedSmsScreen            → Pending list + Verify button         │
/// │ NotificationClickHandler     → Opens exact pending by transactionId │
/// └─────────────────────────────────────────────────────────────────────┘
/// ```
///
/// ## Merchant rules (background)
/// | Payee state   | Background action              | Notification                    |
/// |---------------|------------------------------|---------------------------------|
/// | New (unknown) | PendingTransaction only      | Spent ₹X - Verify • payee • bank |
/// | Known         | Auto-add Transaction to Hive | Spent ₹X - Added • title • bank  |
///
/// ## Key files
/// - [BackgroundSmsProcessor] — headless queue drain
/// - [BackgroundSmsScheduler] — WorkManager registration
/// - [AutoRuleEngine] — merchant match + auto vs pending branch
/// - [SmsPendingService] — Hive pending store + notification tap target
/// - [MerchantMatchResolver] / [MerchantLearningService] — normalized payee DB
/// - [SmsNotificationCopy] — notification title/body for new vs known
/// - [PendingVerificationPresenter] — verification bottom sheet coordinator
/// - [NotificationClickHandler] — routes notification tap → verify popup
///
/// Kotlin: `android/.../NotificationListenerService.kt`, `SmsReceiver.kt`
library;

export 'background_sms_processor.dart';
export 'background_sms_scheduler.dart';