import 'package:workmanager/workmanager.dart';

import 'workmanager_entrypoint.dart';

/// Registers WorkManager tasks that:
/// 1) drain native SMS queues into Hive (no network needed)
/// 2) push local offline data (transactions, etc.) to Supabase when online
///
/// Native listeners ([SmsReceiver], [NotificationListenerService]) queue payloads
/// when the app is killed. WorkManager wakes a Dart isolate periodically (or on
/// demand) without opening the UI.
class BackgroundSmsScheduler {
  BackgroundSmsScheduler._();

  static const taskProcessQueue = 'spentx.processSmsQueue';
  static const taskSyncData = 'spentx.syncDataQueue';
  static const _periodicUniqueName = 'spentx.smsQueuePeriodic';
  static const _periodicSyncName = 'spentx.dataSyncPeriodic';

  static bool _initialized = false;

  static Future<void> initialize({bool isDebug = false}) async {
    if (_initialized) return;
    await Workmanager().initialize(
      smsWorkmanagerCallbackDispatcher,
      isInDebugMode: isDebug,
    );
    _initialized = true;
    await registerPeriodic();
  }

  /// Minimum interval on Android is 15 minutes.
  static Future<void> registerPeriodic() async {
    await Workmanager().registerPeriodicTask(
      _periodicUniqueName,
      taskProcessQueue,
      frequency: const Duration(minutes: 15),
      constraints: Constraints(
        networkType: NetworkType.not_required,
      ),
      existingWorkPolicy: ExistingWorkPolicy.keep,
    );
    // Offline → server push even when the app UI is closed.
    await Workmanager().registerPeriodicTask(
      _periodicSyncName,
      taskSyncData,
      frequency: const Duration(minutes: 15),
      constraints: Constraints(
        networkType: NetworkType.connected,
      ),
      existingWorkPolicy: ExistingWorkPolicy.keep,
    );
  }

  /// Cancels every scheduled task. Called on sign-out so a logged-out device
  /// never wakes an isolate to drain SMS or push data.
  static Future<void> cancelAll() async {
    if (!_initialized) return;
    try {
      await Workmanager().cancelAll();
    } catch (_) {
      // Nothing scheduled / platform not ready — nothing to stop.
    }
  }

  /// Run as soon as possible — e.g. after app pauses or native queues a payload.
  static Future<void> enqueueImmediate() async {
    if (!_initialized) return;
    await Workmanager().registerOneOffTask(
      'spentx.smsOnce',
      taskProcessQueue,
      existingWorkPolicy: ExistingWorkPolicy.keep,
      constraints: Constraints(networkType: NetworkType.not_required),
    );
    // Also try data push once connectivity is available.
    await Workmanager().registerOneOffTask(
      'spentx.syncOnce',
      taskSyncData,
      existingWorkPolicy: ExistingWorkPolicy.keep,
      constraints: Constraints(networkType: NetworkType.connected),
    );
  }

  /// Schedule a one-shot online push (after offline add / app pause).
  static Future<void> enqueueDataSync() async {
    if (!_initialized) return;
    await Workmanager().registerOneOffTask(
      'spentx.syncOnce',
      taskSyncData,
      existingWorkPolicy: ExistingWorkPolicy.keep,
      constraints: Constraints(networkType: NetworkType.connected),
    );
  }
}