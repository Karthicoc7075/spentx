import 'package:workmanager/workmanager.dart';

import '../../../core/sync/background_data_sync.dart';
import 'background_sms_processor.dart';
import 'background_sms_scheduler.dart';

/// Top-level WorkManager callback — must live in a separate library entry point.
@pragma('vm:entry-point')
void smsWorkmanagerCallbackDispatcher() {
  Workmanager().executeTask((taskName, inputData) async {
    if (taskName == BackgroundSmsScheduler.taskProcessQueue) {
      return BackgroundSmsProcessor.processAllQueued();
    }
    if (taskName == BackgroundSmsScheduler.taskSyncData) {
      // Push offline changes, then pull: server deletes clear local,
      // ~1 month window only, no stale wrong data.
      return BackgroundDataSync.runFullBackgroundSync();
    }
    return false;
  });
}