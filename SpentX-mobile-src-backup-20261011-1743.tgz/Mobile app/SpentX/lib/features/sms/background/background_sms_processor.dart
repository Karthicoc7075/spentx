import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/services/auto_detection_native_sync.dart';

import '../core/sms_pending_service.dart';
import '../detected/auto_rule_engine.dart';
import '../detected/sms_background_init.dart';
import '../detected/sms_detection_pipeline.dart';
import '../v4/bank_sms_v4_parser.dart';
import '../v4/merchant_learning_service.dart';
import '../../../data/local/hive_service.dart';

/// Headless processor for queued SMS / notification payloads.
///
/// Runs inside WorkManager isolate (no UI). Responsibilities:
/// - Drain native [TransactionPendingQueue] + [SmsPendingQueue]
/// - **Known merchant** → auto-add transaction to Hive
/// - **New payee** → save [PendingTransaction] (never auto-add in background)
class BackgroundSmsProcessor {
  BackgroundSmsProcessor._();

  static const MethodChannel _permissionsChannel =
      MethodChannel('com.spentx.app/permissions');

  /// Process all native-queued payloads. Returns true when finished (even if empty).
  static Future<bool> processAllQueued() async {
    await SmsBackgroundInit.ensureReady();
    final prefs = await SharedPreferences.getInstance();
    // Preference flags default to on and are not proof of a session.
    final signedIn = prefs.getBool(AutoDetectionNativeSync.sessionPrefKey) ?? false;
    // Supabase is not initialised in this isolate, so the pipeline cannot see
    // the session itself. The native flag above is the proof of sign-in.
    SmsDetectionPipeline.backgroundSessionVerified = signedIn;
    if (!signedIn) {
      try {
        await _permissionsChannel.invokeMethod<bool>('clearSecureQueues');
      } catch (_) {}
      // Delete leftover plaintext keys. Do not read them.
      await prefs.remove('native_sms_queue');
      await prefs.remove('native_tx_queue');
      return true;
    }
    if (Hive.isBoxOpen('settings') &&
        Hive.box('settings').get('account_switch_sync_hold') == true) {
      return true;
    }

    await MerchantLearningService.ensureOpen();
    await BankSmsV4Parser.ensureLoaded();

    if (!Hive.isBoxOpen('settings')) {
      await SecureHive.openBox('settings');
    }
    final autoOn = Hive.box('settings').get('auto_detection', defaultValue: true) == true;
    if (!autoOn) return true;

    await _processTransactionPayloads();
    await _processRawSmsPayloads();
    SmsPendingService.reconcile();
    return true;
  }

  /// Payloads from [NotificationListenerService] (JSON with amount/merchant/bank/rawText).
  ///
  /// Drained through the permissions channel. The background Flutter engine
  /// (SpentXBackgroundWorker) registers that channel and reads the encrypted
  /// queue. There is no plaintext SharedPreferences fallback.
  static Future<void> _processTransactionPayloads() async {
    // SpentXBackgroundWorker registers this channel on the killed-app engine
    // and decrypts SecureQueueStore there. No plaintext SharedPreferences copy.
    try {
      final List<dynamic>? pending = await _permissionsChannel
          .invokeMethod<List<dynamic>>('getPendingTransactionPayloads');
      if (pending == null) return;
      for (final item in pending) {
        if (item is! String || item.isEmpty) continue;
        final map = Map<String, dynamic>.from(jsonDecode(item) as Map);
        AutoRuleEngine.handleNativePayload(map);
      }
    } catch (_) {}
  }

  /// Raw SMS bodies from [SmsReceiver] when Flutter engine was not ready.
  static Future<void> _processRawSmsPayloads() async {
    // Same secure channel as transaction payloads. Plaintext key fallback removed.
    try {
      final List<dynamic>? pending =
          await _permissionsChannel.invokeMethod<List<dynamic>>('getPendingSms');
      if (pending == null) return;
      for (final item in pending) {
        if (item is! Map) continue;
        final body = item['body'] as String? ?? '';
        final sender = item['sender'] as String?;
        if (body.trim().isEmpty) continue;
        final ts = item['timestamp'];
        final receivedAt = ts is int && ts > 0
            ? DateTime.fromMillisecondsSinceEpoch(ts)
            : null;

        await SmsDetectionPipeline.processInbound(
          rawMessage: body,
          sender: sender,
          source: SmsDetectionSource.pendingFlush,
          receivedAt: receivedAt,
        );
      }
    } catch (_) {}
  }
}
