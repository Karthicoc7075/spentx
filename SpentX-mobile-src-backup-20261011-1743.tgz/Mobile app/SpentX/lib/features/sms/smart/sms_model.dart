class SmartSms {
  final String amount;
  final String bank;
  final String account;
  final String receiver;
  final String date;
  final String rawMessage;

  SmartSms({
    required this.amount,
    required this.bank,
    required this.account,
    required this.receiver,
    required this.date,
    required this.rawMessage,
  });
}
