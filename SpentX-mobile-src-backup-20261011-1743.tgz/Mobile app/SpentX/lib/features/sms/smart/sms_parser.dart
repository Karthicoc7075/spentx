import 'sms_model.dart';

class SmartSmsParser {
  static SmartSms parse(String message) {
    // 1. Extract Amount
    final amountRegex = RegExp(r'(Rs\.?|INR)\s?(\d+(?:\.\d{2})?)', caseSensitive: false);
    final amountMatch = amountRegex.firstMatch(message);
    String amount = amountMatch?.group(2) ?? "0";

    // 2. Extract Bank & Account
    final bankRegex = RegExp(r'([A-Z]{3,})\s+Bank', caseSensitive: false);
    final bankMatch = bankRegex.firstMatch(message);
    String bank = bankMatch?.group(1) ?? "Bank";

    final accRegex = RegExp(r'A/C\s+(\*\d+)', caseSensitive: false);
    final accMatch = accRegex.firstMatch(message);
    String account = accMatch?.group(1) ?? "";

    // 3. Extract Receiver Name / Merchant
    String receiver = "";
    
    // Rule A: To <name>
    final toNameRegex = RegExp(r'To\s+([^\n]+)', caseSensitive: false);
    // Rule B: to <merchant> via
    final toMerchantRegex = RegExp(r'to\s+(.+?)\s+via', caseSensitive: false);
    // Rule C: to <vpa>
    final toUpiRegex = RegExp(r'to\s+([a-zA-Z0-9._-]+)@', caseSensitive: false);

    final toNameMatch = toNameRegex.firstMatch(message);
    final toMerchantMatch = toMerchantRegex.firstMatch(message);
    final toUpiMatch = toUpiRegex.firstMatch(message);

    if (toNameMatch != null) {
      receiver = toNameMatch.group(1)!.trim();
    } else if (toUpiMatch != null) {
      receiver = toUpiMatch.group(1)!;
    } else if (toMerchantMatch != null) {
      receiver = toMerchantMatch.group(1)!;
    }

    // 4. Cleanup & Capitalization
    receiver = _cleanAndCapitalize(receiver);

    return SmartSms(
      amount: amount,
      bank: bank.toUpperCase(),
      account: account,
      receiver: receiver.isEmpty ? "Unknown" : receiver,
      date: "19/04/26",
      rawMessage: message,
    );
  }

  static String _cleanAndCapitalize(String text) {
    if (text.isEmpty) return "";
    String cleaned = text.replaceAll(RegExp(r'[^a-zA-Z\s]'), '').trim();
    if (cleaned.isEmpty) return "";
    
    return cleaned.split(' ').map((word) {
      if (word.isEmpty) return "";
      return word[0].toUpperCase() + word.substring(1).toLowerCase();
    }).join(' ');
  }
}
