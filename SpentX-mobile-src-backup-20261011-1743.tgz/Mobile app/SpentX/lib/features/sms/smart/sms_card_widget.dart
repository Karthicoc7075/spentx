import 'package:flutter/material.dart';
import '../../../core/theme/soft_palette.dart';
import 'sms_model.dart';

class SmartSmsCard extends StatelessWidget {
  final SmartSms sms;

  const SmartSmsCard({super.key, required this.sms});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: SoftPalette.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: SoftPalette.border),
        boxShadow: [
          BoxShadow(
            color: SoftPalette.ink.withValues(alpha: 0.04),
            blurRadius: 15,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            height: 52,
            width: 52,
            decoration: BoxDecoration(
              color: SoftPalette.emeraldSoft,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: SoftPalette.mint.withValues(alpha: 0.35)),
            ),
            child: const Center(
              child: Icon(Icons.receipt_long_rounded, color: SoftPalette.emerald),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  sms.receiver,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    letterSpacing: -0.5,
                    color: SoftPalette.ink,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  "${sms.bank}${sms.account.isNotEmpty ? " • ${sms.account}" : ""}",
                  style: const TextStyle(
                    fontSize: 12,
                    color: SoftPalette.muted,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                "₹${sms.amount}",
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: SoftPalette.emerald,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                sms.date,
                style: const TextStyle(
                  fontSize: 11,
                  color: SoftPalette.faint,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
