import '../../../core/theme/soft_palette.dart';
import 'package:flutter/material.dart';
import 'sms_model.dart';
import 'sms_parser.dart';
import 'sms_card_widget.dart';
import '../sms_service.dart';

class SmartSmsListScreen extends StatefulWidget {
  const SmartSmsListScreen({super.key});

  @override
  State<SmartSmsListScreen> createState() => _SmartSmsListScreenState();
}

class _SmartSmsListScreenState extends State<SmartSmsListScreen> {

  List<SmartSms> _parsedSms = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    
    // Attempt real load
    final realMessages = await SmsService.readInbox();
    
    final List<SmartSms> results = [];
    
    if (realMessages.isNotEmpty) {
      for (var msg in realMessages) {
        results.add(SmartSmsParser.parse(msg.rawMessage));
      }
    }

    setState(() {
      _parsedSms = results;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: SoftPalette.bg,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(84),
        child: Container(
          color: SoftPalette.bg,
          child: SafeArea(
            bottom: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
              child: Row(
                children: [
                  if (Navigator.of(context).canPop()) ...[
                    Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                        color: SoftPalette.surface,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: SoftPalette.border),
                        boxShadow: const [
                          BoxShadow(
                            color: Color(0x0A0F172A),
                            blurRadius: 12,
                            offset: Offset(0, 4),
                          ),
                        ],
                      ),
                      child: IconButton(
                        tooltip: 'Back',
                        icon: const Icon(Icons.arrow_back_rounded, size: 20),
                        color: SoftPalette.ink,
                        onPressed: () => Navigator.of(context).pop(),
                      ),
                    ),
                    const SizedBox(width: 12),
                  ],
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'Smart SMS Sync',
                          style: TextStyle(
                            color: SoftPalette.ink,
                            fontWeight: FontWeight.w700,
                            fontSize: 22,
                            letterSpacing: -0.6,
                          ),
                        ),
                        SizedBox(height: 2),
                        Text(
                          'Automatically detected messages',
                          style: TextStyle(
                            color: SoftPalette.muted,
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                      color: SoftPalette.emeraldSoft,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: SoftPalette.mint.withValues(alpha: 0.18)),
                    ),
                    child: IconButton(
                      tooltip: 'Refresh messages',
                      icon: const Icon(Icons.refresh_rounded, size: 21),
                      color: SoftPalette.emerald,
                      onPressed: _loadData,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      body: _isLoading
        ? const Center(child: CircularProgressIndicator(
            color: SoftPalette.emerald,
            backgroundColor: SoftPalette.emeraldSoft,
          ))
        : ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            itemCount: _parsedSms.length,
            physics: const BouncingScrollPhysics(),
            itemBuilder: (context, index) {
              return SmartSmsCard(sms: _parsedSms[index]);
            },
          ),
    );
  }
}
