import '../../sms_parser/models/transaction_parsed.dart';
import '../../sms_parser/sms_direction_helper.dart';
import '../rules/engine/sms_template_engine.dart';
import '../rules/models/sms_template_rule.dart';
import 'bank_sms_template_catalog.dart';
import 'models/parsed_sms_transaction.dart';
import 'models/transaction_status.dart';
import 'merchant_learning_service.dart';
import 'payee_normalizer.dart';
import 'payee_extractor.dart';

/// Production SMS parser backed by `bank_sms_templates_v4.json`.
/// Extracts [Payee] (v4 `[Title]` slot), amount, account, date, reference, etc.
class BankSmsV4Parser {
  BankSmsV4Parser._();

  static List<SmsTemplateRule>? _rules;
  static bool _loading = false;

  static Future<void> ensureLoaded() async {
    if (_rules != null || _loading) return;
    _loading = true;
    try {
      _rules = await BankSmsTemplateCatalog.loadRules();
    } finally {
      _loading = false;
    }
  }

  static bool get isLoaded => _rules != null;

  static int get ruleCount => _rules?.length ?? 0;

  /// Parse a raw bank SMS. Returns null when no v4 template matches.
  static Future<ParsedSmsTransaction?> parse(
    String rawMessage, {
    DateTime? receivedAt,
  }) async {
    await ensureLoaded();
    final rules = _rules;
    if (rules == null || rules.isEmpty) return null;

    final body = rawMessage.trim();
    if (body.isEmpty) return null;

    final match = SmsTemplateEngine.tryMatchAgainstRules(
      rules,
      body,
      smsReceivedTime: receivedAt,
    );
    if (match == null) return null;

    return _fromTransactionParsed(
      parsed: match.parsed,
      rawMessage: body,
      templateId: match.ruleId,
      receivedAt: receivedAt,
    );
  }

  /// Synchronous parse when catalog is already loaded (live pipeline hot path).
  static ParsedSmsTransaction? parseSync(
    String rawMessage, {
    DateTime? receivedAt,
  }) {
    final rules = _rules;
    if (rules == null || rules.isEmpty) return null;

    final body = rawMessage.trim();
    if (body.isEmpty) return null;

    final match = SmsTemplateEngine.tryMatchAgainstRules(
      rules,
      body,
      smsReceivedTime: receivedAt,
    );
    if (match == null) return null;

    return _fromTransactionParsed(
      parsed: match.parsed,
      rawMessage: body,
      templateId: match.ruleId,
      receivedAt: receivedAt,
    );
  }

  static ParsedSmsTransaction _fromTransactionParsed({
    required TransactionParsed parsed,
    required String rawMessage,
    required String templateId,
    DateTime? receivedAt,
  }) {
    final direction = SmsDirectionHelper.resolveDirection(
      rawMessage: rawMessage,
      parsed: parsed,
    );
    final isTransfer = direction == TransactionDirection.transfer;
    final isExpense = direction == TransactionDirection.expense;

    // Payee: always prefer live SMS extraction over template sample fallbacks.
    var payee = PayeeExtractor.extract(rawMessage) ?? parsed.name.trim();
    if (!PayeeNormalizer.isMeaningful(payee) && parsed.upiId.isNotEmpty) {
      payee = parsed.upiId;
    }
    if (!PayeeNormalizer.isMeaningful(payee)) {
      payee = 'Unknown';
    }

    // Title: saved merchant title applied later; default to payee for new merchants.
    final savedMerchant = MerchantLearningService.findVerified(payee);
    final displayTitle = savedMerchant?.title ?? payee;

    return ParsedSmsTransaction(
      amount: parsed.amount,
      payee: payee,
      title: displayTitle,
      purpose: savedMerchant?.purpose ?? '',
      category: savedMerchant?.category ?? 'Other',
      status: savedMerchant != null
          ? TransactionStatus.auto
          : TransactionStatus.verified,
      date: parsed.dateTime,
      accountLast4: parsed.accountLast4,
      referenceId: parsed.referenceId,
      bank: parsed.bank,
      subtype: parsed.mode.name,
      isExpense: isExpense,
      isTransfer: isTransfer,
      upiId: parsed.upiId,
      rawMessage: rawMessage,
      matchedTemplateId: templateId,
    );
  }

  /// Bridge to legacy [TransactionParsed] for existing AutoRuleEngine integration.
  static TransactionParsed? toLegacyParsed(ParsedSmsTransaction v4) {
    final direction = v4.isTransfer
        ? TransactionDirection.transfer
        : (v4.isExpense ? TransactionDirection.expense : TransactionDirection.income);

    final stableId = v4.upiId.isNotEmpty ? v4.upiId : v4.payee;

    return TransactionParsed(
      amount: v4.amount,
      direction: direction,
      bank: v4.bank,
      accountLast4: v4.accountLast4,
      name: v4.payee,
      rawIdentifier: stableId,
      mode: _parseMode(v4.subtype),
      accountFlow: direction == TransactionDirection.transfer
          ? AccountFlow.cash
          : AccountFlow.external,
      upiId: v4.upiId,
      referenceId: v4.referenceId,
      dateTime: v4.date,
      rawMessage: v4.rawMessage,
    );
  }

  static TransactionMode _parseMode(String subtype) {
    switch (subtype) {
      case 'upi':
        return TransactionMode.upi;
      case 'atm':
        return TransactionMode.atm;
      case 'card':
        return TransactionMode.card;
      case 'cash':
        return TransactionMode.cash;
      default:
        return TransactionMode.unknown;
    }
  }
}