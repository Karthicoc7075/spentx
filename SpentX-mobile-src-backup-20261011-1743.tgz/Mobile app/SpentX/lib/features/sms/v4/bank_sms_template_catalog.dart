import 'dart:convert';

import 'package:flutter/services.dart';

import '../rules/models/sms_template_rule.dart';

/// Loads and caches `assets/sms/bank_sms_templates_v4.json`.
class BankSmsTemplateCatalog {
  BankSmsTemplateCatalog._();

  static const assetPath = 'assets/sms/bank_sms_templates_v5.json';

  static List<SmsTemplateRule>? _cachedRules;
  static Map<String, dynamic>? _rawRoot;

  static final Set<String> _skipTypes = {
    'advertisement',
    'failed_transaction',
  };

  /// Load v4 templates once and convert to [SmsTemplateRule] for the template engine.
  static Future<List<SmsTemplateRule>> loadRules({bool forceReload = false}) async {
    if (_cachedRules != null && !forceReload) return _cachedRules!;

    final raw = await rootBundle.loadString(assetPath);
    final root = jsonDecode(raw) as Map<String, dynamic>;
    _rawRoot = root;

    final banks = root['banks'] as List<dynamic>? ?? [];
    final rules = <SmsTemplateRule>[];

    for (final bankEntry in banks) {
      if (bankEntry is! Map) continue;
      final bankMap = Map<String, dynamic>.from(bankEntry);
      final bankName = bankMap['bank']?.toString() ?? '';
      final bankExact = bankMap['bankNameExact']?.toString() ?? '';
      final templates = bankMap['templates'] as List<dynamic>? ?? [];

      for (final tpl in templates) {
        if (tpl is! Map) continue;
        final rule = _toTemplateRule(Map<String, dynamic>.from(tpl), bankName, bankExact);
        if (rule != null) rules.add(rule);
      }
    }

    _cachedRules = rules;
    return rules;
  }

  static Map<String, dynamic>? get metadata => _rawRoot;

  static int get templateCount => _cachedRules?.length ?? 0;

  static SmsTemplateRule? _toTemplateRule(
    Map<String, dynamic> tpl,
    String bankName,
    String bankExact,
  ) {
    // v5: a template the catalog itself marks wrong must never match.
    // `hdfc_credit_card_emi` is a due reminder typed as a Debit — loading it
    // would let "EMI ... due on 10-06-26" book a ₹3,000 spend.
    if (tpl['enabled'] == false) return null;

    final txType = tpl['transactionType']?.toString() ?? 'debit';
    if (_skipTypes.contains(txType)) return null;

    final sample = tpl['sampleMessage']?.toString() ?? '';
    final pattern = tpl['templatePattern']?.toString() ?? '';
    if (sample.trim().isEmpty || pattern.trim().isEmpty) return null;

    final extractionMap = _completeExtraction(
      _mapExtraction(tpl['extractionMap']),
      tpl['template']?.toString() ?? pattern,
      sample,
    );
    final exactTagged = _mapExactTagged(tpl['exactTaggedValues']);
    // Slot alignment can recover a title the hand map forgot. Keep the
    // field→text mirror in sync so later passes see the same value.
    for (final entry in extractionMap.entries) {
      exactTagged.putIfAbsent(entry.value, () => entry.key);
    }

    final keywords = (tpl['keywords'] as List<dynamic>? ?? [])
        .map((e) => e.toString())
        .where((k) => k.isNotEmpty)
        .toList();

    final structuralParts = _structuralParts(tpl, pattern);

    return SmsTemplateRule(
      id: tpl['id']?.toString() ?? '${bankName}_${txType}_${rulesHash(sample)}',
      bankName: tpl['bank']?.toString() ?? bankName,
      bankNameExact: bankExact,
      type: _mapTransactionType(txType),
      mode: tpl['mode']?.toString() ?? 'unknown',
      sampleMessage: sample,
      templatePattern: pattern,
      extractionMap: extractionMap,
      exactTaggedValues: exactTagged,
      keywords: keywords,
      similarityThreshold: (tpl['similarityThreshold'] as num?)?.toDouble() ?? 0.65,
      structuralParts: structuralParts,
      // v5 precision fields. Absent on the 232 generated templates, whose
      // defaults ('' / '' / true) reproduce the pre-v5 behaviour exactly.
      requiredVerb: tpl['requiredVerb']?.toString() ?? '',
      direction: tpl['direction']?.toString() ?? '',
      enabled: tpl['enabled'] != false,
    );
  }

  static String _mapTransactionType(String txType) {
    switch (txType) {
      case 'credit':
      case 'salary_credit':
      case 'interest_credit':
        return 'credit';
      case 'transfer':
      case 'atm_withdraw':
      case 'atm_deposit':
      case 'bank_to_cash':
      case 'cash_to_bank':
        return 'transfer';
      default:
        return 'debit';
    }
  }

  static Map<String, String> _mapExtraction(dynamic raw) {
    if (raw is! Map) return {};
    final out = <String, String>{};
    for (final e in raw.entries) {
      final field = e.value?.toString() ?? '';
      out[e.key.toString()] = _normalizeField(field);
    }
    return out;
  }

  static Map<String, String> _mapExactTagged(dynamic raw) {
    if (raw is! Map) return {};
    final out = <String, String>{};
    for (final e in raw.entries) {
      final key = e.key.toString();
      out[key] = e.value?.toString() ?? '';
      if (key == 'payee' && !out.containsKey('title')) {
        out['title'] = out[key]!;
      }
    }
    return out;
  }

  /// Maps v4 field names (title, payee, merchant) → template engine field types.
  static String _normalizeField(String field) {
    switch (field) {
      case 'payee':
      case 'merchant':
      case 'merchantName':
        return TemplateFieldType.title;
      case 'amount':
      case 'accountLast4':
      case 'accountNumber':
      case 'referenceId':
      case 'upiId':
      case 'date':
      case 'time':
      case 'balance':
      case 'bankName':
      case 'title':
        return field;
      default:
        return field;
    }
  }

  /// Prefer the parts shipped with the template. Re-deriving them used to
  /// leave literal `[UPI]` / `[Note]` in the anchor, so that anchor never
  /// occurred in a real SMS and the template lost the match.
  static List<String> _structuralParts(Map<String, dynamic> tpl, String pattern) {
    final raw = tpl['structuralParts'];
    if (raw is List) {
      final authored = raw
          .map((e) => e.toString().trim())
          .where((p) => p.length >= 2)
          .toList();
      if (authored.isNotEmpty) return authored;
    }
    return _deriveStructuralParts(tpl['template']?.toString() ?? pattern);
  }

  static final RegExp _slotToken = RegExp(r'\[[A-Za-z0-9_]+\]');

  /// Fill extraction fields the template names with `[Title]` / `[Amount]`
  /// but the hand-written map left out. The captured text is the exact
  /// substring of [sample], which is what positional extraction looks up.
  static Map<String, String> _completeExtraction(
    Map<String, String> extraction,
    String template,
    String sample,
  ) {
    final aligned = _alignSlots(template, sample);
    if (aligned == null || aligned.isEmpty) return extraction;
    final out = Map<String, String>.from(extraction);
    final have = out.values.toSet();
    for (final entry in aligned.entries) {
      final field = _slotField(entry.key);
      if (field == null || have.contains(field)) continue;
      final value = entry.value.trim();
      if (value.isEmpty || value.length > 80) continue;
      if (out.containsKey(value)) continue;
      out[value] = field;
      have.add(field);
    }
    return out;
  }

  static String? _slotField(String token) {
    switch (token) {
      case '[Amount]':
        return TemplateFieldType.amount;
      case '[Title]':
      case '[Payee]':
        return TemplateFieldType.title;
      case '[AccountLast4]':
      case '[CardLast4]':
        return TemplateFieldType.accountLast4;
      case '[Date]':
        return TemplateFieldType.date;
      case '[Time]':
        return TemplateFieldType.time;
      case '[ReferenceId]':
        return TemplateFieldType.referenceId;
      case '[Balance]':
        return TemplateFieldType.balance;
      case '[UPI]':
      case '[UPIID]':
        return TemplateFieldType.upiId;
      default:
        return null;
    }
  }

  /// Walk [template] literals through [sample] and return slot token → text.
  /// Null when a literal is not in the sample (multiline or a drifted template).
  static Map<String, String>? _alignSlots(String template, String sample) {
    if (template.isEmpty || sample.isEmpty || !template.contains('[')) return null;
    final slots = _slotToken.allMatches(template).map((m) => m.group(0)!).toList();
    if (slots.isEmpty) return null;
    final literals = template.split(_slotToken);
    if (literals.length != slots.length + 1) return null;
    var pos = 0;
    final out = <String, String>{};
    for (var i = 0; i < literals.length; i++) {
      final lit = literals[i];
      if (lit.isEmpty) {
        if (i == 0) continue;
        if (i == literals.length - 1) {
          out[slots[i - 1]] = sample.substring(pos);
          return out;
        }
        return null;
      }
      final j = sample.indexOf(lit, pos);
      if (j < 0) return null;
      if (i > 0) out[slots[i - 1]] = sample.substring(pos, j);
      pos = j + lit.length;
    }
    return out;
  }

  static List<String> _deriveStructuralParts(String template) {
    if (template.isEmpty) return [];
    final parts = template
        .split(RegExp(r'\[(?:Amount|Payee|Title|AccountLast4|Date|ReferenceId|Balance|CardLast4|UPIID|UPI|Time|Note|SenderAccount)[^\]]*\]'))
        .map((p) => p.trim())
        .where((p) => p.length >= 4)
        .toList();
    return parts;
  }

  static String rulesHash(String sample) => sample.hashCode.abs().toRadixString(16);
}