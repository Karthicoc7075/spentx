/// How a transaction entered the ledger.
enum TransactionStatus {
  /// Auto-created from a verified merchant (no popup).
  auto('AUTO'),

  /// User confirmed/edited in the verification popup.
  verified('VERIFIED');

  final String label;
  const TransactionStatus(this.label);

  static TransactionStatus fromLabel(String? value) {
    if (value == null) return TransactionStatus.verified;
    return TransactionStatus.values.firstWhere(
      (s) => s.label == value || s.name == value,
      orElse: () => TransactionStatus.verified,
    );
  }
}