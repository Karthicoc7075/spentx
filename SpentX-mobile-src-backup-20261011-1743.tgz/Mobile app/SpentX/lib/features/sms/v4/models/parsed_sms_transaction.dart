import 'transaction_status.dart';

/// Clean parsed output from [BankSmsV4Parser].
/// [payee] is the raw counterparty from SMS ([Payee] / [Title] template slot).
class ParsedSmsTransaction {
  final double amount;
  final String payee;
  final String title;
  final String purpose;
  final String category;
  final DateTime date;
  final String accountLast4;
  final String referenceId;
  final String bank;
  final String subtype;
  final bool isExpense;
  final bool isTransfer;
  final String upiId;
  final String rawMessage;
  final String matchedTemplateId;
  final TransactionStatus status;

  const ParsedSmsTransaction({
    required this.amount,
    required this.payee,
    this.title = '',
    this.purpose = '',
    this.category = 'Other',
    required this.date,
    this.accountLast4 = '',
    this.referenceId = '',
    required this.bank,
    this.subtype = 'upi',
    this.isExpense = true,
    this.isTransfer = false,
    this.upiId = '',
    required this.rawMessage,
    this.matchedTemplateId = '',
    this.status = TransactionStatus.verified,
  });

  /// Friendly title shown in the activity list.
  String get displayTitle => title.isNotEmpty ? title : payee;

  Map<String, dynamic> toJson() => {
        'amount': amount,
        'payee': payee,
        'title': title,
        'purpose': purpose,
        'category': category,
        'date': date.toIso8601String(),
        'accountLast4': accountLast4,
        'referenceId': referenceId,
        'bank': bank,
        'subtype': subtype,
        'isExpense': isExpense,
        'isTransfer': isTransfer,
        'upiId': upiId,
        'rawMessage': rawMessage,
        'matchedTemplateId': matchedTemplateId,
        'status': status.label,
      };

  factory ParsedSmsTransaction.fromJson(Map<dynamic, dynamic> json) {
    return ParsedSmsTransaction(
      amount: (json['amount'] as num? ?? 0).toDouble(),
      payee: json['payee']?.toString() ?? '',
      title: json['title']?.toString() ?? '',
      purpose: json['purpose']?.toString() ?? '',
      category: json['category']?.toString() ?? 'Other',
      date: DateTime.tryParse(json['date']?.toString() ?? '') ?? DateTime.now(),
      accountLast4: json['accountLast4']?.toString() ?? '',
      referenceId: json['referenceId']?.toString() ?? '',
      bank: json['bank']?.toString() ?? '',
      subtype: json['subtype']?.toString() ?? 'upi',
      isExpense: json['isExpense'] == true,
      isTransfer: json['isTransfer'] == true,
      upiId: json['upiId']?.toString() ?? '',
      rawMessage: json['rawMessage']?.toString() ?? '',
      matchedTemplateId: json['matchedTemplateId']?.toString() ?? '',
      status: TransactionStatus.fromLabel(json['status']?.toString()),
    );
  }

  ParsedSmsTransaction copyWith({
    String? title,
    String? purpose,
    String? category,
    TransactionStatus? status,
  }) {
    return ParsedSmsTransaction(
      amount: amount,
      payee: payee,
      title: title ?? this.title,
      purpose: purpose ?? this.purpose,
      category: category ?? this.category,
      date: date,
      accountLast4: accountLast4,
      referenceId: referenceId,
      bank: bank,
      subtype: subtype,
      isExpense: isExpense,
      isTransfer: isTransfer,
      upiId: upiId,
      rawMessage: rawMessage,
      matchedTemplateId: matchedTemplateId,
      status: status ?? this.status,
    );
  }
}