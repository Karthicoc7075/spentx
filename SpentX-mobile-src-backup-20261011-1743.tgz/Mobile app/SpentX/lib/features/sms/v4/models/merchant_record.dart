import '../../../../../models/merchant.dart';

export '../../../../../models/merchant.dart';

typedef MerchantRecord = Merchant;