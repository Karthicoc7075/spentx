/// Extracts counterparty / payee from bank SMS text.
/// Never returns sample/training placeholder names — only text from the live message.
class PayeeExtractor {
  PayeeExtractor._();

  /// Ordered patterns — first match wins.
  static final List<RegExp> _patterns = [
    // Bank charge: "For: DEBIT CARD ANNUAL FEE on DATE"
    RegExp(
      r'\bFor:\s+(.+?)(?=\s+on\s+\d|\s*$)',
      caseSensitive: false,
    ),
    // Deposited / Credited for salary/payroll COMPANY NAME.
    // Stop before " on <date>" so "for Home Loan on 07-06-26" stays "Home Loan".
    RegExp(
      r'\bfor\s+(?:[A-Za-z0-9]+-)*(?:TPT|NEFT|IMPS|RTGS)?-?(?:[A-Za-z0-9 ]*salary-)?([A-Za-z0-9.&\- ]+?)(?=\s+on\s+\d|\.Avl|\s+Avl|\s+Available|\. Cheque|\s+Cheque|\s*,|\.|$)',
      caseSensitive: false,
    ),
    // HDFC UPI-app style (multiline): To NAME On DATE
    RegExp(
      r'\bTo\s+(.+?)\s+On\s+\d{1,2}[-/]\d{1,2}[-/]\d{2,4}',
      caseSensitive: false,
      dotAll: true,
    ),
    // Sent Rs... To NAME (line break before On)
    RegExp(
      r'(?:^|\n)\s*To\s+(.+?)(?:\s*\n\s*On\s+|\s+On\s+\d)',
      caseSensitive: false,
      dotAll: true,
    ),
    // to VPA merchant@bank
    RegExp(
      r'\bto\s+VPA\s+([a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+)',
      caseSensitive: false,
    ),
    // debited / paid / sent to NAME (must be preceded by verb to avoid 'subject to clearing')
    RegExp(
      r'\b(?:debited|paid|sent|transferred)\s+to\s+(.+?)(?:\s+on\s+\d|\s*,|\s+UPI\s+Ref|\s+upi\s+ref|\s+Ref\b|\s+avl\b|$)',
      caseSensitive: false,
      dotAll: true,
    ),
    // credited from NAME
    RegExp(
      r'\b(?:from|credited\s+from|received\s+from)\s+(.+?)(?:\s+on\s+|\s+avl\b|\s+UPI|\s+Ref\b|$)',
      caseSensitive: false,
      dotAll: true,
    ),
    // "credited ... by ACCENTURE SOLUTIONS". Skip rails (by NEFT / by VPA).
    RegExp(
      r'\bby\s+(?!vpa\b|neft\b|imps\b|rtgs\b|upi\b|rs\b|inr\b)([A-Za-z][A-Za-z0-9.&\- ]+?)(?=\s+on\b|\s+via\b|\s+ref\b|\s*\.|$)',
      caseSensitive: false,
    ),
    // HDFC card POS: At MERCHANT On YYYY-MM-DD:HH:MM:SS
    RegExp(
      r'\bAt\s+(.+?)\s+On\s+\d{4}-\d{2}-\d{2}(?::\d{2}:\d{2}:\d{2})?',
      caseSensitive: false,
    ),
    // Card POS: At MERCHANT On DD/MM/YY or DD-MM-YY
    RegExp(
      r'\bAt\s+(.+?)\s+On\s+\d{1,2}[-/]\d{1,2}[-/]\d{2,4}',
      caseSensitive: false,
      dotAll: true,
    ),
  ];

  static String? extract(String message) {
    if (message.trim().isEmpty) return null;

    // Normalize line breaks — banks use \n between fields.
    final normalized = message.replaceAll('\r\n', '\n').trim();
    final lower = normalized.toLowerCase();

    // Cash withdrawn at an ATM has no person. The counterparty is the ATM.
    if (RegExp(r'\b(?:withdrawn|w/d)\b').hasMatch(lower) &&
        RegExp(r'\batm\b').hasMatch(lower)) {
      return 'ATM';
    }
    // "FD of Rs.X created" moves the user's own money. Name the holding.
    if ((RegExp(r'\bfd\b').hasMatch(lower) || lower.contains('fixed deposit')) &&
        (lower.contains('created') ||
            lower.contains('booked') ||
            lower.contains('opened'))) {
      return 'Fixed Deposit';
    }

    for (final pattern in _patterns) {
      final match = pattern.firstMatch(normalized);
      if (match == null || match.groupCount < 1) continue;
      final raw = match.group(1)?.trim();
      final cleaned = _clean(raw);
      if (_isValidPayee(cleaned)) return cleaned;
    }

    return null;
  }

  static String _clean(String? raw) {
    if (raw == null) return '';
    return raw
        .replaceAll(RegExp(r'\s+'), ' ')
        .replaceAll(RegExp(r'\.+$'), '')
        .trim();
  }

  static bool _isValidPayee(String value) {
    if (value.length < 2 || value.length > 80) return false;
    final lower = value.toLowerCase();
    const blocked = {
      'unknown',
      'hdfc bank',
      'sbi bank',
      'icici bank',
      'clearing',
      'credited',
      'deposited',
      'balance',
      'ref',
      'cheque',
      'cheques',
      'cheque deposits',
      'subject to clearing',
    };
    if (blocked.contains(lower)) return false;
    if (RegExp(r'^\d+$').hasMatch(value.replaceAll(RegExp(r'\D'), '')) &&
        value.replaceAll(RegExp(r'\D'), '').length == value.replaceAll(RegExp(r'[^0-9]'), '').length) {
      return false;
    }
    return true;
  }
}
