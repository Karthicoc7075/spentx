import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../detected/auto_rule_engine.dart';
import 'bank_sms_v4_parser.dart';
import 'merchant_learning_service.dart';
import 'models/merchant_record.dart';
import 'models/parsed_sms_transaction.dart';
import 'models/transaction_status.dart';
import 'payee_normalizer.dart';

/// Result of parsing + merchant lookup before saving a transaction.
class MerchantPipelineDecision {
  final ParsedSmsTransaction parsed;
  final MerchantRecord? knownMerchant;
  final bool autoSave;
  final bool showVerification;

  const MerchantPipelineDecision({
    required this.parsed,
    this.knownMerchant,
    required this.autoSave,
    required this.showVerification,
  });
}

/// Connects v4 parser + payee merchant learning to the existing detection pipeline.
class MerchantTransactionOrchestrator {
  MerchantTransactionOrchestrator._();

  /// Parse SMS and decide auto-save vs verification popup.
  static Future<MerchantPipelineDecision?> evaluate(
    String rawMessage, {
    DateTime? receivedAt,
  }) async {
    await BankSmsV4Parser.ensureLoaded();
    final parsed = BankSmsV4Parser.parseSync(
      rawMessage,
      receivedAt: receivedAt,
    );
    if (parsed == null) return null;
    if (!PayeeNormalizer.isMeaningful(parsed.payee)) return null;

    final merchant = MerchantLearningService.findByPayee(parsed.payee);
    if (merchant != null) {
      return MerchantPipelineDecision(
        parsed: MerchantLearningService.applyMerchant(parsed, merchant),
        knownMerchant: merchant,
        autoSave: true,
        showVerification: false,
      );
    }

    return MerchantPipelineDecision(
      parsed: parsed.copyWith(status: TransactionStatus.verified),
      autoSave: false,
      showVerification: true,
    );
  }

  /// Route through existing AutoRuleEngine using v4-parsed legacy shape.
  static Future<bool?> handleWithExistingEngine({
    required WidgetRef ref,
    required BuildContext context,
    required String rawMessage,
    bool forcePopup = false,
    DateTime? receivedAt,
  }) async {
    final decision = await evaluate(rawMessage, receivedAt: receivedAt);
    if (decision == null) return null;

    final legacy = BankSmsV4Parser.toLegacyParsed(decision.parsed);
    if (legacy == null) return null;
    if (!context.mounted) return null;

    final result = await AutoRuleEngine.handleForeground(
      ref: ref,
      context: context,
      rawMessage: rawMessage,
      amount: decision.parsed.amount,
      merchant: decision.parsed.displayTitle,
      bank: decision.parsed.bank,
      type:
          decision.parsed.isTransfer
              ? 'ATM Withdrawal / Bank to Cash'
              : (decision.parsed.isExpense ? 'Debit' : 'Credit'),
      forcePopup: forcePopup || decision.showVerification,
    );
    return result is bool ? result : null;
  }

  /// Called from verification popup after user edits title/category/purpose.
  static Future<MerchantRecord> onUserVerified({
    required ParsedSmsTransaction parsed,
    required String title,
    required String purpose,
    required String category,
  }) {
    return MerchantLearningService.saveVerified(
      payee: parsed.payee,
      title: title,
      purpose: purpose,
      category: category,
    );
  }
}
