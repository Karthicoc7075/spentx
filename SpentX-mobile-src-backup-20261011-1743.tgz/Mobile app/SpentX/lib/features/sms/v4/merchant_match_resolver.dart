import '../../../core/models/merchant_rule.dart';
import '../../sms_parser/models/transaction_parsed.dart';
import 'merchant_learning_service.dart';
import 'models/merchant_record.dart';
import 'payee_extractor.dart';
import 'payee_normalizer.dart';

/// Payee-first merchant resolution — normalized SMS payee is the primary lookup key.
class MerchantMatchResolver {
  MerchantMatchResolver._();

  static MerchantMatchResult resolve({
    required String rawMessage,
    TransactionParsed? parsed,
    bool requireAutoApply = true,
  }) {
    final payee = _extractPayee(rawMessage, parsed);
    final normalized = PayeeNormalizer.normalize(payee);

    MerchantRecord? record;
    if (PayeeNormalizer.isMeaningful(payee)) {
      record = requireAutoApply
          ? MerchantLearningService.findByPayee(payee)
          : MerchantLearningService.findVerified(payee);
    }

    if (record != null) {
      return MerchantMatchResult(
        payee: payee,
        normalizedPayee: normalized,
        displayTitle: record.title.isNotEmpty ? record.title : payee,
        category: record.category,
        purpose: record.purpose.isNotEmpty ? record.purpose : 'Personal',
        rule: _ruleFromRecord(record),
        isKnown: true,
      );
    }

    return MerchantMatchResult(
      payee: payee,
      normalizedPayee: normalized,
      displayTitle: payee.isNotEmpty ? payee : 'Unknown',
      category: 'Other',
      purpose: 'Personal',
      rule: null,
      isKnown: false,
    );
  }

  static String _extractPayee(String rawMessage, TransactionParsed? parsed) {
    final fromSms = PayeeExtractor.extract(rawMessage);
    if (fromSms != null && PayeeNormalizer.isMeaningful(fromSms)) {
      return fromSms.trim();
    }
    final parsedName = parsed?.name.trim() ?? '';
    if (PayeeNormalizer.isMeaningful(parsedName)) return parsedName;
    return '';
  }

  static MerchantRule _ruleFromRecord(MerchantRecord record) {
    return MerchantRule(
      id: record.id,
      identifier: record.payee,
      normalizedIdentifierKey: record.normalizedPayee,
      displayName: record.title,
      defaultPurposeType:
          record.purpose.isNotEmpty ? record.purpose : 'Personal',
      defaultCategory: record.category,
      transactionType: 'any',
      lastUsedAt: record.verifiedAt,
    );
  }
}

class MerchantMatchResult {
  final String payee;
  final String normalizedPayee;
  final String displayTitle;
  final String category;
  final String purpose;
  final MerchantRule? rule;
  final bool isKnown;

  const MerchantMatchResult({
    required this.payee,
    required this.normalizedPayee,
    required this.displayTitle,
    required this.category,
    required this.purpose,
    required this.rule,
    required this.isKnown,
  });
}