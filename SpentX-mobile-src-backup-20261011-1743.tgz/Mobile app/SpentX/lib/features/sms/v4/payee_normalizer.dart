/// Normalizes SMS payee / counterparty names for merchant lookup keys.
class PayeeNormalizer {
  PayeeNormalizer._();

  static String normalize(String payee) {
    return payee
        .trim()
        .toLowerCase()
        .replaceAll(RegExp(r'\s+'), ' ')
        .replaceAll(RegExp(r'[^a-z0-9@._\- ]'), '');
  }

  static bool isMeaningful(String payee) {
    final n = normalize(payee);
    if (n.isEmpty || n == 'unknown') return false;
    const noise = {
      'clearing',
      'credited',
      'deposited',
      'received',
      'balance',
      'avl',
      'account',
      'bank',
      'xx',
      'ref',
    };
    return !noise.contains(n);
  }
}