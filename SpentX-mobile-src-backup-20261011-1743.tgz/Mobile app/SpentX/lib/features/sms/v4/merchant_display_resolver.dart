import '../../../core/providers/transaction_provider.dart';
import '../../../core/services/merchant_rule_service.dart';
import '../detected/sms_atm_helper.dart';
import 'merchant_learning_service.dart';
import 'payee_extractor.dart';
import 'payee_normalizer.dart';

/// Resolves the user-facing transaction title for list/detail UI.
///
/// Display rules:
/// - Verified merchant exists → always show saved [MerchantRecord.title]
/// - No merchant linked → show raw SMS payee
/// - Never show raw payee when a verified title exists
class MerchantDisplayResolver {
  MerchantDisplayResolver._();

  static String titleFor(Transaction tx) {
    if (tx.isTransfer) {
      // ATM/CDM rows name the bank in the title ("🏧 HDFC ATM Withdrawal")
      // because the label already explains where the money went — Cash is an
      // internal destination and showing "HDFC → Cash" only adds noise.
      final cashLabel = _cashMovementLabel(tx);
      if (cashLabel != null) {
        final isDeposit = cashLabel == SmsAtmHelper.cashDepositDisplayName;
        final bank = _bankLabel(tx, isDeposit: isDeposit);
        final emoji = isDeposit ? '💰' : '🏧';
        return bank.isEmpty ? '$emoji $cashLabel' : '$emoji $bank $cashLabel';
      }
      return '↔ Transfer';
    }

    final verified = MerchantLearningService.findForTransaction(
      rawIdentifier: tx.rawIdentifier,
      upiId: tx.upiId,
      rawMessage: tx.rawMessage,
      merchant: tx.merchant,
    );
    if (verified != null && verified.title.isNotEmpty) {
      return verified.title;
    }

    final rule = _findLegacyRule(tx);
    if (rule != null && rule.displayName.isNotEmpty) {
      return rule.displayName;
    }

    if (tx.isMerchantMapped && tx.merchant.isNotEmpty) {
      return tx.merchant;
    }

    return _rawPayeeOrFallback(tx);
  }

  /// `ATM Withdrawal` / `Cash Deposit` when this transfer is really a cash
  /// movement, else null (a genuine bank→bank transfer).
  ///
  /// Falls back to [Transaction.transferType] rather than trusting the
  /// merchant string alone. The label is user-editable — renaming an ATM
  /// merchant rule rewrites it — while `bank_to_cash` / `cash_to_bank` is
  /// structural and stamped by every write path, the manual transfer sheet
  /// included. Keying on the string only is why a hand-entered bank→cash
  /// withdrawal used to render as "↔ Transfer".
  static String? _cashMovementLabel(Transaction tx) {
    if (tx.isAtmTransfer) return tx.merchant.trim();
    switch (tx.transferType) {
      case 'bank_to_cash':
        return SmsAtmHelper.defaultDisplayName;
      case 'cash_to_bank':
        return SmsAtmHelper.cashDepositDisplayName;
      default:
        return null;
    }
  }

  /// The bank side of a cash movement — the source of a withdrawal, the
  /// destination of a deposit.
  ///
  /// SMS rows carry it in [Transaction.bankName]; manual rows leave that empty
  /// and only have the account names, so fall back to those. The Cash leg is
  /// never the answer ("🏧 Cash ATM Withdrawal"), so it yields '' and the
  /// caller drops the bank from the title entirely.
  static String _bankLabel(Transaction tx, {required bool isDeposit}) {
    final fromSms = tx.bankName.trim();
    if (fromSms.isNotEmpty) return fromSms;
    final fallback = (isDeposit ? (tx.transferTo ?? '') : tx.account).trim();
    return fallback.toLowerCase() == 'cash' ? '' : fallback;
  }

  /// Raw SMS payee — only for unverified / unlinked transactions.
  static String rawPayeeFor(Transaction tx) => _rawPayeeOrFallback(tx);

  static String _rawPayeeOrFallback(Transaction tx) {
    final fromSms = _extractRawPayee(tx);
    if (fromSms.isNotEmpty) return fromSms;
    return tx.merchant.isNotEmpty ? tx.merchant : 'Unknown';
  }

  static String _extractRawPayee(Transaction tx) {
    if (tx.rawIdentifier != null &&
        tx.rawIdentifier!.isNotEmpty &&
        PayeeNormalizer.isMeaningful(tx.rawIdentifier!)) {
      return tx.rawIdentifier!.trim();
    }
    if (tx.rawMessage.isNotEmpty) {
      final extracted = PayeeExtractor.extract(tx.rawMessage);
      if (extracted != null && PayeeNormalizer.isMeaningful(extracted)) {
        return extracted.trim();
      }
    }
    if (PayeeNormalizer.isMeaningful(tx.merchant)) {
      return tx.merchant.trim();
    }
    return '';
  }

  static dynamic _findLegacyRule(Transaction tx) {
    return MerchantRuleService.findRule(
      upiId: tx.upiId,
      rawIdentifier: tx.rawIdentifier ?? '',
      displayName: tx.merchant,
      rawMessage: tx.rawMessage.isNotEmpty ? tx.rawMessage : null,
      transactionType: tx.isExpense ? 'debit' : 'credit',
      logResult: false,
    );
  }
}