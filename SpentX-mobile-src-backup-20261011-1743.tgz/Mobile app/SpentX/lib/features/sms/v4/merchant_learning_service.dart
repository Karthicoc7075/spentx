import 'dart:async';

import 'package:hive_flutter/hive_flutter.dart';

import '../../../core/services/auth_service.dart';
import '../../../core/services/auto_detection_native_sync.dart';
import '../../../core/services/merchant_rule_service.dart';
import '../../../core/sync/supabase_schema_map.dart';
import '../../../core/sync/sync_service.dart';
import 'models/merchant_record.dart';
import 'models/parsed_sms_transaction.dart';
import 'models/transaction_status.dart';
import 'payee_extractor.dart';
import 'payee_normalizer.dart';
import '../../../data/local/hive_service.dart';

/// Payee-based merchant learning — normalized payee is the unique lookup key.
class MerchantLearningService {
  MerchantLearningService._();

  static const boxName = 'merchants_box';

  static Box get _box => Hive.box(boxName);

  /// Serializes [saveVerified] so two near-simultaneous saves for the same
  /// payee (e.g. bulk SMS backlog scan) can't both read "no existing
  /// record" before either write lands — the read-check-write below would
  /// otherwise double-insert the same merchant.
  static Future<void> _lock = Future.value();

  static Future<void> ensureOpen() async {
    if (!Hive.isBoxOpen(boxName)) {
      await SecureHive.openBox(boxName);
    }
  }

  /// Lookup verified merchant by normalized payee (auto-apply pipeline).
  static MerchantRecord? findByPayee(String payee) {
    return _lookupPayee(payee, requireAutoApply: true);
  }

  /// Lookup any verified merchant — used for display titles in list/detail.
  static MerchantRecord? findVerified(String payee) {
    return _lookupPayee(payee, requireAutoApply: false);
  }

  /// Try multiple transaction keys (rawIdentifier, UPI, SMS payee, stored merchant).
  static MerchantRecord? findForTransaction({
    String? rawIdentifier,
    String? upiId,
    String? rawMessage,
    String? merchant,
  }) {
    for (final candidate in _candidatePayees(
      rawIdentifier: rawIdentifier,
      upiId: upiId,
      rawMessage: rawMessage,
      merchant: merchant,
    )) {
      final found = findVerified(candidate);
      if (found != null) return found;
    }
    return null;
  }

  static MerchantRecord? _lookupPayee(String payee, {required bool requireAutoApply}) {
    if (!Hive.isBoxOpen(boxName)) return null;
    final norm = PayeeNormalizer.normalize(payee);
    if (norm.isEmpty) return null;

    for (final raw in _box.values) {
      final record = MerchantRecord.fromMap(Map<dynamic, dynamic>.from(raw));
      if (record.normalizedPayee != norm) continue;
      if (requireAutoApply && !record.isAutoApply) continue;
      return record;
    }
    return null;
  }

  static List<String> _candidatePayees({
    String? rawIdentifier,
    String? upiId,
    String? rawMessage,
    String? merchant,
  }) {
    final seen = <String>{};
    final out = <String>[];

    void add(String? value) {
      if (value == null || value.trim().isEmpty) return;
      if (!PayeeNormalizer.isMeaningful(value)) return;
      final norm = PayeeNormalizer.normalize(value);
      if (seen.add(norm)) out.add(value.trim());
    }

    add(rawIdentifier);
    add(upiId);
    if (rawMessage != null && rawMessage.isNotEmpty) {
      add(PayeeExtractor.extract(rawMessage));
      add(MerchantRuleService.extractUpiFromMessage(rawMessage));
    }
    add(merchant);
    return out;
  }

  /// Apply saved merchant metadata onto a parsed SMS transaction.
  static ParsedSmsTransaction applyMerchant(
    ParsedSmsTransaction parsed,
    MerchantRecord merchant,
  ) {
    return parsed.copyWith(
      title: merchant.title,
      purpose: merchant.purpose,
      category: merchant.category,
      status: TransactionStatus.auto,
    );
  }

  /// Save or update merchant after user verification.
  /// Dedupes by [normalizedPayee] so local Hive + cloud never double-insert.
  static Future<MerchantRecord> saveVerified({
    required String payee,
    required String title,
    required String purpose,
    required String category,
    bool isAutoApply = true,
    bool mirrorLegacyRules = true,
  }) async {
    // Chain onto the previous call so two saves for the same payee arriving
    // close together can't both read "no existing record" before either
    // write lands (that read-check-write gap is how duplicates got created).
    final previous = _lock;
    final completer = Completer<void>();
    _lock = completer.future;
    await previous;
    try {
      return await _doSaveVerified(
        payee: payee,
        title: title,
        purpose: purpose,
        category: category,
        isAutoApply: isAutoApply,
        mirrorLegacyRules: mirrorLegacyRules,
      );
    } finally {
      completer.complete();
    }
  }

  static Future<MerchantRecord> _doSaveVerified({
    required String payee,
    required String title,
    required String purpose,
    required String category,
    required bool isAutoApply,
    required bool mirrorLegacyRules,
  }) async {
    await ensureOpen();

    final norm = PayeeNormalizer.normalize(payee);
    if (norm.isEmpty) {
      throw ArgumentError('Merchant payee is empty after normalize');
    }

    MerchantRecord? existing;
    final duplicateKeys = <dynamic>[];

    for (final key in _box.keys) {
      final raw = _box.get(key);
      if (raw is! Map) continue;
      final record = MerchantRecord.fromMap(Map<dynamic, dynamic>.from(raw));
      if (record.normalizedPayee != norm) continue;
      if (existing == null) {
        existing = record;
      } else {
        // Extra rows with same payee → remove after keep first.
        duplicateKeys.add(key);
      }
    }

    final now = DateTime.now();
    // Always prefer deterministic cloud id (unique on user_id + normalized_payee).
    final uid = AuthService.currentUserId;
    final stableId = (uid != null)
        ? SyncIds.forMerchant(uid, norm)
        : (existing?.id.isNotEmpty == true
            ? existing!.id
            : now.millisecondsSinceEpoch.toString());

    final record = MerchantRecord(
      id: stableId,
      payee: payee.trim().isNotEmpty ? payee.trim() : (existing?.payee ?? norm),
      normalizedPayee: norm,
      title: title.trim().isNotEmpty ? title.trim() : (existing?.title ?? norm),
      purpose: purpose.trim().isNotEmpty
          ? purpose.trim()
          : (existing?.purpose ?? 'Personal'),
      category: category.isNotEmpty ? category : (existing?.category ?? 'Other'),
      verifiedAt: now,
      isAutoApply: isAutoApply,
    );

    // Drop other keys for same norm (including old timestamp ids).
    if (existing != null) {
      for (final key in _box.keys.toList()) {
        final raw = _box.get(key);
        if (raw is! Map) continue;
        final r = MerchantRecord.fromMap(Map<dynamic, dynamic>.from(raw));
        if (r.normalizedPayee == norm && key.toString() != stableId) {
          duplicateKeys.add(key);
        }
      }
    }
    for (final key in duplicateKeys.toSet()) {
      await _box.delete(key);
    }

    final stored = {...record.toMap(), 'id': stableId};
    await _box.put(stableId, stored);

    // Keep legacy merchant_rules_box in sync (single upsert by norm).
    if (mirrorLegacyRules) {
      await MerchantRuleService.learnRule(
        identifier: norm,
        displayName: record.title,
        category: record.category,
        purposeType: record.purpose.isNotEmpty ? record.purpose : 'Personal',
        transactionType: 'any',
      );
    }

    // Cloud backup (per-user only — never global admin templates).
    try {
      SyncService.queueMerchantUpsert(Map<String, dynamic>.from(stored));
    } catch (_) {}

    try {
      await AutoDetectionNativeSync.syncMerchantsToNative();
    } catch (_) {}

    return MerchantRecord.fromMap(stored);
  }

  static Future<void> delete(String id) async {
    await ensureOpen();
    // Clean the legacy merchant_rules_box mirror too, then refresh the
    // native known_merchants_json snapshot — otherwise native/legacy paths
    // keep auto-recognizing a merchant the user deleted.
    final raw = _box.get(id);
    String? norm;
    if (raw is Map) {
      try {
        final record = MerchantRecord.fromMap(Map<dynamic, dynamic>.from(raw));
        norm = record.normalizedPayee;
        await _deleteLegacyMirror(record.normalizedPayee);
      } catch (_) {}
    }
    await _box.delete(id);
    try {
      SyncService.queueMerchantDelete(id, normalizedPayee: norm);
    } catch (_) {}
    await AutoDetectionNativeSync.syncMerchantsToNative();
  }

  static Future<void> _deleteLegacyMirror(String normalizedPayee) async {
    if (normalizedPayee.isEmpty) return;
    if (!Hive.isBoxOpen('merchant_rules_box')) return;
    final legacy = Hive.box('merchant_rules_box');
    final keysToDelete = <dynamic>[];
    for (final key in legacy.keys) {
      final raw = legacy.get(key);
      if (raw is! Map) continue;
      final norm = (raw['normalizedIdentifierKey'] ?? raw['identifier'] ?? '')
          .toString()
          .trim()
          .toLowerCase();
      if (norm == normalizedPayee) keysToDelete.add(key);
    }
    for (final key in keysToDelete) {
      await legacy.delete(key);
    }
  }

  static List<MerchantRecord> listAll() {
    if (!Hive.isBoxOpen(boxName)) return [];
    return _box.values
        .map((e) => MerchantRecord.fromMap(Map<dynamic, dynamic>.from(e)))
        .toList()
      ..sort((a, b) => b.verifiedAt.compareTo(a.verifiedAt));
  }

  /// Removes rows that share the same normalized payee, keeping only the
  /// most recently verified one. Cleans up duplicates already stored on a
  /// device from before the save-race above was closed. Safe to call
  /// repeatedly (e.g. every time the merchant list loads).
  static Future<void> dedupe() async {
    if (!Hive.isBoxOpen(boxName)) return;
    final byNorm = <String, MerchantRecord>{};
    final toDelete = <MerchantRecord>[];

    for (final key in _box.keys) {
      final raw = _box.get(key);
      if (raw is! Map) continue;
      final record = MerchantRecord.fromMap(Map<dynamic, dynamic>.from(raw));
      if (record.normalizedPayee.isEmpty) continue;
      final current = byNorm[record.normalizedPayee];
      if (current == null) {
        byNorm[record.normalizedPayee] = record;
      } else if (record.verifiedAt.isAfter(current.verifiedAt)) {
        toDelete.add(current);
        byNorm[record.normalizedPayee] = record;
      } else {
        toDelete.add(record);
      }
    }

    if (toDelete.isEmpty) return;
    for (final record in toDelete) {
      await _box.delete(record.id);
      try {
        SyncService.queueMerchantDelete(record.id, normalizedPayee: record.normalizedPayee);
      } catch (_) {}
    }
    await AutoDetectionNativeSync.syncMerchantsToNative();
  }
}