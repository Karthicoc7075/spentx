import 'package:hive_flutter/hive_flutter.dart';

import '../detected/detected_sms_storage.dart';
import '../detected/pending_model.dart';
import '../../../data/local/hive_service.dart';

/// Central store for SMS pending verifications (Hive source of truth).
class SmsPendingService {
  SmsPendingService._();

  static const _queueBox = 'pending_detections';
  static const _clickTargetKey = 'pending_notification_tx_id';

  /// Save pending SMS and sync the id queue used by Detected SMS screen.
  static String save(PendingTransaction pending) {
    DetectedSmsStorage.save(pending);
    _ensureInQueue(pending.id);
    return pending.id;
  }

  static void _ensureInQueue(String txId) {
    if (!Hive.isBoxOpen(_queueBox)) return;
    final box = Hive.box(_queueBox);
    final queue = List<String>.from(box.get('queue', defaultValue: const <dynamic>[]));
    if (!queue.contains(txId)) {
      queue.add(txId);
      box.put('queue', queue);
    }
  }

  /// All items awaiting user verification (excludes background-deferred auto-adds).
  static List<PendingTransaction> listAwaitingVerification() {
    return DetectedSmsStorage.getAll()
        .where((p) => !p.deferAutoAdd)
        .toList()
      ..sort((a, b) => b.date.compareTo(a.date));
  }

  static PendingTransaction? get(String id) => DetectedSmsStorage.get(id);

  static void remove(String id) {
    DetectedSmsStorage.remove(id);
    _removeFromQueue(id);
  }

  static void _removeFromQueue(String txId) {
    if (!Hive.isBoxOpen(_queueBox)) return;
    final box = Hive.box(_queueBox);
    final queue = List<String>.from(box.get('queue', defaultValue: const <dynamic>[]));
    if (queue.remove(txId)) {
      box.put('queue', queue);
    }
  }

  /// Persist notification tap target across cold start (providers reset).
  static Future<void> storeNotificationTapTarget(String transactionId) async {
    if (!Hive.isBoxOpen('settings')) {
      await SecureHive.openBox('settings');
    }
    await Hive.box('settings').put(_clickTargetKey, transactionId);
    _ensureInQueue(transactionId);
    DetectedSmsStorage.reconcilePendingQueue();
  }

  /// Consume stored tap target after app UI is ready.
  static String? consumeNotificationTapTarget() {
    if (!Hive.isBoxOpen('settings')) return null;
    final box = Hive.box('settings');
    final id = box.get(_clickTargetKey)?.toString();
    if (id != null && id.isNotEmpty) {
      box.delete(_clickTargetKey);
      return id;
    }
    return null;
  }

  static void reconcile() => DetectedSmsStorage.reconcilePendingQueue();
}