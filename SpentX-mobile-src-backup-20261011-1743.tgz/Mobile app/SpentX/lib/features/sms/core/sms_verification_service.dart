import '../v4/merchant_learning_service.dart';
import '../v4/models/merchant_record.dart';
import '../v4/payee_normalizer.dart';

/// Persists merchant data after the user confirms a pending SMS in the verification sheet.
class SmsVerificationService {
  SmsVerificationService._();

  /// Create or update a merchant keyed by normalized payee.
  static Future<MerchantRecord> saveMerchant({
    required String payee,
    required String title,
    required String category,
    required String purpose,
  }) {
    return MerchantLearningService.saveVerified(
      payee: payee,
      title: title.trim(),
      category: category,
      purpose: purpose.isNotEmpty ? purpose : 'Personal',
    );
  }

  /// Stable lookup key used for merchant matching on future SMS.
  static String normalizedPayeeKey(String payee) => PayeeNormalizer.normalize(payee);
}