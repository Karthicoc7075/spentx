import '../../sms_parser/models/transaction_parsed.dart';
import '../../sms_parser/sms_direction_helper.dart';
import '../rules/engine/sms_rule_engine.dart';
import '../v4/bank_sms_v4_parser.dart';
import '../v4/merchant_match_resolver.dart';
import '../v4/models/parsed_sms_transaction.dart';
import '../v4/payee_extractor.dart';

/// Production SMS parser — backed by `bank_sms_templates_v4.json`.
///
/// Usage:
/// ```dart
/// await SmsParserService.ensureReady();
/// final result = SmsParserService.parse(smsBody);
/// if (result != null) {
///   print(result.payee);        // raw SMS payee (matching key)
///   print(result.displayTitle); // saved title or payee
///   print(result.isKnownMerchant);
/// }
/// ```
class SmsParserService {
  SmsParserService._();

  /// Load v4 templates once at app startup (also called from [main.dart]).
  static Future<void> ensureReady() => BankSmsV4Parser.ensureLoaded();

  /// Parse a bank SMS and resolve merchant match in one call.
  static SmsParseResult? parse(
    String rawMessage, {
    DateTime? receivedAt,
  }) {
    final body = rawMessage.trim();
    if (body.isEmpty) return null;

    if (SmsRuleEngine.isBlocked(body)) return null;

    final legacy = SmsRuleEngine.parse(body, smsReceivedTime: receivedAt);
    if (legacy == null) return null;

    final payee = PayeeExtractor.extract(body) ?? legacy.name;
    final merchant = MerchantMatchResolver.resolve(
      rawMessage: body,
      parsed: legacy,
      requireAutoApply: true,
    );

    final type = SmsDirectionHelper.typeLabel(rawMessage: body, parsed: legacy);

    return SmsParseResult(
      amount: legacy.amount,
      payee: merchant.payee.isNotEmpty ? merchant.payee : payee,
      normalizedPayee: merchant.normalizedPayee,
      displayTitle: merchant.displayTitle,
      category: merchant.category,
      purpose: merchant.purpose,
      bank: legacy.bank,
      date: legacy.dateTime,
      accountLast4: legacy.accountLast4,
      referenceId: legacy.referenceId,
      upiId: legacy.upiId,
      transactionType: _typeKey(type, legacy),
      isExpense: legacy.direction == TransactionDirection.expense,
      isTransfer: legacy.direction == TransactionDirection.transfer,
      isKnownMerchant: merchant.isKnown,
      merchantRule: merchant.rule,
      rawMessage: body,
      legacyParsed: legacy,
    );
  }

  static String _typeKey(String label, TransactionParsed parsed) {
    if (parsed.direction == TransactionDirection.transfer) return 'transfer';
    if (parsed.direction == TransactionDirection.income) return 'credit';
    return 'debit';
  }

  /// Bridge to v4 [ParsedSmsTransaction] when needed by merchant orchestrator.
  static ParsedSmsTransaction? parseV4(
    String rawMessage, {
    DateTime? receivedAt,
  }) {
    return BankSmsV4Parser.parseSync(rawMessage, receivedAt: receivedAt);
  }
}

/// Unified parse + merchant match output.
class SmsParseResult {
  final double amount;
  final String payee;
  final String normalizedPayee;
  final String displayTitle;
  final String category;
  final String purpose;
  final String bank;
  final DateTime date;
  final String accountLast4;
  final String referenceId;
  final String upiId;
  final String transactionType;
  final bool isExpense;
  final bool isTransfer;
  final bool isKnownMerchant;
  final dynamic merchantRule;
  final String rawMessage;
  final TransactionParsed legacyParsed;

  const SmsParseResult({
    required this.amount,
    required this.payee,
    required this.normalizedPayee,
    required this.displayTitle,
    required this.category,
    required this.purpose,
    required this.bank,
    required this.date,
    required this.accountLast4,
    required this.referenceId,
    required this.upiId,
    required this.transactionType,
    required this.isExpense,
    required this.isTransfer,
    required this.isKnownMerchant,
    required this.merchantRule,
    required this.rawMessage,
    required this.legacyParsed,
  });
}