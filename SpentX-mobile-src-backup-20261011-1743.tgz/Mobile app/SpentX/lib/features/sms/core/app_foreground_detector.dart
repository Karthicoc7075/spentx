import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Tracks whether the app UI is actively in the foreground.
///
/// SMS routing:
/// - **resumed** → known payee: auto-add via Riverpod. Unknown: verify popup.
/// - **background** (paused/hidden/detached) → known payee: auto-add to Hive + notification.
///   Unknown: pending + verify notification.
class AppForegroundDetector {
  AppForegroundDetector._();

  static WidgetRef? _ref;
  static BuildContext? _context;
  static AppLifecycleState _lifecycleState = AppLifecycleState.resumed;

  static void bind({required WidgetRef ref, required BuildContext context}) {
    _ref = ref;
    _context = context;
  }

  static void unbind() {
    _ref = null;
    _context = null;
  }

  /// Call from [WidgetsBindingObserver.didChangeAppLifecycleState].
  static void onLifecycleChange(AppLifecycleState state) {
    _lifecycleState = state;
  }

  /// True only when app is [AppLifecycleState.resumed] and UI context is bound.
  static bool get isInForeground {
    if (_lifecycleState != AppLifecycleState.resumed) return false;
    final ctx = _context;
    final ref = _ref;
    return ctx != null && ref != null && ctx.mounted;
  }

  static bool get isInBackground =>
      _lifecycleState == AppLifecycleState.paused ||
      _lifecycleState == AppLifecycleState.hidden ||
      _lifecycleState == AppLifecycleState.detached;

  static WidgetRef get ref => _ref!;
  static BuildContext get context => _context!;
}