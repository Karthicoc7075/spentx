import 'dart:convert';

import '../sms_notification.dart';
import '../sms_notification_copy.dart';
import '../../../core/services/notification_history_service.dart';
import '../../../core/services/pending_verification_history_service.dart';

/// Builds and shows SMS detection notifications.
///
/// | Case | Title | Body |
/// |------|-------|------|
/// | New payee | `Spent ₹[amount] - Verify` | `[Payee] • [Bank]` |
/// | Known merchant | `Spent ₹[amount] - Added` | `added below [Title] and [Bank]` |
class SmsNotificationHandler {
  SmsNotificationHandler._();

  /// Unknown payee — user must verify in app.
  static Future<void> showVerifyRequired({
    required double amount,
    required String payee,
    required String bank,
    required String type,
    required String transactionId,
  }) async {
    final copy = SmsNotificationCopy.build(
      type: type,
      amount: amount,
      merchantExists: false,
      merchantTitle: null,
      payee: payee,
      bank: bank,
    );

    final payload = jsonEncode({
      'transactionId': transactionId,
      'pending': true,
    });

    await SmsNotificationService.showPendingNotification(
      amount: amount,
      merchant: payee,
      bank: bank,
      type: type,
      payload: payload,
      transactionId: transactionId,
      titleOverride: copy.title,
      bodyOverride: copy.body,
    );

    NotificationHistoryService.add(
      title: 'SMS needs verification',
      body: SmsNotificationCopy.displayLine(title: copy.title, body: copy.body),
      type: 'sms_pending',
    );

    await PendingVerificationHistoryService.recordPending(
      transactionId: transactionId,
      amount: amount,
      merchant: payee,
      bank: bank,
      type: type,
      notificationShown: true,
    );
  }

  /// Known merchant — auto-added (foreground) or deferred (background).
  static Future<void> showKnownMerchant({
    required double amount,
    required String title,
    required String bank,
    required String type,
    String? transactionId,
    bool pending = false,
  }) async {
    final copy = SmsNotificationCopy.build(
      type: type,
      amount: amount,
      merchantExists: true,
      merchantTitle: title,
      payee: null,
      bank: bank,
    );

    await SmsNotificationService.showTransactionAutoAdded(
      amount: amount,
      merchant: title,
      bank: bank,
      type: type,
      transactionId: transactionId,
      titleOverride: copy.title,
      bodyOverride: copy.body,
    );

    NotificationHistoryService.add(
      title: pending ? 'SMS detected' : 'Auto-detected transaction',
      body: SmsNotificationCopy.displayLine(title: copy.title, body: copy.body),
      type: pending ? 'sms_pending' : 'sms_auto',
    );
  }
}