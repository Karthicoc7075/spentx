/// Standard SMS detection notification copy.
///
/// Always includes a useful body (payee/merchant + bank) so the system tray
/// never shows only "Spent ₹120 - Verify" with an empty body.
class SmsNotificationCopy {
  SmsNotificationCopy._();

  /// [type] is one of: `debit`, `credit`, `transfer` (ATM).
  static ({String title, String body}) build({
    required String type,
    required double amount,
    required bool merchantExists,
    String? merchantTitle,
    String? payee,
    String? bank,
    String? outingTitle,
  }) {
    final amountStr = _formatAmount(amount);
    final payeeLabel = _firstNonEmpty([
      merchantTitle,
      payee,
    ]) ?? (merchantExists ? 'Merchant' : 'Unknown payee');

    // 1. ACTIVE OUTING NOTIFICATION
    if (outingTitle != null && outingTitle.trim().isNotEmpty) {
      final cleanOuting = outingTitle.trim();
      final outingHeader = cleanOuting.startsWith('🏖') ? cleanOuting : '🏖 $cleanOuting';
      return (
        title: outingHeader,
        body: 'Spent ₹$amountStr • Added to Outing',
      );
    }

    final normalizedType = type.trim().toLowerCase();

    // 2. NEW MERCHANT (VERIFY PATH)
    if (!merchantExists) {
      switch (normalizedType) {
        case 'credit':
        case 'income':
          return (
            title: '💸 Credit ₹$amountStr',
            body: 'New source detected. • Verify',
          );
        case 'transfer':
        case 'atm':
          return (
            title: '💸 ATM Withdraw ₹$amountStr',
            body: 'New ATM detected. • Verify',
          );
        default:
          return (
            title: '💸 Spent ₹$amountStr',
            body: 'New merchant detected. • Verify',
          );
      }
    }

    // 3. EXISTING MERCHANT (AUTO-ADDED)
    switch (normalizedType) {
      case 'credit':
      case 'income':
        return (
          title: '💸 Credit ₹$amountStr',
          body: '$payeeLabel • Added successfully.',
        );
      case 'transfer':
      case 'atm':
        return (
          title: '💸 ATM Withdraw ₹$amountStr',
          body: '$payeeLabel • Added successfully.',
        );
      default:
        return (
          title: '💸 Spent ₹$amountStr',
          body: '$payeeLabel • Added successfully.',
        );
    }
  }

  static String displayLine({required String title, required String body}) =>
      body.isEmpty ? title : '$title • $body';

  static String _formatAmount(double amount) {
    if (amount == amount.roundToDouble()) {
      return amount.toStringAsFixed(0);
    }
    return amount.toStringAsFixed(2);
  }

  static String? _firstNonEmpty(List<String?> values) {
    for (final v in values) {
      final t = v?.trim();
      if (t != null && t.isNotEmpty) return t;
    }
    return null;
  }
}
