import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/sms_rule.dart';
import '../sms_hive_boxes.dart';
import '../../../../data/local/hive_service.dart';

final smsRuleProvider = StateNotifierProvider<SmsRuleNotifier, List<SmsRule>>((ref) {
  return SmsRuleNotifier();
});

class SmsRuleNotifier extends StateNotifier<List<SmsRule>> {
  final String _boxName = SmsHiveBoxes.regexRules;

  SmsRuleNotifier() : super([]) {
    _loadRules();
  }

  Future<void> _loadRules() async {
    if (!Hive.isBoxOpen(_boxName)) {
      await SecureHive.openBox(_boxName);
    }
    final box = Hive.box(_boxName);
    state = box.values.map((e) => SmsRule.fromMap(Map<dynamic, dynamic>.from(e))).toList();
  }

  Future<void> addRule(SmsRule rule) async {
    if (!Hive.isBoxOpen(_boxName)) await SecureHive.openBox(_boxName);
    final box = Hive.box(_boxName);
    await box.put(rule.id, rule.toMap());
    _loadRules();
  }

  Future<void> deleteRule(String id) async {
    if (!Hive.isBoxOpen(_boxName)) await SecureHive.openBox(_boxName);
    final box = Hive.box(_boxName);
    await box.delete(id);
    _loadRules();
  }

  void refresh() => _loadRules();
}
