import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/sms_template_rule.dart';
import '../models/block_rule.dart';
import '../sms_hive_boxes.dart';
import '../../../../data/local/hive_service.dart';

final smsTemplateRuleProvider = StateNotifierProvider<SmsTemplateRuleNotifier, List<SmsTemplateRule>>((ref) {
  return SmsTemplateRuleNotifier();
});

class SmsTemplateRuleNotifier extends StateNotifier<List<SmsTemplateRule>> {
  static const String _boxName = SmsHiveBoxes.templateRules;

  SmsTemplateRuleNotifier() : super([]) {
    _load();
  }

  Future<void> _load() async {
    if (!Hive.isBoxOpen(_boxName)) {
      await SecureHive.openBox(_boxName);
    }
    final box = Hive.box(_boxName);
    state = box.values
        .map((e) => SmsTemplateRule.fromMap(Map<dynamic, dynamic>.from(e)))
        .toList();
  }

  Future<void> addRule(SmsTemplateRule rule) async {
    if (!Hive.isBoxOpen(_boxName)) await SecureHive.openBox(_boxName);
    await Hive.box(_boxName).put(rule.id, rule.toMap());
    _load();
  }

  Future<void> deleteRule(String id) async {
    if (!Hive.isBoxOpen(_boxName)) await SecureHive.openBox(_boxName);
    await Hive.box(_boxName).delete(id);
    _load();
  }

  void refresh() => _load();
}

final blockRuleProvider = StateNotifierProvider<BlockRuleNotifier, List<BlockRule>>((ref) {
  return BlockRuleNotifier();
});

class BlockRuleNotifier extends StateNotifier<List<BlockRule>> {
  static const String _boxName = SmsHiveBoxes.blockRules;

  BlockRuleNotifier() : super([]) {
    _load();
  }

  Future<void> _load() async {
    if (!Hive.isBoxOpen(_boxName)) await SecureHive.openBox(_boxName);
    final box = Hive.box<dynamic>(_boxName);
    state = box.values
        .map((e) => BlockRule.fromMap(Map<dynamic, dynamic>.from(e)))
        .toList();
  }

  Future<void> addRule(BlockRule rule) async {
    if (!Hive.isBoxOpen(_boxName)) await SecureHive.openBox(_boxName);
    await Hive.box<dynamic>(_boxName).put(rule.id, rule.toMap());
    _load();
  }

  Future<void> updateRule(BlockRule rule) async {
    if (!Hive.isBoxOpen(_boxName)) await SecureHive.openBox(_boxName);
    await Hive.box<dynamic>(_boxName).put(rule.id, rule.toMap());
    _load();
  }

  Future<void> deleteRule(String id) async {
    if (!Hive.isBoxOpen(_boxName)) await SecureHive.openBox(_boxName);
    await Hive.box<dynamic>(_boxName).delete(id);
    _load();
  }

  void refresh() => _load();
}
