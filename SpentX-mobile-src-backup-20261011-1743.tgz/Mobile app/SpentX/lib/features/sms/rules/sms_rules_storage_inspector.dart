import 'dart:convert';

import 'package:hive_flutter/hive_flutter.dart';

import '../../settings/data/sms_default_rules_catalog.dart';
import '../../settings/data/sms_parser_rule_engine_prompt.dart';
import 'models/block_rule.dart';
import 'models/sms_rule.dart';
import 'sms_hive_boxes.dart';
import 'engine/sms_rule_engine.dart';
import 'engine/sms_template_engine.dart';

/// Reads live Hive rule data + built-in catalog for the SMS Rules Storage screen.
class SmsRulesStorageInspector {
  SmsRulesStorageInspector._();

  static final _encoder = const JsonEncoder.withIndent('  ');

  static Future<void> ensureReady() async {
    await SmsRuleEngine.init();
  }

  static String formatJson(dynamic value) {
    try {
      return _encoder.convert(value);
    } catch (_) {
      return value.toString();
    }
  }

  static Future<Map<String, dynamic>> loadFullSnapshot() async {
    await ensureReady();
    final stored = await loadStoredRules();
    return {
      'generatedAt': DateTime.now().toIso8601String(),
      'promptSpec': smsParserRuleEnginePrompt,
      'defaultRules': SmsDefaultRulesCatalog.toJson(),
      'storedRules': stored,
      'hiveBoxSummary': _boxSummary(stored),
    };
  }

  static Future<Map<String, dynamic>> loadStoredRules() async {
    await ensureReady();

    final templates = _loadTemplateRules();
    final regex = _loadRegexRules();
    final blocks = _loadBlockRules();
    final ignored = _loadIgnoredSms();
    final processed = _loadProcessedSms();

    return {
      'templateRules': {
        'hiveBox': SmsHiveBoxes.templateRules,
        'count': templates.length,
        'rules': templates,
      },
      'regexRules': {
        'hiveBox': SmsHiveBoxes.regexRules,
        'count': regex.length,
        'rules': regex,
      },
      'blockRules': {
        'hiveBox': SmsHiveBoxes.blockRules,
        'count': blocks.length,
        'rules': blocks,
      },
      'ignoredSmsLog': {
        'hiveBox': SmsHiveBoxes.ignoredSms,
        'count': ignored.length,
        'entries': ignored,
      },
      'processedSmsLog': {
        'hiveBox': SmsHiveBoxes.processedSms,
        'count': processed.length,
        'entries': processed,
      },
    };
  }

  static Map<String, dynamic> _boxSummary(Map<String, dynamic> stored) {
    return {
      SmsHiveBoxes.templateRules: stored['templateRules']?['count'] ?? 0,
      SmsHiveBoxes.regexRules: stored['regexRules']?['count'] ?? 0,
      SmsHiveBoxes.blockRules: stored['blockRules']?['count'] ?? 0,
      SmsHiveBoxes.ignoredSms: stored['ignoredSmsLog']?['count'] ?? 0,
      SmsHiveBoxes.processedSms: stored['processedSmsLog']?['count'] ?? 0,
    };
  }

  static List<Map<String, dynamic>> _loadTemplateRules() {
    final rules = SmsTemplateEngine.getAllRules();
    return rules.map((r) => r.toMap()).toList();
  }

  static List<Map<String, dynamic>> _loadRegexRules() {
    if (!Hive.isBoxOpen(SmsHiveBoxes.regexRules)) return [];
    final box = Hive.box(SmsHiveBoxes.regexRules);
    return box.values
        .map((e) => SmsRule.fromMap(Map<dynamic, dynamic>.from(e)).toMap())
        .toList();
  }

  static List<Map<String, dynamic>> _loadBlockRules() {
    if (!Hive.isBoxOpen(SmsHiveBoxes.blockRules)) return [];
    final box = Hive.box<dynamic>(SmsHiveBoxes.blockRules);
    return box.values
        .map((e) => BlockRule.fromMap(Map<dynamic, dynamic>.from(e)).toMap())
        .toList();
  }

  static List<Map<String, dynamic>> _loadIgnoredSms() {
    if (!Hive.isBoxOpen(SmsHiveBoxes.ignoredSms)) return [];
    final box = Hive.box<dynamic>(SmsHiveBoxes.ignoredSms);
    return box.values
        .map((e) => Map<String, dynamic>.from(e as Map))
        .take(50)
        .toList();
  }

  static List<Map<String, dynamic>> _loadProcessedSms() {
    if (!Hive.isBoxOpen(SmsHiveBoxes.processedSms)) return [];
    final box = Hive.box<dynamic>(SmsHiveBoxes.processedSms);
    return box.values
        .map((e) => Map<String, dynamic>.from(e as Map))
        .take(50)
        .toList();
  }
}