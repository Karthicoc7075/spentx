import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:uuid/uuid.dart';

import 'engine/sms_rule_engine.dart';
import 'models/sms_template_rule.dart';
import 'sms_hive_boxes.dart';

class SmsTemplateImportResult {
  final int imported;
  final int skipped;
  final List<String> errors;

  const SmsTemplateImportResult({
    required this.imported,
    required this.skipped,
    this.errors = const [],
  });

  bool get success => errors.isEmpty || imported > 0;
}

/// Import bundled or pasted default template rules into Hive.
class SmsTemplateRulesImporter {
  SmsTemplateRulesImporter._();

  static const bundledAssetPath = 'assets/sms/default_template_rules.json';

  /// Load rules from JSON string. Accepts:
  /// - `[{...}, {...}]`
  /// - `{"rules": [{...}]}`
  /// - single rule `{ "id": "...", "sampleMessage": "...", ... }`
  static List<Map<String, dynamic>> parseRuleMaps(String raw) {
    final trimmed = raw.trim();
    if (trimmed.isEmpty) return [];

    final decoded = jsonDecode(trimmed);
    if (decoded is List) {
      return decoded
          .whereType<Map>()
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
    }
    if (decoded is Map) {
      final map = Map<String, dynamic>.from(decoded);
      if (map['rules'] is List) {
        return (map['rules'] as List)
            .whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e))
            .toList();
      }
      if (map['templateRules'] is Map) {
        final inner = Map<String, dynamic>.from(map['templateRules'] as Map);
        if (inner['rules'] is List) {
          return (inner['rules'] as List)
              .whereType<Map>()
              .map((e) => Map<String, dynamic>.from(e))
              .toList();
        }
      }
      if (_looksLikeTemplateRule(map)) return [map];
    }
    return [];
  }

  static bool _looksLikeTemplateRule(Map<String, dynamic> map) {
    return map.containsKey('sampleMessage') &&
        (map.containsKey('templatePattern') || map.containsKey('extractionMap'));
  }

  static SmsTemplateRule _normalizeRule(Map<String, dynamic> map) {
    final id = (map['id']?.toString().trim().isNotEmpty ?? false)
        ? map['id'].toString()
        : const Uuid().v4();
    return SmsTemplateRule.fromMap({...map, 'id': id});
  }

  static Future<SmsTemplateImportResult> importFromJsonString(
    String raw, {
    bool overwriteExisting = false,
  }) async {
    await SmsRuleEngine.init();
    final maps = parseRuleMaps(raw);
    if (maps.isEmpty) {
      return const SmsTemplateImportResult(
        imported: 0,
        skipped: 0,
        errors: ['No template rules found in JSON'],
      );
    }

    final box = Hive.box(SmsHiveBoxes.templateRules);
    var imported = 0;
    var skipped = 0;
    final errors = <String>[];

    for (final map in maps) {
      try {
        final rule = _normalizeRule(map);
        if (rule.sampleMessage.trim().isEmpty || rule.templatePattern.trim().isEmpty) {
          skipped++;
          errors.add('Skipped ${rule.id}: missing sampleMessage or templatePattern');
          continue;
        }
        if (!overwriteExisting && box.containsKey(rule.id)) {
          skipped++;
          continue;
        }
        await box.put(rule.id, rule.toMap());
        imported++;
      } catch (e) {
        skipped++;
        errors.add('Parse error: $e');
      }
    }

    return SmsTemplateImportResult(imported: imported, skipped: skipped, errors: errors);
  }

  /// Seeds [bundledAssetPath] when template box is empty (first install).
  static Future<int> seedBundledDefaultsIfEmpty() async {
    await SmsRuleEngine.init();
    final box = Hive.box(SmsHiveBoxes.templateRules);
    if (box.isNotEmpty) return 0;

    try {
      final raw = await rootBundle.loadString(bundledAssetPath);
      final result = await importFromJsonString(raw);
      return result.imported;
    } catch (_) {
      return 0;
    }
  }

  static String exampleSchemaJson() {
    return const JsonEncoder.withIndent('  ').convert({
      'rules': [
        {
          'id': 'hdfc_upi_debit_example',
          'bankName': 'HDFC',
          'bankNameExact': 'HDFC Bank',
          'type': 'debit',
          'mode': 'upi',
          'sampleMessage': 'Rs.150.00 debited from HDFC Bank A/c **1234 to merchant@upi',
          'templatePattern': 'Rs.{AMOUNT} debited from {BANKNAME} A/c {ACCOUNTLAST4} to {UPIID}',
          'extractionMap': {
            'Rs.150.00': 'amount',
            'HDFC Bank': 'bankName',
            '**1234': 'accountLast4',
            'merchant@upi': 'upiId',
          },
          'exactTaggedValues': {
            'amount': 'Rs.150.00',
            'bankName': 'HDFC Bank',
            'accountLast4': '**1234',
            'upiId': 'merchant@upi',
          },
          'keywords': ['debited', 'hdfc', 'a/c'],
          'similarityThreshold': 0.65,
          'structuralParts': ['debited from', 'A/c', 'to'],
        },
      ],
    });
  }
}