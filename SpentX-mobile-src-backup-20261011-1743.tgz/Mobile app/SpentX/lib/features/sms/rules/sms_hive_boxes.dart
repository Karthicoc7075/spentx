/// Hive box names for SMS rules — keep in sync with [SmsRuleEngine.init] and providers.
class SmsHiveBoxes {
  static const templateRules = 'sms_template_rules_box';
  static const blockRules = 'block_rules_box';
  static const regexRules = 'detection_rules_box';
  static const ignoredSms = 'ignored_sms_box';
  static const processedSms = 'processed_sms_box';

  /// Legacy box from older builds — migrated into [blockRules] on startup.
  static const legacyBlockRules = 'sms_block_rules_box';

  /// Legacy regex/template boxes — migrated on startup into current boxes.
  static const legacyRegexRules = 'sms_rules_box';
  static const legacyTemplateRules = 'sms_template_box';

  static const allRuleBoxes = [
    templateRules,
    blockRules,
    regexRules,
    ignoredSms,
    processedSms,
  ];
}