import 'package:hive_flutter/hive_flutter.dart';
import '../../../sms_parser/models/transaction_parsed.dart';
import '../../../sms_parser/sms_parser.dart';
import '../../../sms_parser/sms_direction_helper.dart';
import '../../../sms_parser/sms_transaction_filters.dart';
import '../../../sms_parser/bank_title_extractor.dart';
import '../../../sms_parser/sms_parse_debug_info.dart';
import '../../../../core/debug/master_debug_log.dart';
import '../../../../core/debug/master_debug_module.dart';
import '../models/sms_rule.dart';
import '../models/block_rule.dart';
import '../sms_hive_boxes.dart';
import 'sms_template_engine.dart';
import '../../v4/bank_sms_v4_parser.dart';
import '../../../../data/local/hive_service.dart';
import '../../../../core/utils/bank_keywords.dart';

class SmsRuleEngine {
  static SmsParseDebugInfo? lastParseDebug;
  static Future<void> init() async {
    await _openRuleBoxes();
    await SmsTemplateEngine.init();
  }

  /// Ensures Hive rule boxes are open before reading (live SMS, lab, background).
  static Future<void> _openRuleBoxes() async {
    for (final name in SmsHiveBoxes.allRuleBoxes) {
      if (!Hive.isBoxOpen(name)) await SecureHive.openBox(name);
    }
  }

  static String normalizeMessage(String text) {
    return text.toLowerCase().trim().replaceAll(RegExp(r'\s+'), ' ');
  }

  /// Check if the message matches any block rule using keyword contains or similarity.
  static bool isBlocked(String message) {
    if (!Hive.isBoxOpen(SmsHiveBoxes.blockRules)) return false;
    final box = Hive.box<dynamic>(SmsHiveBoxes.blockRules);
    final normalized = normalizeMessage(message);

    for (final rawRule in box.values) {
      final rule = BlockRule.fromMap(Map<dynamic, dynamic>.from(rawRule));
      
      // 1) Regex pattern check
      if (rule.pattern != null && rule.pattern!.isNotEmpty) {
        try {
          if (RegExp(rule.pattern!, caseSensitive: false).hasMatch(normalized)) return true;
        } catch (_) {}
      }
      
      // 2) Keyword match / contains match / similarity score
      if (rule.keywords.isNotEmpty) {
        final containsKeyword = rule.keywords.any((kw) => normalized.contains(kw.toLowerCase().trim()));
        if (containsKeyword) return true;

        final score = rule.matchScore(normalized);
        if (score >= rule.similarityThreshold) return true;
      }
    }
    return false;
  }

  static void ignoreMessage(String message, String reason) {
    if (!Hive.isBoxOpen(SmsHiveBoxes.ignoredSms)) return;
    final box = Hive.box<dynamic>(SmsHiveBoxes.ignoredSms);
    box.add({
      'rawMessage': message,
      'reason': reason,
      'time': DateTime.now().toIso8601String(),
    });
  }

  static void _logProcessed(String message, SmsRule rule, TransactionParsed parsed) {
    if (!Hive.isBoxOpen(SmsHiveBoxes.processedSms)) return;
    final box = Hive.box<dynamic>(SmsHiveBoxes.processedSms);
    box.add({
      'rawMessage': message,
      'ruleId': rule.id,
      'bank': rule.bankName,
      'amount': parsed.amount,
      'type': rule.type,
      'referenceId': parsed.referenceId,
      'time': DateTime.now().toIso8601String(),
    });
  }

  static void _logTemplateProcessed(String message, String ruleId, String bank, TransactionParsed parsed) {
    if (!Hive.isBoxOpen(SmsHiveBoxes.processedSms)) return;
    final box = Hive.box<dynamic>(SmsHiveBoxes.processedSms);
    box.add({
      'rawMessage': message,
      'ruleId': ruleId,
      'bank': bank,
      'amount': parsed.amount,
      'type': parsed.direction == TransactionDirection.income ? 'Credit' : 'Debit',
      'referenceId': parsed.referenceId,
      'time': DateTime.now().toIso8601String(),
      'source': 'template',
    });
  }

  /// Master parse method. Priority order:
  ///   1) Block check (stop immediately)
  ///   2) Template check (trained templates & custom rules)
  ///   3) Regex / keyword rules (user-trained)
  ///   4) Fallback parser
  ///
  /// Reads rules from Hive on every call — no in-memory cache.
  static TransactionParsed? parse(
    String message, {
    DateTime? smsReceivedTime,
    String? sender,
  }) {
    lastParseDebug = null;
    _currentSender = sender;

    // STEP 0: FAILED TXN + ADVERTISEMENT + NON-TRANSACTION ALERTS (hard ignore)
    if (SmsTransactionFilters.isFailedTransaction(message)) {
      ignoreMessage(message, 'Failed/declined transaction SMS');
      return null;
    }
    if (SmsTransactionFilters.isAdvertisement(message)) {
      ignoreMessage(message, 'Advertisement / non-transaction SMS');
      return null;
    }
    if (SmsTransactionFilters.isNonTransaction(message)) {
      ignoreMessage(message, 'Non-financial transaction SMS (account update, promo, OTP, info)');
      return null;
    }

    // STEP 1: BLOCK RULES (user-trained)
    if (isBlocked(message)) {
      ignoreMessage(message, 'Blocked SMS matched');
      if (MasterDebugLog.isEnabled) {
        MasterDebugLog.ruleEngine(
          title: 'Block Rule Match',
          message: 'SMS blocked by user rule',
          level: MasterDebugLevel.warning,
        );
      }
      return null;
    }

    // STEP 2: BUNDLED v4 BANK TEMPLATES (bank_sms_templates_v4.json — Payee/Title extraction)
    final v4Parsed = BankSmsV4Parser.parseSync(message, receivedAt: smsReceivedTime);
    if (v4Parsed != null) {
      final legacy = BankSmsV4Parser.toLegacyParsed(v4Parsed);
      if (legacy != null) {
        final corrected = _finalizeParsed(
          legacy,
          message,
          source: 'v4_template',
          matchedTemplate: v4Parsed.matchedTemplateId,
          skipTitleFallback: true,
        );
        if (MasterDebugLog.isEnabled) {
          MasterDebugLog.ruleEngine(
            title: 'V4 Template Match',
            message: v4Parsed.matchedTemplateId,
            data: {
              'bank': corrected.bank,
              'amount': corrected.amount,
              'payee': v4Parsed.payee,
            },
          );
        }
        return corrected;
      }
    }

    // STEP 3: USER-TRAINED TEMPLATE RULES (per-bank structure)
    final templateMatch = SmsTemplateEngine.tryMatch(message, smsReceivedTime: smsReceivedTime);
    if (templateMatch != null) {
      final corrected = _finalizeParsed(
        templateMatch.parsed,
        message,
        source: 'template',
        matchedTemplate: templateMatch.ruleId,
        skipTitleFallback: templateMatch.hasTaggedTitle,
      );
      _logTemplateProcessed(
        message,
        templateMatch.ruleId,
        corrected.bank,
        corrected,
      );
      if (MasterDebugLog.isEnabled) {
        MasterDebugLog.ruleEngine(
          title: 'Template Match',
          message: 'Rule ${templateMatch.ruleId}',
          data: {'bank': corrected.bank, 'amount': corrected.amount},
        );
      }
      return corrected;
    }

    // STEP 4: REGEX / KEYWORD RULES (advanced — use original SMS, not collapsed text)
    final regexResult = _tryRegexRules(message);
    if (regexResult != null) {
      final corrected = _finalizeParsed(
        regexResult.parsed,
        message,
        source: 'regex_rule',
        matchedRule: regexResult.rule.id,
      );
      _logProcessed(message, regexResult.rule, corrected);
      if (MasterDebugLog.isEnabled) {
        MasterDebugLog.ruleEngine(
          title: 'Regex Match',
          message: regexResult.rule.id,
          data: {'bank': corrected.bank, 'amount': corrected.amount},
        );
      }
      return corrected;
    }

    // STEP 5: FALLBACK PARSER + bank-specific title rules
    final fallback = UniversalSmsParser.parseSms(message);
    if (fallback == null) return null;
    if (MasterDebugLog.isEnabled) {
      MasterDebugLog.ruleEngine(
        title: 'Fallback Parser Used',
        message: fallback.bank,
        data: {'amount': fallback.amount, 'merchant': fallback.name},
      );
    }
    return _finalizeParsed(fallback, message, source: 'fallback_parser');
  }

  /// Sender of the message currently being parsed (set by [parse]).
  static String? _currentSender;

  /// Bank and account checked against the message itself.
  ///
  /// v4 templates are matched by similarity, so a Kotak "Sent Rs.99 from
  /// Kotak Bank AC X1234" could land on the HDFC template and come back as
  /// HDFC with the template sample's last-4 (0034). Rules:
  ///  * a bank sender header (AX-KOTAKB-S) decides the bank outright;
  ///  * otherwise a bank the message does not name at all is replaced by the
  ///    bank it does name (UPI handles such as "@okaxis" ignored);
  ///  * a last-4 that is not digits or does not appear in the message is
  ///    replaced by the account/card number the message actually carries.
  static TransactionParsed correctBankAndAccount(
    TransactionParsed parsed,
    String rawMessage, {
    String? sender,
  }) {
    var bank = parsed.bank;
    final parsedKey = bankKeyForLabel(parsed.bank);
    final senderKey = bankKeyForSender(sender);
    if (senderKey.isNotEmpty) {
      if (senderKey != parsedKey) {
        final label = bankDisplayName(senderKey);
        if (label.isNotEmpty) bank = label;
      }
    } else {
      final inText = bankKeysInText(rawMessage);
      if (inText.isNotEmpty &&
          (parsedKey.isEmpty || !inText.contains(parsedKey))) {
        final label = bankDisplayName(resolveBankKey(rawMessage));
        if (label.isNotEmpty) bank = label;
      }
    }

    var last4 = parsed.accountLast4.trim();
    final validDigits = RegExp(r'^\d{3,6}$').hasMatch(last4);
    final digitsOnly = rawMessage.replaceAll(RegExp(r'[^0-9]'), ' ');
    final appears = validDigits &&
        RegExp('(?<![0-9])[0-9]*${RegExp.escape(last4)}(?![0-9])')
            .hasMatch(digitsOnly);
    if (!appears) {
      final fromText = extractAccountLast4(rawMessage);
      if (fromText.isNotEmpty) {
        last4 = fromText;
      } else if (!validDigits) {
        last4 = 'Unknown';
      }
    }

    if (bank == parsed.bank && last4 == parsed.accountLast4) return parsed;
    return TransactionParsed(
      amount: parsed.amount,
      direction: parsed.direction,
      bank: bank,
      accountLast4: last4,
      name: parsed.name,
      rawIdentifier: parsed.rawIdentifier,
      mode: parsed.mode,
      accountFlow: parsed.accountFlow,
      upiId: parsed.upiId,
      referenceId: parsed.referenceId,
      dateTime: parsed.dateTime,
      rawMessage: parsed.rawMessage,
    );
  }

  static TransactionParsed _finalizeParsed(
    TransactionParsed parsed,
    String rawMessage, {
    required String source,
    String? matchedTemplate,
    String? matchedRule,
    bool skipTitleFallback = false,
  }) {
    final corrected =
        correctBankAndAccount(parsed, rawMessage, sender: _currentSender);
    final withDirection = _applyDirectionFromRaw(corrected, rawMessage);
    final enriched = skipTitleFallback
        ? withDirection
        : BankTitleExtractor.enrich(withDirection, rawMessage);

    final typeLabel = SmsDirectionHelper.typeLabel(
      rawMessage: rawMessage,
      parsed: enriched,
    );
    lastParseDebug = SmsParseDebugInfo(
      detectedTitle: enriched.name,
      detectedType: typeLabel,
      matchedTemplate: matchedTemplate,
      matchedRule: matchedRule,
      source: source,
    );
    return enriched;
  }

  static _RegexRuleMatch? _tryRegexRules(String message) {
    if (!Hive.isBoxOpen(SmsHiveBoxes.regexRules)) return null;
    final box = Hive.box(SmsHiveBoxes.regexRules);
    for (final rawRule in box.values) {
      final rule = SmsRule.fromMap(Map<dynamic, dynamic>.from(rawRule));
      if (!matchesRule(message, rule)) continue;
      final parsed = _applyRule(message, rule);
      if (parsed != null) return _RegexRuleMatch(rule: rule, parsed: parsed);
    }
    return null;
  }

  static TransactionParsed _applyDirectionFromRaw(TransactionParsed parsed, String rawMessage) {
    final direction = SmsDirectionHelper.resolveDirection(
      rawMessage: rawMessage,
      parsed: parsed,
    );
    if (direction == parsed.direction) return parsed;
    return TransactionParsed(
      amount: parsed.amount,
      direction: direction,
      bank: parsed.bank,
      accountLast4: parsed.accountLast4,
      name: parsed.name,
      rawIdentifier: parsed.rawIdentifier,
      mode: parsed.mode,
      accountFlow: parsed.accountFlow,
      upiId: parsed.upiId,
      referenceId: parsed.referenceId,
      dateTime: parsed.dateTime,
      rawMessage: parsed.rawMessage,
    );
  }

  /// Whether [message] satisfies a saved regex/keyword rule (same logic as live detection).
  static bool matchesRule(String message, SmsRule rule) {
    final lowerMessage = message.toLowerCase();

    if (rule.excludeKeywords != null) {
      for (final keyword in rule.excludeKeywords!) {
        if (lowerMessage.contains(keyword.toLowerCase())) return false;
      }
    }

    if (rule.matchPattern.isNotEmpty) {
      try {
        if (!RegExp(rule.matchPattern, caseSensitive: false).hasMatch(message)) {
          return false;
        }
      } catch (_) {
        return false;
      }
    }

    final keywords = rule.containsKeywords
        .map((k) => k.toLowerCase().trim())
        .where((k) => k.isNotEmpty)
        .toList();
    if (keywords.isNotEmpty) {
      final keywordHit = keywords.any((kw) => lowerMessage.contains(kw));
      if (!keywordHit) return false;
    }

    if (!_bankNameMatches(message, rule.bankName)) return false;

    return true;
  }

  static bool _bankNameMatches(String message, String bankName) {
    final bank = bankName.trim();
    if (bank.isEmpty || bank.toLowerCase() == 'unknown') return true;

    final lowerMessage = message.toLowerCase();
    final normalizedMsg = lowerMessage.replaceAll(RegExp(r'\s+'), '');
    final normalizedBank = bank.toLowerCase().replaceAll(RegExp(r'\s+'), '');
    if (normalizedBank.isNotEmpty && normalizedMsg.contains(normalizedBank)) {
      return true;
    }

    final tokens = bank
        .toLowerCase()
        .split(RegExp(r'[^a-z0-9]+'))
        .where((t) => t.length >= 3);
    return tokens.any((t) => lowerMessage.contains(t));
  }

  /// Test extraction for the training UI — requires match + apply (same as live).
  static TransactionParsed? testApply(String message, SmsRule rule) {
    if (!matchesRule(message, rule)) return null;
    return _applyRule(message, rule);
  }

  static TransactionParsed? _applyRule(String message, SmsRule rule) {
    try {
      final amount = _extractDouble(
          message,
          rule.amountPattern.isNotEmpty
              ? rule.amountPattern
              : r'(?:rs\.?|inr|₹)\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)(?![0-9A-Za-z_/])');
      if (amount == null) return null;

      final name = _extractString(message, rule.namePattern);
      final ref = _extractString(message, rule.refPattern);
      String? account = _extractString(message, rule.accountPattern);
      if (account != null && account.length > 4) {
        account = account.substring(account.length - 4);
      }
      final upi = _extractString(message, rule.upiPattern);
      final dateStr = _extractString(message, rule.datePattern);
      
      final direction = rule.type.toLowerCase() == 'credit' 
          ? TransactionDirection.income 
          : (rule.type.toLowerCase() == 'transfer' ? TransactionDirection.transfer : TransactionDirection.expense);

      final mode = _parseMode(rule.mode);

      final date = _parseDateTime(dateStr) ?? DateTime.now();

      return TransactionParsed(
        amount: amount,
        direction: direction,
        name: name ?? 'Unknown',
        bank: rule.bankName,
        accountLast4: account ?? '',
        dateTime: date,
        referenceId: ref ?? '',
        upiId: upi ?? '',
        mode: mode,
        rawMessage: message,
        rawIdentifier: name ?? rule.bankName,
        accountFlow: (mode == TransactionMode.atm || direction == TransactionDirection.transfer) 
            ? AccountFlow.cash 
            : AccountFlow.external,
      );
    } catch (e) {
      return null;
    }
  }

  static double? _extractDouble(String message, String pattern) {
    if (pattern.isEmpty) return null;
    try {
      final match = RegExp(pattern, caseSensitive: false).firstMatch(message);
      if (match != null && match.groupCount >= 1) {
        return double.tryParse(match.group(1)!.replaceAll(RegExp(r'[^0-9.]'), ''));
      }
    } catch (_) {}
    return null;
  }

  static String? _extractString(String message, String pattern) {
    if (pattern.isEmpty) return null;
    try {
      final match = RegExp(pattern, caseSensitive: false).firstMatch(message);
      if (match != null) {
        // If capture group exists, use it. Otherwise use the full match.
        if (match.groupCount >= 1) {
          return match.group(1)?.trim();
        }
        return match.group(0)?.trim();
      }
    } catch (_) {}
    return null;
  }

  static TransactionMode _parseMode(String mode) {
    switch (mode.toLowerCase()) {
      case 'upi': return TransactionMode.upi;
      case 'atm': return TransactionMode.atm;
      case 'card': return TransactionMode.card;
      default: return TransactionMode.unknown;
    }
  }

  static DateTime? _parseDateTime(String? dateStr) {
    if (dateStr == null || dateStr.isEmpty) return null;
    try {
      // Clean up common separators
      final clean = dateStr.replaceAll('/', '-').replaceAll('.', '-').trim();
      final parts = clean.split(RegExp(r'[\s-]'));
      
      if (parts.length >= 3) {
        int day = int.parse(parts[0]);
        int month = int.parse(parts[1]);
        int year = int.parse(parts[2]);
        if (year < 100) year += 2000;

        int hour = 0;
        int minute = 0;
        
        // Check for time if present (e.g. 20:23)
        final timePart = parts.firstWhere((p) => p.contains(':'), orElse: () => '');
        if (timePart.isNotEmpty) {
          final timeParts = timePart.split(':');
          hour = int.parse(timeParts[0]);
          minute = int.parse(timeParts[1]);
        }

        return DateTime(year, month, day, hour, minute);
      }
    } catch (_) {}
    return null;
  }
}

class _RegexRuleMatch {
  final SmsRule rule;
  final TransactionParsed parsed;
  const _RegexRuleMatch({required this.rule, required this.parsed});
}
