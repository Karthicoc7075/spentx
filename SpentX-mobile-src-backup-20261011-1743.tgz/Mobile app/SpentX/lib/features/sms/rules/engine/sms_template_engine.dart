import 'package:hive_flutter/hive_flutter.dart';
import '../../../sms_parser/models/transaction_parsed.dart';
import '../../../sms_parser/sms_classifier.dart';
import '../../../sms_parser/sms_direction_helper.dart';
import '../models/sms_template_rule.dart';
import '../sms_hive_boxes.dart';
import '../../v4/payee_extractor.dart';
import '../../../../data/local/hive_service.dart';

/// Template matching engine that compares a new SMS against saved templates
/// using structural similarity and extracts dynamic values.
///
/// EXTRACTION PRIORITY:
///   1) Exact tagged values from training (positional extraction)
///   2) Regex-based field extractors (fallback)
///   3) Default values from the rule itself
class SmsTemplateEngine {
  static const String _templateBox = SmsHiveBoxes.templateRules;

  static Future<void> init() async {
    if (!Hive.isBoxOpen(_templateBox)) {
      await SecureHive.openBox(_templateBox);
    }
  }

  static List<SmsTemplateRule> getAllRules() {
    if (!Hive.isBoxOpen(_templateBox)) return [];
    final box = Hive.box(_templateBox);
    return box.values
        .map((e) {
          try {
            return SmsTemplateRule.fromMap(Map<dynamic, dynamic>.from(e));
          } catch (_) {
            return null;
          }
        })
        .whereType<SmsTemplateRule>()
        .where((r) => r.id.isNotEmpty)
        .toList();
  }

  static void saveRule(SmsTemplateRule rule) {
    if (!Hive.isBoxOpen(_templateBox)) return;
    Hive.box(_templateBox).put(rule.id, rule.toMap());
  }

  static void deleteRule(String id) {
    if (!Hive.isBoxOpen(_templateBox)) return;
    Hive.box(_templateBox).delete(id);
  }

  /// Try to match and extract using all saved template rules (fresh Hive read).
  static SmsTemplateMatch? tryMatch(String message, {DateTime? smsReceivedTime}) {
    return tryMatchAgainstRules(getAllRules(), message, smsReceivedTime: smsReceivedTime);
  }

  /// Match against an in-memory rule list (e.g. bundled bank_sms_templates_v4.json).
  static SmsTemplateMatch? tryMatchAgainstRules(
    List<SmsTemplateRule> rules,
    String message, {
    DateTime? smsReceivedTime,
  }) {
    if (rules.isEmpty) return null;

    final normalizedMsg = _normalize(message);

    SmsTemplateMatch? best;
    double bestScore = 0;

    for (final rule in rules) {
      // v5 `requiredVerb`: this template only describes messages containing
      // this word. Checked before any scoring — a template can score well
      // structurally on a message that never says money moved, and this
      // refuses it outright rather than relying on the threshold to.
      if (rule.requiredVerb.isNotEmpty &&
          !normalizedMsg.contains(rule.requiredVerb.toLowerCase())) {
        continue;
      }

      final bankLower = rule.bankName.toLowerCase();
      final bankExactLower = rule.bankNameExact.toLowerCase();
      final bankNameMatched = _bankMatches(normalizedMsg, bankLower, bankExactLower);

      final score = _computeSimilarity(normalizedMsg, rule);
      final structureMatched = score >= rule.similarityThreshold;
      final keywordOnlyMatch = rule.keywords.isNotEmpty &&
          rule.keywords.every((kw) => normalizedMsg.contains(kw.toLowerCase())) &&
          score >= 0.25;
      // The loose "message mentions a bank" shortcut. It is the only path a
      // low-scoring template can win on, so it must also require that the
      // message actually says money moved — otherwise any text containing a
      // bank name and a number clears 0.35 and becomes a spend.
      final bankWithStructure = bankNameMatched &&
          score >= 0.35 &&
          SmsClassifier.statesMoneyMoved(message);

      if (!structureMatched && !bankWithStructure && !keywordOnlyMatch) continue;

      final extracted = _extractFromTemplate(message, rule, smsReceivedTime: smsReceivedTime);
      if (extracted == null) continue;

      final rank = score + (bankNameMatched ? 0.15 : 0);
      if (rank > bestScore) {
        bestScore = rank;
        final titleTagged = rule.extractionMap.values.any(
          (f) => f == TemplateFieldType.title || f == TemplateFieldType.merchantName,
        );
        best = SmsTemplateMatch(
          ruleId: rule.id,
          parsed: extracted,
          hasTaggedTitle: titleTagged,
        );
      }
    }
    return best;
  }

  static bool _bankMatches(String normalizedMsg, String bankLower, String bankExactLower) {
    if (bankExactLower.isNotEmpty && normalizedMsg.contains(bankExactLower)) {
      return true;
    }
    if (bankLower.isEmpty || bankLower == 'unknown') return false;
    if (normalizedMsg.contains(bankLower.replaceAll(' ', ''))) return true;
    final tokens = bankLower.split(RegExp(r'[^a-z0-9]+')).where((t) => t.length >= 3);
    return tokens.any((t) => normalizedMsg.contains(t));
  }

  /// Fallback to build an extractionMap from a raw sample message when the rule
  /// was saved without one (legacy or manual). Uses common patterns to tag
  /// dynamic fields so _extractFromTemplate can still work positionally.
  static Map<String, String> _inferExtractionFromSample(String sample) {
    final result = <String, String>{};
    if (sample.trim().isEmpty) return result;
    final lower = sample.toLowerCase();

    // Amount (capture the Rs/₹ token as it appeared)
    final amtRe = RegExp(
        r'(?:₹|rs\.?|inr)\s*[0-9][0-9,]*(?:\.[0-9]{1,2})?(?![0-9A-Za-z_/])',
        caseSensitive: false);
    final amtMatch = amtRe.firstMatch(sample);
    if (amtMatch != null) {
      result[amtMatch.group(0)!.trim()] = TemplateFieldType.amount;
    }

    // UPI id
    final upiRe = RegExp(r'[a-zA-Z0-9._-]+@[a-zA-Z]+', caseSensitive: false);
    final upiMatch = upiRe.firstMatch(sample);
    if (upiMatch != null) {
      result[upiMatch.group(0)!] = TemplateFieldType.upiId;
    }

    // Account last4 / masked
    final accRe = RegExp(r'(?:xx|XX|\*{2,}|a/c\s*\*?|account\s*\*?)\s*\d{2,4}', caseSensitive: false);
    final accMatch = accRe.firstMatch(sample);
    if (accMatch != null) {
      result[accMatch.group(0)!.trim()] = TemplateFieldType.accountLast4;
    }

    // Date
    final dateRe = RegExp(r'\d{1,2}[-/]\d{1,2}[-/]\d{2,4}');
    final dateMatch = dateRe.firstMatch(sample);
    if (dateMatch != null) {
      result[dateMatch.group(0)!] = TemplateFieldType.date;
    }

    // Reference / txn id (capture the id portion)
    final refRe = RegExp(r'(?:ref|txn|utr|id|reference)[:=\s]*([0-9a-zA-Z]{6,})', caseSensitive: false);
    final refMatch = refRe.firstMatch(sample);
    if (refMatch != null && refMatch.group(1) != null) {
      result[refMatch.group(1)!] = TemplateFieldType.referenceId;
    }

    // Bank names (pick first known)
    const knownBanks = ['hdfc', 'sbi', 'icici', 'axis', 'kotak', 'pnb', 'bob', 'canara', 'union', 'idfc', 'federal', 'indusind', 'yes bank'];
    for (final b in knownBanks) {
      if (lower.contains(b)) {
        final bankRe = RegExp(r'\b[A-Za-z]*' + RegExp.escape(b) + r'[A-Za-z]*\b', caseSensitive: false);
        final bm = bankRe.firstMatch(sample);
        if (bm != null) {
          result[bm.group(0)!] = TemplateFieldType.bankName;
        }
        break;
      }
    }

    return result;
  }

  /// Test a single template rule against a message. Returns the parsed result
  /// or null if no match.
  static TransactionParsed? testRule(String message, SmsTemplateRule rule) {
    return _extractFromTemplate(message, rule);
  }

  // ───────────────────────────────────────────────────────────
  // SIMILARITY MATCHING
  // ───────────────────────────────────────────────────────────

  static String _normalize(String text) {
    return text.toLowerCase().replaceAll(RegExp(r'\s+'), ' ').trim();
  }

  /// Compute structural similarity between a new message and a template rule.
  /// Checks keyword presence + structural part overlap.
  static double _computeSimilarity(String normalizedMsg, SmsTemplateRule rule) {
    if (rule.keywords.isEmpty && rule.structuralParts.isEmpty) return 0.0;

    // 1) Keyword match score (40% weight)
    int keywordHits = 0;
    for (final kw in rule.keywords) {
      if (normalizedMsg.contains(kw.toLowerCase())) {
        keywordHits++;
      }
    }
    final keywordScore = rule.keywords.isEmpty ? 0.0 : keywordHits / rule.keywords.length;

    // 2) Structural parts match score (60% weight)
    int structHits = 0;
    for (final part in rule.structuralParts) {
      final normalizedPart = part.toLowerCase().trim();
      if (normalizedPart.length < 2) continue;
      if (normalizedMsg.contains(normalizedPart)) {
        structHits++;
      }
    }
    final validParts = rule.structuralParts.where((p) => p.trim().length >= 2).length;
    final structScore = validParts == 0 ? 0.0 : structHits / validParts;

    return (keywordScore * 0.4) + (structScore * 0.6);
  }

  // ───────────────────────────────────────────────────────────
  // TEMPLATE EXTRACTION (Tagged Value Priority)
  // ───────────────────────────────────────────────────────────

  static TransactionParsed? _extractFromTemplate(
    String message,
    SmsTemplateRule rule, {
    DateTime? smsReceivedTime,
  }) {
    try {
      var extractionMap = rule.extractionMap;
      if (extractionMap.isEmpty && rule.sampleMessage.isNotEmpty) {
        extractionMap = _inferExtractionFromSample(rule.sampleMessage);
      }
      if (extractionMap.isEmpty) return null;

      final exactValues = rule.exactTaggedValues;

      double? amount;
      String name = 'Unknown';
      String bank = rule.bankName;
      String accountLast4 = '';
      String upiId = '';
      String referenceId = '';
      DateTime? parsedDate;
      DateTime? parsedTime;

      // ── STEP 1: Extract using tagged values first (positional) ──
      for (final entry in extractionMap.entries) {
        final originalText = entry.key;   // The text from training SMS
        final field = entry.value;        // The field meaning

        switch (field) {
          case TemplateFieldType.amount:
            // Try positional extraction first: find the value at the same
            // structural position where the tagged amount was in the sample.
            amount = _extractAmountByPosition(message, rule.sampleMessage, originalText);
            // Fallback to generic regex extraction
            amount ??= _extractAmount(message);
            break;

          case TemplateFieldType.bankName:
            // Use positional extraction to get the FULL bank name
            bank = _extractByPosition(message, rule.sampleMessage, originalText)
                ?? exactValues[TemplateFieldType.bankName]
                ?? rule.bankName;
            break;

          case TemplateFieldType.merchantName:
          case TemplateFieldType.title:
            final positional = _extractByPosition(message, rule.sampleMessage, originalText);
            final contextual = _extractByContext(message, rule.sampleMessage, originalText);
            final payeeFromSms = PayeeExtractor.extract(message);
            // Never fall back to exactValues / originalText — those are sample training values.
            name = payeeFromSms ??
                positional ??
                contextual ??
                'Unknown';
            break;

          case TemplateFieldType.accountLast4:
          case TemplateFieldType.accountNumber:
            final raw = _extractByPosition(message, rule.sampleMessage, originalText)
                ?? _extractAccountLast4(message)
                ?? originalText;
            accountLast4 = raw.length > 4 ? raw.substring(raw.length - 4) : raw;
            break;

          case TemplateFieldType.upiId:
            upiId = _extractUpi(message) ?? '';
            break;

          case TemplateFieldType.referenceId:
            referenceId = _extractByPosition(message, rule.sampleMessage, originalText)
                ?? _extractRefId(message)
                ?? '';
            break;

          case TemplateFieldType.date:
            parsedDate = _extractDate(message);
            break;

          case TemplateFieldType.time:
            parsedTime = _extractTime(message);
            break;

          case TemplateFieldType.debitType:
          case TemplateFieldType.creditType:
          case TemplateFieldType.transferType:
          case TemplateFieldType.balance:
          case TemplateFieldType.atmWithdraw:
          case TemplateFieldType.cardPayment:
          case TemplateFieldType.ignoreText:
            break;
        }
      }

      if (amount == null || amount <= 0) return null;

      // ── STEP 2: Date/Time fallback logic ──
      // Priority: parsed date+time > parsed date + SMS time > SMS received time > now
      final DateTime finalDateTime = _resolveDateTime(
        parsedDate: parsedDate,
        parsedTime: parsedTime,
        smsReceivedTime: smsReceivedTime,
      );

      // ── STEP 3: Derive transaction direction & mode ──
      final direction = SmsDirectionHelper.resolveDirection(
        rawMessage: message,
        fallbackType: rule.type,
      );

      final mode = _parseMode(rule.mode);

      final stableId = upiId.isNotEmpty ? upiId : name;

      return TransactionParsed(
        amount: amount,
        direction: direction,
        bank: bank,
        accountLast4: accountLast4,
        name: name,
        rawIdentifier: stableId,
        mode: mode,
        accountFlow: (mode == TransactionMode.atm || direction == TransactionDirection.transfer)
            ? AccountFlow.cash
            : AccountFlow.external,
        upiId: upiId,
        referenceId: referenceId,
        dateTime: finalDateTime,
        rawMessage: message,
      );
    } catch (_) {
      return null;
    }
  }

  // ───────────────────────────────────────────────────────────
  // POSITIONAL EXTRACTION
  // ───────────────────────────────────────────────────────────

  /// Extracts the value at the same structural position in [newMessage]
  /// where [originalTaggedText] appeared in [sampleMessage].
  ///
  /// Works by finding the static text immediately before and after the
  /// tagged region in the sample, then using those as anchors to locate
  /// the corresponding dynamic value in the new message.
  static String? _extractByPosition(String newMessage, String sampleMessage, String originalTaggedText) {
    try {
      final idx = sampleMessage.indexOf(originalTaggedText);
      if (idx < 0) return null;

      // Get the 15 chars before and after the tagged text as anchors
      final beforeEnd = idx;
      final afterStart = idx + originalTaggedText.length;

      // Find anchor text BEFORE the tagged value (last 15 chars or from start)
      String beforeAnchor = sampleMessage.substring(
        (beforeEnd - 15).clamp(0, sampleMessage.length),
        beforeEnd,
      ).trim();

      // Find anchor text AFTER the tagged value (next 15 chars or to end)
      String afterAnchor = sampleMessage.substring(
        afterStart,
        (afterStart + 15).clamp(0, sampleMessage.length),
      ).trim();

      // Clean anchors — remove dynamic-looking parts
      beforeAnchor = _cleanAnchor(beforeAnchor);
      afterAnchor = _cleanAnchor(afterAnchor);

      if (beforeAnchor.isEmpty && afterAnchor.isEmpty) return null;

      // Build a regex to match the value between the anchors
      String pattern;
      if (beforeAnchor.isNotEmpty && afterAnchor.isNotEmpty) {
        pattern = '${RegExp.escape(beforeAnchor)}\\s*(.+?)\\s*${RegExp.escape(afterAnchor)}';
      } else if (beforeAnchor.isNotEmpty) {
        pattern = '${RegExp.escape(beforeAnchor)}\\s*(.+?)(?:\\s*[.\\n]|\$)';
      } else {
        pattern = '(.+?)\\s*${RegExp.escape(afterAnchor)}';
      }

      final match = RegExp(pattern, caseSensitive: false, dotAll: true).firstMatch(newMessage);
      if (match != null && match.groupCount >= 1) {
        final val = match.group(1)?.trim();
        if (val != null && val.isNotEmpty && val.length < 100) return val;
      }
    } catch (_) {}
    return null;
  }

  /// Positional amount extraction: tries to find the numeric value at the
  /// same position where the tagged amount appeared in the sample.
  static double? _extractAmountByPosition(String newMessage, String sampleMessage, String originalAmountText) {
    final positional = _extractByPosition(newMessage, sampleMessage, originalAmountText);
    if (positional != null) {
      // Extract numeric value from the positionally-extracted string
      final numMatch = RegExp(r'[0-9,]+(?:\.[0-9]{1,2})?').firstMatch(positional);
      if (numMatch != null) {
        return double.tryParse(numMatch.group(0)!.replaceAll(',', ''));
      }
    }
    return null;
  }

  /// Remove dynamic-looking text from anchor strings (numbers, amounts, etc.)
  /// to keep only the stable structural text.
  static String _cleanAnchor(String anchor) {
    // Keep only alphabetic words and common symbols
    return anchor
        .replaceAll(RegExp(r'[0-9,]+(?:\.[0-9]+)?'), '')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  // ───────────────────────────────────────────────────────────
  // DATE / TIME RESOLUTION
  // ───────────────────────────────────────────────────────────

  /// Resolves the final DateTime using the following priority:
  /// 1) Parsed date + parsed time → combine
  /// 2) Parsed date only → use SMS received time's hour:minute
  /// 3) No date → use SMS received time entirely
  /// 4) Nothing → use DateTime.now()
  static DateTime _resolveDateTime({
    DateTime? parsedDate,
    DateTime? parsedTime,
    DateTime? smsReceivedTime,
  }) {
    final fallback = smsReceivedTime ?? DateTime.now();

    if (parsedDate != null && parsedTime != null) {
      // Both date and time were tagged/found → combine
      return DateTime(
        parsedDate.year, parsedDate.month, parsedDate.day,
        parsedTime.hour, parsedTime.minute, parsedTime.second,
      );
    }

    if (parsedDate != null) {
      // Date found but no time → use SMS received time's HH:mm
      return DateTime(
        parsedDate.year, parsedDate.month, parsedDate.day,
        fallback.hour, fallback.minute,
      );
    }

    // No date found → use SMS received/detected time entirely
    return fallback;
  }

  // ───────────────────────────────────────────────────────────
  // FIELD EXTRACTORS (Regex Fallback)
  // ───────────────────────────────────────────────────────────

  static double? _extractAmount(String message) {
    final pattern = RegExp(
        r'(?:rs\.?|inr|₹)\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)(?![0-9A-Za-z_/])',
        caseSensitive: false);
    final match = pattern.firstMatch(message);
    if (match != null) {
      return double.tryParse(match.group(1)!.replaceAll(',', ''));
    }
    return null;
  }

  static String? _extractAccountLast4(String message) {
    final patterns = [
      RegExp(r'Card\s*x?(\d{4})\b', caseSensitive: false),
      RegExp(r'(?:\*|xx|a/c\s*\*?|account\s*\*?|a/c\s*xx)\s*x?(\d{4,})', caseSensitive: false),
    ];
    for (final pattern in patterns) {
      final match = pattern.firstMatch(message);
      if (match == null) continue;
      final full = match.group(1)!;
      return full.length > 4 ? full.substring(full.length - 4) : full;
    }
    return null;
  }

  static String? _extractUpi(String message) {
    final pattern = RegExp(r'([a-zA-Z0-9._-]+@[a-zA-Z]+)', caseSensitive: false);
    final match = pattern.firstMatch(message);
    return match?.group(0);
  }

  static String? _extractRefId(String message) {
    final pattern = RegExp(r'(?:ref|txn|utr|id|ref no)\s*:?\s*([0-9a-zA-Z]{6,})', caseSensitive: false);
    final match = pattern.firstMatch(message);
    return match?.group(1);
  }

  static DateTime? _extractDate(String message) {
    // Support YYYY-MM-DD first (never guess), then DD-MM-YY, DD-MMM-YY. Guard against substrings.
    final ymd = RegExp(r'(?<![0-9])(\d{4})-(\d{2})-(\d{2})(?![0-9])').firstMatch(message);
    if (ymd != null) {
      try {
        return DateTime(int.parse(ymd.group(1)!), int.parse(ymd.group(2)!), int.parse(ymd.group(3)!));
      } catch (_) {}
    }
    final dmmmy = RegExp(r'(?<![0-9])(\d{1,2})[- ]+([A-Za-z]{3})[- ]+(\d{2,4})(?![0-9])', caseSensitive: false).firstMatch(message);
    if (dmmmy != null) {
      try {
        final d = int.parse(dmmmy.group(1)!);
        final m = _monthAbbrToNum(dmmmy.group(2)!);
        var y = int.parse(dmmmy.group(3)!);
        if (y < 100) y += 2000;
        if (m > 0) return DateTime(y, m, d);
      } catch (_) {}
    }
    // DD-MM-YY etc guarded
    final pattern = RegExp(r'(?<![0-9])(\d{1,2})[-/](\d{1,2})[-/](\d{2,4})(?![0-9])');
    final match = pattern.firstMatch(message);
    if (match != null) {
      try {
        int day = int.parse(match.group(1)!);
        int month = int.parse(match.group(2)!);
        int year = int.parse(match.group(3)!);
        if (year < 100) year += 2000;
        return DateTime(year, month, day);
      } catch (_) {}
    }
    return null;
  }

  static int _monthAbbrToNum(String abbr) {
    const m = {'jan':1,'feb':2,'mar':3,'apr':4,'may':5,'jun':6,'jul':7,'aug':8,'sep':9,'oct':10,'nov':11,'dec':12};
    return m[abbr.toLowerCase()] ?? 0;
  }

  /// Extract time (HH:MM or HH:MM:SS) from SMS text.
  static DateTime? _extractTime(String message) {
    // ISO datetime suffix e.g. 2026-02-28:19:28:51
    final iso = RegExp(r'\d{4}-\d{2}-\d{2}:(\d{2}):(\d{2}):(\d{2})').firstMatch(message);
    if (iso != null) {
      try {
        return DateTime(
          2000,
          1,
          1,
          int.parse(iso.group(1)!),
          int.parse(iso.group(2)!),
          int.parse(iso.group(3)!),
        );
      } catch (_) {}
    }

    final pattern = RegExp(r'(\d{1,2}):(\d{2})(?::(\d{2}))?(?:\s*(am|pm))?', caseSensitive: false);
    final match = pattern.firstMatch(message);
    if (match != null) {
      try {
        int hour = int.parse(match.group(1)!);
        int minute = int.parse(match.group(2)!);
        int second = match.group(3) != null ? int.parse(match.group(3)!) : 0;
        final amPm = match.group(4)?.toLowerCase();
        if (amPm == 'pm' && hour < 12) hour += 12;
        if (amPm == 'am' && hour == 12) hour = 0;
        return DateTime(2000, 1, 1, hour, minute, second);
      } catch (_) {}
    }
    return null;
  }

  /// Try to extract a merchant name by checking what occupies the same
  /// structural position in the new message as the token did in the sample.
  static String? _extractByContext(String message, String sampleMessage, String originalToken) {
    final patterns = [
      RegExp(r'(?:to|paid to|sent to)\s+([A-Za-z0-9. ]+?)(?=\s+on|\s+at|\s+bal|\s+ref|\s+via|$)', caseSensitive: false),
      RegExp(r'(?:at|spent at)\s+([A-Za-z0-9. ]+?)(?=\s+on|\s+at|\s+bal|\s+ref|$)', caseSensitive: false),
      RegExp(r'from\s+(?:vpa\s+)?([a-zA-Z0-9._-]+@[a-zA-Z]+)', caseSensitive: false),
      RegExp(r'from\s+([A-Za-z0-9. ]+?)(?=\s+on|\s+at|\s+bal|\s+ref|$)', caseSensitive: false),
    ];
    for (final p in patterns) {
      final match = p.firstMatch(message);
      if (match != null) {
        final val = match.group(1)?.trim();
        if (val != null && val.length > 1) return val;
      }
    }
    return null;
  }

  static TransactionMode _parseMode(String mode) {
    switch (mode.toLowerCase()) {
      case 'upi': return TransactionMode.upi;
      case 'atm': return TransactionMode.atm;
      case 'card': return TransactionMode.card;
      default: return TransactionMode.unknown;
    }
  }
}

/// Helper to build a template from user-tagged segments.
class TemplateBuilder {
  /// Given a raw message and a list of (startIndex, endIndex, fieldType) selections,
  /// build the template pattern, extraction map, structural parts, keywords,
  /// AND exactTaggedValues for future positional extraction.
  static SmsTemplateRule build({
    required String sampleMessage,
    required List<TaggedSegment> segments,
    required String bankName,
    required String type,
    required String mode,
    double threshold = 0.65,
    String? id,
  }) {
    final extractionMap = <String, String>{};
    final exactTaggedValues = <String, String>{};
    final keywords = <String>[];
    final structuralParts = <String>[];

    String template = sampleMessage;

    // Sort segments by start index descending to replace from end → start
    // so indices don't shift
    final sorted = List<TaggedSegment>.from(segments)
      ..sort((a, b) => b.start.compareTo(a.start));

    for (final seg in sorted) {
      final originalText = sampleMessage.substring(seg.start, seg.end);
      if (seg.fieldType == TemplateFieldType.ignoreText) {
        // Keep as structural keyword
        final cleanWords = originalText.trim().split(RegExp(r'\s+'));
        for (final w in cleanWords) {
          if (w.length > 2) keywords.add(w.toLowerCase());
        }
        structuralParts.add(originalText.trim());
        continue;
      }

      // Replace the text with a token
      final token = TemplateFieldType.tokenTag(seg.fieldType);
      template = template.substring(0, seg.start) + token + template.substring(seg.end);

      // Store both: originalText → fieldType AND fieldType → originalText
      extractionMap[originalText] = seg.fieldType;
      exactTaggedValues[seg.fieldType] = originalText;
    }

    // Derive additional keywords from the non-tagged static parts of the template
    final staticParts = template.split(RegExp(r'\{[A-Z_]+\}'));
    for (final part in staticParts) {
      final trimmed = part.trim();
      if (trimmed.length >= 2) {
        structuralParts.add(trimmed);
        // Extract individual words as keywords
        for (final word in trimmed.split(RegExp(r'\s+'))) {
          final w = word.replaceAll(RegExp(r'[^a-zA-Z0-9]'), '').toLowerCase();
          if (w.length > 2 && !keywords.contains(w)) {
            keywords.add(w);
          }
        }
      }
    }

    final exactBank = exactTaggedValues[TemplateFieldType.bankName] ?? '';

    return SmsTemplateRule(
      id: id ?? DateTime.now().millisecondsSinceEpoch.toString(),
      bankName: bankName,
      bankNameExact: exactBank,
      type: type.toLowerCase(),
      mode: mode.toLowerCase(),
      sampleMessage: sampleMessage,
      templatePattern: template,
      extractionMap: extractionMap,
      exactTaggedValues: exactTaggedValues,
      keywords: keywords,
      similarityThreshold: threshold,
      structuralParts: structuralParts,
    );
  }
}

/// Represents a user-tagged segment of the SMS text.
class TaggedSegment {
  final int start;
  final int end;
  final String fieldType;

  TaggedSegment({required this.start, required this.end, required this.fieldType});
}

/// Lightweight result wrapper for a successful template rule match.
class SmsTemplateMatch {
  final String ruleId;
  final TransactionParsed parsed;
  final bool hasTaggedTitle;
  const SmsTemplateMatch({
    required this.ruleId,
    required this.parsed,
    this.hasTaggedTitle = false,
  });
}
