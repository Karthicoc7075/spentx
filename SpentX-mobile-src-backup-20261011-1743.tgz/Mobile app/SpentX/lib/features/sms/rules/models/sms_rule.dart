import 'package:hive/hive.dart';

class SmsRule extends HiveObject {
  final String id;
  final String matchPattern;
  final List<String> containsKeywords;
  final List<String>? excludeKeywords;
  final String amountPattern;
  final String namePattern;
  final String datePattern;
  final String refPattern;
  final String type; // Debit, Credit, Transfer
  final String mode; // UPI, ATM, CARD
  final String bankName;
  final String sampleMessage;
  final String accountPattern;
  final String upiPattern;
  final bool isManual;

  SmsRule({
    required this.id,
    required this.matchPattern,
    required this.containsKeywords,
    this.excludeKeywords,
    required this.amountPattern,
    required this.namePattern,
    required this.datePattern,
    required this.refPattern,
    required this.type,
    required this.mode,
    required this.bankName,
    required this.sampleMessage,
    required this.accountPattern,
    required this.upiPattern,
    this.isManual = false,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'matchPattern': matchPattern,
      'containsKeywords': containsKeywords,
      'excludeKeywords': excludeKeywords,
      'amountPattern': amountPattern,
      'namePattern': namePattern,
      'datePattern': datePattern,
      'refPattern': refPattern,
      'type': type,
      'mode': mode,
      'bankName': bankName,
      'sampleMessage': sampleMessage,
      'accountPattern': accountPattern,
      'upiPattern': upiPattern,
      'isManual': isManual,
    };
  }

  factory SmsRule.fromMap(Map<dynamic, dynamic> map) {
    return SmsRule(
      id: map['id'] ?? '',
      matchPattern: map['matchPattern'] ?? '',
      containsKeywords: List<String>.from(map['containsKeywords'] ?? []),
      excludeKeywords: map['excludeKeywords'] != null ? List<String>.from(map['excludeKeywords']) : null,
      amountPattern: map['amountPattern'] ?? '',
      namePattern: map['namePattern'] ?? '',
      datePattern: map['datePattern'] ?? '',
      refPattern: map['refPattern'] ?? '',
      type: map['type'] ?? 'Debit',
      mode: map['mode'] ?? 'UPI',
      bankName: map['bankName'] ?? '',
      sampleMessage: map['sampleMessage'] ?? '',
      accountPattern: map['accountPattern'] ?? '',
      upiPattern: map['upiPattern'] ?? '',
      isManual: map['isManual'] ?? false,
    );
  }
}
