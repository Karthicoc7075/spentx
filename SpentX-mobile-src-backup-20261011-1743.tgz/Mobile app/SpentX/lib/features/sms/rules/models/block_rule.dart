import 'package:hive/hive.dart';

class BlockRule extends HiveObject {
  final String id;
  final String? name;
  final List<String> keywords;
  final String? pattern;
  final String sampleMessage;
  final double similarityThreshold;
  final DateTime createdAt;

  BlockRule({
    required this.id,
    this.name,
    required this.keywords,
    this.pattern,
    required this.sampleMessage,
    this.similarityThreshold = 0.6,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  String get displayName {
    if (name != null && name!.trim().isNotEmpty) return name!.trim();
    if (keywords.isNotEmpty) return keywords.take(2).join(', ');
    return 'Block Rule';
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      if (name != null) 'name': name,
      'keywords': keywords,
      'pattern': pattern,
      'sampleMessage': sampleMessage,
      'similarityThreshold': similarityThreshold,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory BlockRule.fromMap(Map<dynamic, dynamic> map) {
    return BlockRule(
      id: map['id'] ?? '',
      name: map['name']?.toString(),
      keywords: List<String>.from(map['keywords'] ?? []),
      pattern: map['pattern'],
      sampleMessage: map['sampleMessage'] ?? '',
      similarityThreshold: (map['similarityThreshold'] as num?)?.toDouble() ?? 0.6,
      createdAt: map['createdAt'] != null ? DateTime.parse(map['createdAt']) : DateTime.now(),
    );
  }

  double matchScore(String message) {
    if (keywords.isEmpty) return 0.0;
    final lower = message.toLowerCase();
    int hits = 0;
    for (final kw in keywords) {
      if (lower.contains(kw.toLowerCase())) hits++;
    }
    return hits / keywords.length;
  }

  /// Returns match reason if this rule blocks [message].
  String? matchReason(String message) {
    final normalized = message.toLowerCase().trim().replaceAll(RegExp(r'\s+'), ' ');
    if (pattern != null && pattern!.isNotEmpty) {
      try {
        if (RegExp(pattern!, caseSensitive: false).hasMatch(normalized)) {
          return 'Regex pattern matched';
        }
      } catch (_) {}
    }
    for (final kw in keywords) {
      if (normalized.contains(kw.toLowerCase().trim())) {
        return 'Contains "$kw"';
      }
    }
    final score = matchScore(normalized);
    if (keywords.isNotEmpty && score >= similarityThreshold) {
      return 'Keyword similarity ${(score * 100).toInt()}%';
    }
    return null;
  }
}