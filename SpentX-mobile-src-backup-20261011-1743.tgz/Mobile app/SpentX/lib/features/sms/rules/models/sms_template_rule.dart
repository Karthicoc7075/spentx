/// A template-based SMS rule that uses structural similarity matching
/// instead of requiring users to write regex patterns.
///
/// The user trains ONE SMS → the system creates a structural template.
/// Future SMS with the same structure but different values auto-extract.
class SmsTemplateRule {
  final String id;
  final String bankName;
  final String bankNameExact;
  final String type; // debit, credit, transfer
  final String mode; // upi, atm, card, unknown

  /// The original SMS the user trained on.
  final String sampleMessage;

  /// A structural template where dynamic values are replaced with tokens.
  /// e.g. "Rs.{AMOUNT} credited to {BANK} A/c {ACCOUNT} on {DATE} from VPA {UPI} (UPI {REF})"
  final String templatePattern;

  /// Mapping of originalText → fieldType.
  /// e.g. { "Rs.150.00": "amount", "HDFC Bank": "bankName", ... }
  final Map<String, String> extractionMap;

  /// Mapping of fieldType → exact tagged text from training SMS.
  /// e.g. { "bankName": "IDFC FIRST Bank", "amount": "INR 10,000.00", ... }
  /// During future parsing, these are used as structural anchors to locate
  /// the corresponding dynamic value in a new SMS with the same format.
  final Map<String, String> exactTaggedValues;

  /// Static keywords that must be present for a match.
  /// e.g. ["credited", "A/c", "VPA", "UPI"]
  final List<String> keywords;

  /// Minimum similarity score (0.0–1.0) for template matching.
  final double similarityThreshold;

  /// Structural tokens extracted from the template for fuzzy matching.
  /// These are the non-dynamic parts of the SMS split by token boundaries.
  final List<String> structuralParts;

  /// A verb the message MUST contain for this template to match, e.g.
  /// `debited`. A precision guard: a template can score well structurally on a
  /// message that never says money moved, and this refuses it outright.
  /// Empty (the default) means "no extra requirement" — older templates and
  /// user-trained rules keep their existing behaviour.
  final String requiredVerb;

  /// Direction declared by the catalog (`debit` / `credit` / `transfer`).
  /// Advisory only: raw-message keywords still win (see [SmsDirectionHelper]),
  /// so a mis-declared template cannot book a credit as a spend.
  final String direction;

  /// False for a template known to be wrong — currently only
  /// `hdfc_credit_card_emi`, a due-reminder mislabeled as a Debit. Disabled
  /// templates are dropped at load, so they can never match.
  final bool enabled;

  SmsTemplateRule({
    required this.id,
    required this.bankName,
    this.bankNameExact = '',
    required this.type,
    this.mode = 'unknown',
    required this.sampleMessage,
    required this.templatePattern,
    required this.extractionMap,
    this.exactTaggedValues = const {},
    required this.keywords,
    this.similarityThreshold = 0.65,
    required this.structuralParts,
    this.requiredVerb = '',
    this.direction = '',
    this.enabled = true,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'bankName': bankName,
    'bankNameExact': bankNameExact,
    'type': type,
    'mode': mode,
    'sampleMessage': sampleMessage,
    'templatePattern': templatePattern,
    'extractionMap': extractionMap,
    'exactTaggedValues': exactTaggedValues,
    'keywords': keywords,
    'similarityThreshold': similarityThreshold,
    'structuralParts': structuralParts,
    'requiredVerb': requiredVerb,
    'direction': direction,
    'enabled': enabled,
  };

  factory SmsTemplateRule.fromMap(Map<dynamic, dynamic> map) => SmsTemplateRule(
    id: map['id']?.toString() ?? '',
    bankName: map['bankName']?.toString() ?? '',
    bankNameExact: map['bankNameExact']?.toString() ?? '',
    type: map['type']?.toString() ?? 'debit',
    mode: map['mode']?.toString() ?? 'unknown',
    sampleMessage: map['sampleMessage']?.toString() ?? '',
    templatePattern: map['templatePattern']?.toString() ?? '',
    extractionMap: _stringMapFrom(map['extractionMap']),
    exactTaggedValues: _stringMapFrom(map['exactTaggedValues']),
    keywords: _stringListFrom(map['keywords']),
    similarityThreshold: (map['similarityThreshold'] as num?)?.toDouble() ?? 0.65,
    structuralParts: _stringListFrom(map['structuralParts']),
    // Absent in every rule written before v5 — defaults keep them working.
    requiredVerb: map['requiredVerb']?.toString() ?? '',
    direction: map['direction']?.toString() ?? '',
    enabled: map['enabled'] != false,
  );

  static Map<String, String> _stringMapFrom(dynamic raw) {
    if (raw is! Map) return {};
    return {
      for (final e in raw.entries)
        e.key.toString(): e.value?.toString() ?? '',
    };
  }

  static List<String> _stringListFrom(dynamic raw) {
    if (raw is! List) return [];
    return raw.map((e) => e.toString()).toList();
  }
}

/// All possible field types a user can tag in template selection.
class TemplateFieldType {
  static const amount = 'amount';
  static const debitType = 'debitType';
  static const creditType = 'creditType';
  static const transferType = 'transferType';
  static const bankName = 'bankName';
  static const accountNumber = 'accountNumber';
  static const accountLast4 = 'accountLast4';
  static const balance = 'balance';
  static const upiId = 'upiId';
  static const referenceId = 'referenceId';
  static const merchantName = 'merchantName';
  /// User-facing "Title" tag — same priority as [merchantName]; always wins over fallback extraction.
  static const title = 'title';
  static const date = 'date';
  static const time = 'time';
  static const atmWithdraw = 'atmWithdraw';
  static const cardPayment = 'cardPayment';
  static const ignoreText = 'ignoreText';

  static const all = [
    amount,
    debitType,
    creditType,
    transferType,
    bankName,
    accountNumber,
    accountLast4,
    balance,
    upiId,
    referenceId,
    merchantName,
    title,
    date,
    time,
    atmWithdraw,
    cardPayment,
    ignoreText,
  ];

  static String label(String field) {
    switch (field) {
      case amount: return 'Amount';
      case debitType: return 'Debit Type';
      case creditType: return 'Credit Type';
      case transferType: return 'Transfer Type';
      case bankName: return 'Bank Name';
      case accountNumber: return 'Account Number';
      case accountLast4: return 'Account Last4';
      case balance: return 'Balance';
      case upiId: return 'UPI ID';
      case referenceId: return 'Reference ID';
      case merchantName: return 'Merchant Name';
      case title: return 'Title';
      case date: return 'Date';
      case time: return 'Time';
      case atmWithdraw: return 'ATM Withdraw';
      case cardPayment: return 'Card Payment';
      case ignoreText: return 'Ignore Text';
      default: return field;
    }
  }

  static String tokenTag(String field) => '{${field.toUpperCase()}}';
}
