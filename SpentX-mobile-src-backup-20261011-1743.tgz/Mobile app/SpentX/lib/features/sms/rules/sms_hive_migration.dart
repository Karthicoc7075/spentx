import 'package:hive_flutter/hive_flutter.dart';
import 'sms_hive_boxes.dart';
import '../../../data/local/hive_service.dart';

/// Moves data from legacy Hive box names into the current schema.
Future<void> migrateSmsHiveBoxes() async {
  await _migrateLegacyBlockBox();
  await _migrateLegacyBox(SmsHiveBoxes.legacyRegexRules, SmsHiveBoxes.regexRules);
  await _migrateLegacyBox(SmsHiveBoxes.legacyTemplateRules, SmsHiveBoxes.templateRules);
}

Future<void> _migrateLegacyBox(String legacyName, String targetName) async {
  if (!Hive.isBoxOpen(legacyName)) {
    try {
      await SecureHive.openBox(legacyName);
    } catch (_) {
      return;
    }
  }
  final legacy = Hive.box(legacyName);
  if (legacy.isEmpty) return;

  if (!Hive.isBoxOpen(targetName)) {
    await SecureHive.openBox(targetName);
  }
  final target = Hive.box(targetName);

  for (final key in legacy.keys) {
    final value = legacy.get(key);
    if (value == null) continue;
    if (!target.containsKey(key)) {
      await target.put(key, value);
    }
  }
  await legacy.clear();
}

Future<void> _migrateLegacyBlockBox() async {
  if (!Hive.isBoxOpen(SmsHiveBoxes.legacyBlockRules)) {
    try {
      await SecureHive.openBox(SmsHiveBoxes.legacyBlockRules);
    } catch (_) {
      return;
    }
  }

  final legacy = Hive.box(SmsHiveBoxes.legacyBlockRules);
  if (legacy.isEmpty) return;

  if (!Hive.isBoxOpen(SmsHiveBoxes.blockRules)) {
    await SecureHive.openBox(SmsHiveBoxes.blockRules);
  }
  final target = Hive.box(SmsHiveBoxes.blockRules);

  for (final key in legacy.keys) {
    final value = legacy.get(key);
    if (value == null) continue;
    if (!target.containsKey(key)) {
      await target.put(key, value);
    }
  }

  await legacy.clear();
}