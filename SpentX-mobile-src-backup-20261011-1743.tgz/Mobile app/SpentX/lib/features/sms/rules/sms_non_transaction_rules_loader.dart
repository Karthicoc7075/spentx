import 'package:flutter/services.dart';

import '../../sms_parser/sms_non_transaction_rules.dart';

/// Reads the bundled non-transaction rule seed and hands it to
/// [SmsNonTransactionRules].
///
/// Exists purely to keep `rootBundle` out of the filter chain: that chain is
/// imported by plain-Dart `tool/` scripts, and a Flutter import anywhere in it
/// makes every one of them fail to compile.
class SmsNonTransactionRulesLoader {
  SmsNonTransactionRulesLoader._();

  static const assetPath = 'assets/sms/sms_block_rules_seed.json';

  static Future<void> ensureLoaded() async {
    if (SmsNonTransactionRules.isLoaded) return;
    try {
      SmsNonTransactionRules.loadFromJson(
        await rootBundle.loadString(assetPath),
      );
    } catch (_) {
      SmsNonTransactionRules.markUnavailable();
    }
  }
}
