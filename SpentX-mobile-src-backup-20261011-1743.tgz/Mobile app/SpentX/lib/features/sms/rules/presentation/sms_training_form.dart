import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../../../core/theme/soft_palette.dart';
import '../models/sms_rule.dart';
import '../engine/sms_rule_engine.dart';
import '../providers/sms_rule_provider.dart';
import '../../../sms_parser/models/transaction_parsed.dart';
import '../../../sms_parser/sms_parser.dart';
import '../../../sms_parser/sms_direction_helper.dart';

class SmsTrainingForm extends ConsumerStatefulWidget {
  final SmsRule? rule;
  final String? sampleSms;
  final bool isManual;
  const SmsTrainingForm({
    super.key,
    this.rule,
    this.sampleSms,
    this.isManual = false,
  });

  @override
  ConsumerState<SmsTrainingForm> createState() => _SmsTrainingFormState();
}

class _SmsTrainingFormState extends ConsumerState<SmsTrainingForm> {
  final _formKey = GlobalKey<FormState>();

  late TextEditingController _keywordsCtrl;
  late TextEditingController _amountPatternCtrl;
  late TextEditingController _namePatternCtrl;
  late TextEditingController _bankNameCtrl;
  late TextEditingController _accountCtrl;
  late TextEditingController _refCtrl;
  late TextEditingController _datePatternCtrl;
  late TextEditingController _upiPatternCtrl;
  late String _sampleMessage;

  String _selectedType = 'Debit';
  String _selectedMode = 'UPI';
  bool _showAdvanced = false;

  @override
  void initState() {
    super.initState();
    _sampleMessage = widget.sampleSms ?? widget.rule?.sampleMessage ?? '';

    // Auto-detect using existing parser if it's a new manual rule
    TransactionParsed? detected;
    if (widget.rule == null && _sampleMessage.isNotEmpty) {
      detected =
          SmsRuleEngine.parse(_sampleMessage) ??
          UniversalSmsParser.parseSms(_sampleMessage);
    }

    _keywordsCtrl = TextEditingController(
      text:
          widget.rule?.containsKeywords.join(', ') ??
          _extractDefaultKeywords(_sampleMessage),
    );

    _amountPatternCtrl = TextEditingController(
      text:
          widget.rule?.amountPattern ??
          r'(?:rs\.?|inr|₹)\s*([0-9,]+(?:\.[0-9]{1,2})?)',
    );

    _namePatternCtrl = TextEditingController(
      text:
          widget.rule?.namePattern ??
          (detected != null
              ? r'to\s+([A-Za-z0-9 ]+?)(?=\s+via|\s+on|\s+bal|$)'
              : r'to\s+([A-Za-z0-9 ]+?)(?=\s+via|\s+on|\s+bal|$)'),
    );

    _bankNameCtrl = TextEditingController(
      text: widget.rule?.bankName ?? detected?.bank ?? '',
    );

    _selectedType =
        widget.rule?.type ?? _directionToString(detected?.direction) ?? 'Debit';
    _selectedMode = widget.rule?.mode ?? _modeToString(detected?.mode) ?? 'UPI';

    _accountCtrl = TextEditingController(
      text:
          widget.rule?.accountPattern ??
          r'(?:\*|xx|a/c\s*\*?|account\s*\*?|a/c\s*xx)(\d{4,})',
    );

    _refCtrl = TextEditingController(
      text: widget.rule?.refPattern ?? r'(?:ref|txn|utr)\s*:?\s*([0-9a-z]{6,})',
    );

    _datePatternCtrl = TextEditingController(
      text:
          widget.rule?.datePattern ??
          r'(\d{2}[-/]\d{2}[-/]\d{2,4}(?:\s\d{2}:\d{2})?)',
    );

    _upiPatternCtrl = TextEditingController(
      text: widget.rule?.upiPattern ?? r'([a-zA-Z0-9.\-_]+@[a-zA-Z]+)',
    );

    // Auto-fill all fields if it's a new rule from a sample
    if (widget.rule == null && _sampleMessage.isNotEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _autoFillFromSample(_sampleMessage);
      });
    }

    // Add listeners for live preview
    _keywordsCtrl.addListener(_updatePreview);
    _amountPatternCtrl.addListener(_updatePreview);
    _namePatternCtrl.addListener(_updatePreview);
    _bankNameCtrl.addListener(_updatePreview);
    _accountCtrl.addListener(_updatePreview);
    _refCtrl.addListener(_updatePreview);
    _datePatternCtrl.addListener(_updatePreview);
    _upiPatternCtrl.addListener(_updatePreview);
  }

  void _updatePreview() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _keywordsCtrl.dispose();
    _amountPatternCtrl.dispose();
    _namePatternCtrl.dispose();
    _bankNameCtrl.dispose();
    _accountCtrl.dispose();
    _refCtrl.dispose();
    _datePatternCtrl.dispose();
    _upiPatternCtrl.dispose();
    super.dispose();
  }

  String? _directionToString(TransactionDirection? dir) {
    if (dir == null) return null;
    switch (dir) {
      case TransactionDirection.income:
        return 'Credit';
      case TransactionDirection.transfer:
        return 'Transfer';
      case TransactionDirection.expense:
        return 'Debit';
    }
  }

  String? _modeToString(TransactionMode? mode) {
    if (mode == null) return null;
    switch (mode) {
      case TransactionMode.upi:
        return 'UPI';
      case TransactionMode.atm:
        return 'ATM';
      case TransactionMode.card:
        return 'CARD';
      default:
        return 'UPI';
    }
  }

  String _extractDefaultKeywords(String message) {
    if (message.isEmpty) return '';
    final words =
        message
            .toLowerCase()
            .split(RegExp(r'[^a-z0-9]'))
            .where((w) => w.length > 3)
            .toList();
    // Common bank SMS triggers
    final triggers = [
      'debited',
      'credited',
      'spent',
      'paid',
      'transfer',
      'sent',
      'received',
      'purchase',
    ];
    final matched = words.where((w) => triggers.contains(w)).take(2).toList();
    return matched.join(', ');
  }

  void _testRule() {
    final tempRule = SmsRule(
      id: 'test',
      matchPattern: '',
      containsKeywords:
          _keywordsCtrl.text
              .split(',')
              .map((e) => e.trim())
              .where((e) => e.isNotEmpty)
              .toList(),
      amountPattern: _amountPatternCtrl.text,
      namePattern: _namePatternCtrl.text,
      refPattern: _refCtrl.text,
      datePattern: _datePatternCtrl.text,
      upiPattern: _upiPatternCtrl.text,
      type: _selectedType,
      mode: _selectedMode,
      bankName: _bankNameCtrl.text,
      sampleMessage: _sampleMessage,
      accountPattern: _accountCtrl.text,
    );

    final result = SmsRuleEngine.testApply(_sampleMessage, tempRule);

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder:
          (_) => Container(
            decoration: BoxDecoration(
              color: context.softCard,
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(28),
              ),
              boxShadow: const [
                BoxShadow(
                  color: Color(0x140F172A),
                  blurRadius: 24,
                  offset: Offset(0, -4),
                ),
              ],
            ),
            padding: const EdgeInsets.fromLTRB(24, 20, 24, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      LucideIcons.flaskConical,
                      color: context.softEmerald,
                      size: 24,
                    ),
                    const SizedBox(width: 12),
                    Text(
                      'Test Results',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                        color: context.softInk,
                      ),
                    ),
                    const Spacer(),
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: Icon(LucideIcons.x, color: context.softFaint),
                    ),
                  ],
                ),
                Divider(height: 32, color: context.softBorder),
                if (result == null)
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: SoftPalette.negative.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      'Pattern failed to parse. Check your Regex.',
                      style: TextStyle(
                        color: SoftPalette.negative,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  )
                else ...[
                  _buildResultRow(
                    'Amount',
                    '₹${result.amount}',
                    LucideIcons.banknote,
                  ),
                  _buildResultRow('Name', result.name, LucideIcons.user),
                  _buildResultRow('Bank', result.bank, LucideIcons.building),
                  _buildResultRow(
                    'Account',
                    '...${result.accountLast4}',
                    LucideIcons.creditCard,
                  ),
                  _buildResultRow(
                    'Mode',
                    result.mode.name.toUpperCase(),
                    LucideIcons.zap,
                  ),
                  _buildResultRow(
                    'Ref ID',
                    result.referenceId,
                    LucideIcons.hash,
                  ),
                  _buildResultRow('UPI ID', result.upiId, LucideIcons.atSign),
                  // We'll show the raw date string from the message if we could extract it
                  _buildResultRow(
                    'Date',
                    result.dateTime.toString().split(' ').first,
                    LucideIcons.calendar,
                  ),
                ],
                const SizedBox(height: 24),
              ],
            ),
          ),
    );
  }

  Widget _buildResultRow(String label, String value, IconData icon) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Icon(icon, size: 16, color: context.softFaint),
          const SizedBox(width: 12),
          Text(label, style: TextStyle(color: context.softFaint, fontSize: 13)),
          const Spacer(),
          Text(
            value.isEmpty ? 'Not Found' : value,
            style: TextStyle(
              color: value.isEmpty ? context.softFaint : context.softInk,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  void _saveRule() {
    if (_formKey.currentState!.validate()) {
      final rule = SmsRule(
        id: widget.rule?.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
        matchPattern: '',
        containsKeywords:
            _keywordsCtrl.text
                .split(',')
                .map((e) => e.trim())
                .where((e) => e.isNotEmpty)
                .toList(),
        amountPattern: _amountPatternCtrl.text,
        namePattern: _namePatternCtrl.text,
        refPattern: _refCtrl.text,
        datePattern: _datePatternCtrl.text,
        upiPattern: _upiPatternCtrl.text,
        type: _selectedType,
        mode: _selectedMode,
        bankName: _bankNameCtrl.text,
        sampleMessage: _sampleMessage,
        accountPattern: _accountCtrl.text,
        isManual: widget.isManual,
      );

      ref.read(smsRuleProvider.notifier).addRule(rule);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              Icon(LucideIcons.checkCircle, color: context.softInk, size: 20),
              const SizedBox(width: 12),
              Text('${rule.bankName} rule saved successfully'),
            ],
          ),
          backgroundColor: SoftPalette.emerald,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
      );

      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.softBg,
      appBar: AppBar(
        backgroundColor: context.softBg,
        elevation: 0,
        scrolledUnderElevation: 0,
        surfaceTintColor: Colors.transparent,
        iconTheme: IconThemeData(color: context.softInk),
        title: Text(
          widget.rule == null ? 'Train SMS Rule' : 'Edit Rule',
          style: TextStyle(
            fontWeight: FontWeight.w600,
            color: context.softInk,
          ),
        ),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            // ── SAMPLE MESSAGE CARD ──
            _buildSectionHeader('SAMPLE MESSAGE'),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: context.softCard,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: context.softSurfaceVariant),
              ),
              child: SelectableText(
                _sampleMessage,
                style: TextStyle(
                  color: context.softInk.withValues(alpha: 0.7),
                  fontSize: 13,
                  height: 1.5,
                  fontFamily: 'Monospace',
                ),
              ),
            ),
            const SizedBox(height: 24),

            // ── LIVE PREVIEW SECTION ──
            _buildSectionHeader('LIVE DETECTION PREVIEW'),
            _buildLivePreview(),
            const SizedBox(height: 24),

            // ── IDENTITY SECTION ──
            _buildSectionHeader('BANK IDENTITY'),
            _buildCard([
              _buildTextField(
                _bankNameCtrl,
                'Detected Bank',
                LucideIcons.building,
                hint: 'e.g. HDFC BANK',
              ),
              Divider(color: context.softDivider, height: 24),
              _buildTextField(
                _keywordsCtrl,
                'Detection Keywords',
                LucideIcons.key,
                hint: 'e.g. spent, paid, a/c',
              ),
              Divider(color: context.softDivider, height: 24),
              _buildTextField(
                _namePatternCtrl,
                'Merchant / Receiver',
                LucideIcons.user,
                hint: 'Regex or Name',
              ),
              Divider(color: context.softDivider, height: 24),
              _buildTextField(
                _refCtrl,
                'Reference ID / UTR',
                LucideIcons.hash,
                hint: 'Regex or ID',
              ),
            ]),
            const SizedBox(height: 24),

            _buildSectionHeader('TRANSACTION TYPE'),
            _buildCard([
              _buildTypeSelector(),
              Divider(color: context.softDivider, height: 24),
              _buildModeSelector(),
            ]),
            const SizedBox(height: 24),

            // ── ADVANCED TOGGLE ──
            GestureDetector(
              onTap: () => setState(() => _showAdvanced = !_showAdvanced),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Row(
                  children: [
                    Text(
                      'ADVANCED EXTRACTION PATTERNS',
                      style: TextStyle(
                        color: context.softInk.withValues(alpha: 0.3),
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                        letterSpacing: 1,
                      ),
                    ),
                    const Spacer(),
                    Icon(
                      _showAdvanced
                          ? LucideIcons.chevronUp
                          : LucideIcons.chevronDown,
                      size: 14,
                      color: context.softFaint,
                    ),
                  ],
                ),
              ),
            ),

            if (_showAdvanced) ...[
              const SizedBox(height: 12),
              _buildCard([
                _buildTextField(
                  _amountPatternCtrl,
                  'Amount Regex',
                  LucideIcons.banknote,
                ),
                _buildTextField(
                  _accountCtrl,
                  'Account Regex',
                  LucideIcons.creditCard,
                ),
                _buildTextField(
                  _upiPatternCtrl,
                  'UPI Regex',
                  LucideIcons.atSign,
                ),
                _buildTextField(
                  _datePatternCtrl,
                  'Date Regex',
                  LucideIcons.calendar,
                ),
              ]),
            ],

            const SizedBox(height: 40),

            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _testRule,
                    icon: const Icon(LucideIcons.flaskConical, size: 18),
                    label: const Text('Test Rule'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: context.softEmerald,
                      side: BorderSide(color: context.softEmerald),
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _saveRule,
                    icon: const Icon(LucideIcons.save, size: 18),
                    label: const Text('Save Rule'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: SoftColors.control,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      elevation: 0,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 60),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 12),
      child: Text(
        title,
        style: TextStyle(
          color: context.softInk.withValues(alpha: 0.3),
          fontSize: 11,
          fontWeight: FontWeight.w500,
          letterSpacing: 1,
        ),
      ),
    );
  }

  Widget _buildCard(List<Widget> children) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: context.softCard,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: context.softSurfaceVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: children,
      ),
    );
  }

  Widget _buildTextField(
    TextEditingController controller,
    String label,
    IconData icon, {
    String? hint,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 14, color: context.softEmerald),
              const SizedBox(width: 8),
              Text(
                label,
                style: TextStyle(
                  color: context.softMuted,
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          TextFormField(
            controller: controller,
            style: TextStyle(color: context.softInk, fontSize: 14),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: TextStyle(color: context.softBorder),
              filled: true,
              fillColor: context.softSurfaceVariant,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 12,
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: context.softInk.withValues(alpha: 0.05),
                ),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: context.softEmerald),
              ),
            ),
            validator: (v) => v!.isEmpty ? 'Required' : null,
          ),
        ],
      ),
    );
  }

  Widget _buildTypeSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Transaction Type',
          style: TextStyle(
            color: context.softMuted,
            fontSize: 13,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children:
              ['Debit', 'Credit', 'Transfer'].map((type) {
                final isSelected = _selectedType == type;
                return Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _selectedType = type),
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      decoration: BoxDecoration(
                        color:
                            isSelected
                                ? context.softEmerald
                                : context.softSurfaceVariant,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color:
                              isSelected
                                  ? context.softEmerald
                                  : context.softSurfaceVariant,
                        ),
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        type,
                        style: TextStyle(
                          color:
                              isSelected
                                  ? SoftPalette.onEmerald
                                  : context.softFaint,
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
        ),
      ],
    );
  }

  Widget _buildModeSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Payment Mode',
          style: TextStyle(
            color: context.softMuted,
            fontSize: 13,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children:
              ['UPI', 'ATM', 'CARD'].map((mode) {
                final isSelected = _selectedMode == mode;
                return Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _selectedMode = mode),
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      decoration: BoxDecoration(
                        color:
                            isSelected
                                ? context.softEmerald
                                : context.softSurfaceVariant,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color:
                              isSelected
                                  ? context.softEmerald
                                  : context.softSurfaceVariant,
                        ),
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        mode,
                        style: TextStyle(
                          color:
                              isSelected
                                  ? SoftPalette.onEmerald
                                  : context.softFaint,
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
        ),
      ],
    );
  }

  Widget _buildLivePreview() {
    final tempRule = SmsRule(
      id: 'preview',
      matchPattern: '',
      containsKeywords:
          _keywordsCtrl.text
              .split(',')
              .map((e) => e.trim())
              .where((e) => e.isNotEmpty)
              .toList(),
      amountPattern: _amountPatternCtrl.text,
      namePattern: _namePatternCtrl.text,
      refPattern: _refCtrl.text,
      datePattern: _datePatternCtrl.text,
      upiPattern: _upiPatternCtrl.text,
      type: _selectedType,
      mode: _selectedMode,
      bankName: _bankNameCtrl.text,
      sampleMessage: _sampleMessage,
      accountPattern: _accountCtrl.text,
    );

    final result = SmsRuleEngine.testApply(_sampleMessage, tempRule);

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: context.softEmeraldSoft,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: context.softEmerald.withValues(alpha: 0.16)),
      ),
      child: Column(
        children: [
          if (result == null)
            Row(
              children: [
                Icon(
                  LucideIcons.alertCircle,
                  color: SoftPalette.negative,
                  size: 18,
                ),
                const SizedBox(width: 12),
                Text(
                  'No match with current patterns',
                  style: TextStyle(
                    color: context.softMuted,
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            )
          else ...[
            _buildPreviewRow(
              'Amount',
              '₹${result.amount}',
              LucideIcons.banknote,
              color: context.softEmerald,
            ),
            const SizedBox(height: 12),
            _buildPreviewRow('Merchant', result.name, LucideIcons.user),
            const SizedBox(height: 12),
            _buildPreviewRow(
              'Account',
              '...${result.accountLast4}',
              LucideIcons.creditCard,
            ),
            const SizedBox(height: 12),
            _buildPreviewRow('UPI ID', result.upiId, LucideIcons.atSign),
            const SizedBox(height: 12),
            _buildPreviewRow('Ref ID', result.referenceId, LucideIcons.hash),
          ],
        ],
      ),
    );
  }

  Widget _buildPreviewRow(
    String label,
    String value,
    IconData icon, {
    Color? color,
  }) {
    return Row(
      children: [
        Icon(icon, size: 14, color: color ?? context.softFaint),
        const SizedBox(width: 12),
        Text(label, style: TextStyle(color: context.softFaint, fontSize: 12)),
        const Spacer(),
        Text(
          value.isEmpty ? 'Not Found' : value,
          style: TextStyle(
            color:
                value.isEmpty ? context.softBorder : (color ?? context.softInk),
            fontSize: 13,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  void _autoFillFromSample(String msg) {
    final detected =
        SmsRuleEngine.parse(msg) ?? UniversalSmsParser.parseSms(msg);
    if (detected == null) return;

    final direction = SmsDirectionHelper.resolveDirection(
      rawMessage: msg,
      parsed: detected,
    );

    setState(() {
      _bankNameCtrl.text = detected.bank;
      _selectedType = _directionToString(direction) ?? 'Debit';
      _selectedMode = _modeToString(detected.mode) ?? 'UPI';

      // Auto-generate patterns based on detected values
      if (detected.amount > 0) {
        _amountPatternCtrl.text =
            r'(?:rs\.?|inr|₹)\s*([0-9,]+(?:\.[0-9]{1,2})?)';
      }

      if (detected.referenceId.isNotEmpty) {
        _refCtrl.text = r'(?:ref|txn|utr|id|vpa)\s*:?\s*([0-9a-zA-Z]{6,})';
      }

      if (detected.accountLast4.isNotEmpty) {
        _accountCtrl.text = r'(?:\*|xx|a/c|account)\s*\*?(\d{4,})';
      }

      if (detected.upiId.isNotEmpty) {
        _upiPatternCtrl.text = r'([a-zA-Z0-9.\-_]+@[a-zA-Z]+)';
      }

      // Smart date detection for formats like 21/09/25 or 21-09-23
      if (msg.contains(RegExp(r'\d{2}/\d{2}/\d{2}'))) {
        _datePatternCtrl.text = r'(\d{2}/\d{2}/\d{2,4}(?:\s\d{2}:\d{2})?)';
      } else if (msg.contains(RegExp(r'\d{2}-\d{2}-\d{2}'))) {
        _datePatternCtrl.text = r'(\d{2}-\d{2}-\d{2,4}(?:\s\d{2}:\d{2})?)';
      }
    });
  }
}
