import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/theme/soft_palette.dart';
import '../../../../core/widgets/reference_ui.dart';
import '../models/block_rule.dart';
import '../sms_hive_boxes.dart';
import 'sms_training_form.dart';

class PasteMessageScreen extends StatefulWidget {
  final bool isForBlocking;
  const PasteMessageScreen({super.key, this.isForBlocking = false});

  @override
  State<PasteMessageScreen> createState() => _PasteMessageScreenState();
}

class _PasteMessageScreenState extends State<PasteMessageScreen> {
  final _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _analyze() {
    final text = _controller.text.trim();
    if (text.isEmpty) return;

    if (widget.isForBlocking) {
      _showBlockConfirm(text);
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => SmsTrainingForm(
            sampleSms: text,
            isManual: true,
          ),
        ),
      );
    }
  }

  void _showBlockConfirm(String text) {
    final keywords = text.split(RegExp(r'\s+')).take(5).toList();
    final kwController = TextEditingController(text: keywords.join(', '));
    final isDark = Theme.of(context).brightness == Brightness.dark;

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: isDark ? SoftPalette.darkCard : SoftPalette.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: Text(
          'Block This Type',
          style: TextStyle(
            color: isDark ? SoftPalette.darkInk : SoftPalette.ink,
            fontWeight: FontWeight.w700,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Define keywords to identify this message type:',
              style: TextStyle(
                color: isDark ? SoftPalette.darkMuted : SoftPalette.muted,
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: kwController,
              decoration: InputDecoration(
                labelText: 'Keywords (comma separated)',
                filled: true,
                fillColor:
                    isDark ? SoftPalette.darkSurfaceVariant : SoftPalette.surfaceVariant,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: BorderSide(
                    color: isDark ? SoftPalette.darkBorder : SoftPalette.border,
                  ),
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(
              'Cancel',
              style: TextStyle(
                color: isDark ? SoftPalette.darkMuted : SoftPalette.muted,
              ),
            ),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: SoftColors.control,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
            onPressed: () {
              final finalKeywords = kwController.text
                  .split(',')
                  .map((e) => e.trim())
                  .where((e) => e.isNotEmpty)
                  .toList();
              if (finalKeywords.isEmpty) return;

              final rule = BlockRule(
                id: DateTime.now().millisecondsSinceEpoch.toString(),
                keywords: finalKeywords,
                sampleMessage: text,
              );
              Hive.box<dynamic>(SmsHiveBoxes.blockRules)
                  .put(rule.id, rule.toMap());
              Navigator.pop(ctx);
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Block rule created')),
              );
            },
            child: const Text('Block'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = isDark ? SoftPalette.darkBg : SoftPalette.bg;
    final ink = isDark ? SoftPalette.darkInk : SoftPalette.ink;
    final muted = isDark ? SoftPalette.darkMuted : SoftPalette.muted;
    final title =
        widget.isForBlocking ? 'Ignore Message' : 'Paste SMS';

    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SoftPageHeader(title: title),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      widget.isForBlocking
                          ? 'Paste a bank SMS to create an ignore rule for similar messages.'
                          : 'Paste a bank SMS to detect a transaction without granting SMS permission.',
                      style: TextStyle(
                        fontSize: 14,
                        height: 1.45,
                        fontWeight: FontWeight.w500,
                        color: muted,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Expanded(
                      child: SxSoftCard(
                        padding: const EdgeInsets.all(16),
                        child: TextField(
                          controller: _controller,
                          maxLines: null,
                          expands: true,
                          textAlignVertical: TextAlignVertical.top,
                          style: TextStyle(
                            fontSize: 14,
                            height: 1.45,
                            color: ink,
                            fontWeight: FontWeight.w500,
                          ),
                          decoration: InputDecoration(
                            hintText: 'Paste your bank SMS here...',
                            hintStyle: TextStyle(color: muted, fontSize: 14),
                            border: InputBorder.none,
                            enabledBorder: InputBorder.none,
                            focusedBorder: InputBorder.none,
                            filled: false,
                            contentPadding: EdgeInsets.zero,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      height: 54,
                      child: FilledButton.icon(
                        onPressed: _analyze,
                        icon: Icon(
                          widget.isForBlocking
                              ? LucideIcons.shieldAlert
                              : LucideIcons.zap,
                          size: 18,
                        ),
                        label: Text(
                          widget.isForBlocking
                              ? 'Block This Type'
                              : 'Detect transaction',
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 15,
                          ),
                        ),
                        style: FilledButton.styleFrom(
                          backgroundColor: SoftColors.control,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(24),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
