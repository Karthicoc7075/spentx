import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/soft_palette.dart';

class SmsRuleStepHeader extends StatelessWidget {
  final int currentStep;
  final List<String> steps;

  const SmsRuleStepHeader({
    super.key,
    required this.currentStep,
    required this.steps,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: List.generate(steps.length * 2 - 1, (i) {
        if (i.isOdd) {
          final stepIndex = i ~/ 2;
          final done = currentStep > stepIndex;
          return Expanded(
            child: Container(
              height: 2,
              margin: const EdgeInsets.only(bottom: 18),
              color: done ? SoftPalette.emerald.withValues(alpha: 0.5) : AppSurface.border,
            ),
          );
        }
        final stepIndex = i ~/ 2;
        final active = currentStep == stepIndex;
        final done = currentStep > stepIndex;
        return Column(
          children: [
            Container(
              width: 28,
              height: 28,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: active || done
                    ? SoftPalette.emerald.withValues(alpha: active ? 0.25 : 0.15)
                    : Colors.white.withValues(alpha: 0.04),
                shape: BoxShape.circle,
                border: Border.all(
                  color: active || done ? SoftPalette.emerald : AppSurface.border,
                ),
              ),
              child: done
                  ? const Icon(LucideIcons.check, size: 14, color: SoftPalette.emerald)
                  : Text(
                      '${stepIndex + 1}',
                      style: TextStyle(
                        color: active ? SoftPalette.emerald : AppSurface.faint,
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
            ),
            const SizedBox(height: 6),
            Text(
              steps[stepIndex],
              style: TextStyle(
                color: active ? Colors.white : AppSurface.faint,
                fontSize: 11,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        );
      }),
    );
  }
}

class SmsRuleSectionLabel extends StatelessWidget {
  final String label;
  final String? hint;

  const SmsRuleSectionLabel({super.key, required this.label, this.hint});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              color: AppSurface.text.withValues(alpha: 0.3),
              fontSize: 11,
              fontWeight: FontWeight.w500,
              letterSpacing: 1,
            ),
          ),
          if (hint != null) ...[
            const SizedBox(height: 4),
            Text(hint!, style: TextStyle(color: AppSurface.faint, fontSize: 12, height: 1.35)),
          ],
        ],
      ),
    );
  }
}

class SmsRuleCard extends StatelessWidget {
  final Widget child;
  final Color? borderColor;

  const SmsRuleCard({super.key, required this.child, this.borderColor});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppSurface.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor ?? Colors.white.withValues(alpha: 0.06)),
      ),
      child: child,
    );
  }
}

class SmsRuleMethodTile extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final bool selected;
  final VoidCallback onTap;

  const SmsRuleMethodTile({
    super.key,
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: selected ? color.withValues(alpha: 0.12) : color.withValues(alpha: 0.05),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: selected ? color.withValues(alpha: 0.45) : color.withValues(alpha: 0.12),
            width: selected ? 1.5 : 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 20),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: TextStyle(color: AppSurface.text, fontWeight: FontWeight.w500, fontSize: 14)),
                  const SizedBox(height: 3),
                  Text(subtitle, style: TextStyle(color: AppSurface.text.withValues(alpha: 0.4), fontSize: 12)),
                ],
              ),
            ),
            Icon(
              selected ? LucideIcons.checkCircle2 : LucideIcons.circle,
              color: selected ? color : AppSurface.faint,
              size: 20,
            ),
          ],
        ),
      ),
    );
  }
}