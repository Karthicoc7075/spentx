import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../../../core/theme/soft_palette.dart';
import '../../../sms_parser/sms_parser.dart';
import '../../../sms_parser/models/transaction_parsed.dart';
import '../../../sms_parser/sms_direction_helper.dart';
import '../engine/sms_rule_engine.dart';
import '../models/sms_template_rule.dart';
import '../engine/sms_template_engine.dart';
import '../providers/sms_template_provider.dart';

class TemplateTrainingScreen extends ConsumerStatefulWidget {
  final String sampleSms;
  final SmsTemplateRule? existingRule;
  const TemplateTrainingScreen({super.key, required this.sampleSms, this.existingRule});
  @override
  ConsumerState<TemplateTrainingScreen> createState() => _TemplateTrainingScreenState();
}

class _TemplateTrainingScreenState extends ConsumerState<TemplateTrainingScreen> {
  late List<_SmsToken> _tokens;
  late final TextEditingController _bankCtrl;
  String _selectedType = 'debit';
  String _selectedMode = 'upi';
  double _threshold = 0.65;
  TransactionParsed? _autoDetected;
  _SmsToken? _rangeAnchor;
  bool _showSummary = false;

  bool get _isEditing => widget.existingRule != null;

  @override
  void initState() {
    super.initState();
    _bankCtrl = TextEditingController();

    if (_isEditing) {
      final rule = widget.existingRule!;
      _bankCtrl.text = rule.bankNameExact.isNotEmpty ? rule.bankNameExact : rule.bankName;
      _selectedType = rule.type;
      _selectedMode = rule.mode;
      _threshold = rule.similarityThreshold;
    } else {
      _autoDetected = SmsRuleEngine.parse(widget.sampleSms) ??
          UniversalSmsParser.parseSms(widget.sampleSms);
      _bankCtrl.text = _autoDetected?.bank ?? '';
      if (_autoDetected != null) {
        final direction = SmsDirectionHelper.resolveDirection(
          rawMessage: widget.sampleSms,
          parsed: _autoDetected,
        );
        _selectedType = direction == TransactionDirection.income
            ? 'credit'
            : direction == TransactionDirection.transfer
                ? 'transfer'
                : 'debit';
        _selectedMode = _autoDetected!.mode == TransactionMode.upi ? 'upi'
            : _autoDetected!.mode == TransactionMode.atm ? 'atm'
            : _autoDetected!.mode == TransactionMode.card ? 'card' : 'unknown';
      }
    }
    _tokenize();
    if (_isEditing) {
      _applyExistingTags(widget.existingRule!);
    }
  }

  @override
  void dispose() {
    _bankCtrl.dispose();
    super.dispose();
  }

  void _tokenize() {
    _tokens = [];
    final msg = widget.sampleSms;
    final pattern = RegExp(r'(\S+)');
    int lastEnd = 0;
    for (final match in pattern.allMatches(msg)) {
      if (match.start > lastEnd) {
        final whitespace = msg.substring(lastEnd, match.start);
        if (whitespace.isNotEmpty) {
          _tokens.add(_SmsToken(text: whitespace, start: lastEnd, end: match.start, isSelectable: false));
        }
      }
      final word = match.group(0)!;
      String? autoField = _isEditing ? null : _autoDetectField(word);
      _tokens.add(_SmsToken(text: word, start: match.start, end: match.end, isSelectable: true, assignedField: autoField));
      lastEnd = match.end;
    }
    if (lastEnd < msg.length) {
      final remaining = msg.substring(lastEnd);
      if (remaining.isNotEmpty) {
        _tokens.add(_SmsToken(text: remaining, start: lastEnd, end: msg.length, isSelectable: false));
      }
    }
  }

  void _applyExistingTags(SmsTemplateRule rule) {
    for (final entry in rule.extractionMap.entries) {
      final originalText = entry.key;
      final fieldType = entry.value;
      for (final token in _tokens) {
        if (!token.isSelectable) continue;
        if (originalText.contains(token.text) || token.text.contains(originalText)) {
          token.assignedField = fieldType;
        }
      }
    }
  }

  String? _autoDetectField(String text) {
    final lower = text.toLowerCase().trim();
    if (RegExp(r'^(?:rs\.?|₹|inr)?[0-9,]+(?:\.[0-9]{1,2})?$', caseSensitive: false).hasMatch(text)) {
      return TemplateFieldType.amount;
    }
    if (text.contains('@')) return TemplateFieldType.upiId;
    if (RegExp(r'^(?:xx|XX|\*{2})\d{4,}$').hasMatch(text)) return TemplateFieldType.accountLast4;
    if (RegExp(r'^\d{2}[-/]\d{2}[-/]\d{2,4}$').hasMatch(text)) return TemplateFieldType.date;
    if (RegExp(r'^\d{9,}$').hasMatch(text)) return TemplateFieldType.referenceId;

    const debitKws = ['debited', 'spent', 'sent', 'paid', 'withdrawn'];
    if (debitKws.any((k) => lower == k || lower.contains(k))) return TemplateFieldType.debitType;

    const creditKws = ['credited', 'received', 'deposited'];
    if (creditKws.any((k) => lower == k || lower.contains(k))) return TemplateFieldType.creditType;

    const transferKws = ['transfer', 'transferred'];
    if (transferKws.any((k) => lower == k || lower.contains(k))) return TemplateFieldType.transferType;

    const bankKws = ['hdfc', 'sbi', 'icici', 'axis', 'kotak', 'pnb', 'bob', 'canara', 'union', 'idfc'];
    if (bankKws.any((b) => lower == b || lower.contains(b))) return TemplateFieldType.bankName;
    return null;
  }

  List<TaggedSegment> _buildSegments() {
    final segments = <TaggedSegment>[];
    final selectable = _tokens.where((t) => t.isSelectable).toList();

    int i = 0;
    while (i < selectable.length) {
      final token = selectable[i];
      if (token.assignedField == null) {
        i++;
        continue;
      }
      final field = token.assignedField!;
      int start = token.start;
      int end = token.end;
      int j = i + 1;
      while (j < selectable.length &&
          selectable[j].assignedField == field &&
          selectable[j].start == end) {
        end = selectable[j].end;
        j++;
      }
      segments.add(TaggedSegment(start: start, end: end, fieldType: field));
      i = j;
    }
    return segments;
  }

  SmsTemplateRule? _buildDraftRule() {
    final segments = _buildSegments();
    if (segments.isEmpty) return null;
    final bank = _bankCtrl.text.trim().isNotEmpty ? _bankCtrl.text.trim() : 'Unknown';
    return TemplateBuilder.build(
      sampleMessage: widget.sampleSms,
      segments: segments,
      bankName: bank,
      type: _selectedType,
      mode: _selectedMode,
      threshold: _threshold,
      id: widget.existingRule?.id,
    );
  }

  void _saveTemplate() {
    final draft = _buildDraftRule();
    if (draft == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Please tag at least one field'),
        backgroundColor: SoftPalette.negative,
      ));
      return;
    }

    if (_isEditing) {
      ref.read(smsTemplateRuleProvider.notifier).deleteRule(widget.existingRule!.id);
    }

    ref.read(smsTemplateRuleProvider.notifier).addRule(draft);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(LucideIcons.checkCircle, color: context.softInk, size: 18),
        const SizedBox(width: 12),
        Text(_isEditing ? '${draft.bankName} updated' : '${draft.bankName} saved'),
      ]),
      backgroundColor: SoftPalette.emerald,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ));
    Navigator.pop(context, true);
  }

  void _testTemplate() {
    final draft = _buildDraftRule();
    if (draft == null) return;
    final result = SmsTemplateEngine.testRule(widget.sampleSms, draft);
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        decoration: BoxDecoration(
          color: context.softSurface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
          border: const Border(top: BorderSide(color: Color(0xFFF1F5F9))),
          boxShadow: const [
            BoxShadow(color: Color(0x140F172A), blurRadius: 24, offset: Offset(0, -8)),
          ],
        ),
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Icon(LucideIcons.flaskConical, color: context.softEmerald, size: 24),
              const SizedBox(width: 12),
              Text('Template Test', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w500, color: context.softInk)),
            ]),
            Divider(height: 32, color: context.softBorder),
            if (result == null)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: SoftPalette.negative.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(12)),
                child: const Text('Could not extract. Tag more fields.', style: TextStyle(color: SoftPalette.negative, fontWeight: FontWeight.w500)),
              )
            else ...[
              _resultRow('Amount', '₹${result.amount}'),
              _resultRow('Title', result.name),
              _resultRow('Bank', result.bank),
              _resultRow('Account', '...${result.accountLast4}'),
              _resultRow('UPI', result.upiId),
              _resultRow('Ref', result.referenceId),
            ],
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  void _onTokenTap(_SmsToken token) {
    if (_rangeAnchor != null && _rangeAnchor != token) {
      final a = _rangeAnchor!;
      final startIdx = _tokens.indexOf(a);
      final endIdx = _tokens.indexOf(token);
      if (startIdx >= 0 && endIdx >= 0) {
        final lo = startIdx < endIdx ? startIdx : endIdx;
        final hi = startIdx < endIdx ? endIdx : startIdx;
        _showFieldPickerForRange(lo, hi);
        setState(() => _rangeAnchor = null);
        return;
      }
    }
    _showFieldPicker(token);
  }

  void _showFieldPickerForRange(int from, int to) {
    final rangeText = widget.sampleSms.substring(_tokens[from].start, _tokens[to].end);
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        decoration: BoxDecoration(
          color: context.softSurface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
          border: const Border(top: BorderSide(color: Color(0xFFF1F5F9))),
          boxShadow: const [
            BoxShadow(color: Color(0x140F172A), blurRadius: 24, offset: Offset(0, -8)),
          ],
        ),
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Tag "$rangeText"', style: TextStyle(color: context.softInk, fontSize: 16, fontWeight: FontWeight.w500)),
            const SizedBox(height: 8),
            Text('Applies to all words in this range', style: TextStyle(color: context.softFaint, fontSize: 12)),
            const SizedBox(height: 16),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                ...TemplateFieldType.all.map((f) => _fieldPickerChip(f, onPick: (field) {
                  setState(() {
                    for (int i = from; i <= to; i++) {
                      if (_tokens[i].isSelectable) _tokens[i].assignedField = field;
                    }
                  });
                  Navigator.pop(context);
                })),
                _fieldPickerChip(null, label: 'Clear', onPick: (_) {
                  setState(() {
                    for (int i = from; i <= to; i++) {
                      if (_tokens[i].isSelectable) _tokens[i].assignedField = null;
                    }
                  });
                  Navigator.pop(context);
                }),
              ],
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _resultRow(String l, String v) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: Row(children: [
      Text(l, style: TextStyle(color: context.softFaint, fontSize: 13)),
      const Spacer(),
      Text(
        v.isEmpty ? '—' : v,
        style: TextStyle(
          color: v.isEmpty ? context.softFaint : context.softInk,
          fontWeight: FontWeight.w500,
          fontSize: 13,
        ),
      ),
    ]),
  );

  @override
  Widget build(BuildContext context) {
    final draft = _buildDraftRule();
    final taggedCount = _tokens.where((t) => t.isSelectable && t.assignedField != null).length;

    return Scaffold(
      backgroundColor: context.softBg,
      appBar: AppBar(
        backgroundColor: context.softBg,
        surfaceTintColor: Colors.transparent,
        shadowColor: Colors.transparent,
        elevation: 0,
        title: Text(
          _isEditing ? 'Edit Template' : 'Tag SMS Fields',
          style: TextStyle(
            color: context.softInk,
            fontSize: 20,
            fontWeight: FontWeight.w700,
            letterSpacing: -0.2,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => setState(() => _showSummary = !_showSummary),
            child: Text(_showSummary ? 'Hide' : 'Summary', style: TextStyle(color: context.softEmerald, fontWeight: FontWeight.w500)),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _softStepHeader(),
          const SizedBox(height: 24),

          _softSectionLabel(
            'TAG SMS PARTS',
            hint: 'Tap a word to tag it. Long-press one word, then tap another to tag a phrase.',
          ),
          _softCard(
            child: Wrap(
              spacing: 2,
              runSpacing: 4,
              children: _tokens.map((t) => _buildTokenChip(t)).toList(),
            ),
          ),
          if (_rangeAnchor != null) ...[
            const SizedBox(height: 8),
            Text(
              'Range mode: tap another word to tag "${_rangeAnchor!.text}" → …',
              style: const TextStyle(color: SoftPalette.warning, fontSize: 11, fontWeight: FontWeight.w500),
            ),
          ],
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 6,
            children: TemplateFieldType.all
                .where((f) => f != TemplateFieldType.ignoreText)
                .map((f) => _legendChip(f))
                .toList(),
          ),
          const SizedBox(height: 8),
          Text('$taggedCount words tagged', style: TextStyle(color: context.softInk.withValues(alpha: 0.3), fontSize: 11)),
          const SizedBox(height: 24),

          _softSectionLabel('BANK NAME'),
          _softCard(
            child: TextField(
              controller: _bankCtrl,
              style: TextStyle(color: context.softInk),
              decoration: InputDecoration(
                hintText: 'e.g. HDFC Bank, IDFC FIRST Bank',
                hintStyle: TextStyle(color: context.softFaint),
                filled: true,
                fillColor: context.softSurfaceVariant,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              ),
            ),
          ),
          const SizedBox(height: 20),

          _softSectionLabel('TRANSACTION TYPE'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _typeCard('Debit', 'debit', SoftPalette.negative, Icons.arrow_downward),
              _typeCard('Credit', 'credit', SoftPalette.positive, Icons.arrow_upward),
              _typeCard('Transfer', 'transfer', context.softEmerald, Icons.swap_horiz),
              _typeCard('ATM', 'atm', SoftPalette.warning, Icons.local_atm),
              _typeCard('Card', 'card', SoftPalette.mintDark, Icons.credit_card),
            ],
          ),
          const SizedBox(height: 20),

          _softSectionLabel(
            'MATCH SENSITIVITY',
            hint: 'How similar a future SMS must be to use this template.',
          ),
          _softCard(
            child: Column(
              children: [
                Row(
                  children: [
                    Text('Threshold', style: TextStyle(color: context.softMuted, fontSize: 13)),
                    const Spacer(),
                    Text('${(_threshold * 100).toInt()}%', style: TextStyle(color: context.softEmerald, fontWeight: FontWeight.w500)),
                  ],
                ),
                Slider(
                  value: _threshold,
                  min: 0.45,
                  max: 0.9,
                  divisions: 9,
                  activeColor: SoftColors.control,
                  inactiveColor: context.softBorder,
                  onChanged: (v) => setState(() => _threshold = v),
                ),
              ],
            ),
          ),

          if (_showSummary && draft != null) ...[
            const SizedBox(height: 20),
            _softSectionLabel('RULE SUMMARY'),
            _softCard(
              borderColor: context.softEmerald.withValues(alpha: 0.2),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _resultRow('Bank', draft.bankNameExact.isNotEmpty ? draft.bankNameExact : draft.bankName),
                  _resultRow('Type', draft.type.toUpperCase()),
                  _resultRow('Mode', draft.mode.toUpperCase()),
                  _resultRow('Fields', '${draft.extractionMap.length} tagged'),
                  _resultRow('Keywords', '${draft.keywords.length}'),
                  const SizedBox(height: 8),
                  Text(
                    draft.templatePattern,
                    style: TextStyle(
                      color: context.softInk.withValues(alpha: 0.45),
                      fontSize: 11,
                      fontFamily: 'monospace',
                      height: 1.4,
                    ),
                  ),
                ],
              ),
            ),
          ],

          if (!_isEditing) ...[
            const SizedBox(height: 20),
            _buildParseDebugPanel(),
          ],
          const SizedBox(height: 32),

          Row(children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: draft == null ? null : _testTemplate,
                icon: const Icon(LucideIcons.flaskConical, size: 18),
                label: const Text('Test'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: context.softEmerald,
                  side: BorderSide(color: context.softEmerald),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: ElevatedButton.icon(
                onPressed: _saveTemplate,
                icon: const Icon(LucideIcons.save, size: 18),
                label: Text(_isEditing ? 'Update' : 'Save Rule'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: SoftColors.control,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  elevation: 0,
                ),
              ),
            ),
          ]),
          const SizedBox(height: 60),
        ],
      ),
    );
  }

  Widget _softStepHeader() {
    const steps = ['Paste SMS', 'Tag Fields', 'Save Rule'];
    const currentStep = 1;
    return Row(
      children: List.generate(steps.length * 2 - 1, (i) {
        if (i.isOdd) {
          final stepIndex = i ~/ 2;
          return Expanded(
            child: Container(
              height: 2,
              margin: const EdgeInsets.only(bottom: 18),
              color: currentStep > stepIndex
                  ? context.softEmerald.withValues(alpha: 0.45)
                  : context.softBorder,
            ),
          );
        }
        final stepIndex = i ~/ 2;
        final active = currentStep == stepIndex;
        final done = currentStep > stepIndex;
        return Column(
          children: [
            Container(
              width: 30,
              height: 30,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: active || done ? context.softEmeraldSoft : context.softSurface,
                shape: BoxShape.circle,
                border: Border.all(
                  color: active || done ? context.softEmerald : context.softBorder,
                ),
              ),
              child: done
                  ? Icon(LucideIcons.check, size: 15, color: context.softEmerald)
                  : Text(
                      '${stepIndex + 1}',
                      style: TextStyle(
                        color: active ? context.softEmerald : context.softFaint,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
            ),
            const SizedBox(height: 6),
            Text(
              steps[stepIndex],
              style: TextStyle(
                color: active ? context.softInk : context.softFaint,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        );
      }),
    );
  }

  Widget _softSectionLabel(String label, {String? hint}) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: context.softMuted,
            fontSize: 11,
            fontWeight: FontWeight.w700,
            letterSpacing: 1.1,
          ),
        ),
        if (hint != null) ...[
          const SizedBox(height: 4),
          Text(
            hint,
            style: TextStyle(color: context.softMuted, fontSize: 12, height: 1.35),
          ),
        ],
      ],
    ),
  );

  Widget _softCard({required Widget child, Color? borderColor}) => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(
      color: context.softSurface,
      borderRadius: BorderRadius.circular(24),
      border: Border.all(color: borderColor ?? const Color(0xFFF1F5F9)),
      boxShadow: const [
        BoxShadow(
          color: Color(0x0A0F172A),
          blurRadius: 16,
          offset: Offset(0, 5),
        ),
      ],
    ),
    child: child,
  );

  Widget _buildParseDebugPanel() {
    final dbg = SmsRuleEngine.lastParseDebug;
    final type = dbg?.detectedType ??
        (_autoDetected != null
            ? SmsDirectionHelper.typeLabel(rawMessage: widget.sampleSms, parsed: _autoDetected)
            : '—');
    return _softCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('PARSER DEBUG', style: TextStyle(color: context.softFaint, fontSize: 11, fontWeight: FontWeight.w500, letterSpacing: 1.2)),
          const SizedBox(height: 10),
          _resultRow('Detected Title', dbg?.detectedTitle ?? _autoDetected?.name ?? '—'),
          _resultRow('Detected Type', type),
          _resultRow('Matched Template', dbg?.matchedTemplate ?? '—'),
          _resultRow('Parse Source', dbg?.source ?? '—'),
        ],
      ),
    );
  }

  Widget _typeCard(String label, String typeValue, Color color, IconData icon) {
    final isSelected = _selectedType == typeValue ||
        (typeValue == 'atm' && _selectedMode == 'atm') ||
        (typeValue == 'card' && _selectedMode == 'card');
    return GestureDetector(
      onTap: () => setState(() {
        if (typeValue == 'atm' || typeValue == 'card') {
          _selectedMode = typeValue;
          _selectedType = 'debit';
        } else {
          _selectedType = typeValue;
          if (_selectedMode == 'atm' || _selectedMode == 'card') {
            _selectedMode = 'upi';
          }
        }
      }),
      child: Container(
        width: (MediaQuery.of(context).size.width - 56) / 2,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: isSelected ? color.withValues(alpha: 0.15) : context.softSurface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: isSelected ? color : context.softBorder),
        ),
        child: Row(children: [
          Icon(icon, size: 18, color: isSelected ? color : context.softFaint),
          const SizedBox(width: 8),
          Expanded(child: Text(label, style: TextStyle(color: isSelected ? context.softInk : context.softMuted, fontSize: 13, fontWeight: FontWeight.w500))),
        ]),
      ),
    );
  }

  Widget _buildTokenChip(_SmsToken token) {
    if (!token.isSelectable) {
      return Text(token.text, style: TextStyle(color: context.softFaint, fontSize: 14, height: 1.6));
    }
    final field = token.assignedField;
    final color = _fieldColor(field);
    final isAnchor = _rangeAnchor == token;
    return GestureDetector(
      onTap: () => _onTokenTap(token),
      onLongPress: () => setState(() => _rangeAnchor = token),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
        decoration: BoxDecoration(
          color: color.withValues(alpha: isAnchor ? 0.35 : 0.15),
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: isAnchor ? SoftPalette.warning : color.withValues(alpha: 0.3), width: isAnchor ? 1.5 : 1),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(token.text, style: TextStyle(color: context.softInk, fontSize: 14, fontWeight: FontWeight.w500)),
            if (field != null)
              Text(TemplateFieldType.label(field), style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w500)),
          ],
        ),
      ),
    );
  }

  void _showFieldPicker(_SmsToken token) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        decoration: BoxDecoration(
          color: context.softSurface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
          border: const Border(top: BorderSide(color: Color(0xFFF1F5F9))),
          boxShadow: const [
            BoxShadow(color: Color(0x140F172A), blurRadius: 24, offset: Offset(0, -8)),
          ],
        ),
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('What is "${token.text}"?', style: TextStyle(color: context.softInk, fontSize: 16, fontWeight: FontWeight.w500)),
            const SizedBox(height: 16),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                ...TemplateFieldType.all.map((f) => _fieldPickerChip(f, onPick: (field) {
                  setState(() => token.assignedField = field);
                  Navigator.pop(context);
                })),
                _fieldPickerChip(null, label: 'Clear', onPick: (_) {
                  setState(() => token.assignedField = null);
                  Navigator.pop(context);
                }),
              ],
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _fieldPickerChip(String? field, {String? label, required void Function(String?) onPick}) {
    final color = _fieldColor(field);
    return GestureDetector(
      onTap: () => onPick(field),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.12),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withValues(alpha: 0.3)),
        ),
        child: Text(
          label ?? TemplateFieldType.label(field!),
          style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w500),
        ),
      ),
    );
  }

  Color _fieldColor(String? field) {
    switch (field) {
      case TemplateFieldType.amount: return context.softEmerald;
      case TemplateFieldType.debitType: return SoftPalette.negative;
      case TemplateFieldType.creditType: return SoftPalette.positive;
      case TemplateFieldType.transferType: return SoftPalette.mintDark;
      case TemplateFieldType.bankName: return context.softEmerald;
      case TemplateFieldType.accountNumber:
      case TemplateFieldType.accountLast4: return SoftPalette.mintDark;
      case TemplateFieldType.balance: return SoftPalette.positive;
      case TemplateFieldType.upiId: return context.softEmerald;
      case TemplateFieldType.referenceId: return context.softMuted;
      case TemplateFieldType.merchantName:
      case TemplateFieldType.title: return SoftPalette.mintDark;
      case TemplateFieldType.date: return SoftPalette.warning;
      case TemplateFieldType.time: return SoftPalette.warning;
      case TemplateFieldType.atmWithdraw: return SoftPalette.negative;
      case TemplateFieldType.cardPayment: return SoftPalette.mintDark;
      case TemplateFieldType.ignoreText: return context.softFaint;
      default: return context.softFaint;
    }
  }

  Widget _legendChip(String field) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
    decoration: BoxDecoration(color: _fieldColor(field).withValues(alpha: 0.08), borderRadius: BorderRadius.circular(6)),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(width: 8, height: 8, decoration: BoxDecoration(color: _fieldColor(field), shape: BoxShape.circle)),
        const SizedBox(width: 6),
        Text(TemplateFieldType.label(field), style: TextStyle(color: _fieldColor(field), fontSize: 11, fontWeight: FontWeight.w500)),
      ],
    ),
  );
}

class _SmsToken {
  final String text;
  final int start;
  final int end;
  final bool isSelectable;
  String? assignedField;
  _SmsToken({required this.text, required this.start, required this.end, this.isSelectable = true, this.assignedField});
}