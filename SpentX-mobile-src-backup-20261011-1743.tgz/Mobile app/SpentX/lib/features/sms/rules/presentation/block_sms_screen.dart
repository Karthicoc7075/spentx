import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/soft_palette.dart';
import '../../../../core/widgets/reference_ui.dart';
import '../models/block_rule.dart';
import '../providers/sms_template_provider.dart';
import 'widgets/sms_rule_flow_widgets.dart';

enum BlockMatchType { contains, regex }

class BlockSmsScreen extends ConsumerStatefulWidget {
  final BlockRule? existingRule;
  final String? initialSms;

  const BlockSmsScreen({super.key, this.existingRule, this.initialSms});

  @override
  ConsumerState<BlockSmsScreen> createState() => _BlockSmsScreenState();
}

class _BlockSmsScreenState extends ConsumerState<BlockSmsScreen> {
  final _nameCtrl = TextEditingController();
  final _smsCtrl = TextEditingController();
  final _keywordsCtrl = TextEditingController();
  final _testCtrl = TextEditingController();

  List<String> _suggestedKeywords = [];
  List<bool> _keywordSelected = [];
  BlockMatchType _matchType = BlockMatchType.contains;
  double _threshold = 0.6;
  bool _analyzed = false;
  String? _testResult;

  bool get _isEditing => widget.existingRule != null;

  @override
  void initState() {
    super.initState();
    if (_isEditing) {
      final rule = widget.existingRule!;
      _nameCtrl.text = rule.name ?? '';
      _smsCtrl.text = rule.sampleMessage;
      _keywordsCtrl.text = rule.keywords.join(', ');
      _matchType = rule.pattern != null && rule.pattern!.isNotEmpty
          ? BlockMatchType.regex
          : BlockMatchType.contains;
      _threshold = rule.similarityThreshold;
      _analyzed = true;
      _suggestedKeywords = List.from(rule.keywords);
      _keywordSelected = List.filled(rule.keywords.length, true);
    } else if (widget.initialSms != null && widget.initialSms!.trim().isNotEmpty) {
      _smsCtrl.text = widget.initialSms!.trim();
    }
    _testCtrl.text = _smsCtrl.text;
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _smsCtrl.dispose();
    _keywordsCtrl.dispose();
    _testCtrl.dispose();
    super.dispose();
  }

  List<String> _parseKeywordInput() {
    final fromField = _keywordsCtrl.text
        .split(RegExp(r'[\n,]+'))
        .map((s) => s.trim().toLowerCase())
        .where((s) => s.isNotEmpty)
        .toList();
    if (fromField.isNotEmpty) return fromField;

    final selected = <String>[];
    for (int i = 0; i < _suggestedKeywords.length; i++) {
      if (_keywordSelected[i]) selected.add(_suggestedKeywords[i]);
    }
    return selected;
  }

  BlockRule _buildDraftRule() {
    final keywords = _parseKeywordInput();
    return BlockRule(
      id: widget.existingRule?.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
      name: _nameCtrl.text.trim().isEmpty ? null : _nameCtrl.text.trim(),
      keywords: keywords,
      pattern: _matchType == BlockMatchType.regex && keywords.isNotEmpty ? keywords.join('|') : null,
      sampleMessage: _smsCtrl.text.trim(),
      similarityThreshold: _threshold,
      createdAt: widget.existingRule?.createdAt,
    );
  }

  void _analyze() {
    final text = _smsCtrl.text.trim();
    if (text.isEmpty) return;

    const fillerWords = {
      'the', 'and', 'for', 'you', 'your', 'our', 'this', 'that', 'with', 'from',
      'has', 'been', 'are', 'was', 'will', 'can', 'not', 'now', 'dear', 'hi',
    };
    final words = text
        .split(RegExp(r'[\s,.:;!?()/\\]+'))
        .map((w) => w.trim().toLowerCase())
        .where((w) => w.length > 2 && !RegExp(r'^\d+$').hasMatch(w) && !fillerWords.contains(w))
        .toSet()
        .toList();

    setState(() {
      _suggestedKeywords = words;
      _keywordSelected = List.filled(words.length, true);
      _keywordsCtrl.text = words.join(', ');
      _analyzed = true;
      _testCtrl.text = text;
    });
  }

  void _runTest() {
    final draft = _buildDraftRule();
    final testMsg = _testCtrl.text.trim();
    if (testMsg.isEmpty) {
      setState(() => _testResult = 'Enter a test message');
      return;
    }
    final reason = draft.matchReason(testMsg);
    setState(() => _testResult = reason ?? 'No match — SMS would NOT be blocked');
    HapticFeedback.lightImpact();
  }

  void _save() {
    final keywords = _parseKeywordInput();
    if (keywords.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Add at least one keyword or pattern'),
          backgroundColor: AppColors.expense,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    final rule = _buildDraftRule();
    if (_isEditing) {
      ref.read(blockRuleProvider.notifier).updateRule(rule);
    } else {
      ref.read(blockRuleProvider.notifier).addRule(rule);
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(LucideIcons.shieldCheck, color: AppSurface.text, size: 18),
            const SizedBox(width: 12),
            Text(_isEditing ? 'Block rule updated' : 'Block rule saved (${keywords.length} keywords)'),
          ],
        ),
        backgroundColor: AppColors.expense,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
    Navigator.pop(context, true);
  }

  Future<void> _pasteSample() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    final text = data?.text?.trim() ?? '';
    if (text.isEmpty) return;
    setState(() => _smsCtrl.text = text);
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      backgroundColor: isDark ? SoftPalette.darkBg : SoftPalette.bg,
      body: SafeArea(
        child: Column(
          children: [
            SoftPageHeader(
              title: _isEditing ? 'Edit Block Rule' : 'Block SMS',
            ),
            Expanded(
              child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
        children: [
          SmsRuleStepHeader(
            currentStep: _isEditing ? 2 : (_analyzed ? 1 : 0),
            steps: const ['Paste SMS', 'Keywords', 'Test & Save'],
          ),
          const SizedBox(height: 24),

          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppColors.expense.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.expense.withValues(alpha: 0.15)),
            ),
            child: Text(
              'Block promo, OTP, loan, and spam SMS before they reach detection. Matching messages are ignored entirely.',
              style: TextStyle(color: AppSurface.subText, fontSize: 12, height: 1.45),
            ),
          ),
          const SizedBox(height: 24),

          const SmsRuleSectionLabel(label: 'RULE NAME', hint: 'Optional — e.g. Wakefit Ads, Loan Offers'),
          SmsRuleCard(
            child: TextField(
              controller: _nameCtrl,
              style: TextStyle(color: AppSurface.text),
              decoration: InputDecoration(
                hintText: 'Block rule name',
                hintStyle: TextStyle(color: AppSurface.faint),
                filled: true,
                fillColor: Colors.black26,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              ),
            ),
          ),
          const SizedBox(height: 20),

          const SmsRuleSectionLabel(
            label: 'PASTE UNWANTED SMS',
            hint: 'Paste one example of the SMS type you want to block.',
          ),
          SmsRuleCard(
            borderColor: AppColors.expense.withValues(alpha: 0.12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextField(
                  controller: _smsCtrl,
                  maxLines: 5,
                  style: TextStyle(color: AppSurface.text, fontSize: 13, height: 1.45),
                  decoration: InputDecoration(
                    hintText: 'Paste promo / OTP / loan SMS here...',
                    hintStyle: TextStyle(color: AppSurface.border),
                    border: InputBorder.none,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    OutlinedButton.icon(
                      onPressed: _pasteSample,
                      icon: const Icon(LucideIcons.clipboardPaste, size: 14),
                      label: const Text('Paste', style: TextStyle(fontSize: 12)),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: AppSurface.subText,
                        side: BorderSide(color: AppSurface.text.withValues(alpha: 0.1)),
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      ),
                    ),
                    const Spacer(),
                    if (!_analyzed)
                      FilledButton.icon(
                        onPressed: _analyze,
                        icon: const Icon(LucideIcons.search, size: 14),
                        label: const Text('Extract Keywords', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500)),
                        style: FilledButton.styleFrom(
                          backgroundBuilder: SoftColors.plainBackground,
                          backgroundColor: AppColors.expense,
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          const SmsRuleSectionLabel(
            label: 'KEYWORDS / PATTERN',
            hint: 'Comma or newline separated. Toggle chips below or edit manually.',
          ),
          SmsRuleCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextField(
                  controller: _keywordsCtrl,
                  maxLines: 4,
                  style: TextStyle(color: AppSurface.text, fontSize: 13),
                  onChanged: (_) => setState(() => _analyzed = true),
                  decoration: InputDecoration(
                    hintText: 'reward, claim now, otp, loan approved',
                    hintStyle: TextStyle(color: AppSurface.faint),
                    filled: true,
                    fillColor: Colors.black26,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                  ),
                ),
                if (_suggestedKeywords.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: List.generate(_suggestedKeywords.length, (i) {
                      final selected = _keywordSelected[i];
                      return GestureDetector(
                        onTap: () => setState(() => _keywordSelected[i] = !_keywordSelected[i]),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 180),
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                          decoration: BoxDecoration(
                            color: selected ? AppColors.expense.withValues(alpha: 0.15) : Colors.white.withValues(alpha: 0.03),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: selected ? AppColors.expense.withValues(alpha: 0.4) : AppSurface.border,
                            ),
                          ),
                          child: Text(
                            _suggestedKeywords[i],
                            style: TextStyle(
                              color: selected ? AppColors.expense : AppSurface.faint,
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      );
                    }),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 20),

          const SmsRuleSectionLabel(label: 'MATCH TYPE'),
          Row(
            children: [
              _matchChip('Contains', BlockMatchType.contains),
              const SizedBox(width: 8),
              _matchChip('Regex', BlockMatchType.regex),
            ],
          ),
          const SizedBox(height: 20),

          if (_matchType == BlockMatchType.contains) ...[
            const SmsRuleSectionLabel(
              label: 'MATCH SENSITIVITY',
              hint: 'Lower = blocks more similar messages. Higher = only close matches.',
            ),
            SmsRuleCard(
              child: Column(
                children: [
                  Row(
                    children: [
                      Text('Threshold', style: TextStyle(color: AppSurface.subText, fontSize: 13)),
                      const Spacer(),
                      Text('${(_threshold * 100).toInt()}%', style: const TextStyle(color: AppColors.expense, fontWeight: FontWeight.w500)),
                    ],
                  ),
                  Slider(
                    value: _threshold,
                    min: 0.4,
                    max: 0.9,
                    divisions: 10,
                    activeColor: SoftColors.control,
                    inactiveColor: AppSurface.border,
                    onChanged: (v) => setState(() => _threshold = v),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
          ],

          const SmsRuleSectionLabel(label: 'TEST RULE', hint: 'Paste any SMS to check if this rule would block it.'),
          SmsRuleCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextField(
                  controller: _testCtrl,
                  maxLines: 3,
                  style: TextStyle(color: AppSurface.text, fontSize: 13),
                  decoration: InputDecoration(
                    hintText: 'Test message...',
                    hintStyle: TextStyle(color: AppSurface.faint),
                    filled: true,
                    fillColor: Colors.black26,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                  ),
                ),
                const SizedBox(height: 10),
                OutlinedButton.icon(
                  onPressed: _runTest,
                  icon: const Icon(LucideIcons.flaskConical, size: 16),
                  label: const Text('Run Test'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.expense,
                    side: BorderSide(color: AppColors.expense.withValues(alpha: 0.4)),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
                if (_testResult != null) ...[
                  const SizedBox(height: 12),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: (_testResult!.contains('NOT') ? Colors.green : AppColors.expense).withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      _testResult!,
                      style: TextStyle(
                        color: _testResult!.contains('NOT') ? Colors.greenAccent : AppColors.expense,
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 28),

          SizedBox(
            width: double.infinity,
            height: 54,
            child: ElevatedButton.icon(
              onPressed: _save,
              icon: const Icon(LucideIcons.shieldAlert, size: 18),
              label: Text(_isEditing ? 'Update Block Rule' : 'Save Block Rule', style: const TextStyle(fontWeight: FontWeight.w500)),
              style: ElevatedButton.styleFrom(
                backgroundBuilder: SoftColors.plainBackground,
                backgroundColor: AppColors.expense,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                elevation: 0,
              ),
            ),
          ),
        ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _matchChip(String label, BlockMatchType type) {
    final selected = _matchType == type;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _matchType = type),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: selected ? AppColors.expense.withValues(alpha: 0.15) : AppSurface.card,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: selected ? AppColors.expense : AppSurface.border),
          ),
          alignment: Alignment.center,
          child: Text(
            label,
            style: TextStyle(
              color: selected ? AppColors.expense : AppSurface.subText,
              fontWeight: FontWeight.w500,
              fontSize: 13,
            ),
          ),
        ),
      ),
    );
  }
}