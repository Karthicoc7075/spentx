import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../../../core/theme/soft_palette.dart';
import '../providers/sms_rule_provider.dart';
import 'widgets/sms_rule_card.dart';
import 'sms_raw_message_screen.dart';

class SmsRuleListScreen extends ConsumerWidget {
  const SmsRuleListScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final rules = ref.watch(smsRuleProvider);

    return Scaffold(
      backgroundColor: SoftPalette.bg,
      body: rules.isEmpty 
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    LucideIcons.fileSearch,
                    size: 48,
                    color: SoftPalette.faint.withValues(alpha: 0.45),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'No custom rules found',
                    style: TextStyle(
                      color: SoftPalette.muted,
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              itemCount: rules.length,
              itemBuilder: (context, index) {
                final rule = rules[index];
                return SmsRuleCard(rule: rule);
              },
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(
          context, 
          MaterialPageRoute(builder: (_) => const SmsRawMessageScreen())
        ),
        backgroundColor: SoftPalette.emerald,
        foregroundColor: SoftPalette.onEmerald,
        icon: const Icon(LucideIcons.plus, size: 18),
        label: const Text('Add From SMS History', style: TextStyle(fontWeight: FontWeight.w500)),
      ),
    );
  }
}
