import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/soft_palette.dart';
import '../../../../core/widgets/reference_ui.dart';
import '../../../sms_parser/models/transaction_parsed.dart';
import '../../sms_service.dart';
import 'sms_training_form.dart';
import '../../detected/detection_queue.dart';
import '../../detected/batch_detection_screen.dart';

class SmsRawMessageScreen extends ConsumerStatefulWidget {
  const SmsRawMessageScreen({super.key});
  @override
  ConsumerState<SmsRawMessageScreen> createState() =>
      _SmsRawMessageScreenState();
}

class _SmsRawMessageScreenState extends ConsumerState<SmsRawMessageScreen> {
  List<TransactionParsed> _allMessages = [];
  List<TransactionParsed> _filteredMessages = [];
  String _activeFilter = 'All';
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadInbox();
  }

  Future<void> _loadInbox() async {
    setState(() => _isLoading = true);
    try {
      final messages = await SmsService.readInbox();
      setState(() {
        _allMessages = messages;
        _applyFilter();
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
    }
  }

  void _applyFilter() {
    if (_activeFilter == 'All') {
      _filteredMessages = _allMessages;
    } else {
      final target =
          _activeFilter == 'Debit'
              ? TransactionDirection.expense
              : (_activeFilter == 'Credit'
                  ? TransactionDirection.income
                  : TransactionDirection.transfer);
      _filteredMessages =
          _allMessages.where((m) => m.direction == target).toList();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: SoftPalette.bg,
      appBar: AppBar(
        backgroundColor: SoftPalette.bg,
        elevation: 0,
        leading: SoftCircleIconButton(
          icon: Icons.arrow_back_ios_new_rounded,
          tooltip: 'Back',
          onPressed: () => Navigator.maybePop(context),
        ),
        title: const Text(
          'Real SMS Inbox',
          style: TextStyle(color: SoftPalette.ink, fontWeight: FontWeight.w800),
        ),
        actions: [
          IconButton(
            onPressed: _loadInbox,
            icon: const Icon(LucideIcons.refreshCw, size: 20),
          ),
        ],
      ),
      body: Column(
        children: [
          _buildPendingBanner(),
          _buildFilters(),
          Expanded(
            child:
                _isLoading
                    ? const Center(child: CircularProgressIndicator())
                    : _filteredMessages.isEmpty
                    ? _buildEmptyState()
                    : ListView.builder(
                      padding: const EdgeInsets.all(20),
                      itemCount: _filteredMessages.length,
                      itemBuilder: (context, index) {
                        final msg = _filteredMessages[index];
                        return _buildSmsCard(msg);
                      },
                    ),
          ),
        ],
      ),
    );
  }

  Widget _buildPendingBanner() {
    final pending = ref.watch(detectionQueueProvider);
    if (pending.isEmpty) return const SizedBox.shrink();

    return GestureDetector(
      onTap:
          () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const BatchDetectionScreen()),
          ),
      child: Container(
        margin: const EdgeInsets.fromLTRB(20, 12, 20, 0),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: SoftPalette.emeraldSoft,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: SoftPalette.emerald.withValues(alpha: 0.16),
          ),
        ),
        child: Row(
          children: [
            Icon(LucideIcons.bell, color: SoftPalette.ink, size: 18),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${pending.length} Pending Detections',
                    style: TextStyle(
                      color: SoftPalette.ink,
                      fontWeight: FontWeight.w500,
                      fontSize: 14,
                    ),
                  ),
                  Text(
                    'Verification required for new transactions',
                    style: TextStyle(color: SoftPalette.muted, fontSize: 11),
                  ),
                ],
              ),
            ),
            Icon(LucideIcons.chevronRight, color: SoftPalette.muted, size: 16),
          ],
        ),
      ),
    );
  }

  Widget _buildFilters() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Row(
          children:
              ['All', 'Debit', 'Credit', 'ATM'].map((filter) {
                final isSelected = _activeFilter == filter;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(
                      filter,
                      style: TextStyle(
                        color:
                            isSelected ? Colors.white : SoftPalette.faint,
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    selected: isSelected,
                    onSelected: (val) {
                      setState(() {
                        _activeFilter = filter;
                        _applyFilter();
                      });
                    },
                    backgroundColor: SoftPalette.surfaceVariant,
                    selectedColor: SoftColors.control,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                );
              }).toList(),
        ),
      ),
    );
  }

  Widget _buildSmsCard(TransactionParsed msg) {
    final isDebit = msg.direction == TransactionDirection.expense;
    final isTransfer = msg.direction == TransactionDirection.transfer;
    final color =
        isTransfer
            ? AppColors.upi
            : (isDebit ? AppColors.expense : AppColors.income);

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => SmsTrainingForm(sampleSms: msg.rawMessage),
          ),
        );
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: SoftPalette.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: SoftPalette.ink.withValues(alpha: 0.05)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: color.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    msg.bank.toUpperCase(),
                    style: TextStyle(
                      color: color,
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      letterSpacing: 1,
                    ),
                  ),
                ),
                const Spacer(),
                Text(
                  '₹${msg.amount.toInt()}',
                  style: TextStyle(
                    color: color,
                    fontWeight: FontWeight.w500,
                    fontSize: 16,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              msg.rawMessage,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: SoftPalette.ink.withValues(alpha: 0.5),
                fontSize: 12,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Icon(LucideIcons.calendar, size: 12, color: SoftPalette.faint),
                const SizedBox(width: 6),
                Text(
                  msg.dateTime.toString().split(' ').first,
                  style: TextStyle(color: SoftPalette.faint, fontSize: 11),
                ),
                const Spacer(),
                const Text(
                  'TRAIN RULE →',
                  style: TextStyle(
                    color: AppColors.primary,
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(LucideIcons.mailX, size: 48, color: SoftPalette.border),
          const SizedBox(height: 16),
          Text(
            'No messages found for $_activeFilter',
            style: TextStyle(color: SoftPalette.faint),
          ),
        ],
      ),
    );
  }
}
