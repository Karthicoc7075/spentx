import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/soft_palette.dart';
import '../../models/sms_template_rule.dart';
import '../../providers/sms_template_provider.dart';
import '../template_training_screen.dart';

class TemplateRuleCard extends ConsumerWidget {
  final SmsTemplateRule rule;
  const TemplateRuleCard({super.key, required this.rule});

  Color get _typeColor {
    final t = rule.type.toLowerCase();
    final m = rule.mode.toLowerCase();
    if (m == 'atm') return const Color(0xFFFF9500);
    if (m == 'card') return const Color(0xFF5AC8FA);
    if (t == 'credit') return AppColors.income;
    if (t == 'transfer') return const Color(0xFF9C5BF5);
    return AppColors.expense;
  }

  String get _typeLabel {
    final t = rule.type.toLowerCase();
    final m = rule.mode.toLowerCase();
    if (m == 'atm') return 'ATM WITHDRAW';
    if (m == 'card') return 'CARD SPEND';
    if (t == 'credit') return 'CREDIT';
    if (t == 'transfer') return 'TRANSFER';
    return 'DEBIT';
  }

  Color get _modeColor {
    switch (rule.mode.toLowerCase()) {
      case 'upi':
        return AppColors.upi;
      case 'atm':
        return const Color(0xFFFF9500);
      case 'card':
        return const Color(0xFF5AC8FA);
      default:
        return AppSurface.faint;
    }
  }

  String get _modeLabel => rule.mode.toUpperCase();

  String get _accountDisplay {
    final exact = rule.exactTaggedValues;
    final acct =
        exact[TemplateFieldType.accountLast4] ??
        exact[TemplateFieldType.accountNumber] ??
        '';
    if (acct.isEmpty) return '';
    // Show last 4 only
    final digits = acct.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.length >= 4) return '*${digits.substring(digits.length - 4)}';
    if (digits.isNotEmpty) return '*$digits';
    return '';
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final account = _accountDisplay;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: AppSurface.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _typeColor.withValues(alpha: 0.1)),
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap:
              () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder:
                      (_) => TemplateTrainingScreen(
                        sampleSms: rule.sampleMessage,
                        existingRule: rule,
                      ),
                ),
              ).then((_) {
                ref.read(smsTemplateRuleProvider.notifier).refresh();
              }),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ── ROW 1: Bank Name + Type Badge ──
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        (rule.bankNameExact.isNotEmpty
                                ? rule.bankNameExact
                                : (rule.bankName.isNotEmpty
                                    ? rule.bankName
                                    : 'Unknown Bank'))
                            .toUpperCase(),
                        style: TextStyle(
                          color: AppSurface.text,
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                          letterSpacing: 0.5,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: 12),
                    _typeBadge(_typeLabel, _typeColor),
                  ],
                ),
                const SizedBox(height: 10),

                // ── ROW 2: Mode Badge + Account ──
                Row(
                  children: [
                    if (rule.mode != 'unknown') ...[
                      _modeBadge(_modeLabel, _modeColor),
                      const SizedBox(width: 8),
                    ],
                    if (account.isNotEmpty) ...[
                      if (rule.mode != 'unknown')
                        Text(
                          '•',
                          style: TextStyle(
                            color: AppSurface.text.withValues(alpha: 0.2),
                            fontSize: 12,
                          ),
                        ),
                      if (rule.mode != 'unknown') const SizedBox(width: 8),
                      Text(
                        account,
                        style: TextStyle(
                          color: AppSurface.text.withValues(alpha: 0.5),
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                          fontFamily: 'monospace',
                        ),
                      ),
                    ],
                    const Spacer(),
                    // Threshold indicator
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: AppSurface.text.withValues(alpha: 0.04),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        '${(rule.similarityThreshold * 100).toInt()}%',
                        style: TextStyle(
                          color: AppSurface.text.withValues(alpha: 0.3),
                          fontSize: 11,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                // ── ROW 3: Sample Message Preview ──
                Text(
                  rule.sampleMessage,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: AppSurface.text.withValues(alpha: 0.35),
                    fontSize: 12,
                    height: 1.5,
                  ),
                ),
                const SizedBox(height: 10),

                // ── Match Keywords Wrap ──
                if (rule.keywords.isNotEmpty) ...[
                  Text(
                    'MATCH KEYWORDS',
                    style: TextStyle(
                      color: AppSurface.text.withValues(alpha: 0.2),
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children:
                        rule.keywords
                            .take(6)
                            .map(
                              (kw) => Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 3,
                                ),
                                decoration: BoxDecoration(
                                  color: AppSurface.text.withValues(
                                    alpha: 0.04,
                                  ),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text(
                                  kw,
                                  style: TextStyle(
                                    color: AppSurface.text.withValues(
                                      alpha: 0.4,
                                    ),
                                    fontSize: 11,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            )
                            .toList(),
                  ),
                  const SizedBox(height: 14),
                ] else ...[
                  const SizedBox(height: 4),
                ],

                // ── ROW 4: Actions ──
                Row(
                  children: [
                    // Tagged fields count
                    Icon(
                      LucideIcons.tag,
                      size: 12,
                      color: AppSurface.text.withValues(alpha: 0.2),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      '${rule.extractionMap.length} fields',
                      style: TextStyle(
                        color: AppSurface.text.withValues(alpha: 0.2),
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Icon(
                      LucideIcons.key,
                      size: 12,
                      color: AppSurface.text.withValues(alpha: 0.2),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      '${rule.keywords.length} kw',
                      style: TextStyle(
                        color: AppSurface.text.withValues(alpha: 0.2),
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const Spacer(),
                    // Edit Button
                    _actionBtn(
                      LucideIcons.edit3,
                      AppColors.primary,
                      () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder:
                              (_) => TemplateTrainingScreen(
                                sampleSms: rule.sampleMessage,
                                existingRule: rule,
                              ),
                        ),
                      ).then((_) {
                        ref.read(smsTemplateRuleProvider.notifier).refresh();
                      }),
                    ),
                    const SizedBox(width: 8),
                    // Delete Button
                    _actionBtn(
                      LucideIcons.trash2,
                      AppColors.expense.withValues(alpha: 0.6),
                      () => _confirmDelete(context, ref),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _typeBadge(String label, Color color) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
    decoration: BoxDecoration(
      color: color.withValues(alpha: 0.12),
      borderRadius: BorderRadius.circular(8),
    ),
    child: Text(
      label,
      style: TextStyle(
        color: color,
        fontSize: 11,
        fontWeight: FontWeight.w500,
        letterSpacing: 0.5,
      ),
    ),
  );

  Widget _modeBadge(String label, Color color) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
    decoration: BoxDecoration(
      color: color.withValues(alpha: 0.1),
      borderRadius: BorderRadius.circular(6),
      border: Border.all(color: color.withValues(alpha: 0.15)),
    ),
    child: Text(
      label,
      style: TextStyle(
        color: color,
        fontSize: 11,
        fontWeight: FontWeight.w500,
        letterSpacing: 0.3,
      ),
    ),
  );

  Widget _actionBtn(IconData icon, Color color, VoidCallback onTap) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(8),
    child: Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Icon(icon, size: 15, color: color),
    ),
  );

  void _confirmDelete(BuildContext context, WidgetRef ref) {
    showDialog(
      context: context,
      builder:
          (ctx) => AlertDialog(
            backgroundColor: SoftPalette.card,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24),
            ),
            title: Text(
              'Delete Template',
              style: TextStyle(
                color: SoftPalette.ink,
                fontWeight: FontWeight.w600,
                fontSize: 18,
              ),
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Remove the ${rule.bankName} template rule?',
                  style: TextStyle(color: SoftPalette.muted, fontSize: 14),
                ),
                const SizedBox(height: 12),
                Text(
                  'Future SMS with this format will no longer be auto-detected.',
                  style: TextStyle(color: SoftPalette.faint, fontSize: 12),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text(
                  'Cancel',
                  style: TextStyle(color: SoftPalette.muted),
                ),
              ),
              ElevatedButton(
                onPressed: () {
                  ref
                      .read(smsTemplateRuleProvider.notifier)
                      .deleteRule(rule.id);
                  Navigator.pop(ctx);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: SoftColors.control,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                child: const Text(
                  'Delete',
                  style: TextStyle(fontWeight: FontWeight.w500),
                ),
              ),
            ],
          ),
    );
  }
}
