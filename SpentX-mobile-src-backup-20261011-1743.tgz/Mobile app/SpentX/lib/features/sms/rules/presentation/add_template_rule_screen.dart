import 'package:flutter/material.dart';
import '../../../../core/theme/spentx_tokens.dart';
import '../../../../core/theme/soft_palette.dart';
import '../../../../core/widgets/reference_ui.dart';
import 'package:flutter/services.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../core/theme/app_colors.dart';
import 'sms_training_form.dart';
import 'template_training_screen.dart';
import 'widgets/sms_rule_flow_widgets.dart';

enum TemplateAddMethod { visualTagging, quickAutoDetect }

class AddTemplateRuleScreen extends StatefulWidget {
  final String? initialSms;

  const AddTemplateRuleScreen({super.key, this.initialSms});

  @override
  State<AddTemplateRuleScreen> createState() => _AddTemplateRuleScreenState();
}

class _AddTemplateRuleScreenState extends State<AddTemplateRuleScreen> {
  final _smsCtrl = TextEditingController();
  TemplateAddMethod _method = TemplateAddMethod.visualTagging;

  @override
  void initState() {
    super.initState();
    if (widget.initialSms != null && widget.initialSms!.trim().isNotEmpty) {
      _smsCtrl.text = widget.initialSms!.trim();
    }
  }

  @override
  void dispose() {
    _smsCtrl.dispose();
    super.dispose();
  }

  Future<void> _pasteFromClipboard() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    final text = data?.text?.trim() ?? '';
    if (text.isEmpty) return;
    setState(() => _smsCtrl.text = text);
  }

  void _continue() {
    final text = _smsCtrl.text.trim();
    if (text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Paste a bank SMS first'),
          backgroundColor: AppColors.expense,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    final nextScreen =
        _method == TemplateAddMethod.visualTagging
            ? TemplateTrainingScreen(sampleSms: text)
            : SmsTrainingForm(sampleSms: text, isManual: true);

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => nextScreen),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: SoftPalette.bg,
      appBar: AppBar(
        backgroundColor: SoftPalette.bg,
        elevation: 0,
        leading: SoftCircleIconButton(
          icon: Icons.arrow_back_ios_new_rounded,
          tooltip: 'Back',
          onPressed: () => Navigator.maybePop(context),
        ),
        title: const Text(
          'Add Template Rule',
          style: TextStyle(color: SoftPalette.ink, fontWeight: FontWeight.w800),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
        children: [
          const SmsRuleStepHeader(
            currentStep: 0,
            steps: ['Paste SMS', 'Tag Fields', 'Save Rule'],
          ),
          const SizedBox(height: 24),

          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppColors.primary.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: AppColors.primary.withValues(alpha: 0.15),
              ),
            ),
            child: Text(
              'Train the parser on one real SMS from your bank. Future messages with the same structure will auto-detect amount, title, and account.',
              style: TextStyle(
                color: SoftPalette.muted,
                fontSize: 12,
                height: 1.45,
              ),
            ),
          ),
          const SizedBox(height: 24),

          const SmsRuleSectionLabel(
            label: 'CHOOSE METHOD',
            hint:
                'Visual tagging is recommended — tap each part of the SMS to label it.',
          ),
          SmsRuleMethodTile(
            icon: LucideIcons.layers,
            color: AppColors.primary,
            title: 'Visual Tagging',
            subtitle: 'Highlight SMS parts → assign Amount, Title, Bank, etc.',
            selected: _method == TemplateAddMethod.visualTagging,
            onTap:
                () => setState(() => _method = TemplateAddMethod.visualTagging),
          ),
          const SizedBox(height: 10),
          SmsRuleMethodTile(
            icon: LucideIcons.zap,
            color: AppColors.upi,
            title: 'Quick Auto Detect',
            subtitle: 'Parser auto-fills regex fields — for advanced users',
            selected: _method == TemplateAddMethod.quickAutoDetect,
            onTap:
                () =>
                    setState(() => _method = TemplateAddMethod.quickAutoDetect),
          ),
          const SizedBox(height: 28),

          const SmsRuleSectionLabel(
            label: 'PASTE BANK SMS',
            hint:
                'Use a real debit/credit/UPI SMS from the bank you want to support.',
          ),
          SmsRuleCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextField(
                  controller: _smsCtrl,
                  maxLines: 8,
                  style: TextStyle(
                    color: SoftPalette.ink,
                    fontSize: 13,
                    fontFamily: 'monospace',
                    height: 1.45,
                  ),
                  decoration: InputDecoration(
                    hintText:
                        'Rs.500.00 debited from A/c *1234 on 07-06-26 to MERCHANT via UPI...',
                    hintStyle: TextStyle(
                      color: SoftPalette.ink.withValues(alpha: 0.15),
                      fontSize: 12,
                    ),
                    filled: true,
                    fillColor: context.tokens.field,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: _pasteFromClipboard,
                  icon: const Icon(LucideIcons.clipboardPaste, size: 16),
                  label: const Text('Paste from Clipboard'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: SoftPalette.muted,
                    side: BorderSide(
                      color: SoftPalette.ink.withValues(alpha: 0.12),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 28),

          SizedBox(
            width: double.infinity,
            height: 54,
            child: ElevatedButton.icon(
              onPressed: _continue,
              icon: Icon(
                _method == TemplateAddMethod.visualTagging
                    ? LucideIcons.tag
                    : LucideIcons.arrowRight,
                size: 18,
              ),
              label: Text(
                _method == TemplateAddMethod.visualTagging
                    ? 'Continue to Tag Fields'
                    : 'Continue to Auto Detect',
                style: const TextStyle(fontWeight: FontWeight.w500),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: SoftColors.control,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                elevation: 0,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
