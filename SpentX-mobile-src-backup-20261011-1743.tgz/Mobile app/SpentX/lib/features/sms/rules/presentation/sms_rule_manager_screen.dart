import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../../../core/theme/soft_palette.dart';
import '../../../../core/widgets/reference_ui.dart';
import '../models/block_rule.dart';
import 'add_template_rule_screen.dart';
import 'block_sms_screen.dart';
import '../providers/sms_rule_provider.dart';
import '../providers/sms_template_provider.dart';
import 'widgets/sms_rule_card.dart';
import 'widgets/template_rule_card.dart';
import '../../../../core/theme/spentx_tokens.dart';

class SmsRuleManagerScreen extends ConsumerStatefulWidget {
  const SmsRuleManagerScreen({super.key});
  @override
  ConsumerState<SmsRuleManagerScreen> createState() =>
      _SmsRuleManagerScreenState();
}

class _SmsRuleManagerScreenState extends ConsumerState<SmsRuleManagerScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _refreshAllRules());
  }

  void _refreshAllRules() {
    ref.read(smsTemplateRuleProvider.notifier).refresh();
    ref.read(smsRuleProvider.notifier).refresh();
    ref.read(blockRuleProvider.notifier).refresh();
  }

  Future<T?> _openRuleScreen<T>(Widget screen) {
    return Navigator.push<T>(
      context,
      MaterialPageRoute(builder: (_) => screen),
    ).then((value) {
      _refreshAllRules();
      return value;
    });
  }

  @override
  Widget build(BuildContext context) {
    final templateRules = ref.watch(smsTemplateRuleProvider);
    final regexRules = ref.watch(smsRuleProvider);
    final blockRules = ref.watch(blockRuleProvider);

    return Scaffold(
      backgroundColor: SoftPalette.bg,
      appBar: AppBar(
        backgroundColor: SoftPalette.bg,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        leadingWidth: 56,
        leading: Padding(
          padding: const EdgeInsets.only(left: 8),
          child: Center(
            child: SoftCircleIconButton(
              icon: Icons.arrow_back_ios_new_rounded,
              tooltip: 'Back',
              onPressed: () => Navigator.maybePop(context),
            ),
          ),
        ),
        title: Text(
          'SMS Detection Rules',
          style: AppType.section(SoftPalette.ink),
        ),
      ),
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(
            child: _buildStatsRow(
              templateRules.length,
              blockRules.length,
              regexRules.length,
            ),
          ),
          SliverToBoxAdapter(child: _buildPrimaryActions()),
          SliverToBoxAdapter(
            child: _buildSectionHeader(
              'Template Rules',
              templateRules.length,
              LucideIcons.layers,
            ),
          ),
          if (templateRules.isEmpty)
            SliverToBoxAdapter(
              child: _buildEmptyState(
                'No template rules yet',
                'Add one from a real bank SMS',
                LucideIcons.layers,
              ),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate(
                  (_, i) => TemplateRuleCard(rule: templateRules[i]),
                  childCount: templateRules.length,
                ),
              ),
            ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.only(top: 16),
              child: _buildSectionHeader(
                'Blocked Messages',
                blockRules.length,
                LucideIcons.shieldAlert,
              ),
            ),
          ),
          if (blockRules.isEmpty)
            SliverToBoxAdapter(
              child: _buildEmptyState(
                'No blocked SMS types',
                'Block promos, OTPs, and spam',
                LucideIcons.shieldCheck,
              ),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate(
                  (_, i) => _buildBlockCard(blockRules[i]),
                  childCount: blockRules.length,
                ),
              ),
            ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.only(top: 16),
              child: _buildSectionHeader(
                'Regex Rules (Advanced)',
                regexRules.length,
                LucideIcons.fileSearch,
              ),
            ),
          ),
          if (regexRules.isEmpty)
            SliverToBoxAdapter(
              child: _buildEmptyState(
                'No regex rules',
                'Created via Quick Auto Detect',
                LucideIcons.fileSearch,
              ),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate(
                  (_, i) => SmsRuleCard(rule: regexRules[i]),
                  childCount: regexRules.length,
                ),
              ),
            ),
          const SliverToBoxAdapter(child: SizedBox(height: 40)),
        ],
      ),
    );
  }

  Widget _buildStatsRow(int templates, int blocks, int regex) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
      child: Row(
        children: [
          _statChip('$templates', 'Templates', SoftPalette.emerald),
          const SizedBox(width: 10),
          _statChip('$blocks', 'Blocked', SoftPalette.muted),
          const SizedBox(width: 10),
          _statChip('$regex', 'Regex', SoftPalette.mintDark),
        ],
      ),
    );
  }

  Widget _statChip(String count, String label, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: color.withValues(alpha: 0.12)),
          boxShadow: const [
            BoxShadow(
              color: Color(0x080F172A),
              blurRadius: 16,
              offset: Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          children: [
            Text(
              count,
              style: TextStyle(
                color: color,
                fontSize: 20,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(
                color: SoftPalette.ink.withValues(alpha: 0.4),
                fontSize: 11,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPrimaryActions() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
      child: Column(
        children: [
          _buildActionCard(
            title: 'Add Template Rule',
            subtitle: 'Paste SMS → tag Amount, Title, Bank → save',
            icon: LucideIcons.plusCircle,
            color: SoftPalette.emerald,
            onTap: () => _openRuleScreen(const AddTemplateRuleScreen()),
          ),
          const SizedBox(height: 12),
          _buildActionCard(
            title: 'Block SMS',
            subtitle: 'Block promos, OTPs, loans — test before saving',
            icon: LucideIcons.shieldAlert,
            color: SoftPalette.muted,
            onTap: () => _openRuleScreen(const BlockSmsScreen()),
          ),
          const SizedBox(height: 12),
          _buildActionCard(
            title: 'SMS Detection Lab',
            subtitle: 'Full pipeline test — paste, detect, simulate',
            icon: LucideIcons.beaker,
            color: SoftPalette.mintDark,
            onTap: () => context.push('/sms-detection-lab'),
            trailing: LucideIcons.externalLink,
          ),
        ],
      ),
    );
  }

  Widget _buildActionCard({
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
    IconData trailing = LucideIcons.chevronRight,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(24),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: SoftPalette.card,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: SoftPalette.border),
          boxShadow: const [
            BoxShadow(
              color: Color(0x080F172A),
              blurRadius: 16,
              offset: Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 20),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: color,
                      fontWeight: FontWeight.w500,
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: SoftPalette.ink.withValues(alpha: 0.4),
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
            Icon(trailing, color: color.withValues(alpha: 0.6), size: 18),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title, int count, IconData icon) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
      child: Row(
        children: [
          Icon(icon, size: 14, color: SoftPalette.faint),
          const SizedBox(width: 8),
          Text(
            title.toUpperCase(),
            style: TextStyle(
              color: SoftPalette.faint,
              fontSize: 11,
              fontWeight: FontWeight.w500,
              letterSpacing: 1.5,
            ),
          ),
          if (count > 0) ...[
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: SoftPalette.emerald.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                '$count',
                style: const TextStyle(
                  color: SoftPalette.emerald,
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildEmptyState(String title, String subtitle, IconData icon) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 20),
      child: Column(
        children: [
          Icon(icon, size: 28, color: SoftPalette.border),
          const SizedBox(height: 10),
          Text(
            title,
            style: TextStyle(
              color: SoftPalette.faint,
              fontSize: 13,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: TextStyle(color: SoftPalette.border, fontSize: 11),
          ),
        ],
      ),
    );
  }

  Widget _buildBlockCard(BlockRule rule) {
    final isRegex = rule.pattern != null && rule.pattern!.isNotEmpty;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: SoftPalette.card,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: SoftPalette.muted.withValues(alpha: 0.1)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x080F172A),
            blurRadius: 16,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(24),
        child: InkWell(
          borderRadius: BorderRadius.circular(24),
          onTap: () => _openRuleScreen(BlockSmsScreen(existingRule: rule)),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: SoftPalette.muted.withValues(alpha: 0.1),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    LucideIcons.shieldOff,
                    color: SoftPalette.muted,
                    size: 16,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Flexible(
                            child: Text(
                              rule.displayName,
                              style: TextStyle(
                                color: SoftPalette.ink,
                                fontWeight: FontWeight.w500,
                                fontSize: 14,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 6,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: (isRegex
                                      ? SoftPalette.muted
                                      : SoftPalette.muted)
                                  .withValues(alpha: 0.12),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              isRegex ? 'REGEX' : 'CONTAINS',
                              style: TextStyle(
                                color:
                                    isRegex
                                        ? SoftPalette.muted
                                        : SoftPalette.muted,
                                fontSize: 11,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(
                        '${rule.keywords.length} keywords • ${(rule.similarityThreshold * 100).toInt()}% threshold',
                        style: TextStyle(
                          color: SoftPalette.ink.withValues(alpha: 0.35),
                          fontSize: 11,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        rule.sampleMessage,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: SoftPalette.faint,
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  icon: Icon(
                    LucideIcons.trash2,
                    color: SoftPalette.border,
                    size: 18,
                  ),
                  onPressed:
                      () => ref
                          .read(blockRuleProvider.notifier)
                          .deleteRule(rule.id),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
