import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/soft_palette.dart';
import '../../models/sms_rule.dart';
import '../../providers/sms_rule_provider.dart';
import '../sms_training_form.dart';

class SmsRuleCard extends ConsumerWidget {
  final SmsRule rule;
  const SmsRuleCard({super.key, required this.rule});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: SoftPalette.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: SoftPalette.border),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap:
                () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => SmsTrainingForm(rule: rule),
                  ),
                ),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: SoftPalette.emerald.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          rule.bankName.toUpperCase(),
                          style: TextStyle(
                            color: SoftPalette.emerald,
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ),
                      if (rule.isManual) ...[
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: AppColors.upi.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            'MANUAL',
                            style: TextStyle(
                              color: AppColors.upi,
                              fontSize: 11,
                              fontWeight: FontWeight.w500,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ),
                      ],
                      const Spacer(),
                      _buildMiniBadge(
                        rule.type,
                        rule.type == 'Debit'
                            ? SoftPalette.negative
                            : SoftPalette.positive,
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    rule.sampleMessage,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: SoftPalette.muted,
                      fontSize: 12,
                      height: 1.4,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      _buildInfoTag(LucideIcons.zap, rule.mode),
                      const SizedBox(width: 12),
                      _buildInfoTag(
                        LucideIcons.key,
                        '${rule.containsKeywords.length} Keywords',
                      ),
                      const Spacer(),
                      IconButton(
                        visualDensity: VisualDensity.compact,
                        icon: Icon(
                          LucideIcons.trash2,
                          size: 18,
                          color: AppSurface.border,
                        ),
                        onPressed: () => _confirmDelete(context, ref, rule.id),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildMiniBadge(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(
        label.toUpperCase(),
        style: TextStyle(
          color: color,
          fontSize: 11,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  Widget _buildInfoTag(IconData icon, String label) {
    return Row(
      children: [
        Icon(icon, size: 12, color: SoftPalette.muted),
        const SizedBox(width: 6),
        Text(
          label,
          style: TextStyle(
            color: SoftPalette.muted,
            fontSize: 11,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  void _confirmDelete(BuildContext context, WidgetRef ref, String id) {
    showDialog(
      context: context,
      builder:
          (ctx) => AlertDialog(
            backgroundColor: SoftPalette.card,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24),
            ),
            title: Text(
              'Delete Rule',
              style: TextStyle(
                color: SoftPalette.ink,
                fontWeight: FontWeight.w600,
              ),
            ),
            content: Text(
              'Are you sure you want to remove this parsing rule?',
              style: TextStyle(color: SoftPalette.muted),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text(
                  'Cancel',
                  style: TextStyle(color: SoftPalette.muted),
                ),
              ),
              ElevatedButton(
                onPressed: () {
                  ref.read(smsRuleProvider.notifier).deleteRule(id);
                  Navigator.pop(ctx);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: SoftColors.control,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                child: const Text('Delete'),
              ),
            ],
          ),
    );
  }
}
