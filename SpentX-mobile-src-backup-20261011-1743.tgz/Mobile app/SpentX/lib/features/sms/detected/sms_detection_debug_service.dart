import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/providers/transaction_provider.dart' as model;
import '../../../core/widgets/premium_bottom_sheet.dart';
import 'detection_popup.dart';
import 'detection_queue.dart';
import 'auto_rule_engine.dart';
import 'detected_sms_storage.dart';
import 'sms_detection_pipeline.dart';
import 'sms_lab_simulator.dart';

class SmsDetectionDebugService {
  /// Live path — same [SmsDetectionPipeline] as real incoming SMS.
  static Future<void> triggerLiveForegroundSave(
    BuildContext context,
    WidgetRef ref,
    String smsBody,
  ) async {
    if (!SmsDetectionPipeline.isAutoDetectionEnabled) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(SmsLabSimulator.autoDetectionOffMessage),
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
      return;
    }

    SmsDetectionPipeline.bindForeground(ref: ref, context: context);
    await SmsDetectionPipeline.processInbound(
      rawMessage: smsBody,
      source: SmsDetectionSource.debug,
    );
    ref.invalidate(model.transactionProvider);
    ref.read(detectionQueueProvider.notifier).refresh();
  }

  static Future<void> triggerLatestPendingClick(
    BuildContext context,
    WidgetRef ref,
  ) async {
    final queue = ref.read(detectionQueueProvider);
    if (queue.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('No pending transactions in the queue to verify.'),
          backgroundColor: Colors.orangeAccent,
        ),
      );
      return;
    }

    final latestId = queue.first;
    final pending = DetectedSmsStorage.get(latestId);
    if (pending != null) {
      await PremiumBottomSheet.show(
        context: context,
        child: DetectionPopup(
          pendingTx: AutoRuleEngine.pendingToTransaction(pending),
        ),
      );
      return;
    }

    final transactions = ref.read(model.transactionProvider);
    try {
      final tx = transactions.firstWhere((t) => t.id == latestId);
      await PremiumBottomSheet.show(
        context: context,
        child: DetectionPopup(pendingTx: tx),
      );
    } catch (_) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: Transaction $latestId not found in local DB.'),
          backgroundColor: Colors.redAccent,
        ),
      );
    }
  }

  static Future<void> testPopupQueue(
    BuildContext context,
    WidgetRef ref,
  ) async {
    final queue = ref.read(detectionQueueProvider);
    if (queue.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Pending queue is empty. Cannot test sequential popups.',
          ),
          backgroundColor: Colors.blueGrey,
        ),
      );
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Processing ${queue.length} items in the verification wizard...',
        ),
        backgroundColor: const Color(0xFF57BE93),
      ),
    );

    await triggerLatestPendingClick(context, ref);
  }
}
