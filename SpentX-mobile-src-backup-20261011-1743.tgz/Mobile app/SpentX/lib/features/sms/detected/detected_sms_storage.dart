import 'package:hive_flutter/hive_flutter.dart';
import 'pending_model.dart';
import '../../../data/local/hive_service.dart';

/// Holds unverified bank SMS detections until the user confirms in-app.
class DetectedSmsStorage {
  static const String boxName = 'detected_sms_box';

  static Box get _box => Hive.box(boxName);

  static Future<void> ensureOpen() async {
    if (!Hive.isBoxOpen(boxName)) {
      await SecureHive.openBox(boxName);
    }
  }

  static void save(PendingTransaction pending) {
    _box.put(pending.id, pending.toJson());
  }

  static PendingTransaction? get(String id) {
    final raw = _box.get(id);
    if (raw == null) return null;
    return PendingTransaction.fromJson(Map<dynamic, dynamic>.from(raw));
  }

  static void remove(String id) {
    _box.delete(id);
  }

  static void markNotificationShown(String id) {
    final p = get(id);
    if (p == null) return;
    save(PendingTransaction(
      id: p.id,
      amount: p.amount,
      receiver: p.receiver,
      bank: p.bank,
      date: p.date,
      rawMessage: p.rawMessage,
      isExpense: p.isExpense,
      isTransfer: p.isTransfer,
      accountLast4: p.accountLast4,
      referenceId: p.referenceId,
      upiId: p.upiId,
      outingId: p.outingId,
      isAutoLinked: p.isAutoLinked,
      notificationShown: true,
      popupOpened: p.popupOpened,
      savedTitle: p.savedTitle,
      savedCategory: p.savedCategory,
      savedPurpose: p.savedPurpose,
      deferAutoAdd: p.deferAutoAdd,
    ));
  }

  static void markPopupOpened(String id) {
    final p = get(id);
    if (p == null) return;
    save(PendingTransaction(
      id: p.id,
      amount: p.amount,
      receiver: p.receiver,
      bank: p.bank,
      date: p.date,
      rawMessage: p.rawMessage,
      isExpense: p.isExpense,
      isTransfer: p.isTransfer,
      accountLast4: p.accountLast4,
      referenceId: p.referenceId,
      upiId: p.upiId,
      outingId: p.outingId,
      isAutoLinked: p.isAutoLinked,
      notificationShown: p.notificationShown,
      popupOpened: true,
      savedTitle: p.savedTitle,
      savedCategory: p.savedCategory,
      savedPurpose: p.savedPurpose,
      deferAutoAdd: p.deferAutoAdd,
    ));
  }

  static List<PendingTransaction> getAll() {
    return _box.values
        .map((e) => PendingTransaction.fromJson(Map<dynamic, dynamic>.from(e)))
        .toList();
  }

  /// Keeps pending_detections queue in sync with stored pending records.
  static void reconcilePendingQueue() {
    if (!Hive.isBoxOpen('pending_detections')) return;
    final qbox = Hive.box('pending_detections');
    final queue = List<String>.from(qbox.get('queue', defaultValue: const <dynamic>[]));
    var changed = false;
    for (final pending in getAll()) {
      if (!queue.contains(pending.id)) {
        queue.add(pending.id);
        changed = true;
      }
    }
    if (changed) {
      qbox.put('queue', queue);
    }
  }
}