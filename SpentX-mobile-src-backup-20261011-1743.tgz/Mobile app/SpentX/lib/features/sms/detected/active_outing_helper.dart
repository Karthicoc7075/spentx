import 'package:hive_flutter/hive_flutter.dart';

import '../../../core/utils/outing_link_rules.dart';

/// Active trip context used when auto-linking SMS transactions.
class ActiveOutingLink {
  final String id;
  final String title;
  final bool isAutoMode;

  const ActiveOutingLink({
    required this.id,
    required this.title,
    required this.isAutoMode,
  });
}

/// Resolves the single active outing from Hive (if any).
class ActiveOutingHelper {
  /// Returns active trip with auto-link on when [transactionDate] falls within trip dates.
  ///
  /// Eligibility is [outingAcceptsDetection]'s call, not this method's: only a
  /// plain expense is ever auto-added, so income and transfers (ATM withdrawal
  /// / cash deposit) resolve to no trip however the caller asks. Pass
  /// [isTransfer] so that holds even when a caller reports a transfer as a
  /// debit. Set [forceLinkForCredit] to attach friend repayment credits to the
  /// outing even though !isExpense — that is the one credit a trip may carry,
  /// and it nets against the trip's cost rather than adding to it.
  static ActiveOutingLink? resolve({
    required bool isExpense,
    bool isTransfer = false,
    DateTime? transactionDate,
    bool forceLinkForCredit = false,
  }) {
    if (!outingAcceptsDetection(
      isExpense: isExpense,
      isTransfer: isTransfer,
      isFriendReturn: forceLinkForCredit,
    )) {
      return null;
    }
    final date = transactionDate ?? DateTime.now();

    try {
      final box = Hive.box('outings');

      for (final key in box.keys) {
        if (key == 'list') continue;
        final val = box.get(key);
        if (val is! Map) continue;
        final link = _fromMap(val, date);
        if (link != null) return link;
      }

      final legacy = box.get('list');
      if (legacy is List) {
        for (final val in legacy) {
          if (val is! Map) continue;
          final link = _fromMap(val, date);
          if (link != null) return link;
        }
      }
    } catch (_) {}

    return null;
  }

  static bool _isWithinTripDates(Map<dynamic, dynamic> map, DateTime date) {
    try {
      final start = DateTime.parse(map['startDate']?.toString() ?? '');
      final end = DateTime.parse(map['endDate']?.toString() ?? '');
      final startDay = DateTime(start.year, start.month, start.day);
      final endDay = DateTime(end.year, end.month, end.day, 23, 59, 59);
      return !date.isBefore(startDay) && !date.isAfter(endDay);
    } catch (_) {
      return true;
    }
  }

  static ActiveOutingLink? _fromMap(Map<dynamic, dynamic> map, DateTime date) {
    final isActive = map['isActive'] ?? false;
    if (isActive != true) return null;

    // Per-outing "auto-add mode" removed — SMS auto-detect is a global
    // mobile setting. Active trips in date range can receive linked spends.
    if (!_isWithinTripDates(map, date)) return null;

    final id = map['id']?.toString();
    if (id == null || id.isEmpty) return null;

    final title = (map['title'] ?? map['name'] ?? 'Trip').toString();
    final isAutoMode = map['isAutoMode'] != false;
    return ActiveOutingLink(id: id, title: title, isAutoMode: isAutoMode);
  }

  static String? titleForId(String? outingId) {
    if (outingId == null) return null;
    try {
      final box = Hive.box('outings');
      final val = box.get(outingId);
      if (val is Map) {
        return (val['title'] ?? val['name'])?.toString();
      }
      final legacy = box.get('list');
      if (legacy is List) {
        for (final item in legacy) {
          if (item is Map && item['id']?.toString() == outingId) {
            return (item['title'] ?? item['name'])?.toString();
          }
        }
      }
    } catch (_) {}
    return null;
  }
}
