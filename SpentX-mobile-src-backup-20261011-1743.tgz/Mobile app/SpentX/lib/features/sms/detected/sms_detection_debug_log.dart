import '../../../core/debug/master_debug_log.dart';
import '../../../core/debug/master_debug_module.dart';

/// Legacy SMS debug log API — delegates to [MasterDebugLog] when enabled.
/// When master logging is OFF: no writes, no storage usage.
class SmsDetectionDebugLog {
  static const boxName = 'sms_detection_debug_log';
  static const maxEntries = 200;

  static Future<void> ensureOpen() async {
    if (MasterDebugLog.isEnabled) {
      await MasterDebugLog.ensureOpen();
    }
  }

  static Future<void> log({
    required String message,
    required SmsDebugLogLevel level,
    String? rawSmsPreview,
    String? source,
    String? detail,
  }) async {
    if (!MasterDebugLog.isEnabled) return;

    final masterLevel = switch (level) {
      SmsDebugLogLevel.success => MasterDebugLevel.success,
      SmsDebugLogLevel.warning => MasterDebugLevel.warning,
      SmsDebugLogLevel.error => MasterDebugLevel.error,
      SmsDebugLogLevel.info => MasterDebugLevel.info,
    };

    await MasterDebugLog.log(
      level: masterLevel,
      module: _moduleForMessage(message),
      title: message,
      message: detail,
      data: {
        if (source != null) 'source': source,
        // Never store the SMS body. Length only, so a debug log cannot be read back.
        if (rawSmsPreview != null && rawSmsPreview.isNotEmpty)
          'preview': 'redacted (${rawSmsPreview.length} chars)',
      },
    );
  }

  static MasterDebugModule _moduleForMessage(String message) {
    final m = message.toLowerCase();
    if (m.contains('merchant')) return MasterDebugModule.merchant;
    if (m.contains('rule') || m.contains('template') || m.contains('block')) {
      return MasterDebugModule.ruleEngine;
    }
    if (m.contains('notification')) return MasterDebugModule.notification;
    if (m.contains('queue') || m.contains('pending') || m.contains('verify')) {
      return MasterDebugModule.queue;
    }
    if (m.contains('duplicate')) return MasterDebugModule.transactions;
    return MasterDebugModule.sms;
  }

  static List<SmsDebugLogEntry> readAll() {
    if (!MasterDebugLog.isEnabled) return [];
    final modules = {
      MasterDebugModule.sms,
      MasterDebugModule.ruleEngine,
      MasterDebugModule.merchant,
      MasterDebugModule.queue,
    };
    return MasterDebugLog.readAll()
        .where((e) => modules.contains(e.module))
        .map(
          (e) => SmsDebugLogEntry(
            time: e.timestamp,
            level: switch (e.level) {
              MasterDebugLevel.success => SmsDebugLogLevel.success,
              MasterDebugLevel.warning => SmsDebugLogLevel.warning,
              MasterDebugLevel.error => SmsDebugLogLevel.error,
              _ => SmsDebugLogLevel.info,
            },
            message: e.title,
            source: e.dataJson,
            detail: e.message.isNotEmpty ? e.message : e.dataJson,
            preview: e.dataJson,
          ),
        )
        .toList();
  }

  static Future<void> clear() async {
    await MasterDebugLog.clear();
  }
}

enum SmsDebugLogLevel { success, info, warning, error }

class SmsDebugLogEntry {
  final DateTime time;
  final SmsDebugLogLevel level;
  final String message;
  final String? source;
  final String? detail;
  final String? preview;

  const SmsDebugLogEntry({
    required this.time,
    required this.level,
    required this.message,
    this.source,
    this.detail,
    this.preview,
  });
}