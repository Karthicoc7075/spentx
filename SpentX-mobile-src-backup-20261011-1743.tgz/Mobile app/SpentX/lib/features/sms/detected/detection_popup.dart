import 'package:flutter/material.dart';
import '../../../core/theme/spentx_tokens.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../core/widgets/reference_ui.dart';
import '../../transactions/presentation/widgets/soft_transaction_widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:intl/intl.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/providers/category_provider.dart';
import '../../../core/providers/contributor_provider.dart';
import '../../../core/providers/merchant_alias_provider.dart';
import '../../../core/providers/merchant_provider.dart';
import '../../../core/providers/outing_provider.dart';
import '../../../core/providers/settlement_feedback_provider.dart';
import '../../../core/providers/transaction_provider.dart'
    show Transaction, TransactionSplitRow, transactionProvider;
import '../../../core/utils/outing_link_rules.dart';
import 'detection_queue.dart';
import 'detected_sms_storage.dart';
import 'active_outing_helper.dart';
import 'pending_model.dart';
import '../../groups/presentation/widgets/outing_unlink_dialog.dart';
import '../../../core/services/friend_credit_handler.dart';
import '../../../core/services/friend_open_claims_service.dart';
import '../../../core/services/friend_repayment_matcher.dart';
import 'sms_atm_helper.dart';
import '../../../core/services/merchant_rule_service.dart';
import '../../../core/services/merchant_identifier_resolver.dart';
import '../v4/merchant_learning_service.dart';

import '../v4/payee_normalizer.dart';
import '../v4/payee_extractor.dart';
import '../../../core/services/pending_verification_history_service.dart';
import '../../sms_parser/sms_direction_helper.dart';
import '../../../data/local/hive_service.dart';

class DetectionPopup extends ConsumerStatefulWidget {
  final Transaction pendingTx;

  const DetectionPopup({super.key, required this.pendingTx});

  @override
  ConsumerState<DetectionPopup> createState() => _DetectionPopupState();
}

const _kAtmPurple = Color(0xFF9C5BF5);

void _noop() {}

class _DetectionPopupState extends ConsumerState<DetectionPopup> {
  String? _selectedPurpose;
  List<String> _purposeTypes = [];
  bool _isLoadingPurposes = true;
  late String _selectedCategory;
  late TextEditingController _amountController;
  late TextEditingController _merchantController;
  bool _initialized = false;
  bool _isRenamed = false;
  late String _rawPayee;
  bool _saveToGlobalDB = true;
  bool _isSmartDetected = false;
  bool _hasMerchantError = false;
  final bool _editingBeforeSave = false;
  bool _showAdvanced = false;
  bool _splitExpense = false;
  bool _splitWithFriends = false;
  bool _pastTransaction = false;
  DateTime? _pastDate;
  // Split expense: what each split row carries (category, purpose or both).
  _SplitBy _splitBy = _SplitBy.category;
  final List<_SplitLine> _splitLines = [];
  String? _splitError;
  final Set<String> _splitFriendNames = {};
  late TextEditingController _descriptionController;
  late TextEditingController _notesController;

  bool _isGenericSourceId(String id) {
    final l = id.toLowerCase().trim();
    const noise = [
      'clearing',
      'credited',
      'deposited',
      'received',
      'balance',
      'avl',
      'unknown',
      'tpt',
      'neft',
      'xx',
      'info',
    ];
    return noise.any((g) => l.contains(g));
  }

  String? _outingId;
  String? _outingTitle;
  bool _isAutoLinked = false;

  bool _linkAsFriend = false;
  String? _linkedFriendName;
  List<String> _friendNames = [];

  /// What the selected friend still owes you — the "Ravi owes you ₹800" list.
  /// Rebuilt whenever the friend selection changes.
  List<FriendOpenClaim> _friendClaims = [];

  /// Which of [_friendClaims] this credit is settling. Only ticked claims are
  /// ever written — the credit amount alone never decides an allocation.
  Set<String> _selectedClaimIds = {};

  double get _creditAmount =>
      double.tryParse(_amountController.text) ?? widget.pendingTx.amount;

  List<FriendOpenClaim> get _tickedClaims =>
      _friendClaims.where((c) => _selectedClaimIds.contains(c.id)).toList();

  /// Amount actually being applied to claims (never more than they're owed).
  double get _settlingAmount => FriendOpenClaimsService.allocate(
    _tickedClaims,
    _creditAmount,
  ).values.fold(0.0, (sum, v) => sum + v);

  /// Received amount left over once the ticked claims are covered.
  double get _extraAmount =>
      FriendOpenClaimsService.unallocated(_tickedClaims, _creditAmount);

  /// Rebuilds the pending list for [friendName] and pre-ticks only an
  /// unambiguous match (see [FriendOpenClaimsService.preselect]).
  void _loadClaimsFor(String friendName) {
    _friendClaims = FriendOpenClaimsService.claimsForFriend(ref, friendName);
    _selectedClaimIds = FriendOpenClaimsService.preselect(
      _friendClaims,
      _creditAmount,
    );
  }

  void _clearClaims() {
    _friendClaims = [];
    _selectedClaimIds = {};
  }

  /// The pending list for the selected friend. Ticking a row is what actually
  /// authorises a settlement — without a tick the credit is just income.
  Widget _buildPendingClaims() {
    final friend = _linkedFriendName;
    if (friend == null) return const SizedBox.shrink();

    if (_friendClaims.isEmpty) {
      return Padding(
        padding: const EdgeInsets.only(top: 12),
        child: Text(
          '$friend has nothing pending — this will be saved as income.',
          style: TextStyle(fontSize: 11, color: context.tokens.textSecondary),
        ),
      );
    }

    final ticked = _tickedClaims;
    final tickedOutstanding = FriendOpenClaimsService.totalOutstanding(ticked);
    final settling = _settlingAmount;
    final extra = _extraAmount;
    final stillPending = tickedOutstanding - settling;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 14),
        Text(
          '$friend owes you ₹${FriendOpenClaimsService.totalOutstanding(_friendClaims).toStringAsFixed(0)}',
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: context.tokens.textPrimary,
          ),
        ),
        const SizedBox(height: 4),
        for (final claim in _friendClaims)
          InkWell(
            onTap:
                () => setState(() {
                  if (!_selectedClaimIds.remove(claim.id)) {
                    _selectedClaimIds.add(claim.id);
                  }
                }),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 2),
              child: Row(
                children: [
                  SizedBox(
                    width: 28,
                    height: 28,
                    child: Checkbox(
                      value: _selectedClaimIds.contains(claim.id),
                      activeColor: SoftColors.control,
                      visualDensity: VisualDensity.compact,
                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      onChanged:
                          (v) => setState(() {
                            if (v == true) {
                              _selectedClaimIds.add(claim.id);
                            } else {
                              _selectedClaimIds.remove(claim.id);
                            }
                          }),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      claim.referenceName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 12,
                        color: context.tokens.textPrimary,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    '₹${claim.outstanding.toStringAsFixed(0)}',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: context.tokens.textPrimary,
                    ),
                  ),
                  if ((claim.outstanding - _creditAmount).abs() <=
                      FriendOpenClaimsService.matchTolerance) ...[
                    const SizedBox(width: 6),
                    Text(
                      'exact',
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        color: AppColors.income,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        const SizedBox(height: 8),
        Divider(
          height: 1,
          color: context.tokens.textSecondary.withValues(alpha: 0.2),
        ),
        const SizedBox(height: 8),
        Text(
          ticked.isEmpty
              ? 'Nothing selected — saving ₹${_creditAmount.toStringAsFixed(0)} as income'
              : 'Settling ₹${settling.toStringAsFixed(0)} of ₹${_creditAmount.toStringAsFixed(0)} received',
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color:
                ticked.isEmpty
                    ? context.tokens.textSecondary
                    : AppColors.income,
          ),
        ),
        if (stillPending > 0.01)
          Padding(
            padding: const EdgeInsets.only(top: 2),
            child: Text(
              'Partial payment — ₹${stillPending.toStringAsFixed(0)} still pending',
              style: TextStyle(
                fontSize: 11,
                color: context.tokens.textSecondary,
              ),
            ),
          ),
        if (extra > 0.01)
          Padding(
            padding: const EdgeInsets.only(top: 2),
            child: Text(
              '₹${extra.toStringAsFixed(0)} extra saved as income',
              style: TextStyle(
                fontSize: 11,
                color: context.tokens.textSecondary,
              ),
            ),
          ),
      ],
    );
  }

  /// Income contributor (default Me) — only for credit / income verify.
  String _selectedContributor = ContributorNotifier.defaultMeName;

  /// ATM withdrawal (Bank -> Cash) vs Cash deposit (Cash -> Bank) — same
  /// isTransfer flag, opposite direction, re-derived from the raw SMS text.
  bool get _isCashDeposit =>
      widget.pendingTx.isTransfer &&
      SmsDirectionHelper.isCashDepositAtSelfMachineSms(
        widget.pendingTx.rawMessage,
      );

  Color get _themeColor {
    if (widget.pendingTx.isTransfer) return _kAtmPurple;
    return widget.pendingTx.isExpense ? AppColors.expense : AppColors.income;
  }

  Color get _buttonColor {
    if (widget.pendingTx.isTransfer) return _kAtmPurple;
    return widget.pendingTx.isExpense ? AppColors.primary : AppColors.income;
  }

  @override
  void initState() {
    super.initState();
    _amountController = TextEditingController(
      text: widget.pendingTx.amount.toStringAsFixed(0),
    );
    _rawPayee =
        PayeeExtractor.extract(widget.pendingTx.rawMessage) ??
        widget.pendingTx.receiver;
    _descriptionController = TextEditingController();
    _notesController = TextEditingController();
    _merchantController = TextEditingController(
      text:
          widget.pendingTx.isTransfer
              ? (_isCashDeposit
                  ? SmsAtmHelper.cashDepositDisplayName
                  : SmsAtmHelper.defaultDisplayName)
              : _rawPayee,
    );

    final outings = ref.read(outingProvider);
    final storedPending = DetectedSmsStorage.get(widget.pendingTx.id);

    if (widget.pendingTx.outingId != null) {
      _outingId = widget.pendingTx.outingId;
      _isAutoLinked = widget.pendingTx.isAutoLinked;
      try {
        _outingTitle = outings.firstWhere((o) => o.id == _outingId).title;
      } catch (_) {
        _outingTitle =
            storedPending != null
                ? ActiveOutingHelper.titleForId(_outingId)
                : null;
      }
    } else if (storedPending?.outingId != null) {
      _outingId = storedPending!.outingId;
      _isAutoLinked = storedPending.isAutoLinked;
      try {
        _outingTitle = outings.firstWhere((o) => o.id == _outingId).title;
      } catch (_) {}
    } else {
      final existingTxs = ref.read(transactionProvider);
      final existingTx =
          existingTxs.where((t) => t.id == widget.pendingTx.id).firstOrNull;
      if (existingTx?.outingId != null) {
        _outingId = existingTx!.outingId;
        _isAutoLinked = existingTx.isAutoLinked;
        try {
          _outingTitle = outings.firstWhere((o) => o.id == _outingId).title;
        } catch (_) {}
      }
    }

    if (!widget.pendingTx.isExpense && !widget.pendingTx.isTransfer) {
      _friendNames = FriendCreditHandler.friendNamesForPicker(ref);
      _linkedFriendName = FriendCreditHandler.matchFriendName(
        ref: ref,
        merchant: widget.pendingTx.receiver,
        upiId: widget.pendingTx.upiId,
        rawIdentifier: widget.pendingTx.rawIdentifier,
      );
      // Default the toggle ON only when this genuinely looks like a
      // repayment: a friend we can identify who actually has money
      // outstanding. Switching it on for every credit (the old behaviour)
      // put the friend panel in front of salary and refunds too, which
      // trains people to dismiss it without reading.
      if (_linkedFriendName != null) {
        _loadClaimsFor(_linkedFriendName!);
        // A known friend with nothing pending is a gift or a transfer, not a
        // repayment — leave it as ordinary income.
        _linkAsFriend = _friendClaims.isNotEmpty;
        if (_linkAsFriend) {
          _selectedCategory = FriendCreditHandler.repaymentCategory;
          _merchantController.text = FriendCreditHandler.merchantLabel(
            _linkedFriendName!,
          );
        } else {
          _clearClaims();
        }
      }
      _selectedContributor = ref.read(contributorProvider.notifier).defaultName;
    }

    // Nothing had linked this row yet — the running trip may still adopt it,
    // but only if it is the kind of money movement a trip can contain. Runs
    // after the friend block so a repayment is already recognised.
    if (_outingId == null) _autoLinkActiveTrip(outings);

    _loadPurposes();
  }

  /// Attaches the running trip to a detection nothing else had linked yet.
  ///
  /// Gated by [outingAcceptsDetection], which is the whole point: this popup
  /// used to link whatever it was handed, so a salary credit or an ATM
  /// withdrawal that happened to arrive mid-trip was auto-added to it and
  /// confirmed onto the trip with the "ADDED TO ACTIVE TRIP" banner. Only an
  /// expense joins a trip; a friend repayment joins it so it can net against
  /// what the trip cost you.
  ///
  /// Note this only *proposes* the link — the row still shows Unlink, and the
  /// detection engine's own decision (already on `pendingTx`/storage/the saved
  /// transaction) always wins over this fallback.
  void _autoLinkActiveTrip(List<Outing> outings) {
    if (!outingAcceptsDetection(
      isExpense: widget.pendingTx.isExpense,
      isTransfer: widget.pendingTx.isTransfer,
      isFriendReturn: _linkAsFriend,
    )) {
      return;
    }
    final activeOuting =
        outings
            .where((o) => outingIsCurrentlyRunning(o) && o.isAutoMode)
            .firstOrNull;
    if (activeOuting == null) return;
    _outingId = activeOuting.id;
    _outingTitle = activeOuting.title;
    _isAutoLinked = true;
  }

  Future<void> _loadPurposes() async {
    final aliases = ref.read(merchantAliasProvider);
    final lookupKey = MerchantIdentifierResolver.stableKey(
      upiId: widget.pendingTx.upiId,
      rawIdentifier: widget.pendingTx.rawIdentifier,
      parsedName: widget.pendingTx.receiver,
      rawMessage: widget.pendingTx.rawMessage,
    );
    final txType =
        widget.pendingTx.isTransfer
            ? 'transfer'
            : (widget.pendingTx.isExpense ? 'debit' : 'credit');
    final savedMerchant = MerchantLearningService.findForTransaction(
      rawIdentifier: widget.pendingTx.rawIdentifier,
      upiId: widget.pendingTx.upiId,
      rawMessage: widget.pendingTx.rawMessage,
      merchant: widget.pendingTx.receiver,
    );
    final rule = ref
        .read(merchantProvider.notifier)
        .findRule(
          lookupKey,
          upiId: widget.pendingTx.upiId,
          transactionType: txType,
        );

    _rawPayee =
        PayeeExtractor.extract(widget.pendingTx.rawMessage) ??
        widget.pendingTx.receiver;

    final box = await SecureHive.openBox('settings');
    final rawPurposes = box.get('purposeTypes');

    if (mounted) {
      setState(() {
        _purposeTypes =
            rawPurposes != null ? List<String>.from(rawPurposes) : ['Personal'];

        String initialTitle;
        if (savedMerchant != null) {
          initialTitle = savedMerchant.title;
          _selectedCategory = savedMerchant.category;
          _selectedPurpose =
              savedMerchant.purpose.isNotEmpty
                  ? savedMerchant.purpose
                  : _purposeTypes.first;
          _isSmartDetected = true;
        } else if (rule != null) {
          initialTitle = rule.merchantName;
          _selectedCategory = rule.defaultCategory;
          _selectedPurpose = rule.defaultPurposeType;
          _isSmartDetected = true;
        } else {
          initialTitle = aliases[lookupKey] ?? _rawPayee;
          _selectedPurpose = _purposeTypes.first;
        }

        _merchantController.text = initialTitle;
        _isRenamed =
            initialTitle.trim().toLowerCase() != _rawPayee.trim().toLowerCase();
        _isLoadingPurposes = false;
      });

      _merchantController.addListener(() {
        final renamed =
            _merchantController.text.trim().toLowerCase() !=
            _rawPayee.trim().toLowerCase();
        if (_isRenamed != renamed) {
          setState(() => _isRenamed = renamed);
        }
      });
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_initialized) {
      final rules = ref.read(merchantProvider.notifier);
      final lookupKey =
          widget.pendingTx.upiId.isNotEmpty
              ? widget.pendingTx.upiId
              : (widget.pendingTx.rawIdentifier ?? widget.pendingTx.receiver);
      final txType =
          widget.pendingTx.isTransfer
              ? 'transfer'
              : (widget.pendingTx.isExpense ? 'debit' : 'credit');
      final rule = rules.findRule(
        lookupKey,
        upiId: widget.pendingTx.upiId,
        transactionType: txType,
      );

      if (rule != null) {
        _selectedCategory = rule.defaultCategory;
      } else if (widget.pendingTx.isTransfer) {
        _selectedCategory =
            _isCashDeposit
                ? SmsAtmHelper.cashDepositCategory
                : SmsAtmHelper.defaultCategory;
      } else {
        final categories =
            widget.pendingTx.isExpense
                ? ref.read(categoryProvider).expense
                : ref.read(categoryProvider).income;
        _selectedCategory = categories.isNotEmpty ? categories.first : 'Other';
      }
      if (!widget.pendingTx.isExpense && !widget.pendingTx.isTransfer) {
        _selectedContributor =
            ref.read(contributorProvider.notifier).defaultName;
      }
      _initialized = true;
    }
  }

  @override
  void dispose() {
    _amountController.dispose();
    _merchantController.dispose();
    _descriptionController.dispose();
    _notesController.dispose();
    for (final line in _splitLines) {
      line.dispose();
    }
    super.dispose();
  }

  void _showAddCategoryDialog() {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            backgroundColor: SoftPalette.surface,
            surfaceTintColor: Colors.transparent,
            elevation: 0,
            insetPadding: const EdgeInsets.symmetric(
              horizontal: 24,
              vertical: 24,
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24),
              side: const BorderSide(color: SoftPalette.border),
            ),
            title: Text(
              'Add Category',
              style: AppType.section(SoftPalette.ink),
            ),
            content: TextField(
              controller: controller,
              autofocus: true,
              style: AppType.body(SoftPalette.ink),
              decoration: InputDecoration(
                hintText: 'Category Name',
                hintStyle: AppType.body(SoftPalette.faint),
                filled: true,
                fillColor: SoftPalette.surfaceVariant,
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 14,
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: const BorderSide(color: SoftPalette.border),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: const BorderSide(color: SoftPalette.border),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: const BorderSide(color: SoftPalette.emerald),
                ),
              ),
            ),
            actionsPadding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                style: TextButton.styleFrom(
                  foregroundColor: SoftPalette.muted,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 12,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                child: const Text('Cancel'),
              ),
              TextButton(
                onPressed: () {
                  if (controller.text.isNotEmpty) {
                    if (widget.pendingTx.isExpense) {
                      ref
                          .read(categoryProvider.notifier)
                          .addExpenseCategory(controller.text);
                    } else {
                      ref
                          .read(categoryProvider.notifier)
                          .addIncomeCategory(controller.text);
                    }
                    setState(() => _selectedCategory = controller.text);
                    Navigator.pop(context);
                  }
                },
                style: TextButton.styleFrom(
                  foregroundColor: SoftPalette.emerald,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 12,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                child: const Text(
                  'Save',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
            ],
          ),
    );
  }

  DateTime? _pastSaveDate() {
    if (!_pastTransaction || _pastDate == null) return null;
    final now = DateTime.now();
    return DateTime(
      _pastDate!.year,
      _pastDate!.month,
      _pastDate!.day,
      now.hour,
      now.minute,
    );
  }

  bool get _splitUsesCategory => _splitBy != _SplitBy.purpose;
  bool get _splitUsesPurpose => _splitBy != _SplitBy.category;

  /// Top-level pickers are hidden for whatever the split rows carry.
  bool get _hideTopCategory => _splitExpense && _splitUsesCategory;
  bool get _hideTopPurpose => _splitExpense && _splitUsesPurpose;

  String get _currentPurpose =>
      _selectedPurpose ??
      (_purposeTypes.isNotEmpty ? _purposeTypes.first : 'Personal');

  List<String> get _distinctPurposes {
    final seen = <String>{};
    return [
      for (final p in _purposeTypes)
        if (p.trim().isNotEmpty && seen.add(p.trim().toLowerCase())) p,
    ];
  }

  /// Purpose / Both splits need at least two purposes.
  bool get _canSplitByPurpose => _distinctPurposes.length >= 2;

  /// Max split rows: one per purpose in Purpose/Both mode, unlimited for Category.
  int? get _splitRowLimit =>
      _splitUsesPurpose ? _distinctPurposes.length : null;

  bool get _atSplitLimit {
    final limit = _splitRowLimit;
    return limit != null && _splitLines.length >= limit;
  }

  /// Accent for the split UI: the app colour rule's solid control green
  /// (#047857, both themes) with white on top.
  Color get _splitInk => SoftColors.control;
  Color get _splitOnInk => Colors.white;

  static double? _parseSplitAmount(String raw) {
    final cleaned = raw.replaceAll(',', '').replaceAll('₹', '').trim();
    if (cleaned.isEmpty) return null;
    return double.tryParse(cleaned);
  }

  static String _plainAmount(double v) =>
      v % 1 == 0 ? v.toInt().toString() : v.toStringAsFixed(2);

  String _firstUnusedPurpose({_SplitLine? except}) {
    final used = {
      for (final l in _splitLines)
        if (!identical(l, except) && l.purpose != null)
          l.purpose!.toLowerCase(),
    };
    for (final p in [_currentPurpose, ..._distinctPurposes]) {
      if (!used.contains(p.toLowerCase())) return p;
    }
    return _currentPurpose;
  }

  void _seedSplitLines() {
    if (_splitLines.isNotEmpty) return;
    if (_splitUsesPurpose && !_canSplitByPurpose) _splitBy = _SplitBy.category;
    final total =
        double.tryParse(_amountController.text) ?? widget.pendingTx.amount;
    final first = double.parse((total / 2).toStringAsFixed(2));
    final second = double.parse((total - first).toStringAsFixed(2));
    _splitLines.add(
      _SplitLine(_plainAmount(first), _selectedCategory, _currentPurpose),
    );
    _splitLines.add(
      _SplitLine(
        _plainAmount(second),
        _selectedCategory,
        _splitUsesPurpose ? _firstUnusedPurpose() : _currentPurpose,
      ),
    );
  }

  /// Applies Purpose/Both rules when the mode changes: trims rows beyond the
  /// purpose count and gives each row its own purpose.
  void _changeSplitBy(_SplitBy next) {
    _splitBy = next;
    _splitError = null;
    if (!_splitUsesPurpose) return;
    final limit = _distinctPurposes.length;
    while (_splitLines.length > limit && _splitLines.length > 2) {
      _splitLines.removeLast().dispose();
    }
    if (_splitBy == _SplitBy.purpose) {
      final seen = <String>{};
      for (final line in _splitLines) {
        final key = (line.purpose ?? '').toLowerCase();
        if (key.isEmpty || !seen.add(key)) {
          line.purpose = _firstUnusedPurpose(except: line);
          seen.add(line.purpose!.toLowerCase());
        }
      }
    }
  }

  double get _splitAllocated => _splitLines.fold<double>(
    0,
    (sum, l) => sum + (_parseSplitAmount(l.amount.text) ?? 0),
  );

  /// Returns an error message, or null when the split rows are valid.
  String? _validateSplits(double total) {
    if (!_splitExpense) return null;
    if (_splitLines.length < 2) return 'Add at least two split rows.';
    if (_splitUsesPurpose && !_canSplitByPurpose) {
      return 'You need at least 2 purposes to split by purpose.';
    }
    final limit = _splitRowLimit;
    if (limit != null && _splitLines.length > limit) {
      return 'You can have at most $limit split rows (one per purpose).';
    }
    for (final line in _splitLines) {
      final v = _parseSplitAmount(line.amount.text);
      if (v == null || v <= 0)
        return 'Each split needs an amount greater than 0.';
      if (_splitUsesCategory && (line.category ?? '').trim().isEmpty) {
        return 'Pick a category for every split.';
      }
      if (_splitUsesPurpose && (line.purpose ?? '').trim().isEmpty) {
        return 'Pick a purpose for every split.';
      }
    }
    if (_splitBy == _SplitBy.purpose) {
      final seen = <String>{};
      for (final line in _splitLines) {
        if (!seen.add(line.purpose!.trim().toLowerCase())) {
          return 'Each split needs a different purpose.';
        }
      }
    } else if (_splitBy == _SplitBy.both) {
      final seen = <String>{};
      for (final line in _splitLines) {
        final key =
            '${line.purpose!.trim().toLowerCase()}|${line.category!.trim().toLowerCase()}';
        if (!seen.add(key)) {
          return 'Each split needs a different purpose + category combination.';
        }
      }
    }
    if ((_splitAllocated - total).abs() > 0.009) {
      return 'Split amounts must add up to ₹${_plainAmount(total)} '
          '(now ₹${_plainAmount(_splitAllocated)}).';
    }
    return null;
  }

  List<TransactionSplitRow>? _splitRows(double amount, String purpose) {
    if (!_splitExpense || amount <= 0) return null;
    return [
      for (final line in _splitLines)
        TransactionSplitRow(
          categoryId:
              _splitUsesCategory
                  ? (line.category ?? _selectedCategory)
                  : _selectedCategory,
          purposeId: _splitUsesPurpose ? (line.purpose ?? purpose) : purpose,
          amount: _parseSplitAmount(line.amount.text) ?? 0,
        ),
    ];
  }

  /// Shared style so Description / Notes / split fields line up with the
  /// rest of the modal (filled field, 16 radius, same padding).
  InputDecoration _fieldDecoration(String label, {Color? accent}) {
    final t = context.tokens;
    final none = OutlineInputBorder(
      borderRadius: BorderRadius.circular(16),
      borderSide: BorderSide.none,
    );
    return InputDecoration(
      labelText: label,
      labelStyle: TextStyle(fontSize: 13, color: t.textSecondary),
      floatingLabelStyle:
          accent == null ? null : TextStyle(fontSize: 13, color: accent),
      filled: true,
      fillColor: t.field,
      isDense: true,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: none,
      enabledBorder: none,
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(color: accent ?? _themeColor, width: 1.2),
      ),
    );
  }

  Widget _splitEditor(List<String> categories) {
    final t = context.tokens;
    final ink = _splitInk;
    final onInk = _splitOnInk;
    final total =
        double.tryParse(_amountController.text) ?? widget.pendingTx.amount;
    final allocated = _splitAllocated;
    final balanced = (allocated - total).abs() <= 0.009;
    final purposes = [..._distinctPurposes];
    final categoryItems = [...categories];
    for (final line in _splitLines) {
      if (line.category != null && !categoryItems.contains(line.category)) {
        categoryItems.add(line.category!);
      }
      if (line.purpose != null && !purposes.contains(line.purpose)) {
        purposes.add(line.purpose!);
      }
    }
    final limit = _splitRowLimit;
    final segmentStyle = ButtonStyle(
      backgroundColor: WidgetStateProperty.resolveWith(
        (s) => s.contains(WidgetState.selected) ? ink : Colors.transparent,
      ),
      foregroundColor: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.disabled))
          return ink.withValues(alpha: 0.35);
        return s.contains(WidgetState.selected) ? onInk : ink;
      }),
      side: WidgetStatePropertyAll(
        BorderSide(color: ink.withValues(alpha: 0.4)),
      ),
      overlayColor: WidgetStatePropertyAll(ink.withValues(alpha: 0.08)),
    );
    return Theme(
      data: Theme.of(context).copyWith(
        colorScheme: Theme.of(context).colorScheme.copyWith(primary: ink),
        textSelectionTheme: TextSelectionThemeData(
          cursorColor: ink,
          selectionColor: ink.withValues(alpha: 0.2),
          selectionHandleColor: ink,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SegmentedButton<_SplitBy>(
            showSelectedIcon: false,
            style: segmentStyle,
            segments: [
              const ButtonSegment(
                value: _SplitBy.category,
                label: Text('Category'),
              ),
              ButtonSegment(
                value: _SplitBy.purpose,
                label: const Text('Purpose'),
                enabled: _canSplitByPurpose,
              ),
              ButtonSegment(
                value: _SplitBy.both,
                label: const Text('Both'),
                enabled: _canSplitByPurpose,
              ),
            ],
            selected: {_splitBy},
            onSelectionChanged: (v) => setState(() => _changeSplitBy(v.first)),
          ),
          if (!_canSplitByPurpose)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text(
                'Add a second purpose to split by Purpose or Both.',
                style: TextStyle(fontSize: 11.5, color: t.textSecondary),
              ),
            )
          else if (limit != null)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text(
                _splitBy == _SplitBy.purpose
                    ? 'Up to $limit rows · one purpose per row'
                    : 'Up to $limit rows · each purpose + category once',
                style: TextStyle(fontSize: 11.5, color: t.textSecondary),
              ),
            ),
          const SizedBox(height: 12),
          for (var i = 0; i < _splitLines.length; i++) ...[
            Container(
              key: ObjectKey(_splitLines[i]),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: t.card,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: t.border),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _splitLines[i].amount,
                          cursorColor: ink,
                          keyboardType: const TextInputType.numberWithOptions(
                            decimal: true,
                          ),
                          decoration: _fieldDecoration(
                            'Split ${i + 1} amount (₹)',
                            accent: ink,
                          ),
                          onChanged: (_) => setState(() => _splitError = null),
                        ),
                      ),
                      if (_splitLines.length > 2)
                        IconButton(
                          tooltip: 'Remove split',
                          icon: Icon(LucideIcons.x, size: 16, color: ink),
                          onPressed:
                              () => setState(() {
                                _splitLines.removeAt(i).dispose();
                                _splitError = null;
                              }),
                        ),
                    ],
                  ),
                  if (_splitUsesCategory) ...[
                    const SizedBox(height: 8),
                    DropdownButtonFormField<String>(
                      // Re-key on value so programmatic changes (mode switch) show.
                      key: ValueKey(
                        'c-${identityHashCode(_splitLines[i])}-${_splitLines[i].category}-${_splitBy.name}',
                      ),
                      initialValue: _splitLines[i].category,
                      isExpanded: true,
                      dropdownColor: t.card,
                      iconEnabledColor: ink,
                      decoration: _fieldDecoration('Category', accent: ink),
                      items: [
                        for (final c in categoryItems)
                          DropdownMenuItem(value: c, child: Text(c)),
                      ],
                      onChanged:
                          (v) => setState(() {
                            _splitLines[i].category = v;
                            _splitError = null;
                          }),
                    ),
                  ],
                  if (_splitUsesPurpose && purposes.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    DropdownButtonFormField<String>(
                      // Re-key on value so programmatic changes (mode switch) show.
                      key: ValueKey(
                        'p-${identityHashCode(_splitLines[i])}-${_splitLines[i].purpose}-${_splitBy.name}',
                      ),
                      initialValue: _splitLines[i].purpose,
                      isExpanded: true,
                      dropdownColor: t.card,
                      iconEnabledColor: ink,
                      decoration: _fieldDecoration('Purpose', accent: ink),
                      items: [
                        for (final p in purposes)
                          () {
                            // Purpose mode: a purpose used by another row is disabled.
                            final usedElsewhere =
                                _splitBy == _SplitBy.purpose &&
                                _splitLines.any(
                                  (l) =>
                                      !identical(l, _splitLines[i]) &&
                                      (l.purpose ?? '').toLowerCase() ==
                                          p.toLowerCase(),
                                );
                            return DropdownMenuItem(
                              value: p,
                              enabled: !usedElsewhere,
                              child: Text(
                                usedElsewhere ? '$p (used)' : p,
                                style: TextStyle(
                                  color: usedElsewhere ? t.textSecondary : null,
                                ),
                              ),
                            );
                          }(),
                      ],
                      onChanged:
                          (v) => setState(() {
                            _splitLines[i].purpose = v;
                            _splitError = null;
                          }),
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 8),
          ],
          Row(
            children: [
              if (!_atSplitLimit)
                TextButton.icon(
                  style: TextButton.styleFrom(foregroundColor: ink),
                  onPressed:
                      () => setState(() {
                        final remaining = total - allocated;
                        _splitLines.add(
                          _SplitLine(
                            remaining > 0
                                ? _plainAmount(
                                  double.parse(remaining.toStringAsFixed(2)),
                                )
                                : '',
                            _selectedCategory,
                            _splitUsesPurpose
                                ? _firstUnusedPurpose()
                                : _currentPurpose,
                          ),
                        );
                        _splitError = null;
                      }),
                  icon: const Icon(LucideIcons.plus, size: 16),
                  label: const Text('Add split'),
                )
              else
                Text(
                  'Max $limit rows (one per purpose)',
                  style: TextStyle(fontSize: 12, color: t.textSecondary),
                ),
              const Spacer(),
              Text(
                '₹${_plainAmount(allocated)} of ₹${_plainAmount(total)}',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: balanced ? ink : AppColors.expense,
                ),
              ),
            ],
          ),
          if (_splitError != null)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                _splitError!,
                style: const TextStyle(fontSize: 12, color: AppColors.expense),
              ),
            ),
        ],
      ),
    );
  }

  Widget _advancedFields(List<String> categories) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Split expense'),
          // App colour rule: solid #047857 when on, grey when off.
          thumbColor: WidgetStateProperty.resolveWith(
            (s) => s.contains(WidgetState.selected) ? _splitOnInk : null,
          ),
          trackColor: WidgetStateProperty.resolveWith(
            (s) => s.contains(WidgetState.selected) ? _splitInk : null,
          ),
          trackOutlineColor: const WidgetStatePropertyAll(Colors.transparent),
          value: _splitExpense,
          onChanged:
              (v) => setState(() {
                _splitExpense = v;
                _splitError = null;
                if (v) _seedSplitLines();
              }),
        ),
        if (_splitExpense) ...[
          _splitEditor(categories),
          const SizedBox(height: 4),
        ],
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Split with friends'),
          value: _splitWithFriends,
          onChanged: (v) => setState(() => _splitWithFriends = v),
        ),
        if (_splitWithFriends)
          _friendNames.isEmpty
              ? Text(
                'Add friends in Friends tab first.',
                style: TextStyle(fontSize: 12, color: Colors.orange.shade700),
              )
              : Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final name in _friendNames)
                    FilterChip(
                      label: Text(name),
                      selected: _splitFriendNames.contains(name),
                      onSelected:
                          (on) => setState(() {
                            if (on) {
                              _splitFriendNames.add(name);
                            } else {
                              _splitFriendNames.remove(name);
                            }
                          }),
                    ),
                ],
              ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Past transaction'),
          value: _pastTransaction,
          onChanged: (on) async {
            if (!on) {
              setState(() => _pastTransaction = false);
              return;
            }
            final picked = await showDatePicker(
              context: context,
              initialDate:
                  _pastDate ?? DateTime.now().subtract(const Duration(days: 1)),
              firstDate: DateTime(2000),
              lastDate: DateTime.now(),
            );
            if (!mounted) return;
            setState(() {
              if (picked != null) {
                _pastTransaction = true;
                _pastDate = picked;
              }
            });
          },
        ),
        if (_pastTransaction && _pastDate != null)
          Align(
            alignment: Alignment.centerLeft,
            child: Text(DateFormat('d MMM y').format(_pastDate!)),
          ),
        const SizedBox(height: 12),
        TextField(
          controller: _descriptionController,
          decoration: _fieldDecoration('Description'),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _notesController,
          minLines: 1,
          maxLines: 3,
          decoration: _fieldDecoration('Notes'),
        ),
      ],
    );
  }

  void _saveTransaction() {
    final rawName = _merchantController.text.trim();
    if (rawName.isEmpty) {
      setState(() => _hasMerchantError = true);
      return;
    }
    setState(() => _hasMerchantError = false);

    final isCredit =
        !widget.pendingTx.isExpense && !widget.pendingTx.isTransfer;
    var finalName = rawName;
    if (isCredit && _linkAsFriend && _linkedFriendName != null) {
      finalName = FriendCreditHandler.merchantLabel(_linkedFriendName!);
      _selectedCategory = FriendCreditHandler.repaymentCategory;
    }

    final parsedAmount = double.tryParse(_amountController.text) ?? 0;
    if (parsedAmount <= 0) return;

    final splitError = _validateSplits(parsedAmount);
    if (splitError != null) {
      setState(() {
        _splitError = splitError;
        _showAdvanced = true;
      });
      return;
    }

    final isTransfer = widget.pendingTx.isTransfer;

    // ATM: per-bank rule key so future withdrawals from same bank auto-add.
    // Other tx: stable SOURCE identifier for rule key, not user-edited display name.
    final extractedUpi =
        widget.pendingTx.upiId.isNotEmpty
            ? widget.pendingTx.upiId
            : (MerchantRuleService.extractUpiFromMessage(
                  widget.pendingTx.rawMessage,
                ) ??
                '');
    String sourceId =
        widget.pendingTx.isTransfer
            ? SmsAtmHelper.ruleIdentifier(
              bank: widget.pendingTx.bankName,
              accountLast4: widget.pendingTx.accountLast4,
              isCashDeposit: _isCashDeposit,
            )
            : MerchantIdentifierResolver.stableKey(
              upiId:
                  extractedUpi.isNotEmpty
                      ? extractedUpi
                      : widget.pendingTx.upiId,
              rawIdentifier: widget.pendingTx.rawIdentifier,
              parsedName: widget.pendingTx.receiver,
              rawMessage: widget.pendingTx.rawMessage,
            );
    if (sourceId.isEmpty && widget.pendingTx.rawMessage.isNotEmpty) {
      final m = RegExp(
        r'(?:Salary|from|by|payroll)[^\w]*([A-Za-z0-9.&\- ]+?)(?:\.|$)',
        caseSensitive: false,
      ).firstMatch(widget.pendingTx.rawMessage);
      if (m != null) {
        final v = m.group(1)!.trim();
        if (v.length > 2 && !_isGenericSourceId(v)) sourceId = v;
      }
    }

    // Friend credit mapping only here; merchant learn is single-path in confirmTransaction.
    // The friend <-> UPI link is personal data, not part of the shared merchant
    // DB, so it is saved regardless of _saveToGlobalDB — gating it there meant a
    // user who turned that switch off never got automatic matching, which is the
    // whole point of asking them once.
    if (isCredit && _linkAsFriend && _linkedFriendName != null) {
      if (_saveToGlobalDB) {
        FriendCreditHandler.learnFriendCreditRule(
          ref: ref,
          friendName: _linkedFriendName!,
          upiId: widget.pendingTx.upiId,
          rawIdentifier: widget.pendingTx.rawIdentifier,
        );
      }
      // Only ever store a real VPA. sourceId is often a parsed name fragment
      // for credits, and storing that as a "UPI" is what lets unrelated
      // senders match this friend later.
      FriendCreditHandler.linkFriendUpi(
        ref,
        _linkedFriendName!,
        widget.pendingTx.upiId.isNotEmpty
            ? widget.pendingTx.upiId
            : extractedUpi,
      );
    }

    if (_isRenamed && _saveToGlobalDB && sourceId.isNotEmpty) {
      ref.read(merchantAliasProvider.notifier).saveAlias(sourceId, finalName);
    }

    var purpose = _currentPurpose;
    final splits = _splitRows(parsedAmount, purpose);
    // When the top-level pickers are hidden, the row-level fields come from the
    // largest split so lists and filters still show a sensible value.
    if (splits != null && splits.isNotEmpty) {
      final main = splits.reduce((a, b) => b.amount > a.amount ? b : a);
      if (_hideTopCategory && main.categoryId.isNotEmpty) {
        _selectedCategory = main.categoryId;
      }
      if (_hideTopPurpose && main.purposeId.isNotEmpty)
        purpose = main.purposeId;
    }
    final merchantId =
        sourceId.isNotEmpty
            ? sourceId
            : (PayeeNormalizer.isMeaningful(_rawPayee) ? _rawPayee : finalName);

    // The user has just been shown the pending list and made a decision, so
    // this popup owns the settlement. Claim the transaction before saving it —
    // addTransaction() runs the automatic matcher on every new row, which would
    // otherwise settle it a second time, or settle a credit the user explicitly
    // chose not to mark as a repayment.
    if (isCredit) {
      FriendRepaymentMatcher.markHandledExternally(widget.pendingTx.id);
    }

    // Debit = isExpense true; credit = false. Never flip type on confirm.
    ref
        .read(detectionQueueProvider.notifier)
        .confirmTransaction(
          widget.pendingTx.id,
          parsedAmount,
          finalName,
          purpose,
          widget.pendingTx.isExpense,
          _selectedCategory,
          isTransfer: isTransfer,
          outingId: _outingId,
          isAutoLinked: _outingId != null,
          merchantIdentifier: merchantId,
          upiId:
              widget.pendingTx.upiId.isNotEmpty
                  ? widget.pendingTx.upiId
                  : extractedUpi,
          contributorSource: isCredit ? _selectedContributor : null,
          learnMerchant: _saveToGlobalDB,
          note: _notesController.text,
          description: _descriptionController.text,
          date: _pastSaveDate(),
          splits: splits,
          isGroup: _splitWithFriends && _splitFriendNames.isNotEmpty,
          groupCount:
              _splitWithFriends && _splitFriendNames.isNotEmpty
                  ? _splitFriendNames.length + 1
                  : 0,
        );

    // Settle exactly what the user ticked — nothing else. The old path handed
    // the credit to FriendRepaymentMatcher, which drained pending shares
    // greedily across every outing until the amount ran out.
    if (isCredit && _linkAsFriend && _linkedFriendName != null) {
      final ticked = _tickedClaims;
      if (ticked.isNotEmpty) {
        final allocation = FriendOpenClaimsService.allocate(
          ticked,
          parsedAmount,
        );
        final settled = FriendOpenClaimsService.applySettlements(
          ref,
          claims: ticked,
          allocation: allocation,
          mode: widget.pendingTx.upiId.isNotEmpty ? 'UPI' : 'Online',
        );
        if (settled > 0) {
          final applied = allocation.values.fold(0.0, (sum, v) => sum + v);
          ref.read(settlementFeedbackProvider.notifier).state =
              '₹${applied.toStringAsFixed(0)} from $_linkedFriendName settled';
        }
      }
    }

    if (!context.mounted) return;
    Navigator.pop(context, 'confirm');

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          isTransfer
              ? (_isCashDeposit
                  ? 'Cash deposit ₹${parsedAmount.toInt()} confirmed'
                  : 'Cash withdrawal ₹${parsedAmount.toInt()} confirmed')
              : isCredit
              ? 'Income ₹${parsedAmount.toInt()} saved · $finalName'
              : 'Expense ₹${parsedAmount.toInt()} saved · $finalName',
        ),
        backgroundColor:
            isTransfer
                ? _kAtmPurple
                : (widget.pendingTx.isExpense
                    ? AppColors.expense
                    : AppColors.income),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.fromLTRB(20, 0, 20, 20),
      ),
    );
  }

  void _ignoreTransaction() {
    PendingVerificationHistoryService.markIgnored(widget.pendingTx.id);
    ref
        .read(detectionQueueProvider.notifier)
        .ignoreTransaction(widget.pendingTx.id);
    if (!mounted) return;
    Navigator.pop(context, 'ignore');
  }

  String _detectedAmountLabel() {
    final amount =
        double.tryParse(_amountController.text) ?? widget.pendingTx.amount;
    final prefix = widget.pendingTx.isExpense ? '-' : '+';
    return '$prefix₹${amount.toStringAsFixed(0)}';
  }

  String _detectedMerchantLine() {
    if (widget.pendingTx.isTransfer) {
      return _isCashDeposit
          ? SmsAtmHelper.cashDepositDisplayName
          : SmsAtmHelper.defaultDisplayName;
    }
    final name = _merchantController.text.trim();
    return name.isEmpty ? widget.pendingTx.receiver : name;
  }

  String _detectedMetaLine() {
    final bank = widget.pendingTx.bankName.trim();
    final date = DateFormat('dd MMM · h:mm a').format(widget.pendingTx.date);
    return bank.isEmpty ? date : '$bank · $date';
  }

  String _detectedAccountLabel() {
    final bank = widget.pendingTx.bankName.trim();
    final last4 = widget.pendingTx.accountLast4.trim();
    if (bank.isEmpty && last4.isEmpty) return 'Account not specified';
    if (last4.isEmpty) return bank;
    return '$bank •••• $last4';
  }

  Future<void> _pickDetectedCategory(List<String> categories) async {
    final selected = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      backgroundColor: SoftPalette.surface,
      barrierColor: context.tokens.scrim,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      clipBehavior: Clip.antiAlias,
      builder:
          (sheetContext) => SafeArea(
            child: ListView(
              shrinkWrap: true,
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
              children: [
                Text(
                  'Choose category',
                  style: AppType.section(SoftPalette.ink),
                ),
                const SizedBox(height: 12),
                for (final category in categories)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        borderRadius: BorderRadius.circular(16),
                        onTap: () => Navigator.pop(sheetContext, category),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 14,
                          ),
                          decoration: BoxDecoration(
                            color:
                                category == _selectedCategory
                                    ? SoftPalette.emeraldSoft
                                    : SoftPalette.surface,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color:
                                  category == _selectedCategory
                                      ? SoftPalette.emerald
                                      : SoftPalette.border,
                            ),
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                child: Text(
                                  category,
                                  style: AppType.body(SoftPalette.ink),
                                ),
                              ),
                              if (category == _selectedCategory)
                                const Icon(
                                  LucideIcons.check,
                                  size: 18,
                                  color: SoftPalette.emerald,
                                ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
    );
    if (selected != null && mounted) {
      setState(() => _selectedCategory = selected);
    }
  }

  Future<void> _pickDetectedPurpose() async {
    final selected = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      backgroundColor: SoftPalette.surface,
      barrierColor: context.tokens.scrim,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      clipBehavior: Clip.antiAlias,
      builder:
          (sheetContext) => SafeArea(
            child: ListView(
              shrinkWrap: true,
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
              children: [
                Text('Choose purpose', style: AppType.section(SoftPalette.ink)),
                const SizedBox(height: 12),
                for (final purpose in _purposeTypes)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        borderRadius: BorderRadius.circular(16),
                        onTap: () => Navigator.pop(sheetContext, purpose),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 14,
                          ),
                          decoration: BoxDecoration(
                            color:
                                purpose == _selectedPurpose
                                    ? SoftPalette.emeraldSoft
                                    : SoftPalette.surface,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color:
                                  purpose == _selectedPurpose
                                      ? SoftPalette.emerald
                                      : SoftPalette.border,
                            ),
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                child: Text(
                                  purpose,
                                  style: AppType.body(SoftPalette.ink),
                                ),
                              ),
                              if (purpose == _selectedPurpose)
                                const Icon(
                                  LucideIcons.check,
                                  size: 18,
                                  color: SoftPalette.emerald,
                                ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
    );
    if (selected != null && mounted) {
      setState(() => _selectedPurpose = selected);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final categories =
        widget.pendingTx.isExpense
            ? ref.watch(categoryProvider).expense
            : ref.watch(categoryProvider).income;

    return SingleChildScrollView(
      padding: const EdgeInsets.only(left: 24, right: 24, top: 20, bottom: 20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Soft Soft Detected header
          SoftPageHeader(
            title: 'Detected',
            onBack: () => Navigator.maybePop(context),
            trailing: PopupMenuButton<String>(
              tooltip: 'More',
              padding: EdgeInsets.zero,
              offset: const Offset(0, 40),
              color: SoftPalette.surface,
              elevation: 0,
              shadowColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
                side: const BorderSide(color: SoftPalette.border),
              ),
              onSelected: (value) {
                if (value == 'ignore') _ignoreTransaction();
              },
              itemBuilder:
                  (context) => const [
                    PopupMenuItem(value: 'ignore', child: Text('Ignore')),
                  ],
              child: const IgnorePointer(
                child: SoftCircleIconButton(
                  icon: Icons.more_horiz_rounded,
                  onPressed: _noop,
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          _DetectedSummaryCard(
            amountLabel: _detectedAmountLabel(),
            merchantLine: _detectedMerchantLine(),
            metaLine: _detectedMetaLine(),
          ),
          const SizedBox(height: 12),
          _DetectedDetailsCard(
            account: _detectedAccountLabel(),
            category:
                widget.pendingTx.isTransfer ? 'Transfer' : _selectedCategory,
            purpose:
                _selectedPurpose ??
                (_purposeTypes.isNotEmpty
                    ? _purposeTypes.first
                    : 'Add purpose...'),
            onAccount: null,
            onCategory:
                widget.pendingTx.isTransfer
                    ? null
                    : () => _pickDetectedCategory(categories),
            onPurpose: _purposeTypes.isEmpty ? null : _pickDetectedPurpose,
            showCategory: !_hideTopCategory,
            showPurpose: !_hideTopPurpose,
          ),
          const SizedBox(height: 18),
          SoftPrimaryButton(
            label: 'Save transaction',
            onPressed: _saveTransaction,
          ),
          const SizedBox(height: 10),
          TextButton(
            onPressed: () {
              setState(() {
                _showAdvanced = !_showAdvanced;
                if (_showAdvanced && _friendNames.isEmpty) {
                  _friendNames = FriendCreditHandler.friendNamesForPicker(ref);
                }
              });
            },
            child: Text(_showAdvanced ? 'Hide advanced' : 'Advanced'),
          ),
          if (_showAdvanced) _advancedFields(categories),
          if (_editingBeforeSave) ...[
            const SizedBox(height: 18),

            if (!widget.pendingTx.isExpense) ...[
              _IncomeCelebrationBanner(
                amount: widget.pendingTx.amount,
                title: _merchantController.text,
              ),
            ] else ...[
              const SizedBox(height: 8),
            ],

            // 1) Amount Area
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  '₹',
                  style: TextStyle(
                    fontSize: 40,
                    fontWeight: FontWeight.w500,
                    color: _themeColor.withValues(alpha: 0.5),
                  ),
                ),
                const SizedBox(width: 8),
                IntrinsicWidth(
                  child: TextField(
                    controller: _amountController,
                    keyboardType: TextInputType.number,
                    // The pending-claim panel shows how much of this amount is
                    // being settled, so it has to follow edits to the amount.
                    onChanged: (_) {
                      if (_linkAsFriend && _friendClaims.isNotEmpty)
                        setState(() {});
                    },
                    style: TextStyle(
                      fontSize: 52,
                      fontWeight: FontWeight.w500,
                      color: _themeColor,
                      letterSpacing: -2,
                    ),
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      isDense: true,
                      contentPadding: EdgeInsets.zero,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // 2) Name (editable)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: context.tokens.field,
                borderRadius: BorderRadius.circular(16),
                border:
                    _hasMerchantError
                        ? Border.all(color: AppColors.expense, width: 1.5)
                        : null,
              ),
              child: TextField(
                controller: _merchantController,
                textAlign: TextAlign.center,
                onChanged: (val) {
                  if (_hasMerchantError && val.trim().isNotEmpty)
                    setState(() => _hasMerchantError = false);
                },
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  color: context.tokens.textPrimary,
                ),
                decoration: InputDecoration(
                  border: InputBorder.none,
                  hintText:
                      widget.pendingTx.isExpense ? 'Paid to' : 'Income from',
                  hintStyle: TextStyle(
                    color: Colors.grey.withValues(alpha: 0.5),
                  ),
                  suffixIcon: Icon(
                    LucideIcons.edit3,
                    size: 14,
                    color: Colors.grey.withValues(alpha: 0.5),
                  ),
                  contentPadding: const EdgeInsets.symmetric(vertical: 12),
                ),
              ),
            ),
            if (_isSmartDetected) ...[
              const SizedBox(height: 6),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    LucideIcons.sparkles,
                    size: 12,
                    color: AppColors.primary,
                  ),
                  const SizedBox(width: 4),
                  const Text(
                    'Learned from previous transaction',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      color: AppColors.primary,
                    ),
                  ),
                ],
              ),
            ],
            if (!widget.pendingTx.isTransfer &&
                _rawPayee.isNotEmpty &&
                _merchantController.text.trim().toLowerCase() !=
                    _rawPayee.trim().toLowerCase()) ...[
              const SizedBox(height: 6),
              Text(
                'From SMS: $_rawPayee',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                  color: Colors.grey.withValues(alpha: 0.65),
                ),
              ),
            ],

            // 3) Bank
            //
            // ATM/CDM rows deliberately show only the bank here — Cash is
            // always the other side, so "To: Cash" would be noise. The user
            // only ever needs to correct account, amount, or date/time.
            const SizedBox(height: 8),
            Text(
              widget.pendingTx.bank.toUpperCase(),
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w500,
                color: Colors.grey.withValues(alpha: 0.6),
                letterSpacing: 2,
              ),
            ),
            if (!widget.pendingTx.isTransfer &&
                widget.pendingTx.upiId.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text(
                widget.pendingTx.upiId,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                  color: Colors.grey.withValues(alpha: 0.4),
                ),
              ),
            ],

            if (!widget.pendingTx.isExpense &&
                !widget.pendingTx.isTransfer) ...[
              const SizedBox(height: 20),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.income.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: AppColors.income.withValues(alpha: 0.2),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(
                          LucideIcons.userPlus,
                          size: 18,
                          color: AppColors.income,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            'Friend sent this?',
                            style: TextStyle(
                              fontWeight: FontWeight.w500,
                              fontSize: 14,
                              color: context.tokens.textPrimary,
                            ),
                          ),
                        ),
                        Switch(
                          value: _linkAsFriend,
                          activeThumbColor: Colors.white,
                          activeTrackColor: SoftColors.control,
                          onChanged:
                              (v) => setState(() {
                                _linkAsFriend = v;
                                if (!v) {
                                  _linkedFriendName = null;
                                  _clearClaims();
                                } else if (_linkedFriendName != null) {
                                  _loadClaimsFor(_linkedFriendName!);
                                }
                              }),
                        ),
                      ],
                    ),
                    if (_linkAsFriend) ...[
                      const SizedBox(height: 8),
                      Text(
                        'Link UPI once — next credits auto-match and clear trip pending.',
                        style: TextStyle(
                          fontSize: 11,
                          color: context.tokens.textSecondary,
                        ),
                      ),
                      const SizedBox(height: 12),
                      if (_friendNames.isEmpty)
                        Text(
                          'Add friends in Friends tab first.',
                          style: TextStyle(
                            fontSize: 11,
                            color: Colors.orange.shade700,
                          ),
                        )
                      else
                        DropdownButtonFormField<String>(
                          value:
                              _linkedFriendName != null &&
                                      _friendNames.contains(_linkedFriendName)
                                  ? _linkedFriendName
                                  : null,
                          decoration: InputDecoration(
                            labelText: 'Select friend',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            isDense: true,
                          ),
                          items:
                              _friendNames
                                  .map(
                                    (n) => DropdownMenuItem(
                                      value: n,
                                      child: Text(n),
                                    ),
                                  )
                                  .toList(),
                          onChanged:
                              (v) => setState(() {
                                _linkedFriendName = v;
                                if (v != null) {
                                  _merchantController.text =
                                      FriendCreditHandler.merchantLabel(v);
                                  _selectedCategory =
                                      FriendCreditHandler.repaymentCategory;
                                  _loadClaimsFor(v);
                                } else {
                                  _clearClaims();
                                }
                              }),
                        ),
                      if (_linkedFriendName != null) _buildPendingClaims(),
                    ],
                  ],
                ),
              ),
            ],

            const SizedBox(height: 24),

            // Date & Time Row (Premium Container)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color:
                    isDark
                        ? AppColors.darkElevated.withValues(alpha: 0.5)
                        : AppColors.lightElevated.withValues(alpha: 0.5),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color:
                      isDark
                          ? Colors.white.withValues(alpha: 0.05)
                          : Colors.black.withValues(alpha: 0.05),
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    LucideIcons.calendar,
                    size: 12,
                    color: Colors.grey.withValues(alpha: 0.8),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    DateFormat('dd MMM yyyy').format(widget.pendingTx.date),
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      color: Colors.grey.withValues(alpha: 0.8),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    '•',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      color: Colors.grey.withValues(alpha: 0.4),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Icon(
                    LucideIcons.clock,
                    size: 12,
                    color: Colors.grey.withValues(alpha: 0.8),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    DateFormat('h:mm a').format(widget.pendingTx.date),
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      color: Colors.grey.withValues(alpha: 0.8),
                    ),
                  ),
                ],
              ),
            ),
            if (_outingTitle != null) ...[
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 14,
                ),
                decoration: BoxDecoration(
                  color: AppColors.primary.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: AppColors.primary.withValues(alpha: 0.15),
                  ),
                ),
                child: Row(
                  children: [
                    const Icon(
                      LucideIcons.compass,
                      size: 20,
                      color: AppColors.primary,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _isAutoLinked
                                ? 'ADDED TO ACTIVE TRIP'
                                : 'LINK TO ACTIVE TRIP?',
                            style: const TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w500,
                              color: Colors.grey,
                              letterSpacing: 1,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            _isAutoLinked
                                ? 'This spend is on $_outingTitle'
                                : 'Add this to $_outingTitle?',
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                    TextButton(
                      onPressed: () async {
                        final ok = await OutingUnlinkDialog.confirm(
                          context,
                          itemName: widget.pendingTx.merchant,
                          amount: widget.pendingTx.amount,
                          isPendingOnly: true,
                        );
                        if (!ok || !mounted) return;
                        setState(() {
                          _outingId = null;
                          _outingTitle = null;
                          _isAutoLinked = false;
                        });
                        final stored = DetectedSmsStorage.get(
                          widget.pendingTx.id,
                        );
                        if (stored != null) {
                          DetectedSmsStorage.save(
                            PendingTransaction(
                              id: stored.id,
                              amount: stored.amount,
                              receiver: stored.receiver,
                              bank: stored.bank,
                              date: stored.date,
                              rawMessage: stored.rawMessage,
                              isExpense: stored.isExpense,
                              isTransfer: stored.isTransfer,
                              accountLast4: stored.accountLast4,
                              referenceId: stored.referenceId,
                              upiId: stored.upiId,
                            ),
                          );
                        }
                      },
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 6,
                        ),
                        minimumSize: Size.zero,
                        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      ),
                      child: const Text(
                        'Unlink',
                        style: TextStyle(
                          color: Colors.red,
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 32),

            // 4) Purpose Type (conditional & dynamic)
            if (!_isLoadingPurposes &&
                _purposeTypes.length >= 2 &&
                !_hideTopPurpose) ...[
              _SectionTitle(title: 'Purpose', isDark: isDark),
              const SizedBox(height: 12),
              SizedBox(
                height: 38,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  clipBehavior: Clip.none,
                  itemCount: _purposeTypes.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (context, i) {
                    final purpose = _purposeTypes[i];
                    final selected = _selectedPurpose == purpose;
                    return GestureDetector(
                      onTap: () => setState(() => _selectedPurpose = purpose),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color:
                              selected ? _buttonColor : (context.tokens.field),
                          borderRadius: BorderRadius.circular(12),
                          boxShadow:
                              selected
                                  ? [
                                    BoxShadow(
                                      color: _buttonColor.withValues(
                                        alpha: 0.3,
                                      ),
                                      blurRadius: 8,
                                      offset: const Offset(0, 4),
                                    ),
                                  ]
                                  : [],
                        ),
                        child: Text(
                          purpose,
                          style: TextStyle(
                            color:
                                selected
                                    ? Colors.white
                                    : (context.tokens.textSecondary),
                            fontWeight:
                                selected ? FontWeight.w500 : FontWeight.w500,
                            fontSize: 13,
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 24),
            ] else if (_isLoadingPurposes)
              const SizedBox(
                height: 20,
                child: Center(
                  child: SizedBox(
                    width: 20,
                    height: 2,
                    child: LinearProgressIndicator(),
                  ),
                ),
              ),

            // 5) Income contributor (credits only)
            if (!widget.pendingTx.isExpense &&
                !widget.pendingTx.isTransfer) ...[
              _SectionTitle(title: 'Income contributor', isDark: isDark),
              const SizedBox(height: 12),
              Builder(
                builder: (context) {
                  final contributors = ref.watch(contributorProvider);
                  final list =
                      contributors.isEmpty
                          ? [
                            const Contributor(
                              id: 'me',
                              name: ContributorNotifier.defaultMeName,
                              isDefault: true,
                              canDelete: false,
                            ),
                          ]
                          : contributors;
                  return SizedBox(
                    height: 38,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      clipBehavior: Clip.none,
                      itemCount: list.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 8),
                      itemBuilder: (context, i) {
                        final c = list[i];
                        final selected = _selectedContributor == c.name;
                        return GestureDetector(
                          onTap:
                              () =>
                                  setState(() => _selectedContributor = c.name),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color:
                                  selected
                                      ? _buttonColor
                                      : (context.tokens.field),
                              borderRadius: BorderRadius.circular(12),
                              boxShadow:
                                  selected
                                      ? [
                                        BoxShadow(
                                          color: _buttonColor.withValues(
                                            alpha: 0.3,
                                          ),
                                          blurRadius: 8,
                                          offset: const Offset(0, 4),
                                        ),
                                      ]
                                      : [],
                            ),
                            child: Text(
                              c.name,
                              style: TextStyle(
                                color:
                                    selected
                                        ? Colors.white
                                        : (context.tokens.textSecondary),
                                fontWeight:
                                    selected
                                        ? FontWeight.w500
                                        : FontWeight.w500,
                                fontSize: 13,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  );
                },
              ),
              const SizedBox(height: 24),
            ],

            // 6) Category (from DB / categoryProvider)
            if (!widget.pendingTx.isTransfer && !_hideTopCategory) ...[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _SectionTitle(title: 'Category', isDark: isDark),
                  GestureDetector(
                    onTap: _showAddCategoryDialog,
                    child: Text(
                      '+ CUSTOM',
                      style: TextStyle(
                        color: _buttonColor,
                        fontWeight: FontWeight.w500,
                        fontSize: 11,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              if (categories.isEmpty)
                Text(
                  'No categories — add custom or sync.',
                  style: TextStyle(
                    fontSize: 12,
                    color: context.tokens.textSecondary,
                  ),
                )
              else
                SizedBox(
                  height: 38,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    clipBehavior: Clip.none,
                    itemCount: categories.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 8),
                    itemBuilder: (context, i) {
                      final cat = categories[i];
                      final selected = _selectedCategory == cat;
                      return GestureDetector(
                        onTap: () => setState(() => _selectedCategory = cat),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color:
                                selected
                                    ? _buttonColor
                                    : (context.tokens.field),
                            borderRadius: BorderRadius.circular(12),
                            boxShadow:
                                selected
                                    ? [
                                      BoxShadow(
                                        color: _buttonColor.withValues(
                                          alpha: 0.3,
                                        ),
                                        blurRadius: 8,
                                        offset: const Offset(0, 4),
                                      ),
                                    ]
                                    : [],
                          ),
                          child: Text(
                            cat,
                            style: TextStyle(
                              color:
                                  selected
                                      ? Colors.white
                                      : (context.tokens.textSecondary),
                              fontWeight:
                                  selected ? FontWeight.w500 : FontWeight.w500,
                              fontSize: 13,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
            ],
            if (!widget.pendingTx.isTransfer) ...[
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color:
                      _saveToGlobalDB
                          ? _buttonColor.withValues(alpha: 0.08)
                          : (isDark
                              ? AppColors.darkElevated.withValues(alpha: 0.4)
                              : AppColors.lightElevated.withValues(alpha: 0.4)),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color:
                        _saveToGlobalDB
                            ? _buttonColor.withValues(alpha: 0.3)
                            : (isDark
                                ? Colors.white.withValues(alpha: 0.06)
                                : Colors.black.withValues(alpha: 0.06)),
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: _buttonColor.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(
                        LucideIcons.zap,
                        size: 18,
                        color: _buttonColor,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(
                                'Auto-Rule Trainer',
                                style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w700,
                                  color: context.tokens.textPrimary,
                                ),
                              ),
                              const SizedBox(width: 6),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 6,
                                  vertical: 2,
                                ),
                                decoration: BoxDecoration(
                                  color: _buttonColor.withValues(alpha: 0.18),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text(
                                  'SMART',
                                  style: TextStyle(
                                    fontSize: 9,
                                    fontWeight: FontWeight.w700,
                                    color: _buttonColor,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 2),
                          Text(
                            _saveToGlobalDB
                                ? 'Always auto-categorize future SMS from this payee'
                                : 'Rule trainer disabled for this payee',
                            style: TextStyle(
                              fontSize: 11,
                              color: context.tokens.textSecondary,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Switch.adaptive(
                      value: _saveToGlobalDB,
                      onChanged: (v) => setState(() => _saveToGlobalDB = v),
                      activeThumbColor: Colors.white,
                      activeTrackColor: SoftColors.control,
                    ),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 24),

            // 6) Actions (Ignore / Save)
            Row(
              children: [
                Expanded(
                  child: TextButton(
                    onPressed: () {
                      PendingVerificationHistoryService.markIgnored(
                        widget.pendingTx.id,
                      );
                      ref
                          .read(detectionQueueProvider.notifier)
                          .ignoreTransaction(widget.pendingTx.id);
                      Navigator.pop(context, 'ignore');
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Transaction ignored')),
                      );
                    },
                    style: TextButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                    child: Text(
                      'Ignore',
                      style: TextStyle(
                        color: context.tokens.textSecondary,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: _saveTransaction,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: SoftColors.control,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      elevation: 8,
                      shadowColor: _buttonColor.withValues(alpha: 0.4),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                    child: Text(
                      widget.pendingTx.isTransfer
                          ? (_isCashDeposit
                              ? 'Confirm Deposit'
                              : 'Confirm Withdraw')
                          : 'Save',
                      style: const TextStyle(fontWeight: FontWeight.w500),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
          ],
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final bool isDark;
  const _SectionTitle({required this.title, required this.isDark});

  @override
  Widget build(BuildContext context) {
    return Text(
      title.toUpperCase(),
      style: TextStyle(
        fontSize: 11,
        fontWeight: FontWeight.w500,
        letterSpacing: 1.2,
        color: context.tokens.textSecondary,
      ),
    );
  }
}

class _DetectedSummaryCard extends StatelessWidget {
  const _DetectedSummaryCard({
    required this.amountLabel,
    required this.merchantLine,
    required this.metaLine,
  });

  final String amountLabel;
  final String merchantLine;
  final String metaLine;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: t.card,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: t.border),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0F050D1A),
            blurRadius: 24,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        children: [
          Text(
            amountLabel,
            style: TextStyle(
              fontSize: 34,
              fontWeight: FontWeight.w800,
              letterSpacing: -1,
              color: t.textPrimary,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            merchantLine,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: t.textPrimary,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            metaLine,
            style: TextStyle(fontSize: 12, color: t.textSecondary),
          ),
        ],
      ),
    );
  }
}

class _DetectedDetailsCard extends StatelessWidget {
  const _DetectedDetailsCard({
    required this.account,
    required this.category,
    required this.purpose,
    required this.onAccount,
    required this.onCategory,
    required this.onPurpose,
    this.showCategory = true,
    this.showPurpose = true,
  });

  final bool showCategory;
  final bool showPurpose;
  final String account;
  final String category;
  final String purpose;
  final VoidCallback? onAccount;
  final VoidCallback? onCategory;
  final VoidCallback? onPurpose;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: t.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: t.border),
      ),
      child: Column(
        children: [
          _DetectedDetailRow(
            label: 'ACCOUNT',
            value: account,
            onTap: onAccount,
          ),
          if (showCategory)
            _DetectedDetailRow(
              label: 'CATEGORY',
              value: category,
              onTap: onCategory,
            ),
          if (showPurpose)
            _DetectedDetailRow(
              label: 'PURPOSE',
              value: purpose,
              onTap: onPurpose,
            ),
        ],
      ),
    );
  }
}

class _DetectedDetailRow extends StatelessWidget {
  const _DetectedDetailRow({
    required this.label,
    required this.value,
    required this.onTap,
  });

  final String label;
  final String value;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final row = Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        children: [
          SizedBox(
            width: 82,
            child: Text(
              label,
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w700,
                letterSpacing: 1,
                color: t.textSecondary,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: t.textPrimary,
              ),
            ),
          ),
          if (onTap != null) ...[
            const SizedBox(width: 6),
            Icon(LucideIcons.chevronRight, size: 15, color: t.textSecondary),
          ],
        ],
      ),
    );
    return onTap == null
        ? row
        : InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: row,
        );
  }
}

class _IncomeCelebrationBanner extends StatelessWidget {
  final double amount;
  final String title;

  const _IncomeCelebrationBanner({required this.amount, required this.title});

  @override
  Widget build(BuildContext context) {
    final isSalary = title.toLowerCase().contains('salary') || amount >= 5000;

    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0.85, end: 1.0),
      duration: const Duration(milliseconds: 600),
      curve: Curves.elasticOut,
      builder: (context, scale, child) {
        return Transform.scale(
          scale: scale,
          child: Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors:
                    isSalary
                        ? [const Color(0xFFF59E0B), const Color(0xFF10B981)]
                        : [
                          AppColors.income.withValues(alpha: 0.25),
                          AppColors.income.withValues(alpha: 0.1),
                        ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color:
                    isSalary
                        ? const Color(0xFFF59E0B)
                        : AppColors.income.withValues(alpha: 0.5),
                width: 1.2,
              ),
              boxShadow: [
                BoxShadow(
                  color: (isSalary ? const Color(0xFFF59E0B) : AppColors.income)
                      .withValues(alpha: 0.3),
                  blurRadius: 16,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  isSalary ? '🎉' : '💰',
                  style: const TextStyle(fontSize: 18),
                ),
                const SizedBox(width: 8),
                Text(
                  isSalary
                      ? 'SALARY / INCOME DETECTED'
                      : 'INCOME CREDIT RECEIVED',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: isSalary ? Colors.black : AppColors.income,
                    letterSpacing: 1.2,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

enum _SplitBy { category, purpose, both }

/// One editable split row in the detected-SMS modal.
class _SplitLine {
  _SplitLine(String amount, this.category, this.purpose)
    : amount = TextEditingController(text: amount);

  final TextEditingController amount;
  String? category;
  String? purpose;

  void dispose() => amount.dispose();
}
