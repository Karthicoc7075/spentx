import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../../core/services/auth_service.dart';
import '../../../core/services/bank_allowlist_service.dart';
import '../../../core/utils/bank_keywords.dart';
import '../sms_service.dart';
import 'sms_detection_debug_log.dart';
import 'sms_detection_pipeline.dart';
import 'sms_seen_store.dart';

/// Re-runs bank SMS from the last few days that never reached the pipeline —
/// the app was killed, the process was swiped away, or an older build dropped
/// them. Runs on app open / resume for a signed-in user with automatic
/// detection on and READ_SMS already granted; it never asks for permission.
///
/// Only messages from a bank sender header (AX-HDFCBK-S, VM-SBIUPI, ...) that
/// the user's bank allowlist accepts are considered. A message is skipped when
/// it was already seen by the pipeline, or its text is already stored on a
/// transaction, a pending/detected item or an ignored item. Everything that remains goes through [SmsDetectionPipeline] in
/// background mode, where the reference-id and amount+day duplicate guards of
/// [AutoRuleEngine] still apply — so a spend the user already added by hand is
/// not added twice.
class SmsInboxCatchUp {
  SmsInboxCatchUp._();

  static const lookback = SmsService.catchUpWindow;
  static const throttle = Duration(minutes: 10);
  static const _lastRunKey = 'sms_inbox_catch_up_last_run';

  static bool _running = false;

  /// Returns how many messages were handed to the pipeline.
  static Future<int> runIfDue({bool force = false}) async {
    if (_running) return 0;
    if (kIsWeb || defaultTargetPlatform != TargetPlatform.android) return 0;
    if (!AuthService.isSignedIn || AuthService.syncHeldForAccountSwitch) {
      return 0;
    }
    if (!SmsDetectionPipeline.isAutoDetectionEnabled) return 0;
    if (!Hive.isBoxOpen('settings')) return 0;
    if (!await Permission.sms.isGranted) return 0;

    final settings = Hive.box('settings');
    final now = DateTime.now();
    final last = DateTime.tryParse(settings.get(_lastRunKey)?.toString() ?? '');
    if (!force && last != null && now.difference(last) < throttle) return 0;

    _running = true;
    try {
      await settings.put(_lastRunKey, now.toIso8601String());

      // Never import messages from before this device's first signed-in use.
      var since = now.subtract(lookback);
      final activityStart = SmsService.activityStartTime();
      if (activityStart != null && activityStart.isAfter(since)) {
        since = activityStart;
      }

      final rows = await SmsService.readInboxRaw(since: since, limit: 300);
      if (rows.isEmpty) return 0;

      final known = _knownBodies();
      var handed = 0;
      // Oldest first, so pending items keep their real order.
      final ordered = rows.toList()..sort((a, b) => a.date.compareTo(b.date));
      for (final row in ordered) {
        if (row.date.isBefore(since)) continue;
        if (bankKeyForSender(row.sender).isEmpty) continue;
        if (SmsSeenStore.contains(row.body)) continue;
        if (known.contains(_norm(row.body))) continue;
        if (BankAllowlistService.evaluate(row.body, sender: row.sender) !=
            AllowResult.allowed) {
          continue;
        }

        await SmsDetectionPipeline.processInbound(
          rawMessage: row.body,
          sender: row.sender,
          source: SmsDetectionSource.catchUp,
          receivedAt: row.date,
          preferBackground: true,
        );
        known.add(_norm(row.body));
        handed++;
      }

      if (handed > 0) {
        await SmsDetectionDebugLog.log(
          level: SmsDebugLogLevel.info,
          message: 'Inbox catch-up: $handed missed bank SMS re-checked',
          source: SmsDetectionSource.catchUp.label,
        );
      }
      return handed;
    } catch (e) {
      debugPrint('SMS inbox catch-up failed: $e');
      return 0;
    } finally {
      _running = false;
    }
  }

  static String _norm(String body) =>
      body.trim().replaceAll(RegExp(r'\s+'), ' ').toLowerCase();

  /// Normalised SMS text already stored anywhere a detection can end up.
  static Set<String> _knownBodies() {
    final out = <String>{};
    void addRaw(dynamic v) {
      if (v is String && v.trim().isNotEmpty) out.add(_norm(v));
    }

    void scanMaps(Iterable<dynamic> values) {
      for (final e in values) {
        if (e is Map) addRaw(e['rawMessage']);
      }
    }

    try {
      if (Hive.isBoxOpen('transactions')) {
        final list = Hive.box('transactions').get('list', defaultValue: []);
        if (list is List) scanMaps(list);
      }
      if (Hive.isBoxOpen('detected_sms_box')) {
        scanMaps(Hive.box('detected_sms_box').values);
      }
      if (Hive.isBoxOpen('ignored_detections')) {
        final history = Hive.box(
          'ignored_detections',
        ).get('history', defaultValue: []);
        if (history is List) scanMaps(history);
      }
    } catch (_) {}
    return out;
  }
}
