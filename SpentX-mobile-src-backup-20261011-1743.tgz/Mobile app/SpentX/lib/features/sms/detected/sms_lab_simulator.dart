import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/providers/transaction_provider.dart' as model;
import '../../../core/providers/outing_provider.dart';
import '../../sms_parser/models/transaction_parsed.dart';
import '../../sms_parser/sms_direction_helper.dart';
import '../rules/engine/sms_rule_engine.dart';
import 'sms_detection_pipeline.dart';
import 'detection_queue.dart';
import 'pending_verification_presenter.dart';
import '../../../core/services/notification_click_handler.dart';
import '../sms_notification.dart';
import 'sms_pipeline_test_runner.dart';
import 'detected_sms_storage.dart';
import 'sms_lab_native_scheduler.dart';

enum SmsLabFlowMode { background, foreground }

enum SmsLabLogLevel { info, success, warning, error }

class SmsLabLogEntry {
  final DateTime time;
  final String message;
  final SmsLabLogLevel level;

  const SmsLabLogEntry({
    required this.time,
    required this.message,
    this.level = SmsLabLogLevel.info,
  });
}

/// Real bank SMS samples for lab testing (debit / credit — not transfer/ATM).
class SmsLabSamples {
  static const List<({String label, String sms, String kind})> bankOnly = [
    (
      label: 'HDFC UPI Debit',
      sms:
          'HDFC Bank: Rs.450.00 debited from A/c **1234 on 04-06-26 to VPA zomato@paytm (UPI Ref 614556266884). Avl Bal: Rs.12,450.00',
      kind: 'debit',
    ),
    (
      label: 'ICICI Credit',
      sms:
          'ICICI Bank: INR 5000.00 credited to A/c XX9876 on 04-Jun-26. Info: SALARY CREDIT. Available Balance: INR 45,000.00',
      kind: 'credit',
    ),
    (
      label: 'SBI Card Spent',
      sms:
          'Dear Customer, Rs.1200.00 spent on your SBI Credit Card ending 4321 at AMAZON INDIA on 04-06-26. Available limit: Rs.50,000',
      kind: 'debit',
    ),
    (
      label: 'Axis UPI Sent',
      sms:
          'Axis Bank: INR 299.00 debited from A/c XX5566 on 04-06-26. Sent to SWIGGY via UPI (Ref 998877665544). Bal INR 8,200',
      kind: 'debit',
    ),
  ];
}

final smsLabLogsProvider = StateProvider<List<SmsLabLogEntry>>((ref) => []);
final smsLabRunningProvider = StateProvider<bool>((ref) => false);
final smsLabCountdownProvider = StateProvider<int?>((ref) => null);
final smsLabScheduledAtProvider = StateProvider<DateTime?>((ref) => null);

class SmsLabSimulator {
  static const String autoDetectionOffMessage =
      'Automatic SMS Detection is turned OFF. Enable it to detect SMS messages.';

  static Timer? _countdownTimer;
  static Timer? _runTimer;

  static void cancel() {
    _countdownTimer?.cancel();
    _runTimer?.cancel();
    _countdownTimer = null;
    _runTimer = null;
  }

  static void _log(WidgetRef ref, String message, {SmsLabLogLevel level = SmsLabLogLevel.info}) {
    final entry = SmsLabLogEntry(time: DateTime.now(), message: message, level: level);
    ref.read(smsLabLogsProvider.notifier).update((logs) => [entry, ...logs].take(80).toList());
  }

  static void clearLogs(WidgetRef ref) {
    ref.read(smsLabLogsProvider.notifier).state = [];
  }

  /// Same gate as live SMS — lab does not bypass [auto_detection].
  static bool _ensureAutoDetectionEnabled(BuildContext context, WidgetRef ref) {
    if (SmsDetectionPipeline.isAutoDetectionEnabled) return true;

    _log(ref, autoDetectionOffMessage, level: SmsLabLogLevel.warning);
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(autoDetectionOffMessage),
          behavior: SnackBarBehavior.floating,
          duration: Duration(seconds: 4),
        ),
      );
    }
    return false;
  }

  static Map<String, dynamic> _payloadFromParsed(TransactionParsed parsed, String rawSms) {
    return {
      'amount': parsed.amount,
      'merchant': parsed.name,
      'bank': parsed.bank,
      'rawText': rawSms,
      'type': SmsDirectionHelper.typeLabel(rawMessage: rawSms, parsed: parsed),
      'mode': parsed.mode.name,
      'referenceId': parsed.referenceId,
    };
  }

  /// Runs the same [SmsDetectionPipeline] as a real incoming SMS (no force bypass).
  static Future<void> runRealFlowTest({
    required WidgetRef ref,
    required BuildContext context,
    required String rawSms,
    required Duration delay,
    required SmsLabFlowMode mode,
    required bool skipTransfers,
    bool forceVerifyPopup = false,
  }) async {
    cancel();

    if (!_ensureAutoDetectionEnabled(context, ref)) return;

    final trimmed = rawSms.trim();
    if (trimmed.isEmpty) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Paste a bank SMS to test')),
        );
      }
      return;
    }

    clearLogs(ref);
    ref.read(smsLabRunningProvider.notifier).state = true;
    ref.read(smsLabCountdownProvider.notifier).state = delay.inSeconds > 0 ? delay.inSeconds : null;

    _log(ref, '━━━ SMS Detection Lab — Real Flow Test ━━━');
    _log(ref, 'Using live pipeline (same rules & validation as real-time SMS)...');

    if (skipTransfers && SmsDirectionHelper.isTransferSms(trimmed)) {
      _log(
        ref,
        'Skipped: transfer/ATM SMS (enable "Include transfers" to test).',
        level: SmsLabLogLevel.warning,
      );
      ref.read(smsLabRunningProvider.notifier).state = false;
      ref.read(smsLabCountdownProvider.notifier).state = null;
      return;
    }

    if (mode == SmsLabFlowMode.background && delay > Duration.zero) {
      await _scheduleNativeBackground(
        ref: ref,
        context: context,
        rawSms: trimmed,
        delay: delay,
      );
      return;
    }

    if (delay > Duration.zero && mode == SmsLabFlowMode.foreground) {
      _log(ref, 'Delay ${delay.inSeconds}s — keep app open (foreground)...');
      var remaining = delay.inSeconds;
      final completer = Completer<void>();
      _countdownTimer = Timer.periodic(const Duration(seconds: 1), (t) {
        remaining--;
        ref.read(smsLabCountdownProvider.notifier).state = remaining > 0 ? remaining : null;
        if (remaining <= 0) {
          t.cancel();
          if (!completer.isCompleted) completer.complete();
        }
      });
      await completer.future;
    }

    if (!context.mounted) {
      ref.read(smsLabRunningProvider.notifier).state = false;
      return;
    }

    try {
      await _executeLivePipeline(
        ref: ref,
        context: context,
        rawSms: trimmed,
        mode: mode,
        showVerifyPopup: forceVerifyPopup && mode == SmsLabFlowMode.foreground,
      );
    } finally {
      ref.read(smsLabRunningProvider.notifier).state = false;
      ref.read(smsLabCountdownProvider.notifier).state = null;
    }
  }

  /// Android AlarmManager — fires after delay; respects auto_detection natively.
  static Future<void> _scheduleNativeBackground({
    required WidgetRef ref,
    required BuildContext context,
    required String rawSms,
    required Duration delay,
  }) async {
    if (!_ensureAutoDetectionEnabled(context, ref)) {
      ref.read(smsLabRunningProvider.notifier).state = false;
      ref.read(smsLabCountdownProvider.notifier).state = null;
      return;
    }

    final parsed = SmsRuleEngine.parse(rawSms, smsReceivedTime: DateTime.now());
    if (parsed == null) {
      _log(ref, 'Cannot schedule: SMS parse failed.', level: SmsLabLogLevel.error);
      ref.read(smsLabRunningProvider.notifier).state = false;
      ref.read(smsLabCountdownProvider.notifier).state = null;
      return;
    }

    if (!SmsLabNativeScheduler.isSupported) {
      _log(ref, 'Native scheduler only on Android — using in-app timer instead.', level: SmsLabLogLevel.warning);
      await _waitWithCountdown(ref, delay);
      if (context.mounted) {
        await _executeLivePipeline(
          ref: ref,
          context: context,
          rawSms: rawSms,
          mode: SmsLabFlowMode.background,
        );
      }
      ref.read(smsLabRunningProvider.notifier).state = false;
      return;
    }

    final payload = _payloadFromParsed(parsed, rawSms);
    try {
      final fireAtMs = await SmsLabNativeScheduler.scheduleBackgroundTest(
        payload: payload,
        delaySeconds: delay.inSeconds,
      );
      final fireAt = fireAtMs != null
          ? DateTime.fromMillisecondsSinceEpoch(fireAtMs)
          : DateTime.now().add(delay);

      ref.read(smsLabScheduledAtProvider.notifier).state = fireAt;
      ref.read(smsLabCountdownProvider.notifier).state = delay.inSeconds;

      _log(
        ref,
        'Scheduled native alarm in ${delay.inSeconds}s (fires ${fireAt.hour}:${fireAt.minute.toString().padLeft(2, '0')}:${fireAt.second.toString().padLeft(2, '0')})',
        level: SmsLabLogLevel.success,
      );
      _log(
        ref,
        'Swipe app from recents — notification only if auto-detection stays ON.',
        level: SmsLabLogLevel.warning,
      );

      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Scheduled in ${delay.inSeconds}s — swipe app from recents NOW'),
            backgroundColor: Colors.amber.shade800,
            behavior: SnackBarBehavior.floating,
            duration: const Duration(seconds: 6),
          ),
        );
      }
    } catch (e) {
      _log(ref, 'Schedule failed: $e', level: SmsLabLogLevel.error);
    } finally {
      ref.read(smsLabRunningProvider.notifier).state = false;
      ref.read(smsLabCountdownProvider.notifier).state = null;
    }
  }

  static Future<void> _waitWithCountdown(WidgetRef ref, Duration delay) async {
    var remaining = delay.inSeconds;
    final completer = Completer<void>();
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      remaining--;
      ref.read(smsLabCountdownProvider.notifier).state = remaining > 0 ? remaining : null;
      if (remaining <= 0) {
        t.cancel();
        if (!completer.isCompleted) completer.complete();
      }
    });
    await completer.future;
  }

  static Future<void> cancelScheduled(WidgetRef ref) async {
    cancel();
    await SmsLabNativeScheduler.cancelScheduledTest();
    ref.read(smsLabScheduledAtProvider.notifier).state = null;
    ref.read(smsLabCountdownProvider.notifier).state = null;
    ref.read(smsLabRunningProvider.notifier).state = false;
    _log(ref, 'Cancelled scheduled lab test.', level: SmsLabLogLevel.warning);
  }

  /// Identical entry to live SMS: [SmsDetectionPipeline.processInbound] only.
  static Future<void> _executeLivePipeline({
    required WidgetRef ref,
    required BuildContext context,
    required String rawSms,
    required SmsLabFlowMode mode,
    bool showVerifyPopup = false,
  }) async {
    if (!_ensureAutoDetectionEnabled(context, ref)) return;

    if (mode == SmsLabFlowMode.background) {
      SmsDetectionPipeline.clearForegroundBinding();
      _log(ref, 'STEP: Background path (same as app closed / native payload)...');
    } else {
      SmsDetectionPipeline.bindForeground(ref: ref, context: context);
      _log(ref, 'STEP: Foreground path (same as live SMS while app open)...');
    }

    final outcome = await SmsDetectionPipeline.processInbound(
      rawMessage: rawSms,
      source: SmsDetectionSource.lab,
      showVerifyPopup: showVerifyPopup,
    );

    if (context.mounted && mode == SmsLabFlowMode.foreground) {
      SmsDetectionPipeline.bindForeground(ref: ref, context: context);
    }

    ref.invalidate(model.transactionProvider);
    ref.invalidate(outingProvider);
    ref.read(detectionQueueProvider.notifier).refresh();

    _logPipelineOutcome(ref, outcome);

    if (!context.mounted) return;

    final snackMessage = switch (outcome) {
      SmsPipelineOutcome.autoAdded => 'Auto-added (known merchant)',
      SmsPipelineOutcome.pendingVerification => 'Pending verification — check notification',
      SmsPipelineOutcome.accountDiscovery =>
        'Unknown account — suggested in Accounts, no transaction created',
      SmsPipelineOutcome.parseFailed => 'Parse failed — not a bank transaction SMS',
      SmsPipelineOutcome.blocked => 'Blocked by user rule',
      SmsPipelineOutcome.autoDetectionOff => autoDetectionOffMessage,
      SmsPipelineOutcome.skippedDuplicate => 'Duplicate — skipped',
      SmsPipelineOutcome.skippedEmpty => 'Empty message',
    };

    if (outcome != SmsPipelineOutcome.skippedDuplicate ||
        ref.read(detectionQueueProvider).isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(snackMessage),
          backgroundColor: outcome == SmsPipelineOutcome.autoAdded
              ? AppColors.primary
              : outcome == SmsPipelineOutcome.pendingVerification
                  ? AppColors.primary
                  : Colors.orange.shade800,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  static void _logPipelineOutcome(WidgetRef ref, SmsPipelineOutcome outcome) {
    switch (outcome) {
      case SmsPipelineOutcome.autoAdded:
        _log(
          ref,
          'Result: auto-added transaction (same as live known merchant).',
          level: SmsLabLogLevel.success,
        );
      case SmsPipelineOutcome.pendingVerification:
        _log(
          ref,
          'Result: pending queue + verification notification (same as live unknown merchant).',
          level: SmsLabLogLevel.success,
        );
        _log(ref, 'Tap notification or use "Simulate notification tap" on Home.');
      case SmsPipelineOutcome.accountDiscovery:
        _log(
          ref,
          'Result: parsed, but for an account you have not added — proposed '
          'in Accounts. No transaction was created.',
          level: SmsLabLogLevel.warning,
        );
        _log(ref, 'Review it under Accounts → accounts found in your SMS.');
      case SmsPipelineOutcome.parseFailed:
        _log(ref, 'Result: parse failed.', level: SmsLabLogLevel.error);
      case SmsPipelineOutcome.blocked:
        _log(ref, 'Result: blocked by user rule.', level: SmsLabLogLevel.warning);
      case SmsPipelineOutcome.autoDetectionOff:
        _log(ref, autoDetectionOffMessage, level: SmsLabLogLevel.warning);
      case SmsPipelineOutcome.skippedDuplicate:
        _log(ref, 'Result: duplicate SMS skipped.', level: SmsLabLogLevel.warning);
      case SmsPipelineOutcome.skippedEmpty:
        _log(ref, 'Result: empty SMS.', level: SmsLabLogLevel.warning);
    }
  }

  static Future<void> simulateNotificationTap({
    required WidgetRef ref,
    required BuildContext context,
  }) async {
    if (!_ensureAutoDetectionEnabled(context, ref)) return;

    ref.read(detectionQueueProvider.notifier).refresh();
    final queue = ref.read(detectionQueueProvider);

    if (queue.isEmpty) {
      _log(ref, 'No pending items in queue — run a background test first.', level: SmsLabLogLevel.warning);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Pending queue is empty'),
            backgroundColor: Colors.orangeAccent,
          ),
        );
      }
      return;
    }

    final txId = queue.first;
    _log(ref, 'Simulating notification tap → Home → verify (id: $txId)...');

    final payload = jsonEncode({'transactionId': txId, 'pending': true});
    NotificationClickHandler.handle(ref: ref, payload: payload);
    if (context.mounted) {
      context.go('/home');
    }
    _log(ref, 'Notification tap flow completed.', level: SmsLabLogLevel.success);
  }

  /// Opens verify popup for the latest pending item without re-running detection.
  static Future<void> openVerifyPopup({
    required WidgetRef ref,
    required BuildContext context,
  }) async {
    if (!_ensureAutoDetectionEnabled(context, ref)) return;

    ref.read(detectionQueueProvider.notifier).refresh();
    final queue = ref.read(detectionQueueProvider);
    if (queue.isEmpty) {
      _log(ref, 'No pending items — run Simulate Detection first.', level: SmsLabLogLevel.warning);
      return;
    }

    final txId = queue.first;
    _log(ref, 'Opening verify popup for $txId (no re-detection)...');
    if (context.mounted) {
      await PendingVerificationPresenter.processQueueIfNeeded(
        context: context,
        ref: ref,
        targetTransactionId: txId,
      );
    }
  }

  static Future<void> simulateNotification({
    required WidgetRef ref,
    required BuildContext context,
    required SmsPipelineTestResult? preview,
  }) async {
    if (!_ensureAutoDetectionEnabled(context, ref)) return;
    if (preview == null || !preview.detectionSuccess) {
      _log(ref, 'Run Detection first to preview notification.', level: SmsLabLogLevel.warning);
      return;
    }
    if (preview.isBlocked || preview.isDuplicate) {
      _log(ref, 'No notification — blocked or duplicate.', level: SmsLabLogLevel.warning);
      return;
    }

    final type = preview.parsedDirection ?? 'debit';
    if (preview.merchantFound) {
      await SmsNotificationService.showTransactionAutoAdded(
        amount: preview.parsedAmount ?? 0,
        merchant: preview.mappedMerchantName ?? preview.parsedMerchant ?? 'Merchant',
        bank: preview.parsedBank ?? 'Bank',
        type: type,
      );
      _log(ref, 'Notification Sent: ${preview.notificationTitle}', level: SmsLabLogLevel.success);
    } else {
      await SmsNotificationService.showPendingNotification(
        amount: preview.parsedAmount ?? 0,
        merchant: preview.parsedMerchant ?? 'Unknown',
        bank: preview.parsedBank ?? 'Bank',
        type: type,
      );
      _log(ref, 'Notification Sent: ${preview.notificationTitle} • ${preview.notificationBody}', level: SmsLabLogLevel.success);
    }
  }

  static Future<void> simulateTransactionSave({
    required WidgetRef ref,
    required BuildContext context,
    required SmsPipelineTestResult? preview,
  }) async {
    if (!_ensureAutoDetectionEnabled(context, ref)) return;

    if (preview?.willSave == true && preview!.merchantFound) {
      await runRealFlowTest(
        ref: ref,
        context: context,
        rawSms: preview.rawSms,
        delay: Duration.zero,
        mode: SmsLabFlowMode.background,
        skipTransfers: false,
      );
      _log(ref, 'Transaction Saved (production auto-save path)', level: SmsLabLogLevel.success);
      return;
    }

    ref.read(detectionQueueProvider.notifier).refresh();
    final queue = ref.read(detectionQueueProvider);
    if (queue.isEmpty) {
      _log(ref, 'No pending item — run Simulate Detection for unknown merchant first.', level: SmsLabLogLevel.warning);
      return;
    }

    final txId = queue.first;
    final pending = DetectedSmsStorage.get(txId);
    if (pending == null) return;

    ref.read(detectionQueueProvider.notifier).confirmTransaction(
          txId,
          pending.amount,
          preview?.mappedMerchantName ?? pending.receiver,
          preview?.mappedPurpose ?? 'Personal',
          pending.isExpense,
          preview?.mappedCategory ?? 'Other',
          isTransfer: pending.isTransfer,
          merchantIdentifier: preview?.merchantIdentifier,
          upiId: pending.upiId,
        );
    _log(ref, 'Transaction Saved via verify confirm (lab simulation)', level: SmsLabLogLevel.success);
  }

  static Future<void> clearTestPending(WidgetRef ref) async {
    final queue = List<String>.from(ref.read(detectionQueueProvider));
    for (final id in queue) {
      DetectedSmsStorage.remove(id);
      ref.read(detectionQueueProvider.notifier).removePending(id);
    }
    _log(ref, 'Cleared ${queue.length} pending test item(s).', level: SmsLabLogLevel.warning);
  }
}