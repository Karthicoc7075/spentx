import 'package:flutter/material.dart';
import '../rules/presentation/block_sms_screen.dart';

/// Opens the full Block SMS flow from the Detection Lab.
class SmsLabBlockRuleSheet extends StatelessWidget {
  final String initialSms;

  const SmsLabBlockRuleSheet({super.key, required this.initialSms});

  static Future<bool?> show(BuildContext context, {required String initialSms}) {
    return Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => BlockSmsScreen(initialSms: initialSms),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlockSmsScreen(initialSms: initialSms);
  }
}