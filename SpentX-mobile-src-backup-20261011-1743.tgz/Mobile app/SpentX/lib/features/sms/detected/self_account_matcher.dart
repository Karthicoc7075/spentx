import 'package:hive_flutter/hive_flutter.dart';

/// True when a payee/name extracted from an SMS matches one of the user's
/// own registered accounts — i.e. this is really a self-transfer, not a
/// payment to another person.
///
/// Reads the same Hive-backed `onboardingAccounts` list
/// `AutoRuleEngine.resolveAccountName` uses (rather than the Riverpod
/// `userStateProvider`), so this works from background isolates too, where
/// there is no live `WidgetRef`.
class SelfAccountMatcher {
  SelfAccountMatcher._();

  static bool matches(String? payee) {
    final target = (payee ?? '').trim().toLowerCase();
    if (target.isEmpty) return false;
    try {
      final raw = Hive.box('settings').get('onboardingAccounts');
      if (raw is! List) return false;
      for (final entry in raw) {
        final name = (Map<dynamic, dynamic>.from(entry as Map)['name'] ?? '')
            .toString()
            .trim()
            .toLowerCase();
        if (name.isNotEmpty && name == target) return true;
      }
    } catch (_) {}
    return false;
  }
}
