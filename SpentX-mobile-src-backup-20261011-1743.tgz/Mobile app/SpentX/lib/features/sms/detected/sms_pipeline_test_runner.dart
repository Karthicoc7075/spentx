import 'package:hive_flutter/hive_flutter.dart';
import 'package:intl/intl.dart';

import '../../sms_parser/models/transaction_parsed.dart';
import '../../sms_parser/sms_direction_helper.dart';
import '../rules/engine/sms_rule_engine.dart';
import '../rules/engine/sms_template_engine.dart';
import '../rules/models/block_rule.dart';
import '../rules/models/sms_template_rule.dart';
import '../rules/sms_hive_boxes.dart';
import 'active_outing_helper.dart';
import 'sms_merchant_matcher.dart';
import '../sms_notification_copy.dart';

class SmsPipelineTestResult {
  final String rawSms;
  final bool detectionSuccess;
  final bool isBlocked;
  final String? blockReason;
  final String? blockRuleName;

  final bool blockRuleMatched;
  final String? templateRuleName;
  final String parserUsed;

  final double? parsedAmount;
  final String? parsedDirection;
  final String? parsedMerchant;
  final String? parsedBank;
  final String? parsedAccountLast4;
  final String? parsedUpi;
  final String? parsedReferenceId;
  final DateTime? parsedDateTime;
  final String? parsedDate;
  final String? parsedTime;

  final String? merchantIdentifier;
  final bool merchantFound;
  final String? mappedMerchantName;
  final String? mappedCategory;
  final String? mappedPurpose;

  final String previewTitle;
  final String previewAmount;
  final String previewType;
  final String previewCategory;
  final String previewPurpose;
  final String previewAccount;

  final bool isActiveOutingDetected;
  final String? outingTitle;
  final bool willLinkOuting;
  final String? outingLinkReason;

  final String notificationTitle;
  final String notificationBody;

  final bool willSave;
  final bool isPendingVerification;
  final bool isDuplicate;
  final String? saveReason;
  final String? duplicateReason;

  final List<String> debugLogs;
  final List<String> errors;

  const SmsPipelineTestResult({
    required this.rawSms,
    required this.detectionSuccess,
    required this.isBlocked,
    this.blockReason,
    this.blockRuleName,
    required this.blockRuleMatched,
    this.templateRuleName,
    required this.parserUsed,
    this.parsedAmount,
    this.parsedDirection,
    this.parsedMerchant,
    this.parsedBank,
    this.parsedAccountLast4,
    this.parsedUpi,
    this.parsedReferenceId,
    this.parsedDateTime,
    this.parsedDate,
    this.parsedTime,
    this.merchantIdentifier,
    required this.merchantFound,
    this.mappedMerchantName,
    this.mappedCategory,
    this.mappedPurpose,
    required this.previewTitle,
    required this.previewAmount,
    required this.previewType,
    required this.previewCategory,
    required this.previewPurpose,
    required this.previewAccount,
    required this.isActiveOutingDetected,
    this.outingTitle,
    required this.willLinkOuting,
    this.outingLinkReason,
    required this.notificationTitle,
    required this.notificationBody,
    required this.willSave,
    required this.isPendingVerification,
    required this.isDuplicate,
    this.saveReason,
    this.duplicateReason,
    required this.debugLogs,
    required this.errors,
  });

  factory SmsPipelineTestResult.empty(String sms) => SmsPipelineTestResult(
        rawSms: sms,
        detectionSuccess: false,
        isBlocked: false,
        blockRuleMatched: false,
        parserUsed: 'Not Used',
        merchantFound: false,
        previewTitle: '—',
        previewAmount: '—',
        previewType: '—',
        previewCategory: '—',
        previewPurpose: '—',
        previewAccount: '—',
        isActiveOutingDetected: false,
        willLinkOuting: false,
        notificationTitle: '—',
        notificationBody: '—',
        willSave: false,
        isPendingVerification: false,
        isDuplicate: false,
        debugLogs: const [],
        errors: const ['Paste an SMS and tap Run Detection'],
      );
}

class SmsLabRuleTestResult {
  final bool matched;
  final String? ruleName;
  final double? amount;
  final String? title;
  final String? type;
  final String? bank;

  const SmsLabRuleTestResult({
    required this.matched,
    this.ruleName,
    this.amount,
    this.title,
    this.type,
    this.bank,
  });
}

class SmsPipelineTestRunner {
  static const sourceLabel = 'SMS Detection Lab';

  static SmsPipelineTestResult run(String sms) {
    final logs = <String>['SMS Received'];
    final errors = <String>[];
    final trimmed = sms.trim();
    if (trimmed.isEmpty) return SmsPipelineTestResult.empty(sms);

    final blockHit = _findBlockMatch(trimmed);
    if (blockHit != null) {
      logs.add('Block Rule Matched: ${blockHit.rule.displayName}');
      return SmsPipelineTestResult(
        rawSms: trimmed,
        detectionSuccess: false,
        isBlocked: true,
        blockReason: blockHit.reason,
        blockRuleName: blockHit.rule.displayName,
        blockRuleMatched: true,
        parserUsed: 'Not Used',
        merchantFound: false,
        previewTitle: '—',
        previewAmount: '—',
        previewType: '—',
        previewCategory: '—',
        previewPurpose: '—',
        previewAccount: '—',
        isActiveOutingDetected: false,
        willLinkOuting: false,
        notificationTitle: 'Blocked',
        notificationBody: blockHit.reason ?? 'Matched block rule',
        willSave: false,
        isPendingVerification: false,
        isDuplicate: false,
        saveReason: 'Blocked by rule — will not save',
        debugLogs: logs,
        errors: errors,
      );
    }
    logs.add('Block Rule: No match');

    final parsed = SmsRuleEngine.parse(trimmed, smsReceivedTime: DateTime.now());
    final dbg = SmsRuleEngine.lastParseDebug;

    String parserUsed = 'Not Used';
    String? templateRuleName;
    if (dbg != null) {
      switch (dbg.source) {
        case 'template':
          parserUsed = 'Template Rule';
          templateRuleName = _templateName(dbg.matchedTemplate);
          logs.add('Template Rule Matched: ${templateRuleName ?? dbg.matchedTemplate}');
        case 'regex_rule':
          parserUsed = 'Regex Rule';
          logs.add('Regex Rule Matched: ${dbg.matchedRule ?? "—"}');
        case 'fallback_parser':
          parserUsed = 'Default Parser';
          logs.add('Default Parser Used');
        default:
          parserUsed = dbg.source;
      }
    }

    if (parsed == null) {
      errors.add('Parse failed — not recognized as bank transaction SMS');
      logs.add('Detection Failed');
      return SmsPipelineTestResult(
        rawSms: trimmed,
        detectionSuccess: false,
        isBlocked: false,
        blockRuleMatched: false,
        templateRuleName: templateRuleName,
        parserUsed: parserUsed,
        merchantFound: false,
        previewTitle: '—',
        previewAmount: '—',
        previewType: '—',
        previewCategory: '—',
        previewPurpose: '—',
        previewAccount: '—',
        isActiveOutingDetected: false,
        willLinkOuting: false,
        notificationTitle: 'Parse Failed',
        notificationBody: 'No transaction detected',
        willSave: false,
        isPendingVerification: false,
        isDuplicate: false,
        saveReason: 'Parse failed',
        debugLogs: logs,
        errors: errors,
      );
    }

    logs.add('Detection Success');

    final typeLabel = SmsDirectionHelper.typeLabel(rawMessage: trimmed, parsed: parsed);
    final resolved = SmsMerchantMatcher.resolve(rawMessage: trimmed, parsed: parsed);
    final identifier = SmsMerchantMatcher.merchantKey(
      upiId: resolved.upiId,
      rawIdentifier: resolved.rawIdentifier,
      displayName: resolved.displayName,
    );

    final merchantFound = resolved.isKnownMerchant;
    final merchantRule = resolved.matchedRule;
    final displayName = merchantRule?.displayName ?? resolved.displayName;
    final category = merchantRule?.defaultCategory ?? 'Other';
    final purpose = merchantRule?.defaultPurposeType ?? 'Personal';

    if (merchantFound) {
      logs.add('Merchant Found: $displayName');
    } else {
      logs.add('Merchant Lookup Failed — verification required');
    }

    final outingLink = ActiveOutingHelper.resolve(
      isExpense: resolved.isExpense,
      isTransfer: resolved.isTransfer,
      transactionDate: parsed.dateTime,
    );
    final willLink = outingLink != null;
    final outingReason = willLink
        ? 'Active outing "${outingLink.title}" covers transaction date'
        : resolved.isTransfer
            ? 'Transfer — outing link skipped'
            : (resolved.isExpense
                ? 'No active outing for this date'
                : 'Credit — outing link skipped');

    if (willLink) logs.add('Outing Linked: ${outingLink.title}');

    final dup = _checkDuplicate(parsed: parsed, rawMessage: trimmed);
    if (dup.isDuplicate) logs.add('Duplicate Found: ${dup.reason}');

    final isPending = !merchantFound && !dup.isDuplicate;
    final willSave = merchantFound && !dup.isDuplicate;

    String notifTitle;
    String notifBody;
    if (!dup.isDuplicate) {
      final copy = SmsNotificationCopy.build(
        type: typeLabel,
        amount: parsed.amount,
        merchantExists: merchantFound,
        merchantTitle: merchantFound ? displayName : null,
        payee: merchantFound ? null : resolved.displayName,
        bank: parsed.bank,
      );
      notifTitle = copy.title;
      notifBody = copy.body;
      logs.add(
        'Notification Sent: ${SmsNotificationCopy.displayLine(title: notifTitle, body: notifBody)}',
      );
    } else {
      notifTitle = '—';
      notifBody = dup.reason ?? 'Duplicate';
    }

    String? saveReason;
    if (dup.isDuplicate) {
      saveReason = dup.reason;
    } else if (willSave) {
      saveReason = 'Known merchant — auto save';
      logs.add('Transaction Saved (auto)');
    } else if (isPending) {
      saveReason = 'Unknown merchant — pending verification';
    }

    final dt = parsed.dateTime;
    return SmsPipelineTestResult(
      rawSms: trimmed,
      detectionSuccess: true,
      isBlocked: false,
      blockRuleMatched: false,
      templateRuleName: templateRuleName,
      parserUsed: parserUsed,
      parsedAmount: parsed.amount,
      parsedDirection: typeLabel,
      parsedMerchant: parsed.name,
      parsedBank: parsed.bank,
      parsedAccountLast4: parsed.accountLast4,
      parsedUpi: parsed.upiId,
      parsedReferenceId: parsed.referenceId,
      parsedDateTime: dt,
      // Use expected display format for Detection Lab (e.g. 08-Jun-2026)
      parsedDate: DateFormat('dd-MMM-yyyy').format(dt),
      parsedTime: DateFormat('HH:mm:ss').format(dt),
      merchantIdentifier: identifier,
      merchantFound: merchantFound,
      mappedMerchantName: displayName,
      mappedCategory: category,
      mappedPurpose: purpose,
      previewTitle: displayName,
      previewAmount: '₹${parsed.amount.toStringAsFixed(0)}',
      previewType: _typeDisplay(typeLabel),
      previewCategory: category,
      previewPurpose: purpose,
      previewAccount: parsed.bank,
      isActiveOutingDetected: outingLink != null,
      outingTitle: outingLink?.title,
      willLinkOuting: willLink,
      outingLinkReason: outingReason,
      notificationTitle: notifTitle,
      notificationBody: notifBody,
      willSave: willSave,
      isPendingVerification: isPending,
      isDuplicate: dup.isDuplicate,
      saveReason: saveReason,
      duplicateReason: dup.reason,
      debugLogs: logs,
      errors: errors,
    );
  }

  static SmsLabRuleTestResult testTemplateRule(String sms, SmsTemplateRule rule) {
    final parsed = SmsTemplateEngine.testRule(sms, rule);
    if (parsed == null) {
      return SmsLabRuleTestResult(matched: false, ruleName: rule.bankName);
    }
    final type = parsed.direction == TransactionDirection.expense
        ? 'Debit'
        : parsed.direction == TransactionDirection.transfer
            ? 'Transfer'
            : 'Credit';
    return SmsLabRuleTestResult(
      matched: true,
      ruleName: rule.bankNameExact.isNotEmpty ? rule.bankNameExact : rule.bankName,
      amount: parsed.amount,
      title: parsed.name,
      type: type,
      bank: parsed.bank,
    );
  }

  static ({BlockRule rule, String? reason})? _findBlockMatch(String message) {
    if (!Hive.isBoxOpen(SmsHiveBoxes.blockRules)) return null;
    final box = Hive.box<dynamic>(SmsHiveBoxes.blockRules);
    for (final raw in box.values) {
      final rule = BlockRule.fromMap(Map<dynamic, dynamic>.from(raw));
      final reason = rule.matchReason(message);
      if (reason != null) return (rule: rule, reason: reason);
    }
    return null;
  }

  static String? _templateName(String? ruleId) {
    if (ruleId == null || ruleId.isEmpty) return null;
    if (!Hive.isBoxOpen(SmsHiveBoxes.templateRules)) return ruleId;
    final raw = Hive.box(SmsHiveBoxes.templateRules).get(ruleId);
    if (raw is! Map) return ruleId;
    final rule = SmsTemplateRule.fromMap(Map<dynamic, dynamic>.from(raw));
    return rule.bankNameExact.isNotEmpty ? rule.bankNameExact : rule.bankName;
  }

  static ({bool isDuplicate, String? reason}) _checkDuplicate({
    required TransactionParsed parsed,
    required String rawMessage,
  }) {
    if (Hive.isBoxOpen('detected_sms_box')) {
      for (final raw in Hive.box('detected_sms_box').values) {
        final p = Map<String, dynamic>.from(raw as Map);
        if (p['rawMessage']?.toString() == rawMessage) {
          return (isDuplicate: true, reason: 'Same SMS already in pending queue');
        }
        if (parsed.referenceId.isNotEmpty && p['referenceId'] == parsed.referenceId) {
          return (isDuplicate: true, reason: 'Reference ID already pending');
        }
      }
    }
    if (Hive.isBoxOpen('transactions')) {
      final txs = Hive.box('transactions').get('list', defaultValue: const <dynamic>[]) as List;
      for (final raw in txs) {
        final t = Map<String, dynamic>.from(raw as Map);
        if (t['isPendingVerification'] == true) continue;
        if (parsed.referenceId.isNotEmpty && t['referenceId'] == parsed.referenceId) {
          return (isDuplicate: true, reason: 'Reference ID already saved');
        }
        final a = (t['amount'] as num?)?.toDouble();
        if (a == parsed.amount) {
          try {
            final d = DateTime.parse(t['date'] as String);
            if (d.day == parsed.dateTime.day && d.month == parsed.dateTime.month) {
              return (isDuplicate: true, reason: 'Same amount on same day already saved');
            }
          } catch (_) {}
        }
      }
    }
    return (isDuplicate: false, reason: null);
  }

  static String _typeDisplay(String type) {
    switch (type) {
      case 'credit':
        return 'Credit';
      case 'transfer':
        return 'Transfer';
      case 'debit':
        return 'Debit';
      default:
        return type;
    }
  }
}