import 'package:hive_flutter/hive_flutter.dart';
import 'detected_sms_storage.dart';
import 'pending_model.dart';

/// Moves legacy pending transactions out of the main ledger into detected SMS storage.
Future<void> migrateLegacyPendingTransactions() async {
  await DetectedSmsStorage.ensureOpen();

  final txBox = Hive.box('transactions');
  final List<dynamic> rawTxs = txBox.get('list', defaultValue: []);
  if (rawTxs.isEmpty) return;

  final queueBox = Hive.box('pending_detections');
  final List<String> queue = List<String>.from(queueBox.get('queue', defaultValue: []));

  final kept = <Map<String, dynamic>>[];
  var migrated = false;

  for (final raw in rawTxs) {
    final map = Map<String, dynamic>.from(raw);
    if (map['isPendingVerification'] == true) {
      final id = map['id']?.toString() ?? DateTime.now().millisecondsSinceEpoch.toString();
      final pending = PendingTransaction(
        id: id,
        amount: (map['amount'] as num).toDouble(),
        receiver: map['merchant']?.toString() ?? 'Unknown',
        bank: map['bankName']?.toString() ?? 'Bank',
        date: DateTime.parse(map['date']?.toString() ?? DateTime.now().toIso8601String()),
        rawMessage: map['rawMessage']?.toString() ?? '',
        isExpense: map['isExpense'] ?? true,
        isTransfer: map['isTransfer'] ?? false,
        accountLast4: map['accountLast4']?.toString() ?? '',
        referenceId: map['referenceId']?.toString() ?? '',
        upiId: map['upiId']?.toString() ?? '',
        outingId: map['outingId']?.toString(),
        isAutoLinked: map['isAutoLinked'] ?? false,
      );
      DetectedSmsStorage.save(pending);
      if (!queue.contains(id)) queue.add(id);
      migrated = true;
    } else {
      kept.add(map);
    }
  }

  if (migrated) {
    txBox.put('list', kept);
    queueBox.put('queue', queue);
  }
}