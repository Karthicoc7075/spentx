import 'package:hive_flutter/hive_flutter.dart';

/// Remembers which SMS bodies have already been through the detection
/// pipeline, so the inbox catch-up never runs a message a second time.
///
/// Stores a 32-bit FNV-1a hash of the whitespace-normalised body (never the
/// text itself) in the `settings` box, capped at [_max] entries.
class SmsSeenStore {
  SmsSeenStore._();

  static const _key = 'sms_seen_body_hashes';
  static const _max = 600;

  /// FNV-1a 32-bit of the trimmed, whitespace-collapsed body.
  static int hashBody(String body) {
    final norm = body.trim().replaceAll(RegExp(r'\s+'), ' ');
    var hash = 0x811C9DC5;
    for (final unit in norm.codeUnits) {
      hash ^= unit & 0xFF;
      hash = (hash * 0x01000193) & 0xFFFFFFFF;
      if (unit > 0xFF) {
        hash ^= (unit >> 8) & 0xFF;
        hash = (hash * 0x01000193) & 0xFFFFFFFF;
      }
    }
    return hash;
  }

  static bool contains(String body) {
    if (!Hive.isBoxOpen('settings')) return false;
    final list = Hive.box('settings').get(_key);
    if (list is! List) return false;
    return list.contains(hashBody(body));
  }

  static Future<void> add(String body) async {
    if (!Hive.isBoxOpen('settings')) return;
    final box = Hive.box('settings');
    final raw = box.get(_key);
    final list = raw is List ? List<int>.from(raw.whereType<int>()) : <int>[];
    final h = hashBody(body);
    if (list.contains(h)) return;
    list.add(h);
    while (list.length > _max) {
      list.removeAt(0);
    }
    await box.put(_key, list);
  }
}
