import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';

/// Schedules SMS lab tests via Android AlarmManager (survives app swipe-away).
class SmsLabNativeScheduler {
  static const MethodChannel _channel = MethodChannel('com.spentx.app/sms_lab');

  static bool get isSupported => Platform.isAndroid;

  static Future<int?> scheduleBackgroundTest({
    required Map<String, dynamic> payload,
    required int delaySeconds,
  }) async {
    if (!isSupported) return null;
    final fireAt = await _channel.invokeMethod<int>('scheduleBackgroundTest', {
      'payload': jsonEncode(payload),
      'delaySeconds': delaySeconds,
    });
    return fireAt;
  }

  static Future<void> cancelScheduledTest() async {
    if (!isSupported) return;
    await _channel.invokeMethod('cancelScheduledTest');
  }

  static Future<DateTime?> getScheduledFireAt() async {
    if (!isSupported) return null;
    final ms = await _channel.invokeMethod<int>('getScheduledFireAt');
    if (ms == null || ms <= 0) return null;
    return DateTime.fromMillisecondsSinceEpoch(ms);
  }
}