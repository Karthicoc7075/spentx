import 'package:flutter/widgets.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../../../core/services/merchant_rule_service.dart';
import '../rules/engine/sms_rule_engine.dart';
import '../rules/sms_hive_boxes.dart';
import '../rules/sms_template_rules_importer.dart';
import '../v4/bank_sms_v4_parser.dart';
import '../rules/sms_non_transaction_rules_loader.dart';
import '../v4/merchant_learning_service.dart';
import 'detected_sms_migration.dart';
import '../rules/sms_hive_migration.dart';
import 'sms_detection_debug_log.dart';
import '../../../data/local/hive_service.dart';

/// Minimal Hive bootstrap for WorkManager / headless SMS processing.
class SmsBackgroundInit {
  static bool _ready = false;

  static Future<void> ensureReady() async {
    if (_ready) return;
    WidgetsFlutterBinding.ensureInitialized();
    await Hive.initFlutter();

    for (final name in [
      'settings',
      'transactions',
      'pending_detections',
      'detected_sms_box',
      'pending_accounts',
      'merchant_rules_box',
      'merchants_box',
      'processed_sms_box',
      'notification_history',
      'pending_verification_history',
      'ignored_detections',
      ...SmsHiveBoxes.allRuleBoxes,
    ]) {
      if (!Hive.isBoxOpen(name)) await SecureHive.openBox(name);
    }

    await migrateSmsHiveBoxes();
    await SmsRuleEngine.init();
    await SmsTemplateRulesImporter.seedBundledDefaultsIfEmpty();
    await BankSmsV4Parser.ensureLoaded();
    await SmsNonTransactionRulesLoader.ensureLoaded();
    await MerchantLearningService.ensureOpen();
    // One-time-per-launch cleanup of duplicate merchant rows left over from
    // before saveVerified/_upsert were made race-safe.
    await MerchantRuleService.dedupe();
    await MerchantLearningService.dedupe();
    await migrateLegacyPendingTransactions();
    await SmsDetectionDebugLog.ensureOpen();

    _ready = true;
  }
}