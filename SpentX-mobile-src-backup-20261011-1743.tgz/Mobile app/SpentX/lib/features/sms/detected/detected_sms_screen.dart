import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:intl/intl.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../core/widgets/soft_page_kit.dart';
import '../../../core/providers/transaction_provider.dart' show Transaction;
import '../../../core/services/pending_verification_history_service.dart';
import '../sms_service.dart';
import '../../../core/widgets/premium_bottom_sheet.dart';
import 'detection_queue.dart';
import 'detection_popup.dart';
import 'auto_rule_engine.dart';
import '../core/sms_pending_service.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../../../core/providers/pending_account_provider.dart';
import '../../accounts/presentation/widgets/pending_account_card.dart';

class DetectedSmsScreen extends ConsumerWidget {
  const DetectedSmsScreen({super.key});

  Future<bool> _confirmAction(BuildContext context, String action) async {
    final result = await showDialog<bool>(
      context: context,
      builder:
          (ctx) => AlertDialog(
            backgroundColor: SoftKit.card(ctx),
            surfaceTintColor: Colors.transparent,
            elevation: 0,
            insetPadding: const EdgeInsets.symmetric(
              horizontal: 24,
              vertical: 24,
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(SoftKit.radius),
            ),
            title: Text(
              'Are you sure you want to ${action.toLowerCase()}?',
              style: SoftKit.text(ctx, 17, FontWeight.w700, SoftKit.ink(ctx)),
            ),
            content: Text(
              'This action cannot be undone.',
              style: SoftKit.text(ctx, 13, FontWeight.w500, SoftKit.slate(ctx)),
            ),
            actionsPadding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
            actions: [
              Row(
                children: [
                  Expanded(
                    child: SoftKitButton.secondary(
                      label: 'Cancel',
                      height: 44,
                      onPressed: () => Navigator.pop(ctx, false),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: SoftKitButton(
                      label: action,
                      height: 44,
                      onPressed: () => Navigator.pop(ctx, true),
                    ),
                  ),
                ],
              ),
            ],
          ),
    );
    return result ?? false;
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final discoveredAccounts = ref.watch(pendingAccountProvider);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      SmsPendingService.reconcile();
      ref.read(detectionQueueProvider.notifier).refresh();
      ref.read(ignoredHistoryProvider.notifier).refresh();
    });

    final isDark = Theme.of(context).brightness == Brightness.dark;
    // Hive source of truth — queue provider can be stale after background SMS.
    ref.watch(detectionQueueProvider);
    final cutoff = SmsService.activityStartTime();
    bool isNewSms(DateTime date) => cutoff == null || !date.isBefore(cutoff);
    final pendingItems =
        SmsPendingService.listAwaitingVerification()
            .where((p) => isNewSms(p.date))
            .toList();
    final history = ref.watch(pendingVerificationHistoryProvider);
    final verified =
        history
            .where((r) => r.status == 'verified' && isNewSms(r.createdAt))
            .toList();
    final ignored =
        ref
            .watch(ignoredHistoryProvider)
            .where((p) => isNewSms(p.date))
            .toList();

    return Scaffold(
      backgroundColor: SoftKit.canvas(context),
      body: SafeArea(
        bottom: false,
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(
              child: SoftKitHeader(
                title: 'Detected SMS',
                subtitle:
                    pendingItems.isEmpty
                        ? 'Bank messages SpentX picked up'
                        : '${pendingItems.length} waiting for you',
                onBack: () {
                  if (context.canPop()) {
                    context.pop();
                  } else {
                    context.go('/home');
                  }
                },
              ),
            ),
            // Accounts inferred from SMS but never added. These sit above the
            // pending transactions on purpose: until the account exists, its
            // spends cannot be booked anywhere, so it is the blocking decision.
            if (discoveredAccounts.isNotEmpty) ...[
              SliverToBoxAdapter(
                child: _sectionHeader(
                  isDark,
                  'ACCOUNTS FOUND',
                  discoveredAccounts.length,
                  SoftPalette.emerald,
                ),
              ),
              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                sliver: SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (context, index) => Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: PendingAccountCard(
                        pending: discoveredAccounts[index],
                      ),
                    ),
                    childCount: discoveredAccounts.length,
                  ),
                ),
              ),
            ],
            if (pendingItems.isNotEmpty) ...[
              SliverToBoxAdapter(
                child: _sectionHeader(
                  isDark,
                  'PENDING VERIFICATION',
                  pendingItems.length,
                  SoftPalette.emerald,
                ),
              ),
              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                sliver: SliverList(
                  delegate: SliverChildBuilderDelegate((context, index) {
                    final pending = pendingItems[index];
                    final txId = pending.id;
                    final tx = AutoRuleEngine.pendingToTransaction(pending);
                    final hist =
                        history
                            .where((r) => r.transactionId == txId)
                            .firstOrNull;

                    return _DetectedItemTile(
                      tx: pending,
                      isPending: true,
                      notificationShown:
                          hist?.notificationShown ?? pending.notificationShown,
                      onVerify:
                          () => PremiumBottomSheet.show(
                            context: context,
                            child: DetectionPopup(pendingTx: tx),
                          ),
                      onIgnore: () async {
                        final confirmed = await _confirmAction(
                          context,
                          'Ignore',
                        );
                        if (confirmed) {
                          ref
                              .read(detectionQueueProvider.notifier)
                              .ignoreTransaction(txId);
                        }
                      },
                      onDelete: () async {
                        final confirmed = await _confirmAction(
                          context,
                          'Delete',
                        );
                        if (confirmed) {
                          ref
                              .read(detectionQueueProvider.notifier)
                              .deleteTransaction(txId);
                        }
                      },
                    );
                  }, childCount: pendingItems.length),
                ),
              ),
            ],
            if (verified.isNotEmpty) ...[
              SliverToBoxAdapter(
                child: _sectionHeader(
                  isDark,
                  'VERIFIED NOTIFICATIONS',
                  verified.length,
                  SoftPalette.positive,
                ),
              ),
              SliverPadding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 8,
                ),
                sliver: SliverList(
                  delegate: SliverChildBuilderDelegate((context, index) {
                    final record = verified[index];
                    return _HistoryRecordTile(
                      record: record,
                      isDark: isDark,
                      onTap:
                          () => context.push(
                            '/transaction/${record.transactionId}',
                          ),
                    );
                  }, childCount: verified.length),
                ),
              ),
            ],
            if (ignored.isNotEmpty) ...[
              SliverToBoxAdapter(
                child: _sectionHeader(
                  isDark,
                  'IGNORED',
                  ignored.length,
                  SoftPalette.warning,
                ),
              ),
              SliverPadding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 8,
                ),
                sliver: SliverList(
                  delegate: SliverChildBuilderDelegate((context, index) {
                    final tx = ignored[index];
                    final transaction = Transaction(
                      id: tx.id,
                      merchant: tx.receiver,
                      category: 'Other',
                      account: 'Personal',
                      time: 'Just now',
                      amount: tx.amount,
                      isExpense: tx.isExpense,
                      date: tx.date,
                      bankName: tx.bank,
                      accountLast4: tx.accountLast4,
                      referenceId: tx.referenceId,
                      upiId: tx.upiId,
                      rawMessage: tx.rawMessage,
                      isTransfer: tx.isTransfer,
                    );
                    return _DetectedItemTile(
                      tx: tx,
                      isPending: false,
                      onVerify:
                          () => PremiumBottomSheet.show(
                            context: context,
                            child: DetectionPopup(pendingTx: transaction),
                          ),
                      onIgnore: () async {
                        final confirmed = await _confirmAction(
                          context,
                          'Ignore',
                        );
                        if (confirmed) {
                          final box = Hive.box('ignored_detections');
                          final List<dynamic> rawHistory = box.get(
                            'history',
                            defaultValue: [],
                          );
                          rawHistory.removeWhere((t) => t['id'] == tx.id);
                          box.put('history', rawHistory);
                          ref.read(ignoredHistoryProvider.notifier).refresh();
                        }
                      },
                      onDelete: () async {
                        final confirmed = await _confirmAction(
                          context,
                          'Delete',
                        );
                        if (confirmed) {
                          final box = Hive.box('ignored_detections');
                          final List<dynamic> rawHistory = box.get(
                            'history',
                            defaultValue: [],
                          );
                          rawHistory.removeWhere((t) => t['id'] == tx.id);
                          box.put('history', rawHistory);
                          ref.read(ignoredHistoryProvider.notifier).refresh();
                        }
                      },
                    );
                  }, childCount: ignored.length),
                ),
              ),
            ],
            if (pendingItems.isEmpty &&
                verified.isEmpty &&
                ignored.isEmpty &&
                discoveredAccounts.isEmpty)
              const SliverFillRemaining(
                hasScrollBody: false,
                child: Center(
                  child: SoftKitEmptyState(
                    icon: LucideIcons.inbox,
                    title: 'All caught up',
                    message:
                        'New bank and UPI messages will show up here for you to confirm.',
                  ),
                ),
              ),
            const SliverToBoxAdapter(child: SizedBox(height: 32)),
          ],
        ),
      ),
    );
  }

  Widget _sectionHeader(bool isDark, String title, int count, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: SoftKitSectionLabel(title, count: count),
    );
  }
}

class _HistoryRecordTile extends StatelessWidget {
  final PendingVerificationRecord record;
  final bool isDark;
  final VoidCallback onTap;

  const _HistoryRecordTile({
    required this.record,
    required this.isDark,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return SoftKitCard(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      onTap: onTap,
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: SoftKit.softTint(context),
              shape: BoxShape.circle,
            ),
            child: Icon(
              LucideIcons.check,
              size: 18,
              color: SoftKit.positive(context),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '₹${record.amount.toInt()} · ${record.merchant}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: SoftKit.text(
                    context,
                    14,
                    FontWeight.w700,
                    SoftKit.ink(context),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  '${record.bank} · ${DateFormat('MMM dd, hh:mm a').format(record.createdAt)}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: SoftKit.text(
                    context,
                    12,
                    FontWeight.w500,
                    SoftKit.slate(context),
                  ),
                ),
              ],
            ),
          ),
          Icon(
            LucideIcons.chevronRight,
            size: 18,
            color: SoftKit.faint(context),
          ),
        ],
      ),
    );
  }
}

class _DetectedItemTile extends StatelessWidget {
  final dynamic tx;
  final bool isPending;
  final bool notificationShown;
  final VoidCallback onVerify;
  final VoidCallback onIgnore;
  final VoidCallback onDelete;

  const _DetectedItemTile({
    required this.tx,
    required this.isPending,
    this.notificationShown = true,
    required this.onVerify,
    required this.onIgnore,
    required this.onDelete,
  });

  String get _typeLabel {
    if (tx.isTransfer) return 'Transfer';
    return tx.isExpense ? 'Debit' : 'Credit';
  }

  IconData get _typeIcon {
    if (tx.isTransfer) return LucideIcons.arrowRightLeft;
    return tx.isExpense ? LucideIcons.arrowUpRight : LucideIcons.arrowDownLeft;
  }

  @override
  Widget build(BuildContext context) {
    final Color typeColor =
        tx.isTransfer
            ? const Color(0xFF8B5CF6)
            : (tx.isExpense
                ? SoftKit.negative(context)
                : SoftKit.positive(context));
    final String bank = (tx.bank ?? '').toString();
    final String merchant = (tx.receiver ?? '').toString();
    return SoftKitCard(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 14),
      onTap: onVerify,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: typeColor.withValues(alpha: 0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(_typeIcon, size: 20, color: typeColor),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      merchant.isEmpty ? 'Unknown merchant' : merchant,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: SoftKit.text(
                        context,
                        15,
                        FontWeight.w700,
                        SoftKit.ink(context),
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      [
                        if (bank.isNotEmpty) bank,
                        _typeLabel,
                        DateFormat('MMM dd, hh:mm a').format(tx.date),
                      ].join(' · '),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: SoftKit.text(
                        context,
                        12,
                        FontWeight.w500,
                        SoftKit.slate(context),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    '${tx.isExpense && !tx.isTransfer ? '−' : ''}₹${tx.amount.toInt()}',
                    style: SoftKit.text(
                      context,
                      17,
                      FontWeight.w800,
                      SoftKit.ink(context),
                    ),
                  ),
                  InkWell(
                    onTap: onDelete,
                    borderRadius: BorderRadius.circular(8),
                    child: Padding(
                      padding: const EdgeInsets.only(
                        top: 6,
                        left: 6,
                        bottom: 2,
                      ),
                      child: Text(
                        'Delete',
                        style: SoftKit.text(
                          context,
                          11.5,
                          FontWeight.w600,
                          SoftKit.negative(context),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
          if (isPending && notificationShown) ...[
            const SizedBox(height: 10),
            Row(
              children: [
                Icon(LucideIcons.bell, size: 12, color: SoftKit.slate(context)),
                const SizedBox(width: 6),
                Text(
                  'Notification sent — tap to verify',
                  style: SoftKit.text(
                    context,
                    11.5,
                    FontWeight.w500,
                    SoftKit.slate(context),
                  ),
                ),
              ],
            ),
          ],
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: SoftKitButton(
                  label: isPending ? 'Confirm' : 'Review',
                  height: 42,
                  onPressed: onVerify,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: SoftKitButton.secondary(
                  label: isPending ? 'Ignore' : 'Remove',
                  height: 42,
                  onPressed: onIgnore,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
