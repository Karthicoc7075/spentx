import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'pending_model.dart';
import 'detected_sms_storage.dart';
import 'sms_merchant_matcher.dart';
import '../../../core/providers/merchant_provider.dart';
import '../../../core/services/merchant_rule_service.dart';
import '../../../core/services/merchant_identifier_resolver.dart';
import '../../../core/services/pending_verification_history_service.dart';
import '../../../core/providers/transaction_provider.dart';
import '../../../core/providers/transaction_provider.dart' as model;
import '../../../core/providers/user_state_provider.dart';
import '../../../core/debug/master_debug_log.dart';
import '../../../core/debug/master_debug_module.dart';
import '../../sms_parser/sms_direction_helper.dart';

class DetectionQueueNotifier extends StateNotifier<List<String>> {
  final Ref _ref;

  DetectionQueueNotifier(this._ref) : super([]) {
    _loadFromStorage();
  }

  Box get _queueBox => Hive.box('pending_detections');

  void _loadFromStorage() {
    final List<dynamic>? rawQueue = _queueBox.get('queue');
    if (rawQueue == null) {
      state = [];
      return;
    }
    final ids = List<String>.from(rawQueue)
        .where((id) {
          final p = DetectedSmsStorage.get(id);
          return p == null || !p.deferAutoAdd;
        })
        .toList();
    // Sort oldest first using Hive (detected_sms_box) as source of truth for dates.
    ids.sort((a, b) {
      final pa = DetectedSmsStorage.get(a);
      final pb = DetectedSmsStorage.get(b);
      if (pa == null && pb == null) return 0;
      if (pa == null) return 1;
      if (pb == null) return -1;
      return pa.date.compareTo(pb.date);
    });
    state = ids;
  }

  void refresh() {
    DetectedSmsStorage.reconcilePendingQueue();
    _loadFromStorage();
  }

  void _saveToStorage() {
    _queueBox.put('queue', state);
  }

  void addPending(String transactionId) {
    if (state.contains(transactionId)) return;
    state = [...state, transactionId];
    _saveToStorage();
    MasterDebugLog.queue(title: 'Added To Queue', transactionId: transactionId);
  }

  /// Move the given txId to front so notification click opens the *exact* transaction first.
  /// Queue remains id-only (Hive source of truth for data).
  void prioritize(String transactionId) {
    if (transactionId.isEmpty) return;
    final without = state.where((id) => id != transactionId).toList();
    state = [transactionId, ...without];
    _saveToStorage();
  }

  void removePending(String transactionId) {
    state = state.where((id) => id != transactionId).toList();
    _saveToStorage();
    MasterDebugLog.queue(
      title: 'Removed From Queue',
      level: MasterDebugLevel.info,
      transactionId: transactionId,
    );
  }

  PendingTransaction? getPending(String transactionId) {
    return DetectedSmsStorage.get(transactionId);
  }

  void ignoreTransaction(String transactionId) {
    PendingVerificationHistoryService.markIgnored(transactionId);
    final pending = DetectedSmsStorage.get(transactionId);
    if (pending != null) {
      final box = Hive.box('ignored_detections');
      final List<dynamic> rawHistory = box.get('history', defaultValue: []);
      final history = List<Map<String, dynamic>>.from(
        rawHistory.map((e) => Map<String, dynamic>.from(e)),
      );
      history.insert(0, pending.toJson());
      box.put('history', history);
      DetectedSmsStorage.remove(transactionId);
    } else {
      _ref.read(transactionProvider.notifier).removeTransaction(transactionId);
    }
    removePending(transactionId);
    MasterDebugLog.queue(title: 'Popup Ignored', transactionId: transactionId);
  }

  void deleteTransaction(String transactionId) {
    // Permanent delete without moving to ignored history
    DetectedSmsStorage.remove(transactionId);
    final box = Hive.box('ignored_detections');
    final List<dynamic> rawHistory = box.get('history', defaultValue: []);
    final history = List<Map<String, dynamic>>.from(
      rawHistory.map((e) => Map<String, dynamic>.from(e)),
    );
    history.removeWhere((t) => t['id'] == transactionId);
    box.put('history', history);
    _ref.read(transactionProvider.notifier).removeTransaction(transactionId);
    removePending(transactionId);
  }

  /// Match bank SMS → user's account (name / last4).
  String _resolveAccountName({
    required String bank,
    required String accountLast4,
  }) {
    final userAccounts = _ref.read(userStateProvider).accounts;
    if (userAccounts.isEmpty) return bank.isNotEmpty ? bank : 'Cash';

    final last4 = accountLast4.trim();
    if (last4.isNotEmpty) {
      final byLast4 = userAccounts.where((a) {
        final a4 = a.last4Digits.trim();
        return a4.isNotEmpty &&
            (a4 == last4 || a4.endsWith(last4) || last4.endsWith(a4));
      }).toList();
      if (byLast4.isNotEmpty) return byLast4.first.name;
    }

    final bankL = bank.toLowerCase().trim();
    if (bankL.isNotEmpty) {
      final byName = userAccounts.where((a) {
        final n = a.name.toLowerCase();
        return n.contains(bankL) || bankL.contains(n);
      }).toList();
      if (byName.isNotEmpty) return byName.first.name;
    }

    final banks = userAccounts.where((a) => a.type.toLowerCase() != 'cash').toList();
    if (banks.isNotEmpty) return banks.first.name;
    return userAccounts.first.name;
  }

  /// The user's Cash-type account name — the other side of an ATM
  /// withdrawal / cash deposit transfer.
  String _resolveCashAccountName() {
    final userAccounts = _ref.read(userStateProvider).accounts;
    final cash = userAccounts.where((a) => a.isCash).toList();
    if (cash.isNotEmpty) return cash.first.name;
    return 'Cash';
  }

  /// Resolves a registered account's id by name, for a transfer's `toAccountId`.
  String? _resolveAccountId(String name) {
    final target = name.trim().toLowerCase();
    if (target.isEmpty) return null;
    final userAccounts = _ref.read(userStateProvider).accounts;
    for (final a in userAccounts) {
      if (a.name.trim().toLowerCase() == target) return a.id;
    }
    return null;
  }

  /// Confirm verify sheet for credit (income) or debit (expense) or ATM transfer.
  /// [purpose] is Personal/Family/… — not the bank account name.
  void confirmTransaction(
    String transactionId,
    double amount,
    String merchant,
    String purpose,
    bool isExpense,
    String category, {
    bool isTransfer = false,
    String? outingId,
    bool isAutoLinked = false,
    String? merchantIdentifier,
    String? upiId,
    String? contributorSource,
    bool learnMerchant = true,
    String? note,
    String? description,
    DateTime? date,
    List<model.TransactionSplitRow>? splits,
    bool isGroup = false,
    int groupCount = 0,
  }) {
    if (amount <= 0 || merchant.trim().isEmpty) {
      MasterDebugLog.queue(
        title: 'Confirm rejected (invalid amount/merchant)',
        level: MasterDebugLevel.warning,
        transactionId: transactionId,
      );
      return;
    }

    final notifier = _ref.read(transactionProvider.notifier);
    final pending = DetectedSmsStorage.get(transactionId);
    final existingTxs = _ref.read(transactionProvider);
    final existingTx =
        existingTxs.where((t) => t.id == transactionId).firstOrNull;

    final txType = SmsMerchantMatcher.transactionTypeLabel(
      isExpense: isExpense,
      isTransfer: isTransfer,
    );

    final bank = pending?.bank ?? existingTx?.bankName ?? '';
    final last4 = pending?.accountLast4 ?? existingTx?.accountLast4 ?? '';
    final matchedAccountName = _resolveAccountName(
      bank: bank,
      accountLast4: last4,
    );

    // ATM withdrawal (Bank -> Cash) vs Cash deposit (Cash -> Bank) — same
    // isTransfer flag, opposite direction. Re-derive from the raw SMS text
    // rather than trusting a separate flag, since it's the one signal that's
    // always available here regardless of entry path.
    final isCashDeposit = isTransfer &&
        SmsDirectionHelper.isCashDepositAtSelfMachineSms(
          pending?.rawMessage ?? existingTx?.rawMessage ?? '',
        );
    final cashAccountName = _resolveCashAccountName();
    final fromAccountName =
        isCashDeposit ? cashAccountName : matchedAccountName;
    final toAccountName = isCashDeposit ? matchedAccountName : cashAccountName;

    final lookupKey = merchantIdentifier ??
        (existingTx?.rawIdentifier?.isNotEmpty == true
            ? existingTx!.rawIdentifier!
            : MerchantIdentifierResolver.stableKey(
                upiId: upiId ?? pending?.upiId ?? existingTx?.upiId,
                rawIdentifier: existingTx?.rawIdentifier,
                parsedName: merchant,
                rawMessage: pending?.rawMessage ?? existingTx?.rawMessage,
              ));

    final purposeName = purpose.trim().isNotEmpty ? purpose.trim() : 'Personal';
    final categoryName = category.trim().isNotEmpty
        ? category.trim()
        : (isTransfer
            ? (isCashDeposit ? 'Cash Deposit' : 'Cash Withdrawal')
            : (isExpense ? 'Miscellaneous' : 'Other Income'));

    // Credit = income → isExpense false; debit = expense → true.
    final isCredit = !isExpense && !isTransfer;

    final tx = model.Transaction(
      id: transactionId,
      merchant: merchant.trim(),
      category: categoryName,
      // For a transfer, `account` is always the FROM/debit leg — ATM
      // withdrawal debits the detected bank, cash deposit debits Cash.
      account: isTransfer ? fromAccountName : matchedAccountName,
      purpose: purposeName,
      time: 'Confirmed',
      amount: amount,
      isExpense: isExpense,
      isAutoDetected: true,
      paymentType: isTransfer ? (isCashDeposit ? 'Online' : 'Cash') : 'Online',
      date: date ?? pending?.date ?? existingTx?.date ?? DateTime.now(),
      isGroup: isGroup || (existingTx?.isGroup ?? false),
      groupCount: groupCount > 0 ? groupCount : (existingTx?.groupCount ?? 0),
      rawIdentifier: lookupKey.isNotEmpty ? lookupKey : null,
      bankName: bank,
      accountLast4: last4,
      referenceId: pending?.referenceId ?? existingTx?.referenceId ?? '',
      upiId: upiId ?? pending?.upiId ?? existingTx?.upiId ?? '',
      rawMessage: pending?.rawMessage ?? existingTx?.rawMessage ?? '',
      note: (note != null && note.trim().isNotEmpty) ? note.trim() : (existingTx?.note ?? ''),
      description: (description != null && description.trim().isNotEmpty)
          ? description.trim()
          : (existingTx?.description ?? ''),
      splits: (splits != null && splits.isNotEmpty)
          ? splits
          : (existingTx?.splits ?? const []),
      outingId: outingId ?? existingTx?.outingId,
      isAutoLinked: isAutoLinked || (existingTx?.isAutoLinked ?? false),
      isPendingVerification: false,
      isMerchantMapped: true,
      isTransfer: isTransfer,
      transferTo: isTransfer ? toAccountName : null,
      toAccountId: isTransfer ? _resolveAccountId(toAccountName) : null,
      transferType:
          isTransfer ? (isCashDeposit ? 'cash_to_bank' : 'bank_to_cash') : null,
      contributorSource: isCredit
          ? (contributorSource?.trim().isNotEmpty == true
              ? contributorSource!.trim()
              : 'Me')
          : null,
    );

    // Single write path — replace by id (credit or debit).
    notifier.addTransaction(tx, applyOutingAutoLink: outingId == null);

    DetectedSmsStorage.remove(transactionId);
    removePending(transactionId);
    PendingVerificationHistoryService.markVerified(transactionId);

    MasterDebugLog.queue(
      title: isCredit
          ? 'Credit verified'
          : (isTransfer ? 'ATM verified' : 'Debit verified'),
      transactionId: transactionId,
    );
    MasterDebugLog.transaction(
      title: 'Transaction Saved',
      message:
          '${isCredit ? "Income" : (isTransfer ? "ATM" : "Expense")} · $merchant · ₹${amount.toStringAsFixed(0)}',
      data: {
        'transactionId': transactionId,
        'category': categoryName,
        'isExpense': isExpense,
        'isTransfer': isTransfer,
        'account': matchedAccountName,
        'purpose': purposeName,
      },
    );

    final refId = pending?.referenceId ?? existingTx?.referenceId ?? '';
    if (refId.isNotEmpty && Hive.isBoxOpen('processed_sms_box')) {
      Hive.box<dynamic>('processed_sms_box').put(
        refId,
        {'referenceId': refId, 'at': DateTime.now().toIso8601String()},
      );
    }

    // Merchant learn once here (popup should pass learnMerchant:false if it already saved).
    if (learnMerchant) {
      try {
        final payeeKey = lookupKey.isNotEmpty
            ? lookupKey
            : (pending?.receiver.isNotEmpty == true
                ? pending!.receiver
                : merchant);
        if (isTransfer) {
          MerchantRuleService.learnAtmRule(
            bank: bank,
            accountLast4: last4,
            displayName: merchant,
            category: categoryName,
            purposeType: purposeName,
            transactionType: txType,
            isCashDeposit: isCashDeposit,
          );
        }
        // ignore: unawaited_futures
        _ref.read(merchantProvider.notifier).saveRule(
              identifier: payeeKey,
              name: merchant,
              category: categoryName,
              accountType: purposeName,
              transactionType: txType,
            );
      } catch (_) {}
    }
  }
}

final detectionQueueProvider =
    StateNotifierProvider<DetectionQueueNotifier, List<String>>(
  (ref) => DetectionQueueNotifier(ref),
);

class IgnoredHistoryNotifier extends StateNotifier<List<PendingTransaction>> {
  IgnoredHistoryNotifier() : super([]) {
    _loadFromStorage();
  }

  Box get _historyBox => Hive.box('ignored_detections');

  void _loadFromStorage() {
    final List<dynamic>? rawHistory = _historyBox.get('history');
    if (rawHistory != null) {
      state = rawHistory
          .map((e) =>
              PendingTransaction.fromJson(Map<dynamic, dynamic>.from(e)))
          .toList();
    } else {
      state = [];
    }
  }

  void refresh() => _loadFromStorage();
}

final ignoredHistoryProvider =
    StateNotifierProvider<IgnoredHistoryNotifier, List<PendingTransaction>>(
  (ref) => IgnoredHistoryNotifier(),
);
