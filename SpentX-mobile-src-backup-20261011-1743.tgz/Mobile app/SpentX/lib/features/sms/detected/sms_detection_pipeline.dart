import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../../sms_parser/sms_direction_helper.dart';
import '../../sms_parser/sms_transaction_filters.dart';
import '../rules/engine/sms_rule_engine.dart';
import '../core/app_foreground_detector.dart';
import '../core/sms_pending_service.dart';
import '../v4/payee_extractor.dart';
import 'auto_rule_engine.dart';
import 'detected_sms_storage.dart';
import 'self_account_matcher.dart';
import 'sms_detection_debug_log.dart';
import 'sms_seen_store.dart';
import '../../../core/debug/master_debug_log.dart';
import '../../../core/debug/master_debug_module.dart';
import '../../../core/services/auth_service.dart';
import '../../../core/services/account_discovery_service.dart';
import '../../../core/services/bank_allowlist_service.dart';

/// Source channel for an inbound SMS — used in debug logs and dedupe keys.
enum SmsDetectionSource {
  smsBroadcast('native_sms'),
  telephony('telephony'),
  notification('notification'),
  pendingFlush('pending_flush'),
  catchUp('inbox_catch_up'),
  lab('lab'),
  debug('debug');

  final String label;
  const SmsDetectionSource(this.label);
}

/// Single entry point for live SMS, notification payloads, lab tests, and queued SMS.
/// Uses [SmsRuleEngine.parse] + [AutoRuleEngine] — same path as SMS Detection Lab.
class SmsDetectionPipeline {
  SmsDetectionPipeline._();

  static WidgetRef? _ref;
  static BuildContext? _context;
  static final Set<String> _recentHashes = {};

  /// Bind Riverpod + navigator context for foreground handling (set from [SpentXApp]).
  static void bindForeground({required WidgetRef ref, required BuildContext context}) {
    _ref = ref;
    _context = context;
    AppForegroundDetector.bind(ref: ref, context: context);
  }

  static void clearForegroundBinding() {
    _ref = null;
    _context = null;
    AppForegroundDetector.unbind();
  }

  /// Set by the WorkManager isolate after it has checked the native session
  /// flag (`spentx_user_authenticated`). Supabase is never initialised in that
  /// isolate, so [AuthService.isSignedIn] is always false there — which used
  /// to make every SMS queued while the app was closed get drained and then
  /// thrown away as "No signed-in user".
  static bool backgroundSessionVerified = false;

  static bool get _hasSession =>
      AuthService.isSignedIn || backgroundSessionVerified;

  static bool get isAutoDetectionEnabled {
    // No session, no detection — regardless of the user's saved preference.
    // Detected spends have to belong to an account, and a signed-out device
    // must never read SMS. This is the single chokepoint every detection
    // path (broadcast, telephony, notification listener, WorkManager isolate)
    // funnels through, so gating here covers all of them.
    if (!_hasSession) return false;
    return Hive.box('settings').get('auto_detection', defaultValue: true) == true;
  }

  /// Process raw bank SMS text (live, lab, or flushed from native queue).
  static Future<SmsPipelineOutcome> processInbound({
    required String rawMessage,
    String? sender,
    required SmsDetectionSource source,
    bool forceProcess = false,
    bool showVerifyPopup = false,
    DateTime? receivedAt,
    /// Skip the foreground popup flow and file the result the way a closed
    /// app would (auto-add known merchants, queue the rest for review). Used
    /// by the inbox catch-up so a batch of old SMS does not stack popups.
    bool preferBackground = false,
  }) async {
    final body = rawMessage.trim();

    if (MasterDebugLog.isEnabled) {
      await MasterDebugLog.sms(
        title: 'Raw SMS Received',
        message: 'redacted (${body.length} chars)',
        sender: sender,
        source: _sourceLabel(source),
      );
    }

    // `forceProcess` (SMS Lab / manual replay) must still respect the session.
    if (!_hasSession) {
      await SmsDetectionDebugLog.log(
        level: SmsDebugLogLevel.warning,
        message: 'No signed-in user — SMS ignored',
        source: source.label,
      );
      return SmsPipelineOutcome.autoDetectionOff;
    }

    if (!forceProcess && !isAutoDetectionEnabled) {
      await SmsDetectionDebugLog.log(
        level: SmsDebugLogLevel.warning,
        message: 'Automatic SMS detection is OFF — ignored (no notification)',
        source: source.label,
        rawSmsPreview: body.isNotEmpty ? body : null,
      );
      return SmsPipelineOutcome.autoDetectionOff;
    }

    if (body.isEmpty) {
      await SmsDetectionDebugLog.log(
        level: SmsDebugLogLevel.warning,
        message: 'Empty SMS body — ignored',
        source: source.label,
      );
      return SmsPipelineOutcome.skippedEmpty;
    }

    final at = receivedAt ?? DateTime.now();
    final dedupeKey = '${body.hashCode}_${sender ?? ''}_${at.minute}';
    if (_recentHashes.contains(dedupeKey)) {
      if (Hive.isBoxOpen('pending_detections')) {
        final q = Hive.box('pending_detections').get('queue', defaultValue: const <dynamic>[]) as List;
        if (q.isNotEmpty) {
          return SmsPipelineOutcome.pendingVerification;
        }
      }
      return SmsPipelineOutcome.skippedDuplicate;
    }
    _recentHashes.add(dedupeKey);
    if (_recentHashes.length > 80) {
      _recentHashes.remove(_recentHashes.first);
    }
    // Persistent record so the inbox catch-up never re-runs this message.
    await SmsSeenStore.add(body);

    if (SmsRuleEngine.isBlocked(body)) {
      SmsRuleEngine.ignoreMessage(body, 'Matched User Block Rule (${source.label})');
      await SmsDetectionDebugLog.log(
        level: SmsDebugLogLevel.warning,
        message: 'SMS blocked by user rule',
        source: source.label,
        rawSmsPreview: body,
      );
      return SmsPipelineOutcome.blocked;
    }

    // Did money actually move? Applied HERE rather than only inside
    // SmsRuleEngine.parse so it covers every SmsDetectionSource identically —
    // broadcast, telephony, notification, WorkManager flush and the Lab — and
    // so a message that moves no money can never reach account discovery and
    // propose an account off the back of a balance alert.
    //
    // A non-transaction rule (admin-managed or bundled) is consulted too, so a
    // false positive can be fixed from the backend without an app release.
    final ntRule = SmsTransactionFilters.nonTransactionRuleId(body);
    if (ntRule != null || !SmsTransactionFilters.statesMoneyMoved(body)) {
      await SmsDetectionDebugLog.log(
        level: SmsDebugLogLevel.warning,
        message: ntRule != null
            ? 'Not a transaction — matched rule $ntRule'
            : 'No transaction verb — message states no money moved',
        source: source.label,
        rawSmsPreview: body,
        detail: sender != null ? 'from: $sender' : null,
      );
      return SmsPipelineOutcome.blocked;
    }

    // Only banks the user actually added — mirrors the native listener's gate
    // so the SMS-broadcast path can't detect what the notification path drops.
    //
    // Three answers, not two. A bank-shaped message carrying a last-4 the user
    // has no account for used to be dropped here without a trace, which is how
    // a forgotten credit card silently went untracked. It now falls through to
    // be parsed, and — only if it really is a transaction — proposes the
    // account instead. See docs/ACCOUNT_DISCOVERY.md.
    final allow = BankAllowlistService.evaluate(body, sender: sender);
    if (allow == AllowResult.blocked) {
      await SmsDetectionDebugLog.log(
        level: SmsDebugLogLevel.warning,
        message: 'SMS is not from a bank the user added — ignored',
        source: source.label,
        rawSmsPreview: body,
        detail: sender != null ? 'from: $sender' : null,
      );
      return SmsPipelineOutcome.blocked;
    }

    final parsed =
        SmsRuleEngine.parse(body, smsReceivedTime: at, sender: sender);
    if (parsed == null) {
      await SmsDetectionDebugLog.log(
        level: SmsDebugLogLevel.error,
        message: 'Parse failed — not recognized as bank transaction SMS',
        source: source.label,
        rawSmsPreview: body,
        detail: sender != null ? 'from: $sender' : null,
      );
      return SmsPipelineOutcome.parseFailed;
    }

    // Parsed, but against an account that does not exist yet. Propose the
    // account and stop: booking a transaction to a missing account is how
    // balances and net worth go wrong. The spend is not lost — once the user
    // adds the account, the same message is re-run through this pipeline.
    if (allow == AllowResult.discovery) {
      final discovered = AccountDiscoveryService.record(rawMessage: body);
      await SmsDetectionDebugLog.log(
        level: SmsDebugLogLevel.info,
        message: discovered == null
            ? 'Unknown account SMS — no last-4 to propose, ignored'
            : 'Unknown account detected — suggested '
                '${discovered.displayBank} XX${discovered.last4} '
                '(${discovered.hitCount} msg)',
        source: source.label,
        rawSmsPreview: body,
        detail: sender != null ? 'from: $sender' : null,
      );
      return discovered == null
          ? SmsPipelineOutcome.blocked
          : SmsPipelineOutcome.accountDiscovery;
    }

    var type = SmsDirectionHelper.typeLabel(rawMessage: body, parsed: parsed);
    final payee = PayeeExtractor.extract(body) ?? parsed.name;

    // Keeps the debug/master logs below accurate to what actually gets
    // written: `type` is only used as `fallbackType` downstream, and
    // SmsDirectionHelper.resolveDirection ignores fallbackType whenever
    // `parsed` is non-null (always true here) — the real transfer-vs-expense
    // decision (including the self-account-match guard against third-party
    // NEFT/IMPS SMS being misread as a transfer) happens inside
    // SmsMerchantMatcher.resolve(), which every entry path (foreground,
    // background, native payload) funnels through. This local recompute is
    // duplicated here only so what gets logged matches what gets saved.
    if (type == 'transfer' && !SmsDirectionHelper.isTransferSms(body)) {
      if (!SelfAccountMatcher.matches(payee)) {
        type = 'debit';
      }
    }

    if (MasterDebugLog.isEnabled) {
      await MasterDebugLog.log(
        level: MasterDebugLevel.info,
        module: MasterDebugModule.transactions,
        title: 'Transaction Type Detected',
        message: type,
        data: {
          'amount': parsed.amount,
          'merchant': parsed.name,
          'bank': parsed.bank,
          'referenceId': parsed.referenceId,
        },
      );
      await MasterDebugLog.sms(
        title: 'Detection Result',
        detectionResult: type,
        source: _sourceLabel(source),
        sender: sender,
      );
    }

    final useForeground = !preferBackground && _canUseForeground();
    if (useForeground) {
      final result = await AutoRuleEngine.handleForeground(
        ref: _ref!,
        context: _context!,
        rawMessage: body,
        amount: parsed.amount,
        merchant: payee,
        bank: parsed.bank,
        type: type,
        forcePopup: showVerifyPopup,
        skipNotification: true,
      );

      await SmsDetectionDebugLog.log(
        level: result == true ? SmsDebugLogLevel.success : SmsDebugLogLevel.info,
        message: result == true
            ? 'Foreground: auto-added transaction (known merchant / learned ATM / active trip)'
            : 'Foreground: pending verification — popup + sms_pending history',
        source: source.label,
        rawSmsPreview: body,
        detail: '$type • ₹${parsed.amount.toStringAsFixed(0)} • $payee',
      );
      return result == true
          ? SmsPipelineOutcome.autoAdded
          : SmsPipelineOutcome.pendingVerification;
    }

    final backgroundResult = AutoRuleEngine.handleBackgroundSms(
      rawMessage: body,
      parsed: parsed,
      fallbackType: type,
      amountOverride: parsed.amount,
      bankOverride: parsed.bank,
      sourceLabel: source.label,
      skipSystemNotification: source == SmsDetectionSource.pendingFlush ||
          source == SmsDetectionSource.notification ||
          source == SmsDetectionSource.catchUp,
    );

    await SmsDetectionDebugLog.log(
      level: backgroundResult == BackgroundSmsOutcome.autoAdded
          ? SmsDebugLogLevel.success
          : SmsDebugLogLevel.info,
      message: switch (backgroundResult) {
        BackgroundSmsOutcome.autoAdded =>
          'Background: known merchant — auto-added + notification',
        BackgroundSmsOutcome.pendingVerification =>
          'Background: unknown payee — verify notification (no auto-add)',
        BackgroundSmsOutcome.skipped =>
          'Background: skipped (dup / blocked / auto-detection off)',
      },
      source: source.label,
      rawSmsPreview: body,
      detail: '$type • ₹${parsed.amount.toStringAsFixed(0)} • $payee',
    );

    return switch (backgroundResult) {
      BackgroundSmsOutcome.autoAdded => SmsPipelineOutcome.autoAdded,
      BackgroundSmsOutcome.pendingVerification =>
        SmsPipelineOutcome.pendingVerification,
      BackgroundSmsOutcome.skipped => SmsPipelineOutcome.skippedDuplicate,
    };
  }

  /// Notification / native JSON payload.
  /// If the payload already carries our transactionId (click or queued notif), short-circuit:
  /// rely on Hive id-only queue + click handler. Avoids reparse, false dups, and extra notifications.
  /// Native notification-listener payloads may fail [SmsRuleEngine.parse] — use [AutoRuleEngine.handleNativePayload]
  /// which falls back to json amount/merchant/bank/type fields.
  static Future<SmsPipelineOutcome> processNotificationPayload(
    Map<String, dynamic> jsonMap, {
    SmsDetectionSource source = SmsDetectionSource.notification,
    bool forceProcess = false,
  }) async {
    final txId = jsonMap['transactionId']?.toString();
    if (txId != null &&
        txId.isNotEmpty &&
        DetectedSmsStorage.get(txId) != null) {
      SmsPendingService.reconcile();
      return SmsPipelineOutcome.pendingVerification;
    }

    final rawText = jsonMap['rawText']?.toString() ?? '';
    final isNativePayload = jsonMap['nativeNotifShown'] == true;

    if (rawText.isEmpty && !isNativePayload) {
      await SmsDetectionDebugLog.log(
        level: SmsDebugLogLevel.error,
        message: 'Notification payload missing rawText',
        source: source.label,
      );
      return SmsPipelineOutcome.parseFailed;
    }

    // Native listener already showed the system notification — always materialize via
    // handleNativePayload so parse failures never drop pending verifications.
    if (isNativePayload || txId != null) {
      final pendingId = AutoRuleEngine.handleNativePayload(jsonMap);
      await SmsDetectionDebugLog.log(
        level: pendingId == null ? SmsDebugLogLevel.success : SmsDebugLogLevel.info,
        message: pendingId == null
            ? 'Native payload: known merchant auto-added'
            : 'Native payload: pending saved for verification',
        source: source.label,
        rawSmsPreview: rawText.isNotEmpty ? rawText : null,
        detail: pendingId ?? jsonMap['type']?.toString(),
      );
      return pendingId == null
          ? SmsPipelineOutcome.autoAdded
          : SmsPipelineOutcome.pendingVerification;
    }

    if (_canUseForeground()) {
      return processInbound(
        rawMessage: rawText,
        source: source,
        forceProcess: forceProcess,
      );
    }

    final pendingId = AutoRuleEngine.handleNativePayload(jsonMap);

    await SmsDetectionDebugLog.log(
      level: pendingId == null ? SmsDebugLogLevel.success : SmsDebugLogLevel.info,
      message: pendingId == null
          ? 'Notification payload: known merchant auto-added + notification'
          : 'Notification payload: unknown payee — pending verify',
      source: source.label,
      rawSmsPreview: rawText,
      detail: jsonMap['type']?.toString(),
    );

    return pendingId == null
        ? SmsPipelineOutcome.autoAdded
        : SmsPipelineOutcome.pendingVerification;
  }

  static bool _canUseForeground() => AppForegroundDetector.isInForeground;

  static String _sourceLabel(SmsDetectionSource source) {
    switch (source) {
      case SmsDetectionSource.smsBroadcast:
      case SmsDetectionSource.telephony:
        return 'SMS Broadcast';
      case SmsDetectionSource.notification:
        return 'Notification Listener';
      case SmsDetectionSource.lab:
        return 'Detection Lab';
      case SmsDetectionSource.pendingFlush:
        return 'Pending Flush';
      case SmsDetectionSource.catchUp:
        return 'Inbox Catch-up';
      case SmsDetectionSource.debug:
        return 'Debug';
    }
  }
}

enum SmsPipelineOutcome {
  autoAdded,

  /// Parsed fine, but belongs to an account the user has not added. A
  /// [PendingAccount] was proposed; no transaction was written.
  accountDiscovery,
  pendingVerification,
  parseFailed,
  blocked,
  skippedEmpty,
  skippedDuplicate,
  autoDetectionOff,
}