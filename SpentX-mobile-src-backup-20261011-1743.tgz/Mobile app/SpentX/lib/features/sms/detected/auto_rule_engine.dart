import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/providers/transaction_provider.dart' as model;
import '../../../core/providers/outing_provider.dart';
import '../../../core/widgets/premium_bottom_sheet.dart';
import '../../sms_parser/models/transaction_parsed.dart';
import '../../sms_parser/sms_direction_helper.dart';
import '../../sms_parser/sms_transaction_filters.dart';
import '../rules/engine/sms_rule_engine.dart';
import 'pending_model.dart';
import 'detection_queue.dart';
import 'detection_popup.dart';
import 'pending_verification_presenter.dart';
import 'detected_sms_storage.dart';
import 'sms_merchant_matcher.dart';
import 'sms_detection_debug_log.dart';
import 'active_outing_helper.dart';
import '../../../core/models/merchant_rule.dart';
import '../sms_notification.dart';
import '../sms_notification_copy.dart';
import '../core/app_foreground_detector.dart';
import '../../../core/services/account_discovery_service.dart';
import '../../../core/services/bank_allowlist_service.dart';
import '../../../core/services/friend_credit_handler.dart';
import '../../../core/services/friend_repayment_matcher.dart';
import '../../../core/services/notification_history_service.dart';
import '../../../core/services/pending_verification_history_service.dart';
import '../../../core/services/merchant_rule_service.dart';
import '../../../core/services/merchant_identifier_resolver.dart';
import '../v4/merchant_match_resolver.dart';
import '../v4/payee_extractor.dart';
import '../v4/bank_sms_v4_parser.dart';
import '../v4/merchant_learning_service.dart';
import '../rules/engine/sms_template_engine.dart';
import '../../settings/data/merchant_provider.dart';
import '../v4/payee_normalizer.dart';
import '../core/sms_pending_service.dart';
import 'transaction_detection_validator.dart';
import '../../../core/debug/master_debug_log.dart';
import '../../../core/debug/master_debug_module.dart';
import '../../../core/sync/sync_service.dart';
import '../../../core/utils/bank_keywords.dart';

/// Bank SMS pipeline:
/// 1) Classify credit / debit / ATM (transfer)
/// 2) Match merchant DB by UPI or name + same transaction type
/// 3) Known merchant → auto-add to transactions
/// 4) Unknown → store in detected SMS DB + queue (user verifies on app open)
class AutoRuleEngine {
  /// Resolves the user's real account name for an SMS-detected transaction.
  ///
  /// Auto-added transactions previously stored the merchant rule's purpose
  /// type ("Personal"/"Family") in the `account` field, which meant they were
  /// invisible to every real account balance and to net worth. This matches
  /// the same bank→account logic the manual verification flow uses.
  static String resolveAccountName(String bank, {String? accountLast4}) {
    try {
      final raw = Hive.box('settings').get('onboardingAccounts');
      if (raw is List) {
        final accounts =
            raw.map((e) => Map<dynamic, dynamic>.from(e as Map)).toList();

        final last4 = accountLast4?.trim() ?? '';
        if (last4.isNotEmpty) {
          for (final a in accounts) {
            if ((a['last4Digits'] ?? '').toString() == last4) {
              final name = (a['name'] ?? '').toString();
              if (name.isNotEmpty) return name;
            }
          }
        }

        final bankLower = bank.trim().toLowerCase();
        if (bankLower.isNotEmpty && bankLower != 'bank') {
          for (final a in accounts) {
            final name = (a['name'] ?? '').toString();
            final nl = name.toLowerCase();
            if (nl.isNotEmpty &&
                (nl.contains(bankLower) || bankLower.contains(nl))) {
              return name;
            }
          }
          // "SBI" vs an account saved as "State Bank of India".
          final key = bankKeyForLabel(bank);
          if (key.isNotEmpty) {
            for (final a in accounts) {
              final name = (a['name'] ?? '').toString();
              if (name.isNotEmpty && bankTokenForAccountName(name) == key) {
                return name;
              }
            }
          }
        }

        for (final a in accounts) {
          if ((a['type'] ?? '').toString() == 'Bank') {
            final name = (a['name'] ?? '').toString();
            if (name.isNotEmpty) return name;
          }
        }
      }
    } catch (_) {}
    return bank.trim().isNotEmpty ? bank.trim() : 'Personal';
  }

  /// Resolves the user's Cash-type account name — background-safe (reads the
  /// same Hive-backed `onboardingAccounts` list as [resolveAccountName]).
  static String resolveCashAccountName() {
    try {
      final raw = Hive.box('settings').get('onboardingAccounts');
      if (raw is List) {
        for (final e in raw) {
          final a = Map<dynamic, dynamic>.from(e as Map);
          if ((a['type'] ?? '').toString().toLowerCase() == 'cash') {
            final name = (a['name'] ?? '').toString();
            if (name.isNotEmpty) return name;
          }
        }
      }
    } catch (_) {}
    return 'Cash';
  }

  /// Resolves a registered account's id by name — background-safe, for
  /// populating a transfer's `toAccountId` (used at sync time to write the
  /// real `to_account_id` column instead of tag-encoding).
  static String? resolveAccountId(String name) {
    final target = name.trim().toLowerCase();
    if (target.isEmpty) return null;
    try {
      final raw = Hive.box('settings').get('onboardingAccounts');
      if (raw is List) {
        for (final e in raw) {
          final a = Map<dynamic, dynamic>.from(e as Map);
          final n = (a['name'] ?? '').toString().trim().toLowerCase();
          if (n == target) return (a['id'] ?? '').toString();
        }
      }
    } catch (_) {}
    return null;
  }


  /// Wall-clock date for an auto-added SMS.
  ///
  /// Use the date the rule parsed when it has one. Otherwise local now.
  /// Components are copied into a local [DateTime] so a UTC flag on the
  /// parsed value cannot move a today spend onto tomorrow, and the stored
  /// ISO is always an explicit UTC instant (see [Transaction.toJson]).
  static DateTime _localAutoAddDate(DateTime? parsed) {
    if (parsed == null) return DateTime.now();
    return DateTime(
      parsed.year,
      parsed.month,
      parsed.day,
      parsed.hour,
      parsed.minute,
      parsed.second,
      parsed.millisecond,
    );
  }

  static bool _isDuplicate({String? refId, required double amount, required DateTime date}) {
    if (refId != null && refId.isNotEmpty) {
      if (Hive.isBoxOpen('processed_sms_box')) {
        final box = Hive.box<dynamic>('processed_sms_box');
        final alreadyProcessed = box.values.any((e) => e['referenceId'] == refId);
        if (alreadyProcessed) return true;
      }
    }

    if (Hive.isBoxOpen('transactions')) {
      final txBox = Hive.box('transactions');
      final List<dynamic> rawTxs = txBox.get('list', defaultValue: []);
      final hasRealDup = rawTxs.any((e) {
        final isPending = e['isPendingVerification'] == true;
        if (isPending) return false;

        if (refId != null && refId.isNotEmpty) {
          return e['referenceId'] == refId;
        }
        final sameAmount = (e['amount'] as num).toDouble() == amount;
        final txDate = DateTime.parse(e['date']);
        return sameAmount && txDate.day == date.day && txDate.month == date.month;
      });
      if (hasRealDup) return true;
    }

    // Hive source of truth: pending items are NOT duplicates for verification flow.
    // If a pending with same logical key exists, do NOT treat as dup (allow verify popup / click).
    if (Hive.isBoxOpen('detected_sms_box')) {
      final pendBox = Hive.box('detected_sms_box');
      final hasPendingMatch = pendBox.values.any((e) {
        final p = (e is Map) ? Map<String, dynamic>.from(e) : <String, dynamic>{};
        final sameAmount = (p['amount'] as num?)?.toDouble() == amount;
        if (refId != null && refId.isNotEmpty && (p['referenceId'] ?? '') == refId) {
          return true;
        }
        if (sameAmount) {
          try {
            final pDate = DateTime.parse(p['date'] as String);
            if (pDate.day == date.day && pDate.month == date.month) return true;
          } catch (_) {}
        }
        return false;
      });
      if (hasPendingMatch) return false; // pending exists → not a dup for verify purposes
    }

    return false;
  }

  /// Returns existing pending tx id (if any) for the logical key. Used to avoid creating
  /// duplicate pending entries + duplicate notifications on reprocess or notification click paths.
  static String? _findExistingPendingId({String? refId, required double amount, required DateTime date}) {
    if (!Hive.isBoxOpen('detected_sms_box')) return null;
    final box = Hive.box('detected_sms_box');
    for (final raw in box.values) {
      try {
        final p = (raw is Map) ? Map<String, dynamic>.from(raw) : <String, dynamic>{};
        final pid = p['id']?.toString();
        if (pid == null || pid.isEmpty) continue;
        if (refId != null && refId.isNotEmpty && (p['referenceId'] ?? '') == refId) {
          return pid;
        }
        final a = (p['amount'] as num?)?.toDouble();
        if (a == amount) {
          final d = DateTime.parse(p['date'] as String);
          if (d.day == date.day && d.month == date.month) return pid;
        }
      } catch (_) {}
    }
    return null;
  }

  static ResolvedSmsDetection _resolve({
    required String rawMessage,
    TransactionParsed? parsed,
    String? fallbackType,
    double? amountOverride,
    String? merchantOverride,
    String? bankOverride,
  }) {
    final overridePayee = merchantOverride?.trim();
    final settings = Hive.box('settings');
    final isAutoOn = settings.get('auto_detection', defaultValue: true);

    final base = SmsMerchantMatcher.resolve(
      rawMessage: rawMessage,
      parsed: parsed,
      fallbackType: fallbackType,
      autoDetectionEnabled: isAutoOn,
    );

    final payeeMatch = MerchantMatchResolver.resolve(
      rawMessage: rawMessage,
      parsed: parsed,
      requireAutoApply: true,
    );
    final effectiveDisplay = base.matchedRule?.displayName ?? payeeMatch.displayTitle;
    final displayName = (overridePayee != null &&
            overridePayee.isNotEmpty &&
            overridePayee.toLowerCase() != 'unknown')
        ? overridePayee
        : effectiveDisplay;
    return ResolvedSmsDetection(
      direction: base.direction,
      isExpense: base.isExpense,
      isTransfer: base.isTransfer,
      transactionType: base.transactionType,
      upiId: base.upiId,
      rawIdentifier: base.rawIdentifier,
      displayName: displayName,
      amount: amountOverride ?? base.amount,
      bank: bankOverride ?? base.bank,
      parsed: parsed,
      matchedRule: base.matchedRule,
      isKnownMerchant: base.isKnownMerchant,
    );
  }



  /// Unknown merchant → detected SMS storage only (not in activity list).
  static String _storeForVerification(
    ResolvedSmsDetection r,
    String rawMessage, {
    String? id,
    String? outingId,
    bool isAutoLinked = false,
    String? savedTitle,
    String? savedCategory,
    String? savedPurpose,
    bool deferAutoAdd = false,
  }) {
    final txId = (id != null && id.isNotEmpty)
        ? id
        : DateTime.now().millisecondsSinceEpoch.toString();
    final txDate = _localAutoAddDate(r.parsed?.dateTime);

    final upiId = r.upiId.isNotEmpty
        ? r.upiId
        : (MerchantRuleService.extractUpiFromMessage(rawMessage) ?? '');

    final rawPayee = PayeeExtractor.extract(rawMessage) ?? r.displayName;

    final pending = PendingTransaction(
      id: txId,
      amount: r.amount,
      receiver: rawPayee,
      bank: r.bank,
      date: txDate,
      rawMessage: rawMessage,
      isExpense: r.isExpense,
      isTransfer: r.isTransfer,
      accountLast4: r.parsed?.accountLast4 ?? '',
      referenceId: r.parsed?.referenceId ?? '',
      upiId: upiId,
      outingId: outingId,
      isAutoLinked: isAutoLinked,
      savedTitle: savedTitle,
      savedCategory: savedCategory,
      savedPurpose: savedPurpose,
      deferAutoAdd: deferAutoAdd,
    );

    return SmsPendingService.save(pending);
  }

  static Map<String, dynamic> _buildTransactionMap({
    required String txId,
    required ResolvedSmsDetection r,
    required String rawMessage,
    String? outingId,
    bool isAutoLinked = false,
  }) {
    final rule = r.matchedRule;
    final txDate = _localAutoAddDate(r.parsed?.dateTime);
    final stableKey = r.rawIdentifier.isNotEmpty
        ? r.rawIdentifier
        : MerchantIdentifierResolver.stableKey(
            upiId: r.upiId,
            rawIdentifier: r.rawIdentifier,
            parsedName: r.displayName,
            rawMessage: rawMessage,
          );
    final title = rule?.displayName ??
        MerchantIdentifierResolver.displayTitle(
          rawMessage: rawMessage,
          parsed: r.parsed,
          matchedRule: rule,
          upiId: r.upiId,
          rawIdentifier: stableKey,
        );

    final detectedBankAccount =
        resolveAccountName(r.bank, accountLast4: r.parsed?.accountLast4);
    final cashAccount = resolveCashAccountName();
    // ATM withdrawal: from = detected bank, to = Cash (bank_to_cash).
    // Cash deposit: from = Cash, to = detected bank (cash_to_bank) — the
    // account this row belongs to is always the FROM/debit leg.
    final fromAccount = (r.isTransfer && r.isCashDeposit) ? cashAccount : detectedBankAccount;
    final toAccount = (r.isTransfer && r.isCashDeposit) ? detectedBankAccount : cashAccount;

    return {
      'id': txId,
      'merchant': title,
      'category': rule?.defaultCategory ?? 'Other',
      'account': r.isTransfer ? fromAccount : detectedBankAccount,
      'purpose': rule?.defaultPurposeType ?? 'Personal',
      'time': 'Auto-added',
      'amount': r.amount,
      'isExpense': r.isExpense,
      'isAutoDetected': true,
      'isGroup': false,
      'groupCount': 0,
      'paymentType': r.isTransfer ? (r.isCashDeposit ? 'Online' : 'Cash') : 'Online',
      'date': txDate.toUtc().toIso8601String(),
      'isTransfer': r.isTransfer,
      if (r.isTransfer) 'transferTo': toAccount,
      if (r.isTransfer) 'toAccountId': resolveAccountId(toAccount),
      if (r.isTransfer) 'transferType': r.isCashDeposit ? 'cash_to_bank' : 'bank_to_cash',
      'rawIdentifier': stableKey,
      'bankName': r.bank,
      'accountLast4': r.parsed?.accountLast4 ?? '',
      'referenceId': r.parsed?.referenceId ?? '',
      'upiId': r.upiId,
      'rawMessage': rawMessage,
      'outingId': outingId,
      'isAutoLinked': isAutoLinked,
      'isPendingVerification': false,
      'isMerchantMapped': r.isKnownMerchant,
    };
  }

  static void _appendTransactionToHive(Map<String, dynamic> newTx) {
    final txBox = Hive.box('transactions');
    final List<dynamic> rawTxs = txBox.get('list', defaultValue: []);
    final txList = rawTxs.map((e) => Map<String, dynamic>.from(e)).toList();
    txList.insert(0, newTx);
    txBox.put('list', txList);
    // Background auto-adds bypass the provider — enqueue for sync here.
    try {
      SyncService.queueTransactionUpsert(Map<String, dynamic>.from(newTx));
    } catch (_) {}
  }

  static void _markProcessed({String? referenceId}) {
    if (referenceId == null || referenceId.isEmpty) return;
    if (!Hive.isBoxOpen('processed_sms_box')) return;
    final box = Hive.box<dynamic>('processed_sms_box');
    box.put(referenceId, {'referenceId': referenceId, 'at': DateTime.now().toIso8601String()});
  }

  /// Unknown / first-time merchant (incl. first ATM per bank): persist, queue, notify, log.
  static String _commitUnknownMerchantPending({
    required ResolvedSmsDetection r,
    required String rawMessage,
    String? pendingId,
    String? outingId,
    bool isAutoLinked = false,
    String? sourceLabel,
    bool skipSystemNotification = false,
    bool allowAutoAddIfKnown = true,
  }) {
    final safetyLookup = TransactionDetectionValidator.evaluateMerchant(
      resolved: r,
      rawMessage: rawMessage,
      sourceLabel: sourceLabel,
      emitLog: false,
    );
    if (safetyLookup.isKnown && safetyLookup.rule != null) {
      if (allowAutoAddIfKnown) {
        _autoSaveKnownMerchantBackground(
          r: r,
          rawMessage: rawMessage,
          rule: safetyLookup.rule!,
          outingId: outingId,
          isAutoLinked: isAutoLinked,
          sourceLabel: sourceLabel,
          skipSystemNotification: skipSystemNotification,
        );
        return '';
      }
      return _commitDeferredKnownMerchant(
        r: r,
        rawMessage: rawMessage,
        rule: safetyLookup.rule!,
        outingId: outingId,
        isAutoLinked: isAutoLinked,
        sourceLabel: sourceLabel,
        skipSystemNotification: skipSystemNotification,
      );
    }

    final savedPendingId = _storeForVerification(
      r,
      rawMessage,
      id: pendingId,
      outingId: outingId,
      isAutoLinked: isAutoLinked,
    );

    SmsDetectionDebugLog.log(
      level: SmsDebugLogLevel.info,
      message: 'step: pending_detection_saved',
      source: sourceLabel,
      rawSmsPreview: rawMessage,
      detail: 'id=$savedPendingId • ${r.displayName} • ₹${r.amount.toInt()}',
    );

    SmsDetectionDebugLog.log(
      level: SmsDebugLogLevel.info,
      message: 'queue: added to pending_detections',
      source: sourceLabel,
      detail: savedPendingId,
    );

    MasterDebugLog.queue(title: 'Added To Queue', transactionId: savedPendingId);
    MasterDebugLog.merchant(
      title: 'Verification Required',
      message: r.displayName,
      level: MasterDebugLevel.warning,
    );

    _notifyPendingVerification(
      r: r,
      txId: savedPendingId,
      rawMessage: rawMessage,
      outingId: outingId,
      sourceLabel: sourceLabel,
      skipSystemNotification: skipSystemNotification,
    );

    PendingVerificationHistoryService.recordPending(
      transactionId: savedPendingId,
      amount: r.amount,
      merchant: r.displayName,
      bank: r.bank,
      type: r.transactionType,
      notificationShown: true,
    );

    TransactionDetectionValidator.logOutcome(
      transactionType: TransactionDetectionValidator.transactionTypeLabel(r),
      merchantIdentifier: safetyLookup.merchantIdentifier,
      merchantRule: null,
      verificationRequired: true,
      outingLinked: isAutoLinked,
      sourceLabel: sourceLabel,
    );

    return savedPendingId;
  }

  static void _autoSaveKnownMerchantBackground({
    required ResolvedSmsDetection r,
    required String rawMessage,
    required MerchantRule rule,
    String? outingId,
    bool isAutoLinked = false,
    String? sourceLabel,
    /// Reuse native payload id so one notification slot updates Verify → Added.
    String? notificationId,
    bool skipSystemNotification = false,
  }) {
    final txId = (notificationId != null && notificationId.isNotEmpty)
        ? notificationId
        : DateTime.now().millisecondsSinceEpoch.toString();
    final txMap = _buildTransactionMap(
      txId: txId,
      r: r,
      rawMessage: rawMessage,
      outingId: outingId,
      isAutoLinked: isAutoLinked,
    );
    txMap['merchant'] = rule.displayName;
    txMap['category'] = rule.defaultCategory;
    txMap['purpose'] = rule.defaultPurposeType;
    txMap['isMerchantMapped'] = true;
    _appendTransactionToHive(txMap);
    _markProcessed(referenceId: r.parsed?.referenceId);

    MasterDebugLog.transaction(
      title: 'Transaction Saved',
      message: '${rule.displayName} • ₹${r.amount.toStringAsFixed(0)}',
      data: {'transactionId': txId, 'autoSaved': true},
    );
    if (isAutoLinked) {
      MasterDebugLog.outing(
        title: 'Outing Linked',
        message: outingId,
        level: MasterDebugLevel.success,
      );
    }
    MasterDebugLog.balance(
      title: 'Balance Updated',
      amountChanged: r.amount,
      extra: {'account': rule.defaultPurposeType, 'type': r.transactionType},
    );

    final notifyResolved = ResolvedSmsDetection(
      direction: r.direction,
      isExpense: r.isExpense,
      isTransfer: r.isTransfer,
      transactionType: r.transactionType,
      upiId: r.upiId,
      rawIdentifier: r.rawIdentifier,
      displayName: rule.displayName,
      amount: r.amount,
      bank: r.bank,
      parsed: r.parsed,
      matchedRule: rule,
      isKnownMerchant: true,
    );
    _notifyAutoAdded(
      notifyResolved,
      outingId: outingId,
      transactionId: txId,
      rawMessage: rawMessage,
      skipSystemNotification: skipSystemNotification,
    );

    TransactionDetectionValidator.logOutcome(
      transactionType: TransactionDetectionValidator.transactionTypeLabel(r),
      merchantIdentifier: TransactionDetectionValidator.primaryIdentifier(r, r.rawIdentifier),
      merchantRule: rule,
      verificationRequired: false,
      autoSaved: true,
      outingLinked: isAutoLinked,
      balanceUpdated: true,
      sourceLabel: sourceLabel,
    );
  }

  /// Row an active trip adopts on its own, from a detected spend.
  ///
  /// The trip takes the SMS as it stands: the payee straight off the message,
  /// no category guess, and `Outing` as the purpose so the trip's own totals
  /// pick it up. `isMerchantMapped` stays false — nothing was matched against
  /// the merchant DB, so renaming it later still teaches a rule.
  ///
  /// Shared by the background and foreground auto-add paths so a spend lands
  /// on the trip identically whether the app was open at the time or not.
  static Map<String, dynamic> _buildOutingTransactionMap({
    required String txId,
    required ResolvedSmsDetection r,
    required String rawMessage,
    required String outingId,
  }) {
    final txMap = _buildTransactionMap(
      txId: txId,
      r: r,
      rawMessage: rawMessage,
      outingId: outingId,
      isAutoLinked: true,
    );
    txMap['merchant'] = _outingMerchantName(r, rawMessage);
    txMap['category'] = 'Other';
    txMap['purpose'] = 'Outing';
    txMap['isMerchantMapped'] = false;
    return txMap;
  }

  static String _outingMerchantName(ResolvedSmsDetection r, String rawMessage) {
    final rawPayee = PayeeExtractor.extract(rawMessage) ?? r.displayName;
    return rawPayee.isNotEmpty && rawPayee.toLowerCase() != 'unknown'
        ? rawPayee
        : r.displayName;
  }

  static void _autoSaveOutingTransactionBackground({
    required ResolvedSmsDetection r,
    required String rawMessage,
    required String outingId,
    String? sourceLabel,
    String? notificationId,
    bool skipSystemNotification = false,
  }) {
    final txId = (notificationId != null && notificationId.isNotEmpty)
        ? notificationId
        : DateTime.now().millisecondsSinceEpoch.toString();
    final txMap = _buildOutingTransactionMap(
      txId: txId,
      r: r,
      rawMessage: rawMessage,
      outingId: outingId,
    );
    final merchantName = txMap['merchant'] as String;
    _appendTransactionToHive(txMap);
    _markProcessed(referenceId: r.parsed?.referenceId);

    MasterDebugLog.transaction(
      title: 'Outing Transaction Auto-Saved',
      message: '$merchantName • ₹${r.amount.toStringAsFixed(0)}',
      data: {'transactionId': txId, 'outingId': outingId, 'autoSaved': true},
    );

    final notifyResolved = ResolvedSmsDetection(
      direction: r.direction,
      isExpense: r.isExpense,
      isTransfer: r.isTransfer,
      transactionType: r.transactionType,
      upiId: r.upiId,
      rawIdentifier: r.rawIdentifier,
      displayName: merchantName,
      amount: r.amount,
      bank: r.bank,
      parsed: r.parsed,
      matchedRule: null,
      isKnownMerchant: false,
    );

    // The native listener already posted a "• Verify" notification under this
    // same id. Nothing is waiting to be verified any more, so post over it
    // instead of honouring [skipSystemNotification] and leaving the stale
    // prompt in the tray — same channel + id means it replaces, not stacks.
    final replacesNativeVerify =
        notificationId != null && notificationId.isNotEmpty;

    _notifyAutoAdded(
      notifyResolved,
      outingId: outingId,
      outingTitle: ActiveOutingHelper.titleForId(outingId),
      transactionId: txId,
      rawMessage: rawMessage,
      skipSystemNotification: skipSystemNotification && !replacesNativeVerify,
    );

    TransactionDetectionValidator.logOutcome(
      transactionType: TransactionDetectionValidator.transactionTypeLabel(r),
      merchantIdentifier: TransactionDetectionValidator.primaryIdentifier(r, r.rawIdentifier),
      merchantRule: null,
      verificationRequired: false,
      autoSaved: true,
      outingLinked: true,
      balanceUpdated: true,
      sourceLabel: sourceLabel,
    );
  }

  /// Background path for known merchant — notify with saved title, defer auto-add to foreground.
  static String _commitDeferredKnownMerchant({
    required ResolvedSmsDetection r,
    required String rawMessage,
    required MerchantRule rule,
    String? outingId,
    bool isAutoLinked = false,
    String? sourceLabel,
    bool skipSystemNotification = false,
  }) {
    final pendingId = _storeForVerification(
      r,
      rawMessage,
      outingId: outingId,
      isAutoLinked: isAutoLinked,
      savedTitle: rule.displayName,
      savedCategory: rule.defaultCategory,
      savedPurpose: rule.defaultPurposeType,
      deferAutoAdd: true,
    );

    final notifyR = ResolvedSmsDetection(
      direction: r.direction,
      isExpense: r.isExpense,
      isTransfer: r.isTransfer,
      transactionType: r.transactionType,
      upiId: r.upiId,
      rawIdentifier: r.rawIdentifier,
      displayName: rule.displayName,
      amount: r.amount,
      bank: r.bank,
      parsed: r.parsed,
      matchedRule: rule,
      isKnownMerchant: true,
    );
    _notifyAutoAdded(
      notifyR,
      outingId: outingId,
      transactionId: pendingId,
      rawMessage: rawMessage,
      skipSystemNotification: skipSystemNotification,
    );

    SmsDetectionDebugLog.log(
      level: SmsDebugLogLevel.info,
      message: 'step: deferred_auto_add_saved',
      source: sourceLabel,
      detail: 'id=$pendingId • ${rule.displayName} • ₹${r.amount.toInt()}',
    );

    return pendingId;
  }

  static void _notifyPendingVerification({
    required ResolvedSmsDetection r,
    required String txId,
    required String rawMessage,
    String? outingId,
    String? sourceLabel,
    bool skipSystemNotification = false,
  }) {
    final existing = DetectedSmsStorage.get(txId);
    if (existing?.notificationShown == true) {
      skipSystemNotification = true;
    }

    final rawPayee = PayeeExtractor.extract(rawMessage) ?? r.displayName;

    final payloadJson = jsonEncode({
      'transactionId': txId,
      'pending': true,
    });

    if (!skipSystemNotification) {
      if (outingId != null) {
        final outingTitle = ActiveOutingHelper.titleForId(outingId);
        SmsNotificationService.showOutingPendingVerification(
          amount: r.amount,
          merchant: rawPayee,
          outingTitle: outingTitle ?? 'Trip',
          bank: r.bank,
          type: r.transactionType,
          payload: payloadJson,
          transactionId: txId,
          rawMessage: rawMessage,
        );
      } else {
        SmsNotificationService.showPendingNotification(
          amount: r.amount,
          merchant: rawPayee,
          bank: r.bank,
          type: r.transactionType,
          payload: payloadJson,
          transactionId: txId,
          rawMessage: rawMessage,
        );
        DetectedSmsStorage.markNotificationShown(txId);
      }
    }

    final pendingCopy = SmsNotificationCopy.build(
      type: r.transactionType,
      amount: r.amount,
      merchantExists: false,
      merchantTitle: null,
      payee: rawPayee,
      bank: r.bank,
    );
    final pendingLine = SmsNotificationCopy.displayLine(
      title: pendingCopy.title,
      body: pendingCopy.body,
    );

    NotificationHistoryService.add(
      title: 'SMS needs verification',
      body: pendingLine,
      type: 'sms_pending',
    );

    SmsDetectionDebugLog.log(
      level: SmsDebugLogLevel.info,
      message: 'notification_history: sms_pending added',
      source: sourceLabel,
      detail: pendingLine,
    );
  }

  /// [outingTitle] switches the copy to the trip line ("🏖 Goa • Spent ₹500 •
  /// Added to Outing"). Only the trip auto-add passes it: a known merchant is
  /// still announced by name even when a trip happens to be running.
  static void _notifyAutoAdded(
    ResolvedSmsDetection r, {
    String? outingId,
    String? outingTitle,
    String? transactionId,
    String? rawMessage,
    bool skipSystemNotification = false,
  }) {
    final title = r.matchedRule?.displayName ?? r.displayName;
    final shouldSkip = skipSystemNotification || AppForegroundDetector.isInForeground;
    if (!shouldSkip) {
      SmsNotificationService.showTransactionAutoAdded(
        amount: r.amount,
        merchant: title,
        bank: r.bank,
        type: r.transactionType,
        outingTitle: outingTitle,
        transactionId: transactionId,
        rawMessage: rawMessage,
      );
    }
    final addedCopy = SmsNotificationCopy.build(
      type: r.transactionType,
      amount: r.amount,
      merchantExists: true,
      merchantTitle: title,
      payee: null,
      bank: r.bank,
      outingTitle: outingTitle,
    );
    NotificationHistoryService.add(
      title: 'Auto-detected transaction',
      body: SmsNotificationCopy.displayLine(
        title: addedCopy.title,
        body: addedCopy.body,
      ),
      type: 'sms_auto',
    );
  }

  static bool get _merchantAutoMatchOn => readSmsMerchantAutoMatchSetting();

  /// Registered account only. A missing or ambiguous account must still confirm.
  static String? _registeredAccountName(String bank, {String? accountLast4}) {
    try {
      final raw = Hive.box('settings').get('onboardingAccounts');
      if (raw is! List) return null;
      final accounts = <Map<dynamic, dynamic>>[];
      for (final e in raw) {
        if (e is Map) accounts.add(Map<dynamic, dynamic>.from(e));
      }

      final last4 = accountLast4?.trim() ?? '';
      if (last4.isNotEmpty) {
        for (final a in accounts) {
          if ((a['last4Digits'] ?? '').toString() == last4) {
            final name = (a['name'] ?? '').toString().trim();
            if (name.isNotEmpty) return name;
          }
        }
        return null;
      }

      final bankLower = bank.trim().toLowerCase();
      if (bankLower.isEmpty || bankLower == 'bank') return null;
      final hits = <String>[];
      for (final a in accounts) {
        final name = (a['name'] ?? '').toString().trim();
        final nl = name.toLowerCase();
        if (nl.isEmpty) continue;
        if (nl.contains(bankLower) || bankLower.contains(nl)) hits.add(name);
      }
      if (hits.isEmpty) {
        // "SBI" vs an account saved as "State Bank of India".
        final key = bankKeyForLabel(bank);
        if (key.isNotEmpty) {
          for (final a in accounts) {
            final name = (a['name'] ?? '').toString().trim();
            if (name.isNotEmpty && bankTokenForAccountName(name) == key) {
              hits.add(name);
            }
          }
        }
      }
      if (hits.length == 1) return hits.first;
    } catch (_) {}
    return null;
  }

  static bool _usableMerchantName(String name) {
    final trimmed = name.trim();
    if (!PayeeNormalizer.isMeaningful(trimmed)) return false;
    if (MerchantRuleService.looksLikeUpi(trimmed)) return false;
    if (MerchantRuleService.looksLikePhone(trimmed)) return false;
    if (!RegExp(r'[A-Za-z]').hasMatch(trimmed)) return false;
    const noise = {
      'upi',
      'neft',
      'imps',
      'rtgs',
      'atm',
      'debit',
      'credit',
      'payment',
      'transfer',
      'merchant',
      'unknown',
      'refund',
      'cash',
    };
    return !noise.contains(PayeeNormalizer.normalize(trimmed));
  }

  static bool _confidentMerchantName(String name) {
    final trimmed = name.trim();
    return trimmed.length >= 3 && _usableMerchantName(trimmed);
  }

  static _MerchantAutoMatchChoice? _existingMerchantChoice(String rawName) {
    if (!_usableMerchantName(rawName)) return null;
    final norm = PayeeNormalizer.normalize(rawName);
    if (norm.isEmpty) return null;

    for (final record in MerchantLearningService.listAll()) {
      final titleNorm = PayeeNormalizer.normalize(record.title);
      final payeeNorm = record.normalizedPayee.isNotEmpty
          ? record.normalizedPayee
          : PayeeNormalizer.normalize(record.payee);
      if (payeeNorm == norm || titleNorm == norm) {
        final title = record.title.trim().isNotEmpty ? record.title.trim() : rawName.trim();
        return _MerchantAutoMatchChoice(
          merchant: title,
          category: record.category.trim().isNotEmpty ? record.category : 'Other',
          purpose: record.purpose.trim().isNotEmpty ? record.purpose : 'Personal',
          mapped: true,
        );
      }
    }

    if (Hive.isBoxOpen('merchant_rules_box')) {
      for (final raw in Hive.box('merchant_rules_box').values) {
        if (raw is! Map) continue;
        final display = (raw['displayName'] ?? raw['merchantName'] ?? '').toString();
        final identifier = (raw['identifier'] ?? '').toString();
        if (PayeeNormalizer.normalize(display) != norm &&
            PayeeNormalizer.normalize(identifier) != norm) {
          continue;
        }
        final title = display.trim().isNotEmpty ? display.trim() : rawName.trim();
        final category = (raw['defaultCategory'] ?? raw['category'] ?? 'Other').toString();
        final purpose = (raw['defaultPurposeType'] ?? raw['purpose'] ?? 'Personal').toString();
        return _MerchantAutoMatchChoice(
          merchant: title,
          category: category.trim().isNotEmpty ? category : 'Other',
          purpose: purpose.trim().isNotEmpty ? purpose : 'Personal',
          mapped: true,
        );
      }
    }

    if (Hive.isBoxOpen('transactions')) {
      final rawTxs = Hive.box('transactions').get('list', defaultValue: []);
      if (rawTxs is List) {
        for (final e in rawTxs) {
          if (e is! Map) continue;
          if (e['isPendingVerification'] == true) continue;
          final merchant = (e['merchant'] ?? '').toString();
          if (PayeeNormalizer.normalize(merchant) != norm) continue;
          final category = (e['category'] ?? 'Other').toString();
          final purpose = (e['purpose'] ?? 'Personal').toString();
          return _MerchantAutoMatchChoice(
            merchant: merchant.trim(),
            category: category.trim().isNotEmpty ? category : 'Other',
            purpose: purpose.trim().isNotEmpty ? purpose : 'Personal',
            mapped: true,
          );
        }
      }
    }
    return null;
  }

  /// Name taken from a matched bank or user SMS template, not a loose guess.
  static String? _templateMerchantName(String rawMessage) {
    try {
      final v4 = BankSmsV4Parser.parseSync(rawMessage);
      if (v4 != null && _confidentMerchantName(v4.displayTitle)) {
        return v4.displayTitle.trim();
      }
    } catch (_) {}
    try {
      final user = SmsTemplateEngine.tryMatch(rawMessage);
      if (user != null &&
          user.hasTaggedTitle &&
          _confidentMerchantName(user.parsed.name)) {
        return user.parsed.name.trim();
      }
    } catch (_) {}
    return null;
  }

  static _MerchantAutoMatchChoice? _merchantAutoMatchChoice(
    ResolvedSmsDetection resolved,
    String rawMessage,
  ) {
    final extracted = PayeeExtractor.extract(rawMessage) ?? resolved.displayName;
    final existing = _existingMerchantChoice(extracted) ??
        _existingMerchantChoice(resolved.displayName);
    if (existing != null) return existing;

    final templateName = _templateMerchantName(rawMessage);
    if (templateName == null) return null;
    return _existingMerchantChoice(templateName) ??
        _MerchantAutoMatchChoice(
          merchant: templateName,
          category: 'Other',
          purpose: 'Personal',
          mapped: false,
        );
  }

  static bool _transactionAlreadyStored({
    String? refId,
    required String rawMessage,
    String? id,
  }) {
    if (!Hive.isBoxOpen('transactions')) return false;
    final rawTxs = Hive.box('transactions').get('list', defaultValue: []);
    if (rawTxs is! List) return false;
    for (final e in rawTxs) {
      if (e is! Map) continue;
      if (e['isPendingVerification'] == true) continue;
      final existingId = (e['id'] ?? '').toString();
      if (id != null && id.isNotEmpty && existingId == id) return true;
      if (refId != null && refId.isNotEmpty && (e['referenceId'] ?? '') == refId) {
        return true;
      }
      if (rawMessage.isNotEmpty && (e['rawMessage'] ?? '') == rawMessage) {
        return true;
      }
    }
    return false;
  }

  static void _dropPendingForSms({
    required String rawMessage,
    String? refId,
    required double amount,
    required DateTime date,
    WidgetRef? ref,
  }) {
    final ids = <String>{};
    final byKey = _findExistingPendingId(refId: refId, amount: amount, date: date);
    final byRaw = _findPendingIdForRawMessage(rawMessage);
    if (byKey != null) ids.add(byKey);
    if (byRaw != null) ids.add(byRaw);
    for (final id in ids) {
      SmsPendingService.remove(id);
      ref?.read(detectionQueueProvider.notifier).removePending(id);
    }
  }

  /// On: skip merchant verify when the name is an existing merchant or a
  /// confident SMS-rule title, and amount plus a real account are present.
  /// Off, or anything missing: caller keeps the confirm path.
  static _MerchantAutoMatchResult _applyMerchantAutoMatch({
    required ResolvedSmsDetection resolved,
    required String rawMessage,
    required DateTime txDate,
    String? outingId,
    bool isAutoLinked = false,
    String? sourceLabel,
    bool skipSystemNotification = false,
    WidgetRef? ref,
  }) {
    if (!_merchantAutoMatchOn) return _MerchantAutoMatchResult.notEligible;
    if (!resolved.isExpense || resolved.isTransfer) {
      return _MerchantAutoMatchResult.notEligible;
    }
    if (resolved.amount <= 0) return _MerchantAutoMatchResult.notEligible;

    final account = _registeredAccountName(
      resolved.bank,
      accountLast4: resolved.parsed?.accountLast4,
    );
    if (account == null) return _MerchantAutoMatchResult.notEligible;

    final choice = _merchantAutoMatchChoice(resolved, rawMessage);
    if (choice == null) return _MerchantAutoMatchResult.notEligible;

    final refId = resolved.parsed?.referenceId;
    if (_transactionAlreadyStored(refId: refId, rawMessage: rawMessage)) {
      _dropPendingForSms(
        rawMessage: rawMessage,
        refId: refId,
        amount: resolved.amount,
        date: txDate,
        ref: ref,
      );
      return _MerchantAutoMatchResult.alreadySaved;
    }

    final pendingId = _findExistingPendingId(
          refId: refId,
          amount: resolved.amount,
          date: txDate,
        ) ??
        _findPendingIdForRawMessage(rawMessage);
    final txId = (pendingId != null && pendingId.isNotEmpty)
        ? pendingId
        : DateTime.now().millisecondsSinceEpoch.toString();
    if (_transactionAlreadyStored(refId: refId, rawMessage: rawMessage, id: txId)) {
      _dropPendingForSms(
        rawMessage: rawMessage,
        refId: refId,
        amount: resolved.amount,
        date: txDate,
        ref: ref,
      );
      return _MerchantAutoMatchResult.alreadySaved;
    }

    final txMap = _buildTransactionMap(
      txId: txId,
      r: resolved,
      rawMessage: rawMessage,
      outingId: outingId,
      isAutoLinked: isAutoLinked,
    );
    txMap['merchant'] = choice.merchant;
    txMap['category'] = choice.category;
    txMap['purpose'] = choice.purpose;
    txMap['account'] = account;
    txMap['isMerchantMapped'] = choice.mapped;
    txMap['isPendingVerification'] = false;

    if (pendingId != null) {
      SmsPendingService.remove(pendingId);
      ref?.read(detectionQueueProvider.notifier).removePending(pendingId);
    }

    if (ref != null) {
      ref.read(model.transactionProvider.notifier).addTransaction(
            model.Transaction.fromJson(txMap),
          );
      ref.invalidate(model.transactionProvider);
      ref.invalidate(outingProvider);
    } else {
      _appendTransactionToHive(txMap);
    }
    _markProcessed(referenceId: refId);

    _notifyAutoAdded(
      ResolvedSmsDetection(
        direction: resolved.direction,
        isExpense: resolved.isExpense,
        isTransfer: resolved.isTransfer,
        transactionType: resolved.transactionType,
        upiId: resolved.upiId,
        rawIdentifier: resolved.rawIdentifier,
        displayName: choice.merchant,
        amount: resolved.amount,
        bank: resolved.bank,
        parsed: resolved.parsed,
        matchedRule: resolved.matchedRule,
        isKnownMerchant: choice.mapped,
      ),
      outingId: outingId,
      transactionId: txId,
      rawMessage: rawMessage,
      skipSystemNotification: skipSystemNotification,
    );
    if (ref != null) ref.invalidate(notificationHistoryProvider);

    TransactionDetectionValidator.logOutcome(
      transactionType: TransactionDetectionValidator.transactionTypeLabel(resolved),
      merchantIdentifier: choice.merchant,
      merchantRule: resolved.matchedRule,
      verificationRequired: false,
      autoSaved: true,
      outingLinked: isAutoLinked,
      balanceUpdated: true,
      sourceLabel: sourceLabel ?? 'merchant_auto_match',
    );
    return _MerchantAutoMatchResult.saved;
  }

  /// Background SMS handler — core branch for killed/background app.
  ///
  /// | Merchant state | Action |
  /// |----------------|--------|
  /// | **New payee**  | [SmsPendingService.save] + "Spent ₹X - Verify" notification. Never auto-add. |
  /// | **Known payee**| Auto-add [Transaction] to Hive + "Spent ₹X - Added" / saved title • bank. |
  ///
  /// Invoked from: [SmsDetectionPipeline] (SMS broadcast), [handleNativePayload]
  /// (notification listener), [BackgroundSmsProcessor] (WorkManager).
  static BackgroundSmsOutcome handleBackgroundSms({
    required String rawMessage,
    TransactionParsed? parsed,
    String? fallbackType,
    double? amountOverride,
    String? merchantOverride,
    String? bankOverride,
    String? pendingId,
    String? sourceLabel,
    bool skipSystemNotification = false,
  }) {
    final settings = Hive.box('settings');
    if (settings.get('auto_detection', defaultValue: true) != true) {
      return BackgroundSmsOutcome.skipped;
    }

    if (SmsRuleEngine.isBlocked(rawMessage)) {
      SmsRuleEngine.ignoreMessage(rawMessage, 'Matched User Block Rule');
      return BackgroundSmsOutcome.skipped;
    }

    if (SmsTransactionFilters.shouldIgnore(rawMessage)) {
      SmsRuleEngine.ignoreMessage(rawMessage, 'Non-transaction / account update alert ignored');
      return BackgroundSmsOutcome.skipped;
    }

    // Same "only banks the user added" gate the native listener and the SMS
    // pipeline apply, so the WorkManager and native-payload paths agree —
    // including the third answer. A message for an account the user has not
    // added proposes that account and stops, rather than vanishing; the app
    // being closed is exactly when a forgotten card would otherwise never
    // surface. See docs/ACCOUNT_DISCOVERY.md.
    final allow = BankAllowlistService.evaluate(rawMessage);
    if (allow == AllowResult.blocked) {
      SmsRuleEngine.ignoreMessage(rawMessage, 'Not from a bank the user added');
      return BackgroundSmsOutcome.skipped;
    }
    if (allow == AllowResult.discovery) {
      AccountDiscoveryService.record(rawMessage: rawMessage);
      SmsRuleEngine.ignoreMessage(
        rawMessage,
        'Unknown account — suggested for review, no transaction created',
      );
      return BackgroundSmsOutcome.skipped;
    }

    final resolved = _resolve(
      rawMessage: rawMessage,
      parsed: parsed,
      fallbackType: fallbackType,
      amountOverride: amountOverride,
      merchantOverride: merchantOverride,
      bankOverride: bankOverride,
    );

    if (_isDuplicate(
          refId: parsed?.referenceId,
          amount: resolved.amount,
          date: _localAutoAddDate(parsed?.dateTime),
        )) {
      return BackgroundSmsOutcome.skipped;
    }

    final txDate = _localAutoAddDate(parsed?.dateTime);
    final outingLink = ActiveOutingHelper.resolve(
      isExpense: resolved.isExpense,
      isTransfer: resolved.isTransfer,
      transactionDate: txDate,
    );
    final outingId = outingLink?.id;
    final isAutoLinked = outingId != null;

    final lookup = TransactionDetectionValidator.evaluateMerchant(
      resolved: resolved,
      rawMessage: rawMessage,
      sourceLabel: sourceLabel ?? 'background',
    );

    if (lookup.isKnown && lookup.rule != null) {
      _autoSaveKnownMerchantBackground(
        r: resolved,
        rawMessage: rawMessage,
        rule: lookup.rule!,
        outingId: outingId,
        isAutoLinked: isAutoLinked,
        sourceLabel: sourceLabel,
        notificationId: pendingId,
        skipSystemNotification: skipSystemNotification,
      );
      return BackgroundSmsOutcome.autoAdded;
    }

    if (isAutoLinked) {
      _autoSaveOutingTransactionBackground(
        r: resolved,
        rawMessage: rawMessage,
        outingId: outingId,
        sourceLabel: sourceLabel,
        notificationId: pendingId,
        skipSystemNotification: skipSystemNotification,
      );
      return BackgroundSmsOutcome.autoAdded;
    }

    final autoMatch = _applyMerchantAutoMatch(
      resolved: resolved,
      rawMessage: rawMessage,
      txDate: txDate,
      outingId: outingId,
      isAutoLinked: isAutoLinked,
      sourceLabel: sourceLabel ?? 'background',
      skipSystemNotification: skipSystemNotification,
    );
    if (autoMatch == _MerchantAutoMatchResult.saved) {
      return BackgroundSmsOutcome.autoAdded;
    }
    if (autoMatch == _MerchantAutoMatchResult.alreadySaved) {
      return BackgroundSmsOutcome.skipped;
    }

    if (pendingId != null && pendingId.isNotEmpty) {
      if (SmsPendingService.get(pendingId) != null) {
        _ensurePendingInQueue(pendingId);
        return BackgroundSmsOutcome.pendingVerification;
      }

      final existingPid = _findExistingPendingId(
        refId: resolved.parsed?.referenceId,
        amount: resolved.amount,
        date: txDate,
      );

      if (existingPid != null && existingPid != pendingId) {
        final existingPending = SmsPendingService.get(existingPid);
        if (existingPending != null) {
          SmsPendingService.remove(existingPid);
          final updatedPending = PendingTransaction(
            id: pendingId,
            amount: existingPending.amount,
            receiver: existingPending.receiver,
            bank: existingPending.bank,
            date: existingPending.date,
            rawMessage: existingPending.rawMessage,
            isExpense: existingPending.isExpense,
            isTransfer: existingPending.isTransfer,
            accountLast4: existingPending.accountLast4,
            referenceId: existingPending.referenceId,
            upiId: existingPending.upiId,
            outingId: existingPending.outingId,
            isAutoLinked: existingPending.isAutoLinked,
            notificationShown: true,
            popupOpened: existingPending.popupOpened,
            savedTitle: existingPending.savedTitle,
            savedCategory: existingPending.savedCategory,
            savedPurpose: existingPending.savedPurpose,
            deferAutoAdd: existingPending.deferAutoAdd,
          );
          SmsPendingService.save(updatedPending);
        }
        return BackgroundSmsOutcome.pendingVerification;
      } else if (existingPid != null) {
        _ensurePendingInQueue(existingPid);
        return BackgroundSmsOutcome.pendingVerification;
      }
    } else {
      final existingPid = _findExistingPendingId(
        refId: resolved.parsed?.referenceId,
        amount: resolved.amount,
        date: txDate,
      );
      if (existingPid != null) {
        _ensurePendingInQueue(existingPid);
        return BackgroundSmsOutcome.pendingVerification;
      }
    }

    _commitUnknownMerchantPending(
      r: resolved,
      rawMessage: rawMessage,
      pendingId: pendingId,
      outingId: outingId,
      isAutoLinked: isAutoLinked,
      sourceLabel: sourceLabel,
      skipSystemNotification: skipSystemNotification,
      allowAutoAddIfKnown: false,
    );
    return BackgroundSmsOutcome.pendingVerification;
  }

  /// Flush background-deferred known merchants when app enters foreground.
  static Future<int> flushDeferredAutoAdds({
    required WidgetRef ref,
  }) async {
    if (!Hive.isBoxOpen('detected_sms_box')) return 0;
    var added = 0;
    final pendings = DetectedSmsStorage.getAll()
        .where((p) => p.deferAutoAdd && p.savedTitle != null)
        .toList();

    for (final pending in pendings) {
      final txId = DateTime.now().millisecondsSinceEpoch.toString();
      final detectedBankAccount = resolveAccountName(pending.bank,
          accountLast4: pending.accountLast4);
      final isCashDeposit = pending.isTransfer &&
          SmsDirectionHelper.isCashDepositAtSelfMachineSms(pending.rawMessage);
      final cashAccount = resolveCashAccountName();
      final fromAccount = isCashDeposit ? cashAccount : detectedBankAccount;
      final toAccount = isCashDeposit ? detectedBankAccount : cashAccount;
      final tx = model.Transaction(
        id: txId,
        merchant: pending.savedTitle!,
        category: pending.savedCategory ?? 'Other',
        account: pending.isTransfer ? fromAccount : detectedBankAccount,
        purpose: pending.savedPurpose ?? 'Personal',
        time: 'Auto-added',
        amount: pending.amount,
        isExpense: pending.isExpense,
        isAutoDetected: true,
        paymentType: pending.isTransfer ? (isCashDeposit ? 'Online' : 'Cash') : 'Online',
        date: pending.date,
        rawIdentifier: PayeeNormalizer.normalize(pending.receiver),
        bankName: pending.bank,
        accountLast4: pending.accountLast4,
        referenceId: pending.referenceId,
        upiId: pending.upiId,
        rawMessage: pending.rawMessage,
        note: '',
        outingId: pending.outingId,
        isAutoLinked: pending.isAutoLinked,
        isPendingVerification: false,
        isMerchantMapped: true,
        isTransfer: pending.isTransfer,
        transferTo: pending.isTransfer ? toAccount : null,
        toAccountId: pending.isTransfer ? resolveAccountId(toAccount) : null,
        transferType: pending.isTransfer
            ? (isCashDeposit ? 'cash_to_bank' : 'bank_to_cash')
            : null,
      );

      ref.read(model.transactionProvider.notifier).addTransaction(tx);
      DetectedSmsStorage.remove(pending.id);
      ref.read(detectionQueueProvider.notifier).removePending(pending.id);
      _markProcessed(referenceId: pending.referenceId);

      added++;
    }

    if (added > 0) {
      ref.invalidate(model.transactionProvider);
      ref.invalidate(outingProvider);
    }
    return added;
  }

  /// Background / native payload entry.
  /// Known merchant → auto-add + notification. Unknown → pending verify.
  /// Materializes a native notification-listener payload into Hive pending / auto-add.
  /// Returns the pending transaction id when verification is required.
  static String? handleNativePayload(Map<String, dynamic> jsonMap) {
    // Native code stamps this. Payloads without it (including anything an
    // exported activity used to accept from other apps) are ignored.
    if (jsonMap['origin']?.toString() != 'spentx_internal') return null;
    final amount = double.tryParse(
          jsonMap['amount'].toString().replaceAll(',', ''),
        ) ??
        0.0;
    final bank = jsonMap['bank']?.toString() ?? 'Bank';
    final merchant = jsonMap['merchant']?.toString();
    final rawText = jsonMap['rawText']?.toString() ?? '';
    final type = jsonMap['type']?.toString() ?? 'debit';
    final skipNotif = jsonMap['nativeNotifShown'] == true;
    final pendingId = jsonMap['transactionId']?.toString();

    if (pendingId != null &&
        pendingId.isNotEmpty &&
        SmsPendingService.get(pendingId) != null) {
      _ensurePendingInQueue(pendingId);
      return pendingId;
    }

    if (rawText.isNotEmpty && SmsTransactionFilters.shouldIgnore(rawText)) {
      SmsRuleEngine.ignoreMessage(rawText, 'Ignored non-transaction native payload');
      return null;
    }

    final parsed = rawText.isNotEmpty
        ? SmsRuleEngine.parse(rawText, smsReceivedTime: DateTime.now())
        : null;

    final outcome = handleBackgroundSms(
      rawMessage: rawText.isNotEmpty ? rawText : '$type $amount $bank',
      parsed: parsed,
      fallbackType: type,
      amountOverride: parsed?.amount ?? amount,
      merchantOverride: merchant,
      bankOverride: bank,
      pendingId: pendingId,
      sourceLabel: 'native_payload',
      skipSystemNotification: skipNotif,
    );

    if (outcome == BackgroundSmsOutcome.autoAdded) return null;
    if (outcome == BackgroundSmsOutcome.skipped) return null;

    if (pendingId != null && pendingId.isNotEmpty) {
      _ensurePendingInQueue(pendingId);
      return pendingId;
    }

    return _findExistingPendingId(
      refId: parsed?.referenceId,
      amount: parsed?.amount ?? amount,
      date: _localAutoAddDate(parsed?.dateTime),
    );
  }

  /// Pending id whose stored SMS text is byte-for-byte [rawMessage].
  ///
  /// The amount/ref lookup in [_findExistingPendingId] misses when the pending
  /// was written from a native payload that parsed the same message
  /// differently, so this second pass keys on the one thing both copies share.
  static String? _findPendingIdForRawMessage(String rawMessage) {
    if (!Hive.isBoxOpen('detected_sms_box')) return null;
    for (final raw in Hive.box('detected_sms_box').values) {
      final p = (raw is Map) ? Map<String, dynamic>.from(raw) : <String, dynamic>{};
      if (p['rawMessage']?.toString() != rawMessage) continue;
      final pid = p['id']?.toString();
      if (pid != null && pid.isNotEmpty) return pid;
    }
    return null;
  }

  static void _ensurePendingInQueue(String txId) {
    if (!Hive.isBoxOpen('pending_detections')) return;
    final qbox = Hive.box('pending_detections');
    final queue = List<String>.from(qbox.get('queue', defaultValue: const <dynamic>[]));
    if (!queue.contains(txId)) {
      queue.add(txId);
      qbox.put('queue', queue);
    }
  }

  /// Foreground entry from live SMS stream.
  static Future<dynamic> handleForeground({
    required WidgetRef ref,
    required BuildContext context,
    required String rawMessage,
    required double amount,
    required String merchant,
    required String bank,
    required String type,
    bool forcePopup = false,
    model.Transaction? existingTx,
    bool skipNotification = false,
  }) async {
    final settings = Hive.box('settings');
    final isAutoOn = settings.get('auto_detection', defaultValue: true);
    if (!isAutoOn && !forcePopup) {
      // Automatic SMS Detection is OFF — ignore live SMS (no auto, no pending creation from notifications).
      // forcePopup allows lab/simulator to still test UI even if off.
      return false;
    }

    if (existingTx != null) {
      return await PremiumBottomSheet.show(
        context: context,
        child: DetectionPopup(pendingTx: existingTx),
      );
    }

    if (SmsRuleEngine.isBlocked(rawMessage)) {
      SmsRuleEngine.ignoreMessage(rawMessage, 'Matched User Block Rule (Foreground)');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('SMS Ignored (Blocked by Rule)')),
      );
      return;
    }

    final parsed = SmsRuleEngine.parse(rawMessage, smsReceivedTime: DateTime.now());

    if (!forcePopup &&
        _isDuplicate(
          refId: parsed?.referenceId,
          amount: parsed?.amount ?? amount,
          date: _localAutoAddDate(parsed?.dateTime),
        )) {
      return;
    }

    final resolved = _resolve(
      rawMessage: rawMessage,
      parsed: parsed,
      fallbackType: type,
      amountOverride: parsed?.amount ?? amount,
      merchantOverride: merchant,
      bankOverride: bank,
    );

    final txDate = _localAutoAddDate(parsed?.dateTime);
    final outingLink = ActiveOutingHelper.resolve(
      isExpense: resolved.isExpense,
      isTransfer: resolved.isTransfer,
      transactionDate: txDate,
    );
    final outingId = outingLink?.id;
    final isAutoLinked = outingId != null;

    final lookup = TransactionDetectionValidator.evaluateMerchant(
      resolved: resolved,
      rawMessage: rawMessage,
      sourceLabel: 'foreground',
    );
    final rule = lookup.rule;

    if (lookup.isKnown && rule != null) {
      final txId = DateTime.now().millisecondsSinceEpoch.toString();
      final detectedBankAccount = resolveAccountName(resolved.bank,
          accountLast4: parsed?.accountLast4);
      final cashAccount = resolveCashAccountName();
      final fromAccount =
          resolved.isCashDeposit ? cashAccount : detectedBankAccount;
      final toAccount =
          resolved.isCashDeposit ? detectedBankAccount : cashAccount;
      final tx = model.Transaction(
        id: txId,
        merchant: rule.displayName,
        category: rule.defaultCategory,
        account: resolved.isTransfer ? fromAccount : detectedBankAccount,
        purpose: rule.defaultPurposeType,
        time: 'Auto-added',
        amount: resolved.amount,
        isExpense: resolved.isExpense,
        isAutoDetected: true,
        paymentType:
            resolved.isTransfer ? (resolved.isCashDeposit ? 'Online' : 'Cash') : 'Online',
        date: txDate,
        rawIdentifier: resolved.merchantLookupKey,
        bankName: resolved.bank,
        accountLast4: parsed?.accountLast4 ?? '',
        referenceId: parsed?.referenceId ?? '',
        upiId: resolved.upiId,
        rawMessage: parsed?.rawMessage ?? rawMessage,
        note: '',
        outingId: outingId,
        isAutoLinked: isAutoLinked,
        isPendingVerification: false,
        isMerchantMapped: true,
        isTransfer: resolved.isTransfer,
        transferTo: resolved.isTransfer ? toAccount : null,
        toAccountId: resolved.isTransfer ? resolveAccountId(toAccount) : null,
        transferType: resolved.isTransfer
            ? (resolved.isCashDeposit ? 'cash_to_bank' : 'bank_to_cash')
            : null,
      );

      ref.read(model.transactionProvider.notifier).addTransaction(tx);
      ref.invalidate(model.transactionProvider);
      ref.invalidate(outingProvider);
      _markProcessed(referenceId: parsed?.referenceId);

      final notifyR = ResolvedSmsDetection(
        direction: resolved.direction,
        isExpense: resolved.isExpense,
        isTransfer: resolved.isTransfer,
        transactionType: resolved.transactionType,
        upiId: resolved.upiId,
        rawIdentifier: resolved.rawIdentifier,
        displayName: rule.displayName,
        amount: resolved.amount,
        bank: resolved.bank,
        parsed: resolved.parsed,
        matchedRule: rule,
        isKnownMerchant: true,
      );
      _notifyAutoAdded(notifyR, outingId: outingId, transactionId: txId, rawMessage: rawMessage);
      ref.invalidate(notificationHistoryProvider);

      TransactionDetectionValidator.logOutcome(
        transactionType: TransactionDetectionValidator.transactionTypeLabel(resolved),
        merchantIdentifier: lookup.merchantIdentifier,
        merchantRule: rule,
        verificationRequired: false,
        autoSaved: true,
        outingLinked: isAutoLinked,
        balanceUpdated: true,
        sourceLabel: 'foreground',
      );

      if (isAutoLinked && context.mounted) {
        final outingTitle = outingLink?.title ?? ActiveOutingHelper.titleForId(outingId) ?? 'Trip';
        ScaffoldMessenger.of(context).hideCurrentSnackBar();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              '₹${resolved.amount.toInt()} added to $outingTitle (${rule.displayName})',
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
            backgroundColor: const Color(0xFF064E3B),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            duration: const Duration(seconds: 6),
            action: SnackBarAction(
              label: 'UNLINK',
              textColor: const Color(0xFF34D399),
              onPressed: () {
                ref
                    .read(model.transactionProvider.notifier)
                    .updateTransactionOuting(txId, null);
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Unlinked from trip — kept as personal spend'),
                      backgroundColor: AppColors.expense,
                      behavior: SnackBarBehavior.floating,
                    ),
                  );
                }
              },
            ),
          ),
        );
      }

      return true;
    }

    // A running trip adopts every spend it sees, merchant known or not — no
    // verification step. The background path already did this; with the app
    // open the same SMS used to stop at the verify popup, so whether a spend
    // reached the trip by itself depended on nothing more than whether the
    // user happened to have the app in front of them.
    //
    // Detection is not loosened to get there. Everything that decides whether
    // this is a real spend of the user's own money has already run: the user's
    // block rules (above), the bank allowlist and the non-transaction filter
    // (re-checked here, since the pipeline is not the only caller), and
    // [ActiveOutingHelper.resolve] — which leaves `outingId` null for anything
    // but a plain expense, so income, ATM withdrawals and cash deposits still
    // take the normal verify path. `forcePopup` is the SMS Lab's explicit
    // "show me the popup" switch and still wins.
    if (outingId != null &&
        !forcePopup &&
        BankAllowlistService.allows(rawMessage) &&
        !SmsTransactionFilters.shouldIgnore(rawMessage)) {
      // This SMS may already have a pending entry — the native listener or a
      // background pass can have queued one before the app came up, and
      // [_isDuplicate] deliberately does not treat a pending as a duplicate.
      // The trip adopts the spend now, so clear that entry rather than leave
      // an orphaned verify prompt beside the transaction, and reuse its id so
      // the "• Verify" notification is replaced instead of stacked.
      final supersededPendingId = _findExistingPendingId(
            refId: parsed?.referenceId,
            amount: resolved.amount,
            date: txDate,
          ) ??
          _findPendingIdForRawMessage(rawMessage);
      final txId = supersededPendingId ??
          DateTime.now().millisecondsSinceEpoch.toString();
      final txMap = _buildOutingTransactionMap(
        txId: txId,
        r: resolved,
        rawMessage: rawMessage,
        outingId: outingId,
      );
      final merchantName = txMap['merchant'] as String;

      if (supersededPendingId != null) {
        // Verified by the trip rather than by hand, but verified — so the
        // history row closes instead of sitting "awaiting" forever.
        PendingVerificationHistoryService.markVerified(supersededPendingId);
        SmsPendingService.remove(supersededPendingId);
        ref.read(detectionQueueProvider.notifier).removePending(supersededPendingId);
      }

      ref
          .read(model.transactionProvider.notifier)
          .addTransaction(model.Transaction.fromJson(txMap));
      ref.invalidate(model.transactionProvider);
      ref.invalidate(outingProvider);
      _markProcessed(referenceId: parsed?.referenceId);

      MasterDebugLog.transaction(
        title: 'Outing Transaction Auto-Saved',
        message: '$merchantName • ₹${resolved.amount.toStringAsFixed(0)}',
        data: {
          'transactionId': txId,
          'outingId': outingId,
          'autoSaved': true,
          'source': 'foreground',
        },
      );

      final outingTitle = outingLink?.title ?? ActiveOutingHelper.titleForId(outingId);
      _notifyAutoAdded(
        ResolvedSmsDetection(
          direction: resolved.direction,
          isExpense: resolved.isExpense,
          isTransfer: resolved.isTransfer,
          transactionType: resolved.transactionType,
          upiId: resolved.upiId,
          rawIdentifier: resolved.rawIdentifier,
          displayName: merchantName,
          amount: resolved.amount,
          bank: resolved.bank,
          parsed: resolved.parsed,
          matchedRule: null,
          isKnownMerchant: false,
        ),
        outingId: outingId,
        outingTitle: outingTitle,
        transactionId: txId,
        rawMessage: rawMessage,
        skipSystemNotification: skipNotification,
      );
      ref.invalidate(notificationHistoryProvider);

      SmsDetectionDebugLog.log(
        level: SmsDebugLogLevel.success,
        message: 'Foreground: active trip — auto-added without verification',
        source: 'foreground',
        rawSmsPreview: rawMessage,
        detail: '$merchantName • ₹${resolved.amount.toInt()} • ${outingTitle ?? outingId}',
      );

      TransactionDetectionValidator.logOutcome(
        transactionType: TransactionDetectionValidator.transactionTypeLabel(resolved),
        merchantIdentifier:
            TransactionDetectionValidator.primaryIdentifier(resolved, resolved.rawIdentifier),
        merchantRule: null,
        verificationRequired: false,
        autoSaved: true,
        outingLinked: true,
        balanceUpdated: true,
        sourceLabel: 'foreground',
      );

      if (context.mounted) {
        final targetTitle = outingTitle ?? 'Trip';
        ScaffoldMessenger.of(context).hideCurrentSnackBar();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              '₹${resolved.amount.toInt()} added to $targetTitle ($merchantName)',
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
            backgroundColor: const Color(0xFF064E3B),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            duration: const Duration(seconds: 6),
            action: SnackBarAction(
              label: 'UNLINK',
              textColor: const Color(0xFF34D399),
              onPressed: () {
                ref
                    .read(model.transactionProvider.notifier)
                    .updateTransactionOuting(txId, null);
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Unlinked from trip — kept as personal spend'),
                      backgroundColor: AppColors.expense,
                      behavior: SnackBarBehavior.floating,
                    ),
                  );
                }
              },
            ),
          ),
        );
      }

      return true;
    }

    if (!resolved.isExpense && !resolved.isTransfer) {
      final friendName = FriendCreditHandler.matchFriendName(
        ref: ref,
        merchant: resolved.displayName,
        upiId: lookup.upiId.isNotEmpty ? lookup.upiId : resolved.upiId,
        rawIdentifier: lookup.lookupRaw,
      );
      if (friendName != null) {
        // For friend credits (existing UPI/record), compute link using date (even for credit) so
        // it only gets outing context if added during the active outing period.
        final creditOutingLink = ActiveOutingHelper.resolve(
          isExpense: false,
          transactionDate: txDate,
          forceLinkForCredit: true,
        );
        final creditOutingId = creditOutingLink?.id;
        final creditIsAutoLinked = creditOutingId != null;
        final txId = DateTime.now().millisecondsSinceEpoch.toString();
        final tx = model.Transaction(
          id: txId,
          merchant: FriendCreditHandler.merchantLabel(friendName),
          category: FriendCreditHandler.repaymentCategory,
          account: resolveAccountName(resolved.bank,
              accountLast4: parsed?.accountLast4),
          purpose: rule?.defaultPurposeType ?? 'Personal',
          time: 'Auto-added',
          amount: resolved.amount,
          isExpense: false,
          isAutoDetected: true,
          paymentType: 'Online',
          date: txDate,
          rawIdentifier: resolved.merchantLookupKey,
          bankName: resolved.bank,
          accountLast4: parsed?.accountLast4 ?? '',
          referenceId: parsed?.referenceId ?? '',
          upiId: resolved.upiId,
          rawMessage: parsed?.rawMessage ?? rawMessage,
          note: '',
          outingId: creditOutingId,
          isAutoLinked: creditIsAutoLinked,
          isPendingVerification: false,
          isMerchantMapped: true,
          isTransfer: false,
        );
        ref.read(model.transactionProvider.notifier).addTransaction(tx);
        FriendRepaymentMatcher.trySettleCreditWithFeedback(ref, tx);
        NotificationHistoryService.add(
          title: 'Auto-detected repayment',
          body: '₹${resolved.amount.toInt()} from $friendName',
          type: 'sms_auto',
        );
        ref.invalidate(notificationHistoryProvider);
        TransactionDetectionValidator.logOutcome(
          transactionType: 'Friend Repayment',
          merchantIdentifier: lookup.merchantIdentifier,
          verificationRequired: false,
          autoSaved: true,
          outingLinked: creditIsAutoLinked,
          balanceUpdated: true,
          friendName: friendName,
          sourceLabel: 'foreground',
        );
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              '₹${resolved.amount.toInt()} from $friendName — added automatically',
            ),
            backgroundColor: AppColors.income,
          ),
        );
        return true;
      }
    }

    final autoMatch = _applyMerchantAutoMatch(
      resolved: resolved,
      rawMessage: rawMessage,
      txDate: txDate,
      outingId: outingId,
      isAutoLinked: isAutoLinked,
      sourceLabel: 'foreground',
      skipSystemNotification: skipNotification,
      ref: ref,
    );
    if (autoMatch == _MerchantAutoMatchResult.saved ||
        autoMatch == _MerchantAutoMatchResult.alreadySaved) {
      ref.read(detectionQueueProvider.notifier).refresh();
      return true;
    }

    // Hive truth guard: existing pending for this detection? Reuse (no 2nd notif / no dup pending).
    final existingPid = _findExistingPendingId(
      refId: parsed?.referenceId,
      amount: resolved.amount,
      date: txDate,
    );
    if (existingPid != null) {
      ref.read(detectionQueueProvider.notifier).refresh();
      PendingVerificationPresenter.requestShow(ref, targetTransactionId: existingPid);
      if (forcePopup) {
        return await PendingVerificationPresenter.processQueueIfNeeded(
          context: context,
          ref: ref,
          targetTransactionId: existingPid,
        );
      }
      return false;
    }

    // Same raw SMS already pending — skip second entry / notification.
    final rawMatchPendingId = _findPendingIdForRawMessage(rawMessage);
    if (rawMatchPendingId != null) {
      ref.read(detectionQueueProvider.notifier).refresh();
      PendingVerificationPresenter.requestShow(ref,
          targetTransactionId: rawMatchPendingId);
      return false;
    }

    final pendingId = _commitUnknownMerchantPending(
      r: resolved,
      rawMessage: rawMessage,
      outingId: outingId,
      isAutoLinked: isAutoLinked,
      sourceLabel: 'foreground',
      skipSystemNotification: skipNotification,
    );
    if (pendingId.isEmpty) return true;

    ref.read(detectionQueueProvider.notifier).refresh();
    ref.invalidate(notificationHistoryProvider);

    PendingVerificationPresenter.requestShow(ref, targetTransactionId: pendingId);
    return false;
  }

  static model.Transaction pendingToTransaction(PendingTransaction p) {
    return model.Transaction(
      id: p.id,
      merchant: p.receiver,
      category: 'Other',
      account: resolveAccountName(p.bank, accountLast4: p.accountLast4),
      time: 'Detected',
      amount: p.amount,
      isExpense: p.isExpense,
      isAutoDetected: true,
      date: p.date,
      bankName: p.bank,
      accountLast4: p.accountLast4,
      referenceId: p.referenceId,
      upiId: p.upiId,
      rawMessage: p.rawMessage,
      note: '',
      isTransfer: p.isTransfer,
      rawIdentifier: p.upiId.isNotEmpty ? p.upiId : p.receiver,
      isPendingVerification: true,
      outingId: p.outingId,
      isAutoLinked: p.isAutoLinked,
    );
  }
}

class _MerchantAutoMatchChoice {
  final String merchant;
  final String category;
  final String purpose;
  final bool mapped;

  const _MerchantAutoMatchChoice({
    required this.merchant,
    required this.category,
    required this.purpose,
    required this.mapped,
  });
}

enum _MerchantAutoMatchResult { notEligible, saved, alreadySaved }

/// Result of [AutoRuleEngine.handleBackgroundSms].
enum BackgroundSmsOutcome {
  autoAdded,
  pendingVerification,
  skipped,
}