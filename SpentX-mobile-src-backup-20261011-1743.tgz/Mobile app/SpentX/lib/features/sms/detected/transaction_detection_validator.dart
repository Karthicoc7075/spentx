import 'package:hive_flutter/hive_flutter.dart';
import '../../../core/models/merchant_rule.dart';
import '../../../core/services/merchant_rule_service.dart';
import '../../sms_parser/models/transaction_parsed.dart';
import 'sms_atm_helper.dart';
import 'sms_detection_debug_log.dart';
import '../../../core/debug/master_debug_log.dart';
import '../../../core/debug/master_debug_module.dart';
import '../v4/merchant_match_resolver.dart';
import 'sms_merchant_matcher.dart';

/// Unified merchant / identifier resolution — runs before any pending verification.
class TransactionDetectionValidator {
  TransactionDetectionValidator._();

  static String transactionTypeLabel(ResolvedSmsDetection r) {
    if (r.isTransfer) return 'ATM Withdrawal / Bank to Cash';
    if (r.transactionType == 'credit') return 'Credit / Income';
    if (r.parsed?.mode == TransactionMode.upi) return 'UPI Payment';
    if (r.parsed?.mode == TransactionMode.card) return 'Card Payment';
    return 'Debit / Expense';
  }

  static String primaryIdentifier(ResolvedSmsDetection r, String lookupRaw) {
    if (r.upiId.isNotEmpty) return r.upiId;
    if (lookupRaw.isNotEmpty && lookupRaw.toLowerCase() != 'unknown') {
      return lookupRaw;
    }
    return r.merchantLookupKey;
  }

  // Note: merchant rule application only via id match (UPI/phone/account/raw). See MerchantRuleService.

  /// Resolves lookup keys and finds merchant rule. Never returns pending when rule exists.
  static MerchantLookupResult evaluateMerchant({
    required ResolvedSmsDetection resolved,
    required String rawMessage,
    String? sourceLabel,
    bool emitLog = true,
  }) {
    var lookupRaw = resolved.rawIdentifier;
    var lookupDisplay = resolved.displayName;

    if (resolved.isTransfer) {
      lookupRaw = SmsAtmHelper.ruleIdentifier(
        bank: resolved.bank,
        accountLast4: resolved.parsed?.accountLast4,
      );
      lookupDisplay = SmsAtmHelper.defaultDisplayName;
    } else if ((resolved.transactionType == 'credit' || !resolved.isExpense) &&
        _isGenericSource(lookupRaw)) {
      final alt = _extractCreditSource(rawMessage);
      if (alt.isNotEmpty) {
        lookupRaw = alt;
        lookupDisplay = alt;
      }
    }

    var upiId = resolved.upiId;
    if (upiId.isEmpty) {
      upiId = MerchantRuleService.extractUpiFromMessage(rawMessage) ?? '';
    }
    if (upiId.isEmpty && MerchantRuleService.looksLikeUpi(lookupDisplay)) {
      upiId = lookupDisplay;
    }

    MerchantRule? rule;

    if (resolved.isTransfer) {
      rule = MerchantRuleService.findAtmRule(
            bank: resolved.bank,
            accountLast4: resolved.parsed?.accountLast4,
            transactionType: resolved.transactionType,
          ) ??
          MerchantRuleService.findRule(
            upiId: upiId,
            rawIdentifier: lookupRaw,
            displayName: lookupDisplay,
            rawMessage: rawMessage,
            transactionType: resolved.transactionType,
            logResult: false,
            sourceLabel: sourceLabel,
          );
    } else {
      final payeeMatch = MerchantMatchResolver.resolve(
        rawMessage: rawMessage,
        parsed: resolved.parsed,
        requireAutoApply: true,
      );
      rule = payeeMatch.rule;

      rule ??= MerchantRuleService.findRule(
        upiId: upiId,
        rawIdentifier: lookupRaw,
        displayName: payeeMatch.payee,
        rawMessage: rawMessage,
        transactionType: resolved.transactionType,
        logResult: false,
        sourceLabel: sourceLabel,
      );
    }

    final effectiveRule = resolved.matchedRule ?? rule;
    final identifier = primaryIdentifier(resolved, lookupRaw);

    if (emitLog) {
      logOutcome(
        transactionType: transactionTypeLabel(resolved),
        merchantIdentifier: identifier,
        merchantRule: effectiveRule,
        verificationRequired: effectiveRule == null,
        sourceLabel: sourceLabel,
      );
    }

    return MerchantLookupResult(
      rule: effectiveRule,
      lookupRaw: lookupRaw,
      lookupDisplay: lookupDisplay,
      merchantIdentifier: identifier,
      upiId: upiId,
    );
  }

  /// Friend UPI lookup from Hive (works in background without Riverpod).
  static String? matchFriendFromHive({
    required String upiId,
    required String rawIdentifier,
    required String merchant,
  }) {
    if (!Hive.isBoxOpen('friends')) return null;
    final raw = Hive.box('friends').get('friend_upi_links', defaultValue: {});
    if (raw is! Map) return null;

    final normalizedUpi = _normalizeUpi(upiId);
    final idKey = _normalizeUpi(rawIdentifier);

    for (final entry in raw.entries) {
      final friendKey = entry.key.toString().trim();
      if (friendKey.isEmpty) continue;
      final friendDisplay = _titleCaseFriend(friendKey);
      final upis = entry.value is List ? entry.value as List : const [];
      for (final linked in upis) {
        final linkedNorm = _normalizeUpi(linked.toString());
        if (linkedNorm.isEmpty) continue;
        if (normalizedUpi.isNotEmpty &&
            (normalizedUpi == linkedNorm ||
                normalizedUpi.contains(linkedNorm) ||
                linkedNorm.contains(normalizedUpi))) {
          return friendDisplay;
        }
        if (idKey.isNotEmpty &&
            (idKey == linkedNorm ||
                idKey.contains(linkedNorm) ||
                linkedNorm.contains(idKey))) {
          return friendDisplay;
        }
      }
    }

    final m = merchant.toLowerCase();
    for (final entry in raw.entries) {
      final friendDisplay = _titleCaseFriend(entry.key.toString());
      final n = friendDisplay.toLowerCase();
      if (m.contains('from $n') || m.contains(n)) return friendDisplay;
    }
    return null;
  }

  static void logOutcome({
    required String transactionType,
    required String merchantIdentifier,
    MerchantRule? merchantRule,
    required bool verificationRequired,
    bool autoSaved = false,
    bool outingLinked = false,
    bool balanceUpdated = false,
    String? friendName,
    String? sourceLabel,
  }) {
    final lines = <String>[
      'Transaction Type: $transactionType',
      'Merchant Identifier: $merchantIdentifier',
      'Merchant Rule Found: ${merchantRule != null ? merchantRule.displayName : 'No'}',
      'Verification Required: ${verificationRequired ? 'Yes' : 'No'}',
      'Auto Saved: ${autoSaved ? 'Yes' : 'No'}',
      'Outing Linked: ${outingLinked ? 'Yes' : 'No'}',
      'Balance Updated: ${balanceUpdated ? 'Yes' : 'No'}',
    ];
    if (friendName != null && friendName.isNotEmpty) {
      lines.add('Friend Match: $friendName');
    }

    SmsDetectionDebugLog.log(
      level: verificationRequired ? SmsDebugLogLevel.info : SmsDebugLogLevel.success,
      message: verificationRequired
          ? 'Detection Validation: VERIFY REQUIRED'
          : 'Detection Validation: AUTO-SAVE',
      source: sourceLabel,
      detail: lines.join('\n'),
    );

    MasterDebugLog.log(
      level: verificationRequired ? MasterDebugLevel.info : MasterDebugLevel.success,
      module: MasterDebugModule.merchant,
      title: verificationRequired ? 'Verification Required' : 'Transaction Auto Saved',
      message: lines.join('\n'),
      data: {
        'transactionType': transactionType,
        'merchantIdentifier': merchantIdentifier,
        'merchantRule': merchantRule?.displayName,
        'autoSaved': autoSaved,
        'outingLinked': outingLinked,
        'balanceUpdated': balanceUpdated,
      },
      showToast: false,
    );
  }

  static bool _isGenericSource(String id) {
    final l = id.toLowerCase().trim();
    const noise = [
      'clearing', 'credited', 'deposited', 'received', 'balance',
      'avl', 'unknown', 'tpt', 'neft', 'xx', 'info',
    ];
    return noise.any((g) => l.contains(g));
  }

  static String _extractCreditSource(String raw) {
    final pats = [
      RegExp(r'Salary[-:\s]+([A-Za-z0-9.&\- ]+?)(?:\.|$)', caseSensitive: false),
      RegExp(r'(?:salary|payroll)[^\w]*([A-Za-z0-9.&\- ]+?)(?:\.|$)', caseSensitive: false),
      RegExp(r'(?:from|by)\s+([A-Za-z0-9.&\- ]+?)\s*(?:salary|payroll|\.|$)', caseSensitive: false),
      RegExp(r'(?:credited|deposited|received)\s+(?:from|by)?\s*([A-Za-z0-9.&\- ]+?)(?=\s+on|\s+avl|$)', caseSensitive: false),
    ];
    for (final p in pats) {
      final m = p.firstMatch(raw);
      if (m != null) {
        final v = m.group(1)!.trim();
        if (v.length > 2 && !_isGenericSource(v)) return v;
      }
    }
    return '';
  }

  static String _normalizeUpi(String raw) {
    final s = raw.trim().toLowerCase();
    if (s.isEmpty) return '';
    return s;
  }

  static String _titleCaseFriend(String key) {
    if (key.isEmpty) return key;
    return key.split(' ').map((w) {
      if (w.isEmpty) return w;
      return w[0].toUpperCase() + w.substring(1);
    }).join(' ');
  }
}

class MerchantLookupResult {
  final MerchantRule? rule;
  final String lookupRaw;
  final String lookupDisplay;
  final String merchantIdentifier;
  final String upiId;

  const MerchantLookupResult({
    required this.rule,
    required this.lookupRaw,
    required this.lookupDisplay,
    required this.merchantIdentifier,
    this.upiId = '',
  });

  bool get isKnown => rule != null;
}