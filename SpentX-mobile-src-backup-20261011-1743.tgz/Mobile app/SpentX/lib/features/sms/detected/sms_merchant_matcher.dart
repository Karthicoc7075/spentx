import '../../../core/models/merchant_rule.dart';
import '../../sms_parser/models/transaction_parsed.dart';
import '../../sms_parser/sms_direction_helper.dart';
import 'self_account_matcher.dart';
import 'sms_atm_helper.dart';
import '../../../core/services/merchant_rule_service.dart';
import '../../../core/services/merchant_identifier_resolver.dart';
import '../v4/merchant_match_resolver.dart';
import '../v4/payee_extractor.dart';

/// Merchant DB lookup: UPI / identifier + transaction type (credit, debit, transfer).
class SmsMerchantMatcher {
  static const String rulesBox = 'merchant_rules_box';

  static String transactionTypeLabel({
    required bool isExpense,
    required bool isTransfer,
  }) {
    if (isTransfer) return 'transfer';
    return isExpense ? 'debit' : 'credit';
  }

  static String transactionTypeFromDirection(TransactionDirection direction) {
    switch (direction) {
      case TransactionDirection.income:
        return 'credit';
      case TransactionDirection.transfer:
        return 'transfer';
      default:
        return 'debit';
    }
  }

  /// Primary key for merchant learning / tx rawIdentifier field.
  /// Prefers UPI / account id / parsed raw identifier (from SMS extract).
  /// Falls back to displayName only if no id-like value (for legacy name-based merchants).
  /// Rule lookup itself (via MerchantRuleService) must ignore displayName.
  static String merchantKey({
    required String upiId,
    required String rawIdentifier,
    required String displayName,
    String? rawMessage,
  }) {
    final key = MerchantIdentifierResolver.stableKey(
      upiId: upiId,
      rawIdentifier: rawIdentifier,
      parsedName: displayName,
      rawMessage: rawMessage,
    );
    return key.isNotEmpty ? key : displayName.trim();
  }

  static MerchantRule? findMatchingRule({
    required String upiId,
    required String rawIdentifier,
    required String displayName,
    required String transactionType,
    bool autoDetectionEnabled = true,
    bool exactOnly = false,
    String? rawMessage,
    String? sourceLabel,
  }) {
    if (!autoDetectionEnabled) return null;
    return MerchantRuleService.findRule(
      upiId: upiId,
      rawIdentifier: rawIdentifier,
      displayName: displayName,
      rawMessage: rawMessage,
      transactionType: transactionType,
      sourceLabel: sourceLabel,
    );
  }

  static ResolvedSmsDetection resolve({
    required String rawMessage,
    TransactionParsed? parsed,
    String? fallbackType,
    bool autoDetectionEnabled = true,
  }) {
    var direction = SmsDirectionHelper.resolveDirection(
      rawMessage: rawMessage,
      parsed: parsed,
      fallbackType: fallbackType,
    );

    // A template can declare `transfer` (e.g. the bundled NEFT/IMPS "transfer"
    // rule type) for messages that are really a payment to a THIRD PARTY, not
    // a self-transfer — SmsDirectionHelper.isTransferSms only recognizes
    // ATM/withdrawal-shaped raw text, so when `direction` came from the
    // template/parsed fallback instead of a real raw-keyword match, only
    // trust it as a transfer when the extracted payee matches one of the
    // user's OWN other registered accounts. Otherwise it's a real expense.
    if (direction == TransactionDirection.transfer &&
        !SmsDirectionHelper.isTransferSms(rawMessage)) {
      final payee = PayeeExtractor.extract(rawMessage) ?? parsed?.name ?? '';
      if (!SelfAccountMatcher.matches(payee)) {
        direction = TransactionDirection.expense;
      }
    }

    final isTransfer = direction == TransactionDirection.transfer;
    final isExpense = direction == TransactionDirection.expense;
    final txType = transactionTypeFromDirection(direction);

    var upiId = parsed?.upiId ?? '';
    if (upiId.isEmpty) {
      upiId = MerchantRuleService.extractUpiFromMessage(rawMessage) ?? '';
    }
    final bank = parsed?.bank ?? 'Bank';
    final amount = parsed?.amount ?? 0.0;

    // ATM withdrawals: lookup only by per-bank rule key (first time = unknown → verify).
    final String rawIdentifier;
    final String displayName;
    MerchantRule? matchedRule;
    // ATM withdrawal (Bank -> Cash) vs Cash deposit (Cash -> Bank) — same raw
    // transfer direction, opposite money flow, so each needs its own display
    // name / rule-learning bucket (see SmsAtmHelper.ruleIdentifier) and,
    // downstream, a different transferType/from-to account pairing.
    final isCashDeposit =
        isTransfer && SmsDirectionHelper.isCashDepositAtSelfMachineSms(rawMessage);

    if (isTransfer) {
      final last4 = parsed?.accountLast4 ?? '';
      rawIdentifier = SmsAtmHelper.ruleIdentifier(
        bank: bank,
        accountLast4: last4,
        isCashDeposit: isCashDeposit,
      );
      displayName = isCashDeposit
          ? SmsAtmHelper.cashDepositDisplayName
          : SmsAtmHelper.defaultDisplayName;
      matchedRule = MerchantRuleService.findAtmRule(
        bank: bank,
        accountLast4: last4,
        transactionType: txType,
        isCashDeposit: isCashDeposit,
      ) ??
          findMatchingRule(
            upiId: '',
            rawIdentifier: rawIdentifier,
            displayName: displayName,
            transactionType: txType,
            autoDetectionEnabled: autoDetectionEnabled,
            exactOnly: true,
          );
    } else {
      final payeeMatch = MerchantMatchResolver.resolve(
        rawMessage: rawMessage,
        parsed: parsed,
        requireAutoApply: true,
      );
      displayName = payeeMatch.payee.isNotEmpty
          ? payeeMatch.payee
          : (PayeeExtractor.extract(rawMessage) ??
              MerchantIdentifierResolver.parsedTitle(
                rawMessage: rawMessage,
                parsed: parsed,
              ));

      rawIdentifier = payeeMatch.normalizedPayee.isNotEmpty
          ? payeeMatch.normalizedPayee
          : MerchantIdentifierResolver.stableKey(
              upiId: parsed?.upiId,
              rawIdentifier: parsed?.rawIdentifier,
              parsedName: displayName,
              rawMessage: rawMessage,
            );

      if (upiId.isEmpty && MerchantRuleService.looksLikeUpi(displayName)) {
        upiId = displayName;
      }
      if (upiId.isEmpty && MerchantRuleService.looksLikeUpi(rawIdentifier)) {
        upiId = rawIdentifier;
      }

      matchedRule = payeeMatch.rule;

      // UPI / account identifier rules — never match by stale display names.
      matchedRule ??= findMatchingRule(
        upiId: upiId,
        rawIdentifier: rawIdentifier,
        displayName: displayName,
        transactionType: txType,
        autoDetectionEnabled: autoDetectionEnabled,
        rawMessage: rawMessage,
        sourceLabel: 'SmsMerchantMatcher',
      );
    }

    final resolvedTitle = matchedRule?.displayName ??
        MerchantMatchResolver.resolve(
          rawMessage: rawMessage,
          parsed: parsed,
        ).displayTitle;

    return ResolvedSmsDetection(
      direction: direction,
      isExpense: isExpense,
      isTransfer: isTransfer,
      isCashDeposit: isCashDeposit,
      transactionType: txType,
      upiId: upiId,
      rawIdentifier: rawIdentifier,
      displayName: resolvedTitle,
      amount: amount,
      bank: bank,
      parsed: parsed,
      matchedRule: matchedRule,
      isKnownMerchant: matchedRule != null,
    );
  }
}

class ResolvedSmsDetection {
  final TransactionDirection direction;
  final bool isExpense;
  final bool isTransfer;
  /// True only when [isTransfer] and the SMS is a Cash -> Bank deposit at an
  /// ATM/CDM, as opposed to a Bank -> Cash ATM withdrawal (the far more
  /// common transfer shape). Always false when [isTransfer] is false.
  final bool isCashDeposit;
  final String transactionType;
  final String upiId;
  final String rawIdentifier;
  final String displayName;
  final double amount;
  final String bank;
  final TransactionParsed? parsed;
  final MerchantRule? matchedRule;
  final bool isKnownMerchant;

  const ResolvedSmsDetection({
    required this.direction,
    required this.isExpense,
    required this.isTransfer,
    this.isCashDeposit = false,
    required this.transactionType,
    required this.upiId,
    required this.rawIdentifier,
    required this.displayName,
    required this.amount,
    required this.bank,
    required this.parsed,
    required this.matchedRule,
    required this.isKnownMerchant,
  });

  String get merchantLookupKey => rawIdentifier.isNotEmpty
      ? rawIdentifier
      : SmsMerchantMatcher.merchantKey(
          upiId: upiId,
          rawIdentifier: rawIdentifier,
          displayName: displayName,
        );
}