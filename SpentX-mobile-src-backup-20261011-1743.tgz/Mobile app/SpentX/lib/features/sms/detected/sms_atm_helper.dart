/// ATM withdrawal / Cash deposit rule keys — bank + card last4; first
/// occurrence of either requires verify, later ones auto-add.
class SmsAtmHelper {
  static const defaultDisplayName = 'ATM Withdrawal';
  static const defaultCategory = 'Cash Withdrawal';
  static const cashDepositDisplayName = 'Cash Deposit';
  static const cashDepositCategory = 'Cash Deposit';

  /// [isCashDeposit] uses a distinct rule-key prefix so a bank+card's ATM
  /// withdrawal auto-learning never collides with its cash-deposit
  /// auto-learning — they're opposite directions and must verify/learn
  /// independently.
  static String ruleIdentifier({
    required String bank,
    String? accountLast4,
    bool isCashDeposit = false,
  }) {
    final prefix = isCashDeposit ? 'deposit' : 'atm';
    final bankNorm = bank
        .trim()
        .toLowerCase()
        .replaceAll(RegExp(r'\s+'), '_')
        .replaceAll(RegExp(r'[^a-z0-9_]'), '');
    final card = (accountLast4 ?? '').replaceAll(RegExp(r'\D'), '');
    if (bankNorm.isEmpty && card.isEmpty) return '${prefix}_unknown';
    if (card.length >= 4) return '${prefix}_${bankNorm}_$card';
    if (bankNorm.isNotEmpty) return '${prefix}_$bankNorm';
    return '${prefix}_card_$card';
  }
}