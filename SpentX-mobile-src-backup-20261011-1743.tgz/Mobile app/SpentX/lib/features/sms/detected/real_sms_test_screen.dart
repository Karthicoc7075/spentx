import 'package:flutter/material.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../core/theme/spentx_tokens.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../sms_parser/models/transaction_parsed.dart';
import '../rules/engine/sms_rule_engine.dart';
import '../sms_service.dart';
import 'sms_lab_simulator.dart';
import 'sms_pipeline_test_runner.dart';

class RealSmsTestScreen extends ConsumerStatefulWidget {
  const RealSmsTestScreen({super.key});

  @override
  ConsumerState<RealSmsTestScreen> createState() => _RealSmsTestScreenState();
}

class _InboxSmsItem {
  final String body;
  final String sender;
  final DateTime date;
  final TransactionParsed? parsed;

  const _InboxSmsItem({
    required this.body,
    required this.sender,
    required this.date,
    this.parsed,
  });
}

class _RealSmsTestScreenState extends ConsumerState<RealSmsTestScreen> {
  List<_InboxSmsItem> _messages = [];
  _InboxSmsItem? _selected;
  String _filter = 'All';
  bool _loading = true;
  String? _error;
  SmsLabFlowMode _flowMode = SmsLabFlowMode.background;
  int _delaySeconds = 5;
  SmsPipelineTestResult? _testResult;

  @override
  void initState() {
    super.initState();
    _loadInbox();
  }

  @override
  void dispose() {
    SmsLabSimulator.cancel();
    super.dispose();
  }

  Future<void> _loadInbox() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    final granted = await SmsService.requestPermissions();
    if (!granted) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = 'SMS permission required to read device inbox.';
      });
      return;
    }

    final raw = await SmsService.readInboxRawForDeveloperTest();
    final items = <_InboxSmsItem>[];
    for (final row in raw) {
      final parsed = SmsRuleEngine.parse(row.body, smsReceivedTime: row.date);
      items.add(
        _InboxSmsItem(
          body: row.body,
          sender: row.sender,
          date: row.date,
          parsed: parsed,
        ),
      );
    }

    if (!mounted) return;
    setState(() {
      _messages = items;
      _loading = false;
      if (_selected != null &&
          !_messages.any(
            (m) => m.body == _selected!.body && m.date == _selected!.date,
          )) {
        _selected = null;
        _testResult = null;
      }
    });
  }

  List<_InboxSmsItem> get _filtered {
    switch (_filter) {
      case 'Debit':
        return _messages
            .where((m) => m.parsed?.direction == TransactionDirection.expense)
            .toList();
      case 'Credit':
        return _messages
            .where((m) => m.parsed?.direction == TransactionDirection.income)
            .toList();
      case 'Parsed':
        return _messages.where((m) => m.parsed != null).toList();
      case 'Unparsed':
        return _messages.where((m) => m.parsed == null).toList();
      default:
        return _messages;
    }
  }

  Future<void> _runTest() async {
    final sms = _selected;
    if (sms == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Select a device SMS first'),
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    setState(() => _testResult = SmsPipelineTestRunner.run(sms.body));
    HapticFeedback.mediumImpact();

    await SmsLabSimulator.runRealFlowTest(
      ref: ref,
      context: context,
      rawSms: sms.body,
      delay: Duration(seconds: _delaySeconds),
      mode: _flowMode,
      skipTransfers: false,
    );
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isRunning = ref.watch(smsLabRunningProvider);
    final countdown = ref.watch(smsLabCountdownProvider);
    final scheduledAt = ref.watch(smsLabScheduledAtProvider);
    final filtered = _filtered;

    final tokens = context.tokens;
    return Scaffold(
      backgroundColor: tokens.background,
      appBar: AppBar(
        backgroundColor: tokens.surface,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        foregroundColor: tokens.textPrimary,
        title: Text(
          'Real-Time SMS Test',
          style: AppType.section(tokens.textPrimary),
        ),
        leading: BackButton(color: tokens.textPrimary),
        actions: [
          IconButton(
            tooltip: 'Refresh inbox',
            color: tokens.primary,
            icon: const Icon(LucideIcons.refreshCw),
            onPressed: _loading ? null : _loadInbox,
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: Column(
        children: [
          _buildTestPanel(isDark, isRunning, countdown, scheduledAt),
          _buildFilters(isDark),
          Expanded(child: _buildList(isDark, filtered)),
        ],
      ),
    );
  }

  Widget _buildTestPanel(
    bool isDark,
    bool isRunning,
    int? countdown,
    DateTime? scheduledAt,
  ) {
    final selected = _selected;
    final tokens = context.tokens;
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 4),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: tokens.card,
        borderRadius: AppRadius.cardR,
        border: Border.all(color: tokens.border),
        boxShadow: AppShadows.subtle,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(LucideIcons.smartphone, size: 16, color: tokens.primary),
              const SizedBox(width: 8),
              const Expanded(
                child: Text(
                  'Device real SMS — tap to select, set lap delay, run lab pipeline',
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
                ),
              ),
              if (isRunning && countdown != null)
                Text(
                  '${countdown}s',
                  style: TextStyle(
                    color: tokens.primary,
                    fontWeight: FontWeight.w700,
                    fontSize: 14,
                  ),
                ),
            ],
          ),
          if (selected != null) ...[
            const SizedBox(height: 10),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: tokens.primarySoft,
                borderRadius: AppRadius.tileR,
                border: Border.all(
                  color: tokens.primary.withValues(alpha: 0.24),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    selected.sender.isNotEmpty
                        ? selected.sender
                        : 'Unknown sender',
                    style: AppType.caption(
                      tokens.primary,
                    ).copyWith(fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    selected.body,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 12,
                      color: tokens.textSecondary,
                      height: 1.4,
                    ),
                  ),
                ],
              ),
            ),
          ],
          const SizedBox(height: 12),
          Text('LAP DELAY', style: _sectionLabel(tokens.primary)),
          const SizedBox(height: 8),
          Row(
            children: [
              _delayChip(0, 'Now'),
              const SizedBox(width: 8),
              _delayChip(5, '5 sec'),
              const SizedBox(width: 8),
              _delayChip(10, '10 sec'),
            ],
          ),
          const SizedBox(height: 12),
          Text('FLOW MODE', style: _sectionLabel(tokens.primary)),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: _flowChip(
                  SmsLabFlowMode.background,
                  'Clear history',
                  LucideIcons.moon,
                  'Notification after delay',
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _flowChip(
                  SmsLabFlowMode.foreground,
                  'App open',
                  LucideIcons.smartphone,
                  'Live detect in app',
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            height: 44,
            child: FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: SoftColors.control,
                foregroundColor: Colors.white,
                disabledBackgroundColor: tokens.disabled,
                disabledForegroundColor: tokens.textDisabled,
                shape: const RoundedRectangleBorder(
                  borderRadius: AppRadius.buttonR,
                ),
                elevation: 0,
              ),
              onPressed: isRunning || selected == null ? null : _runTest,
              icon: Icon(
                isRunning ? LucideIcons.loader : LucideIcons.play,
                size: 16,
              ),
              label: Text(
                isRunning
                    ? (_delaySeconds > 0
                        ? 'Lap running… ${_delaySeconds}s'
                        : 'Running…')
                    : 'Run Real SMS Test',
                style: const TextStyle(fontWeight: FontWeight.w500),
              ),
            ),
          ),
          if (_testResult != null) ...[
            const SizedBox(height: 8),
            Text(
              _testResult!.detectionSuccess
                  ? 'Parse: ${_testResult!.templateRuleName ?? _testResult!.parserUsed} • ${_testResult!.parsedMerchant ?? '—'}'
                  : 'Parse: no rule matched',
              style: TextStyle(
                fontSize: 11,
                color:
                    _testResult!.detectionSuccess
                        ? tokens.positive
                        : tokens.warning,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
          if (scheduledAt != null) ...[
            const SizedBox(height: 8),
            Text(
              'Alarm set for ${DateFormat('HH:mm:ss').format(scheduledAt)} — swipe app from recents.',
              style: AppType.caption(
                tokens.positive,
              ).copyWith(fontWeight: FontWeight.w600),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildFilters(bool isDark) {
    final tokens = context.tokens;
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
      child: Row(
        children:
            ['All', 'Parsed', 'Debit', 'Credit', 'Unparsed'].map((filter) {
              final selected = _filter == filter;
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(
                  label: Text(filter),
                  selected: selected,
                  onSelected: (_) => setState(() => _filter = filter),
                  backgroundColor: tokens.card,
                  selectedColor: tokens.primarySoft,
                  side: BorderSide(
                    color: selected ? tokens.primary : tokens.border,
                  ),
                  shape: const RoundedRectangleBorder(
                    borderRadius: AppRadius.pillR,
                  ),
                  labelStyle: AppType.label(
                    selected ? tokens.primary : tokens.textSecondary,
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 8,
                  ),
                  showCheckmark: false,
                ),
              );
            }).toList(),
      ),
    );
  }

  Widget _buildList(bool isDark, List<_InboxSmsItem> items) {
    if (_loading) {
      return Center(
        child: CircularProgressIndicator(color: context.tokens.primary),
      );
    }
    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                LucideIcons.shieldAlert,
                size: 40,
                color: context.tokens.warning,
              ),
              const SizedBox(height: 12),
              Text(
                _error!,
                textAlign: TextAlign.center,
                style: AppType.body(context.tokens.textSecondary),
              ),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                style: OutlinedButton.styleFrom(
                  foregroundColor: context.tokens.primary,
                  side: BorderSide(color: context.tokens.border),
                  shape: const RoundedRectangleBorder(
                    borderRadius: AppRadius.buttonR,
                  ),
                ),
                onPressed: _loadInbox,
                icon: const Icon(LucideIcons.refreshCw, size: 16),
                label: const Text('Retry'),
              ),
            ],
          ),
        ),
      );
    }
    if (items.isEmpty) {
      return Center(
        child: Text(
          'No device SMS for $_filter',
          style: AppType.body(context.tokens.textSecondary),
        ),
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
      itemCount: items.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (context, index) {
        final msg = items[index];
        final isSelected =
            _selected?.body == msg.body && _selected?.date == msg.date;
        final parsed = msg.parsed;
        final isDebit = parsed?.direction == TransactionDirection.expense;
        final isCredit = parsed?.direction == TransactionDirection.income;
        final accent =
            parsed == null
                ? context.tokens.warning
                : (isDebit
                    ? context.tokens.negative
                    : (isCredit
                        ? context.tokens.positive
                        : context.tokens.primary));

        final tokens = context.tokens;
        return Material(
          color: Colors.transparent,
          borderRadius: AppRadius.cardR,
          child: InkWell(
            borderRadius: AppRadius.cardR,
            onTap:
                () => setState(() {
                  _selected = msg;
                  _testResult = null;
                }),
            child: Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: isSelected ? tokens.primarySoft : tokens.card,
                borderRadius: AppRadius.cardR,
                border: Border.all(
                  color: isSelected ? tokens.primary : tokens.border,
                ),
                boxShadow: AppShadows.subtle,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: accent.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          parsed != null
                              ? (parsed.bank.isNotEmpty
                                  ? parsed.bank.toUpperCase()
                                  : 'PARSED')
                              : 'UNPARSED',
                          style: TextStyle(
                            color: accent,
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                      const Spacer(),
                      if (parsed != null)
                        Text(
                          '₹${parsed.amount.toStringAsFixed(0)}',
                          style: TextStyle(
                            color: accent,
                            fontWeight: FontWeight.w500,
                            fontSize: 14,
                          ),
                        ),
                      if (isSelected) ...[
                        const SizedBox(width: 8),
                        Icon(
                          LucideIcons.checkCircle2,
                          size: 16,
                          color: tokens.primary,
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    msg.sender.isNotEmpty ? msg.sender : 'Unknown',
                    style: AppType.label(tokens.textPrimary),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    msg.body,
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 13,
                      height: 1.4,
                      color: tokens.textSecondary,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    DateFormat('dd MMM yyyy • HH:mm').format(msg.date),
                    style: TextStyle(fontSize: 12, color: tokens.textDisabled),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _delayChip(int seconds, String label) {
    final selected = _delaySeconds == seconds;
    final tokens = context.tokens;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _delaySeconds = seconds),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: selected ? tokens.primarySoft : tokens.card,
            borderRadius: AppRadius.pillR,
            border: Border.all(
              color: selected ? tokens.primary : tokens.border,
            ),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: selected ? tokens.primary : tokens.textSecondary,
              fontWeight: FontWeight.w600,
              fontSize: 12,
            ),
          ),
        ),
      ),
    );
  }

  Widget _flowChip(
    SmsLabFlowMode mode,
    String title,
    IconData icon,
    String subtitle,
  ) {
    final selected = _flowMode == mode;
    final tokens = context.tokens;
    return GestureDetector(
      onTap: () => setState(() => _flowMode = mode),
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: selected ? tokens.primarySoft : tokens.card,
          borderRadius: AppRadius.tileR,
          border: Border.all(
            color:
                selected
                    ? tokens.primary.withValues(alpha: 0.5)
                    : tokens.border,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(
              icon,
              size: 16,
              color: selected ? tokens.primary : tokens.textSecondary,
            ),
            const SizedBox(height: 4),
            Text(title, style: AppType.label(tokens.textPrimary)),
            Text(subtitle, style: AppType.caption(tokens.textSecondary)),
          ],
        ),
      ),
    );
  }

  static TextStyle _sectionLabel(Color color) => TextStyle(
    fontSize: 11,
    fontWeight: FontWeight.w700,
    letterSpacing: 1.1,
    color: color,
  );
}
