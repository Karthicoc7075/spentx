import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:intl/intl.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../core/widgets/premium_bottom_sheet.dart';
import '../../../core/providers/transaction_provider.dart' show Transaction;
import 'detection_queue.dart';
import 'detected_sms_storage.dart';
import 'auto_rule_engine.dart';
import 'detection_popup.dart';

class BatchDetectionScreen extends ConsumerStatefulWidget {
  const BatchDetectionScreen({super.key});

  @override
  ConsumerState<BatchDetectionScreen> createState() =>
      _BatchDetectionScreenState();
}

class _BatchDetectionScreenState extends ConsumerState<BatchDetectionScreen> {
  @override
  Widget build(BuildContext context) {
    final pendingList = ref.watch(detectionQueueProvider);

    return Scaffold(
      backgroundColor: SoftPalette.bg,
      appBar: AppBar(
        backgroundColor: SoftPalette.bg,
        foregroundColor: SoftPalette.ink,
        elevation: 0,
        scrolledUnderElevation: 0,
        surfaceTintColor: Colors.transparent,
        titleSpacing: 20,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Pending Detections',
              style: TextStyle(
                color: SoftPalette.ink,
                fontWeight: FontWeight.w700,
                fontSize: 20,
              ),
            ),
            Text(
              '${pendingList.length} transactions to verify',
              style: const TextStyle(fontSize: 12, color: SoftPalette.muted),
            ),
          ],
        ),
        actions: [
          if (pendingList.isNotEmpty)
            TextButton(
              onPressed: () {
                for (final txId in pendingList) {
                  ref
                      .read(detectionQueueProvider.notifier)
                      .ignoreTransaction(txId);
                }
                Navigator.pop(context);
              },
              child: const Text(
                'Clear All',
                style: TextStyle(color: SoftPalette.negative),
              ),
            ),
          const SizedBox(width: 8),
        ],
      ),
      body:
          pendingList.isEmpty
              ? _buildEmptyState()
              : ListView.builder(
                padding: const EdgeInsets.all(20),
                itemCount: pendingList.length,
                itemBuilder: (context, index) {
                  final txId = pendingList[index];
                  final pending = DetectedSmsStorage.get(txId);
                  if (pending == null) return const SizedBox.shrink();
                  return _buildPendingCard(
                    AutoRuleEngine.pendingToTransaction(pending),
                  );
                },
              ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(28),
          decoration: BoxDecoration(
            color: SoftPalette.card,
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: SoftPalette.border),
            boxShadow: const [
              BoxShadow(
                color: Color(0x0A0F172A),
                blurRadius: 16,
                offset: Offset(0, 6),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: const BoxDecoration(
                  color: SoftPalette.emeraldSoft,
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  LucideIcons.checkCircle,
                  size: 44,
                  color: SoftPalette.emerald,
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'All caught up!',
                style: TextStyle(
                  color: SoftPalette.ink,
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'No pending SMS detections to verify.',
                textAlign: TextAlign.center,
                style: TextStyle(color: SoftPalette.muted),
              ),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: SoftColors.control,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18),
                    ),
                  ),
                  child: const Text(
                    'Back to Home',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPendingCard(Transaction tx) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: SoftPalette.card,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: SoftPalette.border),
        boxShadow: const [
          BoxShadow(
            color: Color(0x080F172A),
            blurRadius: 16,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: (tx.isExpense
                            ? SoftPalette.negative
                            : SoftPalette.positive)
                        .withValues(alpha: 0.1),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    tx.isTransfer
                        ? LucideIcons.arrowRightLeft
                        : (tx.isExpense
                            ? LucideIcons.trendingDown
                            : LucideIcons.trendingUp),
                    color:
                        tx.isExpense
                            ? SoftPalette.negative
                            : SoftPalette.positive,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        tx.receiver,
                        style: const TextStyle(
                          color: SoftPalette.ink,
                          fontWeight: FontWeight.w700,
                          fontSize: 16,
                        ),
                      ),
                      Text(
                        tx.bank,
                        style: const TextStyle(
                          fontSize: 12,
                          color: SoftPalette.muted,
                        ),
                      ),
                    ],
                  ),
                ),
                Text(
                  '₹${tx.amount.toStringAsFixed(0)}',
                  style: const TextStyle(
                    color: SoftPalette.ink,
                    fontWeight: FontWeight.w700,
                    fontSize: 20,
                  ),
                ),
              ],
            ),
          ),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            decoration: const BoxDecoration(
              color: SoftPalette.surfaceVariant,
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
            ),
            child: Row(
              children: [
                Text(
                  DateFormat('MMM dd, hh:mm a').format(tx.date),
                  style: const TextStyle(
                    fontSize: 11,
                    color: SoftPalette.muted,
                  ),
                ),
                const Spacer(),
                TextButton(
                  onPressed:
                      () => ref
                          .read(detectionQueueProvider.notifier)
                          .ignoreTransaction(tx.id),
                  child: const Text(
                    'Ignore',
                    style: TextStyle(
                      color: SoftPalette.muted,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: () async {
                    await PremiumBottomSheet.show(
                      context: context,
                      child: DetectionPopup(pendingTx: tx),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: SoftColors.control,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 18,
                      vertical: 10,
                    ),
                    minimumSize: Size.zero,
                  ),
                  child: const Text(
                    'Verify',
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
