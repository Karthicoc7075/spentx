import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/widgets/premium_bottom_sheet.dart';
import '../core/sms_pending_service.dart';
import 'auto_rule_engine.dart';
import 'detected_sms_storage.dart';
import 'detection_popup.dart';
import 'detection_queue.dart';
import '../../../core/providers/transaction_provider.dart' as model;
import '../../../core/debug/master_debug_log.dart';

/// Shows verify sheets for items in [DetectedSmsStorage] + pending queue.
/// Single coordinator — prevents duplicate / blinking popups.
class PendingVerificationPresenter {
  static bool _isShowing = false;
  static String? _activeTxId;
  static DateTime? _lastRequestAt;

  /// True while the verify bottom sheet is visible.
  static bool get popupAlreadyOpen => _isShowing;
  static bool get isPopupOpen => _isShowing;

  /// Schedule exactly one verify popup (debounced). All entry points should use this.
  static void requestShow(WidgetRef ref, {String? targetTransactionId}) {
    if (_isShowing) return;

    final now = DateTime.now();
    if (_lastRequestAt != null &&
        now.difference(_lastRequestAt!).inMilliseconds < 600 &&
        targetTransactionId == null) {
      return;
    }
    _lastRequestAt = now;

    if (targetTransactionId != null && targetTransactionId.isNotEmpty) {
      ref.read(detectionQueueProvider.notifier).prioritize(targetTransactionId);
      ref.read(openPendingVerificationForTxProvider.notifier).state =
          targetTransactionId;
    } else {
      ref.read(openPendingVerificationOnHomeProvider.notifier).state = true;
    }
  }

  static Future<void> processQueueIfNeeded({
    required BuildContext context,
    required WidgetRef ref,
    String? targetTransactionId,
  }) async {
    if (popupAlreadyOpen || !context.mounted) return;

    SmsPendingService.reconcile();
    ref.read(detectionQueueProvider.notifier).refresh();
    var pendingIds = ref.read(detectionQueueProvider);

    if (pendingIds.isEmpty) {
      await Future.delayed(const Duration(milliseconds: 120));
      SmsPendingService.reconcile();
      ref.read(detectionQueueProvider.notifier).refresh();
      pendingIds = ref.read(detectionQueueProvider);
    }

    final txId = _resolveTargetId(
      pendingIds: pendingIds,
      targetTransactionId: targetTransactionId,
    );
    if (txId == null) return;

    if (popupAlreadyOpen && _activeTxId == txId) return;

    var pending = DetectedSmsStorage.get(txId);
    if (pending == null) {
      final txs = ref.read(model.transactionProvider);
      final tx = txs.where((t) => t.id == txId).firstOrNull;
      if (tx != null && tx.isPendingVerification) {
        if (!context.mounted) return;
        await _showPopup(
          context: context,
          ref: ref,
          txId: txId,
          child: DetectionPopup(pendingTx: tx),
        );
        return;
      }
      ref.read(detectionQueueProvider.notifier).removePending(txId);
      if (context.mounted) {
        await processQueueIfNeeded(context: context, ref: ref);
      }
      return;
    }

    DetectedSmsStorage.markPopupOpened(txId);
    final popupTx = AutoRuleEngine.pendingToTransaction(pending);
    if (!context.mounted) return;
    await _showPopup(
      context: context,
      ref: ref,
      txId: txId,
      child: DetectionPopup(pendingTx: popupTx),
    );
  }

  /// Prefer explicit tap target when it exists in Hive, even if in-memory queue is stale.
  static String? _resolveTargetId({
    required List<String> pendingIds,
    String? targetTransactionId,
  }) {
    if (targetTransactionId != null && targetTransactionId.isNotEmpty) {
      if (SmsPendingService.get(targetTransactionId) != null) {
        return targetTransactionId;
      }
      if (pendingIds.contains(targetTransactionId)) {
        return targetTransactionId;
      }
    }
    if (pendingIds.isNotEmpty) return pendingIds.first;
    final awaiting = SmsPendingService.listAwaitingVerification();
    if (awaiting.isNotEmpty) return awaiting.first.id;
    return null;
  }

  static Future<void> _showPopup({
    required BuildContext context,
    required WidgetRef ref,
    required String txId,
    required Widget child,
  }) async {
    if (popupAlreadyOpen || !context.mounted) return;

    _isShowing = true;
    _activeTxId = txId;
    DetectedSmsStorage.markPopupOpened(txId);
    MasterDebugLog.queue(title: 'Popup Opened', transactionId: txId);

    final result = await PremiumBottomSheet.show<dynamic>(
      context: context,
      isDismissible: true,
      child: child,
    );

    _isShowing = false;
    _activeTxId = null;

    if (!context.mounted) return;

    // Dismiss/close keeps item pending — show again on next app open, not immediately.
    if (result == 'confirm' || result == 'ignore') {
      await Future.delayed(const Duration(milliseconds: 420));
      if (context.mounted) {
        await processQueueIfNeeded(context: context, ref: ref);
      }
    }
  }
}

/// Set true when a notification requests the verify flow on home.
final openPendingVerificationOnHomeProvider = StateProvider<bool>(
  (ref) => false,
);

/// Exact tx id from notification tap — presenter opens this item only.
final openPendingVerificationForTxProvider = StateProvider<String?>(
  (ref) => null,
);
