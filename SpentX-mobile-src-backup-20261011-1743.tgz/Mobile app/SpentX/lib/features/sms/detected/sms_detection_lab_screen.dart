import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:intl/intl.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../core/providers/merchant_provider.dart';
import '../../../core/providers/transaction_provider.dart';
import '../../../core/providers/outing_provider.dart';
import 'sms_pipeline_test_runner.dart';
import 'sms_lab_simulator.dart';
import 'detection_queue.dart';

class SmsDetectionLabScreen extends ConsumerStatefulWidget {
  const SmsDetectionLabScreen({super.key});

  @override
  ConsumerState<SmsDetectionLabScreen> createState() => _SmsDetectionLabScreenState();
}

class _SmsDetectionLabScreenState extends ConsumerState<SmsDetectionLabScreen> {
  final TextEditingController _smsCtrl = TextEditingController(
    text:
        'HDFC Bank: Rs.450.00 debited from A/c **1234 on 04-06-26 to VPA zomato@paytm (UPI Ref 614556266884). Avl Bal: Rs.12,450.00',
  );

  SmsPipelineTestResult? _testResult;
  SmsLabFlowMode _flowMode = SmsLabFlowMode.background;
  int _delaySeconds = 5;

  @override
  void dispose() {
    SmsLabSimulator.cancel();
    _smsCtrl.dispose();
    super.dispose();
  }

  Future<void> _runTest() async {
    final text = _smsCtrl.text.trim();
    if (text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Paste an SMS first'), behavior: SnackBarBehavior.floating),
      );
      return;
    }

    setState(() => _testResult = SmsPipelineTestRunner.run(text));
    HapticFeedback.mediumImpact();

    await SmsLabSimulator.runRealFlowTest(
      ref: ref,
      context: context,
      rawSms: text,
      delay: Duration(seconds: _delaySeconds),
      mode: _flowMode,
      skipTransfers: false,
    );
    if (mounted) setState(() {});
  }

  Future<void> _pasteFromClipboard() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    final text = data?.text?.trim() ?? '';
    if (text.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Clipboard is empty — copy a bank SMS first'),
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }
    setState(() => _smsCtrl.text = text);
    HapticFeedback.lightImpact();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Pasted ${text.length} characters'),
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _clearSmsField() {
    setState(() {
      _smsCtrl.clear();
      _testResult = null;
    });
    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('SMS field cleared'),
        behavior: SnackBarBehavior.floating,
        duration: Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final txs = ref.watch(transactionProvider);
    final queue = ref.watch(detectionQueueProvider);
    final outings = ref.watch(outingProvider);
    final logs = ref.watch(smsLabLogsProvider);
    final isRunning = ref.watch(smsLabRunningProvider);
    final countdown = ref.watch(smsLabCountdownProvider);
    final scheduledAt = ref.watch(smsLabScheduledAtProvider);
    final autoDetectionOn = ref.watch(autoDetectionProvider);

    return Scaffold(
      backgroundColor: AppSurface.bg,
      appBar: AppBar(
        backgroundColor: AppSurface.bg,
        elevation: 0,
        leading: IconButton(
          icon: Icon(LucideIcons.arrowLeft, color: AppSurface.text),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'SMS Detection Lab',
          style: TextStyle(fontWeight: FontWeight.w500, color: AppSurface.text, fontSize: 18),
        ),
        actions: [
          if (isRunning)
            Padding(
              padding: const EdgeInsets.only(right: 16),
              child: Center(
                child: countdown != null
                    ? Text(
                        '${countdown}s',
                        style: const TextStyle(
                          color: Colors.amberAccent,
                          fontWeight: FontWeight.w500,
                          fontSize: 16,
                        ),
                      )
                    : const SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(strokeWidth: 2, color: SoftPalette.emerald),
                      ),
              ),
            ),
        ],
      ),
      body: ListView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: [
          _buildSmsInputCard(isRunning, scheduledAt, autoDetectionOn),
          if (_testResult != null) ...[
            const SizedBox(height: 16),
            _buildPipelinePreview(),
            const SizedBox(height: 12),
            _buildFollowUpActions(queue.length),
          ],
          const SizedBox(height: 16),
          _buildSamplesRow(),
          const SizedBox(height: 16),
          _buildActivityLog(logs),
          const SizedBox(height: 16),
          _buildLiveStats(txs.length, queue.length, outings.where((o) => o.isActive).length),
        ],
      ),
    );
  }

  Widget _buildFollowUpActions(int pendingCount) {
    return Row(
      children: [
        Expanded(
          child: OutlinedButton.icon(
            onPressed: pendingCount == 0
                ? null
                : () => SmsLabSimulator.simulateNotificationTap(ref: ref, context: context),
            icon: const Icon(LucideIcons.bellRing, size: 14),
            label: const Text('Notification Click', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w500)),
            style: _outlineStyle,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: OutlinedButton.icon(
            onPressed: pendingCount == 0
                ? null
                : () => SmsLabSimulator.openVerifyPopup(ref: ref, context: context),
            icon: const Icon(LucideIcons.checkCircle, size: 14),
            label: const Text('Verify Popup', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w500)),
            style: _outlineStyle,
          ),
        ),
      ],
    );
  }

  Widget _buildPipelinePreview() {
    final res = _testResult!;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: SoftPalette.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: SoftPalette.emerald.withValues(alpha: 0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('PIPELINE PREVIEW (dry-run)', style: _sectionLabel),
          const SizedBox(height: 10),
          _diagRow('Parsed Amount', res.parsedAmount != null ? '₹${res.parsedAmount!.toStringAsFixed(0)}' : '—'),
          _diagRow('Transaction Type', res.parsedDirection?.toUpperCase() ?? '—'),
          _diagRow('Title / Merchant', res.parsedMerchant ?? '—'),
          _diagRow('Merchant Identifier (lookup key)', res.merchantIdentifier ?? '—'),
          _diagRow('Bank', res.parsedBank ?? '—'),
          _diagRow('Account Last4', res.parsedAccountLast4 ?? '—'),
          _diagRow('Reference ID', res.parsedReferenceId ?? '—'),
          _diagRow('Parsed Date', res.parsedDate ?? '—'),
          _diagRow('Parsed Time', res.parsedTime ?? '—'),
          _diagRow('Merchant Match', res.merchantFound ? (res.mappedMerchantName ?? 'Yes') : 'No'),
          _diagRow('Pending Verification', res.isPendingVerification ? 'Yes' : 'No'),
          _diagRow('Notification Preview', '${res.notificationTitle} • ${res.notificationBody}'),
          if (res.isBlocked) _diagRow('Blocked', res.blockReason ?? 'Yes', color: SoftPalette.negative),
        ],
      ),
    );
  }

  Widget _buildSmsInputCard(bool isRunning, DateTime? scheduledAt, bool autoDetectionOn) {
    final bool isScheduled = scheduledAt != null && scheduledAt.isAfter(DateTime.now());
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: SoftPalette.emeraldSoft,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: SoftPalette.mint.withValues(alpha: 0.35)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              const Icon(LucideIcons.flaskConical, color: SoftPalette.emerald, size: 20),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'SMS Detection Lab',
                  style: TextStyle(color: AppSurface.text, fontWeight: FontWeight.w500, fontSize: 16),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            'Paste any SMS, pick delay and flow mode, then tap Run Test.',
            style: TextStyle(color: AppSurface.text.withValues(alpha: 0.45), fontSize: 12, height: 1.35),
          ),
          if (!autoDetectionOn) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: SoftPalette.negative.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: SoftPalette.negative.withValues(alpha: 0.35)),
              ),
              child: const Row(
                children: [
                  Icon(LucideIcons.alertCircle, color: SoftPalette.negative, size: 18),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      SmsLabSimulator.autoDetectionOffMessage,
                      style: TextStyle(color: SoftPalette.negative, fontSize: 12, height: 1.35),
                    ),
                  ),
                ],
              ),
            ),
          ],
          const SizedBox(height: 14),
          Row(
            children: [
              const Text('SAMPLE SMS', style: _sectionLabel),
              const Spacer(),
              _smsFieldAction(
                icon: LucideIcons.clipboardPaste,
                label: 'Paste',
                onTap: _pasteFromClipboard,
                color: SoftPalette.emerald,
              ),
              const SizedBox(width: 8),
              _smsFieldAction(
                icon: LucideIcons.eraser,
                label: 'Clear',
                onTap: _clearSmsField,
                color: AppSurface.subText,
              ),
            ],
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _smsCtrl,
            maxLines: 5,
            style: TextStyle(color: AppSurface.text, fontSize: 12, height: 1.4, fontFamily: 'monospace'),
            decoration: InputDecoration(
              hintText: 'Paste any bank SMS here...',
              hintStyle: TextStyle(color: AppSurface.text.withValues(alpha: 0.2), fontSize: 12),
              filled: true,
              fillColor: Colors.black,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: AppSurface.text.withValues(alpha: 0.08)),
              ),
            ),
          ),
          const SizedBox(height: 14),
          const Text('DELAY (simulate SMS arrival)', style: _sectionLabel),
          const SizedBox(height: 8),
          Row(
            children: [
              _delayChip(0, 'Now'),
              const SizedBox(width: 8),
              _delayChip(5, '5 sec'),
              const SizedBox(width: 8),
              _delayChip(10, '10 sec'),
            ],
          ),
          const SizedBox(height: 14),
          const Text('FLOW MODE', style: _sectionLabel),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: _flowChip(
                  SmsLabFlowMode.background,
                  'Clear history',
                  LucideIcons.moon,
                  'Auto notification after delay',
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _flowChip(
                  SmsLabFlowMode.foreground,
                  'App open',
                  LucideIcons.smartphone,
                  'Live detect + snackbar',
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 50,
            child: ElevatedButton.icon(
              onPressed: isRunning ? null : _runTest,
              icon: Icon(isRunning ? LucideIcons.loader : LucideIcons.play, size: 18),
              label: Text(
                isRunning
                    ? (_delaySeconds > 0 ? 'Running in ${_delaySeconds}s...' : 'Running...')
                    : 'Run Test',
                style: const TextStyle(fontWeight: FontWeight.w500),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: SoftColors.control,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
          if (_flowMode == SmsLabFlowMode.background && _delaySeconds > 0) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.amberAccent.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.amberAccent.withValues(alpha: 0.25)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Icon(LucideIcons.smartphoneNfc, size: 14, color: Colors.amberAccent),
                      SizedBox(width: 8),
                      Text(
                        'CLEAR FROM RECENTS TEST',
                        style: TextStyle(
                          color: Colors.amberAccent,
                          fontSize: 11,
                          fontWeight: FontWeight.w500,
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '1. Tap Run → 2. Immediately swipe SpentX away from recent apps (clear history) → '
                    '3. After ${_delaySeconds}s the phone shows a transaction notification automatically → '
                    '4. Tap notification to open verify flow.',
                    style: TextStyle(color: Colors.amberAccent.withValues(alpha: 0.9), fontSize: 11, height: 1.4),
                  ),
                ],
              ),
            ),
          ],
          if (isScheduled) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: SoftPalette.positive.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: SoftPalette.positive.withValues(alpha: 0.3)),
              ),
              child: Row(
                children: [
                  const Icon(LucideIcons.clock, color: SoftPalette.positive, size: 18),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'Alarm set for ${DateFormat('HH:mm:ss').format(scheduledAt)} — clear app from recents now.',
                      style: const TextStyle(color: SoftPalette.positive, fontSize: 12, fontWeight: FontWeight.w500),
                    ),
                  ),
                  TextButton(
                    onPressed: () => SmsLabSimulator.cancelScheduled(ref),
                    child: const Text('Cancel', style: TextStyle(color: Colors.redAccent, fontSize: 11)),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _smsFieldAction({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    required Color color,
  }) {
    return Material(
      color: AppSurface.text.withValues(alpha: 0.06),
      borderRadius: BorderRadius.circular(8),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 14, color: color),
              const SizedBox(width: 5),
              Text(
                label,
                style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w500),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _delayChip(int seconds, String label) {
    final selected = _delaySeconds == seconds;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _delaySeconds = seconds),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: selected ? SoftPalette.emerald.withValues(alpha: 0.2) : Colors.white.withValues(alpha: 0.04),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: selected ? SoftPalette.emerald : AppSurface.border),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: selected ? SoftPalette.emerald : AppSurface.subText,
              fontWeight: FontWeight.w500,
              fontSize: 12,
            ),
          ),
        ),
      ),
    );
  }

  Widget _flowChip(SmsLabFlowMode mode, String title, IconData icon, String subtitle) {
    final selected = _flowMode == mode;
    return GestureDetector(
      onTap: () => setState(() => _flowMode = mode),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: selected ? SoftPalette.emerald.withValues(alpha: 0.15) : Colors.white.withValues(alpha: 0.03),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: selected ? SoftPalette.emerald.withValues(alpha: 0.5) : AppSurface.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 16, color: selected ? SoftPalette.emerald : AppSurface.faint),
            const SizedBox(height: 6),
            Text(title, style: TextStyle(color: selected ? Colors.white : AppSurface.subText, fontWeight: FontWeight.w500, fontSize: 12)),
            const SizedBox(height: 2),
            Text(subtitle, style: TextStyle(color: AppSurface.text.withValues(alpha: 0.3), fontSize: 9)),
          ],
        ),
      ),
    );
  }

  Widget _buildSamplesRow() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('REAL BANK SAMPLES', style: _sectionLabel),
        const SizedBox(height: 8),
        SizedBox(
          height: 36,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: SmsLabSamples.bankOnly.length,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (context, i) {
              final s = SmsLabSamples.bankOnly[i];
              return ActionChip(
                label: Text(s.label, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w500)),
                backgroundColor: s.kind == 'credit' ? SoftPalette.positive.withValues(alpha: 0.15) : SoftPalette.negative.withValues(alpha: 0.15),
                side: BorderSide(
                  color: s.kind == 'credit' ? SoftPalette.positive.withValues(alpha: 0.3) : SoftPalette.negative.withValues(alpha: 0.3),
                ),
                onPressed: () {
                  setState(() => _smsCtrl.text = s.sms);
                  HapticFeedback.lightImpact();
                },
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildActivityLog(List<SmsLabLogEntry> logs) {
    return Container(
      decoration: BoxDecoration(
        color: SoftPalette.surfaceVariant,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppSurface.text.withValues(alpha: 0.05)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
            child: Row(
              children: [
                const Icon(LucideIcons.terminal, color: Colors.greenAccent, size: 16),
                const SizedBox(width: 8),
                const Text('LIVE ACTIVITY LOG', style: _sectionLabel),
                const Spacer(),
                if (logs.isNotEmpty)
                  GestureDetector(
                    onTap: () => SmsLabSimulator.clearLogs(ref),
                    child: Text('Clear', style: TextStyle(color: AppSurface.text.withValues(alpha: 0.35), fontSize: 11)),
                  ),
              ],
            ),
          ),
          Container(
            constraints: const BoxConstraints(minHeight: 120, maxHeight: 200),
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            child: logs.isEmpty
                ? Center(
                    child: Text(
                      'Run a real flow test to see step-by-step logs.',
                      style: TextStyle(color: AppSurface.text.withValues(alpha: 0.25), fontSize: 12),
                    ),
                  )
                : ListView.builder(
                    shrinkWrap: true,
                    itemCount: logs.length,
                    itemBuilder: (_, i) {
                      final e = logs[i];
                      final color = switch (e.level) {
                        SmsLabLogLevel.success => Colors.greenAccent,
                        SmsLabLogLevel.warning => Colors.amberAccent,
                        SmsLabLogLevel.error => Colors.redAccent,
                        _ => AppSurface.subText,
                      };
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 6),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              DateFormat('HH:mm:ss').format(e.time),
                              style: TextStyle(color: AppSurface.text.withValues(alpha: 0.25), fontSize: 11, fontFamily: 'monospace'),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                e.message,
                                style: TextStyle(color: color, fontSize: 11, fontFamily: 'monospace', height: 1.3),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  static ButtonStyle get _outlineStyle => OutlinedButton.styleFrom(
        foregroundColor: AppSurface.subText,
        side: BorderSide(color: AppSurface.text.withValues(alpha: 0.12)),
        padding: const EdgeInsets.symmetric(vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      );

  Widget _buildLiveStats(int txs, int pending, int activeTrips) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: SoftPalette.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppSurface.text.withValues(alpha: 0.04)),
      ),
      child: Row(
        children: [
          _stat('Transactions', '$txs', SoftPalette.ink),
          _stat('Pending', '$pending', SoftPalette.warning),
          _stat('Active trips', '$activeTrips', SoftPalette.emerald),
          _stat('Rules', '${Hive.box('merchant_rules_box').length}', SoftPalette.muted),
        ],
      ),
    );
  }

  Widget _stat(String label, String value, Color color) {
    return Expanded(
      child: Column(
        children: [
          Text(value, style: TextStyle(color: color, fontWeight: FontWeight.w500, fontSize: 16)),
          Text(label, textAlign: TextAlign.center, style: TextStyle(color: AppSurface.text.withValues(alpha: 0.3), fontSize: 11, fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }

  Widget _diagRow(String label, String value, {Color? color}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          Text(label, style: TextStyle(color: AppSurface.text.withValues(alpha: 0.35), fontSize: 11)),
          const Spacer(),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.end,
              style: TextStyle(color: color ?? AppSurface.subText, fontWeight: FontWeight.w500, fontSize: 11),
            ),
          ),
        ],
      ),
    );
  }

  static const _sectionLabel = TextStyle(
    fontSize: 11,
    fontWeight: FontWeight.w500,
    letterSpacing: 1.2,
    color: Colors.grey,
  );
}