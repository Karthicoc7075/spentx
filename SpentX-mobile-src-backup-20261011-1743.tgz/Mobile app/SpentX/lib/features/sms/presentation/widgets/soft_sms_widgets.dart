import 'package:flutter/material.dart';

import '../../../../core/theme/soft_palette.dart';
import '../../../../core/theme/spentx_tokens.dart';
import '../../../../core/widgets/reference_ui.dart';

/// Soft SMS list / activity card.
class SoftSmsCard extends StatelessWidget {
  const SoftSmsCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.color,
    this.onTap,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color? color;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final card = SxSoftCard(padding: padding, color: color, child: child);
    if (onTap == null) return card;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: const BorderRadius.all(Radius.circular(18)),
        child: card,
      ),
    );
  }
}

/// Soft light hero for SMS activity / detected chrome.
class SoftSmsHero extends StatelessWidget {
  const SoftSmsHero({
    super.key,
    required this.label,
    required this.title,
    this.subtitle,
    this.icon = Icons.sms_outlined,
  });

  final String label;
  final String title;
  final String? subtitle;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return SoftSmsCard(
      color: SoftPalette.emeraldSoft,
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: SoftPalette.card,
              shape: BoxShape.circle,
              border: Border.all(color: SoftPalette.mint.withValues(alpha: 0.35)),
            ),
            child: Icon(icon, color: SoftPalette.emerald, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label.toUpperCase(),
                  style: const TextStyle(
                    color: SoftPalette.emerald,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.1,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  title,
                  style: const TextStyle(
                    color: SoftPalette.ink,
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                if (subtitle != null) ...[
                  const SizedBox(height: 2),
                  Text(
                    subtitle!,
                    style: TextStyle(
                      color: context.tokens.textSecondary,
                      fontSize: 12,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Soft muted section label for SMS lists.
class SoftSmsSectionHeader extends StatelessWidget {
  const SoftSmsSectionHeader(this.title, {super.key, this.count, this.accent});

  final String title;
  final int? count;
  final Color? accent;

  @override
  Widget build(BuildContext context) {
    final color = accent ?? SoftPalette.muted;
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 8, 4, 10),
      child: Row(
        children: [
          Text(
            title.toUpperCase(),
            style: TextStyle(
              color: color,
              fontSize: 11,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.1,
            ),
          ),
          if (count != null) ...[
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: SoftPalette.emeraldSoft,
                borderRadius: BorderRadius.circular(999),
              ),
              child: Text(
                '$count',
                style: const TextStyle(
                  color: SoftPalette.emerald,
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
