import 'package:flutter/material.dart';
import '../../../core/theme/spentx_tokens.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../core/widgets/reference_ui.dart';
import 'widgets/soft_sms_widgets.dart';
import '../../../core/widgets/transaction_tile.dart';
import '../../../core/utils/transaction_display_utils.dart';
import '../../../core/providers/transaction_provider.dart' as model;
import '../sms_service.dart';

class SmsTransactionsScreen extends ConsumerStatefulWidget {
  const SmsTransactionsScreen({super.key});

  @override
  ConsumerState<SmsTransactionsScreen> createState() =>
      _SmsTransactionsScreenState();
}

class _SmsTransactionsScreenState extends ConsumerState<SmsTransactionsScreen> {
  DateTime? _activityCutoff;

  @override
  void initState() {
    super.initState();
    _loadActivityCutoff();
  }

  Future<void> _loadActivityCutoff() async {
    final cutoff = await SmsService.ensureActivityStartTime();
    if (!mounted) return;
    setState(() => _activityCutoff = cutoff);
  }

  @override
  Widget build(BuildContext context) {
    final transactions = ref.watch(model.transactionProvider);
    final smsList =
        _activityCutoff == null
            ? const <model.Transaction>[]
            : transactions
                .where(
                  (t) => t.isAutoDetected && !t.date.isBefore(_activityCutoff!),
                )
                .toList();

    final t = context.tokens;
    return Scaffold(
      backgroundColor: t.background,
      appBar: AppBar(
        backgroundColor: t.surface,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        leadingWidth: 56,
        leading: Padding(
          padding: const EdgeInsets.only(left: 8),
          child: Center(
            child: SoftCircleIconButton(
              icon: Icons.arrow_back_ios_new_rounded,
              tooltip: 'Back',
              onPressed: () => Navigator.maybePop(context),
            ),
          ),
        ),
        title: Text('SMS Activity', style: AppType.section(SoftPalette.ink)),
        actions: [
          IconButton(
            icon: const Icon(LucideIcons.refreshCw, size: 20),
            tooltip: 'Reload detected transactions',
            onPressed:
                () =>
                    ref
                        .read(model.transactionProvider.notifier)
                        .reloadFromStorage(),
          ),
          IconButton(
            icon: const Icon(LucideIcons.filter, size: 20),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Header Stats ──
          Padding(
            padding: const EdgeInsets.all(20),
            child: SoftSmsHero(
              label: 'SMS DETECTED',
              title: '${smsList.length} Transactions',
              subtitle: 'Captured from your messages',
              icon: LucideIcons.messageSquare,
            ),
          ),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: const SoftSmsSectionHeader('HISTORY'),
          ),
          const SizedBox(height: 12),

          Expanded(
            child:
                _activityCutoff == null
                    ? const Center(child: CircularProgressIndicator())
                    : smsList.isEmpty
                    ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            LucideIcons.messageSquare,
                            size: 48,
                            color: context.tokens.textSecondary,
                          ),
                          const SizedBox(height: 16),
                          const Text(
                            'No SMS data found',
                            style: TextStyle(fontWeight: FontWeight.w500),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Transactions from SMS will appear here.',
                            style: TextStyle(
                              fontSize: 13,
                              color: context.tokens.textSecondary,
                            ),
                          ),
                        ],
                      ),
                    )
                    : ListView.separated(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 10,
                      ),
                      physics: const BouncingScrollPhysics(),
                      itemCount: smsList.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 10),
                      itemBuilder: (context, i) {
                        final tx = smsList[i];
                        final txDisplayTitle =
                            TransactionDisplayUtils.displayTitle(tx);
                        return TransactionTile(
                          merchant: txDisplayTitle.primary,
                          itemsLabel: txDisplayTitle.itemsLabel,
                          category: tx.category,
                          account: tx.account,
                          paymentType: tx.paymentType,
                          date: TransactionDisplayUtils.formatListDateTime(
                            tx.date,
                            legacyTime: tx.time,
                          ),
                          amount: tx.amount,
                          isExpense: tx.isExpense,
                          purpose: tx.purpose,
                          splitBadge:
                              tx.time == 'OutingSummary' ||
                                      tx.time == 'Trip' ||
                                      (tx.outingId != null)
                                  ? 'Outing'
                                  : (tx.isGroup
                                      ? (tx.groupCount == 1
                                          ? 'Friend Split'
                                          : 'Split Expense')
                                      : null),
                          splitBadgeTint:
                              tx.time == 'OutingSummary' ||
                                      tx.time == 'Trip' ||
                                      (tx.outingId != null)
                                  ? SoftPalette.surfaceVariant
                                  : (tx.isGroup
                                      ? (tx.groupCount == 1
                                          ? SoftPalette.emeraldSoft
                                          : SoftPalette.surfaceVariant)
                                      : null),
                          isAutoDetected: true,
                          isTransfer: tx.isTransfer,
                        );
                      },
                    ),
          ),
        ],
      ),
    );
  }
}
