import 'package:flutter/material.dart';
import '../../../core/theme/soft_palette.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../core/theme/spentx_tokens.dart';
import '../../../core/widgets/reference_ui.dart';

class SmsConfirmationSheet extends StatefulWidget {
  final String bank;
  final String amount;
  final String merchant;
  final String category;

  const SmsConfirmationSheet({
    super.key,
    this.bank = 'HDFC Bank',
    this.amount = '₹1,299',
    this.merchant = 'Amazon',
    this.category = 'Shopping',
  });

  @override
  State<SmsConfirmationSheet> createState() => _SmsConfirmationSheetState();
}

class _SmsConfirmationSheetState extends State<SmsConfirmationSheet> {
  int _accountType = -1; // -1=none, 0=Own, 1=Home

  @override
  Widget build(BuildContext context) {
    final tokens = context.tokens;

    return Container(
      decoration: BoxDecoration(
        color: tokens.card,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        boxShadow: AppShadows.bento,
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(24, 12, 24, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Soft sheet handle keeps the modal chrome calm and consistent.
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: tokens.border,
                borderRadius: BorderRadius.circular(999),
              ),
            ),
            const SizedBox(height: 20),
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                color: tokens.primarySoft,
                shape: BoxShape.circle,
              ),
              child: Icon(
                LucideIcons.smartphone,
                color: tokens.primary,
                size: 28,
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: Text(
                    'SMS Detected',
                    style: TextStyle(
                      color: tokens.textPrimary,
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                SoftCircleIconButton(
                  icon: Icons.close_rounded,
                  tooltip: 'Close',
                  onPressed: () => Navigator.maybePop(context),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              'Transaction detected from ${widget.bank}',
              style: TextStyle(fontSize: 13, color: tokens.textSecondary),
            ),
            const SizedBox(height: 24),

            // ── Own / Home Choice ──
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Add to which account?',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  color: tokens.textSecondary,
                ),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _AccountChoice(
                    icon: LucideIcons.user,
                    label: 'Own Expense',
                    color: tokens.primary,
                    isSelected: _accountType == 0,
                    onTap: () => setState(() => _accountType = 0),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _AccountChoice(
                    icon: LucideIcons.home,
                    label: 'Home Expense',
                    color: tokens.mint,
                    isSelected: _accountType == 1,
                    onTap: () => setState(() => _accountType = 1),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),

            // ── Transaction Details ──
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: tokens.card,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: tokens.border),
                boxShadow: AppShadows.subtle,
              ),
              child: Column(
                children: [
                  _DetailRow(label: 'Merchant', value: widget.merchant),
                  const SizedBox(height: 14),
                  _DetailRow(
                    label: 'Amount',
                    value: widget.amount,
                    valueColor: tokens.negative,
                  ),
                  const SizedBox(height: 14),
                  _DetailRow(label: 'Bank', value: widget.bank),
                  const SizedBox(height: 14),
                  _DetailRow(label: 'Category', value: widget.category),
                ],
              ),
            ),
            const SizedBox(height: 28),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(context),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: tokens.textSecondary,
                      backgroundColor: tokens.card,
                      side: BorderSide(color: tokens.border),
                      elevation: 0,
                      minimumSize: const Size.fromHeight(52),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(22),
                      ),
                    ),
                    child: const Text('Dismiss'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed:
                        _accountType >= 0 ? () => Navigator.pop(context) : null,
                    style: ElevatedButton.styleFrom(
                      foregroundColor: Colors.white,
                      backgroundColor: SoftColors.control,
                      disabledForegroundColor: tokens.textDisabled,
                      disabledBackgroundColor: tokens.disabled,
                      elevation: 0,
                      minimumSize: const Size.fromHeight(52),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(22),
                      ),
                    ),
                    child: const Text('Confirm'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _AccountChoice extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final bool isSelected;
  final VoidCallback onTap;

  const _AccountChoice({
    required this.icon,
    required this.label,
    required this.color,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final tokens = context.tokens;

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: isSelected ? tokens.primarySoft : tokens.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? color : tokens.border,
            width: isSelected ? 1.5 : 1,
          ),
          boxShadow: isSelected ? null : AppShadows.subtle,
        ),
        child: Column(
          children: [
            Icon(
              icon,
              color: isSelected ? color : tokens.textSecondary,
              size: 24,
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                fontSize: 13,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                color: isSelected ? color : tokens.textSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final String label;
  final String value;
  final Color? valueColor;

  const _DetailRow({required this.label, required this.value, this.valueColor});

  @override
  Widget build(BuildContext context) {
    final tokens = context.tokens;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(fontSize: 13, color: tokens.textSecondary),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.end,
              overflow: TextOverflow.ellipsis,
              maxLines: 2,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: valueColor ?? tokens.textPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
