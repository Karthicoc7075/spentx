import 'package:flutter/material.dart';
import '../../../core/theme/spentx_tokens.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../core/providers/friends_provider.dart';
import '../../../core/providers/contacts_provider.dart';
import '../../../core/services/contacts_service.dart';
import 'add_friend_form.dart';
import 'friends_screen.dart' show FriendSearchField, FriendTile, FriendsScreen;

/// Result when a person is picked for an outing (same fields as TripMember / OutingMember).
class FriendPickResult {
  final String name;
  final String? phone;
  final String? upiId;

  const FriendPickResult({required this.name, this.phone, this.upiId});
}

/// Picker for outing members: On this trip → Added friends → All friends → Contacts.
/// Contacts open the same Add Friend form as the Friends page (confirm before save).
class FriendPickerScreen extends ConsumerStatefulWidget {
  final ValueChanged<FriendPickResult> onSelect;

  /// Names already on the outing (incl. You). Shown at top; not offered to add again.
  final Set<String> outingMemberNames;

  const FriendPickerScreen({
    super.key,
    required this.onSelect,
    this.outingMemberNames = const {},
  });

  @override
  ConsumerState<FriendPickerScreen> createState() => _FriendPickerScreenState();
}

class _FriendPickerScreenState extends ConsumerState<FriendPickerScreen> {
  String _search = '';

  Set<String> get _onTripLower =>
      widget.outingMemberNames
          .map((n) => n.toLowerCase())
          .where((n) => n != 'you')
          .toSet();

  bool _isOnTrip(String name) => _onTripLower.contains(name.toLowerCase());

  void _pickResult(FriendPickResult result) {
    if (_isOnTrip(result.name)) return;
    ref.read(recentFriendsProvider.notifier).recordUse(result.name);
    widget.onSelect(result);
    if (mounted) Navigator.pop(context);
  }

  void _pickExistingFriend(Friend f) {
    _pickResult(
      FriendPickResult(
        name: f.name,
        phone: f.phone,
        upiId: f.upiId ?? (f.upiIds.isNotEmpty ? f.upiIds.first : null),
      ),
    );
  }

  /// Contact → quick add by name (+ phone). UPI can be filled later on Friends.
  /// Long-press still opens the full form if they want to edit / add UPI now.
  void _addFromContact(String name, String? phone, {bool openForm = false}) {
    final existing = ref
        .read(manualFriendsProvider.notifier)
        .friendWithPhone(phone);
    if (existing != null) {
      if (_isOnTrip(existing.name)) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${existing.name} is already on this trip'),
            behavior: SnackBarBehavior.floating,
          ),
        );
        return;
      }
      _pickExistingFriend(existing);
      return;
    }

    final byName = ref
        .read(friendsProvider)
        .where((f) => f.name.toLowerCase() == name.toLowerCase());
    if (byName.isNotEmpty) {
      _pickExistingFriend(byName.first);
      return;
    }

    if (openForm) {
      AddFriendForm.show(
        context,
        initialName: name,
        initialPhone: phone,
        title: 'Add Friend to Trip',
        saveLabel: 'Add to Trip',
        onSaved: (friend) {
          _pickResult(
            FriendPickResult(
              name: friend.name,
              phone: friend.phone,
              upiId:
                  friend.upiId ??
                  (friend.upiIds.isNotEmpty ? friend.upiIds.first : null),
            ),
          );
        },
      );
      return;
    }

    // Quick path: name only (phone optional). No UPI required.
    ref.read(manualFriendsProvider.notifier).addFriend(name, phone: phone);
    ref.read(recentFriendsProvider.notifier).recordUse(name);
    _pickResult(FriendPickResult(name: name, phone: phone));
  }

  void _openManageFriends() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const FriendsScreen()),
    ).then((_) {
      if (mounted) setState(() {});
    });
  }

  bool _matchesSearch(String name, {String? phone}) {
    if (_search.isEmpty) return true;
    final q = _search.toLowerCase();
    if (name.toLowerCase().contains(q)) return true;
    if (phone != null && phone.contains(_search)) return true;
    return false;
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) ref.invalidate(deviceContactsProvider);
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final allFriends = ref.watch(friendsProvider);
    final contactsAsync = ref.watch(deviceContactsProvider);
    final friendByName = {for (final f in allFriends) f.name.toLowerCase(): f};

    final outingFriends = <Friend>[];
    for (final name in widget.outingMemberNames) {
      if (name.toLowerCase() == 'you') continue;
      if (!_matchesSearch(name)) continue;
      outingFriends.add(
        friendByName[name.toLowerCase()] ??
            Friend(
              name: name,
              avatar: name.isNotEmpty ? name[0].toUpperCase() : '?',
              expenses: const [],
            ),
      );
    }
    outingFriends.sort(
      (a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()),
    );

    final addedFriends =
        allFriends
            .where(
              (f) =>
                  f.isManual &&
                  !_isOnTrip(f.name) &&
                  _matchesSearch(f.name, phone: f.phone),
            )
            .toList();

    final otherFriends =
        allFriends
            .where(
              (f) =>
                  !f.isManual &&
                  !_isOnTrip(f.name) &&
                  _matchesSearch(f.name, phone: f.phone),
            )
            .toList();

    final headerSurface = isDark ? SoftPalette.darkCard : SoftPalette.surface;
    final headerBorder =
        isDark ? SoftPalette.darkBorder : SoftPalette.surfaceVariant;
    final headerInk = isDark ? SoftPalette.darkInk : SoftPalette.ink;
    final headerAccent = isDark ? SoftPalette.darkEmerald : SoftPalette.emerald;
    final headerTint =
        isDark ? SoftPalette.darkEmeraldSoft : SoftPalette.emeraldSoft;

    return Scaffold(
      backgroundColor: isDark ? SoftPalette.darkBg : SoftPalette.bg,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(76),
        child: SafeArea(
          bottom: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
            child: Row(
              children: [
                if (Navigator.of(context).canPop())
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: headerSurface,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: headerBorder),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0x0A0F172A),
                          blurRadius: 14,
                          offset: Offset(0, 5),
                        ),
                      ],
                    ),
                    child: IconButton(
                      tooltip: 'Back',
                      icon: Icon(
                        LucideIcons.arrowLeft,
                        size: 20,
                        color: headerInk,
                      ),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  )
                else
                  const SizedBox(width: 44),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Add Friend to Trip',
                    style: TextStyle(
                      color: headerInk,
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                      letterSpacing: -0.3,
                    ),
                  ),
                ),
                TextButton(
                  onPressed: _openManageFriends,
                  style: TextButton.styleFrom(
                    foregroundColor: headerAccent,
                    backgroundColor: headerTint,
                    minimumSize: const Size(0, 40),
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  child: const Text(
                    'Friends',
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: headerSurface,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: headerBorder),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x0A0F172A),
                        blurRadius: 14,
                        offset: Offset(0, 5),
                      ),
                    ],
                  ),
                  child: IconButton(
                    tooltip: 'Add friend manually',
                    icon: Icon(
                      LucideIcons.userPlus,
                      size: 19,
                      color: headerAccent,
                    ),
                    onPressed: () {
                      AddFriendForm.show(
                        context,
                        title: 'Add Friend',
                        saveLabel: 'Save & Add to Trip',
                        onSaved: (friend) {
                          _pickResult(
                            FriendPickResult(
                              name: friend.name,
                              phone: friend.phone,
                              upiId: friend.upiId,
                            ),
                          );
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          FriendSearchField(
            hint: 'Search trip, friends & contacts',
            isDark: isDark,
            onChanged: (v) => setState(() => _search = v),
          ),
          Expanded(
            child: contactsAsync.when(
              loading:
                  () => _buildSections(
                    ref: ref,
                    isDark: isDark,
                    outingFriends: outingFriends,
                    addedFriends: addedFriends,
                    otherFriends: otherFriends,
                    contacts: const [],
                    friendNamesLower: friendByName.keys.toSet(),
                    contactsLoading: true,
                  ),
              error:
                  (_, __) => _buildSections(
                    ref: ref,
                    isDark: isDark,
                    outingFriends: outingFriends,
                    addedFriends: addedFriends,
                    otherFriends: otherFriends,
                    contacts: const [],
                    friendNamesLower: friendByName.keys.toSet(),
                  ),
              data: (contacts) {
                final filteredContacts =
                    contacts.where((c) {
                      if (_isOnTrip(c.displayName)) return false;
                      return _matchesSearch(c.displayName, phone: c.phone);
                    }).toList();

                return _buildSections(
                  ref: ref,
                  isDark: isDark,
                  outingFriends: outingFriends,
                  addedFriends: addedFriends,
                  otherFriends: otherFriends,
                  contacts: filteredContacts,
                  friendNamesLower: friendByName.keys.toSet(),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSections({
    required WidgetRef ref,
    required bool isDark,
    required List<Friend> outingFriends,
    required List<Friend> addedFriends,
    required List<Friend> otherFriends,
    required List<DeviceContact> contacts,
    required Set<String> friendNamesLower,
    bool contactsLoading = false,
  }) {
    final isEmpty =
        outingFriends.isEmpty &&
        addedFriends.isEmpty &&
        otherFriends.isEmpty &&
        contacts.isEmpty &&
        !contactsLoading;

    if (isEmpty) {
      return Center(
        child: Text(
          _search.isEmpty ? 'No people to add' : 'No matches for "$_search"',
          style: TextStyle(color: context.tokens.textSecondary),
        ),
      );
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      children: [
        if (outingFriends.isNotEmpty) ...[
          _PickerSectionHeader(
            'ON THIS TRIP',
            isDark: isDark,
            icon: LucideIcons.compass,
          ),
          const SizedBox(height: 8),
          ...outingFriends.map(
            (f) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: _OnTripTile(friend: f, isDark: isDark),
            ),
          ),
          const SizedBox(height: 16),
        ],
        if (addedFriends.isNotEmpty) ...[
          _PickerSectionHeader(
            'ADDED FRIENDS',
            isDark: isDark,
            icon: LucideIcons.userCheck,
          ),
          const SizedBox(height: 8),
          ...addedFriends.map(
            (f) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: FriendTile(
                friend: f,
                isDark: isDark,
                onTap: () => _pickExistingFriend(f),
              ),
            ),
          ),
          const SizedBox(height: 16),
        ],
        if (otherFriends.isNotEmpty) ...[
          _PickerSectionHeader(
            'ALL FRIENDS',
            isDark: isDark,
            icon: LucideIcons.users,
          ),
          const SizedBox(height: 8),
          ...otherFriends.map(
            (f) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: FriendTile(
                friend: f,
                isDark: isDark,
                onTap: () => _pickExistingFriend(f),
              ),
            ),
          ),
          const SizedBox(height: 16),
        ],
        _PickerSectionHeader(
          'CONTACTS',
          isDark: isDark,
          icon: LucideIcons.contact,
        ),
        const SizedBox(height: 8),
        if (contactsLoading)
          const Padding(
            padding: EdgeInsets.all(24),
            child: Center(child: CircularProgressIndicator()),
          )
        else if (contacts.isEmpty)
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Text(
                  _search.isEmpty
                      ? 'Allow contacts to pick from your phone book'
                      : 'No contacts match',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 13,
                    color: context.tokens.textSecondary,
                  ),
                ),
                if (_search.isEmpty) ...[
                  const SizedBox(height: 12),
                  OutlinedButton(
                    onPressed: () async {
                      await ContactsService.requestPermission();
                      ref.invalidate(deviceContactsProvider);
                    },
                    child: const Text('Load Contacts'),
                  ),
                ],
              ],
            ),
          )
        else
          ...contacts.map((c) {
            final alreadyFriend = friendNamesLower.contains(
              c.displayName.toLowerCase(),
            );
            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: _ContactPickTile(
                name: c.displayName,
                phone: c.phone,
                isDark: isDark,
                alreadyFriend: alreadyFriend,
                // Tap = quick name add. Long-press = full form (UPI optional).
                onTap: () => _addFromContact(c.displayName, c.phone),
                onLongPress:
                    () =>
                        _addFromContact(c.displayName, c.phone, openForm: true),
              ),
            );
          }),
      ],
    );
  }
}

class _OnTripTile extends StatelessWidget {
  final Friend friend;
  final bool isDark;

  const _OnTripTile({required this.friend, required this.isDark});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: SoftPalette.emerald.withValues(alpha: isDark ? 0.12 : 0.08),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: SoftPalette.emerald.withValues(alpha: 0.25)),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 22,
            backgroundColor: SoftPalette.emerald.withValues(alpha: 0.2),
            child: Text(
              friend.avatar,
              style: const TextStyle(
                fontWeight: FontWeight.w500,
                color: SoftPalette.emerald,
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Text(
              friend.name,
              style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 15),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: SoftPalette.emerald.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Text(
              'ON TRIP',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w500,
                color: SoftPalette.emerald,
                letterSpacing: 0.5,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _PickerSectionHeader extends StatelessWidget {
  final String title;
  final bool isDark;
  final IconData icon;

  const _PickerSectionHeader(
    this.title, {
    required this.isDark,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 14, color: SoftPalette.emerald),
        const SizedBox(width: 8),
        Text(
          title,
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w500,
            letterSpacing: 1.2,
            color: context.tokens.textSecondary,
          ),
        ),
      ],
    );
  }
}

class _ContactPickTile extends StatelessWidget {
  final String name;
  final String? phone;
  final bool isDark;
  final bool alreadyFriend;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;

  const _ContactPickTile({
    required this.name,
    required this.phone,
    required this.isDark,
    required this.onTap,
    this.onLongPress,
    this.alreadyFriend = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      onLongPress: onLongPress,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: isDark ? AppColors.darkCard : AppColors.lightSurface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color:
                isDark
                    ? AppColors.darkBorder.withValues(alpha: 0.3)
                    : AppColors.lightBorder,
          ),
        ),
        child: Row(
          children: [
            CircleAvatar(
              radius: 22,
              backgroundColor: SoftPalette.emerald.withValues(alpha: 0.12),
              child: Text(
                name.isNotEmpty ? name[0].toUpperCase() : '?',
                style: const TextStyle(
                  fontWeight: FontWeight.w500,
                  color: SoftPalette.emerald,
                ),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    style: const TextStyle(
                      fontWeight: FontWeight.w500,
                      fontSize: 15,
                    ),
                  ),
                  if (phone != null)
                    Text(
                      phone!,
                      style: TextStyle(
                        fontSize: 12,
                        color: context.tokens.textSecondary,
                      ),
                    ),
                ],
              ),
            ),
            if (alreadyFriend)
              const Text(
                'Friend',
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                  color: SoftPalette.positive,
                ),
              )
            else
              const Icon(
                LucideIcons.plusCircle,
                size: 20,
                color: SoftPalette.emerald,
              ),
          ],
        ),
      ),
    );
  }
}
