import 'package:flutter/material.dart';
import '../../../core/theme/spentx_tokens.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../core/providers/friends_provider.dart';
import '../../../core/providers/friend_upi_provider.dart';
import '../data/friend_edit_plan.dart';
import '../data/friend_rename.dart';
import '../../../core/widgets/premium_bottom_sheet.dart';

/// Shared Add Friend form (Friends page + Outing picker + contacts).
/// Supports **multiple UPI IDs** per friend (GPay / PhonePe / bank, etc.).
class AddFriendForm extends ConsumerStatefulWidget {
  final String? initialName;

  /// Name of the saved friend being edited. When set, the form edits that
  /// friend in place (rename + replace fields) instead of adding/merging.
  final String? editingName;
  final String? initialPhone;
  final String? initialUpi;
  final List<String>? initialUpiIds;
  final String? initialNotes;

  /// Called after friend is saved. Sheet is closed before this runs.
  final void Function(Friend friend)? onSaved;
  final String title;
  final String saveLabel;

  const AddFriendForm({
    super.key,
    this.initialName,
    this.editingName,
    this.initialPhone,
    this.initialUpi,
    this.initialUpiIds,
    this.initialNotes,
    this.onSaved,
    this.title = 'Add Friend',
    this.saveLabel = 'Save Friend',
  });

  /// Opens the form in a bottom sheet (same UX as Friends page).
  static Future<void> show(
    BuildContext context, {
    String? initialName,
    String? editingName,
    String? initialPhone,
    String? initialUpi,
    List<String>? initialUpiIds,
    String? initialNotes,
    void Function(Friend friend)? onSaved,
    String title = 'Add Friend',
    String saveLabel = 'Save Friend',
  }) {
    return PremiumBottomSheet.show(
      context: context,
      child: AddFriendForm(
        initialName: initialName,
        editingName: editingName,
        initialPhone: initialPhone,
        initialUpi: initialUpi,
        initialUpiIds: initialUpiIds,
        initialNotes: initialNotes,
        onSaved: onSaved,
        title: title,
        saveLabel: saveLabel,
      ),
    );
  }

  @override
  ConsumerState<AddFriendForm> createState() => _AddFriendFormState();
}

class _AddFriendFormState extends ConsumerState<AddFriendForm> {
  late final _nameCtrl = TextEditingController(text: widget.initialName ?? '');
  late final _phoneCtrl = TextEditingController(
    text: widget.initialPhone ?? '',
  );
  late final _upiDraftCtrl = TextEditingController();
  late final _notesCtrl = TextEditingController(
    text: widget.initialNotes ?? '',
  );
  late List<String> _upiIds;
  bool _hasNameError = false;

  @override
  void initState() {
    super.initState();
    final seed = <String>[
      ...?widget.initialUpiIds,
      if (widget.initialUpi != null) widget.initialUpi!,
      // Editing: show every saved UPI link so removing one is explicit.
      if (widget.editingName != null)
        ...ref
            .read(friendUpiProvider.notifier)
            .upisForFriend(widget.editingName!),
    ];
    _upiIds = _dedupeUpis(seed);
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  /// Edit an existing friend: rename in place, and the form values REPLACE
  /// the stored ones (empty phone/notes clear, removed UPI IDs are removed).
  Future<void> _saveEdit({
    required String original,
    required String name,
    required String phone,
    required String notes,
    required List<String> upis,
  }) async {
    final notifier = ref.read(manualFriendsProvider.notifier);
    final upiLinks = ref.read(friendUpiProvider.notifier);
    final plan = FriendEditPlan.build(
      original: original,
      newName: name,
      phoneOwner: notifier.friendWithPhone(phone)?.name,
      existingNames: ref.read(friendsProvider).map((f) => f.name),
      linkedUpis: upiLinks.upisForFriend(original),
      formUpis: upis,
    );
    if (plan.error != null) {
      _snack(plan.error!);
      return;
    }

    final wasSaved = notifier.isSavedFriend(original);
    if (plan.renamed) {
      if (wasSaved && !notifier.renameFriend(original, name)) {
        _snack('Could not rename to "$name".');
        return;
      }
      await renameFriendHistory(ref, oldName: original, newName: name);
    }

    if (notifier.isSavedFriend(name)) {
      notifier.updateFriendFields(
        name,
        phone: phone,
        upiId: upis.isNotEmpty ? upis.first : '',
        upiIds: upis,
        notes: notes,
      );
    } else {
      notifier.addFriend(
        name,
        phone: phone.isEmpty ? null : phone,
        upiId: upis.isNotEmpty ? upis.first : null,
        upiIds: upis,
        notes: notes.isEmpty ? null : notes,
      );
    }
    for (final u in plan.upisToRemove) {
      upiLinks.removeUpi(name, u);
    }
    for (final u in upis) {
      upiLinks.addUpi(name, u);
    }

    final saved =
        ref
            .read(manualFriendsProvider)
            .where((f) => f.name.toLowerCase() == name.toLowerCase())
            .firstOrNull;
    final friend = Friend(
      id: saved?.id,
      name: saved?.name ?? name,
      phone: phone.isEmpty ? null : phone,
      upiId: upis.isNotEmpty ? upis.first : null,
      upiIds: upis,
      notes: notes.isEmpty ? null : notes,
      avatar: name[0].toUpperCase(),
      expenses: const [],
      isManual: true,
    );
    if (!mounted) return;
    final messenger = ScaffoldMessenger.of(context);
    Navigator.pop(context);
    widget.onSaved?.call(friend);
    if (widget.onSaved == null) {
      messenger.showSnackBar(
        SnackBar(
          content: Text('$name updated'),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    _upiDraftCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  List<String> _dedupeUpis(Iterable<String> raw) {
    final seen = <String>{};
    final out = <String>[];
    for (final r in raw) {
      final v = r.trim();
      if (v.isEmpty) continue;
      final key = v.toLowerCase();
      if (seen.contains(key)) continue;
      seen.add(key);
      out.add(v);
    }
    return out;
  }

  void _addUpiDraft() {
    final v = _upiDraftCtrl.text.trim();
    if (v.isEmpty) return;
    setState(() {
      _upiIds = _dedupeUpis([..._upiIds, v]);
      _upiDraftCtrl.clear();
    });
  }

  void _save() {
    final name = _nameCtrl.text.trim();
    if (name.isEmpty) {
      setState(() => _hasNameError = true);
      return;
    }
    if (name.toLowerCase() == 'you') {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('"You" is reserved for your own profile'),
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    final phone = _phoneCtrl.text.trim();
    final notes = _notesCtrl.text.trim();
    // Include any draft UPI not yet added as a chip.
    final draft = _upiDraftCtrl.text.trim();
    final upis = _dedupeUpis([..._upiIds, if (draft.isNotEmpty) draft]);
    final primary = upis.isNotEmpty ? upis.first : null;
    final notifier = ref.read(manualFriendsProvider.notifier);

    final editing = widget.editingName?.trim();
    if (editing != null && editing.isNotEmpty) {
      _saveEdit(
        original: editing,
        name: name,
        phone: phone,
        notes: notes,
        upis: upis,
      );
      return;
    }

    final dup = notifier.friendWithPhone(phone);
    if (dup != null && dup.name.toLowerCase() != name.toLowerCase()) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'This number is already saved as "${dup.name}" — not adding a duplicate.',
          ),
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    final existing = ref
        .read(friendsProvider)
        .where((f) => f.name.toLowerCase() == name.toLowerCase());
    Friend friend;
    if (existing.isNotEmpty) {
      // Merge extra UPIs onto existing friend.
      final prev = existing.first;
      final merged = _dedupeUpis([
        ...prev.upiIds,
        if (prev.upiId != null) prev.upiId!,
        ...upis,
      ]);
      notifier.updateFriendFields(
        prev.name,
        phone: phone.isEmpty ? prev.phone : phone,
        upiId: merged.isNotEmpty ? merged.first : prev.upiId,
        upiIds: merged,
        notes: notes.isEmpty ? prev.notes : notes,
      );
      for (final u in merged) {
        ref.read(friendUpiProvider.notifier).addUpi(name, u);
      }
      friend = Friend(
        name: prev.name,
        phone: phone.isEmpty ? prev.phone : phone,
        upiId: merged.isNotEmpty ? merged.first : prev.upiId,
        upiIds: merged,
        notes: notes.isEmpty ? prev.notes : notes,
        avatar: prev.avatar,
        expenses: prev.expenses,
        isManual: true,
      );
    } else {
      notifier.addFriend(
        name,
        phone: phone.isEmpty ? null : phone,
        upiId: primary,
        upiIds: upis,
        notes: notes.isEmpty ? null : notes,
      );
      for (final u in upis) {
        ref.read(friendUpiProvider.notifier).addUpi(name, u);
      }
      friend = Friend(
        name: name,
        phone: phone.isEmpty ? null : phone,
        upiId: primary,
        upiIds: upis,
        notes: notes.isEmpty ? null : notes,
        avatar: name[0].toUpperCase(),
        expenses: const [],
        isManual: true,
      );
    }

    Navigator.pop(context);
    widget.onSaved?.call(friend);
    if (widget.onSaved == null && mounted) {
      final isUpdate = widget.saveLabel.toLowerCase().contains('update');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            isUpdate
                ? '$name updated'
                : upis.length > 1
                ? '$name saved · ${upis.length} UPI IDs'
                : '$name saved to friends',
          ),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(widget.title, style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 8),
          Text(
            'One friend, many UPI IDs (GPay, PhonePe, bank…). Phone optional.',
            style: TextStyle(fontSize: 12, color: context.tokens.textSecondary),
          ),
          const SizedBox(height: 20),
          Container(
            decoration: BoxDecoration(
              border:
                  _hasNameError
                      ? Border.all(color: SoftPalette.negative, width: 1.5)
                      : null,
              borderRadius: BorderRadius.circular(12),
            ),
            child: TextField(
              controller: _nameCtrl,
              autofocus: true,
              textCapitalization: TextCapitalization.words,
              onChanged: (v) {
                if (_hasNameError && v.trim().isNotEmpty) {
                  setState(() => _hasNameError = false);
                }
              },
              decoration: InputDecoration(
                labelText: _hasNameError ? 'Name required' : 'Friend name *',
                labelStyle: TextStyle(
                  color: _hasNameError ? SoftPalette.negative : null,
                ),
                hintText: 'e.g. Arun Kumar',
                prefixIcon: Icon(
                  LucideIcons.user,
                  size: 18,
                  color: _hasNameError ? SoftPalette.negative : null,
                ),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.all(12),
              ),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _phoneCtrl,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(
              labelText: 'Phone number (optional)',
              hintText: '+91 98765 43210',
              prefixIcon: Icon(LucideIcons.phone, size: 18),
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'UPI IDs (add multiple)',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: context.tokens.textSecondary,
            ),
          ),
          const SizedBox(height: 8),
          if (_upiIds.isNotEmpty)
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children:
                  _upiIds
                      .map(
                        (u) => Chip(
                          label: Text(u, style: const TextStyle(fontSize: 12)),
                          deleteIcon: const Icon(LucideIcons.x, size: 14),
                          onDeleted: () => setState(() => _upiIds.remove(u)),
                        ),
                      )
                      .toList(),
            ),
          if (_upiIds.isNotEmpty) const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _upiDraftCtrl,
                  keyboardType: TextInputType.emailAddress,
                  onSubmitted: (_) => _addUpiDraft(),
                  decoration: const InputDecoration(
                    hintText: 'name@upi or name@oksbi',
                    prefixIcon: Icon(LucideIcons.hash, size: 18),
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              OutlinedButton(onPressed: _addUpiDraft, child: const Text('Add')),
            ],
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _notesCtrl,
            maxLines: 3,
            textCapitalization: TextCapitalization.sentences,
            decoration: const InputDecoration(
              labelText: 'Notes (optional)',
              hintText: 'e.g. college friend, office split buddy',
              prefixIcon: Icon(LucideIcons.fileText, size: 18),
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 28),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Cancel'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton(
                  onPressed: _save,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: SoftColors.control,
                    foregroundColor: Colors.white,
                  ),
                  child: Text(widget.saveLabel),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
