import 'package:flutter/material.dart';
import '../../../core/theme/spentx_tokens.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:intl/intl.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../core/widgets/premium_bottom_sheet.dart';
import '../../../core/widgets/soft_page_kit.dart';
import '../../../core/providers/outing_provider.dart';
import '../../../core/providers/friend_split_provider.dart';
import '../../../core/providers/transaction_provider.dart'
    show transactionProvider, Transaction;

import '../../../core/providers/friends_provider.dart';
import '../../../core/providers/friend_upi_provider.dart';
import '../../../core/utils/friend_net.dart';
import '../../../core/providers/contacts_provider.dart';
import '../../../core/services/contacts_service.dart'
    show ContactsService, DeviceContact;
import '../../../core/services/friend_open_claims_service.dart';
import '../../../core/services/friend_credit_handler.dart';
import '../../../core/providers/user_state_provider.dart';
import '../../../core/providers/friend_reminder_provider.dart';
import '../../../models/account_model.dart';
import 'package:share_plus/share_plus.dart';
import 'add_friend_form.dart';

// ─────────────────────────────────────────────────────────────────────────────
// FRIENDS LIST SCREEN (Full Screen)
// ─────────────────────────────────────────────────────────────────────────────
class FriendsScreen extends ConsumerStatefulWidget {
  /// If [onSelect] is provided, the screen acts as a picker and returns the
  /// chosen friend name to the caller instead of navigating to detail.
  final ValueChanged<String>? onSelect;
  const FriendsScreen({super.key, this.onSelect});

  @override
  ConsumerState<FriendsScreen> createState() => _FriendsScreenState();
}

class _FriendsScreenState extends ConsumerState<FriendsScreen> {
  String _search = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (widget.onSelect == null && mounted) {
        ref.invalidate(deviceContactsProvider);
      }
    });
  }

  void _showAddFriendSheet() {
    AddFriendForm.show(context);
  }

  void _showEditFriendSheet(Friend friend) {
    AddFriendForm.show(
      context,
      initialName: friend.name,
      editingName: friend.name,
      initialPhone: friend.phone,
      initialUpi: friend.upiId,
      initialUpiIds: friend.upiIds,
      initialNotes: friend.notes,
      title: 'Edit Friend',
      saveLabel: 'Update Friend',
    );
  }

  Future<void> _confirmDeleteFriend(Friend friend) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder:
          (ctx) => AlertDialog(
            backgroundColor: SoftKit.card(ctx),
            surfaceTintColor: Colors.transparent,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(SoftKit.radius),
            ),
            titleTextStyle: SoftKit.text(
              ctx,
              20,
              FontWeight.w700,
              SoftKit.ink(ctx),
            ),
            contentTextStyle: SoftKit.text(
              ctx,
              14,
              FontWeight.w500,
              SoftKit.slate(ctx),
              height: 1.45,
            ),
            title: const Text('Delete Friend?'),
            content: Text(
              'Remove ${friend.name} from saved friends? Past outing and split history stays in Activity.',
            ),
            actionsPadding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
            actions: [
              Row(
                children: [
                  Expanded(
                    child: SoftKitButton.secondary(
                      label: 'Cancel',
                      height: 44,
                      onPressed: () => Navigator.pop(ctx, false),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: SoftKitButton(
                      label: 'Delete',
                      icon: LucideIcons.trash2,
                      height: 44,
                      onPressed: () => Navigator.pop(ctx, true),
                    ),
                  ),
                ],
              ),
            ],
          ),
    );
    if (confirmed != true || !mounted) return;
    ref.read(manualFriendsProvider.notifier).removeFriend(friend.name);
    ref.read(friendUpiProvider.notifier).removeFriend(friend.name);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${friend.name} deleted from saved friends'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _openFriend(Friend f) {
    if (widget.onSelect != null) {
      widget.onSelect!(f.name);
      Navigator.pop(context);
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => FriendDetailScreen(friendName: f.name),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final friends = ref.watch(friendsProvider);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isPicker = widget.onSelect != null;

    final q = _search.toLowerCase();
    final filteredFriends = sortFriendsForDisplay(
      friends.where((f) => f.name.toLowerCase().contains(q)).toList(),
    );

    final header = SoftKitHeader(
      title: isPicker ? 'Select Friend' : 'Friends',
      subtitle:
          isPicker
              ? 'Pick who this is with'
              : '${friends.length} ${friends.length == 1 ? 'friend' : 'friends'} · splits & balances',
      onBack:
          Navigator.of(context).canPop()
              ? () => Navigator.of(context).maybePop()
              : null,
      actions: [
        SoftKitCircleButton(
          icon: LucideIcons.userPlus,
          tooltip: 'Add friend',
          onPressed: _showAddFriendSheet,
        ),
      ],
    );
    return Scaffold(
      backgroundColor: SoftKit.canvas(context),
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            header,
            Expanded(child: _friendsBody(isPicker, isDark, filteredFriends)),
          ],
        ),
      ),
    );
  }

  Widget _friendsBody(
    bool isPicker,
    bool isDark,
    List<Friend> filteredFriends,
  ) {
    return isPicker
        ? Column(
          children: [
            FriendSearchField(
              hint: 'Search friends',
              isDark: isDark,
              onChanged: (v) => setState(() => _search = v),
            ),
            Expanded(child: _buildFriendsList(filteredFriends, isDark)),
          ],
        )
        : Column(
          children: [
            FriendSearchField(
              hint: 'Search friends & contacts',
              isDark: isDark,
              onChanged: (v) => setState(() => _search = v),
            ),
            Expanded(
              child: _ManageFriendsUnifiedList(
                search: _search,
                isDark: isDark,
                onOpenFriend: _openFriend,
                onEditFriend: _showEditFriendSheet,
                onDeleteFriend: _confirmDeleteFriend,
                onAddFromContact: (name, phone) {
                  // Dedup by phone number BEFORE showing the form — same
                  // number as an existing friend must not create a
                  // second entry.
                  final existing = ref
                      .read(manualFriendsProvider.notifier)
                      .friendWithPhone(phone);
                  if (existing != null) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          'This number is already saved as "${existing.name}".',
                        ),
                        behavior: SnackBarBehavior.floating,
                      ),
                    );
                    return;
                  }
                  // Confirm step: pre-filled form, user edits/confirms.
                  // Only these explicitly-saved fields ever leave the
                  // device — never the contact list itself.
                  AddFriendForm.show(
                    context,
                    initialName: name,
                    initialPhone: phone,
                  );
                },
              ),
            ),
          ],
        );
  }

  Widget _buildFriendsList(List<Friend> friends, bool isDark) {
    if (friends.isEmpty) {
      return Center(
        child: SoftKitEmptyState(
          icon: LucideIcons.users,
          title: _search.isEmpty ? 'No friends yet' : 'No matches',
          message:
              _search.isEmpty
                  ? 'Add a friend or pick one from your contacts.'
                  : 'No friends match your search.',
          action: SoftKitButton(
            label: 'Add Friend',
            icon: LucideIcons.userPlus,
            expand: false,
            onPressed: _showAddFriendSheet,
          ),
        ),
      );
    }

    final manual = friends.where((f) => f.isManual).toList();
    final other = friends.where((f) => !f.isManual).toList();
    final showSections =
        _search.isEmpty && manual.isNotEmpty && other.isNotEmpty;

    if (!showSections) {
      return ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: friends.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (context, i) {
          final f = friends[i];
          return FriendTile(
            friend: f,
            isDark: isDark,
            onTap: () => _openFriend(f),
            onEdit:
                widget.onSelect != null ? null : () => _showEditFriendSheet(f),
            onDelete:
                widget.onSelect != null ? null : () => _confirmDeleteFriend(f),
          );
        },
      );
    }

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _FriendsSectionHeader(title: 'ADDED FRIENDS', isDark: isDark),
        const SizedBox(height: 8),
        ...manual.map(
          (f) => Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: FriendTile(
              friend: f,
              isDark: isDark,
              onTap: () => _openFriend(f),
              onEdit: () => _showEditFriendSheet(f),
              onDelete: () => _confirmDeleteFriend(f),
            ),
          ),
        ),
        const SizedBox(height: 16),
        _FriendsSectionHeader(title: 'ALL FRIENDS', isDark: isDark),
        const SizedBox(height: 8),
        ...other.map(
          (f) => Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: FriendTile(
              friend: f,
              isDark: isDark,
              onTap: () => _openFriend(f),
              onEdit: () => _showEditFriendSheet(f),
              onDelete: () => _confirmDeleteFriend(f),
            ),
          ),
        ),
      ],
    );
  }
}

/// Single scroll: Added Friends → All Friends → Contacts (no tabs).
class _ManageFriendsUnifiedList extends ConsumerWidget {
  final String search;
  final bool isDark;
  final void Function(Friend f) onOpenFriend;
  final void Function(Friend f) onEditFriend;
  final void Function(Friend f) onDeleteFriend;
  final void Function(String name, String? phone) onAddFromContact;

  const _ManageFriendsUnifiedList({
    required this.search,
    required this.isDark,
    required this.onOpenFriend,
    required this.onEditFriend,
    required this.onDeleteFriend,
    required this.onAddFromContact,
  });

  bool _matches(String name, {String? phone}) {
    if (search.isEmpty) return true;
    final q = search.toLowerCase();
    if (name.toLowerCase().contains(q)) return true;
    if (phone != null && phone.contains(search)) return true;
    return false;
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final allFriends = ref.watch(friendsProvider);
    final contactsAsync = ref.watch(deviceContactsProvider);
    final savedNames =
        ref
            .watch(manualFriendsProvider)
            .map((f) => f.name.toLowerCase())
            .toSet();

    final addedFriends =
        allFriends
            .where((f) => f.isManual && _matches(f.name, phone: f.phone))
            .toList();
    final otherFriends =
        allFriends
            .where((f) => !f.isManual && _matches(f.name, phone: f.phone))
            .toList();

    return contactsAsync.when(
      loading:
          () => _buildScroll(
            ref: ref,
            isDark: isDark,
            addedFriends: addedFriends,
            otherFriends: otherFriends,
            contacts: const [],
            contactsLoading: true,
            savedNames: savedNames,
          ),
      error:
          (_, __) => _buildScroll(
            ref: ref,
            isDark: isDark,
            addedFriends: addedFriends,
            otherFriends: otherFriends,
            contacts: const [],
            savedNames: savedNames,
          ),
      data: (contacts) {
        final filteredContacts =
            contacts.where((c) {
              return _matches(c.displayName, phone: c.phone);
            }).toList();

        return _buildScroll(
          ref: ref,
          isDark: isDark,
          addedFriends: addedFriends,
          otherFriends: otherFriends,
          contacts: filteredContacts,
          savedNames: savedNames,
        );
      },
    );
  }

  Widget _buildScroll({
    required WidgetRef ref,
    required bool isDark,
    required List<Friend> addedFriends,
    required List<Friend> otherFriends,
    required List<DeviceContact> contacts,
    required Set<String> savedNames,
    bool contactsLoading = false,
  }) {
    final isEmpty =
        addedFriends.isEmpty &&
        otherFriends.isEmpty &&
        contacts.isEmpty &&
        !contactsLoading;

    if (isEmpty) {
      return Center(
        child: SoftKitEmptyState(
          icon: LucideIcons.users,
          title: search.isEmpty ? 'No friends yet' : 'No matches',
          message:
              search.isEmpty
                  ? 'Tap + to add a friend, or allow contacts below.'
                  : 'Nothing matches "$search".',
        ),
      );
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      children: [
        if (addedFriends.isNotEmpty) ...[
          _FriendsSectionHeader(title: 'ADDED FRIENDS', isDark: isDark),
          const SizedBox(height: 8),
          ...addedFriends.map(
            (f) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: FriendTile(
                friend: f,
                isDark: isDark,
                onTap: () => onOpenFriend(f),
                onEdit: () => onEditFriend(f),
                onDelete: () => onDeleteFriend(f),
              ),
            ),
          ),
          const SizedBox(height: 16),
        ],
        if (otherFriends.isNotEmpty) ...[
          _FriendsSectionHeader(title: 'ALL FRIENDS', isDark: isDark),
          const SizedBox(height: 8),
          ...otherFriends.map(
            (f) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: FriendTile(
                friend: f,
                isDark: isDark,
                onTap: () => onOpenFriend(f),
                onEdit: () => onEditFriend(f),
                onDelete: () => onDeleteFriend(f),
              ),
            ),
          ),
          const SizedBox(height: 16),
        ],
        _FriendsSectionHeader(title: 'CONTACTS', isDark: isDark),
        const SizedBox(height: 8),
        if (contactsLoading)
          const Padding(
            padding: EdgeInsets.all(24),
            child: Center(child: CircularProgressIndicator()),
          )
        else if (contacts.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: Column(
              children: [
                Text(
                  search.isEmpty
                      ? 'Allow contacts to see your phone book'
                      : 'No contacts match',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 13,
                    color: isDark ? SoftPalette.darkMuted : SoftPalette.muted,
                  ),
                ),
                if (search.isEmpty) ...[
                  const SizedBox(height: 12),
                  SoftKitButton.secondary(
                    label: 'Load Contacts',
                    icon: LucideIcons.contact,
                    expand: false,
                    height: 42,
                    onPressed: () async {
                      await ContactsService.requestPermission();
                      ref.invalidate(deviceContactsProvider);
                    },
                  ),
                ],
              ],
            ),
          )
        else
          ...contacts.map((c) {
            final saved = savedNames.contains(c.displayName.toLowerCase());
            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: _ContactListTile(
                contact: c,
                isDark: isDark,
                alreadySaved: saved,
                onAdd: () => onAddFromContact(c.displayName, c.phone),
                onTap:
                    saved
                        ? null
                        : () => onAddFromContact(c.displayName, c.phone),
              ),
            );
          }),
      ],
    );
  }
}

class _ContactListTile extends StatelessWidget {
  final DeviceContact contact;
  final bool isDark;
  final bool alreadySaved;
  final VoidCallback onAdd;
  final VoidCallback? onTap;

  const _ContactListTile({
    required this.contact,
    required this.isDark,
    required this.alreadySaved,
    required this.onAdd,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return SoftKitCard(
      onTap: onTap,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          SoftKitAvatar(name: contact.displayName, size: 40),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  contact.displayName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: SoftKit.text(
                    context,
                    15,
                    FontWeight.w700,
                    SoftKit.ink(context),
                  ),
                ),
                if (contact.phone != null)
                  Text(
                    contact.phone!,
                    style: SoftKit.text(
                      context,
                      12,
                      FontWeight.w500,
                      SoftKit.slate(context),
                    ),
                  ),
              ],
            ),
          ),
          if (alreadySaved)
            Text(
              'Added',
              style: SoftKit.text(
                context,
                12,
                FontWeight.w700,
                SoftKit.positive(context),
              ),
            )
          else
            SoftKitButton.secondary(
              label: 'Add',
              height: 34,
              expand: false,
              onPressed: onAdd,
            ),
        ],
      ),
    );
  }
}

class _FriendsSectionHeader extends StatelessWidget {
  final String title;
  final bool isDark;

  const _FriendsSectionHeader({required this.title, required this.isDark});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, top: 4),
      child: Text(
        title,
        style: SoftKit.text(
          context,
          11,
          FontWeight.w700,
          SoftKit.slate(context),
          letterSpacing: 1.1,
        ),
      ),
    );
  }
}

class FriendSearchField extends StatelessWidget {
  final String hint;
  final bool isDark;
  final ValueChanged<String> onChanged;

  const FriendSearchField({
    super.key,
    required this.hint,
    required this.isDark,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
      child: SoftKitSearchField(hint: hint, onChanged: onChanged),
    );
  }
}

class FriendTile extends StatelessWidget {
  final Friend friend;
  final bool isDark;
  final VoidCallback onTap;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;
  const FriendTile({
    super.key,
    required this.friend,
    required this.isDark,
    required this.onTap,
    this.onEdit,
    this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final pending = friend.totalPending;
    final returned = friend.totalReturned;
    final totalShare = friend.totalFriendShare;
    final hasExpenses = friend.expenses.isNotEmpty;
    final isCompleted = hasExpenses && pending == 0 && returned > 0;
    final isPartial = pending > 0 && returned > 0;
    final green = SoftKit.positive(context);
    final slate = SoftKit.slate(context);

    // Balance colours: green = friend owes you. This list only tracks what a
    // friend owes you; settled / no-expense friends show neutral text.
    String statusText;
    String? amountText;
    Color amountColor = slate;
    if (!hasExpenses) {
      statusText = 'No shared expenses yet';
    } else if (isCompleted) {
      statusText = 'Settled · paid ₹$totalShare';
      amountText = 'Settled';
    } else if (isPartial) {
      statusText = 'Owes you · paid ₹$returned of ₹$totalShare';
      amountText = '₹$pending';
      amountColor = green;
    } else if (pending > 0) {
      statusText = 'Owes you';
      amountText = '₹$pending';
      amountColor = green;
    } else {
      statusText = '${friend.expenses.length} shared expenses';
    }

    return SoftKitCard(
      onTap: onTap,
      padding: const EdgeInsets.fromLTRB(16, 12, 8, 12),
      child: Row(
        children: [
          SoftKitAvatar(
            name: friend.name.isNotEmpty ? friend.name : friend.avatar,
            size: 44,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  friend.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: SoftKit.text(
                    context,
                    15,
                    FontWeight.w700,
                    SoftKit.ink(context),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  statusText,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: SoftKit.text(context, 12, FontWeight.w500, slate),
                ),
              ],
            ),
          ),
          if (amountText != null) ...[
            const SizedBox(width: 8),
            Text(
              amountText,
              style: SoftKit.text(
                context,
                amountText == 'Settled' ? 12.5 : 15,
                FontWeight.w800,
                amountColor,
              ),
            ),
          ],
          if (onEdit != null || onDelete != null)
            PopupMenuButton<String>(
              tooltip: 'More',
              icon: Icon(LucideIcons.moreVertical, size: 18, color: slate),
              color: SoftKit.card(context),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              onSelected: (v) {
                if (v == 'edit') onEdit?.call();
                if (v == 'delete') onDelete?.call();
              },
              itemBuilder:
                  (_) => [
                    if (onEdit != null)
                      PopupMenuItem(
                        value: 'edit',
                        child: Text(
                          'Edit friend',
                          style: SoftKit.text(
                            context,
                            14,
                            FontWeight.w600,
                            SoftKit.ink(context),
                          ),
                        ),
                      ),
                    if (onDelete != null)
                      PopupMenuItem(
                        value: 'delete',
                        child: Text(
                          'Delete friend',
                          style: SoftKit.text(
                            context,
                            14,
                            FontWeight.w600,
                            SoftKit.negative(context),
                          ),
                        ),
                      ),
                  ],
            )
          else
            Padding(
              padding: const EdgeInsets.only(left: 4, right: 8),
              child: Icon(LucideIcons.chevronRight, size: 16, color: slate),
            ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// FRIEND DETAIL SCREEN
// ─────────────────────────────────────────────────────────────────────────────
enum _FriendExpenseSort { outingAsc, outingDesc, amountDesc, pendingFirst }

class FriendDetailScreen extends ConsumerStatefulWidget {
  final String friendName;
  const FriendDetailScreen({super.key, required this.friendName});

  @override
  ConsumerState<FriendDetailScreen> createState() => _FriendDetailScreenState();
}

class _FriendDetailScreenState extends ConsumerState<FriendDetailScreen> {
  String _outingSearch = '';
  _FriendExpenseSort _sort = _FriendExpenseSort.outingAsc;

  List<SharedExpense> _filteredExpenses(List<SharedExpense> expenses) {
    final q = _outingSearch.trim().toLowerCase();
    var list =
        q.isEmpty
            ? List<SharedExpense>.from(expenses)
            : expenses
                .where(
                  (e) =>
                      e.outingTitle.toLowerCase().contains(q) ||
                      e.expenseTitle.toLowerCase().contains(q),
                )
                .toList();

    switch (_sort) {
      case _FriendExpenseSort.outingAsc:
        list.sort(compareSharedExpenses);
        break;
      case _FriendExpenseSort.outingDesc:
        list.sort((a, b) => compareSharedExpenses(b, a));
        break;
      case _FriendExpenseSort.amountDesc:
        list.sort((a, b) => b.friendShare.compareTo(a.friendShare));
        break;
      case _FriendExpenseSort.pendingFirst:
        list.sort((a, b) {
          if (a.settled != b.settled) return a.settled ? 1 : -1;
          return compareSharedExpenses(a, b);
        });
        break;
    }
    return list;
  }

  Map<String, List<SharedExpense>> _groupByOuting(
    List<SharedExpense> expenses,
  ) {
    final map = <String, List<SharedExpense>>{};
    for (final e in expenses) {
      map.putIfAbsent(e.outingTitle, () => []).add(e);
    }
    return map;
  }

  void _showReturnAllSheet(BuildContext context, Friend friend) {
    PremiumBottomSheet.show(
      context: context,
      child: FriendReturnConfirmSheet(
        friendName: friend.name,
        // Null expense = settle everything this friend owes.
        expense: null,
        ref: ref,
      ),
    );
  }

  void _showEditFriendSheet(Friend friend) {
    AddFriendForm.show(
      context,
      initialName: friend.name,
      editingName: friend.name,
      initialPhone: friend.phone,
      initialUpi: friend.upiId,
      initialUpiIds: friend.upiIds,
      initialNotes: friend.notes,
      title: 'Edit Friend',
      saveLabel: 'Update Friend',
      onSaved: (saved) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${saved.name} updated'),
            behavior: SnackBarBehavior.floating,
          ),
        );
        // Renamed: this page is keyed by name, so reopen it under the new one.
        if (saved.name != friend.name) {
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(
              builder: (_) => FriendDetailScreen(friendName: saved.name),
            ),
          );
        }
      },
    );
  }

  Future<void> _confirmDeleteFriend(Friend friend) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder:
          (ctx) => AlertDialog(
            backgroundColor: SoftKit.card(ctx),
            surfaceTintColor: Colors.transparent,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(SoftKit.radius),
            ),
            titleTextStyle: SoftKit.text(
              ctx,
              20,
              FontWeight.w700,
              SoftKit.ink(ctx),
            ),
            contentTextStyle: SoftKit.text(
              ctx,
              14,
              FontWeight.w500,
              SoftKit.slate(ctx),
              height: 1.45,
            ),
            title: const Text('Delete Friend?'),
            content: Text(
              'Remove ${friend.name} from saved friends? Past outing and split history stays in Activity.',
            ),
            actionsPadding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
            actions: [
              Row(
                children: [
                  Expanded(
                    child: SoftKitButton.secondary(
                      label: 'Cancel',
                      height: 44,
                      onPressed: () => Navigator.pop(ctx, false),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: SoftKitButton(
                      label: 'Delete',
                      icon: LucideIcons.trash2,
                      height: 44,
                      onPressed: () => Navigator.pop(ctx, true),
                    ),
                  ),
                ],
              ),
            ],
          ),
    );
    if (confirmed != true || !mounted) return;
    final messenger = ScaffoldMessenger.of(context);
    ref.read(manualFriendsProvider.notifier).removeFriend(friend.name);
    ref.read(friendUpiProvider.notifier).removeFriend(friend.name);
    Navigator.pop(context);
    messenger.showSnackBar(
      SnackBar(
        content: Text('${friend.name} deleted from saved friends'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final friends = ref.watch(friendsProvider);
    final friend =
        friends.where((f) => f.name == widget.friendName).firstOrNull;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    if (friend == null) {
      return Scaffold(
        backgroundColor: SoftKit.canvas(context),
        body: SafeArea(
          child: Column(
            children: [
              SoftKitHeader(
                title: widget.friendName,
                onBack: () => Navigator.of(context).maybePop(),
              ),
              const Expanded(
                child: Center(
                  child: SoftKitEmptyState(
                    icon: LucideIcons.userX,
                    title: 'Friend not found',
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }

    final outings = ref.watch(outingProvider);
    final splits = ref.watch(friendSplitProvider);
    final nameKey = friend.name.toLowerCase();
    final paidByThem = expensesThisFriendPaid(
      friendName: friend.name,
      outings: outings,
      splits: splits,
    );
    final history = sortSharedExpensesByOuting([
      ...friend.expenses,
      ...paidByThem,
    ]);
    var theyOwe = 0.0;
    var youOwe = 0.0;
    for (final outing in outings) {
      for (final entry in outing.friendBalanceSummary().entries) {
        if (entry.key.toLowerCase() != nameKey) continue;
        theyOwe += entry.value.pendingToYou;
        youOwe += entry.value.youOwe;
      }
    }
    final balance = friendRunningBalance(
      outingTheyOwe: theyOwe,
      outingYouOwe: youOwe,
      splitSigned: friendSplitNetBalancesByName(splits)[nameKey] ?? 0,
    );
    final outingCount =
        outings
            .where((o) => o.members.any((m) => m.name.toLowerCase() == nameKey))
            .length;
    final splitCount =
        splits
            .where(
              (s) => s.members.any(
                (m) => !m.isCurrentUser && m.name.toLowerCase() == nameKey,
              ),
            )
            .length;
    final hasPending = friend.totalPending > 0;
    final filtered = _filteredExpenses(history);
    final grouped = _groupByOuting(filtered);
    final outingOrder =
        grouped.keys.toList()..sort(
          (a, b) =>
              _sort == _FriendExpenseSort.outingDesc
                  ? b.toLowerCase().compareTo(a.toLowerCase())
                  : a.toLowerCase().compareTo(b.toLowerCase()),
        );

    final ink = SoftKit.ink(context);
    final slate = SoftKit.slate(context);
    return Scaffold(
      backgroundColor: SoftKit.canvas(context),
      body: SafeArea(
        bottom: false,
        child: SingleChildScrollView(
          child: Column(
            children: [
              SoftKitHeader(
                title: friend.name,
                subtitle: '${history.length} shared expenses',
                onBack: () => Navigator.of(context).maybePop(),
                actions: [
                  SoftKitCircleButton(
                    tooltip: 'Edit friend',
                    onPressed: () => _showEditFriendSheet(friend),
                    icon: LucideIcons.pencil,
                  ),
                  SoftKitCircleButton(
                    tooltip: 'Delete friend',
                    onPressed: () => _confirmDeleteFriend(friend),
                    icon: LucideIcons.trash2,
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                child: SoftKitCard(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          SoftKitAvatar(name: friend.name, size: 48),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  friend.name,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: SoftKit.text(
                                    context,
                                    17,
                                    FontWeight.w800,
                                    ink,
                                  ),
                                ),
                                if (friend.phone != null &&
                                    friend.phone!.isNotEmpty)
                                  Text(
                                    friend.phone!,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: SoftKit.text(
                                      context,
                                      12,
                                      FontWeight.w500,
                                      slate,
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 18),
                      _FriendNetCard(
                        friendName: friend.name,
                        balance: balance,
                        outingCount: outingCount,
                        splitCount: splitCount,
                        isDark: isDark,
                      ),
                      const SizedBox(height: 16),
                      Divider(height: 1, color: SoftKit.divider(context)),
                      const SizedBox(height: 14),
                      IntrinsicHeight(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Expanded(
                              child: _SummaryStatCol(
                                label: 'Their Share',
                                amount: friend.totalFriendShare,
                                color: ink,
                                isDark: isDark,
                              ),
                            ),
                            Container(
                              width: 1,
                              margin: const EdgeInsets.symmetric(horizontal: 6),
                              color: SoftKit.divider(context),
                            ),
                            Expanded(
                              child: _SummaryStatCol(
                                label: 'Paid',
                                amount: friend.totalReturned,
                                color: SoftKit.positive(context),
                                isDark: isDark,
                              ),
                            ),
                            Container(
                              width: 1,
                              margin: const EdgeInsets.symmetric(horizontal: 6),
                              color: SoftKit.divider(context),
                            ),
                            Expanded(
                              child: _SummaryStatCol(
                                label: 'Pending',
                                amount: friend.youGetBack,
                                color:
                                    hasPending
                                        ? SoftKit.positive(context)
                                        : slate,
                                isDark: isDark,
                                bold: true,
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (hasPending) ...[
                        const SizedBox(height: 18),
                        SoftKitButton(
                          label: 'Settle',
                          icon: LucideIcons.checkCircle,
                          onPressed: () => _showReturnAllSheet(context, friend),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: _FriendUpiLinkSection(
                  friendName: friend.name,
                  isDark: isDark,
                  savedUpis: friend.upiIds,
                  isManual: friend.isManual,
                  phone: friend.phone,
                ),
              ),
              if (history.isNotEmpty) ...[
                const SizedBox(height: 12),
                Padding(
                  padding: EdgeInsets.zero,
                  child: FriendSearchField(
                    hint: 'Search by outing name',
                    isDark: isDark,
                    onChanged: (v) => setState(() => _outingSearch = v),
                  ),
                ),
                const SizedBox(height: 8),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    children: [
                      Icon(LucideIcons.arrowUpDown, size: 14, color: slate),
                      const SizedBox(width: 8),
                      Expanded(
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<_FriendExpenseSort>(
                            isExpanded: true,
                            value: _sort,
                            dropdownColor: SoftKit.card(context),
                            borderRadius: BorderRadius.circular(16),
                            style: SoftKit.text(
                              context,
                              13,
                              FontWeight.w600,
                              ink,
                            ),
                            items: const [
                              DropdownMenuItem(
                                value: _FriendExpenseSort.outingAsc,
                                child: Text('Outing name (A → Z)'),
                              ),
                              DropdownMenuItem(
                                value: _FriendExpenseSort.outingDesc,
                                child: Text('Outing name (Z → A)'),
                              ),
                              DropdownMenuItem(
                                value: _FriendExpenseSort.pendingFirst,
                                child: Text('Pending first'),
                              ),
                              DropdownMenuItem(
                                value: _FriendExpenseSort.amountDesc,
                                child: Text('Amount (high → low)'),
                              ),
                            ],
                            onChanged: (v) {
                              if (v != null) setState(() => _sort = v);
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: 12),
              // NOT wrapped in Expanded: this whole page lives inside the outer
              // SingleChildScrollView, which gives its Column unbounded height —
              // an Expanded here throws a RenderFlex layout exception on every
              // build, which is why the page rendered blank. The ListView.builder
              // below is shrinkWrap + NeverScrollableScrollPhysics precisely so it
              // can size itself to its content and scroll with the outer view.
              history.isEmpty
                  ? const Padding(
                    padding: EdgeInsets.symmetric(vertical: 24),
                    child: SoftKitEmptyState(
                      icon: LucideIcons.inbox,
                      title: 'No shared expenses yet',
                      message:
                          'Outing and split expenses with this friend show here.',
                    ),
                  )
                  : filtered.isEmpty
                  ? const Padding(
                    padding: EdgeInsets.symmetric(vertical: 24),
                    child: SoftKitEmptyState(
                      icon: LucideIcons.search,
                      title: 'No outings match your search',
                    ),
                  )
                  : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 32),
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: outingOrder.length,
                    itemBuilder: (context, sectionIndex) {
                      final outingTitle = outingOrder[sectionIndex];
                      final sectionItems = grouped[outingTitle]!;
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (sectionIndex > 0) const SizedBox(height: 8),
                          Padding(
                            padding: EdgeInsets.only(
                              top: sectionIndex == 0 ? 0 : 4,
                              bottom: 10,
                            ),
                            child: Padding(
                              padding: const EdgeInsets.only(left: 4),
                              child: Text(
                                (outingTitle == 'Friend Split'
                                        ? 'Mutual splits'
                                        : outingTitle)
                                    .toUpperCase(),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: SoftKit.text(
                                  context,
                                  11,
                                  FontWeight.w700,
                                  slate,
                                  letterSpacing: 1.1,
                                ),
                              ),
                            ),
                          ),
                          // Activity day-card style: one card per outing,
                          // rows separated by inset dividers, no borders.
                          SoftKitCard(
                            padding: EdgeInsets.zero,
                            child: Column(
                              children: [
                                for (
                                  var i = 0;
                                  i < sectionItems.length;
                                  i++
                                ) ...[
                                  if (i > 0)
                                    const SoftKitInsetDivider(
                                      indent: 16,
                                      endIndent: 16,
                                    ),
                                  _SharedExpenseTile(
                                    expense: sectionItems[i],
                                    isDark: isDark,
                                    friendName: friend.name,
                                  ),
                                ],
                              ],
                            ),
                          ),
                          const SizedBox(height: 12),
                        ],
                      );
                    },
                  ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FriendNetCard extends StatelessWidget {
  final String friendName;
  final FriendRunningBalance balance;
  final int outingCount;
  final int splitCount;
  final bool isDark;

  const _FriendNetCard({
    required this.friendName,
    required this.balance,
    required this.outingCount,
    required this.splitCount,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    final net = balance.net;
    final settled = net.abs() < 0.5;
    final theyOweYou = net > 0.5;
    final headline =
        settled
            ? 'All settled'
            : theyOweYou
            ? '$friendName owes you ₹${net.round()}'
            : 'You owe $friendName ₹${net.abs().round()}';
    final slate = SoftKit.slate(context);
    final color =
        settled
            ? SoftKit.ink(context)
            : theyOweYou
            ? SoftKit.positive(context)
            : SoftKit.negative(context);

    // Embedded inside the friend balance card (no own container/border).
    return SizedBox(
      width: double.infinity,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'RUNNING BALANCE',
            style: SoftKit.text(
              context,
              11,
              FontWeight.w700,
              slate,
              letterSpacing: 1.1,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            headline,
            style: SoftKit.text(
              context,
              22,
              FontWeight.w800,
              color,
              letterSpacing: -0.4,
            ),
          ),
          if (balance.theyOweYou > 0.5 && balance.youOweThem > 0.5) ...[
            const SizedBox(height: 4),
            Text(
              'They owe ₹${balance.theyOweYou.round()} · You owe ₹${balance.youOweThem.round()}',
              style: SoftKit.text(context, 12, FontWeight.w500, slate),
            ),
          ],
          const SizedBox(height: 4),
          Text(
            'Across $outingCount outing${outingCount == 1 ? '' : 's'} and $splitCount split${splitCount == 1 ? '' : 's'}.',
            style: SoftKit.text(context, 12, FontWeight.w500, slate),
          ),
        ],
      ),
    );
  }
}

class _FriendUpiLinkSection extends ConsumerStatefulWidget {
  final String friendName;
  final bool isDark;
  final List<String> savedUpis;
  final bool isManual;
  final String? phone;

  const _FriendUpiLinkSection({
    required this.friendName,
    required this.isDark,
    required this.savedUpis,
    required this.isManual,
    this.phone,
  });

  @override
  ConsumerState<_FriendUpiLinkSection> createState() =>
      _FriendUpiLinkSectionState();
}

class _FriendUpiLinkSectionState extends ConsumerState<_FriendUpiLinkSection> {
  final _upiCtrl = TextEditingController();

  @override
  void dispose() {
    _upiCtrl.dispose();
    super.dispose();
  }

  void _persistSaved(List<String> upis) {
    final manual = ref.read(manualFriendsProvider.notifier);
    if (widget.isManual) {
      manual.updateFriendFields(
        widget.friendName,
        upiId: upis.isEmpty ? '' : upis.first,
        upiIds: upis,
      );
      return;
    }
    manual.addFriend(
      widget.friendName,
      phone: widget.phone,
      upiId: upis.isEmpty ? null : upis.first,
      upiIds: upis,
    );
  }

  void _saveUpi() {
    final upi = _upiCtrl.text.trim();
    if (upi.isEmpty) return;
    final links = ref.read(friendUpiProvider.notifier);
    links.addUpi(widget.friendName, upi);
    final merged = ManualFriendsNotifier.normalizeUpiList(
      upiIds: [
        ...widget.savedUpis,
        upi,
        ...links.upisForFriend(widget.friendName),
      ],
    );
    _persistSaved(merged);
    _upiCtrl.clear();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('UPI saved — future credits will auto-settle'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final links = ref.watch(friendUpiProvider);
    final linked =
        links[FriendUpiNotifier.friendKey(widget.friendName)] ?? const [];
    final upis = ManualFriendsNotifier.normalizeUpiList(
      upiIds: [...widget.savedUpis, ...linked],
    );

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: widget.isDark ? SoftPalette.darkCard : SoftPalette.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color:
              widget.isDark
                  ? SoftPalette.darkBorder.withValues(alpha: 0.3)
                  : SoftPalette.border,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                LucideIcons.link,
                size: 16,
                color: SoftPalette.emerald,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'UPI IDs',
                  style: TextStyle(
                    fontWeight: FontWeight.w500,
                    fontSize: 13,
                    color: context.tokens.textPrimary,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            'Save ${widget.friendName}\'s UPI once. Credits like "${widget.friendName} sent" and your payments to them clear pending without Mark Paid.',
            style: TextStyle(
              fontSize: 11,
              height: 1.35,
              color: context.tokens.textSecondary,
            ),
          ),
          if (upis.isNotEmpty) ...[
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children:
                  upis
                      .map(
                        (u) => Chip(
                          label: Text(u, style: const TextStyle(fontSize: 11)),
                          deleteIcon: const Icon(LucideIcons.x, size: 14),
                          onDeleted: () {
                            ref
                                .read(friendUpiProvider.notifier)
                                .removeUpi(widget.friendName, u);
                            final next =
                                widget.savedUpis
                                    .where(
                                      (e) => e.toLowerCase() != u.toLowerCase(),
                                    )
                                    .toList();
                            if (widget.isManual) {
                              ref
                                  .read(manualFriendsProvider.notifier)
                                  .updateFriendFields(
                                    widget.friendName,
                                    upiId: next.isEmpty ? '' : next.first,
                                    upiIds: next,
                                  );
                            }
                          },
                          backgroundColor: SoftPalette.emerald.withValues(
                            alpha: 0.1,
                          ),
                        ),
                      )
                      .toList(),
            ),
          ],
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _upiCtrl,
                  decoration: InputDecoration(
                    hintText: 'e.g. karthi@ybl',
                    isDense: true,
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 10,
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onSubmitted: (_) => _saveUpi(),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(
                onPressed: _saveUpi,
                icon: const Icon(LucideIcons.plus, size: 18),
                style: IconButton.styleFrom(
                  backgroundColor: SoftPalette.emerald,
                  foregroundColor: SoftPalette.onEmerald,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ── Column stat for summary card ──
class _SummaryStatCol extends StatelessWidget {
  final String label;
  final num amount;
  final Color color;
  final bool isDark;
  final bool bold;
  const _SummaryStatCol({
    required this.label,
    required this.amount,
    required this.color,
    required this.isDark,
    this.bold = false,
  });

  @override
  Widget build(BuildContext context) {
    final labelStyle = TextStyle(
      fontSize: 11,
      fontWeight: FontWeight.w500,
      letterSpacing: 0.3,
      color: context.tokens.textSecondary,
    );
    final amountStyle = TextStyle(
      fontSize: bold ? 15 : 13,
      fontWeight: FontWeight.w500,
      color: color,
    );

    final displayAmount =
        amount % 1 == 0 ? amount.toInt().toString() : amount.toStringAsFixed(2);

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(
            label,
            maxLines: 2,
            textAlign: TextAlign.center,
            style: labelStyle,
          ),
        ),
        const SizedBox(height: 4),
        FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(
            '₹$displayAmount',
            maxLines: 1,
            textAlign: TextAlign.center,
            style: amountStyle,
          ),
        ),
      ],
    );
  }
}

// ── Redesigned expense tile with split chips ──
class _SharedExpenseTile extends ConsumerWidget {
  final SharedExpense expense;
  final bool isDark;
  final String friendName;
  const _SharedExpenseTile({
    required this.expense,
    required this.isDark,
    required this.friendName,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isSettled = expense.settled;
    final isPartial = expense.isPartial;
    final reminders = ref.watch(friendReminderProvider);
    final reminderSent =
        reminders['${friendName.trim().toLowerCase()}::${expense.id}'];

    // Flat row inside the outing card (Activity style): no border/fill.
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      expense.expenseTitle,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                        color:
                            isSettled
                                ? (context.tokens.textSecondary)
                                : (context.tokens.textPrimary),
                        decoration:
                            isSettled ? TextDecoration.lineThrough : null,
                        decorationColor: context.tokens.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Trip total: ₹${expense.totalAmount}',
                      style: TextStyle(
                        fontSize: 11,
                        color: context.tokens.textSecondary,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 4),
                    // ── Amount status line ──
                    if (expense.paidByFriend && isSettled)
                      Text(
                        'You paid ₹${expense.yourShare}',
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                          color: SoftPalette.positive,
                        ),
                      )
                    else if (expense.paidByFriend)
                      Text(
                        isPartial
                            ? 'Your share ₹${expense.yourShare} · Paid ₹${expense.friendSettled} · Left ₹${expense.friendPending}'
                            : 'You owe ₹${expense.yourShare}',
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                          color: SoftPalette.negative,
                        ),
                      )
                    else if (isSettled)
                      Row(
                        children: [
                          const Icon(
                            LucideIcons.checkCircle,
                            size: 13,
                            color: SoftPalette.positive,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            'Paid ₹${expense.friendShare}',
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                              color: SoftPalette.positive,
                            ),
                          ),
                        ],
                      )
                    else if (isPartial)
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Owes ₹${expense.friendShare} · Paid ₹${expense.friendSettled}',
                            style: const TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w500,
                              color: Colors.orange,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            'Remaining: ₹${expense.friendPending}',
                            style: const TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w500,
                              color: SoftPalette.negative,
                            ),
                          ),
                        ],
                      )
                    else
                      Text(
                        'Owes you ₹${expense.friendShare}',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: SoftKit.positive(context),
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              // ── Status badge ──
              if (isSettled)
                _StatusBadge(
                  label: 'Completed',
                  color: SoftPalette.positive,
                  icon: LucideIcons.checkCircle,
                )
              else if (isPartial)
                GestureDetector(
                  onTap: () => _showMarkAsPaid(context, ref),
                  child: _StatusBadge(
                    label: 'Pending',
                    color: Colors.orange,
                    icon: LucideIcons.circleDashed,
                    tappable: !expense.paidByFriend,
                  ),
                )
              else
                GestureDetector(
                  onTap: () => _showMarkAsPaid(context, ref),
                  child: _StatusBadge(
                    label: 'Pending',
                    color: SoftPalette.negative,
                    icon: LucideIcons.clock,
                    tappable: !expense.paidByFriend,
                  ),
                ),
            ],
          ),

          // ── Reminder sent indicator ──
          if (!isSettled && reminderSent != null) ...[
            const SizedBox(height: 6),
            Row(
              children: [
                const Icon(
                  LucideIcons.bell,
                  size: 11,
                  color: SoftPalette.emerald,
                ),
                const SizedBox(width: 4),
                Text(
                  'Reminder sent ${reminderTimeAgo(reminderSent)}',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w400,
                    color: context.tokens.textSecondary,
                  ),
                ),
              ],
            ),
          ],

          if (expense.payments.isNotEmpty) ...[
            const SizedBox(height: 10),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children:
                  expense.payments.map((p) {
                    final mode =
                        p.mode.toLowerCase() == 'cash' ? 'Cash' : p.mode;
                    return Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: SoftPalette.positive.withValues(alpha: 0.08),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        '$mode ₹${p.amount.toInt()}',
                        style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w500,
                          color: SoftPalette.positive,
                        ),
                      ),
                    );
                  }).toList(),
            ),
          ],

          const SizedBox(height: 14),

          Row(
            children: [
              Expanded(
                child: _SplitChip(
                  label: 'You',
                  amount: expense.yourShare,
                  color: context.tokens.textSecondary,
                  bgColor: context.tokens.field,
                  isDark: isDark,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _SplitChip(
                  label: _shortFriendLabel(friendName),
                  amount:
                      isPartial ? expense.friendPending : expense.friendShare,
                  color: isSettled ? SoftPalette.positive : SoftPalette.emerald,
                  bgColor: (isSettled
                          ? SoftPalette.positive
                          : SoftPalette.emerald)
                      .withValues(alpha: 0.08),
                  isDark: isDark,
                  highlighted: true,
                  subtitle: isPartial ? 'pending' : null,
                ),
              ),
            ],
          ),
          if (!isSettled && !expense.paidByFriend) ...[
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                // ── Send Reminder button ──
                GestureDetector(
                  onTap: () => _sendReminder(context, ref),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: SoftPalette.emerald.withValues(alpha: 0.08),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: SoftPalette.emerald.withValues(alpha: 0.2),
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          LucideIcons.bell,
                          size: 12,
                          color: SoftPalette.emerald,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          reminderSent != null ? 'Resend' : 'Send Reminder',
                          style: const TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                            color: SoftPalette.emerald,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                // ── Record payment button ──
                GestureDetector(
                  onTap: () => _showMarkAsPaid(context, ref),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: SoftPalette.positive.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: SoftPalette.positive.withValues(alpha: 0.3),
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          LucideIcons.checkCircle,
                          size: 12,
                          color: SoftPalette.positive,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          isPartial ? 'Add payment' : 'Record payment',
                          style: const TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                            color: SoftPalette.positive,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  static String _shortFriendLabel(String name) {
    final trimmed = name.trim();
    if (trimmed.length <= 10) return trimmed;
    return '${trimmed.substring(0, 9)}…';
  }

  void _sendReminder(BuildContext context, WidgetRef ref) {
    final pending =
        expense.isPartial ? expense.friendPending : expense.friendShare;
    final text =
        'Hi $friendName, you owe ₹$pending for '
        '"${expense.expenseTitle}" from ${expense.outingTitle}. '
        'Please settle when you can!';
    SharePlus.instance.share(ShareParams(text: text));
    ref
        .read(friendReminderProvider.notifier)
        .markReminderSent(friendName, expense.id);
  }

  void _showMarkAsPaid(BuildContext context, WidgetRef ref) {
    if (expense.paidByFriend) return;
    PremiumBottomSheet.show(
      context: context,
      child: FriendReturnConfirmSheet(
        friendName: friendName,
        expense: expense,
        ref: ref,
      ),
    );
  }
}

// ── Split amount chip ──
class _SplitChip extends StatelessWidget {
  final String label;
  final num amount;
  final Color color;
  final Color bgColor;
  final bool isDark;
  final bool highlighted;
  final String? subtitle;
  const _SplitChip({
    required this.label,
    required this.amount,
    required this.color,
    required this.bgColor,
    required this.isDark,
    this.highlighted = false,
    this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    final displayAmount =
        amount % 1 == 0 ? amount.toInt().toString() : amount.toStringAsFixed(2);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(12),
        border:
            highlighted
                ? Border.all(color: color.withValues(alpha: 0.3))
                : null,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                    color: color,
                  ),
                ),
              ),
              Text(
                '₹$displayAmount',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  color: color,
                ),
              ),
            ],
          ),
          if (subtitle != null)
            Text(
              subtitle!,
              style: TextStyle(
                fontSize: 11,
                color: color.withValues(alpha: 0.8),
              ),
            ),
        ],
      ),
    );
  }
}

// ── Status badge ──
class _StatusBadge extends StatelessWidget {
  final String label;
  final Color color;
  final IconData icon;
  final bool tappable;
  const _StatusBadge({
    required this.label,
    required this.color,
    required this.icon,
    this.tappable = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withValues(alpha: 0.25)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 11, color: color),
          const SizedBox(width: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w500,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// PER-EXPENSE RETURN CONFIRMATION SHEET
// ─────────────────────────────────────────────────────────────────────────────
/// Records money a friend has paid back — either against one shared expense,
/// or against everything they owe.
///
/// One sheet covers both so the two paths can't drift apart. The old
/// "Mark All Paid" sheet settled without writing a transaction or crediting an
/// account, so the same user action produced two different financial outcomes
/// depending on which button was pressed.
class FriendReturnConfirmSheet extends StatefulWidget {
  final String friendName;

  /// The single expense being settled, or null to settle everything this
  /// friend owes across outings *and* Friend Splits.
  final SharedExpense? expense;
  final WidgetRef ref;
  const FriendReturnConfirmSheet({
    super.key,
    required this.friendName,
    required this.expense,
    required this.ref,
  });

  bool get isSettleAll => expense == null;

  @override
  State<FriendReturnConfirmSheet> createState() =>
      _FriendReturnConfirmSheetState();
}

class _FriendReturnConfirmSheetState extends State<FriendReturnConfirmSheet> {
  bool _done = false;
  AccountModel? _selectedAccount;

  /// false = pay the whole outstanding, true = type an amount.
  bool _isCustom = false;
  late final TextEditingController _amountCtrl;
  double _lastRecorded = 0;

  /// Settle-all only: every claim this friend still owes, across both stores.
  List<FriendOpenClaim> _claims = const [];

  /// Remembers the account the last repayment landed in — most people receive
  /// into the same one every time, so this usually makes the sheet one tap.
  static String? _lastAccountName;

  @override
  void initState() {
    super.initState();
    if (widget.isSettleAll) {
      _claims = FriendOpenClaimsService.claimsForFriend(
        widget.ref,
        widget.friendName,
      );
    }
    _amountCtrl = TextEditingController(text: _pending.toStringAsFixed(0));
  }

  @override
  void dispose() {
    _amountCtrl.dispose();
    super.dispose();
  }

  double get _pending =>
      widget.isSettleAll
          ? FriendClaimMath.totalOutstanding(_claims)
          : widget.expense!.friendPending.toDouble();

  /// What will actually be recorded — the full outstanding unless the user
  /// switched to Custom.
  double get _enteredAmount =>
      _isCustom ? (double.tryParse(_amountCtrl.text.trim()) ?? 0) : _pending;

  /// Settlement mode label. Derived from the chosen account rather than asked
  /// for separately: the old sheet had its own Cash/Online/UPI selector that
  /// changed nothing except the confirmation text.
  String get _creditModeLabel {
    final account = _selectedAccount;
    if (account == null) return 'Account';
    return account.type.toLowerCase() == 'cash' ? 'Cash' : account.name;
  }

  String get _transactionPaymentType {
    final account = _selectedAccount;
    if (account == null) return 'Online';
    return account.type.toLowerCase() == 'cash' ? 'Cash' : 'Online';
  }

  void _settleSingle(SharedExpense expense, double amount) {
    if (expense.isFriendSplit) {
      final split =
          widget.ref
              .read(friendSplitProvider)
              .where((s) => s.id == expense.splitId)
              .firstOrNull;
      // Split removed by a sync while this sheet was open.
      if (split == null) return;
      widget.ref
          .read(friendSplitProvider.notifier)
          .recordSettlement(
            split,
            fromMemberId: expense.memberId,
            toMemberId: split.paidByMemberId,
            amount: amount,
          );
    } else {
      widget.ref
          .read(outingProvider.notifier)
          .recordMemberSettlement(
            expense.outingId,
            expense.id,
            expense.memberId,
            amount: amount,
            mode: _creditModeLabel,
          );
    }
  }

  /// Spreads [amount] over the friend's open claims, oldest first, and writes
  /// a settlement against each. Unlike the old "Mark All Paid", this clears
  /// the balance for real, covers Friend Splits, and never over-settles.
  void _settleAll(double amount) {
    final allocation = FriendClaimMath.allocate(_claims, amount);
    FriendOpenClaimsService.applySettlements(
      widget.ref,
      claims: _claims,
      allocation: allocation,
      mode: _creditModeLabel,
    );
  }

  void _recordPayment() {
    final account = _selectedAccount;
    if (account == null) return;

    final amount = _enteredAmount;
    if (amount <= 0) return;
    if (amount > _pending + 0.01) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Max remaining is ₹${_pending.toInt()}')),
      );
      return;
    }

    final expense = widget.expense;
    if (expense != null) {
      _settleSingle(expense, amount);
      if (amount >= _pending - 0.01) {
        widget.ref
            .read(friendReminderProvider.notifier)
            .clearReminder(widget.friendName, expense.id);
      }
    } else {
      _settleAll(amount);
      if (amount >= _pending - 0.01) {
        widget.ref
            .read(friendReminderProvider.notifier)
            .clearAllForFriend(widget.friendName);
      }
    }

    _lastAccountName = account.name;

    final tx = Transaction(
      merchant: 'From ${widget.friendName}',
      // Shown as a normal income transaction — no special Settlements
      // badge, counted in Income like any other credit, but under its own
      // category so it can still be called out separately in summaries.
      category: FriendCreditHandler.repaymentCategory,
      account: account.name,
      time: DateFormat('hh:mm a').format(DateTime.now()),
      amount: amount,
      isExpense: false,
      paymentType: _transactionPaymentType,
      date: DateTime.now(),
      // Settle-all can span several outings, so it belongs to none of them.
      outingId:
          (expense == null || expense.isFriendSplit) ? null : expense.outingId,
      purpose: expense?.purpose ?? '',
      note: '',
    );
    widget.ref.read(transactionProvider.notifier).addTransaction(tx);

    setState(() {
      _lastRecorded = amount;
      _done = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final rawAccounts = widget.ref.watch(userStateProvider).accounts;
    // Bank/wallet/credit before Cash, same order as the Add Expense form.
    final accounts = [...rawAccounts]..sort((a, b) {
      final aCash = a.type.toLowerCase() == 'cash' ? 1 : 0;
      final bCash = b.type.toLowerCase() == 'cash' ? 1 : 0;
      return aCash - bCash;
    });
    _selectedAccount ??=
        accounts.where((a) => a.name == _lastAccountName).firstOrNull ??
        accounts.where((a) => a.isDefault).firstOrNull ??
        (accounts.isNotEmpty ? accounts.first : null);
    final exp = widget.expense;

    return Padding(
      padding: const EdgeInsets.all(24),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (!_done) ...[
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  color: SoftPalette.positive.withValues(alpha: 0.1),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  LucideIcons.indianRupee,
                  size: 28,
                  color: SoftPalette.positive,
                ),
              ),
              const SizedBox(height: 20),
              Text(
                widget.isSettleAll ? 'Settle all' : 'Record payment',
                style: const TextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: 20,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                widget.isSettleAll
                    ? 'Clears oldest bills first, across trips and splits'
                    : 'Split repayments — e.g. ₹500 online + ₹500 cash',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 12,
                  color: context.tokens.textSecondary,
                ),
              ),
              const SizedBox(height: 20),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: context.tokens.field,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Column(
                  children: [
                    _DetailRow(
                      label: 'Friend',
                      value: widget.friendName,
                      isDark: isDark,
                    ),
                    const SizedBox(height: 8),
                    if (exp == null) ...[
                      if (_claims.isEmpty)
                        _DetailRow(
                          label: 'Pending bills',
                          // Only bills *you* paid count as money owed to you,
                          // so this can be empty even when the friend list
                          // above still shows shared expenses.
                          value: 'None you paid for',
                          isDark: isDark,
                        )
                      else ...[
                        _DetailRow(
                          label: 'Pending bills',
                          value: '${_claims.length}',
                          isDark: isDark,
                        ),
                        const SizedBox(height: 8),
                        for (final claim in _claims) ...[
                          _DetailRow(
                            label: claim.referenceName,
                            value: '₹${claim.outstanding.toInt()}',
                            isDark: isDark,
                          ),
                          const SizedBox(height: 8),
                        ],
                      ],
                    ] else ...[
                      _DetailRow(
                        label: exp.isFriendSplit ? 'Split' : 'Outing',
                        value: exp.outingTitle,
                        isDark: isDark,
                      ),
                      const SizedBox(height: 8),
                      _DetailRow(
                        label: 'Expense',
                        value: exp.expenseTitle,
                        isDark: isDark,
                      ),
                      const SizedBox(height: 8),
                      _DetailRow(
                        label: 'Their share',
                        value: '₹${exp.friendShare}',
                        isDark: isDark,
                      ),
                      const SizedBox(height: 8),
                      _DetailRow(
                        label: 'Already received',
                        value: '₹${exp.friendSettled}',
                        isDark: isDark,
                        valueColor: SoftPalette.positive,
                      ),
                      const SizedBox(height: 8),
                    ],
                    _DetailRow(
                      label: 'Still pending',
                      value: '₹${_pending.toInt()}',
                      isDark: isDark,
                      valueColor: SoftPalette.negative,
                      bold: true,
                    ),
                  ],
                ),
              ),
              if (exp != null && exp.payments.isNotEmpty) ...[
                const SizedBox(height: 16),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'PREVIOUS PAYMENTS',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      letterSpacing: 1,
                      color: context.tokens.textSecondary,
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                ...exp.payments.map(
                  (p) => Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          '${p.mode} · ${DateFormat('MMM dd').format(p.date)}',
                        ),
                        Text(
                          '₹${p.amount.toInt()}',
                          style: const TextStyle(
                            fontWeight: FontWeight.w500,
                            color: SoftPalette.positive,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
              const SizedBox(height: 20),
              const _SectionLabel('HOW MUCH'),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: _ChoiceChipBox(
                      label: 'Full  ₹${_pending.toInt()}',
                      selected: !_isCustom,
                      isDark: isDark,
                      onTap: () => setState(() => _isCustom = false),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _ChoiceChipBox(
                      label: 'Custom',
                      selected: _isCustom,
                      isDark: isDark,
                      onTap:
                          () => setState(() {
                            _isCustom = true;
                            _amountCtrl.text = _pending.toStringAsFixed(0);
                          }),
                    ),
                  ),
                ],
              ),
              if (_isCustom) ...[
                const SizedBox(height: 12),
                TextField(
                  controller: _amountCtrl,
                  keyboardType: TextInputType.number,
                  autofocus: true,
                  onChanged: (_) => setState(() {}),
                  decoration: InputDecoration(
                    labelText: 'Amount received',
                    prefixText: '₹ ',
                    helperText: 'Max ₹${_pending.toInt()}',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ],
              const SizedBox(height: 20),
              const _SectionLabel('CREDIT TO ACCOUNT'),
              const SizedBox(height: 12),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                child: Row(
                  children:
                      accounts.map((acc) {
                        final isSelected = _selectedAccount?.name == acc.name;
                        return Padding(
                          padding: const EdgeInsets.only(right: 12),
                          child: GestureDetector(
                            onTap: () => setState(() => _selectedAccount = acc),
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 200),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 12,
                              ),
                              decoration: BoxDecoration(
                                color:
                                    isSelected
                                        ? SoftPalette.emerald
                                        : (isDark
                                            ? Colors.white.withValues(
                                              alpha: 0.03,
                                            )
                                            : Colors.black.withValues(
                                              alpha: 0.02,
                                            )),
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(
                                  color:
                                      isSelected
                                          ? SoftPalette.emerald
                                          : (isDark
                                              ? Colors.white10
                                              : Colors.black12),
                                ),
                              ),
                              child: Row(
                                children: [
                                  Icon(
                                    LucideIcons.wallet,
                                    size: 14,
                                    color:
                                        isSelected ? Colors.white : Colors.grey,
                                  ),
                                  const SizedBox(width: 8),
                                  Text(
                                    acc.name,
                                    style: TextStyle(
                                      fontWeight: FontWeight.w500,
                                      fontSize: 13,
                                      color:
                                          isSelected
                                              ? Colors.white
                                              : (isDark
                                                  ? Colors.white70
                                                  : Colors.black87),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                ),
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  icon: const Icon(LucideIcons.plus, size: 17),
                  label: Text(
                    _pending > 0
                        ? 'Record ₹${_enteredAmount.toInt()}'
                        : 'Fully settled',
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: SoftColors.control,
                  ),
                  onPressed:
                      _pending > 0 && _enteredAmount > 0
                          ? _recordPayment
                          : null,
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text(
                    'Cancel',
                    style: TextStyle(color: context.tokens.textSecondary),
                  ),
                ),
              ),
            ] else ...[
              Container(
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  color: SoftPalette.positive.withValues(alpha: 0.15),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  LucideIcons.checkCircle,
                  size: 36,
                  color: SoftPalette.positive,
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'Recorded!',
                style: TextStyle(fontWeight: FontWeight.w500, fontSize: 20),
              ),
              const SizedBox(height: 8),
              Text(
                exp == null
                    ? '₹${_lastRecorded.toInt()} from ${widget.friendName} recorded to ${_selectedAccount?.name ?? 'your account'}'
                    : '₹${_lastRecorded.toInt()} recorded for "${exp.expenseTitle}" to ${_selectedAccount?.name ?? 'your account'}',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 13,
                  color: context.tokens.textSecondary,
                ),
              ),
              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Done'),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// DETAIL ROW HELPER
// ─────────────────────────────────────────────────────────────────────────────
class _DetailRow extends StatelessWidget {
  final String label;
  final String value;
  final bool isDark;
  final Color? valueColor;
  final bool bold;
  const _DetailRow({
    required this.label,
    required this.value,
    required this.isDark,
    this.valueColor,
    this.bold = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(fontSize: 12, color: context.tokens.textSecondary),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              value,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.end,
              style: TextStyle(
                fontSize: 13,
                fontWeight: bold ? FontWeight.w500 : FontWeight.w500,
                color: valueColor ?? (context.tokens.textPrimary),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Full / Custom selector box — same visual language as the account chips
/// below it, so the two rows of the sheet read as one control.
class _ChoiceChipBox extends StatelessWidget {
  final String label;
  final bool selected;
  final bool isDark;
  final VoidCallback onTap;

  const _ChoiceChipBox({
    required this.label,
    required this.selected,
    required this.isDark,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: selected ? SoftPalette.positive : context.tokens.field,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: selected ? SoftPalette.positive : Colors.transparent,
          ),
        ),
        child: Text(
          label,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color:
                selected
                    ? Colors.white
                    : (isDark ? Colors.white70 : Colors.black87),
          ),
        ),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);
  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(
        fontSize: 11,
        fontWeight: FontWeight.w500,
        color: Colors.grey,
        letterSpacing: 1.2,
      ),
    );
  }
}
