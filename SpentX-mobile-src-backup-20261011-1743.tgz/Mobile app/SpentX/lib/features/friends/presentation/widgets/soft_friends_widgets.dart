import 'package:flutter/material.dart';

import '../../../../core/theme/soft_palette.dart';
import '../../../../core/widgets/reference_ui.dart';

class SoftFriendsCard extends StatelessWidget {
  const SoftFriendsCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.onTap,
    this.color,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final card = SxSoftCard(padding: padding, color: color, child: child);
    if (onTap == null) return card;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: const BorderRadius.all(Radius.circular(18)),
        child: card,
      ),
    );
  }
}

class SoftFriendsAvatar extends StatelessWidget {
  const SoftFriendsAvatar({
    super.key,
    required this.initial,
    this.size = 44,
  });

  final String initial;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: SoftPalette.emeraldSoft,
        shape: BoxShape.circle,
        border: Border.all(color: SoftPalette.mint.withValues(alpha: 0.35)),
      ),
      child: Text(
        initial.toUpperCase(),
        style: TextStyle(
          color: SoftPalette.emerald,
          fontWeight: FontWeight.w800,
          fontSize: size * 0.36,
        ),
      ),
    );
  }
}
