import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:uuid/uuid.dart';
import '../../../core/services/auth_service.dart';
import '../../../core/sync/supabase_schema_map.dart' show SyncIds;
import '../../../core/sync/sync_queue.dart';
import '../../../core/sync/sync_service.dart';
import '../../../core/providers/outing_provider.dart';
import 'friend_split_provider.dart';
import '../../../models/friend_split.dart';

class SharedExpense {
  final String id;

  /// Real outing id — empty for Friend Splits. This used to carry a
  /// `friend-split:<id>` sentinel that settle-up UI parsed back out with
  /// substring maths; the source is an explicit field now ([isFriendSplit] /
  /// [splitId]) so nothing has to decode an id to know what it is.
  final String outingId;
  final String memberId;
  final String outingTitle;
  final String expenseTitle;
  final String purpose;
  final double totalAmount;
  final double yourShare;
  final double friendShare;
  final double friendSettled;
  final double friendPending;
  final List<SettlementPayment> payments;

  /// True when this row is a Friend Split rather than an outing expense.
  /// The two settle through different notifiers.
  final bool isFriendSplit;

  /// Friend Split id — empty for outing expenses.
  final String splitId;

  /// This friend paid the bill. [friendPending] is what you still owe them.
  /// The friends list does not include these rows, so "owes you" stays unchanged.
  final bool paidByFriend;

  bool settled;

  bool get isPartial => friendSettled > 0 && friendPending > 0;

  /// Full label (outing + expense) — prefer [outingTitle] / [expenseTitle] in UI.
  String get name => '$outingTitle · $expenseTitle';

  SharedExpense({
    required this.id,
    required this.outingId,
    required this.memberId,
    required this.outingTitle,
    required this.expenseTitle,
    required this.purpose,
    required this.totalAmount,
    required this.yourShare,
    required this.friendShare,
    required this.friendSettled,
    required this.friendPending,
    this.payments = const [],
    this.isFriendSplit = false,
    this.splitId = '',
    this.paidByFriend = false,
    this.settled = false,
  });
}

int compareSharedExpenses(SharedExpense a, SharedExpense b) {
  final byOuting = a.outingTitle.toLowerCase().compareTo(
    b.outingTitle.toLowerCase(),
  );
  if (byOuting != 0) return byOuting;
  return a.expenseTitle.toLowerCase().compareTo(b.expenseTitle.toLowerCase());
}

List<SharedExpense> sortSharedExpensesByOuting(List<SharedExpense> expenses) {
  return List<SharedExpense>.from(expenses)..sort(compareSharedExpenses);
}

/// Bills this friend paid that include you. Kept off [friendsProvider] so the
/// list total still means only what they owe you.
List<SharedExpense> expensesThisFriendPaid({
  required String friendName,
  required List<Outing> outings,
  required List<FriendSplit> splits,
}) {
  final key = friendName.trim().toLowerCase();
  if (key.isEmpty || key == 'you') return const [];
  final rows = <SharedExpense>[];

  for (final outing in outings) {
    final member =
        outing.members.where((m) => m.name.toLowerCase() == key).firstOrNull;
    if (member == null) continue;
    final youId = outing.youMemberId;
    for (final expense in outing.expenses) {
      if (!expense.memberIds.contains(member.id)) continue;
      if (expense.isPaidByYou(youId)) continue;
      final payer =
          youId != null
              ? expense.effectivePaidBy(youId)
              : expense.paidByMemberId;
      if (payer != member.id) continue;
      if (!outingExpenseIncludesYou(expense.memberIds, youId)) continue;
      final youKey = outingYourMemberKey(expense.memberIds, youId);
      final yourShare = expense.shareForMember(youKey);
      final settled = expense.settledAmountForMember(youKey);
      final pending = expense.pendingAmountForMember(youKey);
      rows.add(
        SharedExpense(
          id: expense.id,
          outingId: outing.id,
          memberId: member.id,
          outingTitle: outing.title,
          expenseTitle: expense.title,
          purpose: expense.purpose,
          totalAmount: expense.amount,
          yourShare: yourShare,
          friendShare: yourShare,
          friendSettled: settled,
          friendPending: pending,
          payments: expense.paymentsForMember(youKey),
          paidByFriend: true,
          settled: pending < 0.01,
        ),
      );
    }
  }

  for (final split in splits) {
    final youId = split.youMemberId;
    if (youId == null || split.paidByMemberId == youId) continue;
    final friendMember =
        split.members
            .where(
              (m) =>
                  !m.isCurrentUser &&
                  m.name.toLowerCase() != 'you' &&
                  m.name.toLowerCase() == key,
            )
            .firstOrNull;
    if (friendMember == null || split.paidByMemberId != friendMember.id) {
      continue;
    }
    final yourShare = split.shareForMember(youId);
    final settled = split.settledAmountForMember(youId);
    final pending = split.pendingAmountForMember(youId);
    rows.add(
      SharedExpense(
        id: split.id,
        outingId: '',
        isFriendSplit: true,
        splitId: split.id,
        memberId: friendMember.id,
        outingTitle: 'Friend Split',
        expenseTitle: split.description,
        purpose: '',
        totalAmount: split.amount,
        yourShare: yourShare,
        friendShare: yourShare,
        friendSettled: settled,
        friendPending: pending,
        payments:
            split.settlements
                .where((s) => s.fromMemberId == youId)
                .map(
                  (s) => SettlementPayment(
                    amount: s.amount,
                    mode: 'Online',
                    date: s.date,
                  ),
                )
                .toList(),
        paidByFriend: true,
        settled: pending < 0.01,
      ),
    );
  }

  return rows;
}

class Friend {
  /// Server row id (friends.id) once known. Lets edits/renames update the
  /// same remote row instead of creating a new one.
  final String? id;
  final String name;
  final String? phone;
  final String? email;
  final String? upiId;
  final List<String> upiIds;
  final String? notes;
  final String avatar;
  final List<SharedExpense> expenses;
  final bool isManual;

  Friend({
    this.id,
    required this.name,
    this.phone,
    this.email,
    this.upiId,
    this.upiIds = const [],
    this.notes,
    required this.avatar,
    required this.expenses,
    this.isManual = false,
  });

  double get totalPending => expenses.fold(0.0, (s, e) => s + e.friendPending);
  double get totalYouPaid => expenses.fold(0.0, (s, e) => s + e.totalAmount);
  double get totalReturned => expenses.fold(0.0, (s, e) => s + e.friendSettled);
  double get totalFriendShare =>
      expenses.fold(0.0, (s, e) => s + e.friendShare);
  double get youGetBack => totalPending;
}

final manualFriendsProvider =
    StateNotifierProvider<ManualFriendsNotifier, List<Friend>>((ref) {
      return ManualFriendsNotifier();
    });

class ManualFriendsNotifier extends StateNotifier<List<Friend>> {
  Box get _box => Hive.box('friends');

  ManualFriendsNotifier() : super([]) {
    _load();
  }

  void reloadFromStorage() => _load();

  void _load() {
    final list = _box.get('list', defaultValue: []);
    if (list is List) {
      state =
          list
              .map((e) {
                final map = Map<dynamic, dynamic>.from(e as Map);
                final name = (map['name'] ?? '').toString().trim();
                if (name.isEmpty) return null;
                final rawUpiIds = <String>[];
                if (map['upiIds'] is List) {
                  rawUpiIds.addAll(
                    (map['upiIds'] as List)
                        .map((e) => e.toString().trim())
                        .where((e) => e.isNotEmpty),
                  );
                }
                final upiId =
                    map['upiId']?.toString() ?? map['upi']?.toString();
                final upiIds = normalizeUpiList(
                  upiId: upiId,
                  upiIds: rawUpiIds,
                );
                final id = map['id']?.toString().trim();
                return Friend(
                  id: id == null || id.isEmpty ? null : id,
                  name: name,
                  phone: map['phone']?.toString(),
                  email: map['email']?.toString(),
                  upiId: upiIds.isNotEmpty ? upiIds.first : null,
                  upiIds: upiIds,
                  notes: map['notes']?.toString(),
                  avatar: name[0].toUpperCase(),
                  expenses: const [],
                  isManual: true,
                );
              })
              .whereType<Friend>()
              .toList();
    }
  }

  void _persist() {
    _box.put(
      'list',
      state
          .map(
            (e) => {
              if (e.id != null && e.id!.isNotEmpty) 'id': e.id,
              'name': e.name,
              if (e.phone != null && e.phone!.isNotEmpty) 'phone': e.phone,
              if (e.email != null && e.email!.isNotEmpty) 'email': e.email,
              if (e.upiId != null && e.upiId!.isNotEmpty) 'upiId': e.upiId,
              if (e.upiIds.isNotEmpty) 'upiIds': e.upiIds,
              if (e.notes != null && e.notes!.isNotEmpty) 'notes': e.notes,
            },
          )
          .toList(),
    );
  }

  static String normalizePhone(String? phone) =>
      (phone ?? '').replaceAll(RegExp(r'[^0-9]'), '');

  /// Existing friend with the same phone number (dedup for contact imports).
  Friend? friendWithPhone(String? phone) {
    final digits = normalizePhone(phone);
    if (digits.length < 7) return null;
    for (final f in state) {
      final fd = normalizePhone(f.phone);
      if (fd.isNotEmpty &&
          (fd == digits || fd.endsWith(digits) || digits.endsWith(fd))) {
        return f;
      }
    }
    return null;
  }

  /// Unique UPI list; first becomes primary [upiId].
  static List<String> normalizeUpiList({String? upiId, List<String>? upiIds}) {
    final seen = <String>{};
    final out = <String>[];
    void push(String? raw) {
      final v = (raw ?? '').trim();
      if (v.isEmpty) return;
      final key = v.toLowerCase();
      if (seen.contains(key)) return;
      seen.add(key);
      out.add(v);
    }

    push(upiId);
    for (final u in upiIds ?? const <String>[]) {
      push(u);
    }
    return out;
  }

  void addFriend(
    String name, {
    String? phone,
    String? email,
    String? upiId,
    List<String>? upiIds,
    String? notes,
  }) {
    final trimmed = name.trim();
    if (trimmed.isEmpty || trimmed.toLowerCase() == 'you') return;
    if (state.any((f) => f.name.toLowerCase() == trimmed.toLowerCase())) return;
    // Phone-number dedup: same number as an existing friend → don't create a
    // second entry (callers surface this via friendWithPhone first).
    if (friendWithPhone(phone) != null) return;

    final normalizedPhone = phone?.trim();
    final upis = normalizeUpiList(upiId: upiId, upiIds: upiIds);
    // A renamed friend keeps the id derived from its OLD name. A new friend
    // re-using that old name must not collide with (and overwrite) it.
    String? id;
    final uid = _currentUid();
    if (uid != null) {
      final derived = SyncIds.forFriend(uid, trimmed);
      if (state.any((f) => f.id == derived)) id = const Uuid().v4();
    }
    final friend = Friend(
      id: id,
      name: trimmed,
      phone:
          normalizedPhone != null && normalizedPhone.isNotEmpty
              ? normalizedPhone
              : null,
      email: email?.trim().isNotEmpty == true ? email!.trim() : null,
      upiId: upis.isNotEmpty ? upis.first : null,
      upiIds: upis,
      notes: notes?.trim().isNotEmpty == true ? notes!.trim() : null,
      avatar: trimmed[0].toUpperCase(),
      expenses: const [],
      isManual: true,
    );
    state = [...state, friend];
    _persist();
    try {
      SyncService.queueFriendUpsert(
        friend.name,
        friend.phone,
        email: friend.email,
        upiId: friend.upiId,
        upiIds: friend.upiIds,
        notes: friend.notes,
        id: friend.id,
      );
    } catch (_) {}
  }

  static String? _currentUid() {
    try {
      return AuthService.currentUserId;
    } catch (_) {
      return null;
    }
  }

  static String? _blankToNull(String? v) {
    final t = v?.trim();
    return t == null || t.isEmpty ? null : t;
  }

  /// Renames a saved friend in place. Keeps the same server row: uses the
  /// stored server id, or the id derived from the old name (what the phone
  /// used when it created the row). Without a signed-in user the old row is
  /// queued for soft-delete and the new name is upserted.
  ///
  /// Returns false when [oldName] is not saved, [newName] is invalid, or
  /// another friend already uses [newName].
  bool renameFriend(String oldName, String newName) {
    final oldKey = oldName.trim().toLowerCase();
    final trimmed = newName.trim();
    if (oldKey.isEmpty || trimmed.isEmpty || trimmed.toLowerCase() == 'you') {
      return false;
    }
    final idx = state.indexWhere((f) => f.name.toLowerCase() == oldKey);
    if (idx < 0) return false;
    final clash = state.any(
      (f) =>
          f.name.toLowerCase() == trimmed.toLowerCase() &&
          f.name.toLowerCase() != oldKey,
    );
    if (clash) return false;
    final prev = state[idx];
    if (prev.name == trimmed) return true;
    final uid = _currentUid();
    final id =
        prev.id ?? (uid != null ? SyncIds.forFriend(uid, prev.name) : null);
    final next = Friend(
      id: id,
      name: trimmed,
      phone: prev.phone,
      email: prev.email,
      upiId: prev.upiId,
      upiIds: prev.upiIds,
      notes: prev.notes,
      avatar: trimmed[0].toUpperCase(),
      expenses: prev.expenses,
      isManual: true,
    );
    final list = [...state];
    list[idx] = next;
    state = list;
    _persist();
    try {
      // A queued create/update under the old name would recreate the old row.
      SyncQueue.drop(SyncEntity.friend, prev.name);
      if (id == null) SyncService.queueFriendDelete(prev.name);
      SyncService.queueFriendUpsert(
        next.name,
        next.phone,
        email: next.email,
        upiId: next.upiId,
        upiIds: next.upiIds,
        notes: next.notes,
        id: id,
      );
    } catch (_) {}
    return true;
  }

  /// Update an existing manual friend (merge multi-UPI etc.).
  void updateFriendFields(
    String name, {
    String? phone,
    String? email,
    String? upiId,
    List<String>? upiIds,
    String? notes,
  }) {
    final key = name.trim().toLowerCase();
    final idx = state.indexWhere((f) => f.name.toLowerCase() == key);
    if (idx < 0) return;
    final prev = state[idx];
    final upis = normalizeUpiList(
      upiId: upiId ?? prev.upiId,
      upiIds: upiIds ?? prev.upiIds,
    );
    // Passing '' explicitly clears a field; null keeps the previous value.
    final next = Friend(
      id: prev.id,
      name: prev.name,
      phone: phone != null ? _blankToNull(phone) : prev.phone,
      email: email != null ? _blankToNull(email) : prev.email,
      upiId: upis.isNotEmpty ? upis.first : null,
      upiIds: upis,
      notes: notes != null ? _blankToNull(notes) : prev.notes,
      avatar: prev.avatar,
      expenses: prev.expenses,
      isManual: true,
    );
    final list = [...state];
    list[idx] = next;
    state = list;
    _persist();
    try {
      SyncService.queueFriendUpsert(
        next.name,
        next.phone,
        email: next.email,
        upiId: next.upiId,
        upiIds: next.upiIds,
        notes: next.notes,
        id: next.id,
      );
    } catch (_) {}
  }

  void removeFriend(String name) {
    final key = name.trim().toLowerCase();
    if (key.isEmpty) return;
    final removed = state.where((f) => f.name.toLowerCase() == key).firstOrNull;
    if (removed == null) return;
    final next = state.where((f) => f.name.toLowerCase() != key).toList();
    state = next;
    _persist();
    try {
      SyncService.queueFriendDelete(removed.name, id: removed.id);
    } catch (_) {}
  }

  void addFriends(List<String> names, {Map<String, String?>? phonesByName}) {
    var changed = false;
    final newState = List<Friend>.from(state);

    for (final name in names) {
      final trimmed = name.trim();
      if (trimmed.isEmpty || trimmed.toLowerCase() == 'you') continue;
      final existingIndex = newState.indexWhere(
        (f) => f.name.toLowerCase() == trimmed.toLowerCase(),
      );
      final phone = phonesByName?[trimmed] ?? phonesByName?[name];

      if (existingIndex >= 0) {
        if (phone != null &&
            phone.isNotEmpty &&
            (newState[existingIndex].phone == null ||
                newState[existingIndex].phone!.isEmpty)) {
          newState[existingIndex] = Friend(
            name: newState[existingIndex].name,
            phone: phone,
            email: newState[existingIndex].email,
            upiId: newState[existingIndex].upiId,
            upiIds: newState[existingIndex].upiIds,
            notes: newState[existingIndex].notes,
            avatar: newState[existingIndex].avatar,
            expenses: newState[existingIndex].expenses,
            isManual: true,
          );
          changed = true;
        }
      } else {
        newState.add(
          Friend(
            name: trimmed,
            phone: phone?.trim().isNotEmpty == true ? phone!.trim() : null,
            avatar: trimmed[0].toUpperCase(),
            expenses: const [],
            isManual: true,
          ),
        );
        changed = true;
      }
    }

    if (changed) {
      state = newState;
      _persist();
    }
  }

  bool isSavedFriend(String name) {
    return state.any((f) => f.name.toLowerCase() == name.trim().toLowerCase());
  }
}

final friendsProvider = Provider<List<Friend>>((ref) {
  final manualFriends = ref.watch(manualFriendsProvider);
  final outings = ref.watch(outingProvider);
  final friendSplits = ref.watch(friendSplitProvider);
  final Map<String, Friend> byName = {};

  for (final f in manualFriends) {
    byName[f.name.toLowerCase()] = Friend(
      name: f.name,
      phone: f.phone,
      email: f.email,
      upiId: f.upiId,
      upiIds: f.upiIds,
      notes: f.notes,
      avatar: f.avatar,
      expenses: [],
      isManual: true,
    );
  }

  for (final outing in outings) {
    for (final member in outing.members) {
      if (member.name.toLowerCase() == 'you') continue;

      final friendName = member.name;
      final key = friendName.toLowerCase();
      final expenses = <SharedExpense>[];

      for (final expense in outing.expenses) {
        // Only bills YOU paid are money this friend owes you. Without this
        // guard a bill the *friend* paid was still counted into
        // totalPending / youGetBack, overstating what they owe. The outing
        // layer already guards the same way (pendingFromFriendsExcluding,
        // friendBalanceSummary), so this brings the Friends screen in line.
        if (!expense.isPaidByYou(outing.youMemberId)) continue;
        if (expense.memberIds.contains(member.id)) {
          final friendShare = expense.shareForMember(member.id);
          final yourShare = expense.shareForMember(outing.youMemberId);
          final settled = expense.settledAmountForMember(member.id);
          final pending = expense.pendingAmountForMember(member.id);
          expenses.add(
            SharedExpense(
              id: expense.id,
              outingId: outing.id,
              memberId: member.id,
              outingTitle: outing.title,
              expenseTitle: expense.title,
              purpose: expense.purpose,
              totalAmount: expense.amount,
              yourShare: yourShare,
              friendShare: friendShare,
              friendSettled: settled,
              friendPending: pending,
              payments: expense.paymentsForMember(member.id),
              settled: pending < 0.01,
            ),
          );
        }
      }

      final sortedTripExpenses = sortSharedExpensesByOuting(expenses);

      if (byName.containsKey(key)) {
        final existing = byName[key]!;
        byName[key] = Friend(
          name: existing.name,
          phone: existing.phone,
          email: existing.email,
          upiId: existing.upiId,
          upiIds: existing.upiIds,
          notes: existing.notes,
          avatar: existing.avatar,
          expenses: sortSharedExpensesByOuting([
            ...existing.expenses,
            ...sortedTripExpenses,
          ]),
          isManual: existing.isManual,
        );
      } else {
        byName[key] = Friend(
          name: friendName,
          avatar: friendName[0].toUpperCase(),
          expenses: sortedTripExpenses,
        );
      }
    }
  }

  // Friend Splits — standalone shared expenses, no outing involved. Framed
  // the same way as outing expenses so they display/settle identically.
  for (final split in friendSplits) {
    final youId = split.youMemberId;
    // Same rule as outings — a split the friend paid isn't owed to you.
    if (youId == null || split.paidByMemberId != youId) continue;
    for (final member in split.members) {
      if (member.isCurrentUser || member.name.toLowerCase() == 'you') {
        continue;
      }
      final friendName = member.name;
      final key = friendName.toLowerCase();
      final friendShare = split.shareForMember(member.id);
      // youId is non-null — the payer guard above already returned otherwise.
      final yourShare = split.shareForMember(youId);
      final settled = split.settledAmountForMember(member.id);
      final pending = split.pendingAmountForMember(member.id);
      final expense = SharedExpense(
        id: split.id,
        outingId: '',
        isFriendSplit: true,
        splitId: split.id,
        memberId: member.id,
        outingTitle: 'Friend Split',
        expenseTitle: split.description,
        purpose: '',
        totalAmount: split.amount,
        yourShare: yourShare,
        friendShare: friendShare,
        friendSettled: settled,
        friendPending: pending,
        payments:
            split.settlements
                .where((s) => s.fromMemberId == member.id)
                .map(
                  (s) => SettlementPayment(
                    amount: s.amount,
                    mode: 'Online',
                    date: s.date,
                  ),
                )
                .toList(),
        settled: pending < 0.01,
      );

      if (byName.containsKey(key)) {
        final existing = byName[key]!;
        byName[key] = Friend(
          name: existing.name,
          phone: existing.phone,
          email: existing.email,
          upiId: existing.upiId,
          upiIds: existing.upiIds,
          notes: existing.notes,
          avatar: existing.avatar,
          expenses: sortSharedExpensesByOuting([...existing.expenses, expense]),
          isManual: existing.isManual,
        );
      } else {
        byName[key] = Friend(
          name: friendName,
          avatar: friendName[0].toUpperCase(),
          expenses: [expense],
        );
      }
    }
  }

  return sortFriendsForDisplay(byName.values.toList());
});

/// Manual friends first, then others — both alphabetical within each group.
List<Friend> sortFriendsForDisplay(List<Friend> friends) {
  int compareName(Friend a, Friend b) =>
      a.name.toLowerCase().compareTo(b.name.toLowerCase());

  final manual = friends.where((f) => f.isManual).toList()..sort(compareName);
  final other = friends.where((f) => !f.isManual).toList()..sort(compareName);
  return [...manual, ...other];
}

final recentFriendsProvider =
    StateNotifierProvider<RecentFriendsNotifier, List<String>>((ref) {
      return RecentFriendsNotifier();
    });

class RecentFriendsNotifier extends StateNotifier<List<String>> {
  static const _key = 'recent';
  Box get _box => Hive.box('friends');

  RecentFriendsNotifier() : super([]) {
    _load();
  }

  void _load() {
    final raw = _box.get(_key, defaultValue: []);
    if (raw is List) {
      state =
          raw
              .map((e) => e.toString())
              .where((n) => n.trim().isNotEmpty)
              .toList();
    }
  }

  void _persist() => _box.put(_key, state);

  void renameFriend(String oldName, String newName) {
    final oldKey = oldName.trim().toLowerCase();
    final trimmed = newName.trim();
    if (oldKey.isEmpty || trimmed.isEmpty) return;
    if (!state.any((n) => n.toLowerCase() == oldKey)) return;
    final seen = <String>{};
    state = [
      for (final n in state)
        if (seen.add((n.toLowerCase() == oldKey ? trimmed : n).toLowerCase()))
          n.toLowerCase() == oldKey ? trimmed : n,
    ];
    _persist();
  }

  void recordUse(String name) {
    final trimmed = name.trim();
    if (trimmed.isEmpty || trimmed.toLowerCase() == 'you') return;
    final updated =
        [
          trimmed,
          ...state.where((n) => n.toLowerCase() != trimmed.toLowerCase()),
        ].take(15).toList();
    state = updated;
    _persist();
  }
}
