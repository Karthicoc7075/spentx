import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';

/// One-time saved UPI / payment handles per friend (like merchant rules).
class FriendUpiNotifier extends StateNotifier<Map<String, List<String>>> {
  FriendUpiNotifier() : super({}) {
    _load();
  }

  void reloadFromStorage() => _load();

  static const _storageKey = 'friend_upi_links';

  Box get _box => Hive.box('friends');

  static String normalizeUpi(String raw) {
    final s = raw.trim().toLowerCase();
    if (s.isEmpty) return '';
    if (s.contains('@')) return s;
    return s;
  }

  static String friendKey(String name) => name.trim().toLowerCase();

  void _load() {
    final raw = _box.get(_storageKey, defaultValue: {});
    if (raw is! Map) return;
    final map = <String, List<String>>{};
    raw.forEach((key, value) {
      final name = key.toString().trim();
      if (name.isEmpty) return;
      if (value is List) {
        map[friendKey(name)] =
            value
                .map((e) => normalizeUpi(e.toString()))
                .where((u) => u.isNotEmpty)
                .toSet()
                .toList();
      }
    });
    state = map;
  }

  void _persist() {
    final persist = <String, List<String>>{};
    state.forEach((key, upis) {
      if (upis.isEmpty) return;
      // Store with original casing key from first use — use key as display key
      persist[key] = upis;
    });
    _box.put(_storageKey, persist);
  }

  List<String> upisForFriend(String friendName) {
    return List.unmodifiable(state[friendKey(friendName)] ?? const []);
  }

  void addUpi(String friendName, String upi) {
    final normalized = normalizeUpi(upi);
    if (normalized.isEmpty) return;
    final key = friendKey(friendName);
    final current = List<String>.from(state[key] ?? []);
    if (current.contains(normalized)) return;
    current.add(normalized);
    state = {...state, key: current};
    _persist();
  }

  void removeUpi(String friendName, String upi) {
    final key = friendKey(friendName);
    final current = List<String>.from(state[key] ?? []);
    current.remove(normalizeUpi(upi));
    if (current.isEmpty) {
      final next = Map<String, List<String>>.from(state)..remove(key);
      state = next;
    } else {
      state = {...state, key: current};
    }
    _persist();
  }

  /// Moves saved UPI links from [oldName] to [newName] (merging, deduped).
  void renameFriend(String oldName, String newName) {
    final oldKey = friendKey(oldName);
    final newKey = friendKey(newName);
    if (oldKey == newKey || newKey.isEmpty) return;
    final moving = state[oldKey];
    if (moving == null || moving.isEmpty) return;
    final merged = <String>{...?state[newKey], ...moving}.toList();
    final next =
        Map<String, List<String>>.from(state)
          ..remove(oldKey)
          ..[newKey] = merged;
    state = next;
    _persist();
  }

  void removeFriend(String friendName) {
    final key = friendKey(friendName);
    if (!state.containsKey(key)) return;
    final next = Map<String, List<String>>.from(state)..remove(key);
    state = next;
    _persist();
  }
}

final friendUpiProvider =
    StateNotifierProvider<FriendUpiNotifier, Map<String, List<String>>>(
      (ref) => FriendUpiNotifier(),
    );
