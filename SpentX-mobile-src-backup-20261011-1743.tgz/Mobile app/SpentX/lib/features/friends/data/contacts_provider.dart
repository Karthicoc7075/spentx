import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/services/contacts_service.dart';

final deviceContactsProvider = FutureProvider<List<DeviceContact>>((ref) async {
  return ContactsService.loadContacts();
});

final contactsPermissionProvider = FutureProvider<bool>((ref) async {
  return ContactsService.hasPermission();
});