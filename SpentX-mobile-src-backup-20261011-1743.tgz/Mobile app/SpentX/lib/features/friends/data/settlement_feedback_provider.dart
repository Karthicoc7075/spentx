import 'package:flutter_riverpod/flutter_riverpod.dart';

/// One-shot message for auto settlement toasts (e.g. UPI sent to friend).
final settlementFeedbackProvider = StateProvider<String?>((ref) => null);