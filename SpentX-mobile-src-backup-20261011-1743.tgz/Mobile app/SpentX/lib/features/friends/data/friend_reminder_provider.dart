import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';

/// Lightweight Hive-backed state that remembers which friend–expense pairs
/// have had a payment reminder sent. Purely cosmetic — never affects financial
/// calculations.
///
/// Key format: `"friendName::expenseId"` → ISO-8601 timestamp string.
class FriendReminderNotifier extends StateNotifier<Map<String, DateTime>> {
  static const _boxName = 'friend_reminders';
  Box get _box => Hive.box(_boxName);

  FriendReminderNotifier() : super({}) {
    _load();
  }

  void reloadFromStorage() => _load();

  void _load() {
    final raw = _box.get('reminders', defaultValue: <dynamic, dynamic>{});
    if (raw is Map) {
      final map = <String, DateTime>{};
      for (final entry in raw.entries) {
        final key = entry.key.toString();
        final dt = DateTime.tryParse(entry.value.toString());
        if (dt != null) map[key] = dt;
      }
      state = map;
    }
  }

  void _persist() {
    _box.put(
      'reminders',
      state.map((k, v) => MapEntry(k, v.toIso8601String())),
    );
  }

  static String _key(String friendName, String expenseId) =>
      '${friendName.trim().toLowerCase()}::$expenseId';

  /// Record that a reminder was sent for this friend+expense.
  void markReminderSent(String friendName, String expenseId) {
    final k = _key(friendName, expenseId);
    state = {...state, k: DateTime.now()};
    _persist();
  }

  /// When the reminder was sent, or null if never.
  DateTime? reminderSentAt(String friendName, String expenseId) =>
      state[_key(friendName, expenseId)];

  /// Whether ANY expense for this friend has a reminder.
  bool hasAnyReminder(String friendName) {
    final prefix = '${friendName.trim().toLowerCase()}::';
    return state.keys.any((k) => k.startsWith(prefix));
  }

  /// Clear reminder state (e.g. when expense is fully settled).
  void clearReminder(String friendName, String expenseId) {
    final k = _key(friendName, expenseId);
    if (!state.containsKey(k)) return;
    state = Map.from(state)..remove(k);
    _persist();
  }

  /// Re-keys reminder history from [oldName] to [newName].
  void renameFriend(String oldName, String newName) {
    final oldPrefix = '${oldName.trim().toLowerCase()}::';
    final newPrefix = '${newName.trim().toLowerCase()}::';
    if (oldPrefix == newPrefix) return;
    if (!state.keys.any((k) => k.startsWith(oldPrefix))) return;
    final next = <String, DateTime>{};
    state.forEach((k, v) {
      next[k.startsWith(oldPrefix)
              ? '$newPrefix${k.substring(oldPrefix.length)}'
              : k] =
          v;
    });
    state = next;
    _persist();
  }

  /// Clear all reminders for a friend.
  void clearAllForFriend(String friendName) {
    final prefix = '${friendName.trim().toLowerCase()}::';
    final next = Map<String, DateTime>.from(state)
      ..removeWhere((k, _) => k.startsWith(prefix));
    if (next.length == state.length) return;
    state = next;
    _persist();
  }
}

final friendReminderProvider =
    StateNotifierProvider<FriendReminderNotifier, Map<String, DateTime>>((ref) {
      return FriendReminderNotifier();
    });

/// Human-readable "time ago" for the reminder badge.
String reminderTimeAgo(DateTime sentAt) {
  final diff = DateTime.now().difference(sentAt);
  if (diff.inMinutes < 1) return 'just now';
  if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
  if (diff.inHours < 24) return '${diff.inHours}h ago';
  if (diff.inDays < 7) return '${diff.inDays}d ago';
  return '${(diff.inDays / 7).floor()}w ago';
}
