import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../../../core/sync/sync_service.dart';
import '../../../models/friend_split.dart';

/// A one-off shared expense between "you" and friends — a restaurant bill, a
/// taxi fare. Standalone by design (mirrors web's `friend_splits` table):
/// never creates an outing, outing expense, or outing settlement. See
/// `lib/models/friend_split.dart` for the shape.
final friendSplitProvider =
    StateNotifierProvider<FriendSplitNotifier, List<FriendSplit>>((ref) {
  return FriendSplitNotifier();
});

class FriendSplitNotifier extends StateNotifier<List<FriendSplit>> {
  Box get _box => Hive.box('friend_splits');

  FriendSplitNotifier() : super([]) {
    _loadFromStorage();
  }

  /// Reload from Hive after a background sync pull.
  void reloadFromStorage() => _loadFromStorage();

  void _loadFromStorage() {
    try {
      final List<FriendSplit> loaded = [];
      for (final key in _box.keys) {
        final e = _box.get(key);
        if (e is! Map) continue;
        try {
          loaded.add(FriendSplit.fromJson(e));
        } catch (err) {
          debugPrint('Error parsing friend split $key: $err');
        }
      }
      state = loaded..sort((a, b) => b.date.compareTo(a.date));
    } catch (e) {
      debugPrint('CRITICAL: friend split storage load failed: $e');
      state = [];
    }
  }

  void _putAndSync(FriendSplit split) {
    final json = split.toJson();
    _box.put(split.id, json);
    SyncService.queueFriendSplitUpsert(Map<String, dynamic>.from(json));
  }

  /// Creates or replaces the Friend Split describing [split.transactionId]
  /// (a transaction has at most one). Used both for the initial Add-form
  /// save and for edit-time changes (amount/friends/split-type).
  void addOrUpdateSplit(FriendSplit split) {
    final idx = state.indexWhere((s) => s.id == split.id);
    if (idx >= 0) {
      final next = [...state];
      next[idx] = split;
      state = next;
    } else {
      state = [split, ...state];
    }
    _putAndSync(split);
  }

  void removeSplit(String id) {
    state = state.where((s) => s.id != id).toList();
    _box.delete(id);
    SyncService.queueFriendSplitDelete(id);
  }

  /// Removes whichever Friend Split (if any) currently describes
  /// [transactionId] — used when converting a transaction away from Friend
  /// Split, or when the transaction itself is deleted.
  void removeSplitByTransactionId(String transactionId) {
    final split = findForTransaction(transactionId);
    if (split != null) removeSplit(split.id);
  }

  FriendSplit? findForTransaction(String transactionId) {
    for (final s in state) {
      if (s.transactionId == transactionId) return s;
    }
    return null;
  }

  /// Records a repayment against [split] — mirrors web
  /// `saveFriendSettlement`. [fromMemberId] is who paid back, [toMemberId]
  /// who received it (normally the payer of the original split).
  void recordSettlement(
    FriendSplit split, {
    required String fromMemberId,
    required String toMemberId,
    required double amount,
    String? note,
  }) {
    final settlement = FriendSettlementRecord(
      fromMemberId: fromMemberId,
      toMemberId: toMemberId,
      amount: amount,
      date: DateTime.now(),
      note: note,
    );
    addOrUpdateSplit(
      split.copyWith(settlements: [...split.settlements, settlement]),
    );
  }

  /// Reverts/removes settlements associated with a deleted transaction ID
  /// or matching friend name and amount if unlinked.
  void revertSettlementByTransaction({
    required String transactionId,
    String? friendName,
    double? amount,
  }) {
    bool changed = false;
    final next = <FriendSplit>[];

    for (final split in state) {
      final initialCount = split.settlements.length;
      // 1. Check direct note link (e.g. note == 'tx:123' or contains txId)
      final remainingSettlements = split.settlements.where((s) {
        if (s.note != null &&
            (s.note == transactionId || s.note!.contains(transactionId))) {
          return false;
        }
        return true;
      }).toList();

      // 2. Fallback: match by friend name & amount if no direct note
      if (remainingSettlements.length == initialCount &&
          friendName != null &&
          amount != null) {
        final fNameLower =
            friendName.toLowerCase().replaceAll('from ', '').trim();
        final member = split.members
            .where((m) => m.name.toLowerCase() == fNameLower)
            .firstOrNull;
        if (member != null) {
          final matchIdx = remainingSettlements.lastIndexWhere((s) =>
              s.fromMemberId == member.id && (s.amount - amount).abs() < 0.01);
          if (matchIdx >= 0) {
            remainingSettlements.removeAt(matchIdx);
          }
        }
      }

      if (remainingSettlements.length != initialCount) {
        changed = true;
        final updatedSplit = split.copyWith(settlements: remainingSettlements);
        next.add(updatedSplit);
        _putAndSync(updatedSplit);
      } else {
        next.add(split);
      }
    }

    if (changed) {
      state = next;
    }
  }
}

/// Who-owes-whom across every Friend Split, keyed by friend NAME (lowercased
/// — mobile matches friends by name everywhere, same as Outing members).
/// Positive balance = the friend is owed (you owe them); negative = they owe
/// you. Mirrors web `computeFriendSplitNetBalances`.
Map<String, double> friendSplitNetBalancesByName(List<FriendSplit> splits) {
  final totals = <String, double>{};
  for (final split in splits) {
    final balances = <String, double>{
      for (final m in split.members) m.id: 0,
    };
    balances[split.paidByMemberId] =
        (balances[split.paidByMemberId] ?? 0) + split.amount;
    for (final share in split.splits) {
      balances[share.memberId] = (balances[share.memberId] ?? 0) - share.amount;
    }
    for (final settlement in split.settlements) {
      balances[settlement.fromMemberId] =
          (balances[settlement.fromMemberId] ?? 0) + settlement.amount;
      balances[settlement.toMemberId] =
          (balances[settlement.toMemberId] ?? 0) - settlement.amount;
    }
    for (final member in split.members) {
      if (member.isCurrentUser || member.name.toLowerCase() == 'you') {
        continue;
      }
      final key = member.name.toLowerCase();
      totals[key] = (totals[key] ?? 0) + (balances[member.id] ?? 0);
    }
  }
  return totals;
}
