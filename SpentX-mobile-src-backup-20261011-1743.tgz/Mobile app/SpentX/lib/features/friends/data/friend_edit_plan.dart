/// Pure decision logic for editing a saved friend (unit-tested).
class FriendEditPlan {
  FriendEditPlan._({
    required this.renamed,
    required this.upisToRemove,
    this.error,
  });

  /// True when the name changed (including a case-only change).
  final bool renamed;

  /// Saved UPI links that are no longer in the form and must be removed.
  final List<String> upisToRemove;

  /// User-facing reason the edit cannot be saved, or null.
  final String? error;

  static FriendEditPlan build({
    required String original,
    required String newName,
    required String? phoneOwner,
    required Iterable<String> existingNames,
    required Iterable<String> linkedUpis,
    required Iterable<String> formUpis,
  }) {
    final oldKey = original.trim().toLowerCase();
    final newKey = newName.trim().toLowerCase();
    final renamed = original.trim() != newName.trim();

    // The phone belongs to this same friend -> not a duplicate.
    final owner = phoneOwner?.trim().toLowerCase();
    if (owner != null && owner != oldKey && owner != newKey) {
      return FriendEditPlan._(
        renamed: renamed,
        upisToRemove: const [],
        error:
            'This number is already saved as "${phoneOwner!.trim()}" — not adding a duplicate.',
      );
    }
    if (renamed && newKey != oldKey) {
      final clash = existingNames.any((n) => n.trim().toLowerCase() == newKey);
      if (clash) {
        return FriendEditPlan._(
          renamed: renamed,
          upisToRemove: const [],
          error: 'A friend named "${newName.trim()}" already exists.',
        );
      }
    }
    final keep = formUpis.map((u) => u.trim().toLowerCase()).toSet();
    final remove = <String>[
      for (final u in linkedUpis)
        if (!keep.contains(u.trim().toLowerCase())) u,
    ];
    return FriendEditPlan._(renamed: renamed, upisToRemove: remove);
  }
}
