import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../groups/data/outing_provider.dart';
import 'friend_reminder_provider.dart';
import 'friend_split_provider.dart';
import 'friend_upi_provider.dart';
import 'friends_provider.dart';

/// Returns [members] with every non-"you" member called [oldName] renamed to
/// [newName], or null when nothing matched (so callers can skip a sync).
List<OutingMember>? renameMembers(
  List<OutingMember> members,
  String oldName,
  String newName,
) {
  final oldKey = oldName.trim().toLowerCase();
  final trimmed = newName.trim();
  if (oldKey.isEmpty || trimmed.isEmpty || oldKey == 'you') return null;
  var changed = false;
  final next = [
    for (final m in members)
      if (!m.isCurrentUser &&
          m.name.trim().toLowerCase() == oldKey &&
          m.name != trimmed)
        () {
          changed = true;
          return m.copyWith(name: trimmed);
        }()
      else
        m,
  ];
  return changed ? next : null;
}

/// Moves everything keyed by a friend's name to the new name: saved UPI
/// links, recent-friend list, reminder history, and the member name inside
/// outings and friend splits (so shared-expense history follows the friend).
/// The saved friend row itself is renamed by [ManualFriendsNotifier.renameFriend].
Future<void> renameFriendHistory(
  WidgetRef ref, {
  required String oldName,
  required String newName,
}) async {
  if (oldName.trim().toLowerCase() == newName.trim().toLowerCase() &&
      oldName.trim() == newName.trim()) {
    return;
  }
  ref.read(friendUpiProvider.notifier).renameFriend(oldName, newName);
  ref.read(recentFriendsProvider.notifier).renameFriend(oldName, newName);
  ref.read(friendReminderProvider.notifier).renameFriend(oldName, newName);

  final outingNotifier = ref.read(outingProvider.notifier);
  for (final outing in [...ref.read(outingProvider)]) {
    final members = renameMembers(outing.members, oldName, newName);
    if (members == null) continue;
    await outingNotifier.updateOuting(outing.copyWith(members: members));
  }

  final splitNotifier = ref.read(friendSplitProvider.notifier);
  for (final split in [...ref.read(friendSplitProvider)]) {
    final members = renameMembers(split.members, oldName, newName);
    if (members == null) continue;
    splitNotifier.addOrUpdateSplit(split.copyWith(members: members));
  }
}
