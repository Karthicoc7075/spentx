import 'auth_session.dart';

/// Auth port used by presentation. Implemented in data/ against AuthService.
abstract class AuthRepository {
  AuthSession currentSession();
  bool get isSignedIn;
  String? get pendingVerificationEmail;
  Future<void> signOut();
}
