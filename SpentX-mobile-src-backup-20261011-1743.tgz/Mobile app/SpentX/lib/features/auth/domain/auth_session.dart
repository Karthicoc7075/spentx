/// Lightweight auth session snapshot for presentation / routing.
class AuthSession {
  const AuthSession({
    required this.isSignedIn,
    this.email,
    this.userId,
  });

  final bool isSignedIn;
  final String? email;
  final String? userId;

  static const signedOut = AuthSession(isSignedIn: false);
}
