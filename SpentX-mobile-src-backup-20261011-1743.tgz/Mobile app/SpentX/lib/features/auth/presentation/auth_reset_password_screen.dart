import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../../core/config/supabase_config.dart';
import '../../../core/services/auth_service.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../core/widgets/reference_ui.dart';
import 'widgets/auth_widgets.dart';

/// `/auth/reset-password` — reached via the spentx://reset-password deep link
/// from Supabase's reset email (the recovery session is already active when
/// supabase_flutter emits passwordRecovery). Sets the new password, signs the
/// recovery session out, and returns to /auth/login.
class AuthResetPasswordScreen extends StatefulWidget {
  const AuthResetPasswordScreen({super.key});

  @override
  State<AuthResetPasswordScreen> createState() =>
      _AuthResetPasswordScreenState();
}

class _AuthResetPasswordScreenState extends State<AuthResetPasswordScreen> {
  final _passwordCtrl = TextEditingController();
  final _confirmCtrl = TextEditingController();
  bool _obscure = true;
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _passwordCtrl.dispose();
    _confirmCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_passwordCtrl.text.length < SupabaseConfig.minPasswordLength) {
      setState(() => _error =
          'Password must be at least ${SupabaseConfig.minPasswordLength} characters.');
      return;
    }
    if (_passwordCtrl.text != _confirmCtrl.text) {
      setState(() => _error = 'Passwords do not match.');
      return;
    }
    if (!AuthService.isSignedIn) {
      setState(() => _error =
          'Reset session expired — request a new reset link from the login screen.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await AuthService.updatePassword(_passwordCtrl.text);
      await AuthService.signOut();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Password updated — log in with your new password.'),
          behavior: SnackBarBehavior.floating,
        ),
      );
      context.go('/auth/login');
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _busy = false;
        _error = AuthService.friendlyError(e);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = isDark ? SoftPalette.darkBg : SoftPalette.bg;
    final ink = isDark ? SoftPalette.darkInk : SoftPalette.ink;
    final muted = isDark ? SoftPalette.darkMuted : SoftPalette.muted;

    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: Column(
          children: [
            SoftPageHeader(
              title: 'New password',
              onBack: () => context.go('/auth/login'),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.fromLTRB(
                  20,
                  8,
                  20,
                  28 + MediaQuery.viewInsetsOf(context).bottom,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      'Choose a new password',
                      style: TextStyle(
                        color: ink,
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                        letterSpacing: -0.4,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      AuthService.currentUserEmail != null
                          ? 'Setting a new password for ${AuthService.currentUserEmail}.'
                          : 'Choose a new password for your account.',
                      style: TextStyle(
                        color: muted,
                        fontSize: 14,
                        height: 1.5,
                      ),
                    ),
                    const SizedBox(height: 20),
                    AuthErrorBanner(message: _error),
                    SxSoftCard(
                      padding: const EdgeInsets.fromLTRB(16, 18, 16, 18),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          AuthInputField(
                            controller: _passwordCtrl,
                            hint:
                                'At least ${SupabaseConfig.minPasswordLength} characters',
                            prefixIcon: LucideIcons.lock,
                            obscureText: _obscure,
                            enabled: !_busy,
                            suffixWidget: IconButton(
                              icon: Icon(
                                _obscure ? LucideIcons.eye : LucideIcons.eyeOff,
                                size: 18,
                                color: muted,
                              ),
                              onPressed: () =>
                                  setState(() => _obscure = !_obscure),
                            ),
                          ),
                          const SizedBox(height: 14),
                          AuthInputField(
                            controller: _confirmCtrl,
                            hint: 'Repeat password',
                            prefixIcon: LucideIcons.lock,
                            obscureText: _obscure,
                            enabled: !_busy,
                            onSubmitted: (_) => _submit(),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 14,
                        vertical: 12,
                      ),
                      decoration: BoxDecoration(
                        color: isDark
                            ? SoftPalette.darkEmeraldSoft
                            : SoftPalette.emeraldSoft,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Text(
                        'Use a mix of letters and numbers for a stronger password.',
                        style: TextStyle(
                          color: isDark
                              ? SoftPalette.darkEmerald
                              : SoftPalette.mintDark,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          height: 1.4,
                        ),
                      ),
                    ),
                    const SizedBox(height: 28),
                    AuthDarkButton(
                      label: 'Update password',
                      busy: _busy,
                      onPressed: _busy ? null : _submit,
                    ),
                    const SizedBox(height: 12),
                    Center(
                      child: TextButton(
                        onPressed: () => context.go('/auth/login'),
                        child: Text(
                          'Cancel',
                          style: TextStyle(color: muted),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
