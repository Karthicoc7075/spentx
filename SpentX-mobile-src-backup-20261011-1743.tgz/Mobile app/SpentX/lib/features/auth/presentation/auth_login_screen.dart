import 'package:flutter/material.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../core/widgets/reference_ui.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../../core/services/auth_service.dart';
import 'auth_flow.dart';
import 'widgets/auth_widgets.dart';

/// `/auth/login` — Soft Soft Premium returning-user sign in.
class AuthLoginScreen extends StatefulWidget {
  final bool sessionExpired;
  const AuthLoginScreen({super.key, this.sessionExpired = false});

  @override
  State<AuthLoginScreen> createState() => _AuthLoginScreenState();
}

class _AuthLoginScreenState extends State<AuthLoginScreen> {
  final _emailCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  bool _obscure = true;
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    if (widget.sessionExpired) {
      _error = 'Your session has expired. Please log in again.';
    }
  }

  @override
  void dispose() {
    _emailCtrl.dispose();
    _passwordCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final email = _emailCtrl.text.trim();
    if (email.isEmpty || _passwordCtrl.text.isEmpty) {
      setState(() => _error = 'Enter your email and password.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await AuthService.signIn(email: email, password: _passwordCtrl.text);
      if (!mounted) return;
      await AuthFlow.continueAfterAuth(context);
    } catch (e) {
      if (!mounted) return;
      // Unverified accounts must not look like a wrong-password dead end —
      // restore the pending flag and send them to Soft Soft verify/resend.
      if (AuthService.isEmailNotConfirmedError(e)) {
        AuthService.savePendingVerificationEmail(email);
        context.go('/auth/verify-email', extra: email);
        return;
      }
      setState(() {
        _busy = false;
        _error = AuthService.friendlyError(e);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final canvas = isDark ? SoftPalette.darkBg : const Color(0xFFF8FAFC);
    final ink = isDark ? SoftPalette.darkInk : const Color(0xFF0F172A);
    final slate = isDark ? SoftPalette.darkMuted : const Color(0xFF64748B);
    final muted = isDark ? SoftPalette.darkFaint : const Color(0xFF94A3B8);

    return Scaffold(
      backgroundColor: canvas,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        leadingWidth: 56,
        leading: Padding(
          padding: const EdgeInsets.only(left: 8),
          child: Center(
            child: SoftCircleIconButton(
              icon: Icons.arrow_back_ios_new_rounded,
              tooltip: 'Back',
              onPressed: () => Navigator.maybePop(context),
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(
            24,
            4,
            24,
            16 + MediaQuery.viewInsetsOf(context).bottom,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 8),
              const _SoftLockIllustration(),
              const SizedBox(height: 22),

              Text(
                'Sign in',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.w800,
                  letterSpacing: -0.9,
                  color: ink,
                ),
              ),
              const SizedBox(height: 8),

              Text(
                'Welcome back to your ledger',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w500,
                  height: 1.4,
                  color: slate,
                ),
              ),
              const SizedBox(height: 28),

              AuthErrorBanner(message: _error),

              AuthInputField(
                controller: _emailCtrl,
                hint: 'Email',
                prefixIcon: LucideIcons.mail,
                keyboardType: TextInputType.emailAddress,
                enabled: !_busy,
              ),
              const SizedBox(height: 12),

              AuthInputField(
                controller: _passwordCtrl,
                hint: 'Password',
                prefixIcon: LucideIcons.lock,
                obscureText: _obscure,
                enabled: !_busy,
                onSubmitted: (_) => _submit(),
                suffixWidget: GestureDetector(
                  onTap: () => setState(() => _obscure = !_obscure),
                  behavior: HitTestBehavior.opaque,
                  child: Icon(
                    _obscure ? LucideIcons.eyeOff : LucideIcons.eye,
                    size: 19,
                    color: SoftPalette.faint,
                  ),
                ),
              ),
              const SizedBox(height: 10),

              Align(
                alignment: Alignment.centerLeft,
                child: GestureDetector(
                  onTap: () => context.push('/auth/forgot-password'),
                  child: Text(
                    'Forgot your password?',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: slate,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),

              _SoftAuthButton(
                label: 'Continue',
                onPressed: _submit,
                busy: _busy,
              ),
              const SizedBox(height: 18),

              GestureDetector(
                onTap: () => context.pushReplacement('/auth/signup'),
                behavior: HitTestBehavior.opaque,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Create account',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: muted,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Private by design · Your ledger stays calm and yours',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                        color: muted,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }
}

class _SoftAuthButton extends StatelessWidget {
  const _SoftAuthButton({
    required this.label,
    required this.onPressed,
    this.busy = false,
  });

  final String label;
  final VoidCallback? onPressed;
  final bool busy;

  @override
  Widget build(BuildContext context) {
    final enabled = onPressed != null && !busy;
    return SizedBox(
      width: double.infinity,
      height: 56,
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: SoftColors.primaryGradient,
          borderRadius: BorderRadius.circular(22),
          boxShadow:
              enabled
                  ? const [
                    BoxShadow(
                      color: Color(0x33047857),
                      offset: Offset(0, 10),
                      blurRadius: 24,
                    ),
                  ]
                  : null,
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: enabled ? onPressed : null,
            borderRadius: BorderRadius.circular(22),
            child: Center(
              child:
                  busy
                      ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                          color: Colors.white,
                          strokeWidth: 2.2,
                        ),
                      )
                      : Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            label,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(width: 8),
                          const Icon(
                            LucideIcons.arrowRight,
                            color: Colors.white,
                            size: 18,
                          ),
                        ],
                      ),
            ),
          ),
        ),
      ),
    );
  }
}

class _SoftLockIllustration extends StatelessWidget {
  const _SoftLockIllustration();

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final card = isDark ? SoftPalette.darkCard : const Color(0xFFFFFFFF);
    final border = isDark ? SoftPalette.darkBorder : const Color(0xFFF1F5F9);
    return Container(
      width: 152,
      height: 124,
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: border),
        boxShadow: const [
          BoxShadow(
            color: Color.fromRGBO(15, 23, 42, 0.08),
            offset: Offset(0, 12),
            blurRadius: 40,
            spreadRadius: -8,
          ),
        ],
      ),
      child: const Center(child: SpentXBrandBadge(size: 76)),
    );
  }
}
