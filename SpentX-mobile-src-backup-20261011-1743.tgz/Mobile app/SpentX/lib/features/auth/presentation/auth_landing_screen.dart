import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../core/services/auth_service.dart';
import '../../../core/theme/app_fonts.dart';
import '../../../core/theme/soft_palette.dart';
import 'widgets/auth_widgets.dart';

/// `/auth` — required entry point. Soft Soft chrome matching sign-in.
class AuthLandingScreen extends StatelessWidget {
  final bool sessionExpired;
  const AuthLandingScreen({super.key, this.sessionExpired = false});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final canvas = isDark ? SoftPalette.darkBg : const Color(0xFFF8FAFC);
    final card = isDark ? SoftPalette.darkCard : const Color(0xFFFFFFFF);
    final border = isDark ? SoftPalette.darkBorder : const Color(0xFFF1F5F9);
    final ink = isDark ? SoftPalette.darkInk : const Color(0xFF0F172A);
    final slate = isDark ? SoftPalette.darkMuted : const Color(0xFF64748B);
    final muted = isDark ? SoftPalette.darkFaint : const Color(0xFF94A3B8);
    final configured = AuthService.isConfigured;

    return Scaffold(
      backgroundColor: canvas,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 12, 24, 16),
          child: Column(
            children: [
              const Spacer(flex: 2),
              Container(
                width: 152,
                height: 124,
                decoration: BoxDecoration(
                  color: card,
                  borderRadius: BorderRadius.circular(28),
                  border: Border.all(color: border),
                  boxShadow: isDark
                      ? null
                      : const [
                          BoxShadow(
                            color: Color.fromRGBO(15, 23, 42, 0.08),
                            offset: Offset(0, 12),
                            blurRadius: 40,
                            spreadRadius: -8,
                          ),
                        ],
                ),
                child: const Center(child: SpentXBrandBadge(size: 76)),
              ),
              const SizedBox(height: 22),
              Text(
                'SpentX',
                textAlign: TextAlign.center,
                style: AppFonts.text(
                  fontSize: 32,
                  fontWeight: FontWeight.w800,
                  letterSpacing: -0.9,
                  color: ink,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Personal Finance & Budgeting',
                textAlign: TextAlign.center,
                style: AppFonts.text(
                  fontSize: 15,
                  fontWeight: FontWeight.w500,
                  height: 1.4,
                  color: slate,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Track every rupee automatically using SMS detection and smart insights.',
                textAlign: TextAlign.center,
                style: AppFonts.text(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  height: 1.45,
                  color: muted,
                ),
              ),
              const Spacer(flex: 2),
              if (sessionExpired) ...[
                const _Notice(
                  text: 'Your session has expired. Please log in again.',
                ),
                const SizedBox(height: 12),
              ],
              if (!configured) ...[
                const _Notice(
                  text:
                      'Supabase is not configured yet — paste the project URL and '
                      'anon key into lib/core/config/supabase_config.dart.',
                ),
                const SizedBox(height: 12),
              ],
              _LandingCta(
                label: 'Create Account',
                onPressed: configured ? () => context.push('/auth/signup') : null,
              ),
              const SizedBox(height: 16),
              GestureDetector(
                onTap: configured ? () => context.push('/auth/login') : null,
                behavior: HitTestBehavior.opaque,
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Text.rich(
                    TextSpan(
                      text: 'Already have an account?  ',
                      style: AppFonts.text(
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        color: slate,
                      ),
                      children: [
                        TextSpan(
                          text: 'Log In',
                          style: AppFonts.text(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            color: configured
                                ? const Color(0xFF059669)
                                : muted,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Private by design · Your ledger stays calm and yours',
                textAlign: TextAlign.center,
                style: AppFonts.text(
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                  color: muted,
                ),
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }
}

class _Notice extends StatelessWidget {
  const _Notice({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: SoftPalette.warningSoft,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: SoftPalette.warning.withValues(alpha: 0.28)),
      ),
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: AppFonts.text(
          fontSize: 13,
          fontWeight: FontWeight.w600,
          height: 1.4,
          color: SoftPalette.warning,
        ),
      ),
    );
  }
}

class _LandingCta extends StatelessWidget {
  const _LandingCta({required this.label, required this.onPressed});

  final String label;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    final enabled = onPressed != null;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return SizedBox(
      width: double.infinity,
      height: 56,
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: enabled
              ? SoftColors.primaryGradient
              : null,
          color: enabled
              ? null
              : (isDark ? SoftPalette.darkCard : const Color(0xFFFFFFFF)),
          borderRadius: BorderRadius.circular(22),
          border: enabled
              ? null
              : Border.all(
                  color: isDark
                      ? SoftPalette.darkBorder
                      : const Color(0xFFF1F5F9),
                ),
          boxShadow: enabled && !isDark
              ? const [
                  BoxShadow(
                    color: Color(0x33047857),
                    offset: Offset(0, 10),
                    blurRadius: 24,
                  ),
                ]
              : null,
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: onPressed,
            borderRadius: BorderRadius.circular(22),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  label,
                  style: AppFonts.text(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: enabled ? Colors.white : const Color(0xFF94A3B8),
                  ),
                ),
                const SizedBox(width: 8),
                Icon(
                  LucideIcons.arrowRight,
                  size: 18,
                  color: enabled ? Colors.white : const Color(0xFF94A3B8),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
