import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_fonts.dart';
import '../../../../core/theme/soft_palette.dart';

/// SpentX brand badge icon matching the uploaded mockups (rounded squircle).
class SpentXBrandBadge extends StatelessWidget {
  final double size;
  const SpentXBrandBadge({super.key, this.size = 80});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final radius = BorderRadius.circular(size * 0.28);

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: isDark ? SoftPalette.darkEmeraldSoft : SoftPalette.card,
        borderRadius: radius,
        boxShadow: [
          BoxShadow(
            color: isDark ? const Color(0x33000000) : const Color(0x140F172A),
            blurRadius: 18,
            offset: const Offset(0, 6),
          ),
          BoxShadow(
            color: const Color(0x1A10B981),
            blurRadius: 12,
            offset: const Offset(0, 2),
          ),
        ],
        border: Border.all(
          color:
              isDark ? Colors.white.withValues(alpha: 0.1) : SoftPalette.border,
          width: 1,
        ),
      ),
      child: ClipRRect(
        borderRadius: radius,
        child: Image.asset(
          'assets/icon/icon.png',
          width: size,
          height: size,
          fit: BoxFit.cover,
          errorBuilder:
              (_, __, ___) => Container(
                decoration: BoxDecoration(
                  color: SoftPalette.emeraldSoft,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: SoftPalette.mint.withValues(alpha: 0.35),
                  ),
                ),
                child: Center(
                  child: Text(
                    'S',
                    style: TextStyle(
                      color: SoftPalette.emerald,
                      fontSize: size * 0.5,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),
        ),
      ),
    );
  }
}

/// Precise 4-color Google G icon painter.
class GoogleLogoPainter extends CustomPainter {
  const GoogleLogoPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final scale = size.width / 24.0;
    canvas.scale(scale, scale);

    // Blue: horizontal bar & upper right arc
    final bluePaint =
        Paint()
          ..color = const Color(0xFF4285F4)
          ..style = PaintingStyle.fill;
    final bluePath =
        Path()
          ..moveTo(23.75, 12.27)
          ..cubicTo(23.75, 11.57, 23.69, 10.87, 23.56, 10.2)
          ..lineTo(12, 10.2)
          ..lineTo(12, 14.71)
          ..lineTo(18.6, 14.71)
          ..cubicTo(18.31, 16.23, 17.46, 17.51, 16.2, 18.37)
          ..lineTo(20.08, 21.42)
          ..cubicTo(22.35, 19.33, 23.75, 16.25, 23.75, 12.27)
          ..close();
    canvas.drawPath(bluePath, bluePaint);

    // Green: bottom arc
    final greenPaint =
        Paint()
          ..color = const Color(0xFF34A853)
          ..style = PaintingStyle.fill;
    final greenPath =
        Path()
          ..moveTo(12, 24)
          ..cubicTo(15.24, 24, 17.95, 22.92, 19.93, 21.09)
          ..lineTo(16.05, 18.04)
          ..cubicTo(14.97, 18.76, 13.6, 19.2, 12, 19.2)
          ..cubicTo(8.88, 19.2, 6.23, 17.1, 5.28, 14.26)
          ..lineTo(1.26, 17.4)
          ..cubicTo(3.25, 21.34, 7.33, 24, 12, 24)
          ..close();
    canvas.drawPath(greenPath, greenPaint);

    // Yellow: left arc
    final yellowPaint =
        Paint()
          ..color = const Color(0xFFFBBC05)
          ..style = PaintingStyle.fill;
    final yellowPath =
        Path()
          ..moveTo(5.28, 14.26)
          ..cubicTo(5.03, 13.54, 4.9, 12.77, 4.9, 12)
          ..cubicTo(4.9, 11.23, 5.03, 10.46, 5.28, 9.74)
          ..lineTo(1.26, 6.6)
          ..cubicTo(0.46, 8.21, 0, 10.05, 0, 12)
          ..cubicTo(0, 13.95, 0.46, 15.79, 1.26, 17.4)
          ..lineTo(5.28, 14.26)
          ..close();
    canvas.drawPath(yellowPath, yellowPaint);

    // Red: top arc
    final redPaint =
        Paint()
          ..color = const Color(0xFFEA4335)
          ..style = PaintingStyle.fill;
    final redPath =
        Path()
          ..moveTo(12, 4.77)
          ..cubicTo(13.77, 4.77, 15.35, 5.38, 16.6, 6.57)
          ..lineTo(20.02, 3.15)
          ..cubicTo(17.95, 1.19, 15.24, 0, 12, 0)
          ..cubicTo(7.33, 0, 3.25, 2.66, 1.26, 6.6)
          ..lineTo(5.28, 9.74)
          ..cubicTo(6.23, 6.9, 8.88, 4.77, 12, 4.77)
          ..close();
    canvas.drawPath(redPath, redPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class GoogleLogoIcon extends StatelessWidget {
  final double size;
  const GoogleLogoIcon({super.key, this.size = 18});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: const CustomPaint(painter: GoogleLogoPainter()),
    );
  }
}

/// Modern rounded input field matching the mockup (rounded-2xl, subtle border).
class AuthInputField extends StatefulWidget {
  final TextEditingController controller;
  final String hint;
  final IconData? prefixIcon;
  final Widget? prefixWidget;
  final Widget? suffixWidget;
  final bool obscureText;
  final TextInputType keyboardType;
  final ValueChanged<String>? onSubmitted;
  final bool enabled;

  const AuthInputField({
    super.key,
    required this.controller,
    required this.hint,
    this.prefixIcon,
    this.prefixWidget,
    this.suffixWidget,
    this.obscureText = false,
    this.keyboardType = TextInputType.text,
    this.onSubmitted,
    this.enabled = true,
  });

  @override
  State<AuthInputField> createState() => _AuthInputFieldState();
}

class _AuthInputFieldState extends State<AuthInputField> {
  final FocusNode _focusNode = FocusNode();
  bool _isFocused = false;

  @override
  void initState() {
    super.initState();
    _focusNode.addListener(() {
      if (mounted) setState(() => _isFocused = _focusNode.hasFocus);
    });
  }

  @override
  void dispose() {
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    // The field itself is a soft card; focus is shown with a subtle shadow,
    // not an inner/enabled/focused outline.
    final bgColor = isDark ? SoftPalette.darkSurface : SoftPalette.card;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      height: 52,
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow:
            _isFocused && !isDark
                ? [
                  BoxShadow(
                    color: SoftPalette.emerald.withValues(alpha: 0.12),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ]
                : null,
      ),
      child: Row(
        children: [
          if (widget.prefixWidget != null)
            Padding(
              padding: const EdgeInsets.only(left: 12, right: 6),
              child: widget.prefixWidget!,
            )
          else if (widget.prefixIcon != null)
            Padding(
              padding: const EdgeInsets.only(left: 14, right: 10),
              child: Icon(
                widget.prefixIcon,
                size: 19,
                color: _isFocused ? SoftPalette.emerald : SoftPalette.faint,
              ),
            )
          else
            const SizedBox(width: 16),
          Expanded(
            child: TextField(
              controller: widget.controller,
              focusNode: _focusNode,
              obscureText: widget.obscureText,
              keyboardType: widget.keyboardType,
              enabled: widget.enabled,
              onSubmitted: widget.onSubmitted,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: isDark ? SoftPalette.darkInk : SoftPalette.ink,
              ),
              decoration: InputDecoration(
                isDense: true,
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                disabledBorder: InputBorder.none,
                errorBorder: InputBorder.none,
                focusedErrorBorder: InputBorder.none,
                hintText: widget.hint,
                hintStyle: const TextStyle(
                  fontSize: 13.5,
                  fontWeight: FontWeight.w400,
                  color: SoftPalette.faint,
                ),
                contentPadding: const EdgeInsets.symmetric(vertical: 14),
              ),
            ),
          ),
          if (widget.suffixWidget != null)
            Padding(
              padding: const EdgeInsets.only(right: 12),
              child: widget.suffixWidget!,
            ),
        ],
      ),
    );
  }
}

/// Soft primary CTA (emerald, 16px radius, full width).
class AuthDarkButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final bool busy;

  const AuthDarkButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.busy = false,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: ElevatedButton(
        onPressed: busy ? null : onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: SoftColors.control,
          foregroundColor: Colors.white,
          disabledBackgroundColor: SoftPalette.emerald.withValues(alpha: 0.5),
          elevation: 2,
          shadowColor: Colors.black.withValues(alpha: 0.2),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
        child:
            busy
                ? const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    color: SoftPalette.onEmerald,
                    strokeWidth: 2.2,
                  ),
                )
                : Text(
                  label,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.2,
                    color: SoftPalette.onEmerald,
                  ),
                ),
      ),
    );
  }
}

/// Outline social button (Google, Apple) side by side.
class AuthSocialButton extends StatelessWidget {
  final Widget icon;
  final String label;
  final VoidCallback? onPressed;

  const AuthSocialButton({
    super.key,
    required this.icon,
    required this.label,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor = isDark ? SoftPalette.darkSurface : SoftPalette.card;
    final borderColor = isDark ? SoftPalette.darkBorder : SoftPalette.border;
    final textColor = isDark ? SoftPalette.darkInk : SoftPalette.ink;

    return Expanded(
      child: SizedBox(
        height: 48,
        child: OutlinedButton(
          onPressed: onPressed,
          style: OutlinedButton.styleFrom(
            backgroundColor: bgColor,
            foregroundColor: textColor,
            side: BorderSide(color: borderColor, width: 1),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            elevation: 0,
            padding: const EdgeInsets.symmetric(horizontal: 12),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              icon,
              const SizedBox(width: 8),
              Text(
                label,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: textColor,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Modern organic divider with "Or continue with".
class AuthOrDivider extends StatelessWidget {
  final String label;
  const AuthOrDivider({super.key, this.label = 'Or continue with'});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final lineColor = isDark ? SoftPalette.darkBorder : SoftPalette.border;
    final textColor = isDark ? SoftPalette.darkMuted : SoftPalette.faint;

    return Row(
      children: [
        Expanded(child: Container(height: 1, color: lineColor)),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Text(
            label,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w400,
              color: textColor,
            ),
          ),
        ),
        Expanded(child: Container(height: 1, color: lineColor)),
      ],
    );
  }
}

/// Brand header reused from the splash screen — gradient "S" mark,
/// bold SpentX wordmark, tagline.
class AuthBrandHeader extends StatelessWidget {
  final double logoSize;
  final bool showTagline;

  const AuthBrandHeader({
    super.key,
    this.logoSize = 72,
    this.showTagline = true,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: logoSize,
          height: logoSize,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [
                SoftPalette.mint,
                SoftPalette.emerald,
                SoftPalette.mintDark,
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              stops: [0.0, 0.45, 1.0],
            ),
            borderRadius: BorderRadius.circular(logoSize * 0.3),
            boxShadow: [
              BoxShadow(
                color: SoftPalette.emerald.withValues(
                  alpha: isDark ? 0.45 : 0.28,
                ),
                blurRadius: 30,
                offset: const Offset(0, 10),
              ),
            ],
            border: Border.all(
              color: Colors.white.withValues(alpha: isDark ? 0.12 : 0.35),
              width: 1,
            ),
          ),
          child: Center(
            child: Text(
              'S',
              style: AppFonts.text(
                color: Colors.white,
                fontSize: logoSize * 0.48,
                fontWeight: FontWeight.w800,
                letterSpacing: -1,
                height: 1,
              ),
            ),
          ),
        ),
        const SizedBox(height: 20),
        Text.rich(
          TextSpan(
            children: [
              TextSpan(
                text: 'Spent',
                style: AppFonts.text(
                  color: AppSurface.text,
                  fontSize: 34,
                  fontWeight: FontWeight.w800,
                  letterSpacing: -1.6,
                  height: 1.05,
                ),
              ),
              TextSpan(
                text: 'X',
                style: AppFonts.text(
                  color: SoftPalette.emerald,
                  fontSize: 34,
                  fontWeight: FontWeight.w800,
                  letterSpacing: -1.6,
                  height: 1.05,
                ),
              ),
            ],
          ),
        ),
        if (showTagline) ...[
          const SizedBox(height: 10),
          Text(
            'Know where every rupee goes.',
            style: AppFonts.text(
              color: AppSurface.subText,
              fontSize: 14,
              fontWeight: FontWeight.w500,
              letterSpacing: 0.15,
            ),
          ),
        ],
      ],
    );
  }
}

class AuthTextField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final String? hint;
  final bool obscure;
  final TextInputType keyboardType;
  final Widget? suffix;
  final ValueChanged<String>? onSubmitted;

  const AuthTextField({
    super.key,
    required this.controller,
    required this.label,
    this.hint,
    this.obscure = false,
    this.keyboardType = TextInputType.text,
    this.suffix,
    this.onSubmitted,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label.toUpperCase(),
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w500,
            letterSpacing: 1.1,
            color: AppSurface.faint,
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: controller,
          obscureText: obscure,
          keyboardType: keyboardType,
          autocorrect: false,
          onSubmitted: onSubmitted,
          style: TextStyle(color: AppSurface.text, fontSize: 16),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: TextStyle(color: AppSurface.faint),
            filled: true,
            fillColor: AppSurface.elevated,
            suffixIcon: suffix,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 16,
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide.none,
            ),
          ),
        ),
      ],
    );
  }
}

class AuthPrimaryButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final bool busy;

  const AuthPrimaryButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.busy = false,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 56,
      child: ElevatedButton(
        onPressed: busy ? null : onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: SoftColors.control,
          foregroundColor: Colors.white,
          disabledBackgroundColor: SoftPalette.emerald.withValues(alpha: 0.45),
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
        child:
            busy
                ? const SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(
                    color: SoftPalette.onEmerald,
                    strokeWidth: 2.5,
                  ),
                )
                : Text(
                  label,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.4,
                    color: SoftPalette.onEmerald,
                  ),
                ),
      ),
    );
  }
}

/// Inline error banner that surfaces the REAL auth error message.
class AuthErrorBanner extends StatelessWidget {
  final String? message;
  const AuthErrorBanner({super.key, required this.message});

  @override
  Widget build(BuildContext context) {
    if (message == null || message!.isEmpty) return const SizedBox.shrink();
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: SoftPalette.negative.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: SoftPalette.negative.withValues(alpha: 0.35)),
      ),
      child: Text(
        message!,
        style: const TextStyle(
          color: SoftPalette.negative,
          fontSize: 13,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }
}
