import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';

import 'soft_onboarding_widgets.dart';

class OnboardingPurposeTypeCard extends StatefulWidget {
  final ValueChanged<List<String>> onContinue;
  final VoidCallback onBack;

  const OnboardingPurposeTypeCard({
    super.key,
    required this.onContinue,
    required this.onBack,
  });

  @override
  State<OnboardingPurposeTypeCard> createState() =>
      _OnboardingPurposeTypeCardState();
}

class _OnboardingPurposeTypeCardState extends State<OnboardingPurposeTypeCard> {
  final List<_PurposeOption> _allOptions = [
    _PurposeOption(
      id: 'Personal',
      title: 'Personal',
      description:
          'Individual expenditures, discrete lifestyle management, and sole-beneficiary asset tracking.',
      icon: LucideIcons.user,
    ),
    _PurposeOption(
      id: 'Family',
      title: 'Family',
      description:
          'Shared liquidity, household estate planning, and multi-beneficiary wealth structuring.',
      icon: LucideIcons.users,
    ),
  ];

  final Set<String> _selected = {'Personal'};
  final _controller = TextEditingController();

  void _toggle(String id) {
    setState(() {
      if (_selected.contains(id)) {
        if (_selected.length > 1) _selected.remove(id);
      } else {
        _selected.add(id);
      }
    });
  }

  void _addCustom() {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    if (_allOptions.any((option) => option.id == text)) return;
    setState(() {
      _allOptions.add(
        _PurposeOption(
          id: text,
          title: text,
          description: 'Custom purpose type',
          icon: LucideIcons.tag,
        ),
      );
      _selected.add(text);
    });
    _controller.clear();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _openAddSheet() {
    final tone = OnboardingTone(context);
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (sheetContext) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.viewInsetsOf(sheetContext).bottom,
          ),
          child: Container(
            decoration: BoxDecoration(
              color: tone.card,
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(24),
              ),
              border: Border.all(color: tone.border),
              boxShadow: tone.shadow,
            ),
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: tone.border,
                      borderRadius: BorderRadius.circular(999),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  'Add purpose',
                  style: tone.text(20, FontWeight.w800, tone.ink),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: _controller,
                  autofocus: true,
                  style: tone.text(14, FontWeight.w600, tone.ink),
                  decoration: InputDecoration(
                    hintText: 'e.g. Business, Investments',
                    hintStyle: tone.text(14, FontWeight.w500, tone.muted),
                    filled: true,
                    fillColor: tone.card,
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 14,
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: tone.border),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: tone.emerald, width: 1.4),
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: tone.border),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                OnboardingPrimaryButton(
                  label: 'Add purpose',
                  onPressed: () {
                    _addCustom();
                    Navigator.pop(sheetContext);
                  },
                ),
                Center(
                  child: OnboardingTextButton(
                    label: 'Cancel',
                    onPressed: () => Navigator.pop(sheetContext),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final tone = OnboardingTone(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: ListView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.only(bottom: 12),
            children: [
              OnboardingStepHeader(
                step: 3,
                onBack: widget.onBack,
                title: "What's this money for?",
                subtitle: 'Pick one purpose for now.',
              ),
              const SizedBox(height: 18),
              for (final option in _allOptions)
                _PurposeCard(
                  option: option,
                  selected: _selected.contains(option.id),
                  onTap: () => _toggle(option.id),
                ),
              Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: _openAddSheet,
                  borderRadius: BorderRadius.circular(24),
                  child: Ink(
                    decoration: BoxDecoration(
                      color: tone.mint,
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: tone.border),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          LucideIcons.plus,
                          size: 16,
                          color: tone.emeraldDeep,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'Add purpose',
                          style: tone.text(
                            14,
                            FontWeight.w700,
                            tone.emeraldDeep,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              const OnboardingShield(text: 'You can change this later.'),
            ],
          ),
        ),
        OnboardingPrimaryButton(
          label: 'Continue',
          onPressed: () => widget.onContinue(_selected.toList()),
        ),
      ],
    );
  }
}

class _PurposeCard extends StatelessWidget {
  const _PurposeCard({
    required this.option,
    required this.selected,
    required this.onTap,
  });

  final _PurposeOption option;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final tone = OnboardingTone(context);
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(24),
          child: Ink(
            decoration: tone.cardBox(
              fill: selected ? tone.mint : tone.card,
              borderColor: selected ? tone.emerald : tone.border,
            ),
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: selected ? tone.card : tone.mint,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(
                    option.icon,
                    size: 20,
                    color: selected ? tone.emeraldDeep : tone.slate,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        option.title,
                        style: tone.text(16, FontWeight.w800, tone.ink),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        option.description,
                        style: tone.text(
                          12,
                          FontWeight.w500,
                          tone.slate,
                          height: 1.35,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Icon(
                  selected ? LucideIcons.checkCircle2 : LucideIcons.circle,
                  size: 22,
                  color: selected ? tone.emerald : tone.slate,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _PurposeOption {
  final String id;
  final String title;
  final String description;
  final IconData icon;

  _PurposeOption({
    required this.id,
    required this.title,
    required this.description,
    required this.icon,
  });
}
