import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../../models/account_model.dart';
import 'soft_onboarding_widgets.dart';

class OnboardingAccountFormCard extends StatefulWidget {
  final int requiredCount;
  final ValueChanged<List<AccountModel>> onContinue;
  final VoidCallback onBack;

  const OnboardingAccountFormCard({
    super.key,
    required this.requiredCount,
    required this.onContinue,
    required this.onBack,
  });

  @override
  State<OnboardingAccountFormCard> createState() =>
      _OnboardingAccountFormCardState();
}

class _OnboardingAccountFormCardState extends State<OnboardingAccountFormCard> {
  final _formKey = GlobalKey<FormState>();
  late int _totalAccounts;
  int _currentIndex = 0;

  final List<TextEditingController> _nameControllers = [];
  final List<TextEditingController> _customNameControllers = [];
  final List<TextEditingController> _last4Controllers = [];
  final List<TextEditingController> _balanceControllers = [];

  final List<bool> _isCustomBank = [];
  String? _bankError;

  final _cashBalanceController = TextEditingController(text: '0');

  final List<String> _bankSuggestions = [
    'SBI',
    'HDFC',
    'ICICI',
    'Axis',
    'Kotak',
    'Yes Bank',
    'PNB',
    'BOB',
    'Canara',
    'Union Bank',
    'IndusInd',
    'Federal',
  ];

  @override
  void initState() {
    super.initState();
    _totalAccounts = widget.requiredCount;
    for (var i = 0; i < _totalAccounts; i++) {
      _nameControllers.add(TextEditingController());
      _customNameControllers.add(TextEditingController());
      _last4Controllers.add(TextEditingController());
      _balanceControllers.add(TextEditingController(text: '0'));
      _isCustomBank.add(false);
    }
    for (final controller in [
      ..._customNameControllers,
      ..._last4Controllers,
      ..._balanceControllers,
    ]) {
      controller.addListener(_refresh);
    }
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    for (final controller in [
      ..._customNameControllers,
      ..._last4Controllers,
      ..._balanceControllers,
    ]) {
      controller.removeListener(_refresh);
    }
    _cashBalanceController.dispose();
    for (final controller in _nameControllers) {
      controller.dispose();
    }
    for (final controller in _customNameControllers) {
      controller.dispose();
    }
    for (final controller in _last4Controllers) {
      controller.dispose();
    }
    for (final controller in _balanceControllers) {
      controller.dispose();
    }
    super.dispose();
  }

  void _goNext() {
    final bankMissing =
        !_isCustomBank[_currentIndex] &&
        _nameControllers[_currentIndex].text.trim().isEmpty;
    final fieldsOk = _formKey.currentState!.validate();
    setState(() => _bankError = bankMissing ? 'Select a bank' : null);
    if (!fieldsOk || bankMissing) return;
    if (_currentIndex < _totalAccounts - 1) {
      setState(() {
        _bankError = null;
        _currentIndex++;
      });
    } else {
      _submit();
    }
  }

  void _goPrev() {
    if (_currentIndex > 0) {
      setState(() {
        _bankError = null;
        _currentIndex--;
      });
    } else {
      widget.onBack();
    }
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;
    final finalAccounts = <AccountModel>[
      AccountModel(
        name: 'Cash',
        type: 'Cash',
        openingBalance: double.tryParse(_cashBalanceController.text) ?? 0.0,
      ),
    ];
    for (var i = 0; i < _totalAccounts; i++) {
      final bankName =
          _isCustomBank[i]
              ? _customNameControllers[i].text.trim()
              : _nameControllers[i].text.trim();

      finalAccounts.add(
        AccountModel(
          name: bankName.isEmpty ? 'Bank ${i + 1}' : bankName,
          type: 'Bank',
          last4Digits: _last4Controllers[i].text.trim(),
          openingBalance: double.tryParse(_balanceControllers[i].text) ?? 0.0,
        ),
      );
    }
    widget.onContinue(finalAccounts);
  }

  /// Keeps whatever accounts were already completed (indices before
  /// [_currentIndex]) and drops the rest — the one currently being edited
  /// isn't included since it hasn't been validated/confirmed with Next yet.
  void _skipRemaining() {
    final finalAccounts = <AccountModel>[
      AccountModel(
        name: 'Cash',
        type: 'Cash',
        openingBalance: double.tryParse(_cashBalanceController.text) ?? 0.0,
      ),
    ];
    for (var i = 0; i < _currentIndex; i++) {
      final bankName =
          _isCustomBank[i]
              ? _customNameControllers[i].text.trim()
              : _nameControllers[i].text.trim();

      finalAccounts.add(
        AccountModel(
          name: bankName.isEmpty ? 'Bank ${i + 1}' : bankName,
          type: 'Bank',
          last4Digits: _last4Controllers[i].text.trim(),
          openingBalance: double.tryParse(_balanceControllers[i].text) ?? 0.0,
        ),
      );
    }
    widget.onContinue(finalAccounts);
  }

  List<String> _getFilteredBanks() {
    final selectedBanks = <String>[];
    for (var i = 0; i < _currentIndex; i++) {
      if (!_isCustomBank[i] && _nameControllers[i].text.isNotEmpty) {
        selectedBanks.add(_nameControllers[i].text);
      }
    }

    final filtered =
        _bankSuggestions
            .where((bank) => !selectedBanks.contains(bank))
            .toList();
    filtered.add('Other / Custom');
    return filtered;
  }

  bool _slipReady(int index) {
    if (_isCustomBank[index]) {
      if (_customNameControllers[index].text.trim().isEmpty) return false;
    } else if (_nameControllers[index].text.trim().isEmpty) {
      return false;
    }
    final last4 = _last4Controllers[index].text.trim();
    if (last4.isNotEmpty && last4.length < 4) return false;
    return true;
  }

  bool get _allReady {
    for (var i = 0; i < _totalAccounts; i++) {
      if (!_slipReady(i)) return false;
    }
    return _totalAccounts > 0;
  }

  String _money(String raw) {
    final value = double.tryParse(raw.trim()) ?? 0;
    return NumberFormat.currency(
      locale: 'en_IN',
      symbol: '₹',
      decimalDigits: 0,
    ).format(value.abs());
  }

  String _bankName(int index) {
    final name =
        _isCustomBank[index]
            ? _customNameControllers[index].text.trim()
            : _nameControllers[index].text.trim();
    return name.isEmpty ? 'Bank ${index + 1}' : name;
  }

  @override
  Widget build(BuildContext context) {
    final title =
        _totalAccounts == 1
            ? 'Add your 1 bank.'
            : 'Add your $_totalAccounts banks.';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        OnboardingStepHeader(
          step: 2,
          onBack: _goPrev,
          title: title,
          subtitle: 'One slip open at a time.',
        ),
        const SizedBox(height: 14),
        const OnboardingShield(
          text: 'Cash is already included and is not listed.',
        ),
        const SizedBox(height: 12),
        Expanded(
          child: ListView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.only(bottom: 12),
            children: [
              for (var i = 0; i < _totalAccounts; i++)
                if (i < _currentIndex)
                  _DoneSlip(
                    name: _bankName(i),
                    last4: _last4Controllers[i].text.trim(),
                    balance: _money(_balanceControllers[i].text),
                    onTap:
                        () => setState(() {
                          _bankError = null;
                          _currentIndex = i;
                        }),
                  )
                else if (i == _currentIndex)
                  _ActiveSlip(
                    formKey: _formKey,
                    index: i,
                    total: _totalAccounts,
                    banks: _getFilteredBanks(),
                    isCustom: _isCustomBank[i],
                    nameController: _nameControllers[i],
                    customController: _customNameControllers[i],
                    last4Controller: _last4Controllers[i],
                    balanceController: _balanceControllers[i],
                    bankError: _bankError,
                    onBank: (value) {
                      setState(() {
                        _bankError = null;
                        if (value == 'Other / Custom') {
                          _isCustomBank[i] = true;
                          _nameControllers[i].text = '';
                        } else {
                          _isCustomBank[i] = false;
                          _nameControllers[i].text = value ?? '';
                        }
                      });
                    },
                  )
                else
                  _EmptySlip(onTap: _goNext),
            ],
          ),
        ),
        OnboardingPrimaryButton(
          label: 'Continue',
          onPressed: _allReady ? _submit : null,
        ),
        Center(
          child: OnboardingTextButton(
            label: 'Skip Remaining',
            onPressed: _skipRemaining,
          ),
        ),
      ],
    );
  }
}

class _DoneSlip extends StatelessWidget {
  const _DoneSlip({
    required this.name,
    required this.last4,
    required this.balance,
    required this.onTap,
  });

  final String name;
  final String last4;
  final String balance;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final tone = OnboardingTone(context);
    final digits = last4.isEmpty ? '••••' : '•••• $last4';
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(24),
          child: Ink(
            decoration: tone.cardBox(),
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: tone.mint,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(
                    LucideIcons.landmark,
                    size: 18,
                    color: tone.emeraldDeep,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: tone.text(14, FontWeight.w700, tone.ink),
                      ),
                      Text(
                        digits,
                        style: tone.text(12, FontWeight.w600, tone.slate),
                      ),
                    ],
                  ),
                ),
                Text(balance, style: tone.text(14, FontWeight.w800, tone.ink)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _EmptySlip extends StatelessWidget {
  const _EmptySlip({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final tone = OnboardingTone(context);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(24),
          child: Ink(
            decoration: tone.cardBox(),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
            child: Row(
              children: [
                Icon(LucideIcons.plus, size: 16, color: tone.slate),
                const SizedBox(width: 10),
                Text(
                  'Tap to finish',
                  style: tone.text(14, FontWeight.w700, tone.slate),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ActiveSlip extends StatelessWidget {
  const _ActiveSlip({
    required this.formKey,
    required this.index,
    required this.total,
    required this.banks,
    required this.isCustom,
    required this.nameController,
    required this.customController,
    required this.last4Controller,
    required this.balanceController,
    required this.bankError,
    required this.onBank,
  });

  final GlobalKey<FormState> formKey;
  final int index;
  final int total;
  final List<String> banks;
  final bool isCustom;
  final TextEditingController nameController;
  final TextEditingController customController;
  final TextEditingController last4Controller;
  final TextEditingController balanceController;
  final String? bankError;
  final ValueChanged<String?> onBank;

  @override
  Widget build(BuildContext context) {
    final tone = OnboardingTone(context);
    final selected = isCustom ? 'Other / Custom' : nameController.text;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: tone.cardBox(borderColor: tone.emerald),
        child: Form(
          key: formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'SLIP ${index + 1} OF $total',
                style: tone.text(
                  11,
                  FontWeight.w700,
                  tone.emeraldDeep,
                  letterSpacing: 0.6,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                'Bank Name',
                style: tone.text(13, FontWeight.w700, tone.ink),
              ),
              const SizedBox(height: 8),
              InputDecorator(
                decoration: _fieldDecoration(
                  tone,
                  hint: '',
                ).copyWith(errorText: bankError),
                isEmpty: selected.isEmpty,
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: selected.isEmpty ? null : selected,
                    isExpanded: true,
                    hint: Text(
                      'Choose a bank',
                      style: tone.text(14, FontWeight.w500, tone.muted),
                    ),
                    items:
                        banks
                            .map(
                              (bank) => DropdownMenuItem(
                                value: bank,
                                child: Text(
                                  bank,
                                  style: tone.text(
                                    14,
                                    FontWeight.w600,
                                    tone.ink,
                                  ),
                                ),
                              ),
                            )
                            .toList(),
                    onChanged: onBank,
                    dropdownColor: tone.card,
                    icon: Icon(
                      LucideIcons.chevronDown,
                      color: tone.slate,
                      size: 18,
                    ),
                  ),
                ),
              ),
              if (isCustom) ...[
                const SizedBox(height: 12),
                TextFormField(
                  controller: customController,
                  style: tone.text(14, FontWeight.w600, tone.ink),
                  decoration: _fieldDecoration(tone, hint: 'Enter bank name'),
                  validator:
                      (value) =>
                          (value == null || value.trim().isEmpty)
                              ? 'Enter bank name'
                              : null,
                ),
              ],
              const SizedBox(height: 12),
              Text(
                'Last 4 optional',
                style: tone.text(13, FontWeight.w700, tone.ink),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: last4Controller,
                keyboardType: TextInputType.number,
                maxLength: 4,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                style: tone.text(
                  16,
                  FontWeight.w700,
                  tone.ink,
                  letterSpacing: 2,
                ),
                decoration: _fieldDecoration(tone, hint: '1234').copyWith(
                  counterText: '',
                  prefixText: '•••• ',
                  prefixStyle: tone.text(16, FontWeight.w600, tone.slate),
                ),
                validator: (value) {
                  final text = value?.trim() ?? '';
                  if (text.isEmpty || text.length == 4) return null;
                  return 'Enter 4 digits or leave blank';
                },
              ),
              const SizedBox(height: 12),
              Text(
                'Starting Balance',
                style: tone.text(13, FontWeight.w700, tone.ink),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: balanceController,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                style: tone.text(16, FontWeight.w700, tone.ink),
                decoration: _fieldDecoration(tone, hint: '0').copyWith(
                  prefixText: '₹ ',
                  prefixStyle: tone.text(16, FontWeight.w700, tone.emeraldDeep),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  InputDecoration _fieldDecoration(
    OnboardingTone tone, {
    required String hint,
  }) {
    return InputDecoration(
      hintText: hint,
      hintStyle: tone.text(14, FontWeight.w500, tone.muted),
      filled: true,
      fillColor: tone.card,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(color: tone.border),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(color: tone.emerald, width: 1.4),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: Color(0xFFE11D48)),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: Color(0xFFE11D48), width: 1.4),
      ),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(color: tone.border),
      ),
    );
  }
}
