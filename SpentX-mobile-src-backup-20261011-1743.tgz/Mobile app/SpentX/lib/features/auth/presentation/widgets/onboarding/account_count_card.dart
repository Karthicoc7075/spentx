import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';

import 'soft_onboarding_widgets.dart';

class OnboardingAccountCountCard extends StatelessWidget {
  final int count;
  final ValueChanged<int> onChanged;
  final VoidCallback onContinue;
  final VoidCallback? onSkip;
  final VoidCallback? onBack;

  /// Skip typing accounts and let SMS propose them instead (Moment 1 in
  /// docs/ACCOUNT_DISCOVERY.md). Null on platforms with no SMS access, where
  /// the option is hidden rather than shown and broken.
  final VoidCallback? onDetectFromSms;

  const OnboardingAccountCountCard({
    super.key,
    required this.count,
    required this.onChanged,
    required this.onContinue,
    this.onSkip,
    this.onBack,
    this.onDetectFromSms,
  });

  @override
  Widget build(BuildContext context) {
    final tone = OnboardingTone(context);
    final label = count == 1 ? '1 bank account' : '$count bank accounts';
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: ListView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.only(bottom: 12),
            children: [
              OnboardingStepHeader(
                step: 1,
                onBack: onBack ?? () => Navigator.of(context).pop(),
                title: 'How many bank accounts?',
                subtitle: "You'll add them next.",
              ),
              const SizedBox(height: 20),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 22,
                ),
                decoration: tone.cardBox(),
                child: Row(
                  children: [
                    _StepButton(
                      icon: LucideIcons.minus,
                      enabled: count > 1,
                      onTap: () => onChanged(count - 1),
                    ),
                    Expanded(
                      child: Column(
                        children: [
                          Text(
                            '$count',
                            style: tone.text(
                              56,
                              FontWeight.w800,
                              tone.ink,
                              height: 1,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            label,
                            style: tone.text(14, FontWeight.w600, tone.slate),
                          ),
                        ],
                      ),
                    ),
                    _StepButton(
                      icon: LucideIcons.plus,
                      enabled: count < 8,
                      onTap: () => onChanged(count + 1),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              const OnboardingShield(
                text: 'Cash is already included and is not listed.',
              ),
            ],
          ),
        ),
        OnboardingPrimaryButton(label: 'Continue', onPressed: onContinue),
        const SizedBox(height: 8),
        Center(
          child: Text(
            'You can adjust this anytime in Settings.',
            textAlign: TextAlign.center,
            style: tone.text(12, FontWeight.w500, tone.slate),
          ),
        ),
        if (onDetectFromSms != null)
          Center(
            child: OnboardingTextButton(
              label: 'Detect from my SMS instead',
              onPressed: onDetectFromSms,
              color: tone.emeraldDeep,
            ),
          ),
        if (onSkip != null)
          Center(
            child: OnboardingTextButton(
              label: 'Skip for now',
              onPressed: onSkip,
            ),
          ),
      ],
    );
  }
}

class _StepButton extends StatelessWidget {
  const _StepButton({
    required this.icon,
    required this.enabled,
    required this.onTap,
  });

  final IconData icon;
  final bool enabled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final tone = OnboardingTone(context);
    return Material(
      color: enabled ? tone.mint : tone.canvas,
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: enabled ? onTap : null,
        child: SizedBox(
          width: 44,
          height: 44,
          child: Icon(
            icon,
            size: 18,
            color: enabled ? tone.emeraldDeep : tone.muted,
          ),
        ),
      ),
    );
  }
}
