import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/soft_palette.dart';
import 'onboarding/soft_onboarding_widgets.dart';

/// Pure PIN-pad UI: 4-digit entry, then confirm, then [onPinConfirmed] with
/// the matched PIN. Caller decides what to do with it (persist + navigate) —
/// this widget does no storage or routing itself, so it's reusable both as
/// the standalone `/pin-setup` route and as an embedded Setup Wizard step.
class PinEntryStep extends StatefulWidget {
  final String title;
  final String subtitle;
  final ValueChanged<String> onPinConfirmed;
  final VoidCallback? onSkip;
  final String skipLabel;

  /// Setup-wizard chrome. The standalone PIN screen leaves this false.
  final bool softStep;
  final int step;

  const PinEntryStep({
    super.key,
    required this.title,
    required this.subtitle,
    required this.onPinConfirmed,
    this.onSkip,
    this.skipLabel = 'Skip for now',
    this.softStep = false,
    this.step = 4,
  });

  @override
  State<PinEntryStep> createState() => _PinEntryStepState();
}

class _PinEntryStepState extends State<PinEntryStep> {
  int _pinLength = 4;
  String _pin = '';
  String _confirmPin = '';
  bool _isConfirming = false;
  String? _error;

  void _onKeyTap(String value) {
    HapticFeedback.lightImpact();
    setState(() => _error = null);
    if (!_isConfirming) {
      if (_pin.length < _pinLength) _pin += value;
      if (!widget.softStep && _pin.length == _pinLength) {
        Future.delayed(const Duration(milliseconds: 300), () {
          if (mounted) setState(() => _isConfirming = true);
        });
      }
    } else {
      if (_confirmPin.length < _pinLength) _confirmPin += value;
      if (!widget.softStep && _confirmPin.length == _pinLength) {
        Future.delayed(const Duration(milliseconds: 300), () {
          if (!mounted) return;
          if (_pin != _confirmPin) {
            setState(() {
              _error = 'PINs do not match. Try again.';
              _pin = '';
              _confirmPin = '';
              _isConfirming = false;
            });
            return;
          }
          widget.onPinConfirmed(_pin);
        });
      }
    }
    setState(() {});
  }

  void _onBackspace() {
    HapticFeedback.lightImpact();
    setState(() {
      _error = null;
      if (!_isConfirming) {
        if (_pin.isNotEmpty) _pin = _pin.substring(0, _pin.length - 1);
      } else if (_confirmPin.isNotEmpty) {
        _confirmPin = _confirmPin.substring(0, _confirmPin.length - 1);
      } else {
        _isConfirming = false;
        _pin = '';
      }
    });
  }

  void _onSoftContinue() {
    if (!_isConfirming) {
      if (_pin.length == _pinLength) {
        setState(() => _isConfirming = true);
      }
      return;
    }
    if (_confirmPin.length < _pinLength) return;
    if (_pin != _confirmPin) {
      setState(() {
        _error = 'PINs do not match. Try again.';
        _pin = '';
        _confirmPin = '';
        _isConfirming = false;
      });
      return;
    }
    widget.onPinConfirmed(_pin);
  }

  @override
  Widget build(BuildContext context) {
    if (widget.softStep) return _buildSoft(context);
    final currentPin = _isConfirming ? _confirmPin : _pin;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Column(
      children: [
        if (widget.onSkip != null)
          Align(
            alignment: Alignment.topRight,
            child: TextButton(
              onPressed: widget.onSkip,
              child: Text(
                widget.skipLabel,
                style: const TextStyle(fontWeight: FontWeight.w500),
              ),
            ),
          ),
        const SizedBox(height: 20),
        Container(
          width: 56,
          height: 56,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [AppColors.primary, AppColors.primaryLight],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(16),
          ),
          child: const Center(
            child: Text(
              'S',
              style: TextStyle(
                color: SoftPalette.ink,
                fontSize: 24,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ),
        const SizedBox(height: 32),
        Text(
          _isConfirming ? 'Confirm your PIN' : widget.title,
          style: Theme.of(context).textTheme.headlineMedium,
        ),
        const SizedBox(height: 8),
        Text(
          _isConfirming ? 'Enter PIN again' : widget.subtitle,
          style: Theme.of(context).textTheme.bodyMedium,
        ),
        if (_error != null) ...[
          const SizedBox(height: 12),
          Text(
            _error!,
            style: const TextStyle(color: AppColors.expense, fontSize: 13),
          ),
        ],
        // Length choice only makes sense before the user starts typing —
        // changing it mid-entry would silently invalidate what's typed so far.
        if (!_isConfirming && _pin.isEmpty) ...[
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _LengthChip(
                label: '4-digit',
                selected: _pinLength == 4,
                onTap: () => setState(() => _pinLength = 4),
              ),
              const SizedBox(width: 10),
              _LengthChip(
                label: '6-digit',
                selected: _pinLength == 6,
                onTap: () => setState(() => _pinLength = 6),
              ),
            ],
          ),
        ],
        const SizedBox(height: 32),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(_pinLength, (index) {
            final isFilled = index < currentPin.length;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.symmetric(horizontal: 14),
              width: isFilled ? 18 : 16,
              height: isFilled ? 18 : 16,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isFilled ? AppColors.primary : Colors.transparent,
                border: Border.all(
                  color: isFilled ? AppColors.primary : SoftPalette.border,
                  width: 2,
                ),
              ),
            );
          }),
        ),
        const Spacer(),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 48),
          child: Column(
            children: [
              for (int row = 0; row < 4; row++) ...[
                if (row > 0) const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    if (row < 3) ...[
                      for (int col = 0; col < 3; col++)
                        _NumKey(
                          label: '${row * 3 + col + 1}',
                          onTap: () => _onKeyTap('${row * 3 + col + 1}'),
                        ),
                    ] else ...[
                      const SizedBox(width: 72),
                      _NumKey(label: '0', onTap: () => _onKeyTap('0')),
                      _NumKey(
                        onTap: _onBackspace,
                        child: Icon(
                          Icons.backspace_outlined,
                          color: isDark ? SoftPalette.muted : SoftPalette.muted,
                          size: 22,
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ],
          ),
        ),
        const SizedBox(height: 48),
      ],
    );
  }

  Widget _buildSoft(BuildContext context) {
    final tone = OnboardingTone(context);
    final currentPin = _isConfirming ? _confirmPin : _pin;
    final continueReady = currentPin.length == _pinLength;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        OnboardingStepHeader(
          step: widget.step,
          title: _isConfirming ? 'Confirm your PIN' : widget.title,
          subtitle: _isConfirming ? 'Enter PIN again' : widget.subtitle,
        ),
        const SizedBox(height: 16),
        if (!_isConfirming && _pin.isEmpty)
          Row(
            children: [
              _LengthChip(
                label: '4-digit',
                selected: _pinLength == 4,
                onTap: () => setState(() => _pinLength = 4),
              ),
              const SizedBox(width: 8),
              _LengthChip(
                label: '6-digit',
                selected: _pinLength == 6,
                onTap: () => setState(() => _pinLength = 6),
              ),
            ],
          ),
        const SizedBox(height: 16),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 22),
          decoration: tone.cardBox(),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(_pinLength, (index) {
              final filled = index < currentPin.length;
              final active = index == currentPin.length && index < _pinLength;
              return Expanded(
                child: Container(
                  height: 64,
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  alignment: Alignment.center,
                  decoration: tone.cardBox(radius: 16),
                  child:
                      filled
                          ? Container(
                            width: 12,
                            height: 12,
                            decoration: BoxDecoration(
                              color: tone.emerald,
                              shape: BoxShape.circle,
                            ),
                          )
                          : active
                          ? Container(
                            width: 2,
                            height: 22,
                            decoration: BoxDecoration(
                              color: tone.emeraldDeep,
                              borderRadius: BorderRadius.circular(2),
                            ),
                          )
                          : null,
                ),
              );
            }),
          ),
        ),
        if (_error != null) ...[
          const SizedBox(height: 10),
          Text(
            _error!,
            style: tone.text(13, FontWeight.w600, const Color(0xFFE11D48)),
          ),
        ],
        const SizedBox(height: 12),
        const OnboardingShield(text: 'You can skip PIN for now.'),
        const Spacer(),
        _SoftKeypad(onKey: _onKeyTap, onBackspace: _onBackspace),
        const SizedBox(height: 16),
        OnboardingPrimaryButton(
          label: 'Continue',
          onPressed: continueReady ? _onSoftContinue : null,
        ),
        if (widget.onSkip != null)
          Center(
            child: OnboardingTextButton(
              label: widget.skipLabel,
              onPressed: widget.onSkip,
            ),
          ),
      ],
    );
  }
}

class _SoftKeypad extends StatelessWidget {
  const _SoftKeypad({required this.onKey, required this.onBackspace});

  final ValueChanged<String> onKey;
  final VoidCallback onBackspace;

  @override
  Widget build(BuildContext context) {
    final tone = OnboardingTone(context);
    Widget key(String label) {
      return _SoftKey(label: label, onTap: () => onKey(label));
    }

    return Column(
      children: [
        for (var row = 0; row < 3; row++) ...[
          if (row > 0) const SizedBox(height: 10),
          Row(
            children: [
              for (var col = 0; col < 3; col++) ...[
                if (col > 0) const SizedBox(width: 10),
                Expanded(child: key('${row * 3 + col + 1}')),
              ],
            ],
          ),
        ],
        const SizedBox(height: 10),
        Row(
          children: [
            const Expanded(child: SizedBox(height: 56)),
            const SizedBox(width: 10),
            Expanded(child: key('0')),
            const SizedBox(width: 10),
            Expanded(
              child: _SoftKey(
                onTap: onBackspace,
                child: Icon(
                  Icons.backspace_outlined,
                  size: 20,
                  color: tone.ink,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _SoftKey extends StatelessWidget {
  const _SoftKey({this.label, this.child, required this.onTap});

  final String? label;
  final Widget? child;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final tone = OnboardingTone(context);
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Ink(
          height: 56,
          decoration: tone.cardBox(radius: 16),
          child: Center(
            child:
                child ??
                Text(
                  label ?? '',
                  style: tone.text(22, FontWeight.w700, tone.ink),
                ),
          ),
        ),
      ),
    );
  }
}

class _LengthChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _LengthChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color:
              selected
                  ? AppColors.primary.withValues(alpha: 0.16)
                  : Colors.transparent,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(
            color: selected ? AppColors.primary : AppSurface.border,
            width: 1,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 12.5,
            fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
            color: selected ? AppColors.primary : AppSurface.subText,
          ),
        ),
      ),
    );
  }
}

class _NumKey extends StatelessWidget {
  final String? label;
  final Widget? child;
  final VoidCallback onTap;

  const _NumKey({this.label, this.child, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 72,
        height: 72,
        decoration: BoxDecoration(
          color:
              label != null
                  ? (isDark ? SoftPalette.card : SoftPalette.surfaceVariant)
                  : Colors.transparent,
          shape: BoxShape.circle,
        ),
        alignment: Alignment.center,
        child:
            child ??
            Text(
              label ?? '',
              style: const TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w400,
                color: SoftPalette.ink,
              ),
            ),
      ),
    );
  }
}
