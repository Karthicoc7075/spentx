import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../../../core/theme/app_colors.dart';

/// Compact biometric indicator used on the lock screen and verification dialogs.
class BiometricUnlockBadge extends StatelessWidget {
  final bool isAuthenticating;
  final bool hasError;
  final String biometricLabel;
  final VoidCallback? onTap;

  const BiometricUnlockBadge({
    super.key,
    this.isAuthenticating = false,
    this.hasError = false,
    this.biometricLabel = 'Biometrics',
    this.onTap,
  });

  static const double ringSize = 104;
  static const double badgeSize = 88;
  static const double iconSize = 36;

  @override
  Widget build(BuildContext context) {
    final accent = hasError
        ? AppColors.expense
        : (isAuthenticating ? AppColors.primaryLight : AppColors.primary);

    final badge = SizedBox(
      width: ringSize,
      height: ringSize,
      child: Stack(
        alignment: Alignment.center,
        children: [
          if (isAuthenticating)
            SizedBox(
              width: ringSize,
              height: ringSize,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: accent.withValues(alpha: 0.65),
              ),
            ),
          AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: badgeSize,
            height: badgeSize,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AppColors.darkCard,
              border: Border.all(
                color: accent.withValues(alpha: hasError ? 0.55 : 0.3),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: accent.withValues(alpha: isAuthenticating ? 0.18 : 0.08),
                  blurRadius: isAuthenticating ? 14 : 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Icon(
              biometricLabel == 'Face ID' ? LucideIcons.scanFace : LucideIcons.fingerprint,
              size: iconSize,
              color: accent,
            ),
          ),
        ],
      ),
    );

    if (onTap == null) return badge;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: isAuthenticating ? null : onTap,
        customBorder: const CircleBorder(),
        child: badge,
      ),
    );
  }
}