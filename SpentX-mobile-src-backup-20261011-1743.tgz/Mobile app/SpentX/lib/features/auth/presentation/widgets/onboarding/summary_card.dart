import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../../../core/services/pin_service.dart';
import '../../../../../models/account_model.dart';
import 'soft_onboarding_widgets.dart';

class OnboardingSummaryCard extends StatelessWidget {
  final List<AccountModel> accounts;
  final List<String> purposes;
  final bool pinEnabled;
  final VoidCallback onComplete;
  final VoidCallback onBack;
  final VoidCallback onEditBanks;

  const OnboardingSummaryCard({
    super.key,
    required this.accounts,
    required this.purposes,
    required this.pinEnabled,
    required this.onComplete,
    required this.onBack,
    required this.onEditBanks,
  });

  String _money(num value) {
    return NumberFormat.currency(
      locale: 'en_IN',
      symbol: '₹',
      decimalDigits: 0,
    ).format(value.abs());
  }

  @override
  Widget build(BuildContext context) {
    final tone = OnboardingTone(context);
    final banks = accounts.where((account) => account.type == 'Bank').toList();
    final cashTotal = accounts
        .where((account) => account.isCash)
        .fold<double>(0, (sum, account) => sum + account.openingBalance);
    final bankTotal = banks.fold<double>(
      0,
      (sum, account) => sum + account.openingBalance,
    );
    final ledgerTotal = accounts.fold<double>(
      0,
      (sum, account) => sum + account.openingBalance,
    );
    final accountLabel =
        banks.length == 1 ? '1 account' : '${banks.length} accounts';
    final pills = <String>[
      ...purposes,
      if (pinEnabled) 'PIN',
      if (PinService.fingerprintEnabled) 'Fingerprint',
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: ListView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.only(bottom: 12),
            children: [
              OnboardingStepHeader(
                step: 6,
                onBack: onBack,
                title: 'Looks good?',
                subtitle: "Check once, then you're set.",
              ),
              const SizedBox(height: 18),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: tone.cardBox(),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        for (final pill in pills)
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 6,
                            ),
                            decoration: BoxDecoration(
                              color: tone.mint,
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: Text(
                              pill,
                              style: tone.text(
                                12,
                                FontWeight.w700,
                                tone.emeraldDeep,
                              ),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(
                      '$accountLabel · ${_money(bankTotal)}',
                      style: tone.text(16, FontWeight.w800, tone.ink),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              OnboardingShield(
                text:
                    'Cash is already included and is not listed. · ${_money(cashTotal)}',
              ),
              const SizedBox(height: 16),
              Text(
                'CONNECTED BANKS',
                style: tone.text(
                  12,
                  FontWeight.w700,
                  tone.slate,
                  letterSpacing: 0.6,
                ),
              ),
              const SizedBox(height: 10),
              if (banks.isEmpty)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: tone.cardBox(),
                  child: Text(
                    'No banks added',
                    style: tone.text(14, FontWeight.w600, tone.slate),
                  ),
                )
              else
                for (final bank in banks)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Container(
                      padding: const EdgeInsets.all(14),
                      decoration: tone.cardBox(),
                      child: Row(
                        children: [
                          Container(
                            width: 40,
                            height: 40,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: tone.mint,
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: Text(
                              bank.name.trim().isEmpty
                                  ? '?'
                                  : bank.name.trim()[0].toUpperCase(),
                              style: tone.text(
                                16,
                                FontWeight.w800,
                                tone.emeraldDeep,
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  bank.name,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: tone.text(
                                    14,
                                    FontWeight.w700,
                                    tone.ink,
                                  ),
                                ),
                                Text(
                                  bank.last4Digits.trim().isEmpty
                                      ? '••••'
                                      : '•••• ${bank.last4Digits.trim()}',
                                  style: tone.text(
                                    12,
                                    FontWeight.w600,
                                    tone.slate,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Text(
                            _money(bank.openingBalance),
                            style: tone.text(14, FontWeight.w800, tone.ink),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: tone.mint,
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: Text(
                              'Active',
                              style: tone.text(
                                11,
                                FontWeight.w700,
                                tone.emeraldDeep,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
              const SizedBox(height: 6),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: tone.cardBox(),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        'Ledger total',
                        style: tone.text(14, FontWeight.w700, tone.slate),
                      ),
                    ),
                    Text(
                      _money(ledgerTotal),
                      style: tone.text(20, FontWeight.w800, tone.ink),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        OnboardingPrimaryButton(label: 'Finish setup', onPressed: onComplete),
        Center(
          child: OnboardingTextButton(
            label: 'Edit banks',
            onPressed: onEditBanks,
          ),
        ),
      ],
    );
  }
}
