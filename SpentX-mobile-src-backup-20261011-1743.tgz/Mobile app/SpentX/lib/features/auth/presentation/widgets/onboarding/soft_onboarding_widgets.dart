import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lucide_icons/lucide_icons.dart';

import '../../../../../core/theme/soft_palette.dart';

/// Shared Soft Soft chrome for the six setup steps.
class OnboardingTone {
  OnboardingTone(this.context);

  final BuildContext context;

  bool get dark => Theme.of(context).brightness == Brightness.dark;

  Color get canvas => dark ? SoftPalette.darkBg : const Color(0xFFF8FAFC);
  Color get card => dark ? SoftPalette.darkCard : const Color(0xFFFFFFFF);
  Color get border => dark ? SoftPalette.darkBorder : const Color(0xFFF1F5F9);
  Color get ink => dark ? SoftPalette.darkInk : const Color(0xFF0F172A);
  Color get slate => dark ? SoftPalette.darkMuted : const Color(0xFF64748B);
  Color get muted => dark ? SoftPalette.darkFaint : const Color(0xFF94A3B8);
  Color get emerald => dark ? SoftPalette.darkEmerald : const Color(0xFF10B981);
  Color get emeraldDeep =>
      dark ? SoftPalette.darkEmerald : const Color(0xFF059669);
  Color get mint =>
      dark ? SoftPalette.darkEmeraldSoft : const Color(0xFFECFDF5);

  List<BoxShadow> get shadow =>
      dark
          ? const []
          : const [
            BoxShadow(
              color: Color.fromRGBO(15, 23, 42, 0.04),
              offset: Offset(0, 4),
              blurRadius: 16,
              spreadRadius: -2,
            ),
          ];

  TextStyle text(
    double size,
    FontWeight weight,
    Color color, {
    double? letterSpacing,
    double? height,
  }) {
    return GoogleFonts.plusJakartaSans(
      fontSize: size,
      fontWeight: weight,
      color: color,
      letterSpacing: letterSpacing,
      height: height,
    );
  }

  BoxDecoration cardBox({Color? fill, double radius = 24, Color? borderColor}) {
    return BoxDecoration(
      color: fill ?? card,
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: borderColor ?? border),
      boxShadow: shadow,
    );
  }
}

class OnboardingBackButton extends StatelessWidget {
  const OnboardingBackButton({super.key, required this.onPressed});

  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final tone = OnboardingTone(context);
    return Material(
      color: tone.card,
      elevation: 0,
      shadowColor: Colors.transparent,
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onPressed,
        child: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: tone.card,
            boxShadow: tone.dark
                ? null
                : const [
                    BoxShadow(
                      color: Color(0x0F050D1A),
                      blurRadius: 16,
                      offset: Offset(0, 4),
                    ),
                  ],
            border: tone.dark ? Border.all(color: tone.border) : null,
          ),
          child: Icon(
            Icons.arrow_back_ios_new_rounded,
            size: 16,
            color: tone.ink,
          ),
        ),
      ),
    );
  }
}

class OnboardingStepPill extends StatelessWidget {
  const OnboardingStepPill({super.key, required this.step});

  final int step;

  @override
  Widget build(BuildContext context) {
    final tone = OnboardingTone(context);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: tone.mint,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        'STEP $step/6',
        style: tone.text(
          11,
          FontWeight.w700,
          tone.emeraldDeep,
          letterSpacing: 0.6,
        ),
      ),
    );
  }
}

class OnboardingProgress extends StatelessWidget {
  const OnboardingProgress({super.key, required this.step});

  final int step;

  @override
  Widget build(BuildContext context) {
    final tone = OnboardingTone(context);
    return Row(
      children: List.generate(6, (index) {
        final filled = index < step;
        return Expanded(
          child: Container(
            height: 4,
            margin: const EdgeInsets.symmetric(horizontal: 2),
            decoration: BoxDecoration(
              color: filled ? tone.emerald : tone.border,
              borderRadius: BorderRadius.circular(999),
            ),
          ),
        );
      }),
    );
  }
}

class OnboardingStepHeader extends StatelessWidget {
  const OnboardingStepHeader({
    super.key,
    required this.step,
    this.onBack,
    required this.title,
    required this.subtitle,
  });

  final int step;
  final VoidCallback? onBack;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    final tone = OnboardingTone(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            if (onBack != null) ...[
              OnboardingBackButton(onPressed: onBack!),
              const SizedBox(width: 12),
            ],
            OnboardingStepPill(step: step),
          ],
        ),
        const SizedBox(height: 14),
        OnboardingProgress(step: step),
        const SizedBox(height: 18),
        Text(
          title,
          style: tone.text(26, FontWeight.w800, tone.ink, height: 1.15),
        ),
        const SizedBox(height: 6),
        Text(
          subtitle,
          style: tone.text(14, FontWeight.w500, tone.slate, height: 1.4),
        ),
      ],
    );
  }
}

class OnboardingShield extends StatelessWidget {
  const OnboardingShield({super.key, required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    final tone = OnboardingTone(context);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: tone.mint,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: tone.border),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(LucideIcons.shield, size: 18, color: tone.emeraldDeep),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: tone.text(13, FontWeight.w600, tone.ink, height: 1.4),
            ),
          ),
        ],
      ),
    );
  }
}

class OnboardingPrimaryButton extends StatelessWidget {
  const OnboardingPrimaryButton({
    super.key,
    required this.label,
    required this.onPressed,
  });

  final String label;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    final tone = OnboardingTone(context);
    final enabled = onPressed != null;
    return SizedBox(
      width: double.infinity,
      height: 56,
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient:
              enabled
                  ? SoftColors.primaryGradient
                  : null,
          color: enabled ? null : tone.card,
          borderRadius: BorderRadius.circular(22),
          border: enabled ? null : Border.all(color: tone.border),
          boxShadow:
              enabled && !tone.dark
                  ? const [
                    BoxShadow(
                      color: Color(0x33047857),
                      offset: Offset(0, 10),
                      blurRadius: 24,
                    ),
                  ]
                  : null,
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: onPressed,
            borderRadius: BorderRadius.circular(22),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  label,
                  style: tone.text(
                    16,
                    FontWeight.w700,
                    enabled ? Colors.white : tone.muted,
                  ),
                ),
                const SizedBox(width: 8),
                Icon(
                  LucideIcons.arrowRight,
                  size: 18,
                  color: enabled ? Colors.white : tone.muted,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class OnboardingTextButton extends StatelessWidget {
  const OnboardingTextButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.color,
  });

  final String label;
  final VoidCallback? onPressed;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final tone = OnboardingTone(context);
    return TextButton(
      onPressed: onPressed,
      child: Text(
        label,
        style: tone.text(14, FontWeight.w700, color ?? tone.slate),
      ),
    );
  }
}
