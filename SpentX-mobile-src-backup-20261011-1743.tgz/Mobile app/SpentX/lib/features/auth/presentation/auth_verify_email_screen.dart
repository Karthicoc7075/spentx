import 'dart:async';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../core/services/auth_service.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/soft_palette.dart';
import 'widgets/auth_widgets.dart';

const _resendCooldownSeconds = 45;

/// `/auth/verify-email` — link-based signup confirmation waiting screen.
///
/// No OTP entry: the user confirms via the link in the email, which reopens
/// the app through the `spentx://auth/callback` deep link (Android intent
/// filter) — supabase_flutter consumes the tokens from that link and
/// establishes a session automatically, which this screen picks up via
/// [AuthService.onAuthStateChange] and continues into the app from.
///
/// Reached two ways:
/// • Pushed right after signup with the email as `extra`.
/// • The router `redirect` sending a not-yet-confirmed, not-signed-in user
///   back here on any cold start/deep link — no `extra` in that case, so it
///   falls back to [AuthService.pendingVerificationEmail].
class AuthVerifyEmailScreen extends StatefulWidget {
  final String? email;
  final bool verified;

  const AuthVerifyEmailScreen({super.key, this.email, this.verified = false});

  @override
  State<AuthVerifyEmailScreen> createState() => _AuthVerifyEmailScreenState();
}

class _AuthVerifyEmailScreenState extends State<AuthVerifyEmailScreen> {
  late final String _email;
  late final bool _isReopened;
  StreamSubscription<dynamic>? _authSub;

  bool _verified = false;
  bool _resending = false;
  String? _error;
  Timer? _cooldownTimer;
  int _secondsLeft = _resendCooldownSeconds;

  @override
  void initState() {
    super.initState();
    // No `extra` means this screen was reached via the router redirect (a
    // cold start/deep link finding a still-pending signup), not a fresh
    // "Create Account" submit.
    _isReopened = widget.email == null && !widget.verified;
    _email = widget.email ??
        AuthService.pendingVerificationEmail ??
        '';
    _verified = widget.verified || AuthService.verifiedAwaitingLogin;
    _startCooldown();
    // The confirmation link signs the user in underneath this screen.
    // Do NOT continue into the app — show "verified, now login" here.
    _authSub = AuthService.onAuthStateChange((signedIn) {
      if (!mounted || !signedIn) return;
      if (AuthService.passwordSignInInProgress) return;
      _showVerified();
    });
  }

  @override
  void dispose() {
    _cooldownTimer?.cancel();
    _authSub?.cancel();
    super.dispose();
  }

  void _startCooldown() {
    setState(() => _secondsLeft = _resendCooldownSeconds);
    _cooldownTimer?.cancel();
    _cooldownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      if (_secondsLeft <= 1) {
        timer.cancel();
        setState(() => _secondsLeft = 0);
      } else {
        setState(() => _secondsLeft -= 1);
      }
    });
  }

  void _showVerified() {
    if (_verified) return;
    setState(() => _verified = true);
  }

  Future<void> _goToSignIn() async {
    AuthService.clearVerifiedAwaitingLogin();
    AuthService.clearPendingVerificationEmail();
    if (AuthService.isSignedIn) {
      await AuthService.signOutSessionOnly();
    }
    if (!mounted) return;
    context.go('/auth/login');
  }

  Future<void> _openEmailApp() async {
    try {
      await launchUrl(Uri(scheme: 'mailto'));
    } catch (_) {
      if (!mounted) return;
      setState(() => _error = 'Could not open an email app on this device.');
    }
  }

  Future<void> _resend() async {
    if (_resending || _secondsLeft > 0 || _email.isEmpty) return;
    setState(() {
      _resending = true;
      _error = null;
    });
    try {
      await AuthService.resendConfirmationEmail(_email);
      if (!mounted) return;
      setState(() => _resending = false);
      _startCooldown();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Verification email re-sent.'),
          behavior: SnackBarBehavior.floating,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _resending = false;
        _error = AuthService.friendlyError(e);
      });
    }
  }

  void _changeEmail() {
    AuthService.clearPendingVerificationEmail();
    context.go('/auth/signup');
  }

  @override
  Widget build(BuildContext context) {
    if (_verified) {
      final isDarkV = Theme.of(context).brightness == Brightness.dark;
      return Scaffold(
        backgroundColor: isDarkV ? SoftPalette.darkBg : SoftPalette.bg,
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(28, 24, 28, 28),
            child: Column(
              children: [
                const Spacer(),
                const Icon(Icons.check_circle_rounded,
                    color: SoftPalette.positive, size: 56),
                const SizedBox(height: 20),
                Text(
                  'Your mail is verified',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: AppSurface.text,
                    fontSize: 22,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  'Now login to SpentX with the email and password you just created.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: AppSurface.subText,
                    fontSize: 14,
                    height: 1.4,
                  ),
                ),
                const Spacer(),
                AuthPrimaryButton(label: 'SIGN IN', onPressed: () { _goToSignIn(); }),
              ],
            ),
          ),
        ),
      );
    }

    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      backgroundColor: isDark ? SoftPalette.darkBg : SoftPalette.bg,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(28, 12, 28, 28),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Center(
                  child: AuthBrandHeader(logoSize: 56, showTagline: false)),
              const SizedBox(height: 28),
              Text(
                _isReopened ? 'Email Not Verified' : 'Verify your email',
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: AppSurface.text,
                    fontSize: 20,
                    fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 8),
              Text(
                _isReopened
                    ? 'Please verify your email to continue.'
                    : "We've sent a verification email to",
                textAlign: TextAlign.center,
                style: TextStyle(color: AppSurface.subText, fontSize: 13),
              ),
              const SizedBox(height: 4),
              Text(
                _email,
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: AppSurface.text,
                    fontSize: 14,
                    fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 12),
              Text(
                'Open your email and tap "Confirm email address" — this '
                'screen updates automatically once you do.',
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: AppSurface.faint, fontSize: 12.5, height: 1.4),
              ),
              const SizedBox(height: 28),
              AuthErrorBanner(message: _error),
              AuthPrimaryButton(label: 'OPEN EMAIL APP', onPressed: _openEmailApp),
              const SizedBox(height: 16),
              Center(
                child: _secondsLeft > 0
                    ? Text(
                        'Resend Email (${_secondsLeft}s)',
                        style: TextStyle(color: AppSurface.faint, fontSize: 13),
                      )
                    : TextButton(
                        onPressed: _resending ? null : _resend,
                        child: Text(_resending ? 'Sending…' : 'Resend Email'),
                      ),
              ),
              Center(
                child: TextButton(
                  onPressed: _goToSignIn,
                  child: const Text('Already verified? Sign in'),
                ),
              ),
              Center(
                child: GestureDetector(
                  onTap: _changeEmail,
                  child: Text(
                    'Change Email',
                    style: TextStyle(
                        color: SoftPalette.emerald,
                        fontSize: 13,
                        fontWeight: FontWeight.w500),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
