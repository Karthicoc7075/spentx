import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../../../core/services/app_reset_service.dart';
import '../../../core/services/auth_service.dart';
import '../../../core/services/auth_gated_services.dart';
import '../../../core/sync/sync_service.dart';
import '../../../core/theme/spentx_tokens.dart';

/// Post-auth routing shared by signup and login.
class AuthFlow {
  AuthFlow._();

  /// Where to go after a successful signup/login.
  ///
  /// NOTE: whether onboarding shows is decided by the SERVER check
  /// ([AuthService.resolveAccountHasData]) in [continueAfterAuth], not by the
  /// local flag alone — a returning user on a new device must never see
  /// onboarding again. The local flag here only routes devices that already
  /// resolved the question.
  static String postAuthRoute() {
    final settings = Hive.box('settings');
    final setupDone =
        settings.get(AuthService.accountHasDataKey) == true ||
        settings.get('has_seen_onboarding', defaultValue: false) == true;
    if (!setupDone) return '/onboarding';
    if (settings.get(AuthService.permissionsPromptPendingKey) == true) {
      return '/onboarding?resume=permissions';
    }
    final hasPin = settings.get('has_pin', defaultValue: false) == true;
    final lockEnabled =
        settings.get('lock_screen_enabled', defaultValue: true) == true;
    return (hasPin && lockEnabled) ? '/lock' : '/home';
  }

  /// Server-gated routing after a FRESH login/signup: if the account already
  /// has data beyond the handle_new_user seed, skip onboarding entirely
  /// (even on a brand-new device) and let the sync pull populate Hive.
  static Future<String> _gatedPostAuthRoute() async {
    final settings = Hive.box('settings');
    final hasData =
        await AuthService.resolveAccountHasData(freshLogin: true);

    // Always write the live result, not just when true — a genuinely new
    // account (hasData == false) must overwrite any stale `true` left in
    // Hive by a PREVIOUS, different account that onboarded on this same
    // device, otherwise this fresh account silently inherits that account's
    // "already onboarded" flag and skips the wizard entirely.
    if (hasData != null) {
      await settings.put('has_seen_onboarding', hasData);
      if (hasData) {
        // Also clear "how many bank accounts" home modal flag.
        await settings.put('isFirstTimeUser', false);
      }
    }
    // hasData == null → server unreachable and no trustworthy cache: fall
    // back to the local flag; idempotent ids + non-destructive onboarding
    // make the worst case safe.
    return postAuthRoute();
  }

  /// Continues into the app after a successful sign-in/sign-up.
  ///
  /// If a DIFFERENT account signs in on a device that still has a previous
  /// account's local data, the user gets an explicit choice — keep the local
  /// data (it will belong to this account from now on) or erase and start
  /// fresh. Never silently merges, never silently wipes.
  static Future<void> continueAfterAuth(BuildContext context) async {
    // Hold sync before the dialog. The auth listener also arms this, but
    // doing it here covers a sign-in that reaches this method first.
    AuthService.armAccountSwitchHoldIfNeeded();
    if (AuthService.isDifferentAccountWithLocalData() ||
        AuthService.syncHeldForAccountSwitch) {
      final prevEmail = AuthService.previousAccountEmail();
      final summary = AuthService.localDataSummary();
      // Where the data came from is only knowable when an account signed in
      // here before. Claiming "a previous account" when none is on record
      // would be a guess, so that case says what is true instead.
      final origin = prevEmail.isNotEmpty
          ? 'from a previous account ($prevEmail)'
          : 'left over on this device';

      final choice = await showDialog<String>(
        context: context,
        barrierDismissible: false,
        builder: (ctx) {
          final t = ctx.tokens;
          return AlertDialog(
            backgroundColor: t.card,
            surfaceTintColor: Colors.transparent,
            shape: RoundedRectangleBorder(borderRadius: AppRadius.cardR),
            title: Text(
              'Existing data on this device',
              style: AppType.section(t.textPrimary),
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'SpentX found data $origin.',
                  style: AppType.body(t.textSecondary),
                ),
                if (summary.isNotEmpty) ...[
                  const SizedBox(height: AppSpacing.sm),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(
                      horizontal: AppSpacing.sm,
                      vertical: AppSpacing.xs,
                    ),
                    decoration: BoxDecoration(
                      color: t.field,
                      borderRadius: AppRadius.tileR,
                    ),
                    child: Text(
                      summary,
                      style: AppType.label(t.textPrimary)
                          .copyWith(fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
                const SizedBox(height: AppSpacing.sm),
                Text(
                  'Keep it if this is yours — it will belong to the account '
                  'you just signed in with. Erase it if you are starting '
                  'fresh; this cannot be undone.',
                  style: AppType.body(t.textSecondary),
                ),
              ],
            ),
            actionsAlignment: MainAxisAlignment.spaceBetween,
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, 'erase'),
                style: TextButton.styleFrom(foregroundColor: t.negative),
                child: const Text('Erase & start fresh'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(ctx, 'keep'),
                style: TextButton.styleFrom(foregroundColor: t.primary),
                child: const Text('Keep it'),
              ),
            ],
          );
        },
      );

      if (choice == 'erase') {
        await AppResetService.resetLocalDataKeepSession();
      }
      // 'keep' or dismissed: local data belongs to the currently signed in account.
    }

    await AuthService.releaseAccountSwitchHold();
    AuthService.rememberCurrentUser();
    // Sync starts only after Keep or Erase. Starting it earlier would push
    // the previous account's local queue to this account.
    await AuthGatedServices.start();

    // If local storage is empty (fresh login after logout or new install),
    // wait for initial server sync with an elegant branded loading animation
    // so Home never flashes empty zeroes.
    if (SyncService.hasNoLocalCache && context.mounted) {
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        useRootNavigator: true,
        builder: (ctx) => const _AuthPostLoginSyncDialog(),
      );
    }

    final route = await _gatedPostAuthRoute();
    if (context.mounted) context.go(route);
  }
}

class _AuthPostLoginSyncDialog extends StatefulWidget {
  const _AuthPostLoginSyncDialog();

  @override
  State<_AuthPostLoginSyncDialog> createState() =>
      _AuthPostLoginSyncDialogState();
}

class _AuthPostLoginSyncDialogState extends State<_AuthPostLoginSyncDialog>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulseCtrl;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);
    _performInitialSync();
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    super.dispose();
  }

  Future<void> _performInitialSync() async {
    try {
      await SyncService.fullSync(force: true).timeout(
        const Duration(seconds: 8),
      );
    } catch (_) {}
    if (mounted) {
      Navigator.of(context, rootNavigator: true).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = isDark ? const Color(0xFF0F172A) : const Color(0xFFF8FAFC);
    final textPrimary = isDark ? Colors.white : const Color(0xFF0F172A);
    final textSecondary =
        isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: bg,
        body: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                AnimatedBuilder(
                  animation: _pulseCtrl,
                  builder: (context, child) {
                    final scale = 1.0 + (_pulseCtrl.value * 0.08);
                    final opacity = 0.4 + (_pulseCtrl.value * 0.6);
                    return Transform.scale(
                      scale: scale,
                      child: Container(
                        width: 84,
                        height: 84,
                        decoration: BoxDecoration(
                          color: const Color(0xFF10B981).withValues(alpha: 0.15),
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: const Color(
                                0xFF10B981,
                              ).withValues(alpha: 0.25 * opacity),
                              blurRadius: 28,
                              spreadRadius: 4,
                            ),
                          ],
                        ),
                        child: const Center(
                          child: Icon(
                            Icons.sync_rounded,
                            size: 42,
                            color: Color(0xFF10B981),
                          ),
                        ),
                      ),
                    );
                  },
                ),
                const SizedBox(height: 32),
                Text(
                  'Setting up your workspace',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                    color: textPrimary,
                    letterSpacing: -0.4,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Restoring your accounts, budgets, and transactions...',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    color: textSecondary,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 32),
                SizedBox(
                  width: 140,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: const LinearProgressIndicator(
                      backgroundColor: Color(0x2010B981),
                      valueColor: AlwaysStoppedAnimation<Color>(
                        Color(0xFF10B981),
                      ),
                      minHeight: 4,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
