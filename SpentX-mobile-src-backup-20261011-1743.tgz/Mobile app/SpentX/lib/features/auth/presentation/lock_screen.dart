import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:local_auth/local_auth.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../core/services/pin_service.dart';
import '../../../core/sync/sync_service.dart';
import 'widgets/biometric_unlock_badge.dart';

/// Full-screen app lock with PIN entry and biometric unlock.
class LockScreen extends StatefulWidget {
  final String redirectTo;
  const LockScreen({super.key, this.redirectTo = '/home'});

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> with SingleTickerProviderStateMixin {
  static const double _horizontalPadding = 24;

  String _pin = '';
  bool _hasError = false;
  bool _bioError = false;
  bool _autoPrompted = false;
  bool _isAuthenticating = false;
  bool _usePinFallback = false;

  late final AnimationController _shakeController;
  late final Animation<double> _shakeAnim;
  final LocalAuthentication _localAuth = LocalAuthentication();

  bool _biometricsAvailable = false;
  List<BiometricType> _availableTypes = [];
  bool _checkingForgotPin = false;
  Timer? _lockoutTimer;

  @override
  void initState() {
    super.initState();
    _shakeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _shakeAnim = Tween<double>(begin: 0, end: 10).animate(
      CurvedAnimation(parent: _shakeController, curve: Curves.elasticIn),
    );
    _checkBiometrics();
    if (PinService.isLockedOut) _ensureLockoutTicker();
    // If web already requested reset while this screen is open, apply quickly.
    unawaited(_tryApplyWebPinReset(silent: true));
  }

  Future<void> _tryApplyWebPinReset({bool silent = false}) async {
    if (_checkingForgotPin) return;
    setState(() => _checkingForgotPin = true);
    try {
      final cleared = await SyncService.checkAndApplyPinReset();
      if (!mounted) return;
      if (cleared || PinService.forcePinSetup || !PinService.hasPin) {
        context.go('/pin-setup');
        return;
      }
      if (!silent && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'No web reset found. On spentx web → Settings → Security → Reset mobile app PIN, then try again online.',
            ),
            behavior: SnackBarBehavior.floating,
            duration: Duration(seconds: 5),
          ),
        );
      }
    } catch (_) {
      if (!silent && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Need internet to apply a web PIN reset. Try again when online.'),
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _checkingForgotPin = false);
    }
  }

  void _ensureLockoutTicker() {
    _lockoutTimer ??= Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      if (!PinService.isLockedOut) {
        _lockoutTimer?.cancel();
        _lockoutTimer = null;
      }
      setState(() {});
    });
  }

  @override
  void dispose() {
    _lockoutTimer?.cancel();
    _shakeController.dispose();
    super.dispose();
  }

  Future<void> _checkBiometrics() async {
    try {
      final supported = await _localAuth.isDeviceSupported();
      final canCheck = await _localAuth.canCheckBiometrics;
      final types = supported ? await _localAuth.getAvailableBiometrics() : <BiometricType>[];
      final available = supported && (canCheck || types.isNotEmpty);

      if (!mounted) return;
      setState(() {
        _biometricsAvailable = available;
        _availableTypes = types;
      });

      if (available &&
          PinService.hasPin &&
          PinService.lockEnabled &&
          PinService.fingerprintEnabled &&
          !_autoPrompted) {
        _autoPrompted = true;
        Future.delayed(const Duration(milliseconds: 450), () {
          if (mounted) _onBiometric(auto: true);
        });
      }
    } catch (_) {}
  }

  String get _biometricLabel {
    final hasFace = _availableTypes.contains(BiometricType.face);
    final hasFingerprint = _availableTypes.contains(BiometricType.fingerprint);

    if (hasFace && hasFingerprint) return 'Biometrics';
    if (hasFace) return 'Face ID';
    if (hasFingerprint) return 'Fingerprint';
    return 'Biometrics';
  }

  void _fail() {
    HapticFeedback.heavyImpact();
    setState(() {
      _hasError = true;
      _bioError = false;
      _pin = '';
    });
    _shakeController.forward(from: 0);
    _clearErrorAfterDelay(() => _hasError, () => _hasError = false);
  }

  void _clearErrorAfterDelay(bool Function() getter, VoidCallback clear) {
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted && getter()) setState(clear);
    });
  }

  void _unlock() {
    PinService.lastUnlockedAt = DateTime.now();
    HapticFeedback.mediumImpact();
    context.go(widget.redirectTo);
  }

  void _onKeyTap(String value) {
    if (PinService.isLockedOut) {
      _ensureLockoutTicker();
      setState(() {
        _hasError = true;
        _pin = '';
      });
      return;
    }
    HapticFeedback.lightImpact();
    final pinLength = PinService.pinLength;
    if (_pin.length >= pinLength) return;

    setState(() {
      _hasError = false;
      _bioError = false;
      _pin += value;
    });

    if (_pin.length == pinLength) {
      Future.delayed(const Duration(milliseconds: 180), () {
        if (!mounted) return;
        if (PinService.verifyPin(_pin)) {
          _lockoutTimer?.cancel();
          _unlock();
        } else {
          _fail();
          if (PinService.isLockedOut) _ensureLockoutTicker();
        }
      });
    }
  }

  void _onBackspace() {
    HapticFeedback.lightImpact();
    if (_pin.isEmpty) return;
    setState(() {
      _hasError = false;
      _pin = _pin.substring(0, _pin.length - 1);
    });
  }

  Future<void> _onBiometric({bool auto = false}) async {
    if (!PinService.hasPin) {
      _unlock();
      return;
    }
    if (!_biometricsAvailable) {
      if (!auto && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Biometrics unavailable — use your PIN'),
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
      return;
    }
    if (_isAuthenticating) return;

    HapticFeedback.mediumImpact();
    setState(() {
      _isAuthenticating = true;
      _bioError = false;
      _hasError = false;
    });

    PinService.isAuthenticatingBiometrically = true;

    try {
      final authenticated = await _localAuth.authenticate(
        localizedReason: 'Unlock SpentX with $_biometricLabel',
        options: const AuthenticationOptions(
          biometricOnly: false,
          stickyAuth: true,
          useErrorDialogs: true,
        ),
      );

      if (!mounted) return;
      if (authenticated) {
        _unlock();
      } else {
        setState(() => _bioError = true);
        HapticFeedback.heavyImpact();
        _clearErrorAfterDelay(() => _bioError, () => _bioError = false);
      }
    } on PlatformException catch (e) {
      if (!mounted) return;
      final code = e.code.toLowerCase();
      final message = (e.message ?? '').toLowerCase();
      final cancelled = code.contains('cancel') ||
          code.contains('abort') ||
          message.contains('cancel') ||
          message.contains('abort');

      if (!cancelled) {
        setState(() => _bioError = true);
        HapticFeedback.heavyImpact();
        _clearErrorAfterDelay(() => _bioError, () => _bioError = false);
      }
    } finally {
      if (mounted) setState(() => _isAuthenticating = false);
      Future.delayed(const Duration(milliseconds: 500), () {
        PinService.isAuthenticatingBiometrically = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!PinService.hasPin || !PinService.lockEnabled) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) context.go(widget.redirectTo);
      });
    }

    final isBiometricMode =
        PinService.fingerprintEnabled && _biometricsAvailable && !_usePinFallback;

    return Scaffold(
      backgroundColor: Theme.of(context).brightness == Brightness.dark
          ? SoftPalette.darkBg
          : SoftPalette.bg,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: _horizontalPadding),
              child: Column(
                children: [
                  const SizedBox(height: 12),
                  _LockHeader(
                    isBiometricMode: isBiometricMode,
                    bioError: _bioError,
                    pinError: _hasError || PinService.isLockedOut,
                    biometricLabel: _biometricLabel,
                    lockoutSeconds: PinService.lockoutRemaining.inSeconds,
                  ),
                  Expanded(
                    child: Center(
                      child: isBiometricMode
                          ? BiometricUnlockBadge(
                              isAuthenticating: _isAuthenticating,
                              hasError: _bioError,
                              biometricLabel: _biometricLabel,
                              onTap: () => _onBiometric(),
                            )
                          : _PinDots(
                              filledCount: _pin.length,
                              totalCount: PinService.pinLength,
                              hasError: _hasError,
                              shakeAnim: _shakeAnim,
                              shakeController: _shakeController,
                            ),
                    ),
                  ),
                  _LockActions(
                    isBiometricMode: isBiometricMode,
                    isAuthenticating: _isAuthenticating,
                    biometricsAvailable: _biometricsAvailable,
                    biometricLabel: _biometricLabel,
                    onBiometric: () => _onBiometric(),
                    onUsePin: () => setState(() {
                      _usePinFallback = true;
                      _bioError = false;
                      _hasError = false;
                    }),
                    onUseBiometric: () {
                      setState(() {
                        _usePinFallback = false;
                        _bioError = false;
                        _hasError = false;
                      });
                      _onBiometric();
                    },
                    onKeyTap: _onKeyTap,
                    onBackspace: _onBackspace,
                  ),
                  TextButton(
                    onPressed: _checkingForgotPin
                        ? null
                        : () => _tryApplyWebPinReset(silent: false),
                    child: Text(
                      _checkingForgotPin
                          ? 'Checking web reset…'
                          : 'Forgot PIN? Reset from web',
                      style: TextStyle(
                        color: AppSurface.subText.withValues(alpha: 0.9),
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  SizedBox(height: MediaQuery.paddingOf(context).bottom > 0 ? 8 : 20),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

// ── Header ────────────────────────────────────────────────────────────────────

class _LockHeader extends StatelessWidget {
  final bool isBiometricMode;
  final bool bioError;
  final bool pinError;
  final String biometricLabel;
  final int lockoutSeconds;

  const _LockHeader({
    required this.isBiometricMode,
    required this.bioError,
    required this.pinError,
    required this.biometricLabel,
    required this.lockoutSeconds,
  });

  @override
  Widget build(BuildContext context) {
    final subtitle = _subtitle;
    final showError = isBiometricMode ? bioError : pinError;

    return Column(
      children: [
        _AppMark(),
        const SizedBox(height: 20),
        Text(
          'Welcome back',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                color: AppSurface.text,
                fontWeight: FontWeight.w500,
                letterSpacing: -0.3,
              ),
        ),
        const SizedBox(height: 8),
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 220),
          child: Text(
            subtitle,
            key: ValueKey(subtitle),
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: showError ? SoftPalette.negative : AppSurface.subText,
                  fontWeight: FontWeight.w500,
                  height: 1.35,
                ),
          ),
        ),
      ],
    );
  }

  String get _subtitle {
    if (isBiometricMode) {
      if (bioError) return '$biometricLabel not recognized — try again';
      return 'Confirm your identity to continue';
    }
    if (lockoutSeconds > 0) {
      return 'Too many attempts. Try again in ${lockoutSeconds}s';
    }
    if (pinError) return 'Incorrect PIN — try again';
    return 'Enter your ${PinService.pinLength}-digit PIN';
  }
}

class _AppMark extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 56,
      height: 56,
      decoration: BoxDecoration(
        color: SoftPalette.emeraldSoft,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: SoftPalette.mint.withValues(alpha: 0.35)),
      ),
      child: const Center(
        child: Text(
          'S',
          style: TextStyle(
            color: SoftPalette.emerald,
            fontSize: 26,
            fontWeight: FontWeight.w800,
            letterSpacing: -0.8,
          ),
        ),
      ),
    );
  }
}

// ── PIN dots ──────────────────────────────────────────────────────────────────

class _PinDots extends StatelessWidget {
  final int filledCount;
  final int totalCount;
  final bool hasError;
  final Animation<double> shakeAnim;
  final AnimationController shakeController;

  const _PinDots({
    required this.filledCount,
    required this.totalCount,
    required this.hasError,
    required this.shakeAnim,
    required this.shakeController,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: shakeAnim,
      builder: (context, child) {
        final direction =
            shakeController.status == AnimationStatus.forward ? 1.0 : -1.0;
        return Transform.translate(
          offset: Offset(shakeAnim.value * direction, 0),
          child: child,
        );
      },
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(totalCount, (index) {
          final filled = index < filledCount;
          final color = hasError
              ? SoftPalette.negative
              : (filled ? SoftPalette.emerald : AppSurface.border);

          return AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            margin: const EdgeInsets.symmetric(horizontal: 10),
            width: filled ? 14 : 12,
            height: filled ? 14 : 12,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: filled && !hasError ? SoftPalette.emerald : Colors.transparent,
              border: Border.all(color: color, width: 2),
            ),
          );
        }),
      ),
    );
  }
}

// ── Bottom actions ────────────────────────────────────────────────────────────

class _LockActions extends StatelessWidget {
  final bool isBiometricMode;
  final bool isAuthenticating;
  final bool biometricsAvailable;
  final String biometricLabel;
  final VoidCallback onBiometric;
  final VoidCallback onUsePin;
  final VoidCallback onUseBiometric;
  final void Function(String) onKeyTap;
  final VoidCallback onBackspace;

  const _LockActions({
    required this.isBiometricMode,
    required this.isAuthenticating,
    required this.biometricsAvailable,
    required this.biometricLabel,
    required this.onBiometric,
    required this.onUsePin,
    required this.onUseBiometric,
    required this.onKeyTap,
    required this.onBackspace,
  });

  @override
  Widget build(BuildContext context) {
    if (isBiometricMode) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _PrimaryUnlockButton(
            label: isAuthenticating
                ? 'Verifying…'
                : 'Unlock with $biometricLabel',
            isLoading: isAuthenticating,
            onPressed: isAuthenticating ? null : onBiometric,
          ),
          const SizedBox(height: 12),
          _TextLinkButton(label: 'Use PIN instead', onPressed: onUsePin),
        ],
      );
    }

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        _Numpad(onKeyTap: onKeyTap, onBackspace: onBackspace, onBiometric: onBiometric),
        if (biometricsAvailable) ...[
          const SizedBox(height: 12),
          _TextLinkButton(
            label: 'Use $biometricLabel',
            onPressed: onUseBiometric,
          ),
        ],
      ],
    );
  }
}

class _PrimaryUnlockButton extends StatelessWidget {
  final String label;
  final bool isLoading;
  final VoidCallback? onPressed;

  const _PrimaryUnlockButton({
    required this.label,
    required this.isLoading,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: FilledButton(
        onPressed: onPressed,
        style: FilledButton.styleFrom(
          backgroundColor: SoftColors.control,
          disabledBackgroundColor: SoftPalette.emerald.withValues(alpha: 0.45),
          foregroundColor: Colors.white,
          disabledForegroundColor: SoftPalette.onEmerald.withValues(alpha: 0.7),
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        child: isLoading
            ? SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: AppSurface.text,
                ),
              )
            : Text(
                label,
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w500,
                  letterSpacing: 0.1,
                ),
              ),
      ),
    );
  }
}

class _TextLinkButton extends StatelessWidget {
  final String label;
  final VoidCallback onPressed;

  const _TextLinkButton({required this.label, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return TextButton(
      onPressed: onPressed,
      style: TextButton.styleFrom(
        foregroundColor: SoftPalette.mint,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      ),
      child: Text(
        label,
        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
      ),
    );
  }
}

class _Numpad extends StatelessWidget {
  final void Function(String) onKeyTap;
  final VoidCallback onBackspace;
  final VoidCallback onBiometric;

  const _Numpad({
    required this.onKeyTap,
    required this.onBackspace,
    required this.onBiometric,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (int row = 0; row < 4; row++) ...[
          if (row > 0) const SizedBox(height: 14),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              if (row < 3)
                for (int col = 0; col < 3; col++)
                  _NumKey(
                    label: '${row * 3 + col + 1}',
                    onTap: () => onKeyTap('${row * 3 + col + 1}'),
                  )
              else ...[
                _NumKey(
                  onTap: onBiometric,
                  child: const Icon(
                    LucideIcons.fingerprint,
                    color: SoftPalette.emerald,
                    size: 22,
                  ),
                ),
                _NumKey(label: '0', onTap: () => onKeyTap('0')),
                _NumKey(
                  onTap: onBackspace,
                  child: Icon(
                    Icons.backspace_outlined,
                    color: AppSurface.subText,
                    size: 20,
                  ),
                ),
              ],
            ],
          ),
        ],
      ],
    );
  }
}

class _NumKey extends StatelessWidget {
  final String? label;
  final Widget? child;
  final VoidCallback onTap;

  const _NumKey({this.label, this.child, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 64,
        height: 64,
        decoration: BoxDecoration(
          color: label != null ? AppSurface.elevated : Colors.transparent,
          shape: BoxShape.circle,
          border: label != null
              ? Border.all(color: AppSurface.border, width: 1)
              : null,
        ),
        alignment: Alignment.center,
        child: child ??
            Text(
              label ?? '',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w500,
                color: AppSurface.text,
              ),
            ),
      ),
    );
  }
}