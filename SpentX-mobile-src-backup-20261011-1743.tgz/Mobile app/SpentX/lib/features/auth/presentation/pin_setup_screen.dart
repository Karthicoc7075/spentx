import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../../../core/services/pin_service.dart';
import '../../../core/theme/soft_palette.dart';
import 'widgets/pin_entry_step.dart';

/// `/pin-setup` — standalone route used for the existing-user forced PIN
/// reset flow (web admin reset, see [PinService.forcePinSetup]). New-user
/// signup PIN entry is a step inside the Setup Wizard, not this route.
class PinSetupScreen extends StatelessWidget {
  const PinSetupScreen({super.key});

  Future<void> _onPinConfirmed(BuildContext context, String pin) async {
    // setPin already enables fingerprint only when the device supports
    // biometrics — no unconditional force-enable here.
    await PinService.setPin(pin);
    if (!context.mounted) return;
    final hasOnboarding =
        Hive.box('settings').get('has_seen_onboarding', defaultValue: false);
    if (hasOnboarding) {
      if (context.canPop()) {
        context.pop();
      } else {
        context.go('/home');
      }
    } else {
      context.go('/home');
    }
  }

  void _onSkip(BuildContext context) {
    if (context.canPop()) {
      context.pop();
    } else {
      context.go('/home');
    }
  }

  @override
  Widget build(BuildContext context) {
    final isChange = PinService.hasPin;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      backgroundColor: isDark ? SoftPalette.darkBg : SoftPalette.bg,
      body: SafeArea(
        child: PinEntryStep(
          title: isChange ? 'Set new PIN' : 'Create a PIN',
          subtitle: 'Secure your financial vault',
          onPinConfirmed: (pin) => _onPinConfirmed(context, pin),
          onSkip: () => _onSkip(context),
        ),
      ),
    );
  }
}
