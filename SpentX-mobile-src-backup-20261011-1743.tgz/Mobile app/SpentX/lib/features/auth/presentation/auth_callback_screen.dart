import 'dart:async';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../core/services/auth_service.dart';
import '../../../core/theme/soft_palette.dart';
import 'auth_flow.dart';

/// Soft Soft wait screen for `spentx://auth/callback` (email confirm / OAuth).
///
/// go_router used to treat that deep link as an unmatched route → black /
/// error page while supabase_flutter exchanged the PKCE code underneath.
/// This route (plus [overridePlatformDefaultLocation]) keeps a real UI up
/// until a session arrives, then continues into onboarding/home.
class AuthCallbackScreen extends StatefulWidget {
  const AuthCallbackScreen({super.key});

  @override
  State<AuthCallbackScreen> createState() => _AuthCallbackScreenState();
}

class _AuthCallbackScreenState extends State<AuthCallbackScreen> {
  StreamSubscription<dynamic>? _authSub;
  Timer? _timeout;
  String? _error;

  @override
  void initState() {
    super.initState();
    if (AuthService.isSignedIn) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _continue());
      return;
    }
    _authSub = AuthService.onAuthStateChange((signedIn) {
      if (!mounted || !signedIn) return;
      _continue();
    });
    // PKCE exchange is usually <1s; if the link was stale / redirect URL
    // missing from the Supabase allow-list, surface a Soft Soft recovery.
    _timeout = Timer(const Duration(seconds: 8), () {
      if (!mounted || AuthService.isSignedIn) return;
      setState(() {
        _error =
            'Could not finish email verification. Open the link again, or '
            'sign in if you already verified.';
      });
    });
  }

  Future<void> _continue() async {
    _timeout?.cancel();
    if (!mounted) return;
    // Email confirm must stay on the verify screen until the user signs in.
    final pending = AuthService.pendingVerificationEmail;
    if (AuthService.verifiedAwaitingLogin ||
        (pending != null && pending.isNotEmpty)) {
      await AuthService.handoffVerifiedEmailToLogin();
      return;
    }
    await AuthFlow.continueAfterAuth(context);
  }

  @override
  void dispose() {
    _timeout?.cancel();
    _authSub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final canvas = isDark ? SoftPalette.darkBg : SoftPalette.bg;
    final ink = isDark ? SoftPalette.darkInk : SoftPalette.ink;
    final slate = isDark ? SoftPalette.darkMuted : SoftPalette.muted;

    return Scaffold(
      backgroundColor: canvas,
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  _error == null
                      ? Icons.mark_email_read_rounded
                      : Icons.error_outline_rounded,
                  size: 56,
                  color: _error == null
                      ? SoftPalette.emerald
                      : SoftPalette.negative,
                ),
                const SizedBox(height: 20),
                Text(
                  _error == null ? 'Email verified' : 'Verification stalled',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: ink,
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  _error ??
                      'Checking your email link…',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: slate, fontSize: 14, height: 1.4),
                ),
                const SizedBox(height: 28),
                if (_error == null)
                  const SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(
                      color: SoftPalette.emerald,
                      strokeWidth: 2.5,
                    ),
                  )
                else ...[
                  SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: FilledButton(
                      onPressed: () {
                        final email = AuthService.pendingVerificationEmail;
                        if (email != null && email.isNotEmpty) {
                          context.go('/auth/verify-email', extra: email);
                        } else {
                          context.go('/auth/login');
                        }
                      },
                      style: FilledButton.styleFrom(
                        backgroundColor: SoftColors.control,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(22),
                        ),
                      ),
                      child: const Text('Continue'),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextButton(
                    onPressed: () => context.go('/auth/login'),
                    child: const Text('Sign in instead'),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
