import 'dart:io' show Platform;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../../../core/providers/user_state_provider.dart';
import '../../../core/services/auth_service.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../../core/providers/merchant_provider.dart';
import '../../../core/services/auto_detection_native_sync.dart';
import '../../../core/services/notification_permission_service.dart';
import '../../../core/services/pin_service.dart';
import '../../background_detection/notification_service.dart';
import '../../sms/sms_service.dart';
import '../../transactions/data/sms_receiver_service.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../models/account_model.dart';
import 'widgets/onboarding/account_count_card.dart';
import 'widgets/onboarding/account_form_card.dart';
import 'widgets/onboarding/purpose_type_card.dart';
import 'widgets/onboarding/soft_onboarding_widgets.dart';
import 'widgets/onboarding/summary_card.dart';
import 'widgets/pin_entry_step.dart';

/// `/onboarding` — the one-time Setup Wizard for a genuinely new account.
///
/// Runs entirely before Home: account count → accounts → purpose → optional
/// PIN (fingerprint only if a PIN was set) → summary → notifications, SMS
/// read, then auto-detect. Each ask can be skipped. Home itself never shows
/// a setup popup — by the time the user reaches it, everything above is
/// already configured (or explicitly skipped).
class OnboardingScreen extends ConsumerStatefulWidget {
  final bool resumePermissions;

  const OnboardingScreen({super.key, this.resumePermissions = false});

  @override
  ConsumerState<OnboardingScreen> createState() => _OnboardingScreenState();
}

enum _Step {
  welcome,
  accountCount,
  accountForm,
  purposeType,
  pin,
  biometric,
  summary,
  permNotify,
  permSms,
  permAuto,
}

class _OnboardingScreenState extends ConsumerState<OnboardingScreen> {
  late _Step _step;

  int _accountCount = 1;
  List<AccountModel> _accounts = [];
  List<String> _purposes = [];
  bool _pinEnabled = false;

  bool? _biometricSupported;

  @override
  void initState() {
    super.initState();
    _step = widget.resumePermissions ? _Step.permNotify : _Step.accountCount;
    PinService.isBiometricSupported().then((supported) {
      if (mounted) setState(() => _biometricSupported = supported);
    });
  }

  void _completeOnboarding({
    required List<AccountModel> accounts,
    required List<String> purposes,
  }) {
    ref
        .read(userStateProvider.notifier)
        .completeOnboarding(newAccounts: accounts, newPurposes: purposes);
  }

  /// Records setup as finished on the SERVER (`users.setup_completed`, the
  /// same flag web writes) as well as on this device.
  ///
  /// The local flag alone cannot answer "has this account onboarded?" — it
  /// does not survive a reinstall, and it does not travel to the user's other
  /// devices or to web. The server write is fire-and-forget: it is safe to
  /// miss offline because the local flag still routes this device, and the
  /// next fresh login re-reads the server value.
  void _markSeen() {
    final settings = Hive.box('settings');
    settings.put('has_seen_onboarding', true);
    final today = DateTime.now().toUtc().toIso8601String().substring(0, 10);
    if (settings.get(AuthService.accountCreatedAtDateKey) == null) {
      settings.put(AuthService.accountCreatedAtDateKey, today);
    }
    AuthService.markAccountSetupCompleted();
  }

  Future<void> _openLogin() async {
    try {
      await AuthService.signOut();
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(error.toString())),
        );
      }
      return;
    }
    if (!mounted || !context.mounted) return;
    context.go('/auth/login');
  }

  void _enterHome() {
    final settings = Hive.box('settings');
    settings.put(AuthService.permissionsPromptPendingKey, false);
    context.go('/home');
  }

  Future<void> _onPinConfirmed(String pin) async {
    await PinService.setPin(pin);
    if (!mounted) return;
    setState(() => _pinEnabled = true);
    if (_biometricSupported == true) {
      setState(() => _step = _Step.biometric);
    } else {
      setState(() => _step = _Step.summary);
    }
  }

  /// Skip means skip both PIN and fingerprint.
  void _onPinSkipped() {
    setState(() => _step = _Step.summary);
  }

  void _finishSummary() {
    final accounts =
        _accounts.isEmpty
            ? [AccountModel(name: 'Cash', type: 'Cash')]
            : _accounts;
    final purposes = _purposes.isEmpty ? const ['Personal'] : _purposes;
    _completeOnboarding(accounts: accounts, purposes: purposes);
    // Persist on the user row only after accounts + purpose are saved.
    _markSeen();
    Hive.box('settings').put(AuthService.permissionsPromptPendingKey, true);
    setState(() => _step = _Step.permNotify);
  }

  void _goSmsAsk() {
    if (!mounted) return;
    setState(() => _step = _Step.permSms);
  }

  void _goAutoAsk() {
    if (!mounted) return;
    setState(() => _step = _Step.permAuto);
  }

  Future<void> _allowNotifications() async {
    try {
      await Permission.notification.request();
    } catch (_) {}
    _goSmsAsk();
  }

  Future<void> _allowSmsRead() async {
    try {
      if (Platform.isAndroid) {
        await Permission.sms.request();
      }
    } catch (_) {}
    _goAutoAsk();
  }

  /// Same path Settings uses when auto-detect is turned on. A denial or a
  /// closed system sheet still continues to Home.
  Future<void> _allowAutoDetect() async {
    try {
      await Hive.box('settings').put('auto_detection', true);
      await SmsService.ensureActivityStartTime();
      ref.read(autoDetectionProvider.notifier).state = true;
      await AutoDetectionNativeSync.syncToNative();
      if (Platform.isAndroid) {
        final listenerOn =
            await NotificationPermissionService.isNotificationListenerEnabled();
        if (!listenerOn) {
          await NotificationPermissionService.openNotificationListenerSettings();
        }
        await SmsReceiverService.startListening();
        await SmsService.flushPendingQueue();
        await NotificationService.flushPendingPayloads();
      }
    } catch (_) {}
    if (!mounted) return;
    _enterHome();
  }

  @override
  Widget build(BuildContext context) {
    Widget child;
    switch (_step) {
      case _Step.welcome:
        child = _WelcomeStep(
          onStart: () => setState(() => _step = _Step.accountCount),
          onSignIn: _openLogin,
        );
        break;
      case _Step.accountCount:
        child = OnboardingAccountCountCard(
          count: _accountCount,
          onChanged: (v) => setState(() => _accountCount = v),
          onContinue: () => setState(() => _step = _Step.accountForm),
          onBack: null,
          onSkip: () {
            setState(() {
              _accounts = [AccountModel(name: 'Cash', type: 'Cash')];
              _step = _Step.purposeType;
            });
          },
          // SMS is Android-only, so the option is absent on iOS rather than
          // offered and then unable to deliver.
          onDetectFromSms:
              Platform.isAndroid
                  ? () {
                    setState(() {
                      // Cash always exists; the bank accounts come from the
                      // review list after onboarding, not from typing here.
                      _accounts = [AccountModel(name: 'Cash', type: 'Cash')];
                      _step = _Step.purposeType;
                    });
                  }
                  : null,
        );
        break;
      case _Step.accountForm:
        child = OnboardingAccountFormCard(
          requiredCount: _accountCount,
          onContinue: (accs) {
            setState(() {
              _accounts = accs;
              _step = _Step.purposeType;
            });
          },
          onBack: () => setState(() => _step = _Step.accountCount),
        );
        break;
      case _Step.purposeType:
        child = OnboardingPurposeTypeCard(
          onContinue: (purps) {
            setState(() {
              _purposes = purps;
              _step = _Step.pin;
            });
          },
          onBack: () => setState(() => _step = _Step.accountForm),
        );
        break;
      case _Step.pin:
        child = PinEntryStep(
          softStep: true,
          step: 4,
          title: 'Set a 4-digit PIN',
          subtitle: 'Keeps this app private on your phone.',
          onPinConfirmed: _onPinConfirmed,
          onSkip: _onPinSkipped,
        );
        break;
      case _Step.biometric:
        child = _BiometricStep(
          onEnable: () async {
            await PinService.enableFingerprint();
            if (mounted) setState(() => _step = _Step.summary);
          },
          onSkip: () async {
            await PinService.disableFingerprint();
            if (mounted) setState(() => _step = _Step.summary);
          },
        );
        break;
      case _Step.summary:
        child = OnboardingSummaryCard(
          accounts:
              _accounts.isEmpty
                  ? [AccountModel(name: 'Cash', type: 'Cash')]
                  : _accounts,
          purposes: _purposes.isEmpty ? const ['Personal'] : _purposes,
          pinEnabled: _pinEnabled,
          onComplete: _finishSummary,
          onBack: () => setState(() => _step = _Step.purposeType),
          onEditBanks: () => setState(() => _step = _Step.accountForm),
        );
        break;
      case _Step.permNotify:
        child = _PermissionAsk(
          icon: LucideIcons.bell,
          title: 'Stay in the loop',
          subtitle: 'Know when spends land — calm, not noisy.',
          points: const [
            ('New spends', 'A quiet note when a spend is detected.'),
            ('Weekly snapshot', 'A short look at the week.'),
            ('Security alerts', 'Only when something needs you.'),
          ],
          shield:
              'You can change this later in Settings. Not now still continues.',
          allowLabel: 'Allow notifications',
          onAllow: _allowNotifications,
          onSkip: _goSmsAsk,
        );
        break;
      case _Step.permSms:
        child = _PermissionAsk(
          icon: LucideIcons.messageCircle,
          title: 'Auto-detect spends',
          subtitle: 'Read bank SMS to fill your ledger faster.',
          points: const [
            ('Bank SMS', 'Amounts and merchants from bank messages.'),
            ('On this phone', 'Reading stays on the device.'),
          ],
          shield: 'SMS stays on device. Not now still continues.',
          allowLabel: 'Allow SMS read',
          onAllow: _allowSmsRead,
          onSkip: _goAutoAsk,
        );
        break;
      case _Step.permAuto:
        child = _PermissionAsk(
          icon: LucideIcons.sparkles,
          title: 'Reply and control',
          subtitle: 'Optional helpers so spends can land automatically.',
          points: const [
            ('Auto-detect', 'Listen for bank alerts in the background.'),
            ('You stay in control', 'Turn this off anytime in Settings.'),
          ],
          shield: 'Skipping does not lock you out of Home.',
          allowLabel: 'Allow auto-detect',
          onAllow: _allowAutoDetect,
          onSkip: _enterHome,
        );
        break;
    }

    final dark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      backgroundColor: dark ? SoftPalette.darkBg : const Color(0xFFF8FAFC),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 8),
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 300),
            layoutBuilder: (currentChild, previousChildren) {
              return Stack(
                fit: StackFit.expand,
                alignment: Alignment.topCenter,
                children: [
                  ...previousChildren,
                  if (currentChild != null) currentChild,
                ],
              );
            },
            child: KeyedSubtree(key: ValueKey(_step), child: child),
          ),
        ),
      ),
    );
  }
}

class _WelcomeStep extends StatelessWidget {
  final VoidCallback onStart;
  final VoidCallback onSignIn;

  const _WelcomeStep({required this.onStart, required this.onSignIn});

  @override
  Widget build(BuildContext context) {
    final tone = OnboardingTone(context);
    final shieldInk = tone.dark ? tone.emerald : const Color(0xFF065F46);
    final shieldFill = tone.dark ? tone.mint : const Color(0xFFECFDF5);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Column(
        children: [
          const SizedBox(height: 8),
          Text(
            'SpentX',
            style: tone.text(13, FontWeight.w500, tone.ink, letterSpacing: 1.1),
          ),
          const SizedBox(height: 16),
          Flexible(
            child: LayoutBuilder(
              builder: (context, constraints) {
                final cap = MediaQuery.sizeOf(context).height * 0.42;
                final height =
                    constraints.maxHeight < cap ? constraints.maxHeight : cap;
                return Align(
                  child: SizedBox(
                    height: height,
                    width: double.infinity,
                    child: const _WelcomeHero(),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 22),
          Text(
            'Welcome to SpentX',
            textAlign: TextAlign.center,
            style: tone.text(34, FontWeight.w700, tone.ink, height: 1.1),
          ),
          const SizedBox(height: 10),
          Text(
            'Your calm private ledger — banks, purposes, and cashflow in one soft place.',
            textAlign: TextAlign.center,
            style: tone.text(15, FontWeight.w400, tone.slate, height: 1.45),
          ),
          const SizedBox(height: 16),
          Align(
            child: Container(
              padding: const EdgeInsets.fromLTRB(8, 6, 12, 6),
              decoration: BoxDecoration(
                color: shieldFill,
                borderRadius: BorderRadius.circular(999),
                border: Border.all(
                  color: tone.dark ? tone.border : const Color(0xFFD1FAE5),
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 28,
                    height: 28,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: tone.dark ? tone.card : const Color(0xFFD1FAE5),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      LucideIcons.shieldCheck,
                      size: 15,
                      color: tone.emerald,
                    ),
                  ),
                  const SizedBox(width: 8),
                  ConstrainedBox(
                    constraints: BoxConstraints(
                      maxWidth: MediaQuery.sizeOf(context).width - 132,
                    ),
                    child: Text(
                      'Cash is already included · stays on your device',
                      style: tone.text(12, FontWeight.w600, shieldInk),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 22),
          _WelcomeCta(onPressed: onStart),
          TextButton(
            onPressed: onSignIn,
            child: Text(
              'I already have an account',
              style: tone.text(15, FontWeight.w600, tone.slate),
            ),
          ),
          Text(
            'Private by design · You can change setup anytime',
            textAlign: TextAlign.center,
            style: tone.text(12, FontWeight.w500, tone.muted),
          ),
          const SizedBox(height: 4),
        ],
      ),
    );
  }
}

class _WelcomeCta extends StatelessWidget {
  const _WelcomeCta({required this.onPressed});

  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final tone = OnboardingTone(context);
    return SizedBox(
      width: double.infinity,
      height: 56,
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: SoftColors.primaryGradient,
          borderRadius: BorderRadius.circular(22),
          boxShadow:
              tone.dark
                  ? const []
                  : const [
                    BoxShadow(
                      color: Color(0x33047857),
                      offset: Offset(0, 10),
                      blurRadius: 24,
                    ),
                  ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: onPressed,
            borderRadius: BorderRadius.circular(22),
            child: Center(
              child: Text(
                'Get started →',
                style: tone.text(16, FontWeight.w600, Colors.white),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _WelcomeHero extends StatelessWidget {
  const _WelcomeHero();

  @override
  Widget build(BuildContext context) {
    final tone = OnboardingTone(context);
    return DecoratedBox(
      decoration: BoxDecoration(
        color: tone.card,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: tone.border),
        boxShadow:
            tone.dark
                ? const []
                : const [
                  BoxShadow(
                    color: Color.fromRGBO(15, 23, 42, 0.08),
                    offset: Offset(0, 12),
                    blurRadius: 40,
                    spreadRadius: -8,
                  ),
                ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(27),
        child: Stack(
          fit: StackFit.expand,
          children: [
            const CustomPaint(painter: _WelcomeArtPainter()),
            Align(
              alignment: Alignment.bottomCenter,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      const Color(0x00F0FDF4),
                      tone.dark ? tone.card : const Color(0xFFF0FDF4),
                    ],
                  ),
                ),
                child: const SizedBox(height: 84, width: double.infinity),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _WelcomeArtPainter extends CustomPainter {
  const _WelcomeArtPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height * 0.46);
    canvas.drawCircle(
      center,
      size.shortestSide * 0.28,
      Paint()
        ..color = const Color(0x2610B981)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 28),
    );

    void leaf(Offset at, double turn, double w, double h, Color color) {
      canvas.save();
      canvas.translate(at.dx, at.dy);
      canvas.rotate(turn);
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(center: Offset.zero, width: w, height: h),
          Radius.circular(h),
        ),
        Paint()..color = color,
      );
      canvas.restore();
    }

    leaf(center + const Offset(-62, -6), -0.7, 34, 72, const Color(0xFFD1FAE5));
    leaf(center + const Offset(66, 8), 0.55, 26, 56, const Color(0xFFA7F3D0));
    leaf(center + const Offset(18, -58), 0.2, 18, 40, const Color(0xFFECFDF5));

    final wallet = RRect.fromRectAndRadius(
      Rect.fromCenter(
        center: center + const Offset(0, 10),
        width: 124,
        height: 80,
      ),
      const Radius.circular(18),
    );
    canvas.drawRRect(wallet, Paint()..color = const Color(0xFFFFFFFF));
    canvas.drawRRect(
      wallet,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4
        ..color = const Color(0xFFD1FAE5),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
          center: center + const Offset(0, -12),
          width: 46,
          height: 8,
        ),
        const Radius.circular(4),
      ),
      Paint()..color = const Color(0xFF6EE7B7),
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _BiometricStep extends StatelessWidget {
  final VoidCallback onEnable;
  final VoidCallback onSkip;

  const _BiometricStep({required this.onEnable, required this.onSkip});

  @override
  Widget build(BuildContext context) {
    final tone = OnboardingTone(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: ListView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.only(bottom: 12),
            children: [
              const OnboardingStepHeader(
                step: 5,
                title: 'Unlock with fingerprint?',
                subtitle: 'Faster than typing your PIN.',
              ),
              const SizedBox(height: 20),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: tone.cardBox(),
                child: Column(
                  children: [
                    Container(
                      width: 72,
                      height: 72,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: tone.mint,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        Icons.fingerprint,
                        size: 36,
                        color: tone.emeraldDeep,
                      ),
                    ),
                    const SizedBox(height: 14),
                    Text(
                      'Use fingerprint to open SpentX',
                      textAlign: TextAlign.center,
                      style: tone.text(16, FontWeight.w800, tone.ink),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'Faster than typing your PIN.',
                      textAlign: TextAlign.center,
                      style: tone.text(13, FontWeight.w500, tone.slate),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              const OnboardingShield(
                text: 'Biometrics stay private on this device.',
              ),
            ],
          ),
        ),
        OnboardingPrimaryButton(
          label: 'Enable fingerprint',
          onPressed: onEnable,
        ),
        Center(
          child: OnboardingTextButton(label: 'Skip for now', onPressed: onSkip),
        ),
      ],
    );
  }
}

/// One Soft Soft permission screen. Allow requests the existing system API.
/// Not now always continues. Neither path can trap the user before Home.
class _PermissionAsk extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final List<(String, String)> points;
  final String shield;
  final String allowLabel;
  final VoidCallback onAllow;
  final VoidCallback onSkip;

  const _PermissionAsk({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.points,
    required this.shield,
    required this.allowLabel,
    required this.onAllow,
    required this.onSkip,
  });

  @override
  Widget build(BuildContext context) {
    final tone = OnboardingTone(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: ListView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.only(bottom: 12),
            children: [
              const SizedBox(height: 8),
              Center(
                child: Container(
                  width: 88,
                  height: 88,
                  decoration: BoxDecoration(
                    color: tone.mint,
                    shape: BoxShape.circle,
                    border: Border.all(color: tone.border),
                  ),
                  child: Icon(icon, size: 36, color: tone.emeraldDeep),
                ),
              ),
              const SizedBox(height: 18),
              Text(
                title,
                style: tone.text(26, FontWeight.w800, tone.ink, height: 1.15),
              ),
              const SizedBox(height: 6),
              Text(
                subtitle,
                style: tone.text(14, FontWeight.w500, tone.slate, height: 1.4),
              ),
              const SizedBox(height: 16),
              for (final point in points) ...[
                _permCard(tone, point.$1, point.$2),
                const SizedBox(height: 10),
              ],
              OnboardingShield(text: shield),
            ],
          ),
        ),
        OnboardingPrimaryButton(label: allowLabel, onPressed: onAllow),
        Center(
          child: OnboardingTextButton(label: 'Not now', onPressed: onSkip),
        ),
      ],
    );
  }

  Widget _permCard(OnboardingTone tone, String title, String body) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: tone.cardBox(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: tone.text(15, FontWeight.w700, tone.ink)),
          const SizedBox(height: 4),
          Text(
            body,
            style: tone.text(13, FontWeight.w500, tone.slate, height: 1.35),
          ),
        ],
      ),
    );
  }
}
