import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../../../core/services/auth_service.dart';
import 'auth_flow.dart';
import 'package:flutter/services.dart';
import '../../../core/services/pin_service.dart';
import '../../../core/sync/sync_service.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../core/theme/app_fonts.dart';

class SplashScreen extends ConsumerStatefulWidget {
  const SplashScreen({super.key});

  @override
  ConsumerState<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends ConsumerState<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _animController;

  late final Animation<double> _logoScale;
  late final Animation<double> _logoFade;
  late final Animation<double> _wordmarkFade;
  late final Animation<double> _taglineFade;
  late final Animation<double> _loadingFade;

  bool _hasError = false;

  @override
  void initState() {
    super.initState();

    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );

    _logoScale = Tween<double>(begin: 0.82, end: 1.0).animate(
      CurvedAnimation(
        parent: _animController,
        curve: const Interval(0.0, 0.65, curve: Curves.easeOutBack),
      ),
    );

    _logoFade = CurvedAnimation(
      parent: _animController,
      curve: const Interval(0.0, 0.45, curve: Curves.easeOut),
    );

    _wordmarkFade = CurvedAnimation(
      parent: _animController,
      curve: const Interval(0.25, 0.70, curve: Curves.easeOut),
    );

    _taglineFade = CurvedAnimation(
      parent: _animController,
      curve: const Interval(0.40, 0.85, curve: Curves.easeOut),
    );

    _loadingFade = CurvedAnimation(
      parent: _animController,
      curve: const Interval(0.60, 1.0, curve: Curves.easeOut),
    );

    // Hand off from the native (pre-engine) splash the instant this widget
    // can paint its first frame — removing it any earlier would show a
    // blank gap, any later would show a duplicate/frozen native frame on
    // top of our own animation starting underneath it.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      FlutterNativeSplash.remove();
    });

    _animController.forward();
    _initializeApp();
  }

  Future<void> _initializeApp() async {
    final startTime = DateTime.now();

    try {
      // 1. Check session & startup tasks
      var isValidSession = await AuthService.isTokenValid();

      // Cold-start from the email-confirm deep link: supabase_flutter may
      // still be exchanging the PKCE code while splash runs. If a signup is
      // pending, wait briefly for that session before treating this as signed
      // out (which used to bounce users to "session expired" / black gap).
      if (!isValidSession &&
          AuthService.pendingVerificationEmail != null &&
          AuthService.pendingVerificationEmail!.isNotEmpty) {
        final arrived = await AuthService.waitForSession(
          timeout: const Duration(seconds: 4),
        );
        if (arrived) {
          isValidSession = await AuthService.isTokenValid();
        }
      }

      // Ensure smooth splash duration (min 1000ms) for visual polish — real
      // init work above already ran, so this only tops up the remainder,
      // never adds to it.
      final elapsed = DateTime.now().difference(startTime).inMilliseconds;
      if (elapsed < 1000) {
        await Future.delayed(Duration(milliseconds: 1000 - elapsed));
      }

      if (!mounted) return;

      if (AuthService.verifiedAwaitingLogin) {
        if (!mounted) return;
        context.go('/auth/verify-email?verified=1');
        return;
      }

      if (!isValidSession) {
        // No usable session. Clear anything the last account left on this
        // phone so the next login cannot mix with it. A brand-new install
        // has nothing to clear, and must land on Welcome — not "session expired".
        final hadAccount = AuthService.previousAccountEmail().isNotEmpty ||
            AuthService.hasLocalUserData();
        if (AuthService.isConfigured &&
            (AuthService.isSignedIn || AuthService.hasLocalUserData())) {
          await AuthService.signOut(discardUnsyncedChanges: true);
        }
        if (!mounted) return;
        context.go(hadAccount ? '/auth?expired=true' : '/auth');
        return;
      }

      // Confirm link can restore a session before the user has signed in.
      if (AuthService.verifiedAwaitingLogin ||
          (AuthService.pendingVerificationEmail != null &&
              AuthService.pendingVerificationEmail!.isNotEmpty &&
              !AuthService.passwordSignInInProgress)) {
        await AuthService.handoffVerifiedEmailToLogin();
        return;
      }

      // A deep link (email confirm / magic link) can silently establish a
      // session for a DIFFERENT account than whichever one last onboarded
      // on this device — never trust the cached "seen onboarding" flag in
      // that case, or the new account inherits the previous account's
      // completed-onboarding state and lands straight on Home unset-up.
      // Must check BEFORE remembering the current user, since that call
      // overwrites the very "previous account" id this comparison needs.
      final isDifferentAccount = AuthService.isDifferentAccountWithLocalData();
      if (isDifferentAccount || AuthService.syncHeldForAccountSwitch) {
        AuthService.armAccountSwitchHoldIfNeeded();
        if (!mounted) return;
        await AuthFlow.continueAfterAuth(context);
        return;
      }
      AuthService.rememberCurrentUser();

      final settings = Hive.box('settings');
      bool hasSeenOnboarding =
          settings.get('has_seen_onboarding', defaultValue: false) &&
          !isDifferentAccount;
      // Server flag wins when we already know it is false. A stale local
      // "seen" bit must not skip onboarding.
      if (settings.get(AuthService.accountHasDataKey) == false) {
        hasSeenOnboarding = false;
      }

      if (!hasSeenOnboarding) {
        final hasData =
            await AuthService.resolveAccountHasData(freshLogin: false);
        if (hasData == true) {
          await settings.put('has_seen_onboarding', true);
          hasSeenOnboarding = true;
        }
        if (!mounted) return;
      }

      if (hasSeenOnboarding) {
        try {
          await SyncService.checkAndApplyPinReset();
        } catch (_) {}
        if (!mounted) return;

        final pendingPerms = Hive.box('settings')
                .get(AuthService.permissionsPromptPendingKey) ==
            true;
        if (pendingPerms) {
          context.go('/onboarding?resume=permissions');
          return;
        }

        if (PinService.forcePinSetup) {
          context.go('/pin-setup');
          return;
        }

        if (PinService.hasPin && PinService.lockEnabled) {
          context.go('/lock');
        } else {
          context.go('/home');
        }
      } else {
        context.go('/onboarding');
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _hasError = true;
      });
    }
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: isDark ? const Color(0xFF09090B) : Colors.white,
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: isDark ? Brightness.light : Brightness.dark,
          statusBarBrightness: isDark ? Brightness.dark : Brightness.light,
          systemNavigationBarColor: isDark ? const Color(0xFF09090B) : Colors.white,
          systemNavigationBarIconBrightness: isDark ? Brightness.light : Brightness.dark,
        ),
        child: Container(
          width: double.infinity,
          height: double.infinity,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: isDark
                  ? [
                      const Color(0xFF09090B),
                      const Color(0xFF09090B),
                      const Color(0xFF0A1512),
                      const Color(0xFF061A14),
                    ]
                  : [
                      const Color(0xFFFFFFFF),
                      const Color(0xFFFFFFFF),
                      const Color(0xFFF0FDF8),
                      const Color(0xFFEAF8F3),
                    ],
              stops: const [0.0, 0.60, 0.82, 1.0],
            ),
          ),
          child: SafeArea(
            child: _hasError
                ? Center(child: _buildErrorState(context, isDark))
                : Column(
                    children: [
                      const Spacer(flex: 3),

                      // SpentX Brand Mark Logo
                      FadeTransition(
                        opacity: _logoFade,
                        child: ScaleTransition(
                          scale: _logoScale,
                          child: Container(
                            width: 96,
                            height: 96,
                            decoration: BoxDecoration(
                              color: isDark ? const Color(0xFF18181B) : Colors.white,
                              borderRadius: BorderRadius.circular(26),
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(0xFF10B981).withValues(
                                    alpha: isDark ? 0.30 : 0.18,
                                  ),
                                  blurRadius: 28,
                                  offset: const Offset(0, 10),
                                ),
                                BoxShadow(
                                  color: Colors.black.withValues(
                                    alpha: isDark ? 0.50 : 0.04,
                                  ),
                                  blurRadius: 12,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                              border: Border.all(
                                color: isDark
                                    ? const Color(0xFF27272A)
                                    : const Color(0xFFE2E8F0),
                                width: 1.2,
                              ),
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(26),
                              child: Image.asset(
                                'assets/icon/icon.png',
                                width: 96,
                                height: 96,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => Container(
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: isDark
                                          ? [const Color(0xFF064E3B), const Color(0xFF042F2E)]
                                          : [SoftPalette.emerald, SoftPalette.mint],
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                    ),
                                  ),
                                  child: const Center(
                                    child: Text(
                                      'S',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 48,
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 24),

                      // App Title — SpentX
                      FadeTransition(
                        opacity: _wordmarkFade,
                        child: Text(
                          'SpentX',
                          style: AppFonts.text(
                            color: isDark ? Colors.white : const Color(0xFF0F172A),
                            fontSize: 34,
                            fontWeight: FontWeight.w800,
                            letterSpacing: -1.2,
                            height: 1.1,
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),

                      // App Subtitle & Category
                      FadeTransition(
                        opacity: _taglineFade,
                        child: Text(
                          'Personal Finance & Budgeting',
                          textAlign: TextAlign.center,
                          style: AppFonts.text(
                            color: isDark
                                ? const Color(0xFF94A3B8)
                                : const Color(0xFF475569),
                            fontSize: 15,
                            fontWeight: FontWeight.w500,
                            letterSpacing: 0.1,
                          ),
                        ),
                      ),

                      const Spacer(flex: 3),

                      // Subtle Loading Spinner
                      FadeTransition(
                        opacity: _loadingFade,
                        child: SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            color: isDark
                                ? const Color(0xFF34D399)
                                : const Color(0xFF059669),
                            strokeWidth: 2.2,
                            backgroundColor: (isDark
                                    ? const Color(0xFF34D399)
                                    : const Color(0xFF059669))
                                .withValues(alpha: 0.15),
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),

                      // Splash Footer — Made with ❤️ for smarter spending
                      Padding(
                        padding: const EdgeInsets.only(bottom: 16),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              'Made with ',
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w500,
                                color: isDark
                                    ? const Color(0xFF71717A)
                                    : const Color(0xFF94A3B8),
                              ),
                            ),
                            const Text(
                              '❤️',
                              style: TextStyle(fontSize: 12),
                            ),
                            Text(
                              ' for smarter spending',
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w500,
                                color: isDark
                                    ? const Color(0xFF71717A)
                                    : const Color(0xFF94A3B8),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }

  Widget _buildErrorState(BuildContext context, bool isDark) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(
            Icons.error_outline_rounded,
            size: 48,
            color: SoftPalette.negative,
          ),
          const SizedBox(height: 16),
          Text(
            'Failed to initialize app',
            textAlign: TextAlign.center,
            style: AppFonts.text(
              color: isDark ? Colors.white : const Color(0xFF0F172A),
              fontSize: 18,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Please check your connection and try again.',
            textAlign: TextAlign.center,
            style: AppFonts.text(
              color: isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B),
              fontSize: 13,
            ),
          ),
          const SizedBox(height: 24),
          ElevatedButton(
            onPressed: () {
              setState(() {
                _hasError = false;
              });
              _initializeApp();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: SoftColors.control,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(
                horizontal: 24,
                vertical: 12,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: const Text('Retry'),
          ),
        ],
      ),
    );
  }
}
