import 'package:flutter/material.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../core/widgets/reference_ui.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../../core/config/supabase_config.dart';
import '../../../core/services/auth_service.dart';
import 'auth_flow.dart';
import 'widgets/auth_widgets.dart';

/// `/auth/signup` — 100% pixel-matched to the modern fintech Sign Up mockup.
class AuthSignUpScreen extends StatefulWidget {
  const AuthSignUpScreen({super.key});

  @override
  State<AuthSignUpScreen> createState() => _AuthSignUpScreenState();
}

class _AuthSignUpScreenState extends State<AuthSignUpScreen> {
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  final _confirmCtrl = TextEditingController();

  String _countryCode = '+91';
  String _countryFlag = 'IN';

  bool _obscurePassword = true;
  bool _obscureConfirm = true;
  bool _busy = false;
  String? _error;

  static final _emailRe =
      RegExp(r'^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$');

  @override
  void dispose() {
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    _phoneCtrl.dispose();
    _passwordCtrl.dispose();
    _confirmCtrl.dispose();
    super.dispose();
  }

  String? _validate() {
    if (_nameCtrl.text.trim().isEmpty) return 'Enter your name.';
    final email = _emailCtrl.text.trim();
    if (!_emailRe.hasMatch(email)) return 'Enter a valid email address.';
    if (_passwordCtrl.text.length < SupabaseConfig.minPasswordLength) {
      return 'Password must be at least ${SupabaseConfig.minPasswordLength} characters.';
    }
    if (_passwordCtrl.text != _confirmCtrl.text) {
      return 'Passwords do not match.';
    }
    return null;
  }

  Future<void> _submit() async {
    final clientError = _validate();
    if (clientError != null) {
      setState(() => _error = clientError);
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final email = _emailCtrl.text.trim();
      final phone = _phoneCtrl.text.trim().isNotEmpty
          ? '$_countryCode ${_phoneCtrl.text.trim()}'
          : null;

      final res = await AuthService.signUp(
        email: email,
        password: _passwordCtrl.text,
        name: _nameCtrl.text.trim(),
        phone: phone,
      );
      if (!mounted) return;
      if (AuthService.needsEmailVerification(res)) {
        context.go('/auth/verify-email', extra: email);
        return;
      }
      await AuthFlow.continueAfterAuth(context);
    } catch (e) {
      if (!mounted) return;
      final msg = AuthService.friendlyError(e);
      // Account exists (often from a half-finished verify) — point at login,
      // which itself routes unverified emails to the Soft Soft resend screen.
      final already = msg.toLowerCase().contains('already exists');
      setState(() {
        _busy = false;
        _error = already
            ? '$msg Sign in instead — if the email is still unverified you will get a resend screen.'
            : msg;
      });
    }
  }

  Future<void> _handleGoogleSignIn() async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final success = await AuthService.signInWithGoogle();
      if (!success && mounted) {
        setState(() {
          _busy = false;
          _error = 'Google Sign-In cancelled or not configured.';
        });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _busy = false;
        _error = AuthService.friendlyError(e);
      });
    }
  }

  Future<void> _handleAppleSignIn() async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final success = await AuthService.signInWithApple();
      if (!success && mounted) {
        setState(() {
          _busy = false;
          _error = 'Apple Sign-In cancelled or not configured.';
        });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _busy = false;
        _error = AuthService.friendlyError(e);
      });
    }
  }

  void _toggleCountry() {
    setState(() {
      if (_countryCode == '+91') {
        _countryCode = '+1';
        _countryFlag = 'US';
      } else {
        _countryCode = '+91';
        _countryFlag = 'IN';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: isDark ? SoftPalette.darkBg : SoftPalette.bg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        leadingWidth: 56,
        leading: Padding(
          padding: const EdgeInsets.only(left: 8),
          child: Center(
            child: SoftCircleIconButton(
              icon: Icons.arrow_back_ios_new_rounded,
              tooltip: 'Back',
              onPressed: () => Navigator.maybePop(context),
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(24, 4, 24, 4 + MediaQuery.viewInsetsOf(context).bottom),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Logo (w-16 h-16 / 64x64 rounded squircle)
              const Center(
                child: SpentXBrandBadge(size: 64),
              ),
              const SizedBox(height: 16),

              Text(
                'Create your account',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w800,
                  letterSpacing: -0.6,
                  color: isDark ? SoftPalette.darkInk : SoftPalette.ink,
                ),
              ),
              const SizedBox(height: 6),

              // Subtitle
              Text(
                'Start tracking your money and build better financial habits.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w400,
                  height: 1.4,
                  color: isDark ? SoftPalette.darkMuted : SoftPalette.muted,
                ),
              ),
              const SizedBox(height: 22),

              // Error Banner
              AuthErrorBanner(message: _error),

              // Input 1: Full Name
              AuthInputField(
                controller: _nameCtrl,
                hint: 'Full Name',
                prefixIcon: LucideIcons.user,
                keyboardType: TextInputType.name,
                enabled: !_busy,
              ),
              const SizedBox(height: 14),

              // Input 2: Email Address
              AuthInputField(
                controller: _emailCtrl,
                hint: 'Enter your email',
                prefixIcon: LucideIcons.mail,
                keyboardType: TextInputType.emailAddress,
                enabled: !_busy,
              ),
              const SizedBox(height: 14),

              // Input 3: Mobile Number with Flag / Country Pill
              AuthInputField(
                controller: _phoneCtrl,
                hint: 'Mobile number',
                keyboardType: TextInputType.phone,
                enabled: !_busy,
                prefixWidget: GestureDetector(
                  onTap: _toggleCountry,
                  behavior: HitTestBehavior.opaque,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                    decoration: BoxDecoration(
                      color: isDark ? const Color(0xFF1E2D28) : const Color(0xFFF1F5F9),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: isDark ? const Color(0xFF2E453D) : const Color(0xFFE2E8F0),
                        width: 1,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(_countryFlag, style: const TextStyle(fontSize: 14)),
                        const SizedBox(width: 4),
                        Text(
                          _countryCode,
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: isDark ? SoftPalette.darkInk : SoftPalette.ink,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 14),

              // Input 4: Create Password
              AuthInputField(
                controller: _passwordCtrl,
                hint: 'Create password',
                prefixIcon: LucideIcons.lock,
                obscureText: _obscurePassword,
                enabled: !_busy,
                suffixWidget: GestureDetector(
                  onTap: () => setState(() => _obscurePassword = !_obscurePassword),
                  behavior: HitTestBehavior.opaque,
                  child: Icon(
                    _obscurePassword ? LucideIcons.eyeOff : LucideIcons.eye,
                    size: 19,
                    color: const Color(0xFFA0AEC0),
                  ),
                ),
              ),
              const SizedBox(height: 14),

              // Input 5: Confirm Password
              AuthInputField(
                controller: _confirmCtrl,
                hint: 'Confirm password',
                prefixIcon: LucideIcons.lock,
                obscureText: _obscureConfirm,
                enabled: !_busy,
                onSubmitted: (_) => _submit(),
                suffixWidget: GestureDetector(
                  onTap: () => setState(() => _obscureConfirm = !_obscureConfirm),
                  behavior: HitTestBehavior.opaque,
                  child: Icon(
                    _obscureConfirm ? LucideIcons.eyeOff : LucideIcons.eye,
                    size: 19,
                    color: const Color(0xFFA0AEC0),
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // Primary Action: Create Account Button
              AuthDarkButton(
                label: 'Create Account',
                onPressed: _submit,
                busy: _busy,
              ),
              const SizedBox(height: 24),

              // Divider: "Or continue with"
              const AuthOrDivider(),
              const SizedBox(height: 18),

              // Social Buttons Grid (Google & Apple)
              Row(
                children: [
                  AuthSocialButton(
                    icon: const GoogleLogoIcon(size: 18),
                    label: 'Google',
                    onPressed: _busy ? null : _handleGoogleSignIn,
                  ),
                  const SizedBox(width: 12),
                  AuthSocialButton(
                    icon: Icon(
                      Icons.apple,
                      size: 20,
                      color: isDark ? Colors.white : Colors.black,
                    ),
                    label: 'Apple',
                    onPressed: _busy ? null : _handleAppleSignIn,
                  ),
                ],
              ),
              const SizedBox(height: 28),

              // Bottom Login redirect
              GestureDetector(
                onTap: () => context.pushReplacement('/auth/login'),
                behavior: HitTestBehavior.opaque,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Already have an account? ',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w400,
                        color: isDark
                            ? const Color(0xFF94A3B8)
                            : const Color(0xFF64748B),
                      ),
                    ),
                    const Text(
                      'Log in',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF20C997),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}
