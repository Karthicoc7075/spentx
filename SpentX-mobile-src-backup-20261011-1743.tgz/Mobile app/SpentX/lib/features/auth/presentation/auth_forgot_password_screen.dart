import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../../core/services/auth_service.dart';
import '../../../core/theme/soft_palette.dart';
import '../../../core/widgets/reference_ui.dart';
import 'widgets/auth_widgets.dart';

/// `/auth/forgot-password` — sends Supabase's reset email whose link
/// deep-links back into the app (spentx://reset-password).
class AuthForgotPasswordScreen extends StatefulWidget {
  const AuthForgotPasswordScreen({super.key});

  @override
  State<AuthForgotPasswordScreen> createState() =>
      _AuthForgotPasswordScreenState();
}

class _AuthForgotPasswordScreenState extends State<AuthForgotPasswordScreen> {
  final _emailCtrl = TextEditingController();
  bool _busy = false;
  bool _sent = false;
  String? _error;

  @override
  void dispose() {
    _emailCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final email = _emailCtrl.text.trim();
    if (email.isEmpty || !email.contains('@')) {
      setState(() => _error = 'Enter the email you signed up with.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await AuthService.sendPasswordReset(email);
      if (!mounted) return;
      setState(() {
        _busy = false;
        _sent = true;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _busy = false;
        _error = AuthService.friendlyError(e);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = isDark ? SoftPalette.darkBg : SoftPalette.bg;
    final ink = isDark ? SoftPalette.darkInk : SoftPalette.ink;
    final muted = isDark ? SoftPalette.darkMuted : SoftPalette.muted;

    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: Column(
          children: [
            SoftPageHeader(
              title: 'Reset password',
              onBack: () => Navigator.maybePop(context),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.fromLTRB(
                  20,
                  8,
                  20,
                  28 + MediaQuery.viewInsetsOf(context).bottom,
                ),
                child: _sent
                    ? _buildSent(context, ink, muted, isDark)
                    : _buildForm(context, ink, muted),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildForm(BuildContext context, Color ink, Color muted) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          'Forgot your password?',
          style: TextStyle(
            color: ink,
            fontSize: 22,
            fontWeight: FontWeight.w800,
            letterSpacing: -0.4,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Enter your account email and we\'ll send a reset link. Opening the '
          'link on this phone brings you back into SpentX to set a new password.',
          style: TextStyle(color: muted, fontSize: 14, height: 1.5),
        ),
        const SizedBox(height: 20),
        AuthErrorBanner(message: _error),
        SxSoftCard(
          padding: const EdgeInsets.fromLTRB(16, 18, 16, 18),
          child: AuthInputField(
            controller: _emailCtrl,
            hint: 'you@example.com',
            prefixIcon: LucideIcons.mail,
            keyboardType: TextInputType.emailAddress,
            enabled: !_busy,
            onSubmitted: (_) => _submit(),
          ),
        ),
        const SizedBox(height: 28),
        AuthDarkButton(
          label: 'Send reset link',
          busy: _busy,
          onPressed: _busy ? null : _submit,
        ),
      ],
    );
  }

  Widget _buildSent(
    BuildContext context,
    Color ink,
    Color muted,
    bool isDark,
  ) {
    return Column(
      children: [
        const SizedBox(height: 32),
        Container(
          width: 72,
          height: 72,
          decoration: BoxDecoration(
            color: SoftPalette.emeraldSoft,
            shape: BoxShape.circle,
          ),
          child: const Icon(LucideIcons.mail, color: SoftPalette.emerald, size: 30),
        ),
        const SizedBox(height: 24),
        Text(
          'Check your email',
          style: TextStyle(
            color: ink,
            fontSize: 20,
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 12),
        Text(
          'We sent a reset link to ${_emailCtrl.text.trim()}. Tap the link on '
          'this phone to set a new password.',
          textAlign: TextAlign.center,
          style: TextStyle(color: muted, fontSize: 14, height: 1.5),
        ),
        const SizedBox(height: 36),
        AuthDarkButton(
          label: 'Back to log in',
          onPressed: () => context.go('/auth/login'),
        ),
      ],
    );
  }
}
