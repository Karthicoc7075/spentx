import '../../../core/services/auth_service.dart';
import '../domain/auth_repository.dart';
import '../domain/auth_session.dart';

/// Adapts the existing [AuthService] to the clean-architecture auth port.
class AuthRepositoryImpl implements AuthRepository {
  const AuthRepositoryImpl();

  @override
  AuthSession currentSession() {
    if (!AuthService.isSignedIn) return AuthSession.signedOut;
    return AuthSession(
      isSignedIn: true,
      email: AuthService.currentUserEmail,
      userId: AuthService.currentUserId,
    );
  }

  @override
  bool get isSignedIn => AuthService.isSignedIn;

  @override
  String? get pendingVerificationEmail => AuthService.pendingVerificationEmail;

  @override
  Future<void> signOut() => AuthService.signOut();
}
