import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../../../core/providers/transaction_provider.dart' as model;
import '../../../core/services/budget_alert_service.dart';
import '../../../core/utils/ledger_month_index.dart';

class BudgetItem {
  final String id;
  final String category;
  final double limit;
  final bool notifyAt80;
  final bool notifyAt100;

  BudgetItem({
    required this.id,
    required this.category,
    required this.limit,
    this.notifyAt80 = true,
    this.notifyAt100 = true,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'category': category,
        'limit': limit,
        'notifyAt80': notifyAt80,
        'notifyAt100': notifyAt100,
      };

  factory BudgetItem.fromMap(Map<String, dynamic> m) => BudgetItem(
        id: m['id']?.toString() ?? '',
        category: m['category']?.toString() ?? 'Other',
        limit: (m['limit'] as num?)?.toDouble() ?? 0,
        notifyAt80: m['notifyAt80'] != false,
        notifyAt100: m['notifyAt100'] != false,
      );

  BudgetItem copyWith({
    String? category,
    double? limit,
    bool? notifyAt80,
    bool? notifyAt100,
  }) {
    return BudgetItem(
      id: id,
      category: category ?? this.category,
      limit: limit ?? this.limit,
      notifyAt80: notifyAt80 ?? this.notifyAt80,
      notifyAt100: notifyAt100 ?? this.notifyAt100,
    );
  }
}

class BudgetSpendInfo {
  final BudgetItem budget;
  final double spent;
  final double remaining;
  final double progress;

  BudgetSpendInfo({
    required this.budget,
    required this.spent,
  })  : remaining = (budget.limit - spent).clamp(0, double.infinity),
        progress = budget.limit > 0 ? (spent / budget.limit).clamp(0, 2) : 0;
}

class BudgetNotifier extends StateNotifier<List<BudgetItem>> {
  BudgetNotifier(this._ref) : super([]) {
    _load();
  }

  final Ref _ref;
  static const _key = 'list';
  Box get _box => Hive.box('budgets');

  void reloadFromStorage() => _load();

  void _load() {
    final raw = _box.get(_key, defaultValue: <dynamic>[]) as List;
    state = raw
        .map((e) => BudgetItem.fromMap(Map<String, dynamic>.from(e as Map)))
        .toList();
    if (_isDemoSeed(state)) {
      state = [];
      _persist();
    }
  }

  /// The old empty-box seed. Exact match only, so a real budget is kept.
  static bool _isDemoSeed(List<BudgetItem> items) {
    const demo = {
      'food': 12000.0,
      'transport': 8000.0,
      'shopping': 5000.0,
      'entertainment': 6000.0,
      'bills': 10000.0,
    };
    if (items.length != demo.length) return false;
    final seen = <String>{};
    for (final item in items) {
      final key = item.category.trim().toLowerCase();
      if (demo[key] != item.limit || seen.contains(key)) return false;
      seen.add(key);
    }
    return seen.length == demo.length;
  }

  void _persist() {
    _box.put(_key, state.map((b) => b.toMap()).toList());
  }

  double monthlySpentForCategory(String category) {
    final now = DateTime.now();
    final month = '${now.year}-${now.month}';
    return LedgerMonthIndex.of(_ref.read(model.transactionProvider))
        .categorySpend(month, category);
  }

  List<BudgetSpendInfo> spendInfos() {
    return state
        .map((b) => BudgetSpendInfo(budget: b, spent: monthlySpentForCategory(b.category)))
        .toList();
  }

  double get totalLimit => state.fold(0.0, (s, b) => s + b.limit);

  double get totalSpent =>
      state.fold(0.0, (s, b) => s + monthlySpentForCategory(b.category));

  Future<void> addBudget({
    required String category,
    required double limit,
    bool notifyAt80 = true,
    bool notifyAt100 = true,
  }) async {
    final id = DateTime.now().millisecondsSinceEpoch.toString();
    state = [
      ...state,
      BudgetItem(
        id: id,
        category: category,
        limit: limit,
        notifyAt80: notifyAt80,
        notifyAt100: notifyAt100,
      ),
    ];
    _persist();
  }

  Future<void> updateBudget(BudgetItem item) async {
    state = state.map((b) => b.id == item.id ? item : b).toList();
    _persist();
  }

  Future<void> removeBudget(String id) async {
    state = state.where((b) => b.id != id).toList();
    _persist();
  }

  Future<void> checkAlertsAfterSpend(String category, double amount) async {
    if (amount <= 0) return;
    await BudgetAlertService.checkAfterExpense(
      category: category,
      budgets: state.map((b) => b.toMap()).toList(),
      monthlySpent: monthlySpentForCategory,
    );
  }
}

final budgetProvider = StateNotifierProvider<BudgetNotifier, List<BudgetItem>>(
  (ref) => BudgetNotifier(ref),
);

final budgetSpendInfosProvider = Provider<List<BudgetSpendInfo>>((ref) {
  ref.watch(model.transactionProvider);
  return ref.watch(budgetProvider.notifier).spendInfos();
});