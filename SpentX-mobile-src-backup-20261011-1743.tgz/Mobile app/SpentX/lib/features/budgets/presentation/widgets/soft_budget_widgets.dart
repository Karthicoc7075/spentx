import 'package:flutter/material.dart';

import '../../../../core/theme/soft_palette.dart';
import '../../../../core/widgets/reference_ui.dart';

class SoftBudgetCard extends StatelessWidget {
  const SoftBudgetCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.onTap,
    this.borderColor,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  final Color? borderColor;

  @override
  Widget build(BuildContext context) {
    final card = borderColor == null
        ? SxSoftCard(padding: padding, child: child)
        : Container(
            padding: padding,
            decoration: BoxDecoration(
              color: SoftPalette.card,
              borderRadius: const BorderRadius.all(Radius.circular(18)),
              border: Border.all(color: borderColor!),
            ),
            child: child,
          );
    if (onTap == null) return card;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: const BorderRadius.all(Radius.circular(18)),
        child: card,
      ),
    );
  }
}

class SoftBudgetProgress extends StatelessWidget {
  const SoftBudgetProgress({
    super.key,
    required this.value,
    this.over = false,
    this.minHeight = 8,
  });

  final double value;
  final bool over;
  final double minHeight;

  @override
  Widget build(BuildContext context) {
    final clamped = value.isNaN ? 0.0 : value.clamp(0.0, 1.0);
    return ClipRRect(
      borderRadius: BorderRadius.circular(999),
      child: LinearProgressIndicator(
        value: clamped,
        minHeight: minHeight,
        backgroundColor: SoftPalette.surfaceVariant,
        valueColor: AlwaysStoppedAnimation(
          over ? SoftPalette.negative : SoftPalette.emerald,
        ),
      ),
    );
  }
}

class SoftBudgetHero extends StatelessWidget {
  const SoftBudgetHero({
    super.key,
    required this.spentText,
    required this.limitText,
    required this.progress,
    required this.caption,
  });

  final String spentText;
  final String limitText;
  final double progress;
  final String caption;

  @override
  Widget build(BuildContext context) {
    final over = progress >= 0.9;
    return SoftBudgetCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'MONTHLY BUDGET',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.2,
              color: SoftPalette.muted,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            crossAxisAlignment: CrossAxisAlignment.baseline,
            textBaseline: TextBaseline.alphabetic,
            children: [
              Text(
                spentText,
                style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w800,
                  color: SoftPalette.ink,
                ),
              ),
              Text(
                ' / $limitText',
                style: const TextStyle(
                  fontSize: 16,
                  color: SoftPalette.muted,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          SoftBudgetProgress(value: progress, over: over),
          const SizedBox(height: 10),
          Text(
            caption,
            style: const TextStyle(fontSize: 12, color: SoftPalette.muted),
          ),
        ],
      ),
    );
  }
}
