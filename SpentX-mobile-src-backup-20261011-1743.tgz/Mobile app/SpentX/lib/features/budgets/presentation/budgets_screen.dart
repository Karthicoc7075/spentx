import 'package:flutter/material.dart';
import '../../../core/theme/spentx_tokens.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../../core/theme/soft_palette.dart';
import 'widgets/soft_budget_widgets.dart';
import '../../../core/widgets/category_icon.dart';
import '../../../core/widgets/category_selector.dart';
import '../../../core/providers/budget_provider.dart';
import '../../../core/providers/user_state_provider.dart';
import '../../../core/widgets/premium_bottom_sheet.dart';
import '../../../core/widgets/reference_ui.dart';

class BudgetsScreen extends ConsumerStatefulWidget {
  const BudgetsScreen({super.key});

  @override
  ConsumerState<BudgetsScreen> createState() => _BudgetsScreenState();
}

class _BudgetsScreenState extends ConsumerState<BudgetsScreen> {
  bool _multiPurposeEnabled = true;

  String _fmt(int v) {
    final s = v.toString();
    if (s.length <= 3) return s;
    final l3 = s.substring(s.length - 3);
    String r = s.substring(0, s.length - 3);
    r = r.replaceAllMapped(RegExp(r'\B(?=(\d{2})+(?!\d))'), (m) => '${m[0]},');
    return '$r,$l3';
  }

  void _showAddBudget(BuildContext context, WidgetRef ref) {
    final limitCtrl = TextEditingController();
    bool notify80 = true;
    bool notify100 = true;

    // Always show expense categories from local storage (same as expense forms)
    // Supports adding new categories via the + button (stored to Hive via categoryProvider)
    String selectedCategory = 'Food';

    final purposes = ref.read(userStateProvider).purposeTypes;
    final onlyPersonal =
        purposes.length == 1 && purposes.first.toLowerCase() == 'personal';
    final forcePersonal = onlyPersonal || !_multiPurposeEnabled;
    if (forcePersonal) {
      // For personal-only, default to a common expense category (or first available)
      // Budgets are matched against transaction.category (expense cats), not purposes.
      selectedCategory = 'Food';
    }

    PremiumBottomSheet.show(
      context: context,
      child: StatefulBuilder(
        builder:
            (ctx, setLocal) => Padding(
              padding: EdgeInsets.only(
                left: 24,
                right: 24,
                top: 24,
                bottom: MediaQuery.of(ctx).viewInsets.bottom + 24,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Add budget',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Category',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: Theme.of(
                        ctx,
                      ).colorScheme.onSurface.withValues(alpha: 0.7),
                    ),
                  ),
                  const SizedBox(height: 8),
                  CategorySelector(
                    type: CategoryType.expense,
                    selected: selectedCategory,
                    onChanged: (cat) => setLocal(() => selectedCategory = cat),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: limitCtrl,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Monthly limit (₹)',
                    ),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Alert at 80%'),
                    value: notify80,
                    onChanged: (v) => setLocal(() => notify80 = v),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Alert when exceeded'),
                    value: notify100,
                    onChanged: (v) => setLocal(() => notify100 = v),
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () async {
                        final limit = double.tryParse(limitCtrl.text) ?? 0;
                        final cat = selectedCategory;
                        if (cat.isEmpty || limit <= 0) return;
                        await ref
                            .read(budgetProvider.notifier)
                            .addBudget(
                              category: cat,
                              limit: limit,
                              notifyAt80: notify80,
                              notifyAt100: notify100,
                            );
                        if (ctx.mounted) Navigator.pop(ctx);
                      },
                      child: const Text('Save budget'),
                    ),
                  ),
                ],
              ),
            ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    ref.watch(budgetProvider);
    final purposes = ref.watch(userStateProvider).purposeTypes;
    final onlyPersonal =
        purposes.length == 1 && purposes.first.toLowerCase() == 'personal';
    final showMultiEnable = !onlyPersonal;
    final infos = ref.watch(budgetSpendInfosProvider);
    final notifier = ref.read(budgetProvider.notifier);
    final totalSpent = notifier.totalSpent;
    final totalLimit = notifier.totalLimit;
    final remaining = (totalLimit - totalSpent).clamp(0, double.infinity);
    final progress =
        totalLimit > 0
            ? (totalSpent / totalLimit).clamp(0.0, 1.0).toDouble()
            : 0.0;

    return Scaffold(
      backgroundColor: SoftPalette.bg,
      body: SafeArea(
        child: Column(
          children: [
            SoftPageHeader(
              title: 'Budgets',
              trailing: SoftCircleIconButton(
                icon: LucideIcons.bell,
                tooltip: 'Budget alerts in Notification History',
                onPressed: () => context.push('/notifications'),
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  children: [
                    const SizedBox(height: 20),
                    SoftBudgetHero(
                      spentText: '₹${_fmt(totalSpent.toInt())}',
                      limitText: '₹${_fmt(totalLimit.toInt())}',
                      progress: progress,
                      caption:
                          '${(progress * 100).toStringAsFixed(0)}% used • ₹${_fmt(remaining.toInt())} remaining',
                    ),
                    const SizedBox(height: 24),
                    if (showMultiEnable)
                      SwitchListTile(
                        contentPadding: EdgeInsets.zero,
                        title: const Text(
                          'Enable budgeting for other purposes',
                        ),
                        subtitle: const Text(
                          'If multiple purpose types selected (e.g. Family)',
                        ),
                        value: _multiPurposeEnabled,
                        onChanged:
                            (v) => setState(() => _multiPurposeEnabled = v),
                      ),
                    if (infos.isEmpty)
                      const Text('No budgets — tap + to add')
                    else
                      ...infos.map((info) {
                        final cat = CategoryIcon.resolve(info.budget.category);
                        final spent = info.spent.toInt();
                        final limit = info.budget.limit.toInt();
                        final progress = info.progress.clamp(0, 1).toDouble();
                        final isOver = info.progress >= 0.9;
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: _BudgetItem(
                            category: info.budget.category,
                            cat: cat,
                            spent: spent,
                            limit: limit,
                            progress: progress,
                            isDark: isDark,
                            isOver: isOver,
                            onDelete:
                                () => ref
                                    .read(budgetProvider.notifier)
                                    .removeBudget(info.budget.id),
                          ),
                        );
                      }),
                    const SizedBox(height: 80),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddBudget(context, ref),
        child: const Icon(LucideIcons.plus),
      ),
    );
  }
}

class _BudgetItem extends StatelessWidget {
  final String category;
  final CategoryData cat;
  final int spent, limit;
  final double progress;
  final bool isDark, isOver;
  final VoidCallback onDelete;

  const _BudgetItem({
    required this.category,
    required this.cat,
    required this.spent,
    required this.limit,
    required this.progress,
    required this.isDark,
    required this.isOver,
    required this.onDelete,
  });

  String _fmt(int v) {
    final s = v.toString();
    if (s.length <= 3) return s;
    final l3 = s.substring(s.length - 3);
    String r = s.substring(0, s.length - 3);
    r = r.replaceAllMapped(RegExp(r'\B(?=(\d{2})+(?!\d))'), (m) => '${m[0]},');
    return '$r,$l3';
  }

  @override
  Widget build(BuildContext context) {
    final barColor =
        isOver
            ? SoftPalette.negative
            : (progress >= 0.8 ? SoftPalette.warning : SoftPalette.positive);

    return SoftBudgetCard(
      borderColor: isOver ? SoftPalette.negative.withValues(alpha: 0.2) : null,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: cat.color,
                  shape: BoxShape.circle,
                ),
                child: Icon(cat.icon, color: cat.onColor, size: 16),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  cat.label,
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w500,
                    color: Theme.of(context).colorScheme.onSurface,
                  ),
                ),
              ),
              if (isOver)
                const Icon(
                  LucideIcons.alertCircle,
                  color: SoftPalette.negative,
                  size: 16,
                ),
              IconButton(
                icon: const Icon(
                  LucideIcons.trash2,
                  size: 16,
                  color: SoftPalette.negative,
                ),
                onPressed: onDelete,
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '₹${_fmt(spent)} spent',
                style: TextStyle(
                  fontSize: 13,
                  color: Theme.of(context).colorScheme.onSurface,
                ),
              ),
              Text(
                '₹${_fmt(limit)} limit',
                style: TextStyle(
                  fontSize: 13,
                  color: context.tokens.textSecondary,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(3),
            child: LinearProgressIndicator(
              value: progress,
              backgroundColor: context.tokens.field,
              valueColor: AlwaysStoppedAnimation(barColor),
              minHeight: 6,
            ),
          ),
        ],
      ),
    );
  }
}
