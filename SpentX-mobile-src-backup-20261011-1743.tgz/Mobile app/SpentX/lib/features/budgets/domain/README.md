# budgets domain — migrate entities from lib/models + core/providers here
