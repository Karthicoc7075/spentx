import 'package:uuid/uuid.dart';

class PendingTransaction {
  final String id;
  final double amount;
  final String receiver;
  final String bank;
  final DateTime date;
  final String rawMessage;
  final bool isExpense;
  final bool isTransfer;
  final String accountLast4;
  final String referenceId;
  final String upiId;
  final String? outingId;
  final bool isAutoLinked;
  final bool notificationShown;
  final bool popupOpened;
  /// Saved merchant title when payee was known at detection time (background defer).
  final String? savedTitle;
  final String? savedCategory;
  final String? savedPurpose;
  /// When true, auto-add on next foreground open (no verify popup).
  final bool deferAutoAdd;

  PendingTransaction({
    String? id,
    required this.amount,
    required this.receiver,
    required this.bank,
    required this.date,
    required this.rawMessage,
    this.isExpense = true,
    this.isTransfer = false,
    this.accountLast4 = '',
    this.referenceId = '',
    this.upiId = '',
    this.outingId,
    this.isAutoLinked = false,
    this.notificationShown = false,
    this.popupOpened = false,
    this.savedTitle,
    this.savedCategory,
    this.savedPurpose,
    this.deferAutoAdd = false,
  }) : id = id ?? const Uuid().v4();

  Map<String, dynamic> toJson() => {
    'id': id,
    'amount': amount,
    'receiver': receiver,
    'bank': bank,
    'date': date.toIso8601String(),
    'rawMessage': rawMessage,
    'isExpense': isExpense,
    'isTransfer': isTransfer,
    'accountLast4': accountLast4,
    'referenceId': referenceId,
    'upiId': upiId,
    'outingId': outingId,
    'isAutoLinked': isAutoLinked,
    'notificationShown': notificationShown,
    'popupOpened': popupOpened,
    'savedTitle': savedTitle,
    'savedCategory': savedCategory,
    'savedPurpose': savedPurpose,
    'deferAutoAdd': deferAutoAdd,
  };

  factory PendingTransaction.fromJson(Map<dynamic, dynamic> json) => PendingTransaction(
      id: json['id'],
      amount: (json['amount'] as num).toDouble(),
      receiver: json['receiver'] ?? 'Unknown',
      bank: json['bank'] ?? 'Bank',
      date: DateTime.parse(json['date']),
      rawMessage: json['rawMessage'] ?? '',
      isExpense: json['isExpense'] ?? true,
      isTransfer: json['isTransfer'] ?? false,
      accountLast4: json['accountLast4'] ?? '',
      referenceId: json['referenceId'] ?? '',
      upiId: json['upiId'] ?? '',
      outingId: json['outingId']?.toString(),
      isAutoLinked: json['isAutoLinked'] ?? false,
      notificationShown: json['notificationShown'] == true,
      popupOpened: json['popupOpened'] == true,
      savedTitle: json['savedTitle']?.toString(),
      savedCategory: json['savedCategory']?.toString(),
      savedPurpose: json['savedPurpose']?.toString(),
      deferAutoAdd: json['deferAutoAdd'] == true,
    );
}
