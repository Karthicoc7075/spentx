import 'package:uuid/uuid.dart';

class AccountModel {
  final String id;
  final String name;
  /// Bank | Cash | Wallet | Credit — same set as web (lowercase on server).
  final String type;
  final String last4Digits;
  final double openingBalance;
  /// YYYY-MM-DD — when opening balance applies (web `opening_balance_date`).
  final String? openingBalanceDate;
  /// Soft-delete flag; net worth only includes active accounts (web parity).
  final bool isActive;
  /// Web Settings → "Default payment account" (accounts.is_default). Only
  /// one account should carry this at a time — enforced by whoever sets it,
  /// same convention as web's saveAccount.
  final bool isDefault;

  AccountModel({
    String? id,
    required this.name,
    required this.type,
    this.last4Digits = '',
    this.openingBalance = 0.0,
    this.openingBalanceDate,
    this.isActive = true,
    this.isDefault = false,
  }) : id = id ?? const Uuid().v4();

  bool get isCash => type.toLowerCase() == 'cash';
  bool get isCredit => type.toLowerCase() == 'credit';
  bool get isWallet => type.toLowerCase() == 'wallet';
  bool get isInvestment {
    final t = type.toLowerCase().replaceAll(' ', '_');
    return t == 'investment' ||
        t == 'investments' ||
        t == 'mutual_fund' ||
        t == 'mutual_funds' ||
        t == 'stocks' ||
        t == 'stock' ||
        t == 'equity' ||
        t == 'crypto' ||
        t == 'fixed_deposit' ||
        t == 'fd' ||
        t == 'gold' ||
        t == 'real_estate' ||
        t == 'bonds';
  }
  bool get isBank => !isCash && !isCredit && !isWallet && !isInvestment;

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'type': type,
    'last4Digits': last4Digits,
    'openingBalance': openingBalance,
    if (openingBalanceDate != null && openingBalanceDate!.isNotEmpty)
      'openingBalanceDate': openingBalanceDate,
    'isActive': isActive,
    'isDefault': isDefault,
  };

  factory AccountModel.fromJson(Map<dynamic, dynamic> json) => AccountModel(
    id: json['id']?.toString() ?? const Uuid().v4(),
    name: json['name']?.toString() ?? '',
    type: json['type']?.toString() ?? 'Bank',
    last4Digits: json['last4Digits']?.toString() ??
        json['last4']?.toString() ??
        '',
    openingBalance: (json['openingBalance'] as num? ?? 0).toDouble(),
    openingBalanceDate: json['openingBalanceDate']?.toString() ??
        json['opening_balance_date']?.toString(),
    isActive: json['isActive'] != false,
    isDefault: json['isDefault'] == true || json['is_default'] == true,
  );

  AccountModel copyWith({
    String? name,
    String? type,
    String? last4Digits,
    double? openingBalance,
    String? openingBalanceDate,
    bool? isActive,
    bool? isDefault,
  }) {
    return AccountModel(
      id: id,
      name: name ?? this.name,
      type: type ?? this.type,
      last4Digits: last4Digits ?? this.last4Digits,
      openingBalance: openingBalance ?? this.openingBalance,
      openingBalanceDate: openingBalanceDate ?? this.openingBalanceDate,
      isActive: isActive ?? this.isActive,
      isDefault: isDefault ?? this.isDefault,
    );
  }
}
