import 'package:flutter/foundation.dart';
import '../core/providers/plan_provider.dart';

@immutable
class PlanTemplateModel {
  final String id;
  final String userId;
  final String name;
  final double expectedIncome;
  final List<PlanAllocation> allocations;

  const PlanTemplateModel({
    required this.id,
    required this.userId,
    required this.name,
    required this.expectedIncome,
    required this.allocations,
  });

  factory PlanTemplateModel.fromMap(Map<String, dynamic> map) {
    final rawAlloc = map['allocations'];
    final allocs = <PlanAllocation>[];
    if (rawAlloc is List) {
      for (final e in rawAlloc) {
        if (e is Map) {
          allocs.add(PlanAllocation.fromJson(Map<dynamic, dynamic>.from(e)));
        }
      }
    }

    return PlanTemplateModel(
      id: (map['id'] ?? '').toString(),
      userId: (map['user_id'] ?? '').toString(),
      name: (map['template_name'] ?? map['name'] ?? '').toString(),
      expectedIncome: (map['expected_income'] as num? ??
              map['expectedIncome'] as num? ??
              0)
          .toDouble(),
      allocations: allocs,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'user_id': userId,
      'template_name': name,
      'expected_income': expectedIncome,
      'allocations': allocations.map((a) => a.toJson()).toList(),
    };
  }
}
