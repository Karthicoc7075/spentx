/// Model representing a verified merchant.
class Merchant {
  final String id;
  final String payee;
  final String normalizedPayee;
  final String title;
  final String purpose;
  final String category;
  final DateTime verifiedAt;
  final bool isAutoApply;

  const Merchant({
    required this.id,
    required this.payee,
    required this.normalizedPayee,
    required this.title,
    this.purpose = '',
    this.category = 'Other',
    required this.verifiedAt,
    this.isAutoApply = true,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'payee': payee,
        'normalizedPayee': normalizedPayee,
        'title': title,
        'purpose': purpose,
        'category': category,
        'verifiedAt': verifiedAt.toIso8601String(),
        'isAutoApply': isAutoApply,
      };

  factory Merchant.fromMap(Map<dynamic, dynamic> map) {
    return Merchant(
      id: map['id']?.toString() ?? '',
      payee: map['payee']?.toString() ?? '',
      normalizedPayee: map['normalizedPayee']?.toString() ?? map['payee']?.toString() ?? '',
      title: map['title']?.toString() ?? map['displayName']?.toString() ?? '',
      purpose: map['purpose']?.toString() ?? '',
      category: map['category']?.toString() ?? map['defaultCategory']?.toString() ?? 'Other',
      verifiedAt: map['verifiedAt'] != null
          ? DateTime.tryParse(map['verifiedAt'].toString()) ?? DateTime.now()
          : DateTime.now(),
      isAutoApply: map['isAutoApply'] != false,
    );
  }

  Merchant copyWith({
    String? title,
    String? purpose,
    String? category,
    bool? isAutoApply,
    DateTime? verifiedAt,
  }) {
    return Merchant(
      id: id,
      payee: payee,
      normalizedPayee: normalizedPayee,
      title: title ?? this.title,
      purpose: purpose ?? this.purpose,
      category: category ?? this.category,
      verifiedAt: verifiedAt ?? this.verifiedAt,
      isAutoApply: isAutoApply ?? this.isAutoApply,
    );
  }
}
