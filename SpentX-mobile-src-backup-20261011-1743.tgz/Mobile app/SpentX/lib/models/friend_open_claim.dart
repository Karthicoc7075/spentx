// Pure domain layer for repayment matching — deliberately free of Flutter
// and Riverpod imports so the money math can be exercised by the project's
// plain `dart run` test scripts. Anything that needs providers lives in
// `core/services/friend_open_claims_service.dart`.

/// Where an open claim came from. Both paths are money a friend owes *you*,
/// but they live in completely separate stores (see
/// `supabase/migrations/20260746_friend_splits.sql` in the web repo — a
/// Friend Split never touches the outing tables).
enum FriendClaimSource { outing, friendSplit }

/// One outstanding amount a friend still owes you, from either a trip
/// expense or a one-off Friend Split.
///
/// This is the eligibility unit for repayment matching: an incoming credit
/// can only ever be treated as a repayment if it can be pointed at one of
/// these. An amount on its own is never enough.
class FriendOpenClaim {
  final FriendClaimSource source;

  /// Outing id (outing claims) — empty for Friend Splits.
  final String outingId;

  /// Outing expense id (outing claims) — empty for Friend Splits.
  final String expenseId;

  /// Friend Split id — empty for outing claims.
  final String splitId;

  /// Trip title / split description — what the user sees in the picker.
  final String referenceName;

  final String friendName;

  /// The friend's member id *within this reference*. Outing member ids and
  /// Friend Split member ids are unrelated, so this can differ per claim.
  final String friendMemberId;

  /// Who receives the repayment — the "You" member of this reference.
  final String youMemberId;

  final double outstanding;
  final DateTime incurredAt;

  const FriendOpenClaim({
    required this.source,
    required this.outingId,
    required this.expenseId,
    required this.splitId,
    required this.referenceName,
    required this.friendName,
    required this.friendMemberId,
    required this.youMemberId,
    required this.outstanding,
    required this.incurredAt,
  });

  /// Stable identity for checkbox selection state in the popup.
  String get id => source == FriendClaimSource.outing
      ? 'outing:$outingId:$expenseId:$friendMemberId'
      : 'split:$splitId:$friendMemberId';
}

/// Decides which claims an incoming credit is pre-ticked against, and how a
/// credit is divided across the claims the user actually ticked.
///
/// Both answers are deliberately conservative: a wrong auto-settlement is
/// silent and shows up weeks later as a friend balance that doesn't add up,
/// whereas a missed match costs the user one tap.
class FriendClaimMath {
  FriendClaimMath._();

  /// Amounts equal within this are treated as the same — SMS amounts and
  /// stored shares can differ by rounding.
  static const double matchTolerance = 1.0;

  /// Below this a claim counts as settled.
  static const double settledEpsilon = 0.01;

  static double totalOutstanding(List<FriendOpenClaim> claims) =>
      claims.fold(0.0, (sum, c) => sum + c.outstanding);

  /// Which claims to pre-tick for a credit of [amount].
  ///
  /// Only ticks on an unambiguous read — a single claim matching the credit
  /// exactly, or the whole set summing to it ("settling everything"). Any
  /// other shape ticks nothing and lets the user decide, because guessing an
  /// allocation is exactly how wrong settlements get written. Notably, two
  /// claims that could each explain the credit tick nothing at all.
  static Set<String> preselect(List<FriendOpenClaim> claims, double amount) {
    if (claims.isEmpty || amount <= 0) return <String>{};

    final exact = claims
        .where((c) => (c.outstanding - amount).abs() <= matchTolerance)
        .toList();
    if (exact.length == 1) return {exact.first.id};
    if (exact.length > 1) return <String>{};

    if (claims.length > 1 &&
        (totalOutstanding(claims) - amount).abs() <= matchTolerance) {
      return claims.map((c) => c.id).toSet();
    }

    return <String>{};
  }

  /// Splits [amount] across [selected], oldest first, never exceeding any
  /// claim's outstanding. Returns claim id -> amount to settle.
  ///
  /// A short credit (₹400 against ₹500) partially settles. A long one (₹600
  /// against ₹500) settles ₹500 and leaves ₹100 unallocated — the caller
  /// decides what that extra is, this never invents a place to put it.
  static Map<String, double> allocate(
    List<FriendOpenClaim> selected,
    double amount,
  ) {
    final ordered = [...selected]
      ..sort((a, b) => a.incurredAt.compareTo(b.incurredAt));

    final allocation = <String, double>{};
    var remaining = amount;

    for (final claim in ordered) {
      if (remaining < settledEpsilon) break;
      final apply =
          remaining < claim.outstanding ? remaining : claim.outstanding;
      if (apply < settledEpsilon) continue;
      allocation[claim.id] = apply;
      remaining -= apply;
    }

    return allocation;
  }

  /// Amount left over after [allocate] — the "extra" the user must classify.
  static double unallocated(List<FriendOpenClaim> selected, double amount) {
    final used =
        allocate(selected, amount).values.fold(0.0, (sum, v) => sum + v);
    final extra = amount - used;
    return extra < settledEpsilon ? 0 : extra;
  }
}
