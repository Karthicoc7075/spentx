import 'package:uuid/uuid.dart';
import '../core/providers/outing_provider.dart'
    show Outing, OutingExpense, OutingMember, SplitType;

/// One member's share of a Friend Split — mirrors web `ExpenseSplit`
/// (`{ memberId, amount }`).
class FriendSplitShare {
  final String memberId;
  final double amount;

  const FriendSplitShare({required this.memberId, required this.amount});

  Map<String, dynamic> toJson() => {'memberId': memberId, 'amount': amount};

  factory FriendSplitShare.fromJson(Map<dynamic, dynamic> json) =>
      FriendSplitShare(
        memberId: (json['memberId'] ?? json['member_id'] ?? '').toString(),
        amount: (json['amount'] as num? ?? 0).toDouble(),
      );
}

/// A repayment against a Friend Split — mirrors the remote
/// `friend_settlements` table (deliberately separate from outing
/// settlements, which are trip-scoped).
class FriendSettlementRecord {
  final String id;
  final String fromMemberId;
  final String toMemberId;
  final double amount;
  final DateTime date;
  final String? note;

  FriendSettlementRecord({
    String? id,
    required this.fromMemberId,
    required this.toMemberId,
    required this.amount,
    required this.date,
    this.note,
  }) : id = id ?? const Uuid().v4();

  Map<String, dynamic> toJson() => {
        'id': id,
        'fromMemberId': fromMemberId,
        'toMemberId': toMemberId,
        'amount': amount,
        'date': date.toIso8601String(),
        'note': note,
      };

  factory FriendSettlementRecord.fromJson(Map<dynamic, dynamic> json) =>
      FriendSettlementRecord(
        id: json['id']?.toString(),
        fromMemberId:
            (json['fromMemberId'] ?? json['from_member_id'] ?? '').toString(),
        toMemberId:
            (json['toMemberId'] ?? json['to_member_id'] ?? '').toString(),
        amount: (json['amount'] as num? ?? 0).toDouble(),
        date: DateTime.tryParse(
              (json['date'] ?? json['settled_date'] ?? '').toString(),
            ) ??
            DateTime.now(),
        note: json['note']?.toString(),
      );
}

/// A one-off shared expense between "you" and friends — a restaurant bill, a
/// taxi fare. Standalone by design, matching the web app's `friend_splits`
/// table: a Friend Split never creates an outing, an outing expense, outing
/// members or an outing settlement (see supabase/migrations/20260746_friend_splits.sql
/// in the companion web repo — this mirrors that schema exactly).
class FriendSplit {
  final String id;
  /// The personal-ledger [Transaction] this split describes. One split per
  /// transaction (enforced remotely by a unique index on transaction_id).
  final String transactionId;
  final String description;
  final double amount;
  final String category;
  final DateTime date;
  /// Roster for this split — "You" plus the friends involved.
  final List<OutingMember> members;
  final String paidByMemberId;
  final SplitType splitType;
  final List<FriendSplitShare> splits;
  final String? accountName;
  final String? paymentMode;
  final String? note;
  final bool isActive;
  final List<FriendSettlementRecord> settlements;

  FriendSplit({
    String? id,
    required this.transactionId,
    required this.description,
    required this.amount,
    required this.category,
    required this.date,
    required this.members,
    required this.paidByMemberId,
    required this.splitType,
    required this.splits,
    this.accountName,
    this.paymentMode,
    this.note,
    this.isActive = true,
    this.settlements = const [],
  }) : id = id ?? const Uuid().v4();

  /// `You` member's own id, matching [OutingMember.isCurrentUser]/name.
  String? get youMemberId => members
      .firstWhere(
        (m) => m.isCurrentUser || m.name.toLowerCase() == 'you',
        orElse: () => OutingMember(id: '', name: ''),
      )
      .id
      .let((v) => v.isEmpty ? null : v);

  double shareForMember(String memberId) =>
      splits.firstWhere(
        (s) => s.memberId == memberId,
        orElse: () => const FriendSplitShare(memberId: '', amount: 0),
      ).amount;

  double settledAmountForMember(String memberId) {
    var total = 0.0;
    for (final s in settlements) {
      if (s.fromMemberId == memberId) total += s.amount;
    }
    return total;
  }

  double pendingAmountForMember(String memberId) {
    final pending = shareForMember(memberId) - settledAmountForMember(memberId);
    return pending < 0.01 ? 0 : pending;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'transactionId': transactionId,
        'description': description,
        'amount': amount,
        'category': category,
        'date': date.toIso8601String(),
        'members': members.map((m) => m.toJson()).toList(),
        'paidByMemberId': paidByMemberId,
        'splitType': splitType.name,
        'splits': splits.map((s) => s.toJson()).toList(),
        'accountName': accountName,
        'paymentMode': paymentMode,
        'note': note,
        'isActive': isActive,
        'settlements': settlements.map((s) => s.toJson()).toList(),
      };

  factory FriendSplit.fromJson(Map<dynamic, dynamic> json) => FriendSplit(
        id: json['id']?.toString(),
        transactionId:
            (json['transactionId'] ?? json['transaction_id'] ?? '').toString(),
        description: (json['description'] ?? '').toString(),
        amount: (json['amount'] as num? ?? 0).toDouble(),
        category: (json['category'] ?? json['category_id'] ?? 'Other')
            .toString(),
        date: DateTime.tryParse(
              (json['date'] ?? json['split_date'] ?? '').toString(),
            ) ??
            DateTime.now(),
        members: (json['members'] as List? ?? const [])
            .map((e) => OutingMember.fromJson(Map<dynamic, dynamic>.from(e as Map)))
            .toList(),
        paidByMemberId:
            (json['paidByMemberId'] ?? json['paid_by_member_id'] ?? 'you')
                .toString(),
        splitType: SplitType.values.firstWhere(
          (t) => t.name == (json['splitType'] ?? json['split_type'] ?? 'equally'),
          orElse: () => SplitType.equally,
        ),
        splits: (json['splits'] as List? ?? const [])
            .map((e) => FriendSplitShare.fromJson(Map<dynamic, dynamic>.from(e as Map)))
            .toList(),
        accountName: json['accountName']?.toString() ?? json['account_name']?.toString(),
        paymentMode: json['paymentMode']?.toString() ?? json['payment_mode']?.toString(),
        note: json['note']?.toString(),
        isActive: json['isActive'] ?? json['is_active'] ?? true,
        settlements: (json['settlements'] as List? ?? const [])
            .map((e) => FriendSettlementRecord.fromJson(Map<dynamic, dynamic>.from(e as Map)))
            .toList(),
      );

  /// Rebuilds an outing's member split as a standalone Friend Split, so a
  /// shared trip expense keeps working after it is unlinked from the trip.
  ///
  /// The two structures already speak the same language — both use
  /// [OutingMember] for the roster and [SplitType] for the mode — so this is a
  /// re-homing, not a conversion into some third split type. Every per-member
  /// amount is read through [OutingExpense.shareForMember], which is what the
  /// trip itself uses, so equal and custom splits both come across at exactly
  /// the values they already had.
  ///
  /// Returns null when there is nothing to carry over — a solo expense, or one
  /// naming fewer than two people. Also returns null if any member id cannot be
  /// resolved against [outing]'s roster: a split naming someone we cannot
  /// identify would be worse than none, and the caller still keeps the
  /// transaction itself.
  static FriendSplit? fromOutingExpense({
    required Outing outing,
    required OutingExpense expense,
    required String transactionId,
  }) {
    if (expense.splitType == SplitType.solo) return null;
    if (expense.memberIds.length < 2) return null;

    final roster = <OutingMember>[];
    for (final id in expense.memberIds) {
      final member = outing.members.where((m) => m.id == id).firstOrNull;
      if (member == null) return null;
      roster.add(member);
    }

    // Who fronted the bill; falls back to "you" the same way the trip does.
    final payerId = (expense.paidByMemberId?.trim().isNotEmpty ?? false)
        ? expense.paidByMemberId!
        : (outing.youMemberId ?? roster.first.id);

    // Repayments already recorded against the trip come across as friend
    // settlements, so a partly-settled split does not reset to fully pending.
    final settlements = <FriendSettlementRecord>[];
    expense.settlementPayments.forEach((memberId, payments) {
      for (final payment in payments) {
        settlements.add(
          FriendSettlementRecord(
            fromMemberId: memberId,
            toMemberId: payerId,
            amount: payment.amount,
            date: payment.date,
            note: payment.mode,
          ),
        );
      }
    });

    return FriendSplit(
      transactionId: transactionId,
      description: expense.title,
      amount: expense.amount,
      category: expense.category,
      date: expense.date,
      members: roster,
      paidByMemberId: payerId,
      splitType: expense.splitType,
      splits: [
        for (final member in roster)
          FriendSplitShare(
            memberId: member.id,
            amount: expense.shareForMember(member.id),
          ),
      ],
      accountName: expense.accountId,
      paymentMode: expense.paymentMode,
      settlements: settlements,
    );
  }

  FriendSplit copyWith({
    String? description,
    double? amount,
    String? category,
    DateTime? date,
    List<OutingMember>? members,
    String? paidByMemberId,
    SplitType? splitType,
    List<FriendSplitShare>? splits,
    String? accountName,
    String? paymentMode,
    String? note,
    bool? isActive,
    List<FriendSettlementRecord>? settlements,
  }) =>
      FriendSplit(
        id: id,
        transactionId: transactionId,
        description: description ?? this.description,
        amount: amount ?? this.amount,
        category: category ?? this.category,
        date: date ?? this.date,
        members: members ?? this.members,
        paidByMemberId: paidByMemberId ?? this.paidByMemberId,
        splitType: splitType ?? this.splitType,
        splits: splits ?? this.splits,
        accountName: accountName ?? this.accountName,
        paymentMode: paymentMode ?? this.paymentMode,
        note: note ?? this.note,
        isActive: isActive ?? this.isActive,
        settlements: settlements ?? this.settlements,
      );
}

extension _Let<T> on T {
  R let<R>(R Function(T) fn) => fn(this);
}
