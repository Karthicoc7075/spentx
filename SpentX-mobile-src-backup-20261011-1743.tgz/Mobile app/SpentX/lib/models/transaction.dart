import 'package:uuid/uuid.dart';
import 'package:hive_flutter/hive_flutter.dart';

/// Badge shown on a transaction card. `none` = ordinary transaction, which
/// deliberately gets no badge so the list stays scannable.
enum TransactionBadgeKind {
  none,
  splitExpense,
  friendSplit,
  outing,
  settlement,
  friendReturn,
}

extension TransactionBadgeKindLabel on TransactionBadgeKind {
  String? get label => switch (this) {
        TransactionBadgeKind.splitExpense => 'Split Expense',
        TransactionBadgeKind.friendSplit => 'Friend Split',
        TransactionBadgeKind.outing => 'Outing',
        TransactionBadgeKind.settlement => 'Settlement',
        TransactionBadgeKind.friendReturn => 'Friend Return',
        TransactionBadgeKind.none => null,
      };
}

/// One category/purpose slice of a Split Expense. Mirrors the web
/// `transaction_splits` row so both platforms display and filter identically.
class TransactionSplitRow {
  final String categoryId;
  final String purposeId;
  final double amount;

  const TransactionSplitRow({
    required this.categoryId,
    required this.purposeId,
    required this.amount,
  });

  Map<String, dynamic> toJson() => {
        'categoryId': categoryId,
        'purposeId': purposeId,
        'amount': amount,
      };

  factory TransactionSplitRow.fromJson(Map<dynamic, dynamic> json) =>
      TransactionSplitRow(
        categoryId: (json['categoryId'] ?? json['category_id'] ?? '').toString(),
        purposeId: (json['purposeId'] ?? json['purpose_id'] ?? '').toString(),
        amount: (json['amount'] as num? ?? 0).toDouble(),
      );
}

/// One purchased line item on a transaction. Separate from
/// [TransactionSplitRow]: this describes WHAT was bought, splits describe
/// HOW the amount is allocated. Mirrors the web `transaction_items` row.
class TransactionItemRow {
  final String name;
  final String categoryId;
  final double amount;

  const TransactionItemRow({
    required this.name,
    required this.categoryId,
    required this.amount,
  });

  Map<String, dynamic> toJson() => {
        'name': name,
        'categoryId': categoryId,
        'amount': amount,
      };

  factory TransactionItemRow.fromJson(Map<dynamic, dynamic> json) =>
      TransactionItemRow(
        name: (json['name'] ?? '').toString(),
        categoryId: (json['categoryId'] ?? json['category_id'] ?? '').toString(),
        amount: (json['amount'] as num? ?? 0).toDouble(),
      );
}

class Transaction {
  final String id;
  final String merchant;
  final String category;
  final String account; // 'Personal' or 'Home'
  final String time;
  final double amount;
  final bool isExpense;
  final bool isAutoDetected;
  final bool isGroup;
  final int groupCount;
  final String paymentType; // 'Cash' or 'Online'
  final DateTime date;
  final bool isTransfer; // If true, it's an account-to-account transfer
  final String? transferTo; // Destination account for transfers ('Cash', bank name). Null for legacy/ATM records (treated as to-Cash when isExpense).
  /// Destination account's remote id (Supabase accounts.id) for a real
  /// single-row transfer. Null on legacy two-row transfers (transferTo name
  /// only) and on ordinary expense/income rows.
  final String? toAccountId;
  /// 'bank_to_bank' | 'bank_to_cash' | 'cash_to_bank'. Only set on new-style
  /// single-row transfers — its presence (vs. null) is what distinguishes a
  /// new-style transfer from a legacy two-row one in the balance engine, so
  /// legacy history is never double-credited when this field is introduced.
  final String? transferType;
  final String? remoteId; // Supabase row id once synced (uuid). Null until first push/pull.
  final String? outingId; // Link to an active trip
  final String? linkedExpenseId; // Link to parent expense for reimbursements/settlements
  final bool isAutoLinked;
  final String? rawIdentifier; // FOR LEARNING SYSTEM
  final String? purpose; // 'Personal', 'Family', etc
  final String bankName;
  final String accountLast4;
  final String referenceId;
  final String upiId;
  final String rawMessage;
  final String note; // free-text spent purpose / note for the transaction
  final String description; // explicit description separate from note (web parity)
  final bool isPendingVerification; // Unknown merchant auto-added during outing
  final bool isMerchantMapped; // Was merchant already mapped when added
  /// Income source person (web contributorSource / split.contributor_id). Default Me.
  final String? contributorSource;

  /// Every category/purpose slice for a Split Expense. Empty for a normal
  /// transaction, which uses [category] and [purpose] directly.
  final List<TransactionSplitRow> splits;

  /// Optional single display title (e.g. "College Backpack"), independent of
  /// Split Expense — purely descriptive, never used for allocation math.
  final String? title;

  /// Optional purchased line items. Independent of [splits].
  final List<TransactionItemRow> items;

  /// True when this row carries several category/purpose splits.
  ///
  /// Slices in a real split expense sum to the transaction's total amount
  /// (within a 5% rounding allowance). If duplicate split rows were pulled
  /// from the server or created in local storage such that the total split
  /// amount exceeds the parent amount, it is not a genuine split expense.
  bool get isSplitExpense {
    if (splits.length <= 1) return false;
    if (amount > 0) {
      final total = splits.fold<double>(0.0, (acc, s) => acc + s.amount);
      if (total > amount * 1.05) return false;
    }
    return true;
  }

  /// True when 2+ items exist — mirrors the web "{n} Items" list indicator.
  /// See `TransactionDisplayUtils.displayTitle` for the full title/items
  /// display precedence (kept there, alongside `merchantTitle`, since it
  /// needs merchant-learning resolution that this model doesn't have).
  bool get isItemized => items.length > 1;

  /// True when this row is a Friend Split — the amount is shared with other
  /// people. Two independent signals because the split can be recorded either
  /// on the row itself or as a `friend_splits` record keyed by transaction id;
  /// [badgeKind] already reads both, and this reuses the same primitives
  /// rather than introducing a second notion of "is a friend split".
  bool get isFriendSplit =>
      isGroup || groupCount > 0 || _hasFriendSplitRecord(id);

  /// True when the amount is undivided — no Purpose Split, Category Split,
  /// Purpose + Category Split, per-item allocation, or Friend Split.
  ///
  /// An outing expense holds ONE amount against ONE category and ONE purpose,
  /// so a transaction whose amount is already carved up has no single set of
  /// those values to carry into a trip. Rather than picking one slice and
  /// silently dropping the rest, such a row simply cannot be linked.
  ///
  /// Transfers are excluded as well: moving money between your own accounts
  /// is not spending, so it is not something a trip can contain.
  bool get isSimpleTransaction {
    if (isSplitExpense) return false; // purpose / category / purpose+category
    if (isItemized) return false; // per-item allocation
    if (isFriendSplit) return false;
    if (isTransfer) return false;
    return true;
  }

  /// Distinct categories — one for a normal row, all slices for a split.
  List<String> get categoryNames {
    if (!isSplitExpense) return category.isEmpty ? const [] : [category];
    final seen = <String>{};
    final out = <String>[];
    for (final s in splits) {
      final name = s.categoryId.trim();
      if (name.isEmpty || !seen.add(name.toLowerCase())) continue;
      out.add(name);
    }
    return out.isEmpty ? [category] : out;
  }

  /// Ledger category used for settle-up rows (matches web SETTLEMENT_CATEGORY).
  static const settlementCategory = 'Settlements';

  /// Category for money a friend pays back. Mirrors
  /// `FriendCreditHandler.repaymentCategory`; kept as a literal here so the
  /// model layer does not depend on a service.
  static const friendReturnCategory = 'Friend Returns';

  /// A credit that is a friend paying you back, not newly-earned money.
  ///
  /// Used to keep returns out of income everywhere and to subtract them from
  /// spending in Analysis. A return is always a credit — an *expense* in this
  /// category would be you repaying someone, which is a different thing.
  bool get isFriendReturn =>
      !isExpense &&
      category.trim().toLowerCase() == friendReturnCategory.toLowerCase();

  static bool _hasFriendSplitRecord(String txId) {
    if (!Hive.isBoxOpen('friend_splits')) return false;
    try {
      final box = Hive.box('friend_splits');
      for (final key in box.keys) {
        final val = box.get(key);
        if (val is Map) {
          final linkedTxId =
              (val['transactionId'] ?? val['transaction_id'] ?? '').toString();
          if (linkedTxId == txId || key.toString() == txId) return true;
        }
      }
    } catch (_) {}
    return false;
  }

  /// Which badge this row shows in the list. Mirrors the web
  /// `getTransactionBadge` ordering so both platforms agree.
  /// Settlement wins over Outing because a settle-up carries an outingId.
  TransactionBadgeKind get badgeKind {
    final cat = category.trim().toLowerCase();
    // Ranked above Outing on purpose: a return for a trip carries that trip's
    // outingId, and labelling it "Outing" made it read as another trip
    // *expense* rather than money coming back.
    if (isFriendReturn) return TransactionBadgeKind.friendReturn;
    if (cat == settlementCategory.toLowerCase() || cat == 'settlement') {
      return TransactionBadgeKind.settlement;
    }
    if (outingId != null && outingId!.isNotEmpty) {
      return TransactionBadgeKind.outing;
    }
    if (isSplitExpense) return TransactionBadgeKind.splitExpense;
    // No multi-row split but flagged as a group spend → shared with friends.
    if (isGroup || _hasFriendSplitRecord(id)) return TransactionBadgeKind.friendSplit;
    return TransactionBadgeKind.none;
  }

  /// Distinct purposes — one for a normal row, all slices for a split.
  List<String> get purposeNames {
    if (!isSplitExpense) {
      final p = (purpose ?? '').trim();
      return p.isEmpty ? const [] : [p];
    }
    final seen = <String>{};
    final out = <String>[];
    for (final s in splits) {
      final name = s.purposeId.trim();
      if (name.isEmpty || !seen.add(name.toLowerCase())) continue;
      out.add(name);
    }
    return out.isEmpty ? [(purpose ?? '').trim()] : out;
  }

  Transaction({
    String? id,
    required this.merchant,
    required this.category,
    required this.account,
    required this.time,
    required this.amount,
    required this.isExpense,
    this.isAutoDetected = false,
    this.isGroup = false,
    this.groupCount = 0,
    this.paymentType = 'Online',
    required this.date,
    this.isTransfer = false,
    this.transferTo,
    this.toAccountId,
    this.transferType,
    this.remoteId,
    this.outingId,
    this.linkedExpenseId,
    this.isAutoLinked = false,
    this.rawIdentifier,
    this.purpose,
    this.bankName = '',
    this.accountLast4 = '',
    this.referenceId = '',
    this.upiId = '',
    this.rawMessage = '',
    this.note = '',
    this.description = '',
    this.isPendingVerification = false,
    this.isMerchantMapped = false,
    this.contributorSource,
    this.splits = const [],
    this.title,
    this.items = const [],
  }) : id = id ?? const Uuid().v4();

  Map<String, dynamic> toJson() => {
    'id': id,
    'merchant': merchant,
    'category': category,
    'account': account,
    'time': time,
    'amount': amount,
    'isExpense': isExpense,
    'isAutoDetected': isAutoDetected,
    'isGroup': isGroup,
    'groupCount': groupCount,
    'paymentType': paymentType,
    // Always emit an explicit UTC ('Z') timestamp — DateTime.now() is local,
    // and .toIso8601String() on a local DateTime has NO timezone marker.
    // Sent bare like that, Supabase's timestamptz column assumes its own
    // (UTC) session timezone instead of the device's, silently shifting the
    // stored instant forward by the device's UTC offset (e.g. +5:30 for
    // IST) — a 9:00 PM entry round-trips back as ~2:30 AM the next day.
    // Web is unaffected: JS Date.toISOString() is always UTC already.
    'date': date.toUtc().toIso8601String(),
    'isTransfer': isTransfer,
    'transferTo': transferTo,
    'toAccountId': toAccountId,
    'transferType': transferType,
    'remoteId': remoteId,
    'outingId': outingId,
    'linkedExpenseId': linkedExpenseId,
    'isAutoLinked': isAutoLinked,
    'rawIdentifier': rawIdentifier,
    'purpose': purpose,
    'bankName': bankName,
    'accountLast4': accountLast4,
    'referenceId': referenceId,
    'upiId': upiId,
    'rawMessage': rawMessage,
    'note': note,
    'description': description,
    'isPendingVerification': isPendingVerification,
    'isMerchantMapped': isMerchantMapped,
    'contributorSource': contributorSource,
    'splits': splits.map((s) => s.toJson()).toList(),
    'title': title,
    'items': items.map((i) => i.toJson()).toList(),
  };

  factory Transaction.fromJson(Map<dynamic, dynamic> json) => Transaction(
      id: json['id'],
      merchant: json['merchant'] ?? '',
      category: json['category'] ?? 'Other',
      account: json['account'] ?? 'Personal',
      time: json['time'] ?? '',
      amount: (json['amount'] as num? ?? 0).toDouble(),
      isExpense: json['isExpense'] ?? true,
      isAutoDetected: json['isAutoDetected'] ?? false,
      isGroup: json['isGroup'] ?? false,
      groupCount: json['groupCount'] ?? 0,
      paymentType: json['paymentType'] ?? 'Online',
      // Stored as UTC (see toJson) — convert back to local so calendar-day/
      // month comparisons against DateTime.now() (local) land on the day the
      // user actually experienced, not a UTC-shifted one (IST etc. can push
      // a late-night transaction into a different UTC day/month).
      date: DateTime.parse(json['date'] ?? DateTime.now().toIso8601String()).toLocal(),
      isTransfer: json['isTransfer'] ?? false,
      transferTo: json['transferTo'],
      toAccountId: json['toAccountId']?.toString(),
      transferType: json['transferType']?.toString(),
      remoteId: json['remoteId'],
      outingId: json['outingId'],
      linkedExpenseId: json['linkedExpenseId']?.toString(),
      isAutoLinked: json['isAutoLinked'] ?? false,
      rawIdentifier: json['rawIdentifier'],
      purpose: json['purpose'],
      bankName: json['bankName'] ?? '',
      accountLast4: json['accountLast4'] ?? '',
      referenceId: json['referenceId'] ?? '',
      upiId: json['upiId'] ?? '',
      rawMessage: json['rawMessage'] ?? '',
      note: json['note'] ?? '',
      description: json['description']?.toString() ?? '',
      isPendingVerification: json['isPendingVerification'] ?? false,
      isMerchantMapped: json['isMerchantMapped'] ?? false,
      contributorSource: json['contributorSource']?.toString(),
      splits: (() {
        final list = (json['splits'] as List?)
                ?.map((e) => TransactionSplitRow.fromJson(e as Map))
                .toList() ??
            const <TransactionSplitRow>[];
        if (list.length <= 1) return list;
        final txAmount = (json['amount'] as num? ?? 0).toDouble();
        if (txAmount > 0) {
          final total = list.fold<double>(0.0, (acc, s) => acc + s.amount);
          if (total > txAmount * 1.05) return const <TransactionSplitRow>[];
        }
        return list;
      })(),
      title: json['title']?.toString(),
      items: (json['items'] as List?)
              ?.map((e) => TransactionItemRow.fromJson(e as Map))
              .toList() ??
          const [],
    );

  String get receiver => merchant;
  String get bank => bankName;

  /// True for a cash movement detected from a bank SMS (ATM withdrawal or
  /// cash deposit) rather than a transfer the user typed in.
  ///
  /// These are a different UX from a manual transfer: the destination is
  /// always Cash, so it's implied by the label and never shown as "A → B".
  /// Keyed on the merchant labels `SmsAtmHelper` stamps at detection time.
  bool get isAtmTransfer =>
      isTransfer &&
      (merchant.trim() == 'ATM Withdrawal' || merchant.trim() == 'Cash Deposit');

  Transaction copyWith({
    String? merchant,
    String? category,
    String? account,
    String? time,
    double? amount,
    bool? isExpense,
    String? paymentType,
    DateTime? date,
    bool? isTransfer,
    String? transferTo,
    String? toAccountId,
    String? transferType,
    String? remoteId,
    String? outingId,
    String? linkedExpenseId,
    bool? isAutoLinked,
    bool clearOutingId = false,
    String? rawIdentifier,
    String? purpose,
    String? bankName,
    String? accountLast4,
    String? referenceId,
    String? upiId,
    String? rawMessage,
    String? note,
    String? description,
    bool? isPendingVerification,
    bool? isMerchantMapped,
    String? contributorSource,
    bool clearContributorSource = false,
    List<TransactionSplitRow>? splits,
    bool? isGroup,
    int? groupCount,
    String? title,
    bool clearTitle = false,
    List<TransactionItemRow>? items,
  }) {
    return Transaction(
      id: id,
      merchant: merchant ?? this.merchant,
      category: category ?? this.category,
      account: account ?? this.account,
      time: time ?? this.time,
      amount: amount ?? this.amount,
      isExpense: isExpense ?? this.isExpense,
      isAutoDetected: isAutoDetected,
      isGroup: isGroup ?? this.isGroup,
      groupCount: groupCount ?? this.groupCount,
      paymentType: paymentType ?? this.paymentType,
      date: date ?? this.date,
      isTransfer: isTransfer ?? this.isTransfer,
      transferTo: transferTo ?? this.transferTo,
      toAccountId: toAccountId ?? this.toAccountId,
      transferType: transferType ?? this.transferType,
      remoteId: remoteId ?? this.remoteId,
      outingId: clearOutingId ? null : (outingId ?? this.outingId),
      linkedExpenseId: linkedExpenseId ?? this.linkedExpenseId,
      isAutoLinked: clearOutingId ? false : (isAutoLinked ?? this.isAutoLinked),
      splits: splits ?? this.splits,
      rawIdentifier: rawIdentifier ?? this.rawIdentifier,
      purpose: purpose ?? this.purpose,
      bankName: bankName ?? this.bankName,
      accountLast4: accountLast4 ?? this.accountLast4,
      referenceId: referenceId ?? this.referenceId,
      upiId: upiId ?? this.upiId,
      rawMessage: rawMessage ?? this.rawMessage,
      note: note ?? this.note,
      description: description ?? this.description,
      isPendingVerification: isPendingVerification ?? this.isPendingVerification,
      isMerchantMapped: isMerchantMapped ?? this.isMerchantMapped,
      contributorSource: clearContributorSource
          ? null
          : (contributorSource ?? this.contributorSource),
      title: clearTitle ? null : (title ?? this.title),
      items: items ?? this.items,
    );
  }
}
