class ProjectorSettingsModel {
  final int currentAge;
  final double monthlySavings;
  final double incomeGrowthRate;
  final double investmentReturnRate;

  const ProjectorSettingsModel({
    this.currentAge = 25,
    this.monthlySavings = 15000,
    this.incomeGrowthRate = 10.0,
    this.investmentReturnRate = 12.0,
  });

  Map<String, dynamic> toMap() => {
        'currentAge': currentAge,
        'monthlySavings': monthlySavings,
        'incomeGrowthRate': incomeGrowthRate,
        'investmentReturnRate': investmentReturnRate,
      };

  factory ProjectorSettingsModel.fromMap(Map<String, dynamic> map) {
    return ProjectorSettingsModel(
      currentAge: (map['currentAge'] as num? ?? map['current_age'] as num? ?? 25).toInt(),
      monthlySavings: (map['monthlySavings'] as num? ?? map['monthly_savings'] as num? ?? 15000).toDouble(),
      incomeGrowthRate: (map['incomeGrowthRate'] as num? ?? map['income_growth_rate'] as num? ?? 10.0).toDouble(),
      investmentReturnRate: (map['investmentReturnRate'] as num? ?? map['investment_return_rate'] as num? ?? 12.0).toDouble(),
    );
  }

  ProjectorSettingsModel copyWith({
    int? currentAge,
    double? monthlySavings,
    double? incomeGrowthRate,
    double? investmentReturnRate,
  }) {
    return ProjectorSettingsModel(
      currentAge: currentAge ?? this.currentAge,
      monthlySavings: monthlySavings ?? this.monthlySavings,
      incomeGrowthRate: incomeGrowthRate ?? this.incomeGrowthRate,
      investmentReturnRate: investmentReturnRate ?? this.investmentReturnRate,
    );
  }

  /// Calculates projected net worth at a given target age based on web formula.
  double projectNetWorthAtAge({
    required double currentNetWorth,
    required int targetAge,
    double savingsMultiplier = 1.0,
    double incomeGrowthMultiplier = 1.0,
    double returnMultiplier = 1.0,
  }) {
    if (targetAge <= currentAge) return currentNetWorth;

    double wealth = currentNetWorth;
    double contribution = monthlySavings * savingsMultiplier;
    final monthlyReturn = (investmentReturnRate * returnMultiplier) / 100 / 12;
    final annualIncomeGrowth = (incomeGrowthRate * incomeGrowthMultiplier) / 100;

    for (int age = currentAge; age < targetAge; age++) {
      for (int month = 0; month < 12; month++) {
        wealth = wealth * (1 + monthlyReturn) + contribution;
      }
      contribution *= (1 + annualIncomeGrowth);
    }

    return wealth;
  }
}
