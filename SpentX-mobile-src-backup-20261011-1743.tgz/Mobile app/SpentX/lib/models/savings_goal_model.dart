import 'package:uuid/uuid.dart';

class SavingsGoalModel {
  final String id;
  final String? userId;
  final String name;
  final double targetAmount;
  final double savedAmount;
  final double? monthlyContribution;
  final String? targetDate;
  final String? color;
  final String? icon;
  final bool isActive;
  final String? createdAt;
  final String? updatedAt;

  static const defaultIcon = '🎯';

  SavingsGoalModel({
    String? id,
    this.userId,
    required this.name,
    required this.targetAmount,
    this.savedAmount = 0.0,
    this.monthlyContribution,
    this.targetDate,
    this.color,
    this.icon,
    this.isActive = true,
    this.createdAt,
    this.updatedAt,
  }) : id = id ?? const Uuid().v4();

  /// Old rows (and the old DB default) stored the word "target" instead of
  /// an emoji. Never show that word to the user.
  String get displayIcon {
    final value = icon?.trim() ?? '';
    if (value.isEmpty || value.toLowerCase() == 'target') return defaultIcon;
    return value;
  }

  double get progressPercentage {
    if (targetAmount <= 0) return 0.0;
    final pct = (savedAmount / targetAmount);
    return pct.clamp(0.0, 1.0);
  }

  bool get isCompleted => savedAmount >= targetAmount && targetAmount > 0;

  /// Always carries `target_date` and `monthly_contribution` (null clears
  /// them on the server too).
  Map<String, dynamic> toMap() => {
        'id': id,
        if (userId != null) 'user_id': userId,
        'name': name,
        'target_amount': targetAmount,
        'saved_amount': savedAmount,
        'monthly_contribution': monthlyContribution,
        'target_date': targetDate,
        if (color != null) 'color': color,
        if (icon != null) 'icon': icon,
        'is_active': isActive,
        if (createdAt != null) 'created_at': createdAt,
        if (updatedAt != null) 'updated_at': updatedAt,
      };

  static double? _num(Object? v) => v is num ? v.toDouble() : double.tryParse('${v ?? ''}');

  factory SavingsGoalModel.fromMap(Map<String, dynamic> map) {
    final rawDate = (map['target_date'] ?? map['targetDate'])?.toString();
    return SavingsGoalModel(
      id: map['id']?.toString() ?? const Uuid().v4(),
      userId: map['user_id']?.toString() ?? map['userId']?.toString(),
      name: map['name']?.toString() ?? '',
      targetAmount: _num(map['target_amount'] ?? map['targetAmount']) ?? 0.0,
      savedAmount: _num(map['saved_amount'] ?? map['savedAmount']) ?? 0.0,
      monthlyContribution: _num(map['monthly_contribution'] ?? map['monthlyContribution']),
      targetDate: rawDate == null || rawDate.isEmpty
          ? null
          : (rawDate.length >= 10 ? rawDate.substring(0, 10) : rawDate),
      color: map['color']?.toString() ?? 'indigo',
      icon: map['icon']?.toString() ?? defaultIcon,
      isActive: map['is_active'] == null ? true : (map['is_active'] as bool? ?? true),
      createdAt: map['created_at']?.toString() ?? map['createdAt']?.toString(),
      updatedAt: map['updated_at']?.toString() ?? map['updatedAt']?.toString(),
    );
  }

  /// Pass `clearTargetDate` / `clearMonthlyContribution` to remove a value;
  /// a plain null argument keeps the current one.
  SavingsGoalModel copyWith({
    String? name,
    double? targetAmount,
    double? savedAmount,
    double? monthlyContribution,
    bool clearMonthlyContribution = false,
    String? targetDate,
    bool clearTargetDate = false,
    String? color,
    String? icon,
    bool? isActive,
    String? createdAt,
    String? updatedAt,
  }) {
    return SavingsGoalModel(
      id: id,
      userId: userId,
      name: name ?? this.name,
      targetAmount: targetAmount ?? this.targetAmount,
      savedAmount: savedAmount ?? this.savedAmount,
      monthlyContribution: clearMonthlyContribution
          ? null
          : (monthlyContribution ?? this.monthlyContribution),
      targetDate: clearTargetDate ? null : (targetDate ?? this.targetDate),
      color: color ?? this.color,
      icon: icon ?? this.icon,
      isActive: isActive ?? this.isActive,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}
