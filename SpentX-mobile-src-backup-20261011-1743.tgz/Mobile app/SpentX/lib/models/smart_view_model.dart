import 'package:flutter/foundation.dart';

@immutable
class SmartViewModel {
  final String id;
  final String userId;
  final String name;
  final String? accountId;
  final String? purposeId;
  final List<String> categoryIds;
  final String? contributorId;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  const SmartViewModel({
    required this.id,
    required this.userId,
    required this.name,
    this.accountId,
    this.purposeId,
    this.categoryIds = const [],
    this.contributorId,
    this.createdAt,
    this.updatedAt,
  });

  factory SmartViewModel.fromMap(Map<String, dynamic> map) {
    List<String> parsedCategories = [];
    if (map['category_ids'] != null) {
      if (map['category_ids'] is List) {
        parsedCategories = (map['category_ids'] as List)
            .map((e) => e.toString())
            .toList();
      }
    }

    return SmartViewModel(
      id: (map['id'] ?? '').toString(),
      userId: (map['user_id'] ?? '').toString(),
      name: (map['name'] ?? '').toString(),
      accountId: map['account_id']?.toString(),
      purposeId: map['purpose_id']?.toString(),
      categoryIds: parsedCategories,
      contributorId: map['contributor_id']?.toString(),
      createdAt: map['created_at'] != null
          ? DateTime.tryParse(map['created_at'].toString())?.toLocal()
          : null,
      updatedAt: map['updated_at'] != null
          ? DateTime.tryParse(map['updated_at'].toString())?.toLocal()
          : null,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'user_id': userId,
      'name': name,
      'account_id': accountId,
      'purpose_id': purposeId,
      'category_ids': categoryIds,
      'contributor_id': contributorId,
    };
  }
}
