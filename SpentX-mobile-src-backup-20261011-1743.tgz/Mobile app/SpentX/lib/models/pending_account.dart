/// An account SpentX believes the user has, inferred from their bank SMS,
/// but has NOT created.
///
/// The merchant loop, applied to accounts: SMS proposes, the user decides.
/// Nothing here is an [AccountModel] and nothing here counts toward a balance
/// or net worth until the user converts it — see docs/ACCOUNT_DISCOVERY.md.
///
/// Local-only by design. This carries raw SMS provenance, and a half-guessed
/// account has no business appearing on another device, so it is deliberately
/// absent from [SupabaseSchemaMap] and never queued for sync. Only the
/// confirmed [AccountModel] syncs.
///
/// Plain class with [toJson]/[fromJson] into an untyped Hive box, matching
/// [PendingTransaction] — this project registers no Hive adapters.
library;

enum PendingAccountStatus {
  /// Awaiting the user's decision. The only status the UI offers.
  suggested,

  /// User said no. Kept forever rather than deleted: the row IS the
  /// ignore list, and deleting it would make the same account ask again.
  ignored,

  /// User turned it into a real account. Kept so a re-seen SMS resolves to
  /// "already handled" instead of proposing a duplicate.
  converted,
}

PendingAccountStatus _statusFromName(String? raw) {
  return PendingAccountStatus.values.firstWhere(
    (s) => s.name == raw,
    orElse: () => PendingAccountStatus.suggested,
  );
}

class PendingAccount {
  /// `<bankToken>_<last4>` — deterministic, so the same account always lands
  /// on the same row and re-seeing it updates rather than duplicates.
  final String id;

  /// Canonical keyword ('hdfc'), shared with the allowlist so a suggestion
  /// and the account it becomes resolve identically.
  final String bankToken;

  /// What to show the user ('HDFC Bank'). Display only — never matched on.
  final String displayBank;

  final String last4;

  /// `Bank` | `Credit` | `Wallet` — an [AccountModel] type string, not an
  /// enum, because that is what AccountModel.type actually is.
  final String suggestedType;

  /// Balance quoted by the most recent SMS. A hint shown to the user, never
  /// written into an opening balance.
  final double? lastSeenBalance;
  final DateTime? lastSeenBalanceAt;

  /// Id in `detected_sms_box` backing "show me the message".
  final String sampleSmsId;

  /// Messages seen for this account. One hit is weak evidence (a forwarded
  /// SMS, a one-off); many hits over weeks is almost certainly theirs.
  final int hitCount;

  final DateTime firstSeen;
  final DateTime lastSeen;
  final PendingAccountStatus status;

  const PendingAccount({
    required this.id,
    required this.bankToken,
    required this.displayBank,
    required this.last4,
    required this.suggestedType,
    required this.sampleSmsId,
    required this.hitCount,
    required this.firstSeen,
    required this.lastSeen,
    this.status = PendingAccountStatus.suggested,
    this.lastSeenBalance,
    this.lastSeenBalanceAt,
  });

  bool get isSuggested => status == PendingAccountStatus.suggested;

  /// Weak evidence — a single message. Shown lower / behind "older".
  bool get isWeak => hitCount <= 1;

  /// Pre-filled name for the account form. The user can rename it; this is a
  /// starting point, not a decision.
  String get suggestedName => switch (suggestedType) {
        'Credit' => '$displayBank Credit Card',
        'Wallet' => displayBank,
        _ => displayBank,
      };

  PendingAccount copyWith({
    String? displayBank,
    String? suggestedType,
    double? lastSeenBalance,
    DateTime? lastSeenBalanceAt,
    String? sampleSmsId,
    int? hitCount,
    DateTime? lastSeen,
    PendingAccountStatus? status,
  }) {
    return PendingAccount(
      id: id,
      bankToken: bankToken,
      displayBank: displayBank ?? this.displayBank,
      last4: last4,
      suggestedType: suggestedType ?? this.suggestedType,
      lastSeenBalance: lastSeenBalance ?? this.lastSeenBalance,
      lastSeenBalanceAt: lastSeenBalanceAt ?? this.lastSeenBalanceAt,
      sampleSmsId: sampleSmsId ?? this.sampleSmsId,
      hitCount: hitCount ?? this.hitCount,
      firstSeen: firstSeen,
      lastSeen: lastSeen ?? this.lastSeen,
      status: status ?? this.status,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'bankToken': bankToken,
        'displayBank': displayBank,
        'last4': last4,
        'suggestedType': suggestedType,
        'lastSeenBalance': lastSeenBalance,
        'lastSeenBalanceAt': lastSeenBalanceAt?.toIso8601String(),
        'sampleSmsId': sampleSmsId,
        'hitCount': hitCount,
        'firstSeen': firstSeen.toIso8601String(),
        'lastSeen': lastSeen.toIso8601String(),
        'status': status.name,
      };

  factory PendingAccount.fromJson(Map<dynamic, dynamic> json) {
    final now = DateTime.now();
    return PendingAccount(
      id: json['id']?.toString() ?? '',
      bankToken: json['bankToken']?.toString() ?? '',
      displayBank: json['displayBank']?.toString() ?? '',
      last4: json['last4']?.toString() ?? '',
      suggestedType: json['suggestedType']?.toString() ?? 'Bank',
      lastSeenBalance: (json['lastSeenBalance'] as num?)?.toDouble(),
      lastSeenBalanceAt: DateTime.tryParse(
        json['lastSeenBalanceAt']?.toString() ?? '',
      ),
      sampleSmsId: json['sampleSmsId']?.toString() ?? '',
      hitCount: (json['hitCount'] as num?)?.toInt() ?? 1,
      firstSeen:
          DateTime.tryParse(json['firstSeen']?.toString() ?? '') ?? now,
      lastSeen: DateTime.tryParse(json['lastSeen']?.toString() ?? '') ?? now,
      status: _statusFromName(json['status']?.toString()),
    );
  }
}
