import 'package:flutter/foundation.dart';
import '../core/sync/supabase_schema_map.dart';

@immutable
class PurposeShareModel {
  final String id;
  final String ownerId;
  final String viewerEmail;
  final String? viewerId;
  final String purposeId;
  final String? purposeName;
  final String role;
  final String? linkToken;
  final String? contributorId;
  final String? contributorName;
  final DateTime? expiresAt;
  final String status; // 'pending' | 'active' | 'revoked'
  final String kind; // 'link' | 'email'
  final DateTime? lastViewedAt;
  final int totalViews;
  final DateTime createdAt;

  const PurposeShareModel({
    required this.id,
    required this.ownerId,
    required this.viewerEmail,
    this.viewerId,
    required this.purposeId,
    this.purposeName,
    this.role = 'viewer',
    this.linkToken,
    this.contributorId,
    this.contributorName,
    this.expiresAt,
    required this.status,
    required this.kind,
    this.lastViewedAt,
    this.totalViews = 0,
    required this.createdAt,
  });

  bool get isLink =>
      kind == 'link' ||
      viewerEmail.isEmpty ||
      viewerEmail.toLowerCase().startsWith('link-share-');

  String get displayLabel => isLink ? 'View link' : viewerEmail;

  bool get isExpired =>
      expiresAt != null && DateTime.now().isAfter(expiresAt!);

  String get shareUrl {
    final token = (linkToken != null && linkToken!.isNotEmpty) ? linkToken! : id;
    return token.isNotEmpty ? 'https://app.spentx.tech/share/$token' : '';
  }

  factory PurposeShareModel.fromMap(Map<String, dynamic> map) {
    final rawEmail = (map['viewer_email'] ?? '').toString();
    final pId = (map['purpose_id'] ?? '').toString();
    final cId = map['contributor_id']?.toString();
    final resolvedKind = (map['kind'] ?? '').toString().toLowerCase();

    DateTime? exp;
    if (map['expires_at'] != null) {
      exp = DateTime.tryParse(map['expires_at'].toString())?.toLocal();
    }
    DateTime? lastView;
    if (map['last_viewed_at'] != null) {
      lastView = DateTime.tryParse(map['last_viewed_at'].toString())?.toLocal();
    }
    DateTime created = DateTime.now();
    if (map['created_at'] != null) {
      created = DateTime.tryParse(map['created_at'].toString())?.toLocal() ?? DateTime.now();
    }

    final kindValue = resolvedKind.isNotEmpty
        ? resolvedKind
        : (rawEmail.startsWith('link-share-') ? 'link' : 'email');

    return PurposeShareModel(
      id: (map['id'] ?? '').toString(),
      ownerId: (map['owner_id'] ?? '').toString(),
      viewerEmail: rawEmail,
      viewerId: map['viewer_id']?.toString(),
      purposeId: pId,
      purposeName: RemoteIdCache.purposeName(pId) ?? (pId.isEmpty ? 'Personal' : null),
      role: (map['role'] ?? 'viewer').toString(),
      linkToken: map['link_token']?.toString(),
      contributorId: cId,
      contributorName: cId != null ? RemoteIdCache.contributorName(cId) : null,
      expiresAt: exp,
      status: (map['status'] ?? 'pending').toString(),
      kind: kindValue,
      lastViewedAt: lastView,
      totalViews: int.tryParse(map['total_views']?.toString() ?? '0') ?? 0,
      createdAt: created,
    );
  }
}
