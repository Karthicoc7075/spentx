import 'dart:async';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:hive/hive.dart';
import 'package:spentx/core/sync/durable_collection.dart';
import 'package:spentx/core/services/sign_out_guard.dart';

void main() {
  late Directory directory;
  late Box box;
  setUp(() async {
    directory = await Directory.systemTemp.createTemp('spentx-high7-');
    Hive.init(directory.path);
    box = await Hive.openBox('settings');
  });
  tearDown(() async {
    await Hive.close();
    await directory.delete(recursive: true);
  });

  test(
    'offline goal edits survive restart and block destructive logout',
    () async {
      var store = DurableCollection(box, 'goals:A');
      await store.stage('goal', {'id': 'goal', 'saved_amount': 500});
      await expectLater(
        requireSyncedChanges(
          hasPending: () => store.hasPending,
          flush: () async => throw StateError('offline'),
        ),
        throwsA(isA<UnsyncedChangesException>()),
      );
      await box.close();
      box = await Hive.openBox('settings');
      store = DurableCollection(box, 'goals:A');
      expect(store.hasPending, isTrue);
      final server = <String, Map<String, dynamic>>{};
      await store.synchronize(
        write: (id, row) async {
          server[id] = row!;
        },
        read: () async => server.values.toList(),
        isCurrent: () => true,
      );
      expect(store.rows.single['saved_amount'], 500);
      expect(store.hasPending, isFalse);
    },
  );

  test('offline delete retries before pull and never resurrects', () async {
    final store = DurableCollection(box, 'goals:A');
    await store.importRows([
      {'id': 'goal'},
    ]);
    await store.stage('goal', null);
    await expectLater(
      store.synchronize(
        write: (_, __) async => throw StateError('offline'),
        read:
            () async => [
              {'id': 'goal'},
            ],
        isCurrent: () => true,
      ),
      throwsStateError,
    );
    expect(store.rows, isEmpty);
    var deleted = false;
    await store.synchronize(
      write: (_, row) async {
        expect(row, isNull);
        deleted = true;
      },
      read: () async {
        expect(deleted, isTrue);
        return [];
      },
      isCurrent: () => true,
    );
    expect(store.hasPending, isFalse);
    expect(store.rows, isEmpty);
  });

  test('new edit during upload survives old acknowledgement', () async {
    final store = DurableCollection(box, 'goals:A');
    await store.stage('goal', {'id': 'goal', 'saved_amount': 100});
    final uploaded = <int>[];
    await store.synchronize(
      write: (_, row) async {
        uploaded.add(row!['saved_amount'] as int);
        if (uploaded.length == 1) {
          await store.stage('goal', {'id': 'goal', 'saved_amount': 200});
        }
      },
      read:
          () async => [
            {'id': 'goal', 'saved_amount': uploaded.last},
          ],
      isCurrent: () => true,
    );
    expect(uploaded, [100, 200]);
    expect(store.rows.single['saved_amount'], 200);
  });

  test('pending local edits overlay an older in-flight pull', () async {
    final store = DurableCollection(box, 'goals:A');
    await store.synchronize(
      write: (_, __) async {},
      read: () async {
        await store.stage('goal', {'id': 'goal', 'saved_amount': 700});
        return [
          {'id': 'goal', 'saved_amount': 100},
        ];
      },
      isCurrent: () => true,
    );
    expect(store.rows.single['saved_amount'], 700);
    expect(store.hasPending, isTrue);
  });

  test('late response cannot repopulate data after logout', () async {
    final store = DurableCollection(box, 'goals:A');
    var current = true;
    final response = Completer<List<Map<String, dynamic>>>();
    final syncing = store.synchronize(
      write: (_, __) async {},
      read: () => response.future,
      isCurrent: () => current,
    );
    current = false;
    await box.clear();
    response.complete([
      {'id': 'private'},
    ]);
    await syncing;
    expect(store.rows, isEmpty);
    expect(DurableCollection(box, 'goals:B').rows, isEmpty);
  });

  test(
    'legacy recurring bills upload once and restore after local wipe',
    () async {
      final store = DurableCollection(box, 'bills:A');
      final server = <String, Map<String, dynamic>>{};
      await store.importRows([
        {'id': 'rent', 'amount': 2000},
      ], upload: true);
      expect(store.hasPending, isTrue);
      await store.synchronize(
        write: (id, row) async {
          server[id] = row!;
        },
        read: () async => server.values.toList(),
        isCurrent: () => true,
      );
      await box.clear();
      final restored = DurableCollection(box, 'bills:A');
      await restored.synchronize(
        write: (_, __) async {},
        read: () async => server.values.toList(),
        isCurrent: () => true,
      );
      expect(restored.rows.single['amount'], 2000);
      expect(DurableCollection(box, 'bills:B').rows, isEmpty);
    },
  );
}
