// Pure Dart assertions (no flutter_test dependency in this project).
// Run: dart run test/plan_alerts_test.dart
import 'package:spentx/core/utils/friend_net.dart';
import 'package:spentx/core/utils/plan_alerts.dart';
import 'dart:io';

void _assert(bool cond, String msg) {
  if (!cond) {
    throw Exception('ASSERT FAILED: $msg');
  }
}

void main() {
  stdout.writeln('── Plan alerts ──');
  final now = DateTime(2026, 9, 10);
  final alerts = buildPlanAlerts(
    plannedTotal: 10000,
    savedDailyLimit: 300,
    allocations: const [
      PlanCategoryBudget(category: 'Food', planned: 4000),
    ],
    spends: [
      for (var day = 1; day <= 8; day++)
        PlanSpend(amount: 800, category: 'Food', date: DateTime(2026, 9, day)),
      PlanSpend(amount: 500, category: 'Food', date: DateTime(2026, 9, 10)),
    ],
    now: now,
  );

  _assert(
    alerts.any((a) => a.id == 'burn-rate-2026-09'),
    'burn missing ${alerts.map((a) => a.id).toList()}',
  );
  _assert(
    alerts.any((a) => a.id == 'daily-limit-2026-09-10'),
    'daily missing ${alerts.map((a) => a.id).toList()}',
  );
  _assert(
    alerts.any((a) => a.id == 'weekly-share-Food-2026-09-w2'),
    'weekly missing ${alerts.map((a) => a.id).toList()}',
  );

  final quiet = buildPlanAlerts(
    plannedTotal: 30000,
    savedDailyLimit: 2000,
    allocations: const [
      PlanCategoryBudget(category: 'Food', planned: 9000),
    ],
    spends: [
      PlanSpend(amount: 100, category: 'Food', date: now),
    ],
    now: now,
  );
  _assert(quiet.isEmpty, 'quiet month raised ${quiet.map((a) => a.type)}');

  final lateMonth = buildPlanAlerts(
    plannedTotal: 10000,
    savedDailyLimit: 2000,
    allocations: const [
      PlanCategoryBudget(category: 'Food', planned: 4000),
    ],
    spends: [
      PlanSpend(amount: 8000, category: 'Food', date: DateTime(2026, 9, 20)),
    ],
    now: DateTime(2026, 9, 20),
  );
  _assert(
    lateMonth.every((a) => a.type != 'burn-rate'),
    'burn fired in the second half ${lateMonth.map((a) => a.type)}',
  );

  final computedLimit = buildPlanAlerts(
    plannedTotal: 3000,
    savedDailyLimit: null,
    allocations: const [],
    spends: [
      PlanSpend(amount: 200, category: 'Food', date: DateTime(2026, 9, 10)),
    ],
    now: now,
  );
  _assert(
    computedLimit.any((a) => a.type == 'daily-limit'),
    'computed daily limit missing',
  );

  stdout.writeln('── Friend net ──');
  final both = friendRunningBalance(
    outingTheyOwe: 400,
    outingYouOwe: 150,
    splitSigned: 50,
  );
  _assert(both.theyOweYou == 400, 'they ${both.theyOweYou}');
  _assert(both.youOweThem == 200, 'you ${both.youOweThem}');
  _assert(both.net == 200, 'net ${both.net}');

  final theyOweFromSplit = friendRunningBalance(
    outingTheyOwe: 0,
    outingYouOwe: 0,
    splitSigned: -80,
  );
  _assert(theyOweFromSplit.net == 80, 'split receive ${theyOweFromSplit.net}');

  stdout.writeln('  plan alerts + friend net OK');
}
