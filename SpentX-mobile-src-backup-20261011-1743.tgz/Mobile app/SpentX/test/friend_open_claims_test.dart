// Pure Dart assertions (no flutter_test dependency in this project).
// Run: dart run test/friend_open_claims_test.dart
//
// Covers the money math behind repayment matching: which claims get
// pre-ticked for an incoming credit, and how a credit is split across the
// claims the user ticked. These are the two places a wrong answer silently
// corrupts a friend balance.
import 'package:spentx/models/friend_open_claim.dart';
import 'package:spentx/core/utils/upi_vpa.dart';
import 'dart:io';

void _assert(bool cond, String msg) {
  if (!cond) {
    throw Exception('ASSERT FAILED: $msg');
  }
}

FriendOpenClaim _claim({
  required String id,
  required double outstanding,
  int dayOffset = 0,
}) =>
    FriendOpenClaim(
      source: FriendClaimSource.friendSplit,
      outingId: '',
      expenseId: '',
      splitId: id,
      referenceName: id,
      friendName: 'Ravi',
      friendMemberId: 'ravi',
      youMemberId: 'you',
      outstanding: outstanding,
      incurredAt: DateTime(2026, 1, 1).add(Duration(days: dayOffset)),
    );

void main() {
  stdout.writeln('── preselect ──');
  {
    final goa = _claim(id: 'goa', outstanding: 500);
    final dinner = _claim(id: 'dinner', outstanding: 300, dayOffset: 2);

    // Exactly one claim matches the credit -> pre-tick it.
    final exact = FriendClaimMath.preselect([goa, dinner], 500);
    _assert(exact.length == 1 && exact.contains(goa.id), 'exact=$exact');

    // Credit clears everything -> tick all ("settling up").
    final all = FriendClaimMath.preselect([goa, dinner], 800);
    _assert(all.length == 2, 'all=$all');

    // Short payment is ambiguous -> tick nothing, let the user choose.
    _assert(
      FriendClaimMath.preselect([goa, dinner], 400).isEmpty,
      'short payment must not pre-tick',
    );

    // Overpayment is ambiguous -> tick nothing.
    _assert(
      FriendClaimMath.preselect([goa, dinner], 600).isEmpty,
      'overpayment must not pre-tick',
    );

    // Two claims that could each explain the credit -> never guess.
    final twin = FriendClaimMath.preselect(
      [_claim(id: 'a', outstanding: 500), _claim(id: 'b', outstanding: 500)],
      500,
    );
    _assert(twin.isEmpty, 'ambiguous twin claims must not pre-tick: $twin');

    // No open claims -> nothing to match, whatever the amount.
    _assert(
      FriendClaimMath.preselect(const [], 500).isEmpty,
      'no claims must not pre-tick',
    );
  }
  stdout.writeln('  preselect OK');

  stdout.writeln('── allocate ──');
  {
    final goa = _claim(id: 'goa', outstanding: 500);
    final dinner = _claim(id: 'dinner', outstanding: 300, dayOffset: 2);

    // Exact: full settle, nothing left over.
    final exact = FriendClaimMath.allocate([goa], 500);
    _assert(exact[goa.id] == 500, 'exact allocate=$exact');
    _assert(
      FriendClaimMath.unallocated([goa], 500) == 0,
      'exact should leave nothing unallocated',
    );

    // Under: partial settle, claim keeps the remainder.
    final under = FriendClaimMath.allocate([goa], 400);
    _assert(under[goa.id] == 400, 'under allocate=$under');

    // Over: cap at what is owed, surface the extra rather than inventing a
    // place to put it.
    final over = FriendClaimMath.allocate([goa], 600);
    _assert(over[goa.id] == 500, 'over must cap at outstanding: $over');
    _assert(
      FriendClaimMath.unallocated([goa], 600) == 100,
      'over must report 100 extra',
    );

    // Multiple ticked claims fill oldest-first.
    final both = FriendClaimMath.allocate([goa, dinner], 650);
    _assert(both[goa.id] == 500, 'oldest claim filled first: $both');
    _assert(both[dinner.id] == 150, 'remainder to newer claim: $both');

    // Nothing ticked -> nothing allocated, however large the credit.
    _assert(
      FriendClaimMath.allocate(const [], 500).isEmpty,
      'no ticked claims must allocate nothing',
    );

    _assert(
      FriendClaimMath.totalOutstanding([goa, dinner]) == 800,
      'totalOutstanding',
    );
  }
  stdout.writeln('  allocate OK');

  stdout.writeln('── real VPA guard ──');
  {
    _assert(isRealUpiVpa('ravi@ybl'), 'ravi@ybl is a VPA');
    _assert(!isRealUpiVpa('CLEARING'), 'name is not a VPA');
    _assert(!isRealUpiVpa(''), 'empty is not a VPA');
    _assert(!isRealUpiVpa('@ybl'), 'missing local part');
    _assert(!isRealUpiVpa('ravi@'), 'missing handle');
    _assert(!isRealUpiVpa('ravi kumar@ybl'), 'no whitespace');
    _assert(!isRealUpiVpa('a@b@c'), 'single @ only');
  }
  stdout.writeln('  real VPA guard OK');

  stdout.writeln('All friend-open-claims tests passed.');
}
