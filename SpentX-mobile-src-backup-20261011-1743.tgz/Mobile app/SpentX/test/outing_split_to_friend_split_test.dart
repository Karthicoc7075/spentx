// Run: flutter test test/outing_split_to_friend_split_test.dart
//
// A trip expense shared between members is split BY THE TRIP — the per-member
// shares live on the `OutingExpense`, not on the transaction. Unlinking used to
// discard all of it, so a ₹1,200 bill split three ways came back as a plain
// ₹1,200 expense and the two friends silently stopped owing anything.
//
// `FriendSplit.fromOutingExpense` re-homes it. The two structures already speak
// the same language — both use `OutingMember` for the roster and `SplitType`
// for the mode — so this is a re-homing, not a third split type.
import 'package:flutter_test/flutter_test.dart';
import 'package:spentx/core/providers/outing_provider.dart';
import 'package:spentx/models/friend_split.dart';

final _me = OutingMember(id: 'm-you', name: 'You');
final _brother = OutingMember(id: 'm-bro', name: 'Brother');
final _friend = OutingMember(id: 'm-fri', name: 'Friend');

Outing _trip({List<OutingExpense> expenses = const []}) => Outing(
      id: 'trip-1',
      title: 'Bangalore Trip',
      category: 'Trip',
      startDate: DateTime(2026, 8, 1),
      endDate: DateTime(2026, 8, 10),
      members: [_me, _brother, _friend],
      expenses: expenses,
      purpose: 'Personal',
    );

OutingExpense _expense({
  SplitType splitType = SplitType.equally,
  Map<String, double>? custom,
  Map<String, List<SettlementPayment>> settlements = const {},
  List<String>? memberIds,
  String? paidBy,
}) =>
    OutingExpense(
      id: 'exp-1',
      title: 'Dinner',
      amount: 1200,
      category: 'Food',
      date: DateTime(2026, 8, 5),
      paymentMode: 'Cash',
      accountId: 'HDFC',
      purpose: 'Personal',
      memberIds: memberIds ?? const ['m-you', 'm-bro', 'm-fri'],
      splitType: splitType,
      customSplitAmounts: custom,
      settlementPayments: settlements,
      paidByMemberId: paidBy ?? 'm-you',
      transactionId: 'tx-1',
    );

void main() {
  test('the worked example: 1200 three ways survives the unlink', () {
    final split = FriendSplit.fromOutingExpense(
      outing: _trip(),
      expense: _expense(),
      transactionId: 'tx-1',
    )!;

    expect(split.transactionId, 'tx-1');
    expect(split.amount, 1200, reason: 'the bill total is unchanged');
    expect(split.members.map((m) => m.name), ['You', 'Brother', 'Friend'],
        reason: 'nobody is dropped from the split');

    for (final id in ['m-you', 'm-bro', 'm-fri']) {
      expect(split.shareForMember(id), 400, reason: '$id keeps their share');
    }
    expect(
      split.splits.fold<double>(0, (s, e) => s + e.amount),
      1200,
      reason: 'the shares still add up to the bill',
    );
  });

  test('descriptive fields come across unchanged', () {
    final split = FriendSplit.fromOutingExpense(
      outing: _trip(),
      expense: _expense(),
      transactionId: 'tx-1',
    )!;

    expect(split.description, 'Dinner');
    expect(split.category, 'Food');
    expect(split.date, DateTime(2026, 8, 5));
    expect(split.accountName, 'HDFC');
    expect(split.paymentMode, 'Cash');
    expect(split.paidByMemberId, 'm-you');
    expect(split.splitType, SplitType.equally,
        reason: 'never rewritten into a Purpose or Category split');
    expect(split.isActive, isTrue);
  });

  test('a custom split keeps its exact per-member amounts', () {
    final split = FriendSplit.fromOutingExpense(
      outing: _trip(),
      expense: _expense(
        splitType: SplitType.custom,
        custom: const {'m-you': 600, 'm-bro': 400, 'm-fri': 200},
      ),
      transactionId: 'tx-1',
    )!;

    expect(split.splitType, SplitType.custom);
    expect(split.shareForMember('m-you'), 600);
    expect(split.shareForMember('m-bro'), 400);
    expect(split.shareForMember('m-fri'), 200);
    expect(split.splits.fold<double>(0, (s, e) => s + e.amount), 1200);
  });

  test('repayments already made carry over, so nothing resets to pending', () {
    final split = FriendSplit.fromOutingExpense(
      outing: _trip(),
      expense: _expense(settlements: {
        'm-bro': [
          SettlementPayment(amount: 250, mode: 'Cash', date: DateTime(2026, 8, 6)),
          SettlementPayment(amount: 150, mode: 'UPI', date: DateTime(2026, 8, 7)),
        ],
      }),
      transactionId: 'tx-1',
    )!;

    expect(split.settledAmountForMember('m-bro'), 400);
    expect(split.pendingAmountForMember('m-bro'), 0,
        reason: 'Brother had already settled in full on the trip');
    expect(split.pendingAmountForMember('m-fri'), 400,
        reason: 'Friend still owes their share');
    // Repayments are owed to whoever fronted the bill.
    expect(split.settlements.every((s) => s.toMemberId == 'm-you'), isTrue);
  });

  test('a friend who paid is recorded as the payer', () {
    final split = FriendSplit.fromOutingExpense(
      outing: _trip(),
      expense: _expense(paidBy: 'm-bro'),
      transactionId: 'tx-1',
    )!;
    expect(split.paidByMemberId, 'm-bro');
    expect(split.youMemberId, 'm-you');
  });

  group('nothing to convert', () {
    test('a solo expense produces no split', () {
      expect(
        FriendSplit.fromOutingExpense(
          outing: _trip(),
          expense: _expense(splitType: SplitType.solo),
          transactionId: 'tx-1',
        ),
        isNull,
      );
    });

    test('a single-member expense produces no split', () {
      expect(
        FriendSplit.fromOutingExpense(
          outing: _trip(),
          expense: _expense(memberIds: const ['m-you']),
          transactionId: 'tx-1',
        ),
        isNull,
      );
    });

    test('an unresolvable member aborts rather than inventing one', () {
      // Better to leave the transaction unsplit than to name someone we
      // cannot identify; the transaction itself is kept either way.
      expect(
        FriendSplit.fromOutingExpense(
          outing: _trip(),
          expense: _expense(memberIds: const ['m-you', 'm-ghost']),
          transactionId: 'tx-1',
        ),
        isNull,
      );
    });
  });

  test('the result does not reference the outing at all', () {
    final split = FriendSplit.fromOutingExpense(
      outing: _trip(),
      expense: _expense(),
      transactionId: 'tx-1',
    )!;

    // Round-trips through its own JSON with no trip involved — proof it can
    // survive the outing being deleted.
    final revived = FriendSplit.fromJson(split.toJson());
    expect(revived.amount, 1200);
    expect(revived.members.length, 3);
    expect(revived.shareForMember('m-bro'), 400);
    expect(revived.splitType, SplitType.equally);
    expect(
      split.toJson().toString().contains('trip-1'),
      isFalse,
      reason: 'no outing id is carried into the friend split',
    );
  });
}
