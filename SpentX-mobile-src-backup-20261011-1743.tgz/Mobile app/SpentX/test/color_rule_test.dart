import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:spentx/core/theme/soft_palette.dart';

double _lum(Color c) {
  double ch(double v) =>
      v <= 0.03928 ? v / 12.92 : math.pow((v + 0.055) / 1.055, 2.4).toDouble();
  return 0.2126 * ch(c.r) + 0.7152 * ch(c.g) + 0.0722 * ch(c.b);
}

double _contrast(Color a, Color b) {
  final x = _lum(a), y = _lum(b);
  return (math.max(x, y) + 0.05) / (math.min(x, y) + 0.05);
}

void main() {
  test('primary gradient is the Add-transaction Save gradient', () {
    expect(SoftColors.primaryGradientColors, const [
      Color(0xFF006C49),
      Color(0xFF059669),
      Color(0xFF005236),
    ]);
  });

  test('white on control green passes WCAG AA (~5.5:1)', () {
    expect(_contrast(Colors.white, SoftColors.control), greaterThan(5.0));
  });

  test('secondary outline / danger / text tokens', () {
    expect(SoftColors.outline, const Color(0xFFE2E8F0));
    expect(SoftColors.ink, const Color(0xFF0F172A));
    expect(SoftColors.slate, const Color(0xFF64748B));
    expect(SoftColors.control, const Color(0xFF047857));
  });
}
