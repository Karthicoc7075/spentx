import 'package:flutter_test/flutter_test.dart';
import 'package:spentx/core/sync/local_sync_engine.dart';
import 'package:spentx/core/sync/sync_conflict.dart';
import 'package:spentx/core/sync/sync_queue.dart';
import 'package:spentx/core/sync/sync_tables.dart';

void main() {
  test('newer updated_at wins, equal timestamps keep local', () {
    expect(
      SyncConflict.remoteIsNewer(null, '2026-10-03T12:00:00Z'),
      isTrue,
    );
    expect(SyncConflict.remoteIsNewer('2026-10-03T12:00:00Z', null), isFalse);
    expect(SyncConflict.remoteIsNewer(null, null), isFalse);
    expect(
      SyncConflict.remoteIsNewer(
        '2026-10-03T12:00:00Z',
        '2026-10-03T12:00:01Z',
      ),
      isTrue,
    );
    expect(
      SyncConflict.remoteIsNewer(
        '2026-10-03T12:00:02Z',
        '2026-10-03T12:00:01Z',
      ),
      isFalse,
    );
    expect(
      SyncConflict.remoteIsNewer(
        '2026-10-03T17:30:00+05:30',
        '2026-10-03T12:00:00Z',
      ),
      isFalse,
    );
  });

  test('outbox entry stores id, table, action, payload, updated_at', () {
    final entry = SyncQueue.buildEntry(
      entity: SyncEntity.transaction,
      op: SyncOp.upsert,
      localId: 'local-1',
      payload: {'amount': 10},
      updatedAt: '2026-10-03T12:00:00Z',
    );
    expect(entry['id'], isNotEmpty);
    expect(entry['table'], 'transactions');
    expect(entry['action'], SyncOp.upsert);
    expect(entry['op'], SyncOp.upsert);
    expect(entry['updated_at'], '2026-10-03T12:00:00Z');
    expect(entry['payload'], {'amount': 10, 'updatedAt': '2026-10-03T12:00:00Z'});

    final account = SyncQueue.buildEntry(
      entity: SyncEntity.account,
      op: SyncOp.delete,
      localId: 'Cash',
    );
    expect(account['table'], 'accounts');
    expect(account['action'], 'delete');
    expect(account['updated_at'], isNotEmpty);
  });

  test('delta-wired tables match the shared cursor hook', () {
    expect(
      LocalSyncEngine.wired.map((t) => t.table).toSet(),
      {
        'accounts',
        'transactions',
        'purposes',
        'categories',
        'contributors',
        'friends',
        'outings',
        'friend_splits',
        'user_merchants',
        'users',
        'monthly_plans',
        'outing_categories',
      },
    );
    expect(SyncTables.purposes.hasUpdatedAt, isTrue);
    expect(SyncTables.purposes.hasDeletedAt, isTrue);
    expect(SyncTables.categories.hasDeletedAt, isTrue);
    expect(SyncTables.contributors.hasDeletedAt, isTrue);
    expect(SyncTables.userMerchants.hasDeletedAt, isFalse);
    expect(SyncTables.monthlyPlans.hasDeletedAt, isFalse);
    expect(SyncTables.transactions.hasDeletedAt, isTrue);
  });

  test('purpose outbox row uses the purposes table', () {
    final entry = SyncQueue.buildEntry(
      entity: SyncEntity.purpose,
      op: SyncOp.delete,
      localId: 'Family',
      updatedAt: '2026-10-03T12:00:00Z',
    );
    expect(entry['table'], 'purposes');
    expect(entry['action'], 'delete');
    expect(entry['updated_at'], '2026-10-03T12:00:00Z');
  });
}
