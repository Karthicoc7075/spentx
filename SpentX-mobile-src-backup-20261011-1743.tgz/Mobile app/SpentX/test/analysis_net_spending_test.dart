// Run: flutter test test/analysis_net_spending_test.dart
//
// The Analysis headline (Income / Spent) already netted friend returns, but
// the breakdowns underneath did not — each chart re-decided the rule for
// itself, so they disagreed with the totals printed above them:
//
//   * "Income Sources" listed Friend Returns as a source and added it to the
//     income total — the one thing that must never happen.
//   * "Top Categories" charted gross outing spend.
//   * "Cash Flow" counted returns as inflow and charted gross outflow.
//
// The rule is stated once now (_incomeRows / _expenseRows / _netSpend) and
// every chart applies it. These tests pin the rule and the worked examples.
import 'package:flutter_test/flutter_test.dart';
import 'package:spentx/core/providers/transaction_provider.dart' as model;

model.Transaction _tx({
  required String id,
  required double amount,
  required bool isExpense,
  String category = 'Food',
  String? outingId,
  bool isTransfer = false,
  String merchant = 'X',
  DateTime? date,
}) =>
    model.Transaction(
      id: id,
      merchant: merchant,
      category: category,
      account: 'HDFC',
      paymentType: 'Online',
      time: '',
      amount: amount,
      isExpense: isExpense,
      isTransfer: isTransfer,
      date: date ?? DateTime(2026, 8, 5),
      purpose: 'Personal',
      outingId: outingId,
      note: '',
    );

/// Mirrors the shared rule in analytics_screen.dart.
({double income, double spent}) analysis(List<model.Transaction> txs) {
  // Transfers never reach the charts — filtered at the data source.
  final scoped = txs.where((t) => !t.isTransfer).toList();
  double income = 0, gross = 0, returns = 0;
  for (final t in scoped) {
    if (t.isFriendReturn) {
      returns += t.amount;
    } else if (t.isExpense) {
      gross += t.amount;
    } else {
      income += t.amount;
    }
  }
  return (income: income, spent: (gross - returns).clamp(0.0, double.infinity));
}

void main() {
  final salary =
      _tx(id: 'i1', amount: 10000, isExpense: false, category: 'Salary');
  final outingBill = _tx(id: 'e1', amount: 1200, isExpense: true, outingId: 'trip-1');
  model.Transaction ret(String id, double amt) => _tx(
        id: id,
        amount: amt,
        isExpense: false,
        category: 'Friend Returns',
        outingId: 'trip-1',
      );

  group('the spec worked examples', () {
    test('1200 paid, 800 returned → 400 spent, 10000 income', () {
      final r = analysis([salary, outingBill, ret('r1', 400), ret('r2', 400)]);
      expect(r.income, 10000, reason: 'the 800 never touches income');
      expect(r.spent, 400);
    });

    test('1200 paid, 400 returned → 800 spent', () {
      expect(analysis([salary, outingBill, ret('r1', 400)]).spent, 800);
    });

    test('1200 paid, nothing returned → 1200 spent', () {
      expect(analysis([salary, outingBill]).spent, 1200);
    });
  });

  group('income', () {
    test('normal income is counted in full', () {
      expect(analysis([salary]).income, 10000);
    });

    test('a friend return never increases income', () {
      final withReturn = analysis([salary, outingBill, ret('r1', 800)]);
      final withoutReturn = analysis([salary, outingBill]);
      expect(withReturn.income, withoutReturn.income);
      expect(withReturn.income, 10000);
    });

    test('a DEBIT in the Friend Returns category is your own spending', () {
      // You repaying a friend is money out; it must not reduce your spend.
      final youRepaying =
          _tx(id: 'e2', amount: 400, isExpense: true, category: 'Friend Returns');
      final r = analysis([salary, youRepaying]);
      expect(r.spent, 400);
      expect(r.income, 10000);
    });
  });

  group('spending', () {
    test('a normal expense counts in full', () {
      final r = analysis([salary, _tx(id: 'e9', amount: 250, isExpense: true)]);
      expect(r.spent, 250);
    });

    test('multiple returns accumulate', () {
      final r = analysis([
        outingBill,
        ret('r1', 200),
        ret('r2', 200),
        ret('r3', 100),
      ]);
      expect(r.spent, 700, reason: '1200 − 500');
    });

    test('spending never goes negative', () {
      final r = analysis([_tx(id: 'e3', amount: 100, isExpense: true), ret('r1', 400)]);
      expect(r.spent, 0, reason: 'clamped, not -300');
    });

    test('returns do not touch unrelated normal spending', () {
      final r = analysis([
        salary,
        _tx(id: 'e4', amount: 500, isExpense: true, category: 'Groceries'),
        outingBill,
        ret('r1', 800),
      ]);
      expect(r.spent, 900, reason: '500 groceries + (1200 − 800) trip');
    });
  });

  group('transfers are neither income nor spending', () {
    test('a manual transfer between own accounts is ignored', () {
      final out = _tx(id: 't1', amount: 5000, isExpense: true, isTransfer: true);
      final into = _tx(id: 't2', amount: 5000, isExpense: false, isTransfer: true);
      final r = analysis([salary, out, into]);
      expect(r.spent, 0);
      expect(r.income, 10000);
    });

    test('an ATM withdrawal is a transfer, not spending', () {
      // SmsAtmHelper stamps this merchant and the parser marks it a transfer,
      // which is what isAtmTransfer keys on.
      final atm = _tx(
        id: 't3',
        amount: 2000,
        isExpense: true,
        isTransfer: true,
        merchant: 'ATM Withdrawal',
      );
      expect(atm.isAtmTransfer, isTrue);
      final r = analysis([salary, atm]);
      expect(r.spent, 0, reason: 'bank → cash moved money, it did not spend it');
      expect(r.income, 10000);
    });
  });

  group('the rule holds per bucket, not just in the total', () {
    test('a return reduces the outflow of the day it arrived', () {
      // Cash Flow bars: the return is negative spend on its own day rather
      // than inflow, so bars still sum to the totals above them.
      final day1 = DateTime(2026, 8, 1);
      final day2 = DateTime(2026, 8, 2);
      final txs = [
        _tx(id: 'e5', amount: 1200, isExpense: true, outingId: 'trip-1', date: day1),
        _tx(
          id: 'r9',
          amount: 400,
          isExpense: false,
          category: 'Friend Returns',
          outingId: 'trip-1',
          date: day2,
        ),
      ];

      final byDay = <int, double>{};
      for (final t in txs) {
        final key = t.date.day;
        final current = byDay[key] ?? 0;
        byDay[key] = t.isFriendReturn
            ? (current - t.amount).clamp(0.0, double.infinity)
            : (t.isExpense ? current + t.amount : current);
      }

      expect(byDay[1], 1200);
      expect(byDay[2], 0, reason: 'a lone return clamps rather than going negative');
      expect(
        analysis(txs).spent,
        800,
        reason: 'the period total still nets across days',
      );
    });

    test('an outing return is attributed to the Trip category bucket', () {
      // The category chart groups outingId rows under 'Trip'; a return
      // carries the same outingId, so it reduces the same bucket.
      final txs = [outingBill, ret('r1', 400)];
      final data = <String, double>{};
      for (final t in txs.where((t) => t.isExpense)) {
        data[t.outingId != null ? 'Trip' : t.category] =
            (data[t.outingId != null ? 'Trip' : t.category] ?? 0) + t.amount;
      }
      for (final r in txs.where((t) => t.isFriendReturn)) {
        if (r.outingId == null) continue;
        final current = data['Trip'];
        if (current == null) continue;
        data['Trip'] = (current - r.amount).clamp(0.0, double.infinity);
      }
      expect(data['Trip'], 800);
    });
  });
}
