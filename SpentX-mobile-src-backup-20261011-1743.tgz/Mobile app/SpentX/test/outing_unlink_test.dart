// Run: flutter test test/outing_unlink_test.dart
//
// Unlinking must remove the trip association and NOTHING else. Two separate
// paths broke that:
//
//  1. A manual trip entry (an OutingExpense with no transactionId) has no
//     ledger row behind it — the expense IS the record of that spend. Both
//     unlink entry points called `deleteExpense()`, destroying it: the money
//     vanished from the app instead of becoming a normal transaction. That is
//     the reported "transaction does not appear in the normal Activity list".
//
//  2. A materialised row re-entering `addTransaction` while its trip is still
//     active would be grabbed straight back by the outing auto-linker, undoing
//     the unlink on the spot.
//
// The Activity list collapses every `outingId != null` expense into one
// "OutingSummary" row, so a row that keeps its outingId is invisible as an
// individual transaction — which is why clearing it is what makes the row
// reappear.
import 'package:flutter_test/flutter_test.dart';
import 'package:spentx/core/providers/transaction_provider.dart' as model;
import 'package:spentx/core/providers/outing_provider.dart';

/// The Activity screen's grouping rule, mirrored from
/// `transactions_screen.dart`: outing-tagged expenses collapse into one
/// synthetic summary row; everything else lists individually.
({List<model.Transaction> rows, int summaries}) activityRows(
  List<model.Transaction> txs,
) {
  final grouped = <String, model.Transaction>{};
  final finalized = <model.Transaction>[];
  for (final tx in txs) {
    if (tx.outingId != null && tx.isExpense) {
      grouped.putIfAbsent(tx.outingId!, () => tx);
    } else {
      finalized.add(tx);
    }
  }
  return (rows: finalized, summaries: grouped.length);
}

model.Transaction _linkedTx({String outingId = 'trip-1'}) => model.Transaction(
      id: 'tx-1',
      merchant: 'Bangalore Trip Dinner',
      category: 'Food',
      account: 'HDFC',
      paymentType: 'Online',
      time: '',
      amount: 1200,
      isExpense: true,
      date: DateTime(2026, 8, 10),
      purpose: 'Personal',
      outingId: outingId,
      note: '',
    );

OutingExpense _manualExpense() => OutingExpense(
      id: 'exp-1',
      title: 'Bangalore Trip Dinner',
      amount: 1200,
      category: 'Food',
      date: DateTime(2026, 8, 10),
      paymentMode: 'Cash',
      purpose: 'Personal',
    );

void main() {
  test('unlinking a linked transaction clears only the trip association', () {
    final before = _linkedTx();
    final after = before.copyWith(clearOutingId: true);

    expect(after.outingId, isNull, reason: 'the trip link is removed');
    expect(after.isAutoLinked, isFalse,
        reason: 'an auto-linked row must not stay flagged as auto-linked');

    // Everything else is byte-identical.
    expect(after.id, before.id);
    expect(after.amount, 1200);
    expect(after.isExpense, isTrue);
    expect(after.account, before.account);
    expect(after.category, before.category);
    expect(after.purpose, before.purpose);
    expect(after.date, before.date);
    expect(after.merchant, before.merchant);
    expect(after.paymentType, before.paymentType);
  });

  test('a linked expense is hidden behind the trip summary; unlinked it lists',
      () {
    final linked = _linkedTx();
    final before = activityRows([linked]);
    expect(before.rows, isEmpty,
        reason: 'while linked it is collapsed into the trip summary row');
    expect(before.summaries, 1);

    final after = activityRows([linked.copyWith(clearOutingId: true)]);
    expect(after.summaries, 0);
    expect(after.rows.length, 1,
        reason: 'requirement 6 — it must appear in the normal list at once');
    expect(after.rows.single.amount, 1200);
  });

  test('outing filters only match rows still linked to that trip', () {
    final linked = _linkedTx();
    final unlinked = linked.copyWith(clearOutingId: true);

    // `_getAutoTaggedTransactions` in the trip screen.
    List<model.Transaction> forTrip(List<model.Transaction> txs, String id) =>
        txs.where((t) => t.outingId == id).toList();

    expect(forTrip([linked], 'trip-1').length, 1);
    expect(forTrip([unlinked], 'trip-1'), isEmpty,
        reason: 'requirement 8 — an unlinked row leaves the trip view');
  });

  test('normal filters keep rows whose outingId is null', () {
    final unlinked = _linkedTx().copyWith(clearOutingId: true);

    // Requirement 7 + 10: nothing in the ordinary filter chain may drop a row
    // for having no trip. Each predicate below mirrors a real filter.
    expect(unlinked.outingId, isNull);
    expect(
      [unlinked].where((t) => t.purpose == 'Personal').length,
      1,
      reason: 'purpose filter',
    );
    expect(
      [unlinked].where((t) => t.category == 'Food').length,
      1,
      reason: 'category filter',
    );
    expect(
      [unlinked]
          .where((t) =>
              !t.date.isBefore(DateTime(2026, 8, 1)) &&
              t.date.isBefore(DateTime(2026, 9, 1)))
          .length,
      1,
      reason: 'date-range filter',
    );
    expect(
      [unlinked]
          .where((t) => t.merchant.toLowerCase().contains('bangalore'))
          .length,
      1,
      reason: 'search',
    );
  });

  test('a manual trip entry carries every field into its ledger row', () {
    // Mirrors TransactionNotifier.materialiseOutingExpense. Before the fix
    // this data was simply deleted, so there was nothing to assert against.
    final e = _manualExpense();
    final materialised = model.Transaction(
      id: e.id,
      merchant: e.title,
      category: e.category,
      account: (e.accountId ?? '').trim().isNotEmpty
          ? e.accountId!.trim()
          : (e.paymentMode.trim().isNotEmpty ? e.paymentMode.trim() : 'Cash'),
      paymentType: 'Cash',
      time: '',
      amount: e.amount,
      isExpense: true,
      date: e.date,
      purpose: e.purpose,
      note: '',
    );

    expect(materialised.amount, 1200, reason: 'amount unchanged');
    expect(materialised.isExpense, isTrue, reason: 'still an expense');
    expect(materialised.category, 'Food');
    expect(materialised.purpose, 'Personal');
    expect(materialised.date, DateTime(2026, 8, 10));
    expect(materialised.merchant, 'Bangalore Trip Dinner');
    expect(materialised.account, 'Cash');
    expect(materialised.outingId, isNull, reason: 'no longer on the trip');

    // And it now shows up as an ordinary row.
    final rows = activityRows([materialised]);
    expect(rows.rows.length, 1);
    expect(rows.summaries, 0);
  });

  test('reusing the expense id makes a double unlink idempotent', () {
    // addTransaction replaces a same-id row, so unlinking twice cannot leave
    // two ledger rows for one real spend.
    final e = _manualExpense();
    final first = model.Transaction(
      id: e.id,
      merchant: e.title,
      category: e.category,
      account: 'Cash',
      paymentType: 'Cash',
      time: '',
      amount: e.amount,
      isExpense: true,
      date: e.date,
      purpose: e.purpose,
      note: '',
    );
    final second = first.copyWith();
    final state = <model.Transaction>[second, ...[first].where((t) => t.id != second.id)];
    expect(state.length, 1, reason: 'same id replaces, never duplicates');
    expect(state.single.amount, 1200);
  });
}
