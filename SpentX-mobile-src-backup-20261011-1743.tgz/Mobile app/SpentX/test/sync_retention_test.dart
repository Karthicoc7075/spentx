import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:hive/hive.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:spentx/core/services/auth_service.dart';
import 'package:spentx/core/services/sign_out_guard.dart';
import 'package:spentx/core/sync/sync_queue.dart';
import 'package:spentx/core/sync/sync_service.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:spentx/features/wealth/data/projector_service.dart';
import 'package:spentx/models/projector_settings_model.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test(
    'six failed pushes and logout retain data, successful retry acknowledges it',
    () async {
      SharedPreferences.setMockInitialValues({});
      final dir = await Directory.systemTemp.createTemp('spentx_retry_');
      Hive.init(dir.path);
      await Hive.openBox('settings');
      await Hive.openBox('sync_queue');
      await Hive.openBox('investments');
      var online = false;
      var writes = 0;
      var conflict = false;
      var serverProjector = <String, dynamic>{
        'holdings': [
          {'id': 'cloud'},
        ],
        'webOnly': 'preserve',
      };
      final client = MockClient((request) async {
        expect(request.url.host, 'sync-test.invalid');
        if (request.url.path == '/rest/v1/projector_settings') {
          if (!online)
            return http.Response(
              '{"message":"offline fixture","code":"400"}',
              400,
              request: request,
            );
          if (request.method == 'GET')
            return http.Response(
              jsonEncode({'settings': serverProjector}),
              200,
              request: request,
            );
          if (request.method == 'PATCH') {
            if (conflict) {
              conflict = false;
              serverProjector['webOnly'] = 'concurrent web change';
            }
            final filter = request.url.queryParameters['settings']!;
            final expected = jsonDecode(filter.substring(3));
            if (jsonEncode(expected) != jsonEncode(serverProjector)) {
              return http.Response('[]', 200, request: request);
            }
            serverProjector = Map<String, dynamic>.from(
              jsonDecode(request.body)['settings'] as Map,
            );
            return http.Response(
              '[{"user_id":"test-user"}]',
              200,
              request: request,
            );
          }
        }
        if (request.method == 'PATCH' && request.url.path == '/rest/v1/users') {
          writes++;
          return online
              ? http.Response('', 204, request: request)
              : http.Response(
                '{"message":"temporarily unavailable","code":"503"}',
                503,
                request: request,
              );
        }
        return http.Response('{}', 200, request: request);
      });
      await Supabase.initialize(
        url: 'https://sync-test.invalid',
        publishableKey: 'test-key',
        httpClient: client,
        debug: false,
        authOptions: const FlutterAuthClientOptions(
          autoRefreshToken: false,
          detectSessionInUri: false,
          localStorage: EmptyLocalStorage(),
        ),
      );
      addTearDown(() async {
        await Supabase.instance.dispose();
        await Hive.close();
        await dir.delete(recursive: true);
      });
      String part(Object value) =>
          base64Url.encode(utf8.encode(jsonEncode(value))).replaceAll('=', '');
      final jwt =
          '${part({'alg': 'HS256'})}.${part({'sub': 'test-user', 'exp': DateTime.now().millisecondsSinceEpoch ~/ 1000 + 3600})}.test';
      await Supabase.instance.client.auth.setInitialSession(
        jsonEncode({
          'access_token': jwt,
          'refresh_token': 'test-refresh',
          'token_type': 'bearer',
          'user': {
            'id': 'test-user',
            'aud': 'authenticated',
            'app_metadata': {},
            'user_metadata': {},
            'created_at': '2026-10-04T00:00:00Z',
          },
        }),
      );
      SyncQueue.enqueue(
        entity: SyncEntity.userSettings,
        op: SyncOp.upsert,
        localId: 'test-user',
        payload: {'private_mode': true},
      );
      for (var i = 0; i < 6; i++) {
        await SyncService.pushPending();
      }
      expect(writes, 6);
      expect(SyncQueue.items().single['attempts'], 6);
      var wiped = false;
      AuthService.clearLocalDataOnSignOut = () async {
        wiped = true;
      };
      addTearDown(() => AuthService.clearLocalDataOnSignOut = null);
      await expectLater(
        AuthService.signOut(),
        throwsA(isA<UnsyncedChangesException>()),
      );
      expect(wiped, false);
      expect(AuthService.isSignedIn, true);
      expect(SyncQueue.length, 1);
      online = true;
      await SyncService.pushPending();
      expect(
        SyncQueue.isEmpty,
        true,
        reason:
            Hive.box('settings').get(SyncService.lastPushErrorKey)?.toString(),
      );

      online = false;
      await ProjectorService.saveSettings(
        const ProjectorSettingsModel(monthlySavings: 3000),
      );
      expect(ProjectorService.hasPendingChanges, true);
      online = true;
      await ProjectorService.flushPending();
      expect(serverProjector['holdings'], [
        {'id': 'cloud'},
      ]);
      expect(serverProjector['monthlySavings'], 3000);
      expect(ProjectorService.hasPendingChanges, false);

      // A web edit between read and write must not be lost or acknowledged.
      conflict = true;
      await ProjectorService.saveSettings(
        const ProjectorSettingsModel(monthlySavings: 4000),
      );
      expect(ProjectorService.hasPendingChanges, true);
      expect(serverProjector['webOnly'], 'concurrent web change');
      await ProjectorService.flushPending();
      expect(ProjectorService.hasPendingChanges, false);
      expect(serverProjector['webOnly'], 'concurrent web change');
      expect(serverProjector['monthlySavings'], 4000);
      // Legacy server holdings are preserved, never rewritten by the app.
      expect(serverProjector['holdings'], [
        {'id': 'cloud'},
      ]);
    },
  );
}
