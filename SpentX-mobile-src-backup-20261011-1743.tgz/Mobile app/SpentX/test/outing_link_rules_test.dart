// Run: flutter test test/outing_link_rules_test.dart
//
// "Add to outing" used to list EVERY outing for EVERY transaction, with no
// eligibility check at all. Two things were wrong with that:
//
//  * A divided transaction (Friend Split, Purpose Split, Category Split,
//    Purpose + Category Split, or per-item allocation) has no single
//    amount + category + purpose to carry into a trip. Linking one would have
//    meant picking a slice and silently dropping the rest.
//  * A trip configures a purpose, and a transaction belonging to a different
//    purpose was still offered — the mismatch only surfaced afterwards.
//
// Covers the nine cases in the spec.
import 'package:flutter_test/flutter_test.dart';
import 'package:spentx/core/providers/outing_provider.dart';
import 'package:spentx/core/providers/transaction_provider.dart';
import 'package:spentx/core/utils/outing_link_rules.dart';

Outing _outing({
  String title = 'Bangalore Trip',
  String purpose = 'Personal',
}) =>
    Outing(
      id: 'trip-${title.hashCode}',
      title: title,
      category: 'Trip',
      startDate: DateTime(2026, 8, 1),
      endDate: DateTime(2026, 8, 10),
      purpose: purpose,
    );

Transaction _tx({
  String purpose = 'Personal',
  List<TransactionSplitRow> splits = const [],
  List<TransactionItemRow> items = const [],
  bool isGroup = false,
  int groupCount = 0,
  bool isTransfer = false,
}) =>
    Transaction(
      id: 'tx-1',
      merchant: 'Cafe',
      category: 'Food',
      account: 'HDFC',
      paymentType: 'Online',
      time: '',
      amount: 500,
      isExpense: true,
      date: DateTime(2026, 8, 5),
      purpose: purpose,
      splits: splits,
      items: items,
      isGroup: isGroup,
      groupCount: groupCount,
      isTransfer: isTransfer,
      note: '',
    );

TransactionSplitRow _split(String category, String purpose, double amount) =>
    TransactionSplitRow(categoryId: category, purposeId: purpose, amount: amount);

void main() {
  final personalTrip = _outing(purpose: 'Personal');

  group('rule 1 — only undivided transactions are eligible', () {
    test('case 3: a plain expense with no split is eligible', () {
      final tx = _tx();
      expect(tx.isSimpleTransaction, isTrue);
      expect(outingAcceptsTransaction(personalTrip, tx), isTrue);
    });

    test('case 4: a Friend Split is not eligible', () {
      // Recorded on the row itself…
      expect(_tx(isGroup: true).isSimpleTransaction, isFalse);
      // …or as a member count.
      expect(_tx(groupCount: 3).isSimpleTransaction, isFalse);
      expect(
        outingAcceptsTransaction(personalTrip, _tx(isGroup: true)),
        isFalse,
      );
    });

    test('case 5: a Purpose Split is not eligible', () {
      final tx = _tx(splits: [
        _split('Food', 'Personal', 300),
        _split('Food', 'Family', 200),
      ]);
      expect(tx.isSplitExpense, isTrue);
      expect(tx.isSimpleTransaction, isFalse);
      expect(outingAcceptsTransaction(personalTrip, tx), isFalse);
    });

    test('case 6: a Category Split is not eligible', () {
      final tx = _tx(splits: [
        _split('Food', 'Personal', 300),
        _split('Travel', 'Personal', 200),
      ]);
      expect(tx.isSimpleTransaction, isFalse);
      expect(
        outingAcceptsTransaction(personalTrip, tx),
        isFalse,
        reason: 'every slice is Personal, so the purpose matches — it is the '
            'division itself that disqualifies the row',
      );
    });

    test('case 7: a Purpose + Category Split is not eligible', () {
      final tx = _tx(splits: [
        _split('Food', 'Personal', 300),
        _split('Travel', 'Family', 200),
      ]);
      expect(tx.isSimpleTransaction, isFalse);
      expect(outingAcceptsTransaction(personalTrip, tx), isFalse);
    });

    test('per-item allocation is not eligible', () {
      final tx = _tx(items: const [
        TransactionItemRow(name: 'Coffee', categoryId: 'Food', amount: 200),
        TransactionItemRow(name: 'Book', categoryId: 'Shopping', amount: 300),
      ]);
      expect(tx.isItemized, isTrue);
      expect(tx.isSimpleTransaction, isFalse);
    });

    test('a single split row is still a plain transaction', () {
      // isSplitExpense is `splits.length > 1` — one row is the normal shape,
      // not a division, and must stay linkable.
      final tx = _tx(splits: [_split('Food', 'Personal', 500)]);
      expect(tx.isSplitExpense, isFalse);
      expect(tx.isSimpleTransaction, isTrue);
    });

    test('a transfer is not spending, so no trip can contain it', () {
      expect(_tx(isTransfer: true).isSimpleTransaction, isFalse);
    });
  });

  group('rule 2 — purpose must match the trip', () {
    test('case 1: Personal transaction + Personal trip is allowed', () {
      expect(
        outingAcceptsTransaction(personalTrip, _tx(purpose: 'Personal')),
        isTrue,
      );
    });

    test('case 2: Family transaction + Personal trip is not allowed', () {
      expect(
        outingAcceptsTransaction(personalTrip, _tx(purpose: 'Family')),
        isFalse,
      );
    });

    test('any other purpose is rejected too', () {
      expect(
        outingAcceptsTransaction(personalTrip, _tx(purpose: 'Business')),
        isFalse,
      );
    });

    test('matching ignores case and surrounding space', () {
      expect(
        outingAcceptsTransaction(_outing(purpose: 'personal'),
            _tx(purpose: '  Personal ')),
        isTrue,
      );
    });

    test('a blank transaction purpose is treated as Personal', () {
      // Matches the Activity screen's _purposeOf, so a row with no purpose
      // behaves the same way everywhere instead of matching nothing.
      expect(
        outingAcceptsTransaction(personalTrip, _tx(purpose: '')),
        isTrue,
      );
      expect(
        outingAcceptsTransaction(_outing(purpose: 'Family'), _tx(purpose: '')),
        isFalse,
      );
    });

    test('a trip with no configured purpose accepts any eligible row', () {
      final unscoped = _outing(purpose: '');
      expect(outingAcceptsTransaction(unscoped, _tx(purpose: 'Family')), isTrue);
      expect(outingAcceptsTransaction(unscoped, _tx(purpose: 'Business')), isTrue);
      // Eligibility still applies — an unscoped trip does not accept a split.
      expect(
        outingAcceptsTransaction(
          unscoped,
          _tx(splits: [
            _split('Food', 'Personal', 300),
            _split('Travel', 'Family', 200),
          ]),
        ),
        isFalse,
      );
    });
  });

  group('multiple outings are judged independently', () {
    final trips = [
      _outing(title: 'Bangalore Trip', purpose: 'Personal'),
      _outing(title: 'Family Goa', purpose: 'Family'),
      _outing(title: 'Client Offsite', purpose: 'Business'),
    ];

    test('only the matching trip is offered', () {
      final offered = outingsAcceptingTransaction(trips, _tx(purpose: 'Family'));
      expect(offered.map((o) => o.title), ['Family Goa']);
    });

    test('a divided transaction is offered nothing at all', () {
      final offered = outingsAcceptingTransaction(
        trips,
        _tx(isGroup: true),
      );
      expect(
        offered,
        isEmpty,
        reason: 'requirement: hide the option entirely rather than failing '
            'after the user picks',
      );
    });

    test('ordering is preserved for the trips that qualify', () {
      final many = [
        _outing(title: 'A', purpose: 'Personal'),
        _outing(title: 'B', purpose: 'Family'),
        _outing(title: 'C', purpose: 'Personal'),
      ];
      expect(
        outingsAcceptingTransaction(many, _tx(purpose: 'Personal'))
            .map((o) => o.title),
        ['A', 'C'],
      );
    });
  });

  group('linking changes only the association', () {
    test('case 9: every other field survives linking', () {
      final before = _tx(purpose: 'Personal');
      // updateTransactionOuting applies exactly this change.
      final after = before.copyWith(outingId: personalTrip.id);

      expect(after.outingId, personalTrip.id);
      expect(after.amount, before.amount);
      expect(after.category, before.category);
      expect(after.merchant, before.merchant);
      expect(after.account, before.account);
      expect(after.date, before.date);
      expect(after.isExpense, before.isExpense);
      expect(after.isGroup, before.isGroup);
      expect(after.groupCount, before.groupCount);
      expect(after.splits, before.splits);
      expect(
        after.purpose,
        'Personal',
        reason: 'the trip must never rewrite the transaction purpose',
      );
    });

    test('case 8: an unlinked row is re-judged by the same rules', () {
      final linked = _tx(purpose: 'Family').copyWith(outingId: 'trip-old');
      final unlinked = linked.copyWith(clearOutingId: true);

      expect(unlinked.outingId, isNull);
      expect(unlinked.isSimpleTransaction, isTrue);
      // Still Family, so a Personal trip stays unavailable.
      expect(outingAcceptsTransaction(personalTrip, unlinked), isFalse);
      expect(
        outingAcceptsTransaction(_outing(purpose: 'Family'), unlinked),
        isTrue,
      );
    });
  });
}
