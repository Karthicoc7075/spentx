// Run: flutter test test/outing_auto_add_rules_test.dart
//
// What an ACTIVE outing may adopt by itself, from a bank SMS.
//
// The detection popup used to link the running trip to whatever it was handed:
// its fallback ran before anything had checked what kind of money movement the
// row was. A salary credit or an ATM withdrawal that happened to arrive during
// a trip therefore came up under "ADDED TO ACTIVE TRIP" and was confirmed onto
// it. Only an expense is trip spending:
//
//  * income is money coming in, not what the trip cost;
//  * a transfer (ATM withdrawal / cash deposit) just moves your own money
//    between your own accounts — the spend you then make with the cash is what
//    belongs to the trip.
//
// The one credit a trip may carry is a friend paying you back for it, which
// nets against what the trip cost you (see outing_return_netting_test.dart).
//
// The divided-amount half of the rules (Friend Split / Purpose Split /
// Category Split / per-item) is covered by outing_link_rules_test.dart; the
// cases here re-assert it for the auto-add caller, since a row that is not
// eligible for the picker must not arrive on a trip automatically either.
import 'package:flutter_test/flutter_test.dart';
import 'package:spentx/core/providers/outing_provider.dart';
import 'package:spentx/core/providers/transaction_provider.dart';
import 'package:spentx/core/utils/outing_link_rules.dart';

Outing _outing({String purpose = 'Personal'}) => Outing(
      id: 'trip-1',
      title: 'Bangalore Trip',
      category: 'Trip',
      startDate: DateTime(2026, 8, 1),
      endDate: DateTime(2026, 8, 10),
      purpose: purpose,
    );

Transaction _tx({
  String merchant = 'ABC Store',
  String purpose = 'Personal',
  bool isExpense = true,
  bool isTransfer = false,
  bool isGroup = false,
  List<TransactionSplitRow> splits = const [],
}) =>
    Transaction(
      id: 'tx-1',
      merchant: merchant,
      category: 'Food',
      account: 'HDFC',
      paymentType: 'Online',
      time: 'Auto-added',
      amount: 500,
      isExpense: isExpense,
      isTransfer: isTransfer,
      isGroup: isGroup,
      splits: splits,
      date: DateTime(2026, 8, 5),
      purpose: purpose,
      note: '',
    );

void main() {
  group('a detected row is auto-added only when it is an expense', () {
    test('a plain detected expense is auto-added', () {
      expect(
        outingAcceptsDetection(isExpense: true, isTransfer: false),
        isTrue,
      );
    });

    test('income is never auto-added', () {
      expect(
        outingAcceptsDetection(isExpense: false, isTransfer: false),
        isFalse,
      );
    });

    test('a transfer is never auto-added', () {
      expect(
        outingAcceptsDetection(isExpense: false, isTransfer: true),
        isFalse,
      );
    });

    test('an ATM withdrawal is never auto-added, however it is reported', () {
      // A withdrawal reaches the popup as a transfer; some callers describe
      // the same row as a debit. Neither may land on the trip.
      expect(
        outingAcceptsDetection(isExpense: false, isTransfer: true),
        isFalse,
      );
      expect(
        outingAcceptsDetection(isExpense: true, isTransfer: true),
        isFalse,
      );
    });

    test('a friend repayment is the one credit a trip carries', () {
      expect(
        outingAcceptsDetection(
          isExpense: false,
          isTransfer: false,
          isFriendReturn: true,
        ),
        isTrue,
      );
    });

    test('a friend repayment flag never rescues a transfer', () {
      expect(
        outingAcceptsDetection(
          isExpense: false,
          isTransfer: true,
          isFriendReturn: true,
        ),
        isFalse,
      );
    });
  });

  group('an auto-added expense stays eligible after a merchant rename', () {
    final trip = _outing();

    test('the detected merchant is accepted, and so is the corrected one', () {
      // ₹500 — ABC Store lands on the trip…
      expect(outingAcceptsTransaction(trip, _tx(merchant: 'ABC Store')), isTrue);
      // …and correcting it to XYZ Supermarket changes nothing about
      // eligibility, so nothing in the rules drops the link.
      expect(
        outingAcceptsTransaction(trip, _tx(merchant: 'XYZ Supermarket')),
        isTrue,
      );
    });

    test('a rename does not touch amount, category or purpose', () {
      final detected = _tx(merchant: 'ABC Store');
      final renamed = detected.copyWith(merchant: 'XYZ Supermarket');
      expect(renamed.merchant, 'XYZ Supermarket');
      expect(renamed.amount, detected.amount);
      expect(renamed.category, detected.category);
      expect(renamed.purpose, detected.purpose);
      expect(renamed.isExpense, detected.isExpense);
      expect(renamed.isSimpleTransaction, isTrue);
    });
  });

  group('divided amounts are still refused', () {
    final trip = _outing();

    test('a Friend Split is not auto-added', () {
      expect(outingAcceptsTransaction(trip, _tx(isGroup: true)), isFalse);
    });

    test('a Purpose / Category Split is not auto-added', () {
      final split = _tx(splits: [
        TransactionSplitRow(
            categoryId: 'Food', purposeId: 'Personal', amount: 300),
        TransactionSplitRow(
            categoryId: 'Food', purposeId: 'Family', amount: 200),
      ]);
      expect(split.isSimpleTransaction, isFalse);
      expect(outingAcceptsTransaction(trip, split), isFalse);
    });

    test('purpose matching still gates the link', () {
      expect(
        outingAcceptsTransaction(_outing(purpose: 'Personal'),
            _tx(purpose: 'Family')),
        isFalse,
      );
    });
  });
}
