import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:hive/hive.dart';
import 'package:spentx/core/sync/sync_queue.dart';
import 'package:spentx/core/utils/amount_input.dart';
import 'package:spentx/features/export/data/backup_builder.dart';
import 'package:spentx/features/friends/data/friend_edit_plan.dart';
import 'package:spentx/features/friends/data/friend_rename.dart';
import 'package:spentx/features/friends/data/friends_provider.dart';
import 'package:spentx/features/groups/data/outing_provider.dart';
import 'package:spentx/features/recurring/data/recurring_matching.dart';
import 'package:spentx/features/wealth/presentation/wealth_screen.dart';

void main() {
  group('FriendEditPlan', () {
    test('own phone is not a duplicate when renaming', () {
      final p = FriendEditPlan.build(
        original: 'Ravi',
        newName: 'Ravi Kumar',
        phoneOwner: 'Ravi',
        existingNames: const ['Ravi', 'Asha'],
        linkedUpis: const [],
        formUpis: const [],
      );
      expect(p.error, isNull);
      expect(p.renamed, isTrue);
    });

    test('phone of another friend blocks', () {
      final p = FriendEditPlan.build(
        original: 'Ravi',
        newName: 'Ravi',
        phoneOwner: 'Asha',
        existingNames: const ['Ravi', 'Asha'],
        linkedUpis: const [],
        formUpis: const [],
      );
      expect(p.error, isNotNull);
    });

    test('rename onto an existing name blocks; case-only rename ok', () {
      expect(
        FriendEditPlan.build(
          original: 'Ravi',
          newName: 'asha',
          phoneOwner: null,
          existingNames: const ['Ravi', 'Asha'],
          linkedUpis: const [],
          formUpis: const [],
        ).error,
        isNotNull,
      );
      final caseOnly = FriendEditPlan.build(
        original: 'ravi',
        newName: 'Ravi',
        phoneOwner: null,
        existingNames: const ['ravi'],
        linkedUpis: const [],
        formUpis: const [],
      );
      expect(caseOnly.error, isNull);
      expect(caseOnly.renamed, isTrue);
    });

    test('removed UPI ids are listed for removal', () {
      final p = FriendEditPlan.build(
        original: 'Ravi',
        newName: 'Ravi',
        phoneOwner: null,
        existingNames: const ['Ravi'],
        linkedUpis: const ['ravi@okhdfc', 'ravi@ybl'],
        formUpis: const ['RAVI@ybl'],
      );
      expect(p.upisToRemove, ['ravi@okhdfc']);
    });
  });

  test('renameMembers renames matching non-you members only', () {
    final members = [
      OutingMember(id: 'y', name: 'You', isCurrentUser: true),
      OutingMember(id: 'a', name: 'ravi'),
      OutingMember(id: 'b', name: 'Asha'),
    ];
    final out = renameMembers(members, 'Ravi', 'Ravi K')!;
    expect(out.map((m) => m.name), ['You', 'Ravi K', 'Asha']);
    expect(out[1].id, 'a');
    expect(renameMembers(members, 'Nobody', 'X'), isNull);
  });

  group('ManualFriendsNotifier', () {
    late Directory dir;
    setUp(() async {
      dir = await Directory.systemTemp.createTemp('friends_fix');
      Hive.init(dir.path);
      await Hive.openBox('friends');
      await Hive.openBox('sync_queue');
      await Hive.openBox('settings');
    });
    tearDown(() async {
      await Hive.close();
      await dir.delete(recursive: true);
    });

    test('rename in place keeps one friend and fields', () {
      final n = ManualFriendsNotifier();
      n.addFriend('Ravi', phone: '9876543210', upiIds: ['ravi@ybl']);
      expect(n.renameFriend('Ravi', 'Ravi Kumar'), isTrue);
      expect(n.state.length, 1);
      expect(n.state.single.name, 'Ravi Kumar');
      expect(n.state.single.phone, '9876543210');
      expect(n.state.single.upiIds, ['ravi@ybl']);
      // Survives a reload from Hive.
      expect(ManualFriendsNotifier().state.single.name, 'Ravi Kumar');
      // Old name's queued create is gone; new name is queued.
      expect(SyncQueue.hasPending(SyncEntity.friend, 'Ravi'), isFalse);
      expect(SyncQueue.hasPending(SyncEntity.friend, 'Ravi Kumar'), isTrue);
    });

    test('rename onto another friend is refused', () {
      final n = ManualFriendsNotifier();
      n.addFriend('Ravi');
      n.addFriend('Asha');
      expect(n.renameFriend('Ravi', 'asha'), isFalse);
      expect(n.state.map((f) => f.name), ['Ravi', 'Asha']);
    });

    test('updateFriendFields: empty clears, list replaces', () {
      final n = ManualFriendsNotifier();
      n.addFriend(
        'Ravi',
        phone: '9876543210',
        upiIds: ['a@ybl', 'b@ybl'],
        notes: 'gym',
      );
      n.updateFriendFields(
        'Ravi',
        phone: '',
        upiId: '',
        upiIds: const [],
        notes: '',
      );
      final f = n.state.single;
      expect(f.phone, isNull);
      expect(f.notes, isNull);
      expect(f.upiIds, isEmpty);
      expect(f.upiId, isNull);
    });

    test('stored server id survives persist/reload', () async {
      await Hive.box('friends').put('list', [
        {'id': '11111111-1111-4111-8111-111111111111', 'name': 'Web Friend'},
      ]);
      final n = ManualFriendsNotifier();
      expect(n.state.single.id, '11111111-1111-4111-8111-111111111111');
      n.updateFriendFields('Web Friend', notes: 'x');
      final raw = (Hive.box('friends').get('list') as List).single as Map;
      expect(raw['id'], '11111111-1111-4111-8111-111111111111');
    });
  });

  group('amount validation', () {
    test('rejects NaN / Infinity / zero / junk', () {
      expect(parsePositiveAmount('NaN'), isNull);
      expect(parsePositiveAmount('Infinity'), isNull);
      expect(parsePositiveAmount('1e400'), isNull);
      expect(parsePositiveAmount('0'), isNull);
      expect(parsePositiveAmount('-5'), isNull);
      expect(parsePositiveAmount('abc'), isNull);
      expect(parsePositiveAmount(''), isNull);
    });
    test('accepts commas and decimals', () {
      expect(parsePositiveAmount('1,250.50'), 1250.5);
      expect(parsePositiveAmount(' 99 '), 99);
    });
  });

  group('RecurringMatching', () {
    final now = DateTime(2026, 10, 11);
    bool pays({
      double bill = 649,
      double amount = 649,
      String merchant = 'NETFLIX.COM',
      bool pending = false,
      DateTime? date,
    }) => RecurringMatching.paysBill(
      billName: 'Netflix',
      billAmount: bill,
      merchant: merchant,
      amount: amount,
      isExpense: true,
      isTransfer: false,
      isPendingVerification: pending,
      date: date ?? DateTime(2026, 10, 3),
      now: now,
    );

    test('verified, same month, close amount pays', () {
      expect(pays(), isTrue);
      expect(pays(amount: 700), isTrue); // within 10%
    });
    test(
      'unverified tx does not pay',
      () => expect(pays(pending: true), isFalse),
    );
    test('far amount does not pay', () => expect(pays(amount: 99), isFalse));
    test('₹10 floor for small bills', () {
      expect(pays(bill: 50, amount: 59), isTrue);
      expect(pays(bill: 50, amount: 61), isFalse);
    });
    test(
      'bill without amount matches by name',
      () => expect(pays(bill: 0, amount: 1), isTrue),
    );
    test(
      'other month does not pay',
      () => expect(pays(date: DateTime(2026, 9, 30)), isFalse),
    );

    test('dedupe drops detected duplicates of manual bills', () {
      final out = RecurringMatching.dedupeDetected(
        ['NETFLIX', 'Jio Fiber', 'Swiggy'],
        ['Netflix', 'jio-fiber'],
        (s) => s,
      );
      expect(out, ['Swiggy']);
    });
  });

  group('goal deadline picker range', () {
    final now = DateTime(2026, 10, 11, 18, 30);
    test('overdue saved date is selectable', () {
      final r = goalDeadlinePickerRange(DateTime(2026, 3, 1, 9), now: now);
      expect(r.first, DateTime(2026, 3, 1));
      expect(r.initial, DateTime(2026, 3, 1));
      expect(r.initial.isBefore(r.first), isFalse);
    });
    test('future / null dates start today', () {
      final r = goalDeadlinePickerRange(DateTime(2027, 1, 5), now: now);
      expect(r.first, DateTime(2026, 10, 11));
      expect(r.initial, DateTime(2027, 1, 5));
      final n = goalDeadlinePickerRange(null, now: now);
      expect(n.initial, DateTime(2026, 10, 11));
    });
  });

  group('BackupBuilder', () {
    test('secret and internal keys are excluded from preferences', () {
      final prefs = BackupBuilder.preferencesFrom({
        'pin_hash': 'x',
        'has_pin': true,
        'supabase_token': 't',
        'api_key': 'k',
        'recurring_bills_v2:uid': {'a': 1},
        'auto_detection': true,
        'profile_name': 'Karthi',
        'big_blob': {'nested': true},
      });
      expect(prefs, {'auto_detection': true, 'profile_name': 'Karthi'});
    });
    test('jsonSafe converts dates, maps and non-finite numbers', () {
      final out = BackupBuilder.jsonSafe({
        1: DateTime.utc(2026, 1, 2),
        'n': double.nan,
        'l': [
          {'k': 1},
        ],
      });
      expect(out, {
        '1': '2026-01-02T00:00:00.000Z',
        'n': null,
        'l': [
          {'k': 1},
        ],
      });
    });
    test('normalize tolerates v1 (old) backups', () {
      final v1 = BackupBuilder.normalize({
        'transactions': [1],
        'investments': [
          {'name': 'old holding'},
        ],
      });
      expect(v1['version'], 1);
      expect(v1['investments'], isEmpty);
      expect((v1['legacyHoldings'] as List).length, 1);
      expect(v1['savingsGoals'], isEmpty);
      final v2 = BackupBuilder.normalize({
        'version': 2,
        'investments': [
          {'id': 'x'},
        ],
      });
      expect((v2['investments'] as List).length, 1);
    });
  });
}
