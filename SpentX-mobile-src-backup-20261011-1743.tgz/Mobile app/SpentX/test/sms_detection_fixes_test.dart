// Run: flutter test test/sms_detection_fixes_test.dart
//
// Regression tests for the Oct 2026 "UPI / debit card SMS not detected" fix.
// Every sample is made up and masked (fake account numbers, refs, phones).
import 'package:flutter_test/flutter_test.dart';
import 'package:spentx/core/utils/bank_keywords.dart';
import 'package:spentx/features/sms/rules/engine/sms_rule_engine.dart';
import 'package:spentx/features/sms/rules/sms_non_transaction_rules_loader.dart';
import 'package:spentx/features/sms/v4/bank_sms_v4_parser.dart';
import 'package:spentx/features/sms_parser/models/transaction_parsed.dart';
import 'package:spentx/features/sms_parser/sms_direction_helper.dart';
import 'package:spentx/features/sms_parser/sms_transaction_filters.dart';

const sbiUpi =
    'Dear UPI user A/C X1234 debited by 250.0 on date 10Oct26 trf to SWIGGY '
    'Refno 600000000001. If not u? call 1800000000. -SBI';
const sbiUpiCredit =
    'Dear SBI UPI User, ur A/cX1234 credited by Rs500 on 10Oct26 by '
    '(Ref no 600000000002)';
const hdfcUpi = 'Sent Rs.120.00\nFrom HDFC Bank A/C *1234\nTo RAJESH KUMAR\n'
    'On 10/10/26\nRef 600000000003\nNot You?\nCall 18000000000/SMS BLOCK UPI '
    'to 7000000000';
const iciciUpi =
    'ICICI Bank Acct XX234 debited for Rs 450.00 on 10-Oct-26; ZOMATO '
    'credited. UPI:600000000004. Call 18000000 for dispute. SMS BLOCK 234 to '
    '9000000000.';
const axisUpi = 'INR 300.00 debited\nA/c no. XX1234\n10-10-26, 14:22:11\n'
    'UPI/P2M/600000000005/PAYTM\nNot you? SMS BLOCKUPI Cust ID to '
    '910000000000\nAxis Bank';
const kotakUpi =
    'Sent Rs.99.00 from Kotak Bank AC X5678 to paytm-123@ptys on 10-10-26.UPI '
    'Ref 600000000006. Not you, https://kotak.com/KBANKT/Fraud';
const canaraUpi =
    'An amount of INR 250.00 has been DEBITED to your account XXX4321 on '
    '10/10/2026 towards UPI/600000000007/SWIGGY. Total Avail.bal INR '
    '1,234.00. - Canara Bank';
const iobUpi =
    'Your a/c no. XXXXX1234 is debited for Rs.250.00 on 10-10-2026 and '
    'credited to a/c no. XXXXX5678 (UPI Ref no 600000000008) -IOB';
const indianBankUpi =
    'A/c *1234 debited Rs. 250.00 on 10-10-26 to VPA swiggy@icici. UPI Ref: '
    '600000000009. Not you? Call 18000000000 - Indian Bank';
const hdfcCard =
    'Spent Rs.560 From HDFC Bank Card x1234 At RELIANCE RETAIL On '
    '2026-10-10:18:32:11 Bal Rs.12345.67 Not You? Call 18000000000/SMS BLOCK '
    'DC 1234 to 7000000000';
const sbiCard =
    'Dear Customer, your SBI Debit Card ending 1234 has been used for '
    'Rs.560.00 at RELIANCE RETAIL on 10Oct26. If not done by you, call '
    '1800000000 -SBI';
const sbiPos =
    'Your A/C XXXXX1234 has a debit by transfer of Rs 560.00 on 10/10/26 at '
    'POS RELIANCE RETAIL. Avl Bal Rs 1234.56 -SBI';
const iciciCard =
    'INR 560.00 spent using ICICI Bank Card XX1234 on 10-Oct-26 on RELIANCE '
    'RETAIL. Avl Limit: INR 12,345.00. If not you, call 1800 0000/SMS BLOCK '
    '1234 to 9000000000';
const axisCard = 'Spent\nCard no. XX1234\nINR 560.00\n10-10-26 18:32:11\n'
    'RELIANCE RETAIL\nAvl Lmt INR 12345.00\nSMS BLOCK 1234 to 910000000000, '
    'if not you - Axis Bank';
const kotakCard =
    'Rs.560.00 spent via Kotak Debit Card XX1234 at RELIANCE RETAIL on '
    '10/10/2026. Avl bal Rs.1234.00. Not you? Call 18600000000';
const hdfcCredit =
    'Rs.500.00 credited to HDFC Bank A/c XX1234 on 10-10-26 by a/c linked to '
    'VPA rajesh@okaxis (UPI Ref No 600000000010).';

TransactionParsed _parse(String m, {String? sender}) {
  final p = SmsRuleEngine.parse(
    m,
    smsReceivedTime: DateTime(2026, 10, 10, 12),
    sender: sender,
  );
  expect(p, isNotNull, reason: 'should parse: $m');
  return p!;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUpAll(() async {
    await BankSmsV4Parser.ensureLoaded();
    await SmsNonTransactionRulesLoader.ensureLoaded();
  });

  group('UPI debits', () {
    test('SBI "debited by 250.0" (no Rs/INR) parses as a 250 debit', () {
      final p = _parse(sbiUpi);
      expect(p.amount, 250.0);
      expect(p.direction, TransactionDirection.expense);
      expect(p.bank, 'SBI');
      expect(p.accountLast4, '1234');
      expect(SmsTransactionFilters.transactionAmount(sbiUpi), 250.0);
    });

    test('SBI "credited by Rs500" is income', () {
      final p = _parse(sbiUpiCredit);
      expect(p.amount, 500.0);
      expect(p.direction, TransactionDirection.income);
    });

    test('ICICI "debited ...; ZOMATO credited" is a debit, not income', () {
      final p = _parse(iciciUpi);
      expect(p.direction, TransactionDirection.expense);
      expect(p.amount, 450.0);
      expect(p.bank, 'ICICI');
      expect(p.accountLast4, '234');
      expect(SmsDirectionHelper.debitStatedFirst(iciciUpi), isTrue);
    });

    test('IOB "debited ... and credited to a/c" is a debit', () {
      final p = _parse(iobUpi);
      expect(p.direction, TransactionDirection.expense);
      expect(p.bank, 'IOB');
      expect(p.accountLast4, '1234');
    });

    test('HDFC UPI sent', () {
      final p = _parse(hdfcUpi);
      expect(p.direction, TransactionDirection.expense);
      expect(p.bank, 'HDFC');
      expect(p.accountLast4, '1234');
    });

    test('Kotak is Kotak with its own last-4 (not HDFC / template 0034)', () {
      final p = _parse(kotakUpi);
      expect(p.bank, 'Kotak');
      expect(p.accountLast4, '5678');
      expect(p.direction, TransactionDirection.expense);
    });

    test('Canara is Canara (not AU Small Finance)', () {
      final p = _parse(canaraUpi);
      expect(p.bank, 'Canara');
      expect(p.accountLast4, '4321');
      expect(p.direction, TransactionDirection.expense);
    });

    test('Axis UPI is Axis', () {
      final p = _parse(axisUpi);
      expect(p.bank, 'Axis');
      expect(p.direction, TransactionDirection.expense);
    });

    test('Indian Bank is not taken from the payee VPA "@icici"', () {
      final p = _parse(indianBankUpi);
      expect(p.bank, 'IndianBank');
      expect(p.direction, TransactionDirection.expense);
    });
  });

  group('Debit card spends', () {
    test('HDFC card spend', () {
      final p = _parse(hdfcCard);
      expect(p.amount, 560.0);
      expect(p.direction, TransactionDirection.expense);
      expect(p.bank, 'HDFC');
      expect(p.accountLast4, '1234');
    });

    test('SBI debit card "ending 1234" gets a numeric last-4', () {
      final p = _parse(sbiCard);
      expect(p.direction, TransactionDirection.expense);
      expect(p.bank, 'SBI');
      expect(p.accountLast4, '1234');
    });

    test('SBI POS "a debit by transfer of Rs 560" is not a balance snapshot',
        () {
      expect(SmsTransactionFilters.statesMoneyMoved(sbiPos), isTrue);
      expect(SmsTransactionFilters.nonTransactionRuleId(sbiPos), isNull);
      final p = _parse(sbiPos);
      expect(p.amount, 560.0);
      expect(p.direction, TransactionDirection.expense);
      expect(p.bank, 'SBI');
    });

    test('ICICI card spend', () {
      final p = _parse(iciciCard);
      expect(p.direction, TransactionDirection.expense);
      expect(p.bank, 'ICICI');
    });

    test('Axis card spend is Axis (not AU Small Finance)', () {
      final p = _parse(axisCard);
      expect(p.amount, 560.0);
      expect(p.bank, 'Axis');
      expect(p.direction, TransactionDirection.expense);
    });

    test('Kotak card spend', () {
      final p = _parse(kotakCard);
      expect(p.bank, 'Kotak');
      expect(p.direction, TransactionDirection.expense);
    });
  });

  test('HDFC credit is HDFC, not Axis from "@okaxis"', () {
    final p = _parse(hdfcCredit);
    expect(p.bank, 'HDFC');
    expect(p.direction, TransactionDirection.income);
  });

  test('a bank sender header decides the bank', () {
    final p = _parse(sbiUpi, sender: 'VM-SBIUPI-S');
    expect(p.bank, 'SBI');
  });

  group('sender ID -> bank', () {
    test('DLT headers', () {
      expect(bankKeyForSender('XX-HDFCBK'), 'hdfc');
      expect(bankKeyForSender('AX-HDFCBK-S'), 'hdfc');
      expect(bankKeyForSender('AX-ICICIB'), 'icici');
      expect(bankKeyForSender('JD-ICICIT-T'), 'icici');
      expect(bankKeyForSender('JD-SBIUPI'), 'sbi');
      expect(bankKeyForSender('VM-ATMSBI-S'), 'sbi');
      expect(bankKeyForSender('VM-KOTAKB'), 'kotak');
      expect(bankKeyForSender('AD-AXISBK-T'), 'axis');
      expect(bankKeyForSender('BZ-CANBNK'), 'canara');
      expect(bankKeyForSender('VK-IOBSMS'), 'iob');
      expect(bankKeyForSender('AD-PNBSMS'), 'pnb');
      expect(bankKeyForSender('CP-CUBANK'), 'city union bank');
      expect(bankKeyForSender('VM-SIBSMS'), 'south indian bank');
      expect(bankKeyForSender('AX-CENTBK'), 'central bank of india');
      expect(bankKeyForSender('HDFCBK'), 'hdfc');
    });

    test('phone numbers and unknown headers are not banks', () {
      expect(bankKeyForSender('+919000000000'), '');
      expect(bankKeyForSender('AX-JIOINF'), '');
      expect(bankKeyForSender(''), '');
      expect(bankKeyForSender(null), '');
    });

    test('allowlist accepts a body without the bank name via sender', () {
      const body = 'Rs 250.00 debited from A/c XX9999 to VPA shop@ybl';
      expect(
        messageMatchesAllowedBank(body,
            tokens: const ['hdfc'], last4s: const [], sender: 'AX-HDFCBK-S'),
        isTrue,
      );
      expect(
        messageMatchesAllowedBank(body,
            tokens: const ['hdfc'], last4s: const [], sender: 'AX-ICICIB-S'),
        isFalse,
      );
    });
  });

  group('account name -> bank', () {
    test('full bank names map to the right bank', () {
      expect(bankTokenForAccountName('State Bank of India'), 'sbi');
      expect(bankTokenForAccountName('SBI Savings'), 'sbi');
      expect(bankTokenForAccountName('Punjab National Bank'), 'pnb');
      expect(bankTokenForAccountName('Indian Overseas Bank'), 'iob');
      expect(bankTokenForAccountName('City Union Bank'), 'city union bank');
      expect(bankTokenForAccountName('South Indian Bank'), 'south indian bank');
      expect(
        bankTokenForAccountName('Central Bank of India'),
        'central bank of india',
      );
      expect(bankTokenForAccountName('Bank of India'), 'bank of india');
      expect(bankTokenForAccountName('Indian Bank'), 'indian bank');
      expect(bankTokenForAccountName('Union Bank of India'), 'union bank');
      expect(bankTokenForAccountName('HDFC Bank'), 'hdfc');
    });

    test('a State Bank of India account accepts "-SBI" messages', () {
      expect(
        messageMatchesAllowedBank(sbiUpi,
            tokens: [bankTokenForAccountName('State Bank of India')],
            last4s: const []),
        isTrue,
      );
    });

    test('a Bank of India account does not accept State Bank SMS', () {
      const m = 'Rs 100 debited from State Bank of India A/c XX9999';
      expect(
        messageMatchesAllowedBank(m,
            tokens: [bankTokenForAccountName('Bank of India')],
            last4s: const []),
        isFalse,
      );
    });

    test('UPI handles never name the bank', () {
      expect(resolveBankKey('paid to shop@okaxis from your a/c'), '');
      expect(resolveBankKey('VPA swiggy@icici - Indian Bank'), 'indian bank');
    });
  });
}
