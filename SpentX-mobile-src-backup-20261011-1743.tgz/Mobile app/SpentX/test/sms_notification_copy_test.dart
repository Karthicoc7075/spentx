// Pure Dart assertions (no flutter_test dependency in this project).
// Run: dart run test/sms_notification_copy_test.dart
import 'package:spentx/features/sms/sms_notification_copy.dart';
import 'package:spentx/features/sms/rules/models/block_rule.dart';
import 'package:spentx/features/sms/rules/models/sms_rule.dart';
import 'dart:io';

void _assert(bool cond, String msg) {
  if (!cond) {
    throw Exception('ASSERT FAILED: $msg');
  }
}

void main() {
  stdout.writeln('── SmsNotificationCopy (default detected SMS) ──');

  // Unknown debit (New Merchant verify path)
  final r1 = SmsNotificationCopy.build(
    type: 'debit',
    amount: 120,
    merchantExists: false,
    merchantTitle: null,
    payee: 'SWIGGY',
    bank: 'HDFC',
  );
  _assert(r1.title == '💸 Spent ₹120', 'r1.title=${r1.title}');
  _assert(r1.body == 'New merchant detected. • Verify', 'r1.body=${r1.body}');
  _assert(r1.body.isNotEmpty, 'r1 body empty');

  final r2 = SmsNotificationCopy.build(
    type: 'credit',
    amount: 5000,
    merchantExists: false,
    payee: 'Employer',
    bank: 'SBI',
  );
  _assert(r2.title == '💸 Credit ₹5000', 'r2.title=${r2.title}');
  _assert(r2.body == 'New source detected. • Verify', 'r2.body=${r2.body}');

  final r3 = SmsNotificationCopy.build(
    type: 'transfer',
    amount: 2000,
    merchantExists: false,
    payee: 'ATM',
    bank: 'ICICI',
  );
  _assert(r3.title == '💸 ATM Withdraw ₹2000', 'r3.title=${r3.title}');
  _assert(r3.body == 'New ATM detected. • Verify', 'r3.body=${r3.body}');

  // Existing merchant (Auto-added path)
  final r5 = SmsNotificationCopy.build(
    type: 'debit',
    amount: 120,
    merchantExists: true,
    merchantTitle: 'Abi',
    bank: 'HDFC',
  );
  _assert(r5.title == '💸 Spent ₹120', 'r5.title=${r5.title}');
  _assert(r5.body == 'Abi • Added successfully.', 'r5.body=${r5.body}');

  // Active Outing auto-tag path
  final r6 = SmsNotificationCopy.build(
    type: 'debit',
    amount: 150,
    merchantExists: false,
    payee: 'Cafe',
    bank: 'Axis',
    outingTitle: 'Goa Trip',
  );
  _assert(r6.title == '🏖 Goa Trip', 'r6.title=${r6.title}');
  _assert(r6.body == 'Spent ₹150 • Added to Outing', 'r6.body=${r6.body}');

  stdout.writeln('  notification copy OK');

  stdout.writeln('── Block rules ──');
  final otpBlock = BlockRule(
    id: 'block-otp',
    name: 'OTP',
    keywords: ['otp', 'one time password', 'do not share'],
    sampleMessage: 'Your OTP is 123456',
    similarityThreshold: 0.6,
  );
  _assert(
    otpBlock.matchReason(
          'HDFC Bank: Your OTP is 482910 for login. Do not share with anyone.',
        ) !=
        null,
    'OTP should block',
  );
  _assert(
    otpBlock.matchReason(
          'HDFC: Rs.250 debited to VPA swiggy@okicici UPI Ref 123',
        ) ==
        null,
    'real debit must pass OTP block',
  );

  final promoBlock = BlockRule(
    id: 'block-promo',
    name: 'Offers',
    keywords: ['pre-approved', 'loan offer', 'click here'],
    pattern: r'pre-?approved',
    sampleMessage: 'Pre-approved loan offer',
    similarityThreshold: 0.5,
  );
  _assert(
    promoBlock.matchReason(
          'Congrats! Pre-approved personal loan offer. Click here.',
        ) !=
        null,
    'promo should block',
  );
  _assert(
    promoBlock.matchReason(
          'ICICI Bank: INR 320.00 debited for UPI/merchant@ybl/123 on 19-07-26.',
        ) ==
        null,
    'real debit must pass promo block',
  );
  stdout.writeln('  block rules OK');

  stdout.writeln('── New detection rule shape ──');
  final rule = SmsRule(
    id: 'rule-hdfc-upi-debit',
    matchPattern: r'debited',
    containsKeywords: ['debited', 'upi', 'rs'],
    excludeKeywords: ['otp', 'failed'],
    amountPattern: r'(?:rs\.?|inr|₹)\s*([0-9,]+(?:\.[0-9]{1,2})?)',
    namePattern: r'to\s+([A-Za-z0-9 @._-]+)',
    datePattern: r'on\s+(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})',
    refPattern: r'(?:upi\s*ref|ref)\s*([0-9]{6,})',
    type: 'Debit',
    mode: 'UPI',
    bankName: 'HDFC',
    sampleMessage:
        'HDFC Bank: Rs.250.00 debited from A/c XX1234 on 19-07-26 to VPA merchant@okicici. UPI Ref 998877665544.',
    accountPattern: r'a/c\s*(?:xx)?(\d{4})',
    upiPattern: r'([a-z0-9._-]+@[a-z]+)',
    isManual: true,
  );
  final restored = SmsRule.fromMap(rule.toMap());
  _assert(restored.id == rule.id, 'id round-trip');
  _assert(restored.bankName == 'HDFC', 'bank round-trip');
  _assert(restored.containsKeywords.contains('upi'), 'keywords');

  final amountRe = RegExp(rule.amountPattern, caseSensitive: false);
  final m = amountRe.firstMatch(rule.sampleMessage.toLowerCase());
  _assert(m != null, 'amount regex match');
  _assert(m!.group(1)!.replaceAll(',', '') == '250.00', 'amount extract');

  final notif = SmsNotificationCopy.build(
    type: 'debit',
    amount: 250,
    merchantExists: true,
    payee: 'merchant@okicici',
    bank: 'HDFC',
  );
  _assert(notif.title.contains('₹250'), 'notif amount');
  _assert(notif.body.contains('merchant@okicici'), 'notif payee in body');
  _assert(notif.body.contains('Added successfully.'), 'notif status in body');
  stdout.writeln('  detection rule OK');

  stdout.writeln('ALL SMS RULE / NOTIFICATION TESTS PASSED');
}
