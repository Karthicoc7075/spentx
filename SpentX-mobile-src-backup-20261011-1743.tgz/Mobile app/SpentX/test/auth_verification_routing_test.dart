// Run: dart run test/auth_verification_routing_test.dart
//
// A user who signed up, confirmed their email, and used the app for a day was
// shown "Verify your email" the next time the app signed them out — for an
// address that had been verified since the day before, with no way back to
// login.
//
// `pending_verification_email` is written at signup and was deleted in exactly
// one place: the verify screen's "change email" button. Confirming the address
// never cleared it. While a session existed the router's "signed in on an
// /auth route → /" rule masked the leftover, so it stayed invisible; once the
// session ended, the pending-signup rule rewrote every route — including the
// `/auth?expired=true` that sign-out itself navigates to — back to the verify
// screen.
//
// Two changes: a session arriving now clears the flag (a session is only
// issued to a confirmed address), and the routing rule no longer trusts the
// flag over a completed sign-in for the same address, which un-sticks devices
// that already carry the stale value.
import 'package:spentx/core/utils/auth_routing_rules.dart';
import 'dart:io';

void _assert(bool cond, String msg) {
  if (!cond) {
    throw Exception('ASSERT FAILED: $msg');
  }
}

/// Mirrors the signed-out half of `app_router.dart`'s `redirect`. The bug was
/// in how the rules composed, not in any one of them, so the assertions run
/// through the whole chain.
String? redirect(
  String loc, {
  required bool signedIn,
  required String? pendingEmail,
  required String lastSignedInEmail,
  bool verifiedAwaitingLogin = false,
  bool? setupCompleted,
  bool permissionsPromptPending = false,
  bool pinLock = false,
}) {
  return authRedirect(
    loc: loc,
    signedIn: signedIn,
    pendingEmail: pendingEmail,
    lastSignedInEmail: lastSignedInEmail,
    verifiedAwaitingLogin: verifiedAwaitingLogin,
    setupCompleted: setupCompleted,
    permissionsPromptPending: permissionsPromptPending,
    pinLock: pinLock,
  );
}

void main() {
  stdout.writeln('── the reported bug: verified yesterday, logged out today ──');

  // The state a real device was left in: signup wrote the flag, the address
  // was confirmed, and nothing ever removed it.
  const stale = (pendingEmail: 'karthi@example.com', last: 'karthi@example.com');

  _assert(
    redirect('/auth?expired=true',
            signedIn: false,
            pendingEmail: stale.pendingEmail,
            lastSignedInEmail: stale.last) !=
        '/auth/verify-email',
    'a sign-out must not land on the verify screen for an address that has '
    'already signed in on this device',
  );
  _assert(
    redirect('/auth',
            signedIn: false,
            pendingEmail: stale.pendingEmail,
            lastSignedInEmail: stale.last) ==
        null,
    'Welcome/login is reachable — the route stands as navigated',
  );
  _assert(
    redirect('/home',
            signedIn: false,
            pendingEmail: stale.pendingEmail,
            lastSignedInEmail: stale.last) ==
        '/auth',
    'a protected route while signed out still lands on Welcome, not verify',
  );
  stdout.writeln('  signed out with a stale flag → /auth, never /auth/verify-email');

  stdout.writeln('── a genuine pending signup is still held ──');

  // Nobody has completed a sign-in on this device yet.
  _assert(
    redirect('/auth',
            signedIn: false,
            pendingEmail: 'new@example.com',
            lastSignedInEmail: '') ==
        '/auth/verify-email',
    'an unconfirmed signup is held on the verify screen, even at /auth',
  );
  _assert(
    redirect('/home',
            signedIn: false,
            pendingEmail: 'new@example.com',
            lastSignedInEmail: '') ==
        '/auth/verify-email',
    'and from any protected route',
  );
  _assert(
    redirect('/auth/verify-email',
            signedIn: false,
            pendingEmail: 'new@example.com',
            lastSignedInEmail: '') ==
        null,
    'the verify screen itself does not redirect to itself',
  );
  _assert(
    redirect('/',
            signedIn: false,
            pendingEmail: 'new@example.com',
            lastSignedInEmail: '') ==
        null,
    'splash is exempt — it runs the session gate first',
  );
  stdout.writeln('  survives an app kill and outranks login/home, as designed');

  stdout.writeln('── a DIFFERENT address is still pending ──');

  // Signing in as one account says nothing about a signup started for another.
  _assert(
    shouldHoldForEmailVerification(
      pendingEmail: 'second@example.com',
      lastSignedInEmail: 'first@example.com',
    ),
    'a different account having signed in does not confirm this signup',
  );
  stdout.writeln('  only the SAME address clears the hold');

  stdout.writeln('── the address match is forgiving ──');

  _assert(
    !shouldHoldForEmailVerification(
      pendingEmail: '  Karthi@Example.com ',
      lastSignedInEmail: 'karthi@example.com',
    ),
    'case and stray whitespace must not resurrect the trap — Supabase '
    'lowercases the address it stores, the signup form does not',
  );
  stdout.writeln('  case- and whitespace-insensitive');

  stdout.writeln('── no pending signup at all ──');

  for (final empty in <String?>[null, '', '   ']) {
    _assert(
      !shouldHoldForEmailVerification(
        pendingEmail: empty,
        lastSignedInEmail: '',
      ),
      'nothing pending (${empty == null ? 'null' : '"$empty"'}) → no hold',
    );
  }
  stdout.writeln('  null / empty / blank are all "nothing pending"');

  stdout.writeln('── a signed-in user never sees the verify screen ──');

  _assert(
    redirect('/auth/verify-email',
            signedIn: true,
            pendingEmail: 'new@example.com',
            lastSignedInEmail: '') ==
        '/',
    'a session arriving while on the verify screen moves on to the splash gate',
  );
  _assert(
    redirect('/auth/reset-password',
            signedIn: true,
            pendingEmail: null,
            lastSignedInEmail: 'karthi@example.com') ==
        null,
    'reset-password stays exempt — its recovery link signs the user in on '
    'purpose and that screen is where they belong',
  );
  stdout.writeln('  signed in → splash gate, with reset-password exempt');

  stdout.writeln('── email confirm must not enter the app ──');
  _assert(
    redirect('/auth/callback',
            signedIn: true,
            pendingEmail: null,
            lastSignedInEmail: '',
            verifiedAwaitingLogin: true) ==
        '/auth/verify-email?verified=1',
    'a confirm-link session is sent back to the verify screen',
  );
  _assert(
    redirect('/home',
            signedIn: false,
            pendingEmail: null,
            lastSignedInEmail: '',
            verifiedAwaitingLogin: true) ==
        '/auth/verify-email?verified=1',
    'verified-awaiting-login cannot open Home',
  );
  _assert(
    redirect('/auth/verify-email',
            signedIn: false,
            pendingEmail: null,
            lastSignedInEmail: '',
            verifiedAwaitingLogin: true) ==
        null,
    'the verify screen itself stays up to say now login',
  );

  stdout.writeln('── setup_completed false blocks the app ──');
  _assert(
    redirect('/home',
            signedIn: true,
            pendingEmail: null,
            lastSignedInEmail: 'new@example.com',
            setupCompleted: false) ==
        '/onboarding',
    'unfinished account+purpose setup cannot open Home',
  );
  _assert(
    redirect('/onboarding',
            signedIn: true,
            pendingEmail: null,
            lastSignedInEmail: 'new@example.com',
            setupCompleted: false) ==
        null,
    'onboarding itself is allowed while setup is false',
  );
  _assert(
    redirect('/onboarding',
            signedIn: true,
            pendingEmail: null,
            lastSignedInEmail: 'done@example.com',
            setupCompleted: true,
            pinLock: true) ==
        '/lock',
    'finished setup with a PIN leaves the wizard for the lock screen',
  );
  _assert(
    redirect('/home',
            signedIn: true,
            pendingEmail: null,
            lastSignedInEmail: 'done@example.com',
            setupCompleted: true) ==
        null,
    'finished setup can open Home',
  );
  _assert(
    redirect('/activity',
            signedIn: true,
            pendingEmail: null,
            lastSignedInEmail: 'done@example.com',
            setupCompleted: true,
            permissionsPromptPending: true) ==
        '/onboarding?resume=permissions',
    'the one-time permission ask is offered before the rest of the app',
  );


  stdout.writeln('── email-confirm deep link must not black-screen ──');

  _assert(
    redirect('/auth/callback',
            signedIn: false,
            pendingEmail: 'new@example.com',
            lastSignedInEmail: '') ==
        null,
    'pending signup must not yank /auth/callback away — Soft Soft wait UI '
    'owns that beat while PKCE finishes',
  );
  _assert(
    redirect('/auth/callback',
            signedIn: true,
            pendingEmail: 'new@example.com',
            lastSignedInEmail: '') ==
        null,
    'signed-in on /auth/callback stays put so AuthCallbackScreen can hand off',
  );

  stdout.writeln('ALL AUTH VERIFICATION ROUTING TESTS PASSED');
}

