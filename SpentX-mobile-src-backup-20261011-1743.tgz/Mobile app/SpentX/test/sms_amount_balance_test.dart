// Run: flutter test test/sms_amount_balance_test.dart
//
// Two rules that decide how much money a message says moved:
//
//  1. right boundary — `Rs899_90D_2GB` is a telecom plan code, not ₹899
//  2. amount vs balance — a number introduced by "Avl Bal" is what is LEFT,
//     never what was spent
//
// Both were live bugs: the first turned a Jio data alert into a spend, the
// second would book "Rs.2200 spent … Avl Bal Rs.17,800" as ₹17,800.
import 'package:flutter_test/flutter_test.dart';
import 'package:spentx/features/sms_parser/sms_transaction_filters.dart';

void main() {
  group('transactionAmount', () {
    test('ignores a trailing balance', () {
      expect(
        SmsTransactionFilters.transactionAmount(
          'Axis Bank Debit Card 7890 used Rs.2200.00 at LIFESTYLE on '
          '07-06-2026. Avl Bal Rs.17,800.00',
        ),
        2200.00,
      );
      expect(
        SmsTransactionFilters.transactionAmount(
          'Fino Bank: Rs.340.00 used on Debit Card XX5566 at V Mart on '
          '07-06-26. Avl Bal:Rs.8,380.00',
        ),
        340.00,
      );
    });

    test('ignores a leading balance and finds the real amount after it', () {
      expect(
        SmsTransactionFilters.transactionAmount(
          'Available balance Rs.9,000.00. Rs.150.00 debited for UPI.',
        ),
        150.00,
      );
    });

    test('returns null when the message quotes only a balance', () {
      expect(
        SmsTransactionFilters.transactionAmount(
          'Dear Customer, the available balance in your SBI A/c XX5678 as on '
          '04-09-26 is INR 12,418.68. -SBI',
        ),
        isNull,
      );
    });

    test('a telecom plan code is not an amount', () {
      expect(
        SmsTransactionFilters.transactionAmount(
          'Plan Name : Rs899_90D_2GB/D_20GB Validity : 16-Aug-26',
        ),
        isNull,
      );
    });

    test('ordinary amounts still parse, commas and decimals included', () {
      expect(
        SmsTransactionFilters.transactionAmount('Sent Rs.450.00 To SWIGGY'),
        450.00,
      );
      expect(
        SmsTransactionFilters.transactionAmount('INR 5,000.00 credited'),
        5000.00,
      );
      expect(
        SmsTransactionFilters.transactionAmount('₹1234 debited'),
        1234.0,
      );
    });
  });

  group('statesMoneyMoved', () {
    test('accepts the formats that were being dropped', () {
      expect(
        SmsTransactionFilters.statesMoneyMoved(
          'Sent Rs.450.00 From HDFC Bank A/C x0034 To SWIGGY',
        ),
        isTrue,
      );
      expect(
        SmsTransactionFilters.statesMoneyMoved(
          'Axis Bank Debit Card 7890 used Rs.2200.00 at LIFESTYLE',
        ),
        isTrue,
      );
      expect(
        SmsTransactionFilters.statesMoneyMoved(
          'HDFC Bank: FD of Rs.50000.00 created from A/c **1234',
        ),
        isTrue,
      );
    });

    test('rejects money that has not moved yet', () {
      expect(
        SmsTransactionFilters.statesMoneyMoved(
          'Rs.2,499.00 will be debited on 05-Sep-26 from your A/c XX0034 '
          'towards SIP mandate ARN12345.',
        ),
        isFalse,
      );
    });

    test('rejects wording that only looks like a transaction', () {
      expect(
        SmsTransactionFilters.statesMoneyMoved(
          '50% of available data used as on 16-Aug-26',
        ),
        isFalse,
      );
      expect(
        SmsTransactionFilters.statesMoneyMoved(
          'Bal in HDFC Bank A/c XX0034 has gone below minimum limit',
        ),
        isFalse,
      );
    });
  });
}
