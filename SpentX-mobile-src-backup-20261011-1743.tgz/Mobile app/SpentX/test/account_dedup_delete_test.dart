import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:hive/hive.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spentx/core/providers/user_state_provider.dart';
import 'package:spentx/models/account_model.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  late Directory dir;

  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    dir = await Directory.systemTemp.createTemp('spentx_account_test_');
    Hive.init(dir.path);
    await Hive.openBox('settings');
    await Hive.openBox('sync_queue');
  });

  tearDown(() async {
    await Hive.close();
    await dir.delete(recursive: true);
  });

  test('UserStateNotifier.deduplicate merges duplicate accounts cleanly', () {
    final list = [
      AccountModel(id: '1', name: 'HDFC Bank', type: 'Bank', last4Digits: '1234', openingBalance: 5000),
      AccountModel(id: '2', name: 'HDFC Bank', type: 'Bank', last4Digits: '1234', openingBalance: 5000),
      AccountModel(id: '3', name: 'Cash', type: 'Cash', openingBalance: 1000),
    ];

    final deduped = UserStateNotifier.deduplicate(list);
    expect(deduped.length, 2);
    expect(deduped.map((a) => a.name).toList(), ['HDFC Bank', 'Cash']);
    expect(deduped.first.openingBalance, 5000);
  });

  test('removeAccount deletes ONLY the targeted account instance, never all matching names', () {
    final box = Hive.box('settings');
    final initialAccounts = [
      AccountModel(id: 'acc-1', name: 'HDFC Bank', type: 'Bank', last4Digits: '1234'),
      AccountModel(id: 'acc-2', name: 'HDFC Bank', type: 'Bank', last4Digits: '1234'),
      AccountModel(id: 'acc-3', name: 'Cash', type: 'Cash'),
    ];
    box.put('onboardingAccounts', initialAccounts.map((a) => a.toJson()).toList());

    final notifier = UserStateNotifier();
    // After load, notifier deduplicates initial duplicates
    expect(notifier.state.accounts.length, 2);

    // If we add two distinct accounts and delete one by ID
    final acc1 = AccountModel(id: 'acc-a', name: 'HDFC Salary', type: 'Bank', last4Digits: '1111');
    final acc2 = AccountModel(id: 'acc-b', name: 'ICICI Savings', type: 'Bank', last4Digits: '2222');
    notifier.addAccount(acc1);
    notifier.addAccount(acc2);

    final beforeCount = notifier.state.accounts.length;
    // Delete specifically acc-a
    notifier.removeAccount('HDFC Salary', accountId: 'acc-a');

    expect(notifier.state.accounts.length, beforeCount - 1);
    expect(notifier.state.accounts.any((a) => a.id == 'acc-a'), false);
    expect(notifier.state.accounts.any((a) => a.id == 'acc-b'), true);
  });

  test('different bank names stay even when last4 and id are blank', () {
    final list = [
      AccountModel(id: 'null', name: 'Cash', type: 'Cash'),
      AccountModel(id: 'null', name: 'HDFC', type: 'Bank', last4Digits: '1234'),
      AccountModel(id: 'null', name: 'SBI', type: 'Bank', last4Digits: '1234'),
    ];
    final deduped = UserStateNotifier.deduplicate(list);
    expect(deduped.map((a) => a.name).toList(), ['Cash', 'HDFC', 'SBI']);
  });

  test('addAccount rejects duplicate bank account number or duplicate name', () {
    final notifier = UserStateNotifier();
    notifier.addAccount(AccountModel(name: 'SBI Bank', type: 'Bank', last4Digits: '9999'));

    // Duplicate name rejected
    final errName = notifier.addAccount(AccountModel(name: 'SBI Bank', type: 'Bank', last4Digits: '8888'));
    expect(errName, contains('already exists'));

    // Duplicate last-4 digits rejected
    final errLast4 = notifier.addAccount(AccountModel(name: 'SBI Savings', type: 'Bank', last4Digits: '9999'));
    expect(errLast4, contains('already exists'));
  });
}
