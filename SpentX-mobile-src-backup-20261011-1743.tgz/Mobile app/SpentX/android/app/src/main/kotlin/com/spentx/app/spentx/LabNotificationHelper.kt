package com.spentx.app.spentx

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONObject

/**
 * Shows the same style of transaction alert as [SmsNotificationListenerService]
 * when the app is in the background / killed (lab scheduled test).
 */
object LabNotificationHelper {

    private const val CHANNEL_ID = "transaction_alerts"
    private const val PREFS = "FlutterSharedPreferences"
    private const val PENDING_PAYLOAD_KEY = "flutter.lab_pending_payload"

    fun showFromPayload(context: Context, payloadJson: String) {
        if (!SpentXDetectionPrefs.isAutoDetectionEnabled(context)) return

        val json = try {
            JSONObject(payloadJson)
        } catch (_: Exception) {
            return
        }

        val amount = json.optString("amount", "0")
        val merchant = json.optString("merchant", "Unknown")
        val bank = json.optString("bank", "Bank")
        val type = json.optString("type", "debit")
        val rawText = json.optString("rawText", "")

        // Persist for cold start (MainActivity.getInitialPayload)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(PENDING_PAYLOAD_KEY, payloadJson)
            .putBoolean("flutter.lab_open_pending_queue", true)
            .apply()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Transaction Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "SpentX SMS lab & background transaction alerts"
            }
            manager.createNotificationChannel(channel)
        }

        val launchIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)?.apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("open_pending_queue", true)
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            System.currentTimeMillis().toInt(),
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val savedTitle = SpentXDetectionPrefs.findSavedMerchantName(
            context = context,
            rawMessage = rawText,
            parsedUpi = if (merchant.contains("@")) merchant else null,
            parsedMerchant = merchant,
            bank = bank,
            type = type
        )
        val merchantExists = savedTitle != null

        val title: String
        val body: String
        if (!merchantExists) {
            when (type) {
                "credit" -> {
                    title = "Credit ₹$amount - Verify"
                    body = ""
                }
                "transfer" -> {
                    title = "ATM Withdraw ₹$amount - Verify"
                    body = ""
                }
                else -> {
                    title = "Spent ₹$amount - Verify"
                    body = ""
                }
            }
        } else {
            val titleName = savedTitle ?: "Merchant"
            val bankLabel = if (bank.trim().isNotEmpty()) bank.trim() else "Bank"
            when (type) {
                "credit" -> {
                    title = "Credit ₹$amount - Added"
                    body = "$titleName • $bankLabel."
                }
                "transfer" -> {
                    title = "ATM Withdraw ₹$amount - Added"
                    body = "$titleName • $bankLabel."
                }
                else -> {
                    title = "Spent ₹$amount - Added"
                    body = "$titleName • $bankLabel."
                }
            }
        }

        val notification = android.app.Notification.Builder(context, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(body)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        manager.notify(System.currentTimeMillis().toInt(), notification)
    }
}