package com.spentx.app.spentx

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import org.json.JSONObject
import java.util.regex.Pattern

class SmsNotificationListenerService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return

        if (!SpentXDetectionPrefs.isUserAuthenticated(this)) {
            SmsPendingQueue.clear(this)
            TransactionPendingQueue.clear(this)
            return
        }
        if (!SpentXDetectionPrefs.isAutoDetectionEnabled(this)) return
        if (!SpentXDetectionPrefs.isBackgroundDetectionEnabled(this)) return

        // Default SMS apps across common Android skins. UPI apps (GPay,
        // PhonePe, Paytm) are deliberately not here: their notifications need
        // their own parser.
        val allowedPackages = listOf(
            "com.google.android.apps.messaging", // Google Messages (Pixel, Nothing, Moto, OnePlus 12+)
            "com.android.mms",                   // AOSP / Xiaomi / older OEM
            "com.android.messaging",             // AOSP Messaging
            "com.samsung.android.messaging",     // Samsung Messages
            "com.oneplus.mms",                   // OnePlus (OxygenOS)
            "com.coloros.mms",                   // Oppo / Realme (ColorOS)
            "com.oppo.mms",
            "com.vivo.message",                  // Vivo (Funtouch / OriginOS)
            "com.motorola.messaging",            // Motorola
            "com.asus.message",                  // Asus
            "com.sonyericsson.conversations",    // Sony
            "com.htc.sense.mms",                 // HTC
            "com.lge.message",                   // LG
            "com.transsion.message",             // Tecno / Infinix / itel
        )
        val isBankApp = sbn.packageName.contains("bank", ignoreCase = true) || sbn.packageName.contains("hdfc") || sbn.packageName.contains("icici") || sbn.packageName.contains("sbi") || sbn.packageName.contains("axis")
        
        if (sbn.packageName !in allowedPackages && !isBankApp) return

        if (sbn.packageName.startsWith("com.spentx.app")) return

        val extras = sbn.notification.extras
        val text = extras.getCharSequence("android.text")?.toString() ?: return
        val lowerText = text.lowercase()

        // Only banks the user actually added — or one they plainly have but
        // never entered. A message naming none of their banks (a telecom data
        // alert, another bank's promo) is still not theirs.
        //
        // An unknown-but-bank-shaped message is queued WITHOUT posting a
        // notification: there is no account to book it against yet, so the
        // only honest thing to show would be a prompt about an account, and
        // Dart owns that decision. Queuing it here is what lets a forgotten
        // card surface even though it arrived while the app was killed.
        // See docs/ACCOUNT_DISCOVERY.md.
        val allowedBank = SpentXDetectionPrefs.isMessageFromAllowedBank(this, text)
        val discoverable = !allowedBank &&
            SpentXDetectionPrefs.isDiscoverableAccountMessage(this, text)
        if (!allowedBank && !discoverable) return

        // A real transaction verb is required. Finding a currency amount is not
        // enough on its own: "Bal ... has gone below minimum limit of INR
        // 5,000.00" and "Rs899_90D_2GB" both contain one but move no money.
        if (!hasTransactionVerb(lowerText)) return

        val amount = extractAmount(text) ?: return
        val merchant = extractMerchant(text)
        val bank = extractBank(text)
        // Credit must be checked before debit — credit SMS often contains "sent"/"from" phrases.
        // No `else` branch: hasTransactionVerb() above guarantees one of these
        // matches, so an unrecognised message is dropped rather than guessed
        // into a debit.
        // "Acct XX234 debited for Rs 450; ZOMATO credited" is the user's
        // money leaving — the "credited" half is the payee. Debit wording
        // that comes first wins (mirrors SmsDirectionHelper.debitStatedFirst).
        val debitIdx = Regex("\\bdebited\\b|\\b(a\\s+)?debit\\s+(by|of)\\b|\\bdeducted\\b")
            .find(lowerText)?.range?.first ?: -1
        val creditIdx = Regex("\\bcredited\\b|\\bcredit\\s+alert\\b|\\breceived\\b|\\bdeposited\\b")
            .find(lowerText)?.range?.first ?: -1
        val debitFirst = debitIdx >= 0 && (creditIdx < 0 || debitIdx < creditIdx)
        val type = when {
            debitFirst && !(lowerText.contains("withdrawn") || lowerText.contains("atm w/d")) -> "debit"
            lowerText.contains("credited") || lowerText.contains("credit alert") ||
                lowerText.contains("received") || lowerText.contains("deposited") -> "credit"
            lowerText.contains("withdrawn") || lowerText.contains("atm w/d") ||
                (lowerText.contains("atm") && lowerText.contains("withdraw")) -> "transfer"
            else -> "debit"
        }
        val mode = when {
            lowerText.contains("withdrawn") || lowerText.contains("atm") -> "atm"
            lowerText.contains("upi") || lowerText.contains("vpa") || merchant.contains("@") -> "upi"
            lowerText.contains("spent") && (lowerText.contains("card") || lowerText.contains("pos")) -> "card"
            else -> "unknown"
        }

        val transactionId = System.currentTimeMillis().toString()
        val transactionJson = JSONObject().apply {
            put("transactionId", transactionId)
            put("pending", true)
            put("amount", amount)
            put("merchant", merchant)
            put("bank", bank)
            put("type", type)
            put("mode", mode)
            put("rawText", text)
            put("nativeNotifShown", true)
            put("origin", "spentx_internal")
        }

        val payload = transactionJson.toString()
        if (discoverable) {
            // Unknown account: hand the raw text to Dart and stay silent. Dart
            // re-parses it, proposes the account, and creates no transaction.
            SmsPendingQueue.enqueue(applicationContext, sbn.packageName, text)
            SmsWorkScheduler.enqueueDrain(applicationContext)
            return
        }
        if (MainActivity.isAppInForeground) {
            val intent = Intent("NEW_TRANSACTION_DETECTED")
            intent.putExtra("data", payload)
            LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
        } else {
            TransactionPendingQueue.enqueue(applicationContext, payload)
            SmsWorkScheduler.enqueueDrain(applicationContext)
            showNotification(amount, merchant, bank, type, payload, transactionId, text)
        }
    }

    /**
     * Whether the text actually reports money moving.
     *
     * Deliberately the same set of verbs the `type` mapping above keys off, so
     * anything admitted here resolves to a real type and nothing has to be
     * guessed. This replaced a much weaker gate that accepted "rs" as a bare
     * substring — which matched inside ordinary words ("hours", "cards") and
     * let non-transactional alerts through.
     */
    private fun hasTransactionVerb(lowerText: String): Boolean {
        val verbs = listOf(
            "credited", "credit alert", "received", "deposited",
            "withdrawn", "atm w/d",
            "debited", "spent", "sent to", "paid to", "debit by", "a debit of"
        )
        if (verbs.any { lowerText.contains(it) }) return true
        return lowerText.contains("atm") && lowerText.contains("withdraw")
    }

    private fun extractAmount(text: String): String? {
        // Right-boundary lookahead: a real amount is never followed by a
        // letter, underscore or slash. Without it "Rs899_90D_2GB" (a telecom
        // plan code) parsed as 899 and posted a spend notification.
        val pattern = Pattern.compile(
            "(?i)(?:rs\\.?|inr|₹)\\s*([0-9][0-9,]*(?:\\.[0-9]{1,2})?)(?![0-9A-Za-z_/])"
        )
        val matcher = pattern.matcher(text)
        if (matcher.find()) return matcher.group(1)
        // SBI UPI: "debited by 250.0" — no currency marker at all.
        val bare = Pattern.compile(
            "(?i)\\b(?:debited|credited)\\s+(?:by|for|with)\\s+([0-9][0-9,]*(?:\\.[0-9]{1,2})?)(?![0-9A-Za-z_/])"
        ).matcher(text)
        return if (bare.find()) bare.group(1) else null
    }

    private fun extractMerchant(text: String): String {
        // 1) UPI ID (highest priority)
        val upiPattern = Pattern.compile("(?i)To\\s+([a-zA-Z0-9._-]+@[a-zA-Z]+)")
        val upiMatcher = upiPattern.matcher(text)
        if (upiMatcher.find()) {
            return upiMatcher.group(1)?.trim() ?: "Unknown"
        }

        // 2) Name and Fallback
        val lines = text.split("\n", "\r\n")
        for (line in lines) {
            val lowerLine = line.lowercase()
            if (lowerLine.contains("call ") || lowerLine.contains("sms ") || lowerLine.contains("block ") || lowerLine.contains("block upi")) {
                continue
            }
            // Match "To <Name>"
            val namePattern = Pattern.compile("(?i)To\\s+([A-Za-z ]+)")
            val nameMatcher = namePattern.matcher(line)
            if (nameMatcher.find()) {
                val match = nameMatcher.group(1)?.trim()
                if (!match.isNullOrEmpty() && match.length > 2) {
                    return match
                }
            }
        }
        return "Unknown"
    }

    private fun extractBank(text: String): String {
        val banks = listOf("HDFC", "SBI", "ICICI", "AXIS", "KOTAK")
        return banks.firstOrNull { text.contains(it, ignoreCase = true) } ?: "Bank"
    }

    private fun showNotification(
        amount: String,
        merchant: String,
        bank: String,
        type: String,
        payload: String,
        transactionId: String,
        text: String,
    ) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "sms_transactions"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "SMS Transactions",
                NotificationManager.IMPORTANCE_HIGH,
            )
            channel.description = "Notifications for auto-detected SMS transactions"
            manager.createNotificationChannel(channel)
        }

        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)?.apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            // Do not put the transaction JSON on this intent. MainActivity is
            // exported, so another app could spoof that extra.
            putExtra("open_pending_queue", true)
        }

        val pendingIntent = PendingIntent.getActivity(
            this,
            transactionId.hashCode(),
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        val savedTitle = SpentXDetectionPrefs.findSavedMerchantName(
            context = this,
            rawMessage = text,
            parsedUpi = if (merchant.contains("@")) merchant else null,
            parsedMerchant = merchant,
            bank = bank,
            type = type
        )
        val merchantExists = savedTitle != null

        // Match Flutter SmsNotificationCopy: Existing Merchant vs New Merchant formatting.
        val title: String
        val body: String
        if (!merchantExists) {
            when (type) {
                "credit" -> {
                    title = "💸 Credit ₹$amount"
                    body = "New source detected. • Verify"
                }
                "transfer" -> {
                    title = "💸 ATM Withdraw ₹$amount"
                    body = "New ATM detected. • Verify"
                }
                else -> {
                    title = "💸 Spent ₹$amount"
                    body = "New merchant detected. • Verify"
                }
            }
        } else {
            val titleName = savedTitle ?: "Merchant"
            when (type) {
                "credit" -> {
                    title = "💸 Credit ₹$amount"
                    body = "$titleName • Added successfully."
                }
                "transfer" -> {
                    title = "💸 ATM Withdraw ₹$amount"
                    body = "$titleName • Added successfully."
                }
                else -> {
                    title = "💸 Spent ₹$amount"
                    body = "$titleName • Added successfully."
                }
            }
        }

        val notification = android.app.Notification.Builder(this, channelId)
            .setContentTitle(title)
            .setContentText(body)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        // Same id Flutter uses (FNV-1a of the SMS text) so a later Dart
        // notification replaces this one instead of posting a second.
        manager.notify(notificationIdForSms(text), notification)
    }

    /** FNV-1a 32-bit of the trimmed SMS, masked to a positive notification id. */
    private fun notificationIdForSms(raw: String): Int {
        var hash = 0x811C9DC5.toInt()
        for (b in raw.trim().toByteArray(Charsets.UTF_8)) {
            hash = hash xor (b.toInt() and 0xFF)
            hash *= 0x01000193
        }
        return hash and 0x7FFFFFFF
    }
}
