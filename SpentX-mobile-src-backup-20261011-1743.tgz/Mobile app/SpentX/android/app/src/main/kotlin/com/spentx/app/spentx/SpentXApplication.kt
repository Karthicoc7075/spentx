package com.spentx.app.spentx

import android.content.Context
import androidx.work.Configuration
import androidx.work.ListenableWorker
import androidx.work.WorkerFactory
import androidx.work.WorkerParameters
/**
 * Owns WorkManager init so the background isolate can drain the encrypted SMS
 * queue. The default WorkManager initializer is removed in the manifest;
 * providing a second Configuration crashes process start.
 */
class SpentXApplication : android.app.Application(), Configuration.Provider {
    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(SpentXWorkerFactory())
            .build()
}

/**
 * workmanager 0.7 enqueues dev.fluttercommunity.workmanager.BackgroundWorker,
 * whose engine never registers a channel that can read [SecureQueueStore].
 * Swap that class for [SpentXBackgroundWorker], which does.
 */
class SpentXWorkerFactory : WorkerFactory() {
    override fun createWorker(
        appContext: Context,
        workerClassName: String,
        workerParameters: WorkerParameters,
    ): ListenableWorker? {
        if (workerClassName == "dev.fluttercommunity.workmanager.BackgroundWorker") {
            return SpentXBackgroundWorker(appContext, workerParameters)
        }
        return null
    }
}
