package com.spentx.app.spentx

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.provider.Settings
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel

/**
 * MainActivity must extend FlutterFragmentActivity (not FlutterActivity) for
 * local_auth plugin to work correctly. The biometric prompt requires a
 * FragmentActivity to host the dialog.
 */
class MainActivity : FlutterFragmentActivity() {
    companion object {
        @Volatile var eventSink: EventChannel.EventSink? = null
        var isAppInForeground = false
        /** True only between configureFlutterEngine and engine clean-up. */
        @Volatile var isEngineAttached = false
    }

    private var initialPayload: String? = null
    private var shouldOpenPendingQueue: Boolean = false
    private val BACKGROUND_CHANNEL = "com.spentx/notifications"
    private val BACKGROUND_EVENTS = "com.spentx/transaction_events"
    private val SMS_LAB_CHANNEL = "com.spentx.app/sms_lab"

    private val notificationReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == "com.spentx.app.NOTIFICATION_RECEIVED") {
                val data = mapOf(
                    "packageName" to intent.getStringExtra("packageName"),
                    "title" to intent.getStringExtra("title"),
                    "body" to intent.getStringExtra("text"),
                    "timestamp" to intent.getLongExtra("timestamp", 0)
                )
                eventSink?.success(data)
            }
        }
    }

    private var backgroundEventSink: EventChannel.EventSink? = null
    private val transactionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val data = intent?.getStringExtra("data")
            if (data != null) {
                backgroundEventSink?.success(data)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        isAppInForeground = true
    }

    override fun onPause() {
        super.onPause()
        isAppInForeground = false
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent) {
        // This activity is exported because it is the launcher. Do not accept
        // transaction_payload from the intent: any other app can start us and
        // attach one. Payloads are read only from app-private storage.
        if (intent.hasExtra("transaction_payload")) {
            intent.removeExtra("transaction_payload")
        }
        if (intent.getBooleanExtra("open_pending_queue", false)) {
            val caller = callingPackage
            if (caller == null || caller == packageName) {
                shouldOpenPendingQueue = true
            }
        }
        consumeLabPendingPayload()
    }

    private fun stampInternal(payload: String): String {
        return try {
            val obj = org.json.JSONObject(payload)
            obj.put("origin", "spentx_internal")
            obj.toString()
        } catch (_: Exception) {
            payload
        }
    }

    private fun consumeLabPendingPayload() {
        val prefs = getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
        val labPayload = prefs.getString("flutter.lab_pending_payload", null)
        if (!labPayload.isNullOrEmpty()) {
            val stamped = stampInternal(labPayload)
            if (initialPayload == null) initialPayload = stamped
            shouldOpenPendingQueue = true
            backgroundEventSink?.success(stamped)
            prefs.edit()
                .remove("flutter.lab_pending_payload")
                .remove("flutter.lab_open_pending_queue")
                .apply()
        } else if (prefs.getBoolean("flutter.lab_open_pending_queue", false)) {
            shouldOpenPendingQueue = true
            prefs.edit().remove("flutter.lab_open_pending_queue").apply()
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        isEngineAttached = true

        handleIntent(intent)

        LocalBroadcastManager.getInstance(this).registerReceiver(transactionReceiver, IntentFilter("NEW_TRANSACTION_DETECTED"))

        // Original MethodChannel for Permissions and Data
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "com.spentx.app/permissions").setMethodCallHandler { call, result ->
            when (call.method) {
                "isNotificationListenerEnabled" -> {
                    result.success(isNotificationListenerEnabled())
                }
                "openNotificationListenerSettings" -> {
                    val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                    startActivity(intent)
                    result.success(true)
                }
                "getDeveloperInboxSms" -> {
                    result.success(getDeveloperInboxSms())
                }
                "getInboxSms" -> {
                    val since = (call.argument<Number>("sinceMillis") ?: 0).toLong()
                    val limit = (call.argument<Number>("limit") ?: 300).toInt()
                    result.success(getInboxSms(since, limit))
                }
                "getPendingSms" -> {
                    result.success(SmsPendingQueue.drain(this))
                }
                "getPendingTransactionPayloads" -> {
                    result.success(TransactionPendingQueue.drain(this))
                }
                "clearSecureQueues" -> {
                    SmsPendingQueue.clear(this)
                    TransactionPendingQueue.clear(this)
                    result.success(true)
                }
                else -> result.notImplemented()
            }
        }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, SMS_LAB_CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "scheduleBackgroundTest" -> {
                    val payload = call.argument<String>("payload")
                    val delaySeconds = call.argument<Int>("delaySeconds") ?: 5
                    if (payload.isNullOrEmpty()) {
                        result.error("INVALID", "payload required", null)
                        return@setMethodCallHandler
                    }
                    val fireAt = SmsLabScheduler.schedule(this, payload, delaySeconds)
                    result.success(fireAt)
                }
                "cancelScheduledTest" -> {
                    SmsLabScheduler.cancel(this)
                    result.success(true)
                }
                "getScheduledFireAt" -> {
                    result.success(SmsLabScheduler.scheduledAtMillis(this))
                }
                else -> result.notImplemented()
            }
        }

        // New Background MethodChannel
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, BACKGROUND_CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "getInitialPayload" -> {
                    result.success(initialPayload)
                    initialPayload = null
                }
                "shouldOpenPendingQueue" -> {
                    result.success(shouldOpenPendingQueue)
                    shouldOpenPendingQueue = false
                }
                "openListenerSettings" -> {
                    startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    result.success(true)
                }
                else -> result.notImplemented()
            }
        }

        // Existing EventChannel for SMS/Notifications
        EventChannel(flutterEngine.dartExecutor.binaryMessenger, "com.spentx.app/sms").setStreamHandler(
            object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                    eventSink = events
                }

                override fun onCancel(arguments: Any?) {
                    eventSink = null
                }
            }
        )

        // New EventChannel for Transactions
        EventChannel(flutterEngine.dartExecutor.binaryMessenger, BACKGROUND_EVENTS).setStreamHandler(
            object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                    backgroundEventSink = events
                }
                override fun onCancel(arguments: Any?) {
                    backgroundEventSink = null
                }
            }
        )

        // Register BroadcastReceiver for existing notifications
        // Signature permission: other apps cannot broadcast notification text into us.
        val internalPerm = "com.spentx.app.spentx.INTERNAL_BROADCAST"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(
                notificationReceiver,
                IntentFilter("com.spentx.app.NOTIFICATION_RECEIVED"),
                internalPerm,
                null,
                Context.RECEIVER_NOT_EXPORTED,
            )
        } else {
            registerReceiver(
                notificationReceiver,
                IntentFilter("com.spentx.app.NOTIFICATION_RECEIVED"),
                internalPerm,
                null,
            )
        }
    }

    private fun getDeveloperInboxSms(): List<Map<String, Any>> {
        val messages = mutableListOf<Map<String, Any>>()
        try {
            val cursor = contentResolver.query(
                android.net.Uri.parse("content://sms/inbox"),
                null, null, null, "date DESC"
            )

            cursor?.use {
                val bodyIndex = it.getColumnIndex("body")
                val addressIndex = it.getColumnIndex("address")
                val dateIndex = it.getColumnIndex("date")

                var count = 0
                while (it.moveToNext() && count < 500) {
                    messages.add(mapOf(
                        "body" to (it.getString(bodyIndex) ?: ""),
                        "sender" to (it.getString(addressIndex) ?: ""),
                        "date" to it.getLong(dateIndex)
                    ))
                    count++
                }
            }
        } catch (_: Exception) {
            // Developer test screen shows an empty state when inbox access fails.
        }
        return messages
    }

    /**
     * Inbox rows received after [sinceMillis], newest first. Empty without
     * READ_SMS — this never requests the permission.
     */
    private fun getInboxSms(sinceMillis: Long, limit: Int): List<Map<String, Any>> {
        val messages = mutableListOf<Map<String, Any>>()
        if (checkSelfPermission(android.Manifest.permission.READ_SMS) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            return messages
        }
        try {
            val cursor = contentResolver.query(
                android.net.Uri.parse("content://sms/inbox"),
                arrayOf("address", "body", "date"),
                if (sinceMillis > 0) "date >= ?" else null,
                if (sinceMillis > 0) arrayOf(sinceMillis.toString()) else null,
                "date DESC"
            )
            cursor?.use {
                val bodyIndex = it.getColumnIndex("body")
                val addressIndex = it.getColumnIndex("address")
                val dateIndex = it.getColumnIndex("date")
                val cap = limit.coerceIn(1, 1000)
                while (it.moveToNext() && messages.size < cap) {
                    messages.add(mapOf(
                        "body" to (it.getString(bodyIndex) ?: ""),
                        "sender" to (it.getString(addressIndex) ?: ""),
                        "date" to it.getLong(dateIndex)
                    ))
                }
            }
        } catch (_: Exception) {
            // Caller treats an empty list as "nothing to catch up".
        }
        return messages
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val packageName = packageName
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return flat != null && flat.contains(packageName)
    }

    override fun cleanUpFlutterEngine(flutterEngine: FlutterEngine) {
        detachSinks()
        super.cleanUpFlutterEngine(flutterEngine)
    }

    /** The engine is going away: native listeners must queue from now on. */
    private fun detachSinks() {
        isEngineAttached = false
        eventSink = null
        backgroundEventSink = null
    }

    override fun onDestroy() {
        detachSinks()
        super.onDestroy()
        try {
            unregisterReceiver(notificationReceiver)
        } catch (e: Exception) {}
        try {
            LocalBroadcastManager.getInstance(this).unregisterReceiver(transactionReceiver)
        } catch(e: Exception) {}
    }
}
