package com.spentx.app.spentx

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Fires a scheduled SMS lab test after the user clears the app from recents.
 */
class SmsLabAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val payload = intent?.getStringExtra(EXTRA_PAYLOAD) ?: return
        LabNotificationHelper.showFromPayload(context.applicationContext, payload)
    }

    companion object {
        const val EXTRA_PAYLOAD = "transaction_payload"
    }
}