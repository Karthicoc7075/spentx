package com.spentx.app.spentx

import android.content.Context
import org.json.JSONArray

/**
 * Queues transaction JSON payloads from the notification listener when Flutter is not ready.
 * Encrypted at rest. SpentXBackgroundWorker decrypts this file inside the
 * app process and hands the payloads to Dart only after the auth check in drain.
 * Nothing is copied into FlutterSharedPreferences.
 */
object TransactionPendingQueue {
    private const val LEGACY_KEY = "flutter.native_tx_queue"
    private const val KEY = "tx_queue"
    private const val MAX = 30

    private fun store(context: Context) = SecureQueueStore.prefs(context).also {
        SecureQueueStore.migrateString(context, LEGACY_KEY, KEY)
    }

    fun enqueue(context: Context, payloadJson: String) {
        if (!SpentXDetectionPrefs.isUserAuthenticated(context)) {
            clear(context)
            return
        }
        val prefs = store(context)
        val existing = prefs.getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(existing)
        arr.put(payloadJson)
        while (arr.length() > MAX) {
            arr.remove(0)
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    fun drain(context: Context): List<String> {
        if (!SpentXDetectionPrefs.isUserAuthenticated(context)) {
            clear(context)
            return emptyList()
        }
        val prefs = store(context)
        val existing = prefs.getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(existing)
        val out = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            out.add(arr.getString(i))
        }
        prefs.edit().putString(KEY, "[]").apply()
        return out
    }

    fun clear(context: Context) {
        SecureQueueStore.migrateString(context, LEGACY_KEY, KEY)
        SecureQueueStore.prefs(context).edit().putString(KEY, "[]").apply()
        context.applicationContext
            .getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
            .edit()
            .remove(LEGACY_KEY)
            .apply()
    }
}
