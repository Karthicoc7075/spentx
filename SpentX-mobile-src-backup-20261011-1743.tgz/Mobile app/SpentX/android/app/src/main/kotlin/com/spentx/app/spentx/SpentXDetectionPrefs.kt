package com.spentx.app.spentx

import android.content.Context
import java.util.regex.Pattern
import org.json.JSONArray
import org.json.JSONObject

object SpentXDetectionPrefs {
    private const val PREFS = "FlutterSharedPreferences"
    private const val KEY_AUTO_DETECTION = "flutter.auto_detection"
    private const val KEY_BACKGROUND_DETECTION = "flutter.background_detection_enabled"
    private const val KEY_ALLOWED_BANKS = "flutter.allowed_banks_json"
    private const val KEY_AUTHENTICATED = "flutter.spentx_user_authenticated"

    /** False when missing. A detection preference defaulting to on is not a session. */
    fun isUserAuthenticated(context: Context): Boolean {
        return context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_AUTHENTICATED, false)
    }

    fun isAutoDetectionEnabled(context: Context): Boolean {
        return context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_AUTO_DETECTION, true)
    }

    fun isBackgroundDetectionEnabled(context: Context): Boolean {
        return context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_BACKGROUND_DETECTION, true)
    }

    /**
     * True when [message] mentions a bank the user has actually added, or one
     * of their account numbers.
     *
     * Dart writes the match tokens (see AutoDetectionNativeSync
     * .syncAllowedBanksToNative), so the bank keyword list lives in one place
     * and never has to be mirrored here.
     *
     * Fail closed: a missing key (never synced) or malformed JSON does not
     * forward the message. An empty token list also rejects everything.
     */
    fun isMessageFromAllowedBank(context: Context, message: String): Boolean {
        val jsonStr = context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_ALLOWED_BANKS, null) ?: return false

        return try {
            val root = JSONObject(jsonStr)
            val tokens = root.optJSONArray("tokens") ?: JSONArray()
            val last4s = root.optJSONArray("last4") ?: JSONArray()
            val lower = message.lowercase()

            for (i in 0 until tokens.length()) {
                val token = tokens.optString(i, "").trim().lowercase()
                if (token.isEmpty()) continue
                if (containsWord(lower, token)) return true
            }

            for (i in 0 until last4s.length()) {
                val last4 = last4s.optString(i, "").trim()
                if (last4.length < 3) continue
                // Only in an account/card context — a bare "0034" could be anything.
                val pattern = Pattern.compile(
                    "(?i)(?:x|\\*|a/c|ac|acct|account|card|no\\.?)\\s*[x*]*\\s*" +
                        Pattern.quote(last4) + "(?![0-9])"
                )
                if (pattern.matcher(lower).find()) return true
            }

            false
        } catch (e: Exception) {
            // Malformed payload must not forward unknown banks.
            false
        }
    }

    /**
     * True when [message] is bank-shaped but names an account the user has NOT
     * added, and has not already been ignored — a discovery candidate.
     *
     * Mirrors Dart's `isDiscoverableAccountMessage`. Kept deliberately narrow:
     * a bank keyword AND a context-anchored last-4 are both required, because
     * a message with no account number can never be told apart from an account
     * the user already has.
     *
     * Dart writes both lists (see AutoDetectionNativeSync), so the bank
     * keyword list still lives in exactly one place.
     */
    fun isDiscoverableAccountMessage(context: Context, message: String): Boolean {
        if (message.isBlank()) return false

        val prefs = context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val jsonStr = prefs.getString(KEY_ALLOWED_BANKS, null) ?: return false

        return try {
            val root = JSONObject(jsonStr)
            val tokens = root.optJSONArray("tokens") ?: JSONArray()
            val ignored = root.optJSONArray("ignored") ?: JSONArray()
            val blankLast4 = root.optJSONArray("tokensWithoutLast4") ?: JSONArray()
            val lower = message.lowercase()

            val token = (0 until tokens.length())
                .map { tokens.optString(it, "").trim().lowercase() }
                .firstOrNull { it.isNotEmpty() && containsWord(lower, it) }
                ?: knownBankTokenIn(lower)
                ?: return false

            // Their bank, but they never recorded which account — ambiguous,
            // so stay silent rather than propose what they already added.
            for (i in 0 until blankLast4.length()) {
                if (blankLast4.optString(i, "").trim().lowercase() == token) return false
            }

            val last4 = extractAccountLast4(message) ?: return false
            val key = "${token}_$last4"
            for (i in 0 until ignored.length()) {
                if (ignored.optString(i, "").trim().lowercase() == key) return false
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Last-4 in an account/card context, or null. Mirrors the Dart regex. */
    private fun extractAccountLast4(message: String): String? {
        val pattern = Pattern.compile(
            "(?i)(?:x|\\*|a/c|ac|acct|account|card|no\\.?)\\s*[x*]*\\s*(\\d{3,4})(?![0-9])"
        )
        val matcher = pattern.matcher(message)
        return if (matcher.find()) matcher.group(1) else null
    }

    /**
     * Bank keyword present in [lower], for a bank the user has NOT added.
     * Only the handful that appear in Indian bank SMS — Dart owns the full
     * list; this is just enough to recognise "this is a bank message".
     */
    private fun knownBankTokenIn(lower: String): String? {
        val banks = listOf(
            "hdfc", "icici", "sbi", "axis", "kotak", "indusind", "idfc", "idbi",
            "pnb", "canara", "federal bank", "yes bank", "rbl", "bandhan",
            "standard chartered", "citibank", "hsbc", "dbs", "bank of baroda",
            "bank of india", "union bank", "indian bank", "uco bank",
            "state bank", "punjab national", "indian overseas", "iob",
            "central bank of india", "city union", "south indian bank",
            "karur vysya", "tamilnad mercantile", "karnataka bank"
        )
        return banks.firstOrNull { containsWord(lower, it) }
    }

    private fun containsWord(haystack: String, needle: String): Boolean {
        val pattern = Pattern.compile(
            "(?<![a-z0-9])" + Pattern.quote(needle) + "(?![a-z0-9])",
            Pattern.CASE_INSENSITIVE
        )
        return pattern.matcher(haystack).find()
    }

    fun findSavedMerchantName(
        context: Context,
        rawMessage: String,
        parsedUpi: String?,
        parsedMerchant: String?,
        bank: String,
        type: String
    ): String? {
        val sharedPrefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val jsonStr = sharedPrefs.getString("flutter.known_merchants_json", null) ?: return null

        try {
            val candidates = mutableSetOf<String>()

            fun addCandidate(value: String?) {
                val v = value?.trim() ?: return
                if (v.isEmpty() || v.lowercase() == "unknown") return
                
                val norm = v.lowercase()
                    .replace("\\s+".toRegex(), " ")
                    .replace("[^a-z0-9@._\\- ]".toRegex(), "")
                
                if (norm.isNotEmpty()) {
                    candidates.add(norm)
                }
                
                val digits = v.replace("\\D".toRegex(), "")
                if (digits.length >= 10) {
                    candidates.add(digits)
                }
            }

            // Extract UPI from raw message
            val upiPattern = Pattern.compile("[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+")
            val upiMatcher = upiPattern.matcher(rawMessage)
            if (upiMatcher.find()) {
                addCandidate(upiMatcher.group(0))
            }

            // Extract To/From names
            val payeePatterns = listOf(
                Pattern.compile("(?i)To\\s+([A-Za-z ]+)"),
                Pattern.compile("(?i)from\\s+([A-Za-z ]+)")
            )
            for (pattern in payeePatterns) {
                val matcher = pattern.matcher(rawMessage)
                if (matcher.find()) {
                    addCandidate(matcher.group(1))
                }
            }

            addCandidate(parsedUpi)
            addCandidate(parsedMerchant)

            // For transfer (ATM withdrawals)
            if (type == "transfer") {
                val last4Pattern = Pattern.compile("(?i)(?:XX|\\*{1,2}|A/c\\s*\\*?|Acct\\s*\\*?|a/c\\s*no\\.?\\s*XX?)\\s*(\\d{2,4})")
                val last4Matcher = last4Pattern.matcher(rawMessage)
                val last4 = if (last4Matcher.find()) last4Matcher.group(1) else null
                
                val bankNorm = bank.trim().lowercase()
                    .replace("\\s+".toRegex(), "_")
                    .replace("[^a-z0-9_]".toRegex(), "")
                val cardClean = (last4 ?: "").replace("\\D".toRegex(), "")
                
                val atmKey = when {
                    bankNorm.isEmpty() && cardClean.isEmpty() -> "atm_unknown"
                    cardClean.length >= 4 -> "atm_${bankNorm}_$cardClean"
                    bankNorm.isNotEmpty() -> "atm_$bankNorm"
                    else -> "atm_card_$cardClean"
                }
                candidates.add(atmKey)
            }

            val rulesArray = JSONArray(jsonStr)
            for (i in 0 until rulesArray.length()) {
                val rule = rulesArray.getJSONObject(i)
                val ruleIdentifier = rule.optString("identifier", "").trim().lowercase()
                val ruleNormalizedKey = rule.optString("normalizedIdentifierKey", "").trim().lowercase()
                
                if (ruleIdentifier.isEmpty() && ruleNormalizedKey.isEmpty()) continue

                val idMatches = candidates.contains(ruleIdentifier) || candidates.contains(ruleNormalizedKey)
                if (!idMatches) continue

                val ruleType = rule.optString("transactionType", "").trim().lowercase()
                
                val isUpiRule = ruleIdentifier.contains("@") || ruleNormalizedKey.contains("@")
                val isPhoneRule = ruleIdentifier.replace("\\D".toRegex(), "").length in 10..13
                val ruleIsPortable = isUpiRule || isPhoneRule || ruleType == "any"
                
                val typeOk = ruleType.isEmpty() || ruleType == "any" || ruleType == type || ruleIsPortable
                if (typeOk) {
                    return rule.optString("displayName", null)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return null
    }
}