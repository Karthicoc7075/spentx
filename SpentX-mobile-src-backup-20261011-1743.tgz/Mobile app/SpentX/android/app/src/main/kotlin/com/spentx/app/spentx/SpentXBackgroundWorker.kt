package com.spentx.app.spentx

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.concurrent.futures.CallbackToFutureAdapter
import androidx.work.ListenableWorker
import androidx.work.WorkerParameters
import com.google.common.util.concurrent.ListenableFuture
import dev.fluttercommunity.workmanager.BackgroundWorker
import dev.fluttercommunity.workmanager.DebugHelper
import dev.fluttercommunity.workmanager.SharedPreferenceHelper
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.embedding.engine.dart.DartExecutor
import io.flutter.embedding.engine.loader.FlutterLoader
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugins.GeneratedPluginRegistrant
import io.flutter.view.FlutterCallbackInformation
import java.util.Random

/**
 * Same Dart callback protocol as workmanager's BackgroundWorker, plus the
 * permissions channel that drains [SecureQueueStore]. Payloads stay encrypted
 * until this process decrypts them for the signed-in Dart isolate. Nothing is
 * copied into FlutterSharedPreferences.
 */
class SpentXBackgroundWorker(
    applicationContext: Context,
    private val workerParams: WorkerParameters,
) : ListenableWorker(applicationContext, workerParams), MethodChannel.MethodCallHandler {
    private lateinit var backgroundChannel: MethodChannel

    private val payload
        get() = workerParams.inputData.getString(BackgroundWorker.PAYLOAD_KEY)

    private val dartTask
        get() = workerParams.inputData.getString(BackgroundWorker.DART_TASK_KEY) ?: ""

    private val isInDebug
        get() = workerParams.inputData.getBoolean(BackgroundWorker.IS_IN_DEBUG_MODE_KEY, false)

    private val randomThreadIdentifier = Random().nextInt()
    private var engine: FlutterEngine? = null
    private var startTime: Long = 0
    private var completer: CallbackToFutureAdapter.Completer<Result>? = null

    private var resolvableFuture =
        CallbackToFutureAdapter.getFuture { completer ->
            this.completer = completer
            null
        }

    override fun startWork(): ListenableFuture<Result> {
        startTime = System.currentTimeMillis()
        engine = FlutterEngine(applicationContext)

        if (!flutterLoader.initialized()) {
            flutterLoader.startInitialization(applicationContext)
        }

        flutterLoader.ensureInitializationCompleteAsync(
            applicationContext,
            null,
            Handler(Looper.getMainLooper()),
        ) {
            val callbackHandle = SharedPreferenceHelper.getCallbackHandle(applicationContext)
            val callbackInfo = FlutterCallbackInformation.lookupCallbackInformation(callbackHandle)
            if (callbackInfo == null) {
                Log.e(TAG, "WorkManager callback handle missing")
                stopEngine(Result.failure())
                return@ensureInitializationCompleteAsync
            }
            val dartBundlePath = flutterLoader.findAppBundlePath()

            if (isInDebug) {
                DebugHelper.postTaskStarting(
                    applicationContext,
                    randomThreadIdentifier,
                    dartTask,
                    payload,
                    callbackHandle,
                    callbackInfo,
                    dartBundlePath,
                )
            }

            engine?.let { engine ->
                try {
                    GeneratedPluginRegistrant.registerWith(engine)
                } catch (e: Exception) {
                    Log.e(TAG, "Plugin registration failed: ${e.message}")
                }
                MethodChannel(engine.dartExecutor.binaryMessenger, PERMISSIONS_CHANNEL)
                    .setMethodCallHandler { call, result ->
                        when (call.method) {
                            "getPendingSms" -> result.success(SmsPendingQueue.drain(applicationContext))
                            "getPendingTransactionPayloads" ->
                                result.success(TransactionPendingQueue.drain(applicationContext))
                            "clearSecureQueues" -> {
                                SmsPendingQueue.clear(applicationContext)
                                TransactionPendingQueue.clear(applicationContext)
                                result.success(true)
                            }
                            else -> result.notImplemented()
                        }
                    }

                backgroundChannel = MethodChannel(engine.dartExecutor, BACKGROUND_CHANNEL_NAME)
                backgroundChannel.setMethodCallHandler(this@SpentXBackgroundWorker)
                engine.dartExecutor.executeDartCallback(
                    DartExecutor.DartCallback(
                        applicationContext.assets,
                        dartBundlePath,
                        callbackInfo,
                    ),
                )
            }
        }

        return resolvableFuture
    }

    override fun onStopped() {
        stopEngine(null)
    }

    private fun stopEngine(result: Result?) {
        val fetchDuration = System.currentTimeMillis() - startTime
        if (isInDebug) {
            DebugHelper.postTaskCompleteNotification(
                applicationContext,
                randomThreadIdentifier,
                dartTask,
                payload,
                fetchDuration,
                result ?: Result.failure(),
            )
        }
        if (result != null) {
            this.completer?.set(result)
        }
        Handler(Looper.getMainLooper()).post {
            engine?.destroy()
            engine = null
        }
    }

    override fun onMethodCall(call: MethodCall, r: MethodChannel.Result) {
        when (call.method) {
            BACKGROUND_CHANNEL_INITIALIZED ->
                backgroundChannel.invokeMethod(
                    "onResultSend",
                    mapOf(
                        BackgroundWorker.DART_TASK_KEY to dartTask,
                        BackgroundWorker.PAYLOAD_KEY to payload,
                    ),
                    object : MethodChannel.Result {
                        override fun notImplemented() {
                            stopEngine(Result.failure())
                        }

                        override fun error(
                            errorCode: String,
                            errorMessage: String?,
                            errorDetails: Any?,
                        ) {
                            Log.e(TAG, "errorCode: $errorCode, errorMessage: $errorMessage")
                            stopEngine(Result.failure())
                        }

                        override fun success(receivedResult: Any?) {
                            val wasSuccessful = receivedResult?.let { it as Boolean? } == true
                            stopEngine(if (wasSuccessful) Result.success() else Result.retry())
                        }
                    },
                )
        }
    }

    companion object {
        private const val TAG = "SpentXBackgroundWorker"
        private const val PERMISSIONS_CHANNEL = "com.spentx.app/permissions"
        private const val BACKGROUND_CHANNEL_NAME =
            "be.tramckrijte.workmanager/background_channel_work_manager"
        private const val BACKGROUND_CHANNEL_INITIALIZED = "backgroundChannelInitialized"
        private val flutterLoader = FlutterLoader()
    }
}
