package com.spentx.app.spentx

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Queues SMS received while Flutter engine / EventChannel is not ready.
 * Stored encrypted (Android Keystore). Drained on next app start via MethodChannel.
 */
object SmsPendingQueue {
    private const val LEGACY_KEY = "flutter.native_sms_queue"
    private const val KEY = "sms_queue"
    private const val MAX = 50

    private fun store(context: Context) = SecureQueueStore.prefs(context).also {
        SecureQueueStore.migrateString(context, LEGACY_KEY, KEY)
    }

    fun enqueue(context: Context, sender: String?, body: String) {
        if (!SpentXDetectionPrefs.isUserAuthenticated(context)) {
            clear(context)
            return
        }
        val prefs = store(context)
        val existing = prefs.getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(existing)

        val obj = JSONObject()
        obj.put("sender", sender ?: "")
        obj.put("body", body)
        obj.put("timestamp", System.currentTimeMillis())
        arr.put(obj)

        while (arr.length() > MAX) {
            arr.remove(0)
        }

        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    fun drain(context: Context): List<Map<String, Any?>> {
        if (!SpentXDetectionPrefs.isUserAuthenticated(context)) {
            clear(context)
            return emptyList()
        }
        val prefs = store(context)
        val existing = prefs.getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(existing)
        val out = mutableListOf<Map<String, Any?>>()

        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            out.add(
                mapOf(
                    "sender" to obj.optString("sender", ""),
                    "body" to obj.optString("body", ""),
                    "timestamp" to obj.optLong("timestamp", 0L),
                ),
            )
        }

        prefs.edit().putString(KEY, "[]").apply()
        return out
    }

    fun clear(context: Context) {
        SecureQueueStore.migrateString(context, LEGACY_KEY, KEY)
        SecureQueueStore.prefs(context).edit().putString(KEY, "[]").apply()
        context.applicationContext
            .getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
            .edit()
            .remove(LEGACY_KEY)
            .apply()
    }
}
