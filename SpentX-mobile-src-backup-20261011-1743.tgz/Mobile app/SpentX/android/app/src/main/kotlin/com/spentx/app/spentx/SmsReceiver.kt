package com.spentx.app.spentx

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.telephony.SmsMessage
import android.util.Log

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        if (context == null || intent?.action != "android.provider.Telephony.SMS_RECEIVED") return
        if (!SpentXDetectionPrefs.isUserAuthenticated(context)) {
            SmsPendingQueue.clear(context)
            return
        }
        if (!SpentXDetectionPrefs.isAutoDetectionEnabled(context)) return

        val bundle = intent.extras ?: return
        try {
            val pdus = bundle.get("pdus") as? Array<*> ?: return
            val format = bundle.getString("format")
            var queued = false

            for (pdu in pdus) {
                val message = SmsMessage.createFromPdu(pdu as ByteArray, format)
                val sender = message.displayOriginatingAddress
                val body = message.displayMessageBody ?: continue

                Log.d("SmsReceiver", "SMS from $sender (${body.length} chars)")

                val data = mapOf(
                    "sender" to sender,
                    "body" to body,
                )

                // Only hand the SMS to Dart when the UI engine is really
                // alive. The sink used to outlive the engine after the app was
                // swiped away (the notification listener keeps the process
                // up), and success() on a dead engine silently dropped it.
                val sink = MainActivity.eventSink
                if (sink != null && MainActivity.isEngineAttached) {
                    sink.success(data)
                } else {
                    SmsPendingQueue.enqueue(context.applicationContext, sender, body)
                    queued = true
                    Log.d("SmsReceiver", "Flutter not ready — queued, drain scheduled")
                }
            }
            if (queued) SmsWorkScheduler.enqueueDrain(context.applicationContext)
        } catch (e: Exception) {
            Log.e("SmsReceiver", "Error receiving SMS: ${e.message}")
        }
    }
}