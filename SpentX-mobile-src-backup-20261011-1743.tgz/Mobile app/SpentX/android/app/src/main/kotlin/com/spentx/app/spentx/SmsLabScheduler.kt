package com.spentx.app.spentx

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object SmsLabScheduler {

    private const val REQUEST_CODE = 91042
    private const val PREFS = "FlutterSharedPreferences"

    fun schedule(context: Context, payloadJson: String, delaySeconds: Int): Long {
        cancel(context)

        val triggerAt = System.currentTimeMillis() + delaySeconds * 1000L
        val alarmIntent = Intent(context, SmsLabAlarmReceiver::class.java).apply {
            putExtra(SmsLabAlarmReceiver.EXTRA_PAYLOAD, payloadJson)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            alarmIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
            // No exact-alarm access (USE_EXACT_ALARM removed for Play policy;
            // SCHEDULE_EXACT_ALARM not granted): fire as close as Android allows.
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
        } else {
            @Suppress("DEPRECATION")
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
        }

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putLong("flutter.lab_scheduled_at", triggerAt)
            .putInt("flutter.lab_scheduled_delay", delaySeconds)
            .putString("flutter.lab_scheduled_payload_preview", payloadJson.take(120))
            .apply()

        return triggerAt
    }

    fun cancel(context: Context) {
        val alarmIntent = Intent(context, SmsLabAlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            alarmIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.cancel(pendingIntent)

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .remove("flutter.lab_scheduled_at")
            .remove("flutter.lab_scheduled_delay")
            .remove("flutter.lab_scheduled_payload_preview")
            .apply()
    }

    fun scheduledAtMillis(context: Context): Long {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getLong("flutter.lab_scheduled_at", 0L)
    }
}