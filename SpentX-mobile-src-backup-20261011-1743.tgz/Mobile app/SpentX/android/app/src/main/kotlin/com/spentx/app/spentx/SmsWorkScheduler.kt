package com.spentx.app.spentx

import android.content.Context
import android.util.Log
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequest
import androidx.work.WorkManager
import dev.fluttercommunity.workmanager.BackgroundWorker

/**
 * Starts the Dart queue drain as soon as a native listener queues something,
 * instead of waiting up to 15 minutes for the periodic job (or for the user
 * to open the app).
 *
 * Enqueues the same worker class and task name the Dart side registers
 * (BackgroundSmsScheduler.taskProcessQueue). SpentXWorkerFactory swaps the
 * class for SpentXBackgroundWorker, which can read SecureQueueStore.
 * APPEND_OR_REPLACE chains behind a drain that is already running, so a
 * message queued mid-drain is still picked up and nothing is cancelled.
 */
object SmsWorkScheduler {
    private const val TAG = "SmsWorkScheduler"
    private const val UNIQUE_NAME = "spentx.smsNative"
    private const val TASK_PROCESS_QUEUE = "spentx.processSmsQueue"

    fun enqueueDrain(context: Context) {
        if (!SpentXDetectionPrefs.isUserAuthenticated(context)) return
        try {
            val input = Data.Builder()
                .putString(BackgroundWorker.DART_TASK_KEY, TASK_PROCESS_QUEUE)
                .putBoolean(BackgroundWorker.IS_IN_DEBUG_MODE_KEY, false)
                .build()
            val request = OneTimeWorkRequest.Builder(BackgroundWorker::class.java)
                .setInputData(input)
                .build()
            WorkManager.getInstance(context.applicationContext)
                .enqueueUniqueWork(UNIQUE_NAME, ExistingWorkPolicy.APPEND_OR_REPLACE, request)
        } catch (e: Exception) {
            // The periodic job and the next app open still drain the queue.
            Log.e(TAG, "Could not enqueue SMS drain: ${e.message}")
        }
    }
}
