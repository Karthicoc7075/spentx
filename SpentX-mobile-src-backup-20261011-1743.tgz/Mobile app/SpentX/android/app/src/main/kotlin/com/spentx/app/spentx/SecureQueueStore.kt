package com.spentx.app.spentx

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys

/**
 * SMS and transaction queues live in EncryptedSharedPreferences. The key is
 * created in the Android Keystore (AES256-GCM). Nothing here is hardcoded.
 *
 * Plaintext copies under FlutterSharedPreferences are moved once, then deleted.
 */
object SecureQueueStore {
    private const val FILE = "spentx_secure_queues"
    private const val LEGACY = "FlutterSharedPreferences"

    fun prefs(context: Context): SharedPreferences {
        val app = context.applicationContext
        val masterKey = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
        return EncryptedSharedPreferences.create(
            FILE,
            masterKey,
            app,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }

    /** Moves a legacy plaintext value into the encrypted file and deletes it. */
    fun migrateString(context: Context, legacyKey: String, secureKey: String) {
        val legacy = context.applicationContext
            .getSharedPreferences(LEGACY, Context.MODE_PRIVATE)
        val old = legacy.getString(legacyKey, null) ?: return
        if (old.isNotEmpty() && old != "[]") {
            val secure = prefs(context)
            val existing = secure.getString(secureKey, null)
            if (existing.isNullOrEmpty() || existing == "[]") {
                secure.edit().putString(secureKey, old).apply()
            }
        }
        legacy.edit().remove(legacyKey).apply()
    }
}
