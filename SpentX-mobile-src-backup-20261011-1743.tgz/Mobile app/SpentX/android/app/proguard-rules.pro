# Flutter embedding and plugins. Release R8 only.
-keep class io.flutter.app.** { *; }
-keep class io.flutter.plugin.** { *; }
-keep class io.flutter.util.** { *; }
-keep class io.flutter.view.** { *; }
-keep class io.flutter.** { *; }
-keep class io.flutter.plugins.** { *; }
-keep class io.flutter.embedding.** { *; }
-dontwarn io.flutter.embedding.**

# Dart VM / JNI
-keep class com.google.android.play.core.** { *; }
-dontwarn com.google.android.play.core.**

# WorkManager worker class name is stored as a string.
-keep class dev.fluttercommunity.workmanager.** { *; }
-keep class com.spentx.app.spentx.SpentXApplication { *; }
-keep class com.spentx.app.spentx.SpentXWorkerFactory { *; }
-keep class com.spentx.app.spentx.SpentXBackgroundWorker { *; }
-keep class androidx.work.** { *; }

# Encrypted SMS queue (Tink + security-crypto).
-keep class androidx.security.crypto.** { *; }
-keep class com.google.crypto.tink.** { *; }
-dontwarn com.google.crypto.tink.**

# Supabase Flutter is Dart, but its Android plugins use Gson/OkHttp reflection.
-keep class com.supabase.** { *; }
-dontwarn com.supabase.**
-keep class io.github.jan.** { *; }
-dontwarn io.github.jan.**
-keepattributes Signature
-keepattributes *Annotation*
-keepattributes EnclosingMethod
-keepattributes InnerClasses

# SMS plugin. Left on telephony 0.2.0; do not strip its channel classes.
-keep class com.shounakmulay.telephony.** { *; }

# local_auth
-keep class androidx.biometric.** { *; }
