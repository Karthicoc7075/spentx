# SpentX — Local Database & Schema Reference

Complete inventory of all on-device storage: **Hive boxes**, **model schemas**, **settings keys**, **SharedPreferences**, and **secure storage**.

> Engine: [Hive](https://docs.hivedb.dev/) (`hive_flutter`) — JSON maps in most boxes; two typed `@HiveType` models exist but are **not registered** in `main.dart` (runtime uses plain maps).

---

## Quick index — all Hive boxes (24 active + 3 legacy)

| Box name | Encrypted | Primary purpose |
|---|---|---|
| `settings` | No | App prefs, PIN, onboarding, profile, debug flags |
| `transactions` | No | Financial transaction ledger |
| `outings` | No | Trips / group expenses |
| `friends` | No | Manual friends, recent picks, UPI links |
| `categories` | No | Custom expense/income category lists |
| `budgets` | No | Monthly category budgets |
| `investments` | No | Investment holdings |
| `merchant_rules_box` | No | Legacy merchant auto-map rules (UPI/phone/account id) |
| `merchants_box` | No | V4 payee-based verified merchants |
| `merchant_aliases` | No | Raw name → display alias map |
| `pending_detections` | No | Queue of pending SMS verification IDs |
| `detected_sms_box` | No | Full pending SMS detection records |
| `ignored_detections` | No | Ignored/deleted detection history |
| `pending_verification_history` | No | Pending/verified/ignored audit log |
| `notification_history` | No | In-app notification feed |
| `sms_template_rules_box` | No | User-trained SMS template rules |
| `block_rules_box` | No | SMS block/ignore rules |
| `detection_rules_box` | No | Regex/keyword SMS detection rules |
| `ignored_sms_box` | No | Auto-ignored SMS log (OTP, ads, blocked) |
| `processed_sms_box` | No | Dedupe by `referenceId` + parse audit log |
| `master_debug_log_box` | No | Developer debug log entries (lazy-open) |
| `vault` | **Yes** (AES) | Defined in `HiveService` — optional encrypted box |
| `sms_block_rules_box` | No | **Legacy** → migrated to `block_rules_box` |
| `sms_rules_box` | No | **Legacy** → migrated to `detection_rules_box` |
| `sms_template_box` | No | **Legacy** → migrated to `sms_template_rules_box` |

Boxes referenced in reset but unused at runtime: `user`, `user_state`.

---

## Secure storage (FlutterSecureStorage)

| Key | Type | Purpose |
|---|---|---|
| `hive_encryption_key` | `base64Url` bytes | AES key for encrypted `vault` box (`HiveService`) |

---

## SharedPreferences (native mirror / misc)

| Key | Type | Purpose |
|---|---|---|
| `auto_detection` | `bool` | Mirror of Hive `settings.auto_detection` for Android native SMS/notification code |
| `known_merchants_json` | `String` (JSON array) | Mirror of `merchant_rules_box` for native lookup |
| `has_prompted_notification_permission` | `bool` | First-launch notification listener permission prompt shown |
| `background_detection_enabled` | `bool` | Background notification detection toggle (default `true`) |

`known_merchants_json` entry shape:
```json
{ "identifier": "string", "normalizedIdentifierKey": "string", "displayName": "string", "transactionType": "debit|credit|transfer|any" }
```

---

## Box: `settings`

Unencrypted general-purpose settings box.

### PIN / lock screen / biometrics

| Key | Type | Default | Description |
|---|---|---|---|
| `pin_hash` | `String` | — | `base64Url(salt::pin)` hashed 4-digit PIN |
| `pin_salt` | `String` | — | Salt (epoch ms string) |
| `has_pin` | `bool` | `false` | Whether PIN is set |
| `lock_screen_enabled` | `bool` | `true` | Show lock screen on launch |
| `fingerprint_enabled` | `bool` | `false` | Biometric unlock enabled |

### Onboarding & profile

| Key | Type | Default | Description |
|---|---|---|---|
| `has_seen_onboarding` | `bool` | `false` | Onboarding carousel completed |
| `isFirstTimeUser` | `bool` | `true` | First-time user flag |
| `onboardingAccounts` | `List<Map>` | — | See **AccountModel** schema |
| `purposeTypes` | `List<String>` | `['Personal','Family']` | User purpose tags |
| `profile_name` | `String` | `'Karthi'` / `''` | Display name |

### SMS / detection

| Key | Type | Default | Description |
|---|---|---|---|
| `auto_detection` | `bool` | `true` | Auto-detect & add SMS transactions |
| `pending_notification_tx_id` | `String` | — | Notification tap target (consumed on open) |

### Privacy & UI

| Key | Type | Default | Description |
|---|---|---|---|
| `private_mode` | `bool` | `false` | Hide balances on home |
| `outing_privacy_mode` | `bool` | `false` | Trip-only view while outing active |
| `disable_rotation` | `bool` | `false` | Lock portrait orientation |
| `outing_categories` | `List<String>` | `['Trip','Restaurant','Temple','Family','Work']` | Global outing category picker |

### Debug (Master Debug Log)

| Key | Type | Default | Description |
|---|---|---|---|
| `master_debug_logging` | `bool` | `false` | Enable internal debug log |
| `debug_toast_messages` | `bool` | `false` | Show debug toasts |
| `master_debug_retention` | `int` | `500` | Max debug log entries |

### Budget alerts (dynamic keys)

| Key pattern | Type | Description |
|---|---|---|
| `budget_alert_{budgetId}_{year}_{month}` | `List<String>` | Fired thresholds: `'80'`, `'100'` |

---

## Box: `transactions`

| Key | Type | Description |
|---|---|---|
| `list` | `List<Map>` | All transactions (newest inserted at index 0) |

### Model: `Transaction` (`lib/models/transaction.dart`)

Primary ledger model used by `transactionProvider`.

| Field | Type | Required | Notes |
|---|---|---|---|
| `id` | `String` | auto UUID | Primary key |
| `merchant` | `String` | ✓ | Payee / title |
| `category` | `String` | ✓ | e.g. Food, Other |
| `account` | `String` | ✓ | Account name (Personal, Home, bank name) |
| `time` | `String` | ✓ | Display time string |
| `amount` | `double` | ✓ | |
| `isExpense` | `bool` | ✓ | `true` = debit/expense |
| `isAutoDetected` | `bool` | | From SMS pipeline |
| `isGroup` | `bool` | | Group expense flag |
| `groupCount` | `int` | | Split count |
| `paymentType` | `String` | | `Cash` \| `Online` |
| `date` | `String` (ISO8601) | ✓ | |
| `isTransfer` | `bool` | | Bank ↔ Cash transfer |
| `outingId` | `String?` | | Linked trip |
| `isAutoLinked` | `bool` | | Auto-linked to active outing |
| `rawIdentifier` | `String?` | | Merchant learning key |
| `purpose` | `String?` | | Personal, Family, etc. |
| `bankName` | `String` | | |
| `accountLast4` | `String` | | |
| `referenceId` | `String` | | SMS ref / UPI ref for dedupe |
| `upiId` | `String` | | |
| `rawMessage` | `String` | | Original SMS |
| `note` | `String` | | Free-text note |
| `isPendingVerification` | `bool` | | Awaiting user confirm |
| `isMerchantMapped` | `bool` | | Known merchant at add time |

### Alternate typed model (not active in ledger)

`lib/features/transactions/domain/transaction_model.dart` — `@HiveType(typeId: 1)` with fields: `id`, `amount`, `type` (income/expense/transfer), `accountId`, `paymentMode`, `category`, `note`, `merchant`, `isAutoDetected`, `date`, `createdAt`, `linkedTransactionId`, `outingId`, `isAutoLinked`. Adapter not registered.

---

## Box: `outings`

| Key pattern | Type | Description |
|---|---|---|
| `{outingId}` | `Map` | One **Outing** object per trip (preferred) |
| `list` | `List<Map>` | **Legacy** — array of outings (merged on load) |

### Model: `Outing`

| Field | Type | Notes |
|---|---|---|
| `id` | `String` | UUID |
| `title` | `String` | |
| `category` | `String` | Trip, Restaurant, etc. |
| `location` | `String?` | |
| `startDate` | `String` (ISO8601) | |
| `endDate` | `String` (ISO8601) | |
| `members` | `List<OutingMember>` | |
| `expenses` | `List<OutingExpense>` | |
| `isActive` | `bool` | Only one active at a time |
| `isAutoMode` | `bool` | Auto-link SMS in date range |

### Model: `OutingMember`

| Field | Type |
|---|---|
| `id` | `String` |
| `name` | `String` |

### Model: `OutingExpense`

| Field | Type | Notes |
|---|---|---|
| `id` | `String` | |
| `title` | `String` | |
| `amount` | `double` | |
| `category` | `String` | |
| `date` | `String` (ISO8601) | |
| `paymentMode` | `String` | Cash, UPI, etc. |
| `memberIds` | `List<String>` | Split participants (`'you'` or member UUID) |
| `settledMemberIds` | `List<String>` | Legacy full-settle ids |
| `splitType` | `int` | `0` = solo, `1` = equally |
| `transactionId` | `String?` | Linked ledger tx |
| `accountId` | `String?` | |
| `purpose` | `String` | |
| `paidByMemberId` | `String?` | Who paid the bill |
| `settledModes` | `Map<String,String>` | memberId → last mode (legacy) |
| `settlementPayments` | `Map<String, List<SettlementPayment>>` | Partial repayments |

### Model: `SettlementPayment`

| Field | Type |
|---|---|
| `amount` | `double` |
| `mode` | `String` |
| `date` | `String` (ISO8601) |

---

## Box: `friends`

| Key | Type | Description |
|---|---|---|
| `list` | `List<Map>` | Manual friends |
| `recent` | `List<String>` | Last 15 friend names used |
| `friend_upi_links` | `Map<String, List<String>>` | Friend name (lowercase key) → UPI handles |

### Manual friend entry (`list` item)

| Field | Type |
|---|---|
| `name` | `String` |
| `phone` | `String?` |

> Trip-derived friends are computed at runtime from `outings` — not stored here.

---

## Box: `categories`

| Key | Type | Default expense | Default income |
|---|---|---|---|
| `expense` | `List<String>` | Food, Shopping, Transport, Entertainment, Bills, Health, Trip, Hotel Stay, Flight, Sightseeing, Other | |
| `income` | `List<String>` | | Salary, Freelance, Interest, Investment, Other |

---

## Box: `budgets`

| Key | Type | Description |
|---|---|---|
| `list` | `List<Map>` | Budget items |

### Model: `BudgetItem`

| Field | Type | Default |
|---|---|---|
| `id` | `String` | |
| `category` | `String` | |
| `limit` | `double` | |
| `notifyAt80` | `bool` | `true` |
| `notifyAt100` | `bool` | `true` |

---

## Box: `investments`

| Key | Type | Description |
|---|---|---|
| `holdings` | `List<Map>` | Investment holdings |

### Model: `InvestmentHolding`

| Field | Type | Notes |
|---|---|---|
| `id` | `String` | |
| `name` | `String` | |
| `type` | `String` | `liquid`, `mutualFund`, `fixedDeposit`, `stocks`, `bonds`, `crypto`, `gold`, `realEstate`, `other` |
| `amount` | `double` | |
| `growthPercent` | `double` | |
| `updatedAt` | `String` (ISO8601) | |

---

## Box: `onboardingAccounts` → stored in `settings`

### Model: `AccountModel` (`lib/models/account_model.dart`)

| Field | Type | Notes |
|---|---|---|
| `id` | `String` | UUID |
| `name` | `String` | e.g. HDFC, Cash |
| `type` | `String` | `Bank` \| `Cash` |
| `last4Digits` | `String` | |
| `openingBalance` | `double` | |

### Alternate typed model (not active)

`lib/features/accounts/domain/account_model.dart` — `@HiveType(typeId: 0)`: `id`, `name`, `type` (own/home), `cashBalance`, `bankBalance`, `colorHex`, `iconName`. Adapter not registered.

---

## Box: `merchant_rules_box`

Keyed by rule `id`. Legacy merchant lookup (identifier → display name + category).

### Model: `MerchantRule`

| Field | Type | Notes |
|---|---|---|
| `id` | `String` | |
| `identifier` | `String` | UPI, phone, account id, ATM key |
| `normalizedIdentifierKey` | `String` | lowercase trimmed |
| `displayName` | `String` | User-facing merchant title |
| `defaultPurposeType` | `String` | Personal, Family, etc. |
| `defaultCategory` | `String` | |
| `transactionType` | `String` | `debit` \| `credit` \| `transfer` \| `any` |
| `lastUsedAt` | `String` (ISO8601) | |

Legacy field aliases on read: `normalizedMerchantKey`, `merchantName`, `accountType`, `category`.

---

## Box: `merchants_box`

Keyed by record `id`. V4 payee-based verified merchants.

### Model: `Merchant` / `MerchantRecord`

| Field | Type | Notes |
|---|---|---|
| `id` | `String` | |
| `payee` | `String` | Raw payee from SMS |
| `normalizedPayee` | `String` | Normalized lookup key |
| `title` | `String` | Display title |
| `purpose` | `String` | |
| `category` | `String` | default `Other` |
| `verifiedAt` | `String` (ISO8601) | |
| `isAutoApply` | `bool` | default `true` |

---

## Box: `merchant_aliases`

| Key | Value | Description |
|---|---|---|
| `{rawMerchantName}` | `String` | Display alias |

Flat key-value map (no wrapper key).

---

## Box: `pending_detections`

| Key | Type | Description |
|---|---|---|
| `queue` | `List<String>` | Pending transaction IDs (FIFO-ish, sort by date from `detected_sms_box`) |

---

## Box: `detected_sms_box`

Keyed by pending `id`. Full SMS detection awaiting verification.

### Model: `PendingTransaction`

| Field | Type | Notes |
|---|---|---|
| `id` | `String` | UUID |
| `amount` | `double` | |
| `receiver` | `String` | Payee |
| `bank` | `String` | |
| `date` | `String` (ISO8601) | |
| `rawMessage` | `String` | |
| `isExpense` | `bool` | |
| `isTransfer` | `bool` | |
| `accountLast4` | `String` | |
| `referenceId` | `String` | Dedupe key |
| `upiId` | `String` | |
| `outingId` | `String?` | |
| `isAutoLinked` | `bool` | |
| `notificationShown` | `bool` | |
| `popupOpened` | `bool` | |
| `savedTitle` | `String?` | Known merchant defer |
| `savedCategory` | `String?` | |
| `savedPurpose` | `String?` | |
| `deferAutoAdd` | `bool` | Background auto-add on next foreground |

---

## Box: `ignored_detections`

| Key | Type | Description |
|---|---|---|
| `history` | `List<Map>` | Ignored pending records (`PendingTransaction` JSON shape) |

---

## Box: `pending_verification_history`

| Key | Type | Description |
|---|---|---|
| `items` | `List<Map>` | Audit trail |

### Model: `PendingVerificationRecord`

| Field | Type | Notes |
|---|---|---|
| `transactionId` | `String` | |
| `createdAt` | `String` (ISO8601) | |
| `notificationShown` | `bool` | |
| `status` | `String` | `pending` \| `verified` \| `ignored` |
| `amount` | `double` | |
| `merchant` | `String` | |
| `bank` | `String` | |
| `type` | `String` | `debit`, `credit`, etc. |

---

## Box: `notification_history`

| Key | Type | Max |
|---|---|---|
| `items` | `List<Map>` | 200 entries |

### Model: `AppNotificationRecord`

| Field | Type | Notes |
|---|---|---|
| `id` | `String` | epoch ms |
| `title` | `String` | |
| `body` | `String` | |
| `type` | `String` | `general`, `budget`, `sms_auto`, `sms_pending`, etc. |
| `createdAt` | `String` (ISO8601) | |
| `isRead` | `bool` | |

---

## SMS rule boxes

### `sms_template_rules_box`

Keyed by rule `id`. User-trained structural SMS templates.

### Model: `SmsTemplateRule`

| Field | Type | Notes |
|---|---|---|
| `id` | `String` | |
| `bankName` | `String` | |
| `bankNameExact` | `String` | |
| `type` | `String` | `debit` \| `credit` \| `transfer` |
| `mode` | `String` | `upi` \| `atm` \| `card` \| `unknown` |
| `sampleMessage` | `String` | Training SMS |
| `templatePattern` | `String` | Tokenized pattern |
| `extractionMap` | `Map<String,String>` | originalText → fieldType |
| `exactTaggedValues` | `Map<String,String>` | fieldType → anchor text |
| `keywords` | `List<String>` | Required keywords |
| `similarityThreshold` | `double` | default `0.65` |
| `structuralParts` | `List<String>` | Static structural tokens |

**Template field types:** `amount`, `debitType`, `creditType`, `transferType`, `bankName`, `accountNumber`, `accountLast4`, `balance`, `upiId`, `referenceId`, `merchantName`, `title`, `date`, `time`, `atmWithdraw`, `cardPayment`, `ignoreText`

Bundled seed: `assets/sms/default_template_rules.json`

---

### `block_rules_box`

Keyed by rule `id`. Block OTP/promo/non-transaction SMS.

### Model: `BlockRule`

| Field | Type | Default |
|---|---|---|
| `id` | `String` | |
| `name` | `String?` | |
| `keywords` | `List<String>` | |
| `pattern` | `String?` | Regex |
| `sampleMessage` | `String` | |
| `similarityThreshold` | `double` | `0.6` |
| `createdAt` | `String` (ISO8601) | |

---

### `detection_rules_box`

Keyed by rule `id`. Regex/keyword SMS parse rules.

### Model: `SmsRule`

| Field | Type | Notes |
|---|---|---|
| `id` | `String` | |
| `matchPattern` | `String` | |
| `containsKeywords` | `List<String>` | |
| `excludeKeywords` | `List<String>?` | |
| `amountPattern` | `String` | |
| `namePattern` | `String` | |
| `datePattern` | `String` | |
| `refPattern` | `String` | |
| `type` | `String` | Debit, Credit, Transfer |
| `mode` | `String` | UPI, ATM, CARD |
| `bankName` | `String` | |
| `sampleMessage` | `String` | |
| `accountPattern` | `String` | |
| `upiPattern` | `String` | |
| `isManual` | `bool` | |

---

### `ignored_sms_box`

Append-only list entries (auto-increment keys).

| Field | Type |
|---|---|
| `rawMessage` | `String` |
| `reason` | `String` |
| `time` | `String` (ISO8601) |

---

### `processed_sms_box`

**Dual use:**

1. **Dedupe** — keyed by `referenceId`:
   ```json
   { "referenceId": "string", "at": "ISO8601" }
   ```

2. **Parse audit log** — append entries (from `SmsRuleEngine`):
   ```json
   {
     "rawMessage": "string",
     "ruleId": "string",
     "bank": "string",
     "amount": "number",
     "type": "Debit|Credit",
     "referenceId": "string",
     "time": "ISO8601",
     "source": "template"  // optional
   }
   ```

---

## Box: `master_debug_log_box`

Opened lazily when `settings.master_debug_logging = true`.

| Key | Type | Description |
|---|---|---|
| `entries` | `List<Map>` | Debug log (retention from `master_debug_retention`) |

### Debug log entry

| Field | Type |
|---|---|
| `id` | `String` |
| `timestamp` | `String` (ISO8601) |
| `level` | `String` | info, success, warning, error |
| `module` | `String` | system, sms, merchant, queue, ruleEngine, etc. |
| `title` | `String` |
| `message` | `String` |
| `dataJson` | `String?` | JSON-encoded map |
| `functionName` | `String?` |
| `errorMessage` | `String?` |
| `stackTrace` | `String?` |

---

## Box: `vault` (encrypted)

Defined in `lib/data/local/hive_service.dart`. AES-encrypted via key in FlutterSecureStorage. **Not opened in `main.dart`** — reserved for future secure data. Currently unused by providers.

---

## Legacy migration boxes

Migrated on startup by `migrateSmsHiveBoxes()`:

| Legacy box | Target box |
|---|---|
| `sms_block_rules_box` | `block_rules_box` |
| `sms_rules_box` | `detection_rules_box` |
| `sms_template_box` | `sms_template_rules_box` |

---

## Bundled assets (not Hive — seed sources)

| Asset | Purpose |
|---|---|
| `assets/sms/default_template_rules.json` | Default `SmsTemplateRule` seed |
| `assets/sms/bank_sms_templates_v4.json` | V4 bank SMS templates (runtime parse, not stored unless imported) |
| `assets/bank_sms_templates_v4_full.json` | Extended v4 catalog |

---

## Reset behavior (`AppResetService.resetAll`)

Clears all boxes listed above + SharedPreferences + PIN (`pin_hash`, `pin_salt`, `has_pin`).

Re-seeds `settings`:
- `has_seen_onboarding = false`
- `isFirstTimeUser = true`
- `auto_detection = true`
- `lock_screen_enabled = true`

---

## Startup open order (`main.dart`)

```
merchant_aliases, categories, outings, transactions, settings, friends,
pending_detections, detected_sms_box, ignored_detections,
sms_template_rules_box, block_rules_box, detection_rules_box,
ignored_sms_box, processed_sms_box,
merchant_rules_box, merchants_box (lazy), budgets, investments,
notification_history, pending_verification_history
```

Background worker (`SmsBackgroundInit`) opens a subset + runs migrations.

---

## Entity relationship (simplified)

```mermaid
erDiagram
    Transaction ||--o| Outing : "outingId"
    Outing ||--|{ OutingExpense : contains
    OutingExpense ||--o| Transaction : "transactionId"
    PendingTransaction ||--|| Transaction : "becomes on verify"
    MerchantRule ||--o{ Transaction : "auto-map"
    Merchant ||--o{ Transaction : "v4 auto-apply"
    Friend ||--o{ OutingMember : "derived from outings"
    SmsTemplateRule ||--o{ PendingTransaction : "parses SMS"
```

---

*Generated from SpentX codebase — all boxes, models, and keys as of project source.*