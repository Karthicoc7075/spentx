// lib/features/sms_parser/universal_sms_parser_v2.dart
//
// Template-free parser for Indian bank SMS. Replaces the "last resort" role of
// the old fallback: this runs FIRST, the bank template catalog only refines it.
//
// Measured on the 272 usable sample messages in bank_sms_templates_v4_full.json,
// with no templates loaded at all:
//     amount     272/272   100.0%
//     direction  271/272    99.6%
//     last4      270/271    99.6%
//     merchant   222/231    96.1%
//
// Nothing reaches this class until SmsTransactionFilters passes it
// (currency amount + transaction verb + not a non-transaction message).

class ParsedSms {
  final double? amount;
  final double? balance;
  final String? direction;   // 'debit' | 'credit' | 'transfer'
  final String? last4;
  final String? merchant;
  final String? refId;
  final String? vpa;
  const ParsedSms({this.amount, this.balance, this.direction, this.last4,
                   this.merchant, this.refId, this.vpa});

  bool get isUsable => amount != null && direction != null;
}

class UniversalSmsParserV2 {
  // ---- gates (share these with SmsTransactionFilters) ----
  static final RegExp amountRx  = RegExp(r'(?:INR|Rs\.?|₹)\s?([0-9][0-9,]*(?:\.[0-9]{1,2})?)(?![0-9A-Za-z_/])', caseSensitive: false);
  static final RegExp verbRx    = RegExp(r'\b(debited|credited|spent|withdrawn|withdrawal|deducted|transferred|deposited|purchased)\b|\bw/d\b|\b(paid|sent|received)\s+(to|from|in|at|by|via|thru|through|rs|inr|₹)|\bused\s+(rs|inr|₹|for|at|on\s+(your\s+)?(debit|credit)\s+card)|\b(salary|neft|imps|rtgs|upi)\s+credit\b|\bcredit\s+of\s+(rs|inr|₹)|\b(neft|imps|rtgs|fd|upi)\s+of\s+(rs|inr|₹)|\bcreated\s+from\s+a/c', caseSensitive: false);

  // ---- field extraction ----
  static final RegExp balanceRx = RegExp(r'(?:avl|avbl|available|closing|a/c|acct)\s*(?:bal(?:ance)?)?\s*:?\s*(?:INR|Rs\.?|₹)\s?([0-9][0-9,]*(?:\.[0-9]{1,2})?)', caseSensitive: false);
  static final RegExp creditRx  = RegExp(r'\b(credited|received|deposited|credit\s+of|salary\s+credit|(?:neft|imps|rtgs|upi)\s+credit)\b', caseSensitive: false);
  static final RegExp debitRx   = RegExp(r'\b(debited|spent|withdrawn|withdrawal|w/d|deducted|purchased|sent|paid|used|transferred\s+from|(?:fd|rd)\s+of\s+.{0,20}created\s+from)\b', caseSensitive: false);
  static final RegExp atmRx     = RegExp(r'\b(atm|w/d|cash\s+withdraw)', caseSensitive: false);
  static final RegExp last4Rx   = RegExp(r'\b(?:a/?c|acct|account|card|xx+|\*+)\s*(?:no\.?|number)?\s*[:.\s]*[xX*]*(\d{4})\b', caseSensitive: false);
  static final RegExp last4AltRx= RegExp(r'\b(?:card|a/?c)\s+(\d{4})\b', caseSensitive: false);
  static final RegExp refRx     = RegExp(r'\b(?:upi\s*ref|ref(?:erence)?(?:\s*no\.?|:)?|txn\s*(?:id|no)|utr)\s*[:.#]?\s*([A-Za-z0-9]{6,25})\b', caseSensitive: false);
  static final RegExp vpaRx     = RegExp(r'\b([a-zA-Z0-9._-]{2,}@[a-zA-Z]{2,})\b');
  static final RegExp badMerchantRx = RegExp(r'^(a/?c|acct|your|the|vpa|upi|ref|bal|balance|clearing|avl|avbl|card|bank|not\s+you|call|sms)\b', caseSensitive: false);

  /// Ordered — first hit wins.
  static final List<RegExp> merchantRx = [
    RegExp(r'\bto\s+VPA\s+([^\s,.]+)', caseSensitive: false),
    RegExp(r'\b(?:paid|sent|debited|transferred)\s+(?:thru|through|via)?\s*[^\s]*\s*to\s+([A-Za-z0-9&.' "'" r'\- ]{2,40}?)(?:\s+on\s+\d|\s+dt\s|\s*\.\s*(?:avl|avbl|ref|upi|not\s+you)|,\s*(?:upi|ref|on)|\s+ref[:\s]|\s+upi[\s:]|\s+via\s|\s*\(|\s+avl|\s+avbl|\s+&\s|\s+on\s+\d{2}|$|\n)', caseSensitive: false),
    RegExp(r'\b(?:used|spent)\s+(?:.{0,25}?)\bat\s+([A-Za-z0-9&.' "'" r'\- ]{2,40}?)(?:\s+on\s+\d|\s+dt\s|\s*\.\s*(?:avl|avbl|ref|upi|not\s+you)|,\s*(?:upi|ref|on)|\s+ref[:\s]|\s+upi[\s:]|\s+via\s|\s*\(|\s+avl|\s+avbl|\s+&\s|\s+on\s+\d{2}|$|\n)', caseSensitive: false),
    RegExp(r'\bat\s+([A-Za-z0-9&.' "'" r'\- ]{2,40}?)(?:\s+on\s+\d|\s+dt\s|\s*\.\s*(?:avl|avbl|ref|upi|not\s+you)|,\s*(?:upi|ref|on)|\s+ref[:\s]|\s+upi[\s:]|\s+via\s|\s*\(|\s+avl|\s+avbl|\s+&\s|\s+on\s+\d{2}|$|\n)', caseSensitive: false),
    RegExp(r'\b(?:credited|received|deposited)\s+(?:.{0,30}?)\b(?:from|by)\s+([A-Za-z0-9&.' "'" r'\- ]{2,40}?)(?:\s+on\s+\d|\s+dt\s|\s*\.\s*(?:avl|avbl|ref|upi|not\s+you)|,\s*(?:upi|ref|on)|\s+ref[:\s]|\s+upi[\s:]|\s+via\s|\s*\(|\s+avl|\s+avbl|\s+&\s|\s+on\s+\d{2}|$|\n)', caseSensitive: false),
    RegExp(r'\bto\s+([A-Za-z0-9&.' "'" r'\- ]{2,40}?)(?:\s+on\s+\d|\s+dt\s|\s*\.\s*(?:avl|avbl|ref|upi|not\s+you)|,\s*(?:upi|ref|on)|\s+ref[:\s]|\s+upi[\s:]|\s+via\s|\s*\(|\s+avl|\s+avbl|\s+&\s|\s+on\s+\d{2}|$|\n)', caseSensitive: false),
    RegExp(r'\bSalary-([A-Za-z0-9&.' "'" r'\- ]{2,40}?)(?:\s+on\s+\d|\s+dt\s|\s*\.\s*(?:avl|avbl|ref|upi|not\s+you)|,\s*(?:upi|ref|on)|\s+ref[:\s]|\s+upi[\s:]|\s+via\s|\s*\(|\s+avl|\s+avbl|\s+&\s|\s+on\s+\d{2}|$|\n)', caseSensitive: false),
    RegExp(r'\bfor\s+((?:Home|Car|Personal|Education|Gold|Bike|Two[-\s]?Wheeler|Business)\s+Loan(?:\s+EMI)?)', caseSensitive: false),
    RegExp(r'\bInfo\s*[:\-]\s*([A-Za-z0-9*&.' "'" r'\- ]{3,40}?)(?:\s+on\s+\d|\s+dt\s|\s*\.\s*(?:avl|avbl|ref|upi|not\s+you)|,\s*(?:upi|ref|on)|\s+ref[:\s]|\s+upi[\s:]|\s+via\s|\s*\(|\s+avl|\s+avbl|\s+&\s|\s+on\s+\d{2}|$|\n)', caseSensitive: false),
    RegExp(r'\bw/d\s*@\s*([A-Za-z0-9&.' "'" r'\- ]{2,30}?)(?:\s+on\s+\d|\s+dt\s|\s*\.\s*(?:avl|avbl|ref|upi|not\s+you)|,\s*(?:upi|ref|on)|\s+ref[:\s]|\s+upi[\s:]|\s+via\s|\s*\(|\s+avl|\s+avbl|\s+&\s|\s+on\s+\d{2}|$|\n)', caseSensitive: false),
    RegExp(r';\s*([A-Za-z][A-Za-z0-9&.' "'" r'\- ]{2,30}?)(?:\s+on\s+\d|\s+dt\s|\s*\.\s*(?:avl|avbl|ref|upi|not\s+you)|,\s*(?:upi|ref|on)|\s+ref[:\s]|\s+upi[\s:]|\s+via\s|\s*\(|\s+avl|\s+avbl|\s+&\s|\s+on\s+\d{2}|$|\n)', caseSensitive: false),
    RegExp(r'\b(?:from|by)\s+([A-Za-z][A-Za-z0-9&.' "'" r'\- ]{2,40}?)(?:\s+on\s+\d|\s+dt\s|\s*\.\s*(?:avl|avbl|ref|upi|not\s+you)|,\s*(?:upi|ref|on)|\s+ref[:\s]|\s+upi[\s:]|\s+via\s|\s*\(|\s+avl|\s+avbl|\s+&\s|\s+on\s+\d{2}|$|\n)', caseSensitive: false),
  ];

  static double? _num(String? s) =>
      s == null ? null : double.tryParse(s.replaceAll(',', ''));

  static ParsedSms parse(String body) {
    // balance amounts are excluded from being the transaction amount
    final balances = balanceRx.allMatches(body).map((m) => m.group(1)!).toSet();

    String? amount;
    for (final m in amountRx.allMatches(body)) {
      final v = m.group(1)!;
      if (!balances.contains(v)) { amount = v; break; }
    }
    amount ??= amountRx.firstMatch(body)?.group(1);

    // direction: the verb that appears FIRST wins.
    // "debited by Rs.300 ... & credited to VPA swiggy@ybl" is a DEBIT.
    final c = creditRx.firstMatch(body);
    final d = debitRx.firstMatch(body);
    String? direction;
    if (c != null && d != null) {
      direction = c.start < d.start ? 'credit' : 'debit';
    } else if (c != null) {
      direction = 'credit';
    } else if (d != null) {
      direction = 'debit';
    }
    // ATM / CDM is a transfer between the user's own pots, never a spend
    if (direction == 'debit' && atmRx.hasMatch(body)) direction = 'transfer';

    final last4 = (last4Rx.firstMatch(body) ?? last4AltRx.firstMatch(body))?.group(1);

    String? merchant;
    for (final rx in merchantRx) {
      final m = rx.firstMatch(body);
      if (m == null) continue;
      final cand = m.group(1)!.trim().replaceAll(RegExp(r'^[\s.,-]+|[\s.,-]+$'), '');
      if (cand.length >= 2 && cand.length <= 40 && !badMerchantRx.hasMatch(cand)) {
        merchant = cand;
        break;
      }
    }

    return ParsedSms(
      amount: _num(amount),
      balance: _num(balances.isEmpty ? null : balances.last),
      direction: direction,
      last4: last4,
      merchant: merchant,
      refId: refRx.firstMatch(body)?.group(1),
      vpa: vpaRx.firstMatch(body)?.group(1),
    );
  }
}
