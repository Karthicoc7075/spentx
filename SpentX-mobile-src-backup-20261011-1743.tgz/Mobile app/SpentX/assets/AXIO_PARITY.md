# SpentX — how to detect like axio (and where to stop copying)

**Related:** `SMS_DETECTION_FIX.md` (the bug fixes) · `ACCOUNT_DISCOVERY.md` (accounts)

---

## 0. Why axio catches everything and SpentX does not

axio is the old Walnut app, now run by an RBI-registered NBFC. It has been reading Indian bank SMS since 2015 and reads transaction SMS from over 40 banks and cards, categorising automatically. Its users say accounts are created automatically and it remembers merchants for next time.

The difference is **not** that axio has more templates. It is four architecture choices:

| | axio | SpentX today |
|---|---|---|
| What decides if a message is looked at | The message itself: does it state money moved? | A **bank allowlist** built from accounts the user typed |
| Primary parser | One **generic grammar** (amount + verb + account tail + payee) | A **catalog of 273 per-bank templates**; generic parser is only the last resort |
| History on install | Scans the existing inbox, months back | Mostly live messages |
| Merchant knowledge on day 1 | Ships a server-side merchant → category database | Empty; every merchant must be taught by the user |

Templates are a losing race: 100+ banks × card/UPI/ATM/NEFT/EMI/refund formats, each changing without notice. You will never finish the catalog. axio does not try.

---

## 1. The flip: generic parser first, templates second

Right now your pipeline is:

```
templates (505) → user rules → fallback parser   ← fallback almost never runs
```

It should be:

```
gates → GENERIC PARSER (always) → templates refine the result → merchant lookup
```

The generic parser needs six fields, nothing more:

| Field | Signal |
|---|---|
| amount | currency symbol + number, no letter/`_`/`/` after it |
| direction | first verb by position: `debited` / `credited` / `withdrawn` … |
| account tail | `a/c` \| `card` \| `XX` + 4 digits |
| payee | text after `to` / `at` / `to VPA` / `from`, stopped at the date, ref or balance |
| ref id | `UPI Ref` / `Ref no` / `UTR` — for dedupe |
| balance | number after `avl bal` — never the transaction amount |

**I built this and measured it against the 272 usable sample messages in your own `bank_sms_templates_v4_full.json`, with zero templates loaded:**

| Field | Coverage |
|---|---|
| amount | **272 / 272 — 100%** |
| direction | **271 / 272 — 99.6%** |
| account last-4 | **270 / 271 — 99.6%** |
| payee | **222 / 231 — 96.1%** |

One parser, ~120 lines, matches what 273 hand-written templates were supposed to do — and it also handles the 100+ banks that are *not* in your catalog, because it never asks which bank sent the message.

Two rules that mattered most while tuning it:

- **First verb by position wins.** `"A/c **5678 debited by Rs.300.00 ... & credited to VPA swiggy@ybl"` is a **debit**. Checking "credited" first books it as income.
- **The balance is not the amount.** `"used Rs.2200.00 at LIFESTYLE ... Avl Bal Rs.17,800.00"` — exclude any number that follows `avl/avbl/available/closing bal`.

Shipped: `universal_sms_parser_v2.dart` (drop into `lib/features/sms_parser/`) and `tool_generic_parser_check.py` (the reference I measured with — run it on your own inbox export to get your real numbers).

**Templates keep a job**, just a smaller one: cleaning up the payee (`SWIGGY*ORDER*123` → Swiggy), and forcing type where the wording is ambiguous. They stop being the gate.

---

## 2. Use the sender, not just the body

Every transactional SMS in India arrives from a DLT header — `VM-HDFCBK`, `AD-SBIINB`, `JD-ICICIB` — never from a 10-digit number. Your Kotlin receiver already has `sender`, but every gate looks only at `body`.

Add it as a signal:

- sender is a **10-digit number** → it is a person → never a transaction, whatever the body says. (This is also what stops a friend forwarding you their bank SMS.)
- sender is an **alphanumeric header** → candidate. Pull the bank token out of the header's 6-character part and fuzzy-match it against your existing `kKnownBankKeywords`, so `HDFCBK` → `hdfc` even when the body never spells "HDFC Bank".
- Do not hardcode a header list. Collect headers seen during the inbox scan and let unknown ones be learned — a fixed list goes stale the same way templates do.

Combined with the verb gate from `SMS_DETECTION_FIX.md`, this lets you **drop the bank allowlist as a hard gate** — which is what was silently eating the user's un-added credit card in `ACCOUNT_DISCOVERY.md`.

---

## 3. Inbox backfill on first run

axio feels smart in the first minute because it shows months of history immediately. Do the same, once, on permission grant:

- read 90 days (offer 180/365 as "load more history"),
- run every message through the same pipeline, **auto-add nothing** — produce pending rows grouped by merchant,
- one screen: *"We found 214 transactions from 6 accounts. Confirm the merchants you recognise."* Batch-confirm by merchant, not one by one.

That single screen also feeds account discovery and teaches the merchant DB. After it, live detection has almost nothing left to ask.

---

## 4. Never drop silently — the "Unparsed" bucket

This is the habit that closes the gap over time, and it costs almost nothing:

> Any message that passed the verb + amount gates but produced no usable transaction goes into an **Unparsed** list in Developer Options, with the raw text.

Then: sort by frequency, fix the top ones, ship a rule. You already have `SMS Detection Lab` to replay them and admin `sms_block_rules` / `sms_template_rules` to push fixes without an app update. What is missing is the list itself.

If you later want telemetry, upload only the **masked shape** (`Rs.{AMT} debited from A/c XX{L4} to {NAME}`) with explicit consent — never the raw SMS. Keeping raw text on-device is a real differentiator; do not trade it away.

---

## 5. Ship merchant knowledge, don't wait to learn it

On day 1 axio already knows SWIGGY is Food. SpentX knows nothing until the user teaches it, which is exactly when the app feels worse.

Ship a seed table (~1–2k rows) of common Indian payees → category: Swiggy, Zomato, Blinkit, Zepto, BigBasket, DMart, Amazon, Flipkart, Myntra, IRCTC, Uber, Ola, Rapido, IOCL/HP/BPCL, BESCOM/TNEB, Airtel, Jio, Netflix, Spotify, PhonePe/Paytm merchant tails, and so on. Match on the normalized payee key you already build.

Rules: seed is a **default**, the user's own rule always wins, and the seed lives in the admin pull-only tables so it updates without a release. Personal/Family purpose is never guessed — that stays user-owned.

---

## 6. Sources beyond SMS

UPI apps mostly do not send SMS any more — the bank does, but GPay/PhonePe/Paytm/CRED confirmations arrive as **notifications**. You already have `SmsNotificationListenerService`; point it at those packages too, then dedupe against SMS by `(amount, last4, ±3 min, refId)`.

That is also your iOS answer: no SMS there ever, so manual entry plus (later) email-receipt parsing is the only path.

---

## 7. Play Store — this is allowed, but declare it correctly

Google Play restricts SMS permissions, but there is an explicit permitted exception for **SMS-based money management** ("apps that track and manage budget"), covering `READ_SMS`, `RECEIVE_SMS`, `RECEIVE_MMS`, `RECEIVE_WAP_PUSH`. You must submit the Permissions Declaration Form and get approval; apps without one may be removed.

Three things to get right:

- `SEND_SMS` is **not** in that exception — do not put it in the manifest.
- The spyware policy states budgeting apps may not exfiltrate non-financial or personal SMS history. Your "only the transaction syncs, never the SMS body" design already complies — say so in the declaration and privacy policy.
- Your store listing must prominently document SMS-based tracking as the core feature.

Since this is a rule that changes, re-check the current text before you submit.

---

## 8. What to copy from axio — and what not to

**Copy:** generic parsing over templates · inbox backfill · confirm-once-then-silent merchants · notification for spend detected · account suggestions from SMS.

**Do not copy:**

- **Uploading everything.** axio backs your transaction and balance data to their servers; the business behind it is lending, and reviewers have called out the privacy trade. Local-first Hive with only the transaction syncing is your actual differentiator — detection quality comes from the *rules*, not from uploading SMS.
- **Silent account creation.** See `ACCOUNT_DISCOVERY.md`: suggest, confirm once, then automatic.
- **Loan / FD marketplace.** Different business, different licence, different app.

Your edge stays: Purpose axis (Personal/Family), outings + friend splits, true net worth from opening balances, ATM/CDM as transfer, PIN + Private Mode.

---

## 9. Order of work

1. Verb gate + amount boundary + block rules — from `SMS_DETECTION_FIX.md`. Stops the junk.
2. `universal_sms_parser_v2.dart` runs **before** the template layer; templates refine only. Biggest single jump in detection.
3. Sender header signal; retire the bank allowlist as a hard gate (pair with `PendingAccount`).
4. Unparsed bucket in Developer Options.
5. Inbox backfill screen with batch merchant confirm.
6. Seed merchant catalog via the admin pull-only tables.
7. Notification listener for GPay / PhonePe / Paytm / CRED + cross-source dedupe.
8. Play Console permissions declaration before the public release.

After steps 1–3 you should be at or past axio on detection, on a device that never uploads a single SMS.
