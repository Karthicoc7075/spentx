# SpentX Soft Clean-Architecture Rewrite — Status

**Updated:** 2026-10-01 ~13:30 Asia/Calcutta
**Figma:** `JImVYBCKgNoo9fYrEUpZus` (SpentX Soft) + Soft Neo-Fintech Soft frames
**Palette locked:** `#f8f9fc` bg · `#020617` ink · `#64748b` muted · `#059669` emerald  
**Backup / web:** untouched

Note: Figma MCP may be rate-limited — Soft hexes from `lib/core/theme/soft_palette.dart` are the source of truth.

## Coverage — Soft screens done

| Area | Soft status |
|------|-------------|
| Palette + SoftBottomNav | done |
| Home | Soft Figma hierarchy (Hello + liquid `#06281e→#01140e` card, denser gaps, Soft cards for recent/outing/plan); Soft nav active `#10b981` |
| Auth | landing/login/signup Soft; lock/onboarding/splash Soft emerald marks (no dark-green invent) |
| Accounts + Transactions | Soft cards; `transaction_provider` → `transactions/data` |
| **Transaction details (Soft Neo-Fintech Soft)** | Soft header circles, amount hero + details cards, SMS pill, Edit/Delete — visual Soft Figma parity |
| **Soft Home densify (this run)** | Hello greeting; tight section gaps; borderless Soft shadows; recent as Soft cards; liquid Soft gradient |
| Wealth | Soft light hero; wealth + daily_snapshot → `wealth/data` |
| Analytics | SoftAnalyticsPalette only |
| Plan | Soft cards/progress; `plan_provider` → `plan/data` |
| Outings/Groups | Soft list + Soft detail hero; `outing_provider` → `groups/data` |
| Settings | Soft profile/groups/SMS banner + notif prefs / purpose / premium / merchants |
| SMS | activity/detected/smart/rules/block Soft; lab + batch Soft (this run) |
| Budgets | SoftBudgetHero/Card/Progress |
| Calendar | SoftCalendarCard + Soft emerald selection |
| Recurring | SoftRecurringCard |
| Friends | SoftFriendsCard/Avatar; Soft detail hero |
| Notifications | SoftNotificationCard + softNotificationAccent |
| **Investments (this run)** | SoftInvestmentHero/Card/Progress; Soft emeraldSoft wealth hero |
| **Loans (this run)** | SoftLoanCard/Progress; Soft emerald vs positive paid-off |
| **Export (this run)** | SoftExportCard; Soft positive/emerald chrome |
| **Cash reminder (this run)** | Soft warning icon + Soft emerald save |
| **SMS lab / batch (this run)** | Soft card surfaces (no dark `#141414`); Soft emerald/positive/negative/warning stats |

## Analyze
| Severity | Count |
|----------|------:|
| **error** | **0** |
| **warning** | **0** (was 73) |
| **info** | **31** (was 471) |

### Warning cleanup (2026-10-01 ~12:58 IST)
Real fixes only — no ignore-comment suppressions:
- **29** unused imports (app_colors / glass_card / Soft leftovers across feature screens)
- **32** unnecessary_type_check on Postgrest `select()` results (`sync_service`, `sms_rules_refresh_service`); Hive/dynamic guards kept
- **3** unused locals + **2** unused private widgets (`_SectionHeader`, `_BudgetBar`) + **1** unused param
- **3** unnecessary casts (`group_detail_screen`)
- **1** redundant null check (`auto_rule_engine` `isAutoLinked && outingId`)
- **2** unnecessary `!` in `tool/test_background_pending_flow.dart` (bound to non-null local)

### Info cleanup (2026-10-01 ~13:02 IST) — 471 → 31
Real fixes; Soft chrome / controlled-dropdown behavior left alone.

| Lint | Fixed | Notes |
|------|------:|-------|
| `deprecated_member_use` (`withOpacity`) | 242 | → `.withValues(alpha: …)` across `lib/` |
| `avoid_print` | 140 | `test/` + `tool/` → `stdout.writeln` (+ `dart:io`) |
| `deprecated_member_use` (`NAMESPACE_URL`) | 17 | → `Namespace.url.value` |
| `use_super_parameters` / keys / braces / docs / imports / `??=` / etc. | ~37 | easy `lib/` + tool relative imports |
| `deprecated_member_use` (`activeColor` on Switch) | 3 | → `activeThumbColor` |
| `deprecated_member_use` (`anonKey`) | 1 | → `publishableKey` |

**Left intentionally (31):**
- **19** `use_build_context_synchronously` — needs per-site `mounted`/context capture; risk of navigator/snackbar regressions
- **12** `DropdownButtonFormField.value` → `initialValue` — controlled `setState` dropdowns; naive swap would break selection updates (Flutter 3.33+ FormField API)

## Provider moves (this run)

Moved from `lib/core/providers/` → `lib/features/<feature>/data/` with thin core re-exports:

| Provider | Destination |
|----------|-------------|
| `budget_provider` | `budgets/data` |
| `friends_provider` | `friends/data` |
| `friend_reminder_provider` | `friends/data` |
| `friend_split_provider` | `friends/data` |
| `friend_upi_provider` | `friends/data` |
| `contacts_provider` | `friends/data` |
| `settlement_feedback_provider` | `friends/data` |
| `investment_provider` | `investments/data` |
| `outing_privacy_provider` | `groups/data` |
| `pending_account_provider` | `accounts/data` |
| `merchant_provider` | `settings/data` |
| `merchant_alias_provider` | `settings/data` |
| `contributor_provider` | `settings/data` |
| `animation_provider` | `settings/data` |

Already moved earlier: `transaction` → transactions; `wealth` + `daily_snapshot` → wealth; `plan` → plan; `outing` → groups; `private_mode` + `dashboard_kpi` → home; `theme_mode` → settings.

### Intentionally remaining in `lib/core/providers/` (full impl)
| Provider | Why |
|----------|-----|
| `category_provider` | Cross-cutting (transactions, plan, recurring, SMS, core widgets) |
| `user_state_provider` | App session / accounts / purposes — used across nearly every feature |

### No dedicated Riverpod providers found (N/A)
loans, recurring, calendar, export, notifications — screens use shared services/providers; SMS rule/template providers already live under `features/sms/rules/providers/`.

### Deleted
- Placeholder `README.md` stubs under feature `data/` folders that now hold real providers (budgets, friends, investments, groups).

## Leftover (not blocking Soft chrome)

1. **Info leftovers (31):** `use_build_context_synchronously` (19) + DropdownButtonFormField `value` (12) — left (async / controlled-field risk).
2. **Deeper screen parity** vs every Soft Figma frame (sheets, debug/developer screens) — chrome Soft-tokenized; not a pixel-perfect frame audit.
3. **Dark mode** keeps structural Soft flips (`SoftPalette.dark*`); light Soft hexes are canonical.
4. Optional later: point feature-local imports at `features/*/data` instead of core re-exports.


## Soft Home vs Soft Figma remaining (2026-10-01)

Still may differ slightly from Soft frames:
1. Populated Monthly Plan / Saving Report gauge micro-layout (not a pixel clone of Soft Pro copy).
2. Illustration size on first-time Monthly Plan vs Figma artboard (asset aspect kept; height tightened).
3. Category chips on recent Soft tiles use emeraldSoft rather than per-category Soft Pro pastel fills when dark/light mapping differs.
4. Bottom nav height 68 vs Figma ~72 — denser for Soft whitespace request.
