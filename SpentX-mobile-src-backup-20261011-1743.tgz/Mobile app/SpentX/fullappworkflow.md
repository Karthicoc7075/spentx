# SpentX — Full App Workflow & Feature Documentation

> **SpentX** is an offline-first, PIN-protected personal finance app for Android (Flutter) built for Indian users. It automatically detects bank/UPI transactions from SMS and notification alerts, tracks spending by account and purpose, manages budgets, splits trip costs with friends, and provides analytics — all stored locally on device.

**Version:** 1.0.0+1  
**Platform:** Flutter (Android primary; iOS/Windows/Linux scaffolding present)  
**Currency:** ₹ (INR)

---

## Table of Contents

1. [Technology Stack](#1-technology-stack)
2. [App Startup Workflow](#2-app-startup-workflow)
3. [Authentication & Security Flow](#3-authentication--security-flow)
4. [Main Navigation & Shell](#4-main-navigation--shell)
5. [Feature: Home Dashboard](#5-feature-home-dashboard)
6. [Feature: Transactions (Activity)](#6-feature-transactions-activity)
7. [Feature: Quick Add (Center FAB)](#7-feature-quick-add-center-fab)
8. [Feature: Accounts](#8-feature-accounts)
9. [Feature: Budgets](#9-feature-budgets)
10. [Feature: Analytics](#10-feature-analytics)
11. [Feature: Outings / Groups (Trip Splitting)](#11-feature-outings--groups-trip-splitting)
12. [Feature: Friends](#12-feature-friends)
13. [Feature: Investments](#13-feature-investments)
14. [Feature: Wealth](#14-feature-wealth)
15. [Feature: Notifications History](#15-feature-notifications-history)
16. [Feature: Settings (More Tab)](#16-feature-settings-more-tab)
17. [Feature: SMS Auto-Detection Pipeline](#17-feature-sms-auto-detection-pipeline)
18. [Feature: Merchant Learning & Rules](#18-feature-merchant-learning--rules)
19. [Feature: Privacy Modes](#19-feature-privacy-modes)
20. [Feature: Categories & Purposes](#20-feature-categories--purposes)
21. [Partial / Mock Features](#21-partial--mock-features)
22. [Developer & Debug Tools](#22-developer--debug-tools)
23. [Data Models](#23-data-models)
24. [Hive Storage (Local Database)](#24-hive-storage-local-database)
25. [State Management (Riverpod Providers)](#25-state-management-riverpod-providers)
26. [Cross-Feature Integration Map](#26-cross-feature-integration-map)
27. [Complete Route Reference](#27-complete-route-reference)
28. [Implementation Maturity](#28-implementation-maturity)
29. [Key Source Files Index](#29-key-source-files-index)

---

## 1. Technology Stack

| Layer | Technology |
|-------|------------|
| UI Framework | Flutter (Dart SDK ^3.7.0) |
| State Management | `flutter_riverpod` |
| Navigation | `go_router` |
| Local Storage | `hive` / `hive_flutter` |
| Secure Storage | `flutter_secure_storage` (PIN hash/salt) |
| Biometrics | `local_auth` |
| SMS Reading | `telephony` + native Android broadcast |
| Background Jobs | `workmanager` |
| Notifications | `flutter_local_notifications` + native notification listener |
| Charts | `fl_chart` |
| Contacts | `flutter_contacts` |
| Export (planned) | `csv`, `share_plus` |
| Permissions | `permission_handler` |
| Fonts/Icons | `google_fonts`, `lucide_icons` |

**Theme:** Dark mode is the default and only active theme (`ThemeMode.dark` in `main.dart`). A dark mode toggle exists in Settings but is non-functional.

---

## 2. App Startup Workflow

When the app launches, the following sequence runs before the user sees any screen:

```
App Launch
    │
    ▼
WidgetsFlutterBinding.ensureInitialized()
    │
    ▼
Hive.initFlutter() → Open all Hive boxes (see Section 24)
    │
    ▼
Migrate SMS Hive boxes (legacy → current schema)
    │
    ▼
SmsRuleEngine.init() — load SMS parsing rules
    │
    ▼
SmsTemplateRulesImporter.seedBundledDefaultsIfEmpty()
    │   (loads assets/sms/default_template_rules.json
    │    and assets/sms/bank_sms_templates_v4.json)
    │
    ▼
BankSmsV4Parser.ensureLoaded() — bank SMS template v4 parser
    │
    ▼
migrateLegacyPendingTransactions() — migrate old pending tx format
    │
    ▼
Initialize default settings:
    • auto_detection = true
    • profile_name = ''
    • master debug log settings
    │
    ▼
AutoDetectionNativeSync.syncToNative() — sync SMS toggle to Android
    │
    ▼
Apply portrait lock if disable_rotation setting is ON
    │
    ▼
SmsNotificationService.init() — local notification channel
    │
    ▼
SmsService.init() — native SMS event channel
    │
    ▼
BackgroundSmsScheduler.initialize() — WorkManager 15-min periodic task
    │
    ▼
runApp(ProviderScope → SpentXApp)
    │
    ▼
SpentXApp.initState():
    • Register lifecycle observer (PIN lock on resume)
    • Setup SMS listener
    • Setup notification click handler
    │
    ▼
After 800ms delay:
    • Request SMS permissions
    • Start SmsReceiverService (telephony bridge)
    • PendingVerificationBootstrap.processStartupAndShowIfNeeded()
    │
    ▼
Route to SplashScreen (/)
```

**On app resume from background:**
1. PIN lock screen shown if PIN enabled (with 4-second debounce after unlock)
2. Flush pending SMS queue (`SmsService.flushPendingQueue`)
3. Flush pending notification payloads (`NotificationService.flushPendingPayloads`)
4. Reload transactions from Hive
5. Run `PendingVerificationBootstrap.afterUnlock()` — show pending SMS verification popups

**Key file:** `lib/main.dart`

---

## 3. Authentication & Security Flow

### 3.1 Splash Screen (`/`)

**File:** `lib/features/auth/presentation/splash_screen.dart`

**Workflow:**
1. Animated SpentX logo plays (~2.2 seconds)
2. Read `settings.has_seen_onboarding`
3. Route decision:
   - `has_seen_onboarding = false` → `/onboarding`
   - `has_seen_onboarding = true` + PIN set + lock enabled → `/lock`
   - Otherwise → `/home`

### 3.2 Marketing Onboarding (`/onboarding`)

**File:** `lib/features/auth/presentation/onboarding_screen.dart`

**3-page carousel:**
1. **Track Every Rupee** — automatic SMS/notification detection
2. **Smart Analytics** — spending insights and charts
3. **Private & Secure** — PIN protection and local storage

**User actions:**
- **Skip** → sets `has_seen_onboarding = true`, navigates to `/home`
- **Get Started** (last page) → navigates to `/pin-setup`

### 3.3 PIN Setup (`/pin-setup`)

**File:** `lib/features/auth/presentation/pin_setup_screen.dart`

**Workflow:**
1. User enters 4-digit PIN
2. User confirms PIN (must match)
3. `PinService.setPin()` stores hashed PIN + salt in secure storage
4. Fingerprint/biometric unlock enabled by default
5. Navigate to `/home` (or pop back if changing PIN from Settings)

**Stored keys:** `pin_hash`, `pin_salt`, `has_pin`, `lock_screen_enabled`, `fingerprint_enabled`

### 3.4 Lock Screen (`/lock`)

**File:** `lib/features/auth/presentation/lock_screen.dart`

**Workflow:**
1. On open: auto-prompt biometrics if available and `fingerprint_enabled = true`
2. User enters PIN via numpad OR uses biometric
3. On success: set `PinService.lastUnlockedAt`, navigate to `redirectTo` (default `/home`)
4. After unlock: pending SMS verification queue is drained

**App-level auto-lock:**
- Triggered in `SpentXApp.didChangeAppLifecycleState` on `resumed`
- Skips lock for routes: `/`, `/lock`, `/splash`, `/onboarding`
- Requires PIN if `has_pin && lock_screen_enabled`
- 4-second debounce after last unlock to prevent double-prompt loops

### 3.5 First-Time Account Setup Modal

**File:** `lib/features/auth/presentation/widgets/onboarding/onboarding_modal.dart`

**Triggered:** First visit to Home when `userStateProvider.isFirstTimeUser = true`

**Steps:**
1. **Account count** — how many bank/cash accounts to track
2. **Account forms** — name, type (Cash/Bank), last 4 digits, opening balance
3. **Purpose types** — Personal, Family, Business, etc.
4. **Summary** → `userStateProvider.completeOnboarding()`

**Stored in:** `settings.onboardingAccounts`, `settings.purposeTypes`, `settings.isFirstTimeUser`

---

## 4. Main Navigation & Shell

**File:** `lib/features/home/presentation/main_wrapper.dart`  
**Route:** `/home`

### Bottom Navigation Bar

| Tab Index | Label | Icon | Screen |
|-----------|-------|------|--------|
| 0 | Home | `home` | `HomeScreen` |
| 1 | Activity | `receipt` | `TransactionsScreen` |
| — | **+ (FAB)** | — | Quick Add bottom sheet |
| 2 | Analytics | `pieChart` | `AnalyticsScreen` |
| 4 | More | `settings` | `SettingsScreen` |

> **Note:** `AccountsScreen` exists in the IndexedStack at index 3 but has no bottom nav tab. Accounts are accessed via Home quick actions or `/accounts` route.

### Center FAB — Quick Add

Tapping the center `+` button opens `_QuickAddSheet` with two options:
- **Expense** — debit transaction form
- **Income** — credit transaction form

### Startup Side Effects (MainWrapper)

On first frame after mount:
1. `outingProvider.expireEndedOutings()` — auto-close past trips
2. First-time notification listener permission prompt
3. `PendingVerificationBootstrap.processStartupAndShowIfNeeded()` — show SMS verify popups

On app resume:
1. Reload transactions from Hive
2. Drain pending verification queue

### Settlement Feedback

Listens to `settlementFeedbackProvider` — shows green snackbar on Home when friend repayments are auto-matched.

---

## 5. Feature: Home Dashboard

**File:** `lib/features/home/presentation/home_screen.dart`

### What It Shows

| Section | Content |
|---------|---------|
| Header | Profile greeting, notification bell (unread badge) |
| Net Worth Card | Total balance across all accounts (tap → `/accounts`) |
| Monthly Flow | Income vs Spent chips for current month |
| Quick Actions | Outings, Wealth, Transfer, Budgets |
| Account Summary | Mini-cards per account OR purpose spending breakdown |
| Recent Activity | Latest transactions + outing summary rows |
| SMS Pending Banner | Shown when detection queue has unverified items |
| Active Trip Banner | Shown when an outing is in progress |

### User Workflows

**Normal mode:**
1. View net worth and monthly income/spent
2. Tap net worth card → Accounts screen
3. Tap quick action chips → respective feature screens
4. Tap recent transaction → transaction detail
5. Tap bell icon → Notifications history

**Pending SMS banner workflow:**
1. Banner appears: "X transactions need verification"
2. Tap banner → `PendingVerificationPresenter.processQueueIfNeeded()`
3. Detection popup opens for each pending SMS (oldest first)
4. Confirm or Ignore each transaction

**Outing Privacy mode** (when active trip + privacy ON):
- Hides net worth and non-trip balances
- Shows trip-only spend card with share/pending stats
- Activity list scoped to trip transactions only

**First-time setup:**
- `OnboardingModal` appears automatically for new users

### Key Providers
- `transactionProvider`, `netWorthProvider`, `outingProvider`
- `effectivePrivateModeProvider`, `isOutingPrivacyActiveProvider`
- `detectionQueueProvider`, `hasUnreadNotificationsProvider`

---

## 6. Feature: Transactions (Activity)

**File:** `lib/features/transactions/presentation/transactions_screen.dart`  
**Route:** Tab index 1 (also `/activity`)

### What It Does

Full chronological ledger of all income and expense transactions with filtering, search, and grouping.

### User Workflow

1. **View transactions** grouped by Today / Yesterday / date
2. **Filter** by purpose, category, date range (filter chips at top)
3. **Search** via in-app `TransactionSearchDelegate` (search icon in app bar)
4. **Outing expenses** appear as grouped outing summary rows
5. **Tap a row:**
   - Regular transaction → `/transaction/:id`
   - Outing summary row → `/outing-detail/:outingId`
   - Trip expense row → `/outing-expense/:outingId/:expenseId`

### Transaction Detail Screen

**File:** `lib/features/transactions/presentation/transaction_detail_screen.dart`  
**Routes:** `/transaction/:id`, `/outing-expense/:outingId/:expenseId`

**Actions available:**
- View all transaction fields (amount, merchant, category, account, purpose, SMS metadata)
- Edit transaction (opens `EditTransactionSheet`)
- Link/unlink from active outing
- Edit trip expense splits (who paid, split type)
- Delete transaction (syncs with outing if linked)
- Merchant rule learning on save

### Privacy Mode

When outing privacy is active, only trip-scoped transactions and manual trip expenses are shown.

---

## 7. Feature: Quick Add (Center FAB)

**File:** `lib/features/home/presentation/main_wrapper.dart` (`_QuickAddSheet`, `_ExpenseForm`, `_IncomeForm`)

### Expense Form Fields

| Field | Required | Notes |
|-------|----------|-------|
| Amount | Yes | ₹ amount |
| Merchant | Yes | Payee name |
| Category | Yes | From category selector |
| Account | Yes | Bank/Cash account |
| Purpose | Optional | Personal, Family, etc. |
| UPI ID | Optional | For merchant learning |
| Reference ID | Optional | UTR/txn ref |
| Note | Optional | Free-text purpose |

### Income Form Fields

Same as expense but `isExpense = false`.

### On Save

1. `transactionProvider.addTransaction()` — writes to Hive `transactions` box
2. `merchantProvider.learnRule()` — if UPI/raw identifier provided, saves merchant rule
3. `BudgetAlertService.checkAfterExpense()` — triggers budget alerts if applicable
4. Outing auto-link if active trip + auto-mode + date in range
5. Friend repayment matcher runs on credits

---

## 8. Feature: Accounts

**Files:**
- `lib/features/accounts/presentation/accounts_screen.dart` (`/accounts`)
- `lib/features/accounts/presentation/account_detail_screen.dart` (`/account-detail/:name`)

### Accounts Screen Workflow

1. **Hero card** — total net worth (respects private mode masking)
2. **Add Funds** — credit income to a selected account
3. **Transfer** — opens `TransferBottomSheet` for account-to-account transfer
4. **Per-account cards** — name, type, balance, last 4 digits
5. Tap account card → Account Detail screen

### Balance Calculation

```
Account Balance = openingBalance + sum(transactions for that account)
  where expenses subtract and income/transfer-in adds
```

### Account Detail Workflow

1. View account-specific transaction history
2. See running balance
3. Tap transaction → `/transaction/:id`

### Account Data Source

Accounts are stored in `settings.onboardingAccounts` via `userStateProvider`. They are configured during first-time setup or via Settings → Account Configuration.

---

## 9. Feature: Budgets

**File:** `lib/features/budgets/presentation/budgets_screen.dart`  
**Route:** `/budgets` (from Home quick action)

### What It Does

Monthly category-based spending limits with visual progress bars and threshold alerts.

### User Workflow

1. **View overview** — total monthly spent, total limit, remaining
2. **Add budget** — select category, set monthly limit, toggle 80%/100% alert
3. **Per-category cards** — spent vs limit with color-coded progress bar
4. **Bell icon** → `/notifications` (budget alert history)

### Alert Logic

**File:** `lib/core/services/budget_alert_service.dart`

When a new expense is added:
1. Check if category has an active budget
2. Calculate current month spend for that category
3. If spend crosses 80% or 100% threshold → write alert to `notification_history`
4. Alert types: `budget_80`, `budget_100`

### Storage

Hive box: `budgets`, key: `list`  
Provider: `budgetProvider`, `budgetSpendInfosProvider`

---

## 10. Feature: Analytics

**File:** `lib/features/analytics/presentation/analytics_screen.dart`  
**Route:** Bottom nav tab index 2

### What It Does

Visual spending and income analytics using `fl_chart` pie and bar charts.

### User Workflow

1. **Filter bar** — purpose filter + time range (Day / Week / Month / Year)
2. **Hero stats** — Income, Spent, Savings for selected period
3. **Category pie chart** — spending breakdown by category
4. **Bar trend chart** — daily/weekly spending over time
5. **Top merchants** — highest spending merchants list

### Outing Privacy

When outing privacy is active, analytics are scoped to the active trip only.

### Data Sources

- `transactionProvider` — all ledger transactions
- `outingProvider` — manual outing expenses included in spend totals

---

## 11. Feature: Outings / Groups (Trip Splitting)

**Files:**
- `lib/features/groups/presentation/groups_screen.dart` (`/outings`)
- `lib/features/groups/presentation/group_detail_screen.dart` (`/outing-detail/:id`)
- `lib/core/providers/outing_provider.dart`

### What It Does

Track shared trip expenses, split costs among friends, record repayments, and generate trip statements.

### Outing Model

```
Outing
├── id, title, startDate, endDate
├── members: List<OutingMember> (name, upiId)
├── expenses: List<OutingExpense>
│   ├── manual (cash) or linked (transactionId)
│   ├── paidBy: member name
│   ├── splitType: solo | equally
│   └── amount, merchant, category, date
├── settlementPayments: List<SettlementPayment>
│   ├── fromMember, toMember, amount, date
│   └── partial repayments supported
├── isActive: bool
├── autoAddMode: bool (auto-link new expenses)
└── privacyMode: bool
```

### Groups List Workflow (`/outings`)

1. **Active trip banner** — if a trip is in progress, shows at top
2. **Completed trips list** — historical trips with total spend
3. **FAB "New Trip"** — opens `CreateOutingSheet` (only if no active trip)
4. Tap trip card → `/outing-detail/:id`

### Create Trip Workflow

1. Enter trip title
2. Set start and end dates
3. Add members (from friends list or manual entry)
4. Enable/disable auto-add mode
5. Save → trip becomes active

### Group Detail Workflow (`/outing-detail/:id`)

1. **Trip stats** — total spend, your share, pending return
2. **Charts** — spending by category, by member
3. **Bank-detected expenses** — SMS transactions auto-linked to trip
4. **Manual cash expenses** — manually added trip expenses
5. **Add expense** → `AddOutingExpenseSheet`
6. **Verify pending SMS** — link unverified detections to trip
7. **Unlink expenses** — remove transaction from trip
8. **Settlement tracking** — record friend repayments (cash/UPI, partial OK)
9. **End trip** — deactivates trip, stops auto-add
10. **Edit trip settings** — dates, members, auto-mode

### Auto-Linking Logic

When `transactionProvider.addTransaction()` runs and an active outing exists with `autoAddMode = true`:
- Expenses within trip date range → `outingId` set + `isAutoLinked = true`
- Credits during trip → linked if `FriendRepaymentMatcher` matches friend UPI/name

### Trip Statement

**File:** `lib/features/groups/presentation/widgets/outing_statement_section.dart`

Shows per-member:
- Total paid
- Share owed
- Pending return (money friends still owe you)
- Settled amount

### Outing Privacy Mode

When enabled during an active trip:
- Home and Activity screens show trip-only view
- Net worth and non-trip activity hidden
- Unlock requires PIN or profile name via `PrivacyUnlockDialog`

### Storage

Hive box: `outings`  
Providers: `outingProvider`, `activeOutingProvider`, `outingPrivacyModeProvider`, `isOutingPrivacyActiveProvider`

---

## 12. Feature: Friends

**Files:**
- `lib/features/friends/presentation/friends_screen.dart` (`/friends`)
- `lib/features/friends/presentation/friend_picker_screen.dart`
- `lib/core/services/friend_repayment_matcher.dart`

### What It Does

Manage a directory of people you split expenses with, link their UPI IDs for auto-repayment detection, and settle outing balances.

### User Workflow

1. **Add friend manually** — name, optional phone, optional UPI ID
2. **Import from contacts** — uses `flutter_contacts` to pick from device contacts
3. **Friend detail** — view UPI IDs, linked transactions, settle balances
4. **Friend picker mode** — used when adding members to outings or expense splits

### Friend Repayment Automation

**File:** `lib/core/services/friend_repayment_matcher.dart`

When a credit transaction (income SMS) is detected:
1. Match UPI ID or merchant name against friend UPI mappings
2. If match found → auto-settle outing split for that friend
3. Feedback shown via `settlementFeedbackProvider` snackbar on Home

### Storage

Hive box: `friends`  
Providers: `friendsProvider`, `manualFriendsProvider`, `friendUpiProvider`

---

## 13. Feature: Investments

**File:** `lib/features/investments/presentation/investments_screen.dart`  
**Route:** `/investments` (from Wealth screen)

### What It Does

Manual portfolio tracking for mutual funds, FDs, stocks, crypto, and other holdings. No live market data integration.

### User Workflow

1. **View portfolio** — total invested + breakdown by investment type
2. **Add holding** — name, amount invested, growth %, type (MF/FD/Stock/Crypto/Other), optional link URL
3. **Edit/delete holdings**
4. **Detected investments section** — keyword-matched transactions (Groww, Zerodha, etc.) from SMS

### Investment Types

Mutual Fund, Fixed Deposit, Stocks, Crypto, Other

### Storage

Hive box: `investments`  
Provider: `investmentProvider`

---

## 14. Feature: Wealth

**File:** `lib/features/wealth/presentation/wealth_screen.dart`  
**Route:** `/wealth` (from Home quick action)

### What It Does

High-level net worth overview combining cash, bank balances, and investments, plus wealth goals.

### User Workflow

1. View net worth breakdown (cash + bank + investments)
2. Add wealth goals (target amount, deadline) — **in-memory only, not persisted**
3. Tap investments section → `/investments`

### Implementation Note

Wealth screen uses simplified/mock base balances adjusted by transactions. For accurate balances, use the Accounts screen. Wealth goals are not saved to Hive.

---

## 15. Feature: Notifications History

**File:** `lib/features/notifications/presentation/notifications_screen.dart`  
**Route:** `/notifications`

### What It Does

In-app log of system events (not the Android notification tray). Tracks SMS auto-adds, pending verifications, and budget alerts.

### Notification Record Types

| Type | Description |
|------|-------------|
| `sms_auto` | Transaction auto-added from SMS detection |
| `sms_pending` | SMS detected but needs user verification |
| `budget` | Budget threshold alert (80% or 100%) |

### User Workflow

1. View chronological list with unread highlighting
2. Tap "Mark all read" to clear unread state
3. Unread badge shown on Home bell icon

### Storage

Hive box: `notification_history`  
Service: `lib/core/services/notification_history_service.dart`  
Provider: `hasUnreadNotificationsProvider`

---

## 16. Feature: Settings (More Tab)

**File:** `lib/features/settings/presentation/settings_screen.dart`  
**Route:** Bottom nav tab index 4

### Settings Sections

#### Help
| Item | Route | Description |
|------|-------|-------------|
| App Guide | `/app-guide` | In-app how-to guide |

#### Configuration
| Item | Description |
|------|-------------|
| Account Configuration | Opens `PremiumSettingsScreen` — edit accounts, purposes, profile image |
| Profile Name | Editable display name on profile card |

#### Features
| Item | Route | Description |
|------|-------|-------------|
| Manage Outing | `/outings` | Trip/group management |
| Outing Privacy | Toggle | Hide balances during active trip |
| Manage Friends | `/friends` | Friend directory |
| Manage Merchants | `/merchant-names` | UPI → name/category mappings |

#### Developer
| Item | Route | Description |
|------|-------|-------------|
| SMS Rules Storage | `/sms-rules-storage` | Inspect bundled + Hive JSON rules |
| Developer Options | `/developer-options` | SMS lab, debug tools, health check |

#### Preferences
| Item | Description |
|------|-------------|
| Private Mode | Mask amounts with `*****` on Home & Accounts |
| Notification History | `/notifications` |
| Auto SMS Detection | Toggle SMS auto-detection on/off |
| Dark Mode | Non-functional (app always dark) |

#### Security
| Item | Description |
|------|-------------|
| Set/Change PIN | `/pin-setup` |
| Lock Screen | Toggle PIN required on app open |
| Fingerprint | Toggle biometric unlock |
| Reset PIN | Clear PIN (requires current PIN) |

#### Danger Zone
| Item | Description |
|------|-------------|
| Reset App Data | Wipes all Hive data; requires PIN or profile name confirmation via `AppResetService` |

### Auto Detection Toggle Workflow

**ON:**
1. Request SMS read permissions
2. Start `SmsReceiverService`
3. Flush pending SMS/notification queues
4. Sync to native via `AutoDetectionNativeSync`

**OFF:**
1. Flush/discard pending payloads
2. Sync OFF state to native

---

## 17. Feature: SMS Auto-Detection Pipeline

This is the core feature of SpentX. It automatically reads bank/UPI SMS and notification alerts, parses transaction details, and either auto-adds them to the ledger or queues them for user verification.

### Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│                   INBOUND SOURCES                        │
├──────────────┬──────────────┬──────────────┬───────────┤
│ Native SMS   │ Telephony    │ Notification │ WorkManager│
│ Broadcast    │ Receiver     │ Listener     │ Flush      │
└──────┬───────┴──────┬───────┴──────┬───────┴─────┬─────┘
       │              │              │             │
       └──────────────┴──────────────┴─────────────┘
                              │
                              ▼
              SmsDetectionPipeline.processInbound()
              or processNotificationPayload()
                              │
                              ▼
              ┌───────────────────────────────┐
              │  auto_detection enabled?      │
              │  (settings.auto_detection)  │
              └───────────┬───────────────────┘
                          │ YES
                          ▼
              ┌───────────────────────────────┐
              │  Dedupe check (recent hashes) │
              └───────────┬───────────────────┘
                          │
                          ▼
              ┌───────────────────────────────┐
              │  SmsRuleEngine.parse()        │
              │  + block rules check          │
              │  + BankSmsV4Parser            │
              └───────────┬───────────────────┘
                          │
                          ▼
              ┌───────────────────────────────┐
              │  AutoRuleEngine               │
              │  (foreground or background)   │
              └───────────┬───────────────────┘
                          │
              ┌───────────┴───────────────────┐
              │                               │
              ▼                               ▼
    ┌─────────────────┐           ┌─────────────────────┐
    │ KNOWN MERCHANT  │           │ UNKNOWN MERCHANT    │
    │ (rule match or  │           │ (no rule match)     │
    │  ATM pattern)   │           │                     │
    └────────┬────────┘           └──────────┬──────────┘
             │                               │
             ▼                               ▼
    Auto-add Transaction          Store in detected_sms_box
    + notification_history        + add to pending_detections queue
    (type: sms_auto)              + show system notification
                                  (type: sms_pending)
                                             │
                                             ▼
                              PendingVerificationPresenter
                              → DetectionPopup (on app open/resume)
```

### Detection Sources

| Source | Label | Description |
|--------|-------|-------------|
| `smsBroadcast` | `native_sms` | Android SMS broadcast receiver |
| `telephony` | `telephony` | Telephony plugin inbox read |
| `notification` | `notification` | Native notification listener |
| `pendingFlush` | `pending_flush` | Queued SMS flushed on app resume |
| `lab` | `lab` | SMS Detection Lab (manual test) |
| `debug` | `debug` | Developer debug injection |

### Key Pipeline Files

| File | Role |
|------|------|
| `lib/features/sms/sms_service.dart` | EventChannel SMS listener, inbox read, permissions |
| `lib/features/sms/detected/sms_detection_pipeline.dart` | Single entry point, dedupe, auto-detection gate |
| `lib/features/sms/detected/auto_rule_engine.dart` | Merchant match, auto-add vs pending |
| `lib/features/sms/rules/engine/sms_rule_engine.dart` | Parse + block rules |
| `lib/features/sms/v4/bank_sms_v4_parser.dart` | Bundled bank templates v4 |
| `lib/features/background_detection/notification_service.dart` | Native notification payloads |
| `lib/features/sms/background/background_sms_scheduler.dart` | WorkManager 15-min + immediate tasks |
| `lib/features/transactions/data/sms_receiver_service.dart` | Telephony receiver bridge |

### Parsing Assets

| Asset | Purpose |
|-------|---------|
| `assets/sms/default_template_rules.json` | Default SMS template rules |
| `assets/sms/bank_sms_templates_v4.json` | Bank-specific SMS templates v4 |
| `assets/sms/bank_sms_templates_v4_report.json` | Template coverage report |

Seeded on startup via `SmsTemplateRulesImporter.seedBundledDefaultsIfEmpty()`.

### Auto-Add Conditions

A transaction is auto-added (no user verification needed) when:
1. **Known merchant rule** — UPI ID or merchant name matches a saved rule in `merchant_rules_box`
2. **Learned ATM pattern** — SMS matches ATM withdrawal pattern (`sms_atm_helper.dart`)
3. **Duplicate detection** — same `referenceId` or same amount+date already exists in ledger

### Pending Verification Workflow

```
Unknown payee SMS detected
        │
        ▼
Stored in detected_sms_box (Hive)
        │
        ▼
ID added to pending_detections queue
        │
        ▼
System notification shown
(tap stores target via SmsPendingService)
        │
        ▼
On startup / resume / unlock:
PendingVerificationBootstrap runs
        │
        ▼
PendingVerificationPresenter shows
DetectionPopup sequentially (oldest first)
        │
        ├── CONFIRM → real transaction added to ledger
        │              + optional merchant rule saved
        │              + optional outing link
        │              + optional friend repayment link
        │
        └── IGNORE → stays in ignored_detections
                     or remains pending
```

### Detection Popup

**File:** `lib/features/sms/detected/detection_popup.dart`

**Fields user can edit before confirming:**
- Amount
- Merchant name
- Category
- Purpose
- Account
- Link to active outing
- Link as friend repayment
- Save merchant rule for future auto-detect

### Background Processing

**WorkManager** runs every 15 minutes (`BackgroundSmsScheduler`) to:
1. Read new SMS from inbox since last check
2. Process notification payloads queued while app was closed
3. Auto-add known merchants even when app is not open

On app pause/inactive: `BackgroundSmsScheduler.enqueueImmediate()` triggers an immediate background task.

### Notification Listener Path

SpentX can read bank alerts from the Android notification tray (no SMS permission required for this path):
1. User grants notification listener access on first Home visit
2. Native service captures bank app notifications
3. Payload forwarded to `SmsDetectionPipeline.processNotificationPayload()`
4. Same parse → auto-add or pending flow as SMS path

---

## 18. Feature: Merchant Learning & Rules

### Merchant Rules

**File:** `lib/core/models/merchant_rule.dart`  
**Screen:** `lib/features/settings/presentation/merchant_names_screen.dart` (`/merchant-names`)

Maps a UPI ID or normalized payee key to:
- Display name
- Category
- Purpose
- Transaction type (debit/credit)

**Learning triggers:**
- User confirms a pending SMS detection and checks "Save rule"
- User manually adds a transaction with UPI ID
- `merchantProvider.learnRule()` called on transaction save

### SMS Template Rules

**Files:** `lib/features/sms/rules/`  
**Screen:** `lib/features/sms/rules/presentation/sms_rule_manager_screen.dart`

Custom parsers for bank SMS formats:
- **Template rules** — regex patterns for amount, payee, date extraction
- **Block rules** — SMS patterns to ignore (promotional, OTP, etc.)
- **Detection rules** — custom detection logic

**Hive boxes:** `sms_template_rules_box`, `block_rules_box`, `detection_rules_box`, `ignored_sms_box`, `processed_sms_box`

### Merchant Alias Provider

**File:** `lib/core/providers/merchant_alias_provider.dart`  
Hive box: `merchant_aliases` — alternative name mappings for merchants.

---

## 19. Feature: Privacy Modes

### Private Mode

**Provider:** `privateModeProvider`  
**Toggle:** Settings → Private Mode

Masks all monetary amounts with `*****` on Home and Accounts screens. Automatically disabled when outing privacy is active.

### Outing Privacy Mode

**Provider:** `outingPrivacyModeProvider`  
**Toggle:** Settings → Outing Privacy (only available during active trip)

When enabled:
- Home shows trip-only spend view (no net worth)
- Activity shows only trip transactions
- Analytics scoped to trip
- Unlock requires PIN or profile name via `PrivacyUnlockDialog`

**Effective provider:** `effectivePrivateModeProvider` — combines both modes.

---

## 20. Feature: Categories & Purposes

### Categories

**Provider:** `categoryProvider`  
**Hive box:** `categories`

Default categories: Food, Transport, Shopping, Entertainment, Bills, Health, Education, Travel, Other.

Users can add custom categories. Used in:
- Transaction forms
- Budget setup
- Analytics pie chart
- SMS detection popup

### Purposes

**Provider:** `userStateProvider`  
**Stored in:** `settings.purposeTypes`

Default purposes: Personal, Family, Business, Home.

Configured during onboarding. Used to:
- Tag transactions by spending purpose
- Filter Activity and Analytics
- Scope spending summaries on Home

---

## 21. Partial / Mock Features

These screens exist in the router but have limited or placeholder implementation:

| Feature | Route | Status | Notes |
|---------|-------|--------|-------|
| **Recurring** | `/recurring` | UI mock | Hardcoded Rent/Netflix/Spotify; FAB has no action |
| **Calendar** | `/calendar` | UI mock | Static April 2026 grid with hardcoded daily stats |
| **Search** | `/search` | Partial | Standalone screen shows mock results; real search works in Activity via `TransactionSearchDelegate` |
| **Export** | `/export` | UI only | CSV/JSON/PDF/Backup tiles have empty `onTap` handlers |
| **Wealth Goals** | `/wealth` | In-memory | Goals not persisted to Hive |
| **Dark Mode Toggle** | Settings | Non-functional | App theme locked to `ThemeMode.dark` |
| **SMS Activity** | `/sms-activity` | Exists | `SmartSmsListScreen` — no main nav link |

---

## 22. Developer & Debug Tools

**Access:** Settings → Developer Options (`/developer-options`)

### Available Tools

| Tool | Route | Purpose |
|------|-------|---------|
| Master Debug Logging | — | Structured internal logs with retention (500/1000/5000 entries) |
| Debug Toasts | — | Real-time on-screen debug messages |
| Master Debug Log Screen | `/master-debug-log` | Search, filter, export debug logs |
| System Health Check | — | Validates Hive, SMS pipeline, notifications, merchants, queue, outings |
| SMS Detection Rules | — | `SmsRuleManagerScreen` — train/block custom rules |
| SMS Rules Storage | `/sms-rules-storage` | Inspect bundled + Hive JSON rules |
| Detected SMS | `/detected-sms` | View pending & ignored SMS detections |
| SMS Detection Lab | `/sms-detection-lab` | Paste SMS text, simulate detection with delays |
| Real-Time SMS Test | `/real-sms-test` | Read device SMS inbox → live pipeline test |
| Clear Transactions | — | Bulk delete by type (all, auto-detected, manual, etc.) |
| Disable Rotation | — | Lock app to portrait orientation |
| Copy Master App Prompt | — | Export full app spec for AI/developer use |

### SMS Detection Lab Workflow

1. Paste a sample bank SMS message
2. Optionally set sender ID and received timestamp
3. Tap "Simulate" — runs through full `SmsDetectionPipeline`
4. View parse result, auto-add decision, and debug log
5. Test foreground vs background behavior with delay simulation

### CLI Test Tools (`tool/`)

| Script | Purpose |
|--------|---------|
| `test_background_pending_flow.dart` | Test background pending verification flow |
| `test_hdfc_card_sms.dart` | Test HDFC card SMS parsing |
| `test_payee.dart` | Test payee extraction logic |

---

## 23. Data Models

### Transaction

**File:** `lib/models/transaction.dart`

| Field | Type | Description |
|-------|------|-------------|
| `id` | String (UUID) | Unique identifier |
| `merchant` | String | Payee/merchant name |
| `category` | String | Spending category |
| `account` | String | Bank/Cash account name |
| `time` | String | Display time string |
| `amount` | double | Transaction amount in ₹ |
| `isExpense` | bool | true = debit, false = credit |
| `isAutoDetected` | bool | Added via SMS pipeline |
| `isGroup` | bool | Group expense flag |
| `groupCount` | int | Number of people in group |
| `paymentType` | String | 'Cash' or 'Online' |
| `date` | DateTime | Transaction date |
| `isTransfer` | bool | Account-to-account transfer |
| `outingId` | String? | Linked trip ID |
| `isAutoLinked` | bool | Auto-linked to trip by date range |
| `rawIdentifier` | String? | UPI ID for merchant learning |
| `purpose` | String? | Personal, Family, etc. |
| `bankName` | String | Bank name from SMS |
| `accountLast4` | String | Last 4 digits from SMS |
| `referenceId` | String | UTR/transaction reference |
| `upiId` | String | UPI VPA from SMS |
| `rawMessage` | String | Original SMS text |
| `note` | String | Free-text note |
| `isPendingVerification` | bool | Unknown merchant during outing |
| `isMerchantMapped` | bool | Merchant rule existed when added |

### Account

**File:** `lib/models/account_model.dart`

| Field | Type | Description |
|-------|------|-------------|
| `name` | String | Account display name |
| `type` | String | 'Cash' or 'Bank' |
| `last4` | String | Last 4 digits |
| `openingBalance` | double | Starting balance |
| `imagePath` | String? | Optional account image |

### Merchant Rule

**File:** `lib/core/models/merchant_rule.dart`

| Field | Type | Description |
|-------|------|-------------|
| `key` | String | Normalized UPI ID or payee key |
| `displayName` | String | Human-readable merchant name |
| `category` | String | Default category |
| `purpose` | String | Default purpose |
| `transactionType` | String | 'debit' or 'credit' |

### Outing (inline in outing_provider.dart)

| Model | Key Fields |
|-------|-----------|
| `Outing` | id, title, startDate, endDate, members, expenses, isActive, autoAddMode |
| `OutingMember` | name, upiId |
| `OutingExpense` | id, amount, merchant, paidBy, splitType, transactionId, date |
| `SettlementPayment` | fromMember, toMember, amount, date |

### Pending Transaction

**Files:** `lib/models/pending_transaction.dart`, `lib/features/sms/detected/pending_model.dart`

Intermediate SMS detection record before user verification. Stored in `detected_sms_box`.

---

## 24. Hive Storage (Local Database)

All data is stored locally on device using Hive. No cloud sync.

| Hive Box | Key(s) | Contents |
|----------|--------|----------|
| `settings` | various | Profile, PIN flags, auto_detection, privacy, debug, accounts, purposes |
| `transactions` | `list` | All ledger transactions (List of JSON maps) |
| `outings` | outing IDs | Trip/group data |
| `friends` | friend IDs | Friend directory |
| `budgets` | `list` | Category budget limits |
| `investments` | `list` | Investment holdings |
| `categories` | category names | Custom expense/income categories |
| `merchant_aliases` | alias keys | Merchant alias mappings |
| `merchant_rules_box` | UPI keys | Learned merchant rules |
| `detected_sms_box` | detection IDs | Pending SMS verifications |
| `pending_detections` | queue | Transaction IDs awaiting verify popup |
| `ignored_detections` | IDs | User-ignored SMS detections |
| `notification_history` | record IDs | In-app notification log |
| `pending_verification_history` | IDs | SMS pending verification history |
| `sms_template_rules_box` | rule IDs | Custom SMS template rules |
| `block_rules_box` | rule IDs | SMS block/ignore rules |
| `detection_rules_box` | rule IDs | Custom detection rules |
| `ignored_sms_box` | hashes | Ignored SMS hashes |
| `processed_sms_box` | hashes | Already-processed SMS hashes |

**Opened in:** `lib/main.dart` (lines 38–55)

---

## 25. State Management (Riverpod Providers)

| Provider | File | Responsibility |
|----------|------|----------------|
| `transactionProvider` | `transaction_provider.dart` | Ledger CRUD, net worth, outing sync, budget alerts, friend settlement |
| `userStateProvider` | `user_state_provider.dart` | Profile, accounts, purposes, first-time flag |
| `outingProvider` | `outing_provider.dart` | Trips, expenses, settlements, auto-expire |
| `activeOutingProvider` | `outing_provider.dart` | Currently active trip |
| `budgetProvider` | `budget_provider.dart` | Category budgets + spend calculation |
| `merchantProvider` | `merchant_provider.dart` | Merchant rule CRUD |
| `investmentProvider` | `investment_provider.dart` | Investment holdings |
| `friendsProvider` | `friends_provider.dart` | Friend list |
| `manualFriendsProvider` | `friends_provider.dart` | Manually added friends |
| `friendUpiProvider` | `friend_upi_provider.dart` | Friend UPI ID mappings |
| `categoryProvider` | `category_provider.dart` | Custom categories |
| `merchantAliasProvider` | `merchant_alias_provider.dart` | Merchant alias mappings |
| `privateModeProvider` | `private_mode_provider.dart` | Mask amounts on home |
| `outingPrivacyModeProvider` | `outing_privacy_provider.dart` | Trip privacy overlay |
| `detectionQueueProvider` | `detection_queue.dart` | Pending SMS ID queue |
| `settlementFeedbackProvider` | `settlement_feedback_provider.dart` | Friend settlement snackbars |
| `contactsProvider` | `contacts_provider.dart` | Device contacts for friend import |

### Derived Providers

| Provider | Computes |
|----------|----------|
| `netWorthProvider` | Total balance across all accounts |
| `budgetSpendInfosProvider` | Per-category spend vs limit |
| `effectivePrivateModeProvider` | Combined private + outing privacy state |
| `hasUnreadNotificationsProvider` | Unread notification count |
| `isOutingPrivacyActiveProvider` | Whether outing privacy is currently active |

---

## 26. Cross-Feature Integration Map

```
┌──────────────────────────────────────────────────────────────────┐
│                     SMS DETECTION PIPELINE                        │
│  (SMS Broadcast / Notification Listener / WorkManager)           │
└────────────────────────────┬─────────────────────────────────────┘
                             │
              ┌──────────────┼──────────────┐
              │              │              │
              ▼              ▼              ▼
     Auto-add to       Pending         Merchant Rule
     Transaction       Queue           Learning
     Ledger            (verify popup)
              │              │              │
              ▼              ▼              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      TRANSACTION LEDGER                          │
└──┬──────────┬──────────┬──────────┬──────────┬───────────────┘
   │          │          │          │          │
   ▼          ▼          ▼          ▼          ▼
Accounts   Budgets   Analytics  Friends    Outings
(balances) (alerts)  (charts)   (repay     (auto-link
                                 match)     in trip dates)

┌─────────────────────────────────────────────────────────────────┐
│                         OUTINGS                                  │
│  Active Trip → Auto-link expenses → Privacy Mode → Home/Activity │
│              → Friend splits → Settlement tracking               │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                      PIN / LOCK SCREEN                           │
│  Resume from background → Lock → Unlock → Drain pending SMS      │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                   NOTIFICATION TAP                               │
│  System notification → NotificationClickHandler → DetectionPopup   │
└─────────────────────────────────────────────────────────────────┘
```

---

## 27. Complete Route Reference

| Route | Screen | Accessed From |
|-------|--------|---------------|
| `/` | SplashScreen | App launch |
| `/onboarding` | OnboardingScreen | Splash (first launch) |
| `/pin-setup` | PinSetupScreen | Onboarding / Settings |
| `/lock` | LockScreen | Splash / app resume |
| `/home` | MainWrapper | Auth success |
| `/activity` | TransactionsScreen | Router (also bottom nav tab 1) |
| `/investments` | InvestmentsScreen | Wealth screen |
| `/wealth` | WealthScreen | Home quick action |
| `/outings` | GroupsScreen | Home / Settings |
| `/outing-detail/:id` | GroupDetailScreen | Outings list / banners |
| `/budgets` | BudgetsScreen | Home quick action |
| `/recurring` | RecurringScreen | Router only (no nav link) |
| `/notifications` | NotificationsScreen | Home bell / Settings / Budgets |
| `/search` | SearchScreen | Router only |
| `/calendar` | CalendarScreen | Router only |
| `/export` | ExportScreen | Router only |
| `/accounts` | AccountsScreen | Home net worth card / quick action |
| `/account-detail/:name` | AccountDetailScreen | Accounts list |
| `/transaction/:id` | TransactionDetailScreen | Activity / Home |
| `/outing-expense/:outingId/:expenseId` | TransactionDetailScreen | Activity / Home (trip mode) |
| `/friends` | FriendsScreen | Settings |
| `/merchant-names` | MerchantNamesScreen | Settings |
| `/app-guide` | AppGuideScreen | Settings |
| `/developer-options` | DeveloperOptionsScreen | Settings |
| `/sms-rules-storage` | SmsRulesStorageScreen | Settings / Dev options |
| `/master-debug-log` | MasterDebugLogScreen | Dev options |
| `/sms-detection-lab` | SmsDetectionLabScreen | Dev options |
| `/real-sms-test` | RealSmsTestScreen | Dev options |
| `/sms-activity` | SmartSmsListScreen | Router only |
| `/detected-sms` | DetectedSmsScreen | Dev options |

---

## 28. Implementation Maturity

| Feature Area | Status | Notes |
|--------------|--------|-------|
| SMS auto-detection + verification | ✅ Production-grade | Full pipeline with background, notification, and foreground paths |
| Transactions & ledger | ✅ Fully functional | CRUD, filters, search, detail edit |
| Accounts & balances | ✅ Fully functional | Multi-account, transfers, add funds |
| Budgets & alerts | ✅ Fully functional | Category limits, 80%/100% alerts |
| Outings / trip splitting | ✅ Fully functional | Auto-link, splits, settlements, privacy |
| Friends & repayments | ✅ Fully functional | UPI matching, auto-settlement |
| Analytics | ✅ Fully functional | Charts, filters, top merchants |
| Investments | ✅ Functional | Manual holdings, detected investments |
| Auth / PIN / biometrics | ✅ Fully functional | Setup, lock, resume lock |
| Notifications history | ✅ Functional | SMS and budget event log |
| Merchant learning | ✅ Functional | Auto-learn from confirmations |
| Notification listener | ✅ Functional | Bank alert parsing without SMS permission |
| Background SMS processing | ✅ Functional | WorkManager 15-min + immediate |
| Wealth screen | ⚠️ Partial | Mock base balances; goals not persisted |
| Calendar | ⚠️ UI mock | Static data only |
| Recurring | ⚠️ UI mock | Hardcoded subscriptions |
| Export | ⚠️ UI only | No export logic implemented |
| Standalone Search | ⚠️ Partial | Mock results; real search in Activity |
| Dark mode toggle | ❌ Non-functional | Theme locked to dark |
| Encrypted vault (HiveService) | ❌ Not used | Defined but boxes opened directly |

---

## 29. Key Source Files Index

### Entry & Core
| File | Purpose |
|------|---------|
| `lib/main.dart` | App entry, Hive init, service bootstrap, lifecycle |
| `lib/core/router/app_router.dart` | All route definitions |
| `lib/core/theme/app_theme.dart` | Light/dark theme definitions |
| `lib/core/constants/app_constants.dart` | Spacing, radius, currency constants |

### Features
| Directory | Feature |
|-----------|---------|
| `lib/features/auth/` | Splash, onboarding, PIN, lock screen |
| `lib/features/home/` | MainWrapper, HomeScreen |
| `lib/features/transactions/` | Activity, detail, add/edit sheets |
| `lib/features/accounts/` | Accounts list, account detail |
| `lib/features/budgets/` | Budget management |
| `lib/features/analytics/` | Charts and spending analytics |
| `lib/features/groups/` | Outings/trips, group detail, widgets |
| `lib/features/friends/` | Friends directory, picker |
| `lib/features/investments/` | Portfolio tracking |
| `lib/features/wealth/` | Net worth overview |
| `lib/features/notifications/` | Notification history |
| `lib/features/settings/` | Settings, merchant names, dev options |
| `lib/features/sms/` | Full SMS detection pipeline |
| `lib/features/background_detection/` | Notification service |
| `lib/features/sms_parser/` | SMS parsing utilities |
| `lib/features/recurring/` | Recurring (mock) |
| `lib/features/calendar/` | Calendar (mock) |
| `lib/features/search/` | Search (partial) |
| `lib/features/export/` | Export (mock) |

### Services
| File | Purpose |
|------|---------|
| `lib/core/services/pin_service.dart` | PIN hash, biometric auth |
| `lib/core/services/budget_alert_service.dart` | Budget threshold alerts |
| `lib/core/services/friend_repayment_matcher.dart` | Auto-settle friend repayments |
| `lib/core/services/merchant_rule_service.dart` | Merchant rule CRUD |
| `lib/core/services/app_reset_service.dart` | Wipe all app data |
| `lib/core/services/notification_click_handler.dart` | Handle notification taps |
| `lib/core/services/pending_verification_bootstrap.dart` | Startup pending SMS drain |
| `lib/core/services/auto_detection_native_sync.dart` | Sync SMS toggle to Android |

### Models
| File | Purpose |
|------|---------|
| `lib/models/transaction.dart` | Core transaction model |
| `lib/models/account_model.dart` | Account model |
| `lib/models/merchant.dart` | Merchant model |
| `lib/models/pending_transaction.dart` | Pending SMS detection model |
| `lib/core/models/merchant_rule.dart` | Merchant rule model |

### Providers
| File | Purpose |
|------|---------|
| `lib/core/providers/transaction_provider.dart` | Transaction ledger state |
| `lib/core/providers/outing_provider.dart` | Outing/trip state |
| `lib/core/providers/user_state_provider.dart` | User profile and accounts |
| `lib/core/providers/budget_provider.dart` | Budget state |
| `lib/core/providers/merchant_provider.dart` | Merchant rules state |
| `lib/core/providers/investment_provider.dart` | Investments state |
| `lib/core/providers/friends_provider.dart` | Friends state |

---

*This document reflects the SpentX codebase as of version 1.0.0+1. Generated from full source analysis.*