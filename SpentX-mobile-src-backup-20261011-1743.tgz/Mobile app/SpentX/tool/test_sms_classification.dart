import 'package:spentx/features/sms_parser/sms_classifier.dart';
import 'package:spentx/features/sms_parser/sms_transaction_filters.dart';
import 'package:spentx/features/sms/sms_notification_copy.dart';
import 'dart:io';

void main() {
  stdout.writeln('=== SMS CLASSIFIER & WORKFLOW TEST ===\n');

  final testCases = <String, SmsType>{
    // 1. Financial Transactions ✅
    '₹200 spent at Starbucks.': SmsType.financialTransaction,
    'Rs 450 debited from A/c XX1234 on 27-Jul-26 at Zomato. UPI Ref 6271928371.': SmsType.financialTransaction,
    'Your a/c XX5678 was credited with Rs. 5,000 on 27-Jul-26 by Salary Deposit.': SmsType.financialTransaction,
    'ATM cash withdrawal of Rs 2000 from SBI ATM.': SmsType.financialTransaction,

    // 2. Account Updates ❌
    'UPDATE: Bal in HDFC Bank A/c XX0000 has gone below minimum limit. Yesterday\'s bal: ₹7.04': SmsType.accountUpdate,
    'Low balance warning: Your account balance is below the required minimum limit of Rs 5000.': SmsType.accountUpdate,
    'Your monthly e-statement for A/c XX1234 for June 2026 is now available.': SmsType.accountUpdate,
    'KYC reminder: Please update your KYC for account XX9999 to avoid account restriction.': SmsType.accountUpdate,
    'Your debit card ending 4321 is expiring soon. Re-issue card now.': SmsType.accountUpdate,

    // 3. Promotional SMS ❌
    'Get pre-approved instant loan up to Rs 5 Lakhs at 10.5%. Apply now!': SmsType.promotional,
    'Earn 5x reward points on your next purchase. Claim now!': SmsType.promotional,
    'Flat 20% cashback offer on holiday bookings this weekend.': SmsType.promotional,

    // 4. OTP / Authentication ❌
    '123456 is your OTP for HDFC Bank NetBanking login. Do not share with anyone.': SmsType.otp,
    'Your secret verification code for device registration is 987654.': SmsType.otp,

    // 5. Banking Information ❌
    'NetBanking password changed successfully for your account XX1234.': SmsType.bankingInfo,
    'Beneficiary John Doe added to your account XX5678 successfully.': SmsType.bankingInfo,
    'Mobile number updated successfully for A/c XX4321.': SmsType.bankingInfo,
    'Service request SR987654 has been completed.': SmsType.bankingInfo,
  };

  int passed = 0;
  int failed = 0;

  testCases.forEach((msg, expectedType) {
    final result = SmsClassifier.classify(msg);
    final shouldIgnore = SmsTransactionFilters.shouldIgnore(msg);
    final isTxn = result.isFinancialTransaction;

    final typeOk = result.type == expectedType;
    final ignoreOk = isTxn ? !shouldIgnore : shouldIgnore;

    if (typeOk && ignoreOk) {
      stdout.writeln('✓ PASS: [${result.type.name}] -> "${msg.length > 60 ? '${msg.substring(0, 60)}...' : msg}"');
      passed++;
    } else {
      stdout.writeln('✗ FAIL: Expected [${expectedType.name}] but got [${result.type.name}] (shouldIgnore=$shouldIgnore) -> "$msg"');
      failed++;
    }
  });

  stdout.writeln('\n--- Notification Copy Format Verification ---');

  final existingCopy = SmsNotificationCopy.build(
    type: 'debit',
    amount: 200,
    merchantExists: true,
    merchantTitle: 'Starbucks',
  );
  stdout.writeln('Existing Merchant Notification:\n  Title: "${existingCopy.title}"\n  Body: "${existingCopy.body}"');

  final newCopy = SmsNotificationCopy.build(
    type: 'debit',
    amount: 200,
    merchantExists: false,
    payee: 'Unknown Merchant',
  );
  stdout.writeln('\nNew Merchant Notification:\n  Title: "${newCopy.title}"\n  Body: "${newCopy.body}"');

  final outingCopy = SmsNotificationCopy.build(
    type: 'debit',
    amount: 200,
    merchantExists: false,
    outingTitle: 'Wonderla Trip',
  );
  stdout.writeln('\nActive Outing Notification:\n  Title: "${outingCopy.title}"\n  Body: "${outingCopy.body}"');

  stdout.writeln('\n=== RESULTS: $passed Passed, $failed Failed ===');
  if (failed > 0) {
    throw Exception('$failed tests failed!');
  }
}
