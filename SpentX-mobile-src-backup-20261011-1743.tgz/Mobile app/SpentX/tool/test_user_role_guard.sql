-- Run ONLY in an empty, disposable PostgreSQL database as postgres:
-- psql -v ON_ERROR_STOP=1 -f tool/test_user_role_guard.sql
-- Tests the migration itself; does not require a deployed Supabase instance.
create role authenticated;
create role anon;
create role service_role;
create table public.users (id text primary key, name text, role text not null default 'user');
grant usage on schema public to authenticated, anon, service_role;
grant select, insert, update on public.users to authenticated, anon, service_role;
insert into public.users values ('ordinary', 'Before', 'user'), ('admin', 'Admin', 'admin');
\ir ../../../supabase/migrations/20261004000100_protect_user_roles.sql

set role authenticated;
update public.users set name = 'After' where id = 'ordinary';
insert into public.users (id, name) values ('new-user', 'New');
do $$
begin
  begin
    update public.users set role = 'admin' where id = 'ordinary';
    raise exception 'FAIL: ordinary role promotion was allowed';
  exception when insufficient_privilege then null;
  end;
  begin
    insert into public.users values ('attacker', 'Attacker', 'admin');
    raise exception 'FAIL: admin role insertion was allowed';
  exception when insufficient_privilege then null;
  end;
  begin
    insert into public.users values ('ordinary', 'After', 'admin')
      on conflict (id) do update set role = excluded.role;
    raise exception 'FAIL: role promotion through upsert was allowed';
  exception when insufficient_privilege then null;
  end;
end;
$$;
reset role;
-- Represents the existing, separately guarded SECURITY DEFINER admin RPC.
create function public.test_trusted_role_update() returns void
language sql security definer set search_path = '' as $$
  update public.users set role = 'admin' where id = 'ordinary';
$$;
set role authenticated;
select public.test_trusted_role_update();
reset role;
do $$
begin
  if not exists (select 1 from public.users where id = 'ordinary' and role = 'admin' and name = 'After') then
    raise exception 'FAIL: trusted admin update or normal profile edit failed';
  end if;
end;
$$;
set role service_role;
update public.users set role = 'user' where id = 'ordinary';
reset role;
select 'Role guard regression checks passed' as result;
