import 'package:spentx/features/sms/v4/payee_extractor.dart';
import 'dart:io';

void main() {
  const sms1 =
      'Spent Rs.587 From HDFC Bank Card x8191 At PAULPANDI KATHIRESAN On 2026-02-28:19:28:51 Bal Rs.1027.78 Not You? Call 18002586161/SMS BLOCK DC  8191 to 7308080808';

  const sms2 =
      'Spent Rs.1200 From HDFC Bank Card x8191 At PAULPANDI KATHIRESAN On 2026-03-15:10:45:22 Bal Rs.500.50 Not You? Call 18002586161/SMS BLOCK DC  8191 to 7308080808';

  for (final t in [
    (1, sms1, 'PAULPANDI KATHIRESAN'),
    (2, sms2, 'PAULPANDI KATHIRESAN'),
  ]) {
    final payee = PayeeExtractor.extract(t.$2);
    stdout.writeln('SMS ${t.$1} payee: $payee');
    if (payee != t.$3) {
      throw StateError('SMS ${t.$1}: expected "${t.$3}", got "$payee"');
    }
  }
  stdout.writeln('Both HDFC card payee tests passed.');
}