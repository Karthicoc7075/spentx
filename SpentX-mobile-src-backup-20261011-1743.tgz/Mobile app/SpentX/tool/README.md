# tool/

| Script | Run | What it does |
|---|---|---|
| `check_parser.dart` | `dart run tool/check_parser.dart [--diff]` | Parser coverage table (amount / direction / last-4 / payee) over every v5 sample message, plus a per-message diff against the Python reference. |
| `generic_parser_check.py` | `python3 tool/generic_parser_check.py [catalog] [--json]` | The tested Python reference the Dart parser is measured against. `--json` emits per-message results for the diff. |
| `test_*.dart` | `dart run tool/test_<name>.dart` | Older single-purpose probes. |

**Everything at once** — `flutter test && dart run tool/check_parser.dart`,
or `npm run test:sms` from the repo root.

Both parser tools score only the 273 hand-authored templates (those carrying a
`type` field). The merged catalog also holds 232 generated templates that have
no expected values, and scoring them would inflate the denominator with
messages nobody has verified.
