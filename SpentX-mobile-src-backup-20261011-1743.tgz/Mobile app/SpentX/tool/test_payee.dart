import 'package:spentx/features/sms/v4/payee_extractor.dart';
import 'dart:io';

void main() {
  const sms = '''Sent Rs.150.00
From HDFC Bank A/C *0034
To Abinesh Murugan
On 19/04/26
Ref 610901629095''';

  final payee = PayeeExtractor.extract(sms);
  stdout.writeln('Payee: $payee');
  assert(payee == 'Abinesh Murugan', 'Expected Abinesh Murugan, got $payee');
  stdout.writeln('OK');
}