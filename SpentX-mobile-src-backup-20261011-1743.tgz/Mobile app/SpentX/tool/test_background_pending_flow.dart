// ignore_for_file: avoid_print
// Integration test: native background payload → Hive pending → Detected SMS list.
//
// Run: dart run tool/test_background_pending_flow.dart
import 'dart:convert';

import 'package:hive_flutter/hive_flutter.dart';

import 'package:spentx/features/sms/detected/auto_rule_engine.dart';
import 'package:spentx/features/sms/detected/detected_sms_storage.dart';
import 'package:spentx/features/sms/core/sms_pending_service.dart';
import 'package:spentx/features/sms/rules/engine/sms_rule_engine.dart';
import 'package:spentx/features/sms/v4/bank_sms_v4_parser.dart';
import 'dart:io';

Future<void> main() async {
  await Hive.initFlutter();
  await Hive.openBox('settings');
  await Hive.openBox('pending_detections');
  await Hive.openBox('detected_sms_box');
  await Hive.openBox('transactions');
  await Hive.openBox('merchant_rules_box');
  await Hive.openBox('merchants_box');
  await Hive.openBox('processed_sms_box');
  await Hive.openBox('notification_history');

  await Hive.box('settings').put('auto_detection', true);
  await Hive.box('detected_sms_box').clear();
  await Hive.box('pending_detections').put('queue', <String>[]);
  await Hive.box('transactions').put('list', <dynamic>[]);

  await SmsRuleEngine.init();
  await BankSmsV4Parser.ensureLoaded();

  const txId = '1718123456789';
  const rawSms =
      'Sent Rs.115.00 from HDFC Bank A/c *1234 to Abinesh Murugan on 12-06-26. Ref 998877';

  final nativePayload = jsonEncode({
    'transactionId': txId,
    'pending': true,
    'amount': '115',
    'merchant': 'Abinesh Murugan',
    'bank': 'HDFC',
    'type': 'debit',
    'mode': 'upi',
    'rawText': rawSms,
    'nativeNotifShown': true,
  });

  stdout.writeln('=== Simulating native background notification payload ===');
  final map = Map<String, dynamic>.from(jsonDecode(nativePayload));
  final pendingId = AutoRuleEngine.handleNativePayload(map);

  stdout.writeln('handleNativePayload returned: $pendingId');
  assert(pendingId == txId, 'Expected stable native transaction id');

  final stored = DetectedSmsStorage.get(txId);
  assert(stored != null, 'Pending must be saved to detected_sms_box');
  final pending = stored!;
  assert(pending.amount == 115, 'Amount should be 115, got ${pending.amount}');
  assert(pending.receiver.contains('Abinesh'), 'Payee should be preserved');
  assert(!pending.deferAutoAdd, 'New payee must not defer auto-add');

  SmsPendingService.reconcile();
  final awaiting = SmsPendingService.listAwaitingVerification();
  assert(awaiting.isNotEmpty, 'Detected SMS list must show pending item');
  assert(awaiting.first.id == txId, 'Awaiting list must include native tx id');

  final queue = List<String>.from(
    Hive.box('pending_detections').get('queue', defaultValue: const <dynamic>[]),
  );
  assert(queue.contains(txId), 'pending_detections queue must contain tx id');

  stdout.writeln('PASS: background native payload → pending saved (₹${pending.amount}, ${pending.receiver})');
  stdout.writeln('PASS: Detected SMS awaiting count = ${awaiting.length}');
}