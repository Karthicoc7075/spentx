// Parser coverage check — Dart vs the Python reference.
//
//   dart run tool/check_parser.dart            # coverage table
//   dart run tool/check_parser.dart --diff     # + per-message Dart/Python diff
//
// Runs every `sampleMessage` in assets/sms/bank_sms_templates_v5.json through
// the app's parser path and prints the same four-field coverage table that
// tool/generic_parser_check.py prints. The two must agree.
//
// Scope: only templates carrying a `type` field are scored — the 273
// hand-authored v5 originals the Python reference was validated against. The
// merged catalog also holds 232 generated templates with no expected values;
// the Python applies the identical filter, so both tables describe the same
// set. `hdfc_credit_card_emi` is skipped by both (a mislabeled due reminder).
//
// This runs on the Dart VM, so it cannot use rootBundle and therefore cannot
// load the template engine. It measures the TEMPLATE-FREE path — the same
// thing the Python measures — which is what makes the two comparable.
import 'dart:convert';
import 'dart:io';

import 'package:spentx/features/sms_parser/sms_direction_helper.dart';
import 'package:spentx/features/sms_parser/sms_parser.dart';
import 'package:spentx/features/sms_parser/sms_transaction_filters.dart';
import 'package:spentx/features/sms/v4/payee_extractor.dart';
import 'package:spentx/features/sms_parser/models/transaction_parsed.dart';

const _catalog = 'assets/sms/bank_sms_templates_v5.json';
const _pythonScript = 'tool/generic_parser_check.py';

/// What the Dart side extracts for one message, in the Python's shape.
Map<String, String> parseDart(String body) {
  final out = <String, String>{};

  final amount = SmsTransactionFilters.transactionAmount(body);
  if (amount != null) {
    out['amount'] = amount.toStringAsFixed(2);
  }

  final parsed = UniversalSmsParser.parseSms(body);
  final direction = SmsDirectionHelper.resolveDirection(
    rawMessage: body,
    parsed: parsed,
  );
  out['direction'] = switch (direction) {
    TransactionDirection.income => 'credit',
    TransactionDirection.transfer => 'transfer',
    TransactionDirection.expense => 'debit',
  };

  final last4 = parsed?.accountLast4 ?? '';
  if (last4.isNotEmpty) out['last4'] = last4;

  final payee = PayeeExtractor.extract(body) ?? parsed?.name ?? '';
  if (payee.isNotEmpty && payee.toLowerCase() != 'unknown') {
    out['merchant'] = payee;
  }
  return out;
}

/// Numbers only differ by formatting between the two languages.
bool sameAmount(String? a, String? b) {
  if (a == null || b == null) return a == b;
  final x = double.tryParse(a.replaceAll(',', ''));
  final y = double.tryParse(b.replaceAll(',', ''));
  if (x == null || y == null) return a == b;
  return (x - y).abs() < 0.005;
}

void main(List<String> args) {
  final showDiff = args.contains('--diff');

  final file = File(_catalog);
  if (!file.existsSync()) {
    stderr.writeln('Catalog not found: $_catalog');
    exit(2);
  }
  final root = jsonDecode(file.readAsStringSync()) as Map<String, dynamic>;

  final rows = <Map<String, dynamic>>[];
  for (final bank in (root['banks'] as List)) {
    for (final t in ((bank as Map)['templates'] as List? ?? const [])) {
      final tpl = Map<String, dynamic>.from(t as Map);
      if (tpl['type'] == null) continue;          // generated, no expectations
      if (tpl['enabled'] == false) continue;      // catalog says it is wrong
      if (tpl['id'] == 'hdfc_credit_card_emi') continue;
      rows.add(tpl);
    }
  }

  final need = {'amount': 0, 'direction': 0, 'last4': 0, 'merchant': 0};
  final got = {'amount': 0, 'direction': 0, 'last4': 0, 'merchant': 0};
  final results = <String, Map<String, String>>{};

  for (final tpl in rows) {
    final id = tpl['id'].toString();
    final body = tpl['sampleMessage'].toString();
    final tags = ((tpl['tags'] as List?) ?? const []).map((e) => e.toString()).toSet();
    final r = parseDart(body);
    results[id] = r;

    need['amount'] = need['amount']! + 1;
    if (r.containsKey('amount')) got['amount'] = got['amount']! + 1;

    need['direction'] = need['direction']! + 1;
    if (r.containsKey('direction')) got['direction'] = got['direction']! + 1;

    if (tags.contains('AccountLast4') || tags.contains('CardLast4')) {
      need['last4'] = need['last4']! + 1;
      if (r.containsKey('last4')) got['last4'] = got['last4']! + 1;
    }
    if (tags.contains('Payee')) {
      need['merchant'] = need['merchant']! + 1;
      if (r.containsKey('merchant')) got['merchant'] = got['merchant']! + 1;
    }
  }

  stdout.writeln('Dart parser coverage on ${rows.length} real sample messages:');
  for (final k in need.keys) {
    final n = need[k]!;
    final g = got[k]!;
    final pct = n == 0 ? 0.0 : 100 * g / n;
    stdout.writeln('  ${k.padRight(10)} ${g.toString().padLeft(3)}/${n.toString().padLeft(3)}  '
        '${pct.toStringAsFixed(1)}%');
  }

  // ── compare against the Python reference ──
  stdout.writeln('');
  final py = Process.runSync('python3', [_pythonScript, _catalog, '--json']);
  if (py.exitCode != 0) {
    stdout.writeln('Python reference did not run — skipping comparison.');
    stdout.writeln(py.stderr);
    exit(1);
  }
  final pyResults = (jsonDecode(py.stdout as String) as Map)
      .map((k, v) => MapEntry(k.toString(), Map<String, dynamic>.from(v as Map)));

  var agree = 0;
  final diffs = <String>[];
  for (final tpl in rows) {
    final id = tpl['id'].toString();
    final d = results[id] ?? const {};
    final p = pyResults[id] ?? const {};

    final fieldDiffs = <String>[];
    for (final field in ['amount', 'direction', 'last4', 'merchant']) {
      final dv = d[field];
      final pv = p[field]?.toString();
      final same = field == 'amount'
          ? sameAmount(dv, pv)
          : (field == 'merchant'
              // Payee text is normalised differently on each side; agreement
              // means both found one, not that the strings are identical.
              ? (dv == null) == (pv == null)
              : dv == pv);
      if (!same) fieldDiffs.add('$field: dart=${dv ?? "-"}  python=${pv ?? "-"}');
    }
    if (fieldDiffs.isEmpty) {
      agree++;
    } else {
      diffs.add('$id\n      ${fieldDiffs.join("\n      ")}');
    }
  }

  stdout.writeln('Dart vs Python: $agree/${rows.length} messages agree on all four fields');
  if (diffs.isNotEmpty) {
    final show = showDiff ? diffs : diffs.take(15).toList();
    stdout.writeln('');
    stdout.writeln(showDiff ? 'all disagreements:' : 'first ${show.length} disagreements '
        '(run with --diff for all ${diffs.length}):');
    for (final d in show) {
      stdout.writeln('  $d');
    }
  }

  stdout.writeln('');
  if (diffs.isEmpty) {
    stdout.writeln('PARSERS AGREE.');
  } else {
    stdout.writeln('${diffs.length} message(s) differ between Dart and Python.');
  }
}
