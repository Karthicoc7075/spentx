# -*- coding: utf-8 -*-
"""Generic (template-free) Indian bank SMS parser — proof of coverage."""
import json, re

CUR = r"(?:INR|Rs\.?|₹)"
AMOUNT = re.compile(CUR + r"\s?([0-9][0-9,]*(?:\.[0-9]{1,2})?)(?![0-9A-Za-z_/])", re.I)
BAL_AMOUNT = re.compile(r"(?:avl|avbl|available|closing|a/c|acct)\s*(?:bal(?:ance)?)?\s*:?\s*" + CUR + r"\s?([0-9][0-9,]*(?:\.[0-9]{1,2})?)", re.I)

CREDIT = re.compile(r"\b(credited|received|deposited|credit\s+of|salary\s+credit|(?:neft|imps|rtgs|upi)\s+credit)\b", re.I)
DEBIT  = re.compile(r"\b(debited|spent|withdrawn|withdrawal|w/d|deducted|purchased|sent|paid|used|transferred\s+from|(?:fd|rd)\s+of\s+.{0,20}created\s+from)\b", re.I)
ATM    = re.compile(r"\b(atm|w/d|cash\s+withdraw)", re.I)

LAST4 = re.compile(r"\b(?:a/?c|acct|account|card|xx+|\*+)\s*(?:no\.?|number)?\s*[:.\s]*[xX*]*(\d{4})\b", re.I)
LAST4_ALT = re.compile(r"\b(?:card|a/?c)\s+(\d{4})\b", re.I)
REF = re.compile(r"\b(?:upi\s*ref|ref(?:erence)?(?:\s*no\.?|:)?|txn\s*(?:id|no)|utr)\s*[:.#]?\s*([A-Za-z0-9]{6,25})\b", re.I)
UPI_VPA = re.compile(r"\b([a-zA-Z0-9._-]{2,}@[a-zA-Z]{2,})\b")

# merchant: text after a direction preposition, stopped by date/ref/balance words
STOP = r"(?:\s+on\s+\d|\s+dt\s|\s*\.\s*(?:avl|avbl|ref|upi|not\s+you)|,\s*(?:upi|ref|on)|\s+ref[:\s]|\s+upi[\s:]|\s+via\s|\s*\(|\s+avl|\s+avbl|\s+&\s|\s+on\s+\d{2}|$|\n)"
MERCHANT_PATTERNS = [
 re.compile(r"\bto\s+VPA\s+([^\s,.]+)", re.I),
 re.compile(r"\b(?:paid|sent|debited|transferred)\s+(?:thru|through|via)?\s*[^\s]*\s*to\s+([A-Za-z0-9&.'\- ]{2,40}?)" + STOP, re.I),
 re.compile(r"\b(?:used|spent)\s+(?:.{0,25}?)\bat\s+([A-Za-z0-9&.'\- ]{2,40}?)" + STOP, re.I),
 re.compile(r"\bat\s+([A-Za-z0-9&.'\- ]{2,40}?)" + STOP, re.I),
 re.compile(r"\b(?:credited|received|deposited)\s+(?:.{0,30}?)\b(?:from|by)\s+([A-Za-z0-9&.'\- ]{2,40}?)" + STOP, re.I),
 re.compile(r"\bto\s+([A-Za-z0-9&.'\- ]{2,40}?)" + STOP, re.I),
 re.compile(r"\bSalary-([A-Za-z0-9&.'\- ]{2,40}?)" + STOP, re.I),
 re.compile(r"\bfor\s+((?:Home|Car|Personal|Education|Gold|Bike|Two[-\s]?Wheeler|Business)\s+Loan(?:\s+EMI)?)", re.I),
 re.compile(r"\bInfo\s*[:\-]\s*([A-Za-z0-9*&.'\- ]{3,40}?)" + STOP, re.I),
 re.compile(r"\bw/d\s*@\s*([A-Za-z0-9&.'\- ]{2,30}?)" + STOP, re.I),
 re.compile(r";\s*([A-Za-z][A-Za-z0-9&.'\- ]{2,30}?)" + STOP, re.I),
 re.compile(r"\b(?:from|by)\s+([A-Za-z][A-Za-z0-9&.'\- ]{2,40}?)" + STOP, re.I),
]
BAD_MERCHANT = re.compile(r"^(a/?c|acct|your|the|vpa|upi|ref|bal|balance|clearing|avl|avbl|card|bank|not\s+you|call|sms)\b", re.I)

def parse(body):
    out = {}
    # amount: first currency amount that is NOT the balance
    bals = {m.group(1) for m in BAL_AMOUNT.finditer(body)}
    for m in AMOUNT.finditer(body):
        if m.group(1) not in bals:
            out['amount'] = m.group(1); break
    if 'amount' not in out and AMOUNT.search(body):
        out['amount'] = AMOUNT.search(body).group(1)
    if bals: out['balance'] = sorted(bals)[-1]
    # direction
    # FIRST verb by position wins — "debited ... & credited to VPA" is a debit
    c, dbt = CREDIT.search(body), DEBIT.search(body)
    if c and dbt: out['direction'] = 'credit' if c.start() < dbt.start() else 'debit'
    elif c: out['direction'] = 'credit'
    elif dbt: out['direction'] = 'debit'
    if ATM.search(body) and out.get('direction') == 'debit': out['direction'] = 'transfer'
    # account tail
    m = LAST4.search(body) or LAST4_ALT.search(body)
    if m: out['last4'] = m.group(1)
    m = REF.search(body)
    if m: out['ref'] = m.group(1)
    m = UPI_VPA.search(body)
    if m: out['vpa'] = m.group(1)
    for p in MERCHANT_PATTERNS:
        m = p.search(body)
        if m:
            cand = m.group(1).strip(' .,-')
            if 2 <= len(cand) <= 40 and not BAD_MERCHANT.match(cand):
                out['merchant'] = cand; break
    return out

if __name__ == '__main__':
    # Path made an argument. The original hardcoded an authoring-sandbox path
    # (/mnt/user-data/uploads/...) that does not exist in this repo.
    #
    # Only templates carrying a `type` field are scored: those are the 273
    # hand-authored v5 originals this reference was validated against. The
    # merged catalog also holds 232 generated templates with no `type`/`tags`,
    # which this script has no expected values for. The Dart tool applies the
    # identical filter so the two tables describe the same set.
    import sys
    path = sys.argv[1] if len(sys.argv) > 1 else 'assets/sms/bank_sms_templates_v5.json'
    src = json.load(open(path))
    rows = [(b.get('bank', ''), t) for b in src['banks'] for t in b['templates']
            if t.get('type') and t.get('enabled') is not False]

    # `--json` emits per-message results for the Dart comparison.
    if '--json' in sys.argv:
        out = {}
        for _bank, t in rows:
            if t['id'] == 'hdfc_credit_card_emi':
                continue
            out[t['id']] = parse(t['sampleMessage'])
        print(json.dumps(out, ensure_ascii=False))
        sys.exit(0)
    need = {'amount':0,'direction':0,'last4':0,'merchant':0}
    got  = {'amount':0,'direction':0,'last4':0,'merchant':0}
    dirok = 0; dirn = 0; misses = []
    for bank, t in rows:
        if t['id'] == 'hdfc_credit_card_emi': continue
        r = parse(t['sampleMessage'])
        tags = set(t['tags'])
        need['amount'] += 1;  got['amount'] += 'amount' in r
        need['direction'] += 1; got['direction'] += 'direction' in r
        if 'AccountLast4' in tags or 'CardLast4' in tags:
            need['last4'] += 1; got['last4'] += 'last4' in r
        if 'Payee' in tags:
            need['merchant'] += 1; got['merchant'] += 'merchant' in r
        exp = {'Debit':'debit','Credit':'credit','Transfer':'transfer'}[t['type']]
        if 'direction' in r:
            dirn += 1
            ok = r['direction'] == exp or (exp == 'transfer' and r['direction'] in ('debit','credit')) or (exp=='Debit' and r['direction']=='transfer')
            dirok += ok
            if not ok: misses.append((t['id'], exp, r['direction'], t['sampleMessage'][:70]))
        if 'amount' not in r or ('Payee' in tags and 'merchant' not in r):
            misses.append((t['id'], 'FIELD', r.get('amount'), t['sampleMessage'][:70]))
    print(f'generic parser coverage on {len(rows)} real sample messages:')
    for k in need: print(f"  {k:10} {got[k]:3}/{need[k]:3}  {100*got[k]/max(1,need[k]):.1f}%")
    print(f"  direction correct vs catalog type: {dirok}/{dirn}")
    print()
    print('first 15 problems:')
    for m in misses[:15]: print('  ',m)
