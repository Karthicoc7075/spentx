# SpentX — Complete App & Page-by-Page Documentation

> **SpentX** is an offline-first, PIN-protected personal finance app for Android (Flutter) built for Indian users. It automatically detects bank/UPI transactions from SMS and notification alerts, tracks spending by account and purpose, manages budgets, splits trip costs with friends, and provides analytics — all stored locally on device. No cloud sync, no backend server.

**Version:** 1.0.0+1
**Platform:** Flutter (Android primary; iOS/Windows/Linux scaffolding present but unused)
**Currency:** ₹ (INR)
**Theme:** Always dark (`ThemeMode.dark`). The "Dark Mode" toggle in Settings is a decorative no-op.

This document goes page by page: every card/section on every screen, what it shows, why it exists, and exactly what happens when you tap it — plus the full backend workflow that powers it (SMS detection, Hive storage, providers).

---

## Table of Contents

1. [Technology Stack](#1-technology-stack)
2. [App Startup Sequence](#2-app-startup-sequence)
3. [Auth & Onboarding Screens](#3-auth--onboarding-screens)
4. [Main Navigation Shell](#4-main-navigation-shell)
5. [Home Screen — Full Card Breakdown](#5-home-screen--full-card-breakdown)
6. [Quick Add (+ FAB)](#6-quick-add--fab)
7. [Activity / Transactions Screen](#7-activity--transactions-screen)
8. [Transaction Detail Screen](#8-transaction-detail-screen)
9. [Accounts Screens](#9-accounts-screens)
10. [Budgets Screen](#10-budgets-screen)
11. [Analytics Screen](#11-analytics-screen)
12. [Outings / Trips (Groups) Screens](#12-outings--trips-groups-screens)
13. [Friends Screens](#13-friends-screens)
14. [Investments Screen](#14-investments-screen)
15. [Wealth Screen](#15-wealth-screen)
16. [Notifications History Screen](#16-notifications-history-screen)
17. [Settings ("More") Screen](#17-settings-more-screen)
18. [Merchant Names Screen](#18-merchant-names-screen)
19. [App Guide Screen](#19-app-guide-screen)
20. [Account Configuration Screen (Premium Settings)](#20-account-configuration-screen-premium-settings)
21. [Developer Options Screen](#21-developer-options-screen)
22. [Mock / Placeholder Screens](#22-mock--placeholder-screens)
23. [SMS Auto-Detection Pipeline (the core engine)](#23-sms-auto-detection-pipeline-the-core-engine)
24. [Privacy Modes](#24-privacy-modes)
25. [Data Models](#25-data-models)
26. [Hive Local Storage](#26-hive-local-storage)
27. [Riverpod Providers Reference](#27-riverpod-providers-reference)
28. [Complete Route Table](#28-complete-route-table)
29. [Known Issues, Dead Code & Non-Functional UI](#29-known-issues-dead-code--non-functional-ui)
30. [Implementation Maturity Summary](#30-implementation-maturity-summary)

---

## 1. Technology Stack

| Layer | Technology |
|-------|------------|
| UI Framework | Flutter (Dart SDK ^3.7.0) |
| State Management | `flutter_riverpod` |
| Navigation | `go_router` |
| Local Storage | `hive` / `hive_flutter` (no cloud sync) |
| Secure Storage | `flutter_secure_storage` (PIN hash/salt) |
| Biometrics | `local_auth` |
| SMS Reading | `telephony` + native Android broadcast receiver |
| Background Jobs | `workmanager` (15-min periodic SMS sweep) |
| Notifications | `flutter_local_notifications` + native notification listener (reads bank app alerts without SMS permission) |
| Charts | `fl_chart` |
| Contacts | `flutter_contacts` |
| Permissions | `permission_handler` |
| Fonts/Icons | `google_fonts`, `lucide_icons` |

---

## 2. App Startup Sequence

```
App Launch
    │
    ▼
WidgetsFlutterBinding.ensureInitialized()
    │
    ▼
Hive.initFlutter() → open all Hive boxes (see §26)
    │
    ▼
Migrate legacy SMS Hive boxes → current schema
    │
    ▼
SmsRuleEngine.init() — load SMS parsing rules
    │
    ▼
SmsTemplateRulesImporter.seedBundledDefaultsIfEmpty()
    (loads assets/sms/default_template_rules.json
     and assets/sms/bank_sms_templates_v4.json)
    │
    ▼
BankSmsV4Parser.ensureLoaded()
    │
    ▼
migrateLegacyPendingTransactions()
    │
    ▼
Initialize defaults: auto_detection=true, profile_name='', debug settings
    │
    ▼
AutoDetectionNativeSync.syncToNative() — push SMS toggle to Android side
    │
    ▼
Apply portrait lock if disable_rotation setting is ON
    │
    ▼
SmsNotificationService.init() + SmsService.init() (native event channel)
    │
    ▼
BackgroundSmsScheduler.initialize() — WorkManager 15-min periodic task
    │
    ▼
runApp(ProviderScope → SpentXApp)
    │
    ▼
SpentXApp.initState(): register lifecycle observer, SMS listener,
notification click handler
    │
    ▼
After 800ms: request SMS permissions, start SmsReceiverService,
PendingVerificationBootstrap.processStartupAndShowIfNeeded()
    │
    ▼
Route to Splash Screen ("/")
```

**On app resume from background:**
1. PIN lock screen shown if PIN + lock enabled (4-second debounce prevents double-prompt loops)
2. Flush pending SMS queue and pending notification payloads
3. Reload transactions from Hive
4. Run pending-SMS-verification popups if any accumulated while backgrounded

**Key file:** `lib/main.dart`

---

## 3. Auth & Onboarding Screens

There are **two unrelated "onboarding" flows** in this app — worth understanding up front:
- `/onboarding` (§3.2) is a 3-slide **marketing carousel**, collects no data, and is fully skippable straight to Home.
- `OnboardingModal` (§3.5) is a **non-dismissible 4-step dialog** shown automatically on first Home visit that actually collects your bank accounts and purpose types. Skipping the marketing carousel does *not* skip this — you'll hit it the moment you land on Home.

### 3.1 Splash Screen (`/`)
**File:** `lib/features/auth/presentation/splash_screen.dart`

The first screen on cold start.

| Element | Purpose |
|---|---|
| 80×80 gradient "S" logo mark | Brand identity while routing decision is made |
| "SpentX" wordmark | Brand |
| Tagline "Know where every rupee goes." | Fades in during back half of animation |
| Small spinner | Decorative — not tied to any real async wait |
| Footer "Created by Karthi" | Credit line |

**Workflow:** Plays a fixed **2.2 second** fade/scale animation (not a real loading wait), then reads Hive `settings` box:
- `has_seen_onboarding = false` → go to `/onboarding`
- `has_seen_onboarding = true` and `has_pin && lock_screen_enabled` → go to `/lock`
- Otherwise → go to `/home`

### 3.2 Marketing Onboarding (`/onboarding`)
**File:** `lib/features/auth/presentation/onboarding_screen.dart`

A 3-page swipeable carousel, purely cosmetic (collects nothing):

| Slide | Icon | Title | Copy |
|---|---|---|---|
| 1 | wallet | **Track Every Rupee** | "Effortlessly log expenses and income. See where your money really goes." |
| 2 | auto-graph | **Smart Analytics** | "Beautiful charts, daily insights, and budget tracking built for you." |
| 3 | security shield | **Private & Secure** | "PIN protected, offline-first. Your financial data stays yours." |

- Top-right **"Skip"** button → sets `has_seen_onboarding=true`, goes straight to `/home` (no PIN set).
- Bottom CTA button reads **"Next"** on slides 1-2 (advances the PageView), and **"Get Started"** on slide 3 → sets `has_seen_onboarding=true`, goes to `/pin-setup`.
- Animated dot indicators track the active page.

### 3.3 PIN Setup Screen (`/pin-setup`)
**File:** `lib/features/auth/presentation/pin_setup_screen.dart`

Reached from: onboarding's "Get Started", Settings → "Set/Change PIN", or the "Reset PIN" flow.

| Element | Behavior |
|---|---|
| App mark ("S" logo) | Branding |
| Headline | "Create a PIN" (first time) / "Set new PIN" (changing) / "Confirm your PIN" (2nd entry) |
| Error text | "PINs do not match. Try again." — shown only on mismatch |
| 4 animated PIN dots | Fill in as digits are typed |
| Custom numeric keypad | 1-9, blank, 0, backspace |

**Workflow:** Enter 4 digits → 300ms pause → re-enter to confirm → 300ms pause → on match, `PinService.setPin()` stores the hash+salt in secure storage, **and fingerprint unlock is silently force-enabled** (`PinService.enableFingerprint()` fires automatically, regardless of device capability), then navigates to Home (or pops back to Settings if this was a change-PIN flow). On mismatch, resets to first entry and shows the error.

### 3.4 Lock Screen (`/lock`)
**File:** `lib/features/auth/presentation/lock_screen.dart`

Shown on cold start (if PIN+lock enabled) and on every app resume from background (4-second debounce prevents re-prompting immediately after an unlock).

**Two modes**, switched automatically or manually:

**Biometric mode** (default if fingerprint enabled + device supports it):
- App mark + "Welcome back" + "Confirm your identity to continue"
- Animated fingerprint/face badge — auto-triggers the OS biometric prompt ~450ms after screen opens, no tap needed
- **"Unlock with Face ID / Fingerprint"** button (re-triggers prompt manually)
- **"Use PIN instead"** link → switches to PIN mode

**PIN mode:**
- 4 animated PIN dots (shake animation on wrong PIN)
- Custom numeric keypad (includes a fingerprint icon key to jump back to biometric mode)
- On 4th digit: 180ms pause → verifies against stored hash → success unlocks and navigates to `redirectTo` (default `/home`); failure shakes the dots and shows a red error for 3 seconds, then clears

**On unlock (either method):** sets `PinService.lastUnlockedAt`, drains the pending SMS verification queue, navigates onward.

### 3.5 First-Time Account Setup Modal (not a route — a dialog)
**Files:** `lib/features/auth/presentation/widgets/onboarding/onboarding_modal.dart` + `account_count_card.dart`, `account_form_card.dart`, `purpose_type_card.dart`, `summary_card.dart`

Triggered from `HomeScreen.initState()` when `userStateProvider.isFirstTimeUser == true`. Shown as a `barrierDismissible: false` dialog — **cannot be closed** except by completing it (or force-closing the app).

**Step 1 — Account Count** ("STEP 1"):
- Headline: "How many bank accounts do you manage?"
- A slider (1-8) with a giant number display and 1-8 tap-labels
- "Continue" button advances; a "Skip for now" text label is present but **has no tap handler — does nothing**

**Step 2 — Account Details** ("STEP 2 OF 3", 3-segment progress bar):
- Cycles through one form per account you said you have, with a counter "N of Total"
- **Select Bank** dropdown (SBI, HDFC, ICICI, Axis, Kotak, Yes Bank, PNB, BOB, Canara, Union Bank, IndusInd, Federal, or "Other/Custom") — excludes banks already picked earlier in this session
- **Custom Bank Name** field — only shown if "Other/Custom" selected
- **Account Last 4 Digits** — required, exactly 4 digits
- **Initial Balance** — optional ₹ field, defaults to 0
- "Back"/"Next Account"/"Continue" navigation
- On finish: **automatically prepends a hidden "Cash" account** with opening balance silently fixed at 0 (there is no UI to set the cash balance during onboarding), then one Bank account per form filled in

**Step 3 — Purpose Types** ("STEP 3", 4-segment progress bar):
- Headline "Configure Purpose Types"
- Two pre-built selectable cards: **Personal** (pre-selected, cannot be fully deselected — at least one purpose must remain checked) and **Family**
- "Add Custom Purpose" → bottom sheet with a text field to add your own (e.g. "Business")
- "Continue Configuration" button

**Step 4 — Summary**:
- Green checkmark, "Ready to go!"
- Summary card: bank account count + purpose types chosen
- **"ENTER APP"** button → calls `userStateProvider.completeOnboarding()`, which persists everything and flips `isFirstTimeUser` off, closing the dialog for good

---

## 4. Main Navigation Shell

**File:** `lib/features/home/presentation/main_wrapper.dart`

`MainWrapper` hosts all 5 primary screens in an `IndexedStack` (state preserved across tab switches):

| Index | Screen | Tab visible? |
|---|---|---|
| 0 | `HomeScreen` | Yes — "Home" |
| 1 | `TransactionsScreen` | Yes — "Activity" |
| 2 | `AnalyticsScreen` | Yes — "Analytics" |
| 3 | `AccountsScreen` | **No tab** — reachable only via Home's Net Worth card or "Transfer" quick action |
| 4 | `SettingsScreen` | Yes — "More" |

### Bottom Navigation Bar
Row of 4 tappable items (Home / Activity / Analytics / More) plus a **center floating "+" button** that sits above the bar (not a tab — it opens a bottom sheet, see §6). Selected tab icon gets a pill-shaped primary-tinted background.

### Startup side effects (on first frame)
1. `outingProvider.expireEndedOutings()` — auto-closes any trip whose end date has passed
2. First-time notification-listener permission check — if the user hasn't granted Android's notification listener access, shows a **Permission Prompt bottom sheet**: bell icon, "Enable Auto-Detection", explains SpentX can detect expenses from bank notifications without SMS permission; **"Allow Permission"** opens OS settings, **"Maybe Later"** dismisses. Shown once per install.
3. `PendingVerificationBootstrap.processStartupAndShowIfNeeded()` — shows SMS verification popups if any are queued

### On every app resume
Reloads transactions from Hive and re-drains the pending SMS verification queue.

### Settlement feedback snackbar
Listens to `settlementFeedbackProvider` — pops a green floating SnackBar anywhere in the app when a friend's repayment gets auto-matched from an incoming SMS/credit (e.g. "Priya's ₹500 repayment auto-matched").

---

## 5. Home Screen — Full Card Breakdown

**File:** `lib/features/home/presentation/home_screen.dart` (1054 lines)
**Route:** Tab 0, the default landing screen after auth.

This is the most complex screen in the app — it renders **two entirely different layouts** depending on whether "Outing Privacy Mode" is currently active for a trip.

### Top App Bar (always shown)
- Left: 36×36 gradient "S" logo + app name "SpentX" + a subtitle line that reads either `Privacy · {tripTitle}` (primary-colored, when trip privacy is active) or **"Good Evening, {profileName}"** — note this greeting is hardcoded text, not actually time-of-day-aware.
- Right: notification bell icon → `/notifications`. Shows a small red badge dot only when there are unread notifications.

### Pending SMS Verification Banner (conditional)
Shown whenever `pendingCount > 0` and privacy mode is off: a tappable pill — mail icon + **"{N} SMS pending verification — tap to review"** + chevron. Tapping opens the sequential SMS-verification popup flow (confirm/edit/ignore each detected transaction one at a time).

### — Normal Mode Cards (privacy mode off) —

**1. Outing Banner** — a persistent prompt widget shown at the very top of the normal dashboard (create/join a trip nudge).

**2. Net Worth Hero Card** *(tap → Accounts screen)*
- Label "NET WORTH" + chevron
- Big number: total balance across all accounts, Indian-comma-formatted (e.g. `₹1,24,500.00`)
- If Private Mode is on, the real number is replaced with a masked `*****` string at a smaller font
- Below it, a **Monthly Flow row** with two chips:
  - **Income** — this month's non-expense, non-transfer, non-"Repayment" credits
  - **Spent** — this month's expenses (excluding transfers) **minus** this month's "Repayment" credits, **plus** this month's manual (cash) trip expenses across all outings
  - Both figures respect Private Mode masking
- Purpose: the single "how am I doing" glance card.

**3. Quick Actions row** — 4 circular icon shortcuts, evenly spaced:
| Icon | Label | Destination |
|---|---|---|
| Map | Outing | `/outings` |
| Trending-up | Wealth | `/wealth` |
| Arrow-swap | Transfer | `/accounts` (opens the account list, where the real Transfer sheet lives) |
| Target | Budgets | `/budgets` |

**4. "Your Accounts" / "Spent by Purpose" card** — the section **title and content both change** based on how many purpose types (Personal/Family/etc.) you configured:
- **If you only use 1 purpose type**: title is "Your Accounts", "View all" → `/accounts`. Lists each account (Cash first) as a mini card — icon, name, `"Global Wallet"` (Cash) or `"•••• {last4}"` (Bank), balance.
- **If you use multiple purpose types**: title is "Spent by Purpose", "View all" → `/activity`. Lists each purpose (Personal, Family, ...) as a mini card showing *this month's* spend total for that purpose. Each purpose can be independently masked in Private Mode via a purpose-level mask setting.

**5. Recent Activity card**
- "View all" → `/activity`
- Merges standalone transactions with any trip that has expenses, sorted newest-first, shows the top 5
- **Empty state**: inbox icon + "No recent activity" when there's nothing yet
- Each row is a standard transaction tile; an outing row shows the trip title as the "merchant" and total trip spend as the amount, tapping it opens the trip detail; a normal transaction row opens its detail page.

### — Outing Privacy Mode Cards (replaces everything above when a trip has privacy turned on) —

**1. Privacy banner** — eye-off icon + "Outing privacy · {trip title} — balances & other spending hidden until the trip ends".

**2. Trip Spend Card**
- "TRIP TOTAL SPENT" + ₹ total for the active trip only
- If the trip has other members, 3 mini-stats: **Your share**, **Pending return** (what friends still owe you), **Returned** (already paid back)

**3. "Trip activity" section** — "Trip details" link → full trip detail screen; lists recent trip-only expenses (empty state: "No trip expenses yet").

**Net effect:** while trip privacy is on, Home shows *only* the active trip's numbers — no net worth, no other accounts, no unrelated transactions are visible on this screen.

### Providers this screen depends on
`detectionQueueProvider`, `isOutingPrivacyActiveProvider`, `activeOutingProvider`, `effectivePrivateModeProvider`, `hasUnreadNotificationsProvider`, `userStateProvider`, `netWorthProvider`, `transactionProvider`, `outingProvider`.

---

## 6. Quick Add (+ FAB)

**File:** `lib/features/home/presentation/main_wrapper.dart` (`_QuickAddSheet`, `_ExpenseForm`, `_IncomeForm`)

Tapping the center **"+"** button (available from any tab) opens a bottom sheet:

> **"Quick Add"** — "What would you like to record?"
> - **Add Expense** card — down-left arrow icon — "Record spending from any category"
> - **Add Income** card — up-right arrow icon — "Log salary, freelance or other income"

### Add Expense Form
| Field | Required | Notes |
|---|---|---|
| Amount | Yes | Large centered ₹ field |
| "Where did you spend?" (title) | Yes | Hint: "McDonalds, Rent, Shopping..." |
| UPI ID / Unique Ref | No | Feeds the merchant-learning engine for future auto-detection |
| Source Account | Yes | Horizontal chip selector, defaults to first account |
| Purpose | No | Horizontal chip selector, defaults to first purpose |
| Category | Yes | Visual category picker, defaults to "Food" |

**"Save Expense"** button → creates the transaction, and if a UPI/ref was entered, teaches the merchant-recognition engine so future SMS from that payee are auto-categorized the same way. Silently no-ops if amount ≤ 0 (no error message shown).

### Add Income Form
Same layout, plus an extra optional **"Note / Purpose"** field. Hints differ ("Salary, Refund, Gift..."). **"Save Income"** button follows the same save + merchant-learning pattern.

---

## 7. Activity / Transactions Screen

**File:** `lib/features/transactions/presentation/transactions_screen.dart`
**Route:** Tab 1 ("Activity"), also reachable via `/activity`.

The full chronological ledger.

### App Bar
Title "Activity" (or "{trip} activity" in privacy mode). Icons: **search** (opens an in-app search delegate over merchant/category/account) and **calendar** (date-range filter, turns primary-colored once a range is picked).

### Cards, top to bottom
1. **Trip privacy banner** — conditional, same pattern as Home.
2. **Purpose Tabs** — pill row "All / Personal / Family / ..." — only shown if you have more than one purpose type configured.
3. **Total Expenses Summary Card** — big red total of everything currently visible under the active filters.
4. **Category Filter Chips** — horizontally scrollable "All" + every expense category.
5. **Date-grouped transaction list** — bucketed under "Today" / "Yesterday" / full date headers. Trip expenses roll up into a single "outing summary" row per trip rather than showing every line item individually. **Empty state**: receipt icon + "No transactions found".

### Tap behavior
- A rolled-up trip summary row → trip detail screen
- An unlinked manual trip expense → its own detail screen
- Everything else → the standard transaction detail screen

### Search
Tapping the search icon opens a live filter over merchant/category/account name; tapping a result opens that transaction's detail.

---

## 8. Transaction Detail Screen

**File:** `lib/features/transactions/presentation/transaction_detail_screen.dart`
**Routes:** `/transaction/:id` and `/outing-expense/:outingId/:expenseId`

### Hero section
80×80 category-colored circle icon, big signed amount (`-₹X` red for expense / `+₹X` green for income), title, formatted date/time.

### Details Card (rows shown only when relevant)
Category (always) · Purpose (if set) · Source Bank (if online payment) · Payment Mode (always) · Status (`Verified`/`Confirmed`/`Trip expense`) · Source ("Auto-detected via SMS", if applicable) · Account Number (`****last4`) · Reference ID · UPI ID · Note · Trip Activity (if part of a trip).

### Raw SMS / Note (collapsible)
An expandable tile showing the original bank SMS text (if auto-detected) or your manual note — lets you verify the parser got it right.

### Trip Management section (three variants)
- **Already linked to a trip**: shows which trip, buttons for **Edit Split**, **Change Outing** (move to a different trip), **Unlink**.
- **Not linked to any trip**: a dropdown to link it to an existing outing (active one flagged "ACTIVE").
- **Manual trip-only expense**: shows the trip name; unlinking here can permanently delete the expense (with a warning dialog) if it has no underlying transaction.

### Top-right actions
**Edit** (opens the edit form, pre-filled) and **Delete** (confirmation dialog: "Delete Transaction? This action cannot be undone and will update your balances.").

---

## 9. Accounts Screens

### 9.1 Accounts List
**File:** `lib/features/accounts/presentation/accounts_screen.dart`
**Route:** `/accounts` — reached from Home's Net Worth card, "Transfer" quick action, or "View all" (single-purpose mode). **Not on the bottom nav bar.**

- **Total Balance Hero Card**: big ₹ total (or masked), with **"Add Funds"** and **"Transfer"** buttons.
  - Add Funds opens a sheet: amount, source account, purpose, title/reason → creates an income transaction categorized "Income".
  - Transfer opens the account-to-account Transfer bottom sheet.
- **Account cards** — one per account (Cash always sorted first): wallet/building icon, name, type badge, subtitle ("Global Wallet" for Cash or "•••• {last4}" for Bank), balance = opening balance + net of all its transactions. Tap → Account Detail.

**Balance formula:** `Account Balance = openingBalance + Σ(transactions for that account)`, expenses subtract, income/transfer-in adds.

### 9.2 Account Detail
**File:** `lib/features/accounts/presentation/account_detail_screen.dart`
**Route:** `/account-detail/:name`

- **Time Range selector**: Day / Week / Month / Custom (default Week) — Custom opens a date-range picker.
- **Summary Card**: two-column Credit vs Debit totals for the selected range.
- **Sub Filter**: All / Credit / Debit.
- **Transaction list** for just this account, date-formatted, tap any real transaction to open its detail (manual unlinked trip expenses appear in the list but are not tappable here). Empty state: "No transactions found".

**Special rule:** when viewing the Cash account, an incoming transfer *from* a bank account is displayed as a credit (money coming in), not a debit — even though the underlying record is technically flagged as an expense on the source side.

---

## 10. Budgets Screen

**File:** `lib/features/budgets/presentation/budgets_screen.dart`
**Route:** `/budgets`, from Home's Budgets quick action.

- **App bar** bell icon → `/notifications` (to review past budget alerts).
- **Monthly Budget Summary Card**: `₹{spent} / ₹{limit}` across all budgets combined, progress bar (turns red past 90% used), remaining-amount caption.
- **"Enable budgeting for other purposes" switch** — only shown if you have more than one purpose type; toggling affects the default category shown in the Add-Budget sheet.
- **Per-category budget cards** — one per configured budget: category icon, red alert icon if ≥90% used, spent vs limit text, color-coded progress bar, and a trash icon that **deletes instantly with no confirmation dialog**.
- **Empty state**: "No budgets — tap + to add."
- **"+" FAB** → Add Budget sheet: pick category, set a ₹ monthly limit (defaults to 5000), two switches ("Alert at 80%", "Alert when exceeded" — both default on), "Save budget".

### Alert logic (background service)
**File:** `lib/core/services/budget_alert_service.dart` — every time a new expense is added, it checks whether that category has an active budget, computes this month's spend, and if it crosses 80% or 100%, writes an alert into notification history.

---

## 11. Analytics Screen

**File:** `lib/features/analytics/presentation/analytics_screen.dart`
**Route:** Tab 2 ("Analytics").

- **Trip privacy banner** — when active, replaces the filters below with a single "Showing {trip} only" notice and title becomes "Trip analytics".
- **Purpose Filter chips** — "All" + your purpose types (hidden in privacy mode).
- **Time Range tabs** — Day / Week / Month (default) / Year.
- **Hero Savings Card**: `NET SAVINGS ({period})` = income − spent for the selected window, plus a color-coded health badge:
  | Savings | Badge |
  |---|---|
  | > ₹50,000 | 💎 "Wealth Builder Mode" (cyan) |
  | > ₹10,000 | ✓ "Healthy Balance" (green) |
  | > ₹0 | 📈 "On Track" (orange) |
  | < ₹0 | ⚠️ "Overspending" (red) |
- **Detailed Stats**: Income, Spent, Savings rate %, Avg/day chips; expense/income counts; top 3 accounts by spend.
- **Cash Flow chart**: grouped bar chart (Income vs Expense) bucketed by hour/weekday/week/month depending on the selected time range.
- **Top Categories**: top 5 categories with ₹ amount, % share, and a progress bar (trip expenses roll up under a synthetic "Trip" category).
- **Top Spending Items**: top 5 biggest single expenses or trips (whichever is bigger), each with a merchant or map icon.

---

## 12. Outings / Trips (Groups) Screens

The trip-splitting feature — track shared costs, split bills, record repayments.

### Outing Data Model
```
Outing
├── id, title, category, location, startDate, endDate
├── members: List<OutingMember> (name, upiId)
├── expenses: List<OutingExpense>
│   ├── manual (cash) OR linked (has a transactionId)
│   ├── paidBy: member, splitType: solo | equally, memberIds
│   └── amount, title, category, date
├── settlementPayments — repayments, partial amounts supported
├── isActive, autoAddMode, privacyMode
```

### 12.1 Groups (Outings) List
**File:** `lib/features/groups/presentation/groups_screen.dart`
**Route:** `/outings`

- **Active Trip banner** (if a trip is running): title, date range, "DAY N / Total" pill, total spent + item count, a day-progress bar, **"Add Expense"** button, and a **settings gear** → full trip detail.
- **Completed Trips list**: cards with category tag, title, total spend, item count, date range. Tap → trip detail.
- **Empty state**: map icon + "No trips yet — Start a trip to track group expenses."
- **FAB**: if no trip is active → gradient **"New Trip"** button opens the Create Outing sheet. If a trip is already active, the FAB is replaced by an "An outing is already active" banner with a "View Trip" link — **the app only allows one active trip at a time.**

### 12.2 Create/Edit Outing Sheet
**File:** `lib/features/groups/presentation/widgets/create_outing_sheet.dart`

- Trip Title (required)
- Category dropdown (with an "Other…" option to add a custom category) + optional free-text Location
- Start Date / End Date pickers (end auto-clamps to not precede start)
- Members — chip list; "You" cannot be removed; "Add" opens the friend picker
- **"START TRIP"** (create) / **"SAVE CHANGES"** (edit) button

### 12.3 Trip Detail Screen
**File:** `lib/features/groups/presentation/group_detail_screen.dart` (1412 lines — the most complex secondary screen)
**Route:** `/outing-detail/:id`

**Header block:**
- Category + location chips
- **Summary boxes**: "TOTAL TRIP" spend (always); for multi-member trips also "YOUR SHARE", "PENDING RETURN" (owed to you), "RETURNED", conditionally "YOU OWE" and "YOUR OUTSTANDING" (net out-of-pocket)
- **Payment Summary card**: cash-manual vs auto-detected totals, with item bullet lists
- Date range row

**Split & Balances card** (multi-member trips only): per-friend net balance — "Owes you ₹X" / "You owe ₹X" / "Settled".

**Members row**: horizontally scrollable avatar chips, "You" highlighted.

**Category Breakdown**: donut pie chart + legend of top categories for this trip.

**Trip Statement** (`OutingStatementSection` widget): a full financial audit — total spend, your share, pending/returned/owed amounts, your UPI spend/receipts on the trip, split-bills-paid breakdown, and a **Statement History** list of every linked bank/UPI transaction (tap → transaction detail). Empty state: "No linked bank/UPI transactions yet."

**Activity section** (header shows item count, "+" button to log a cash expense while the trip is active):
- **"YOU NEED TO SEND" callout** — one orange card per friend you owe, "Send ₹X to {friend}" with a note that UPI payments auto-detect.
- **Expense list**, grouped by "DAY N" if the trip spans multiple days, each row shows category icon, title, amount, who paid, split details, and status badges: **VERIFY** (unconfirmed SMS), **✓** (confirmed auto-detected), **SPLIT (N)** (equally split). An **unlink** icon detaches items from the trip (confirmation dialog first).
- **Repayments history**: chronological list of every settlement payment recorded ("{Name} paid ₹X (mode) for {expense}"). Empty state: "No returns yet."

**Trip menu (⋮ icon)**: **Edit Trip Details**, **End Trip & Settle** (only while active — ends the trip and shows a success snackbar), **Delete Trip** (red, permanent, confirmation required).

### 12.4 Add Outing Expense Sheet
**File:** `lib/features/groups/presentation/widgets/add_outing_expense_sheet.dart`

Amount, Description, Category (chip row + "Other" custom field), Account (Cash-only when opened from the trip's cash-expense "+" button), and — for multi-member trips — **"Who paid?"** and **"Split with"** (Solo or Equally, with per-member inclusion toggles). **"LOG TRIP EXPENSE"** button submits.

### Auto-linking behavior
When you add any transaction while a trip is active with auto-add mode on: expenses within the trip's date range are automatically tagged to it; incoming credits are automatically matched to friend repayments if the sender's UPI/name is recognized.

---

## 13. Friends Screens

### 13.1 Friends List
**File:** `lib/features/friends/presentation/friends_screen.dart` (2110 lines — largest screen in the app)
**Route:** `/friends`

Combines three sections in one scrollable list (no tabs): **Added Friends** (manually added), **All Friends** (derived from shared trip history), **Contacts** (device address book with one-tap "Add"/"Added" state). A search field filters all three. Empty state: "No friends yet — add one or pick from contacts."

- **"+" AppBar action** → Add Friend sheet (Name required, Phone optional).
- Each friend tile shows avatar, name, phone, and either "No shared trip expenses yet" or **"You get back ₹X"** in green.

### 13.2 Friend Detail Screen
Tapping a friend opens their full shared-expense ledger:

- **Summary header**: avatar, name, phone, expense count, and a 3-column stat row — **You Paid / Their Share / You Get Back**.
- **"Mark all paid"** AppBar action (only shown if there's a pending balance) → bulk-settle everything owed by this friend in one confirmation.
- **Linked UPI section**: add the friend's UPI ID so future SMS credits/debits from them auto-clear pending balances without manual confirmation. Includes a "Sync past SMS repayments" button to retroactively re-match old transactions.
- **Search + Sort** controls (by outing name A-Z/Z-A, pending-first, amount high-to-low) — shown once the friend has any expenses.
- **Expense list grouped by outing**: each shows trip total, partial-payment notes ("Received ₹A of ₹B · pending ₹C"), a status badge (**Settled**/**Partial**/**Pending** — tap Partial or Pending to record a payment), payment history chips, and split breakdown (your share vs their share).
- **Record Payment sheet**: amount (pre-filled to remaining balance, with a "Max" quick-fill), payment type (Cash/Online/UPI), destination account — supports partial/split repayments across multiple submissions.

---

## 14. Investments Screen

**File:** `lib/features/investments/presentation/investments_screen.dart`
**Route:** `/investments`, from the Wealth screen.

Manual portfolio tracking — no live market data.

- **Total Wealth Card**: sum of all holdings, with **Invest**/**Withdraw** buttons (disabled until you have at least one holding).
- **"SMS Detected Investment Transactions" card**: scans your transaction history for investment-related keywords (`groww, zerodha, upstox, sip, mutual, stocks, nse, bse, fd, fixed deposit, ...`) and lists up to 10 matches with a **"Select / Allocate"** button per row to assign them to a holding — or create a new holding from the transaction directly. Quick-link chips to open Groww/Zerodha/Upstox/MF Central in a browser.
- **Portfolio Breakdown card** (shown once you have holdings): a progress bar per investment type showing % share.
- **Holdings list**: one card per holding — icon, name, amount, green growth-% pill, delete icon (confirmation dialog). Tap to edit; **long-press to quick-invest more**.
- **Today's Flow**: Income vs Expenses for today, sourced from the transaction ledger.

**Investment types:** Liquid, Mutual Fund, Fixed Deposit, Stocks, Bonds, Crypto, Gold, Real Estate, Other.

---

## 15. Wealth Screen

**File:** `lib/features/wealth/presentation/wealth_screen.dart`
**Route:** `/wealth`, from Home's Wealth quick action.

- **Net Worth Overview Card**: Cash + Bank + Invested, broken into 3 metric columns.
- **"SMS Wealth Events" card**: scans income transactions for keywords like `salary, bonus, dividend, interest, refund, sale, maturity` — each detected event has an **"Allocate"** button that assigns 10% of that amount toward your first savings goal.
- **"Wealth Goals" card**: progress bars per goal with quick **"+10k"/"+50k"** buttons and a full "Add Wealth Goal" dialog (name + target amount).
- **"Expanded Wealth Features" card**: links to Detailed Investments, plus two informational-only tiles (**Diversification Score**, **Financial Freedom Tracker**) that are explicitly demo placeholders.

> **⚠️ Important caveat:** Cash/Bank balances on this screen use hardcoded starting offsets (₹1,00,000 cash / ₹4,50,000 bank base) adjusted only by matching transactions — they are **not the same accurate figures shown on the Accounts screen**. Wealth Goals are stored in memory only and **reset when you navigate away and back** — they are not saved to Hive.

---

## 16. Notifications History Screen

**File:** `lib/features/notifications/presentation/notifications_screen.dart`
**Route:** `/notifications`

An in-app log (not the Android system tray) of three event types:

| Type | Meaning |
|---|---|
| `sms_auto` | A transaction was auto-added from an SMS/notification detection |
| `sms_pending` | An SMS was detected but needs your manual verification |
| `budget` | A budget threshold alert (80% or 100% of a category limit) |

Each entry shows an icon, title, body text, and timestamp; unread entries have a highlighted border and a colored dot. **"Mark read"** AppBar action clears all unread styling at once. Empty state: bell icon + "No notification history yet." Entries are **not individually tappable**.

---

## 17. Settings ("More") Screen

**File:** `lib/features/settings/presentation/settings_screen.dart`
**Route:** Tab 4 ("More").

### Profile Header Card
Avatar circle (first letter of your name), your profile name, "Tap to edit name" → opens an inline rename dialog.

### HELP
- **How to use SpentX** → `/app-guide`

### CONFIGURATION
- **Account Configuration** → opens the Premium Settings screen (§20) for managing accounts & purposes

### FEATURES
- **Manage Outing** → `/outings`
- **Outing Privacy Mode** switch — only togglable while a trip is active; turning it **on** is instant, turning it **off** requires PIN/name verification via a confirmation dialog (prevents someone else grabbing your phone from casually exposing your real balances)
- **Manage Friends** → `/friends`
- **Manage Merchants** → `/merchant-names`

### DEVELOPER
- **SMS Rules Storage** → `/sms-rules-storage`
- **Developer Options** → `/developer-options`

### PREFERENCES
- **Private Mode** switch — masks amounts on Home & Accounts with `*****`. Blocked/disabled while Outing Privacy is live. Turning off also requires verification.
- **Notification History** → `/notifications`
- **Automatic SMS Detection** switch — turns the entire SMS/notification auto-capture pipeline on/off. When off, subtitle explicitly tells you to "use manual one-time add for UPI spends."
- **Dark Mode** switch — **hardcoded to always-on, tapping it does nothing.**

### SECURITY
- **Set/Change PIN** → `/pin-setup`
- **Lock Screen** switch — requires a PIN to already exist
- **Fingerprint Authentication** switch — only shown once a PIN exists
- **Reset PIN** — only shown once a PIN exists; requires **biometric** verification (not your old PIN) before letting you set a new one

### DANGER ZONE
- **Reset App Data** — multi-step destructive flow: confirmation dialog → PIN or biometric verification → final "last chance" confirmation → wipes **all** Hive data via `AppResetService.resetAll()` → force-quits the app after a few seconds so first-time setup runs on next open.

---

## 18. Merchant Names Screen

**File:** `lib/features/settings/presentation/merchant_names_screen.dart`
**Route:** `/merchant-names`

The UPI/payee → display-name/category mapping table that powers auto-detection accuracy.

- Search bar filters by merchant name or the underlying identifier key.
- Empty state: store icon + "No mappings yet" (or "No results found" when search yields nothing).
- Each list row: store icon, merchant display name, normalized identifier key, category badge, purpose-type badge. Tap → detail screen with **Edit Mapping** and **Delete Mapping** (confirmation warns future SMS from that identifier will stop being auto-recognized under this name).
- **"+" FAB** → Add/Edit sheet: Identifier (e.g. `zomato@paytm`), Display Name, Category picker, Purpose Type chips (hidden if you only have one purpose type).

---

## 19. App Guide Screen

**File:** `lib/features/settings/presentation/app_guide_screen.dart`
**Route:** `/app-guide`

A fully static, non-interactive in-app manual (no data, no navigation from within it). Sections: Getting Started, Bottom Navigation, Track Spending Automatically, Trips & Outings, Friends & Splits, Privacy Modes, Security, Budgets & Investments — each a bulleted card. Followed by a **Tips & Tricks** section (7 practical tips) and a **"Future — Must Add"** section that self-documents planned features (cloud backup, recurring bills, CSV/PDF export, multi-currency, widgets, etc.) — note this list is somewhat stale (it lists biometric unlock and theme toggle as "future" even though the former already exists and the latter is a permanent no-op).

---

## 20. Account Configuration Screen (Premium Settings)

**File:** `lib/features/settings/presentation/screens/premium_settings_screen.dart`
**Entry point:** pushed from Settings → "Account Configuration" (not a `go_router` path).

This is the real account & purpose management screen.

- **Bank Accounts section**: count badge "N / 8" (8-account cap). Each account card has edit (banks only, not Cash) and delete icons — **the Cash account and the first bank account added can never be deleted**, and Cash can never be edited either.
- **"Add Institutional Account"** dashed card → opens an Add Account sheet (bank picker from a 12-bank list + "Other", last-4-digits, opening balance). Silently does nothing once you hit 8 accounts (no error shown).
- **Purpose Types section**: **Personal** is permanent (no toggle/delete). **Family** has an on/off switch. Any custom purpose you've added gets full edit/delete controls. **"Create Custom Purpose"** row adds a new one.

---

## 21. Developer Options Screen

**File:** `lib/features/settings/presentation/screens/developer_options_screen.dart`
**Route:** `/developer-options`

Internal debugging toolkit, not intended for regular users.

- **Master Debug Logging** switch + **Debug Toast Messages** switch (only usable once logging is on) + **Log Retention** dropdown (500/1000/5000 entries) + **"Open Master Debug Log"** → `/master-debug-log`.
- **"Run System Health Check"** → runs a live diagnostic across Hive, the SMS pipeline, notifications, merchant rules, the pending queue, outings, and balances, then shows a pass/fail report per check.
- **SMS Detection Tools**: links to SMS Detection Rules, SMS Rules Storage, Detected SMS, SMS Detection Lab, Real-Time SMS Test.
- **Clear Transaction History**: 7 destructive one-tap actions (All / Debit only / Credit only / Transfers only / Auto-Detected only / Manual only / Pending Verification only) — each shows a live matching count and a confirmation dialog before deleting.
- **Quick SMS Test & Rule Creator**: paste a sample SMS to test parsing — note the "Create Test Rule from SMS" button is a stub that only shows an explanatory SnackBar, it does not actually create a rule.
- **"How SMS Detection Works"**: a static technical explainer of the internal pipeline architecture.
- **SMS Detection Debug Log panel**: live, refreshable list of the last ~40 detection events with level-coded status dots.
- **Disable App Rotation** switch — locks the whole app to portrait.
- **Full App Prompt / Specification**: the entire internal app-specification document, rendered as selectable text with a **"Copy to clipboard"** button — effectively a complete developer/AI-readable spec dump reachable from within the shipped app.

---

## 22. Mock / Placeholder Screens

These routes exist and render, but are **not wired to real data** — flagged here explicitly since the request was "nothing missing":

### Recurring (`/recurring`)
100% hardcoded: 4 fake upcoming bills (Rent ₹18,000, Netflix ₹649, Gym ₹2,500, Car EMI ₹4,000) and 2 fake "completed" ones (Spotify, Jio Recharge). The **"+" FAB does nothing** when tapped.

### Calendar (`/calendar`)
Static "April 2026" label that never changes; left/right month-navigation arrows do nothing; a fixed 30-cell grid marks a hardcoded set of days as "has expense" regardless of real data; the "Today" summary stats (Spent ₹1,827 / Earned ₹0 / Txns 3) are hardcoded, not computed.

### Search (`/search`)
Partially real: the text field and clear button genuinely work, and there's a real recent-vs-results UI switch. But the "Recent Searches" list is a hardcoded array (`Swiggy, Netflix, Rent, Amazon`), and **typing any query always returns the same 3 fake Swiggy transactions** — no real search against the transaction ledger happens here. (Real, working search exists inside the Activity screen via its search icon — see §7.)

### Export (`/export`)
Fully static: a fake "Last Backup: Today, 2:30 PM" status, and 5 action tiles (Export CSV/JSON/PDF, Backup Now, Restore Backup) whose taps **all do nothing** — no export or backup logic exists anywhere behind this screen.

> None of these four screens were found to have a discoverable in-app navigation entry point during this review (no menu item links to them) — they may be reachable from elsewhere not covered, or could be vestigial routes left over from an earlier design pass.

---

## 23. SMS Auto-Detection Pipeline (the core engine)

This is what makes SpentX "automatic" — it reads bank/UPI SMS and notification alerts, parses the transaction, and either auto-adds it or queues it for your confirmation.

```
┌─────────────────────────────────────────────────────────┐
│                   INBOUND SOURCES                        │
├──────────────┬──────────────┬──────────────┬───────────┤
│ Native SMS   │ Telephony    │ Notification │ WorkManager│
│ Broadcast    │ Receiver     │ Listener     │ Flush      │
└──────┬───────┴──────┬───────┴──────┬───────┴─────┬─────┘
       └──────────────┴──────────────┴─────────────┘
                              │
              SmsDetectionPipeline.processInbound() /
              processNotificationPayload()
                              │
              auto_detection enabled in Settings? ──No──→ dropped
                              │ Yes
              Dedupe check (recent hashes)
                              │
              SmsRuleEngine.parse() + block rules
              + BankSmsV4Parser (bundled bank templates)
                              │
              AutoRuleEngine (foreground or background)
                    ┌─────────┴─────────┐
                    ▼                   ▼
          KNOWN MERCHANT         UNKNOWN MERCHANT
          (rule match or          (no rule match)
           ATM pattern)
                    │                   │
                    ▼                   ▼
        Auto-add to ledger    Store in detected_sms_box
        + notification log    + queue for verification
        (type: sms_auto)      + system notification
                               (type: sms_pending)
                                        │
                                        ▼
                         PendingVerificationPresenter
                         → sequential Detection Popup
                           (Confirm / Ignore)
```

### Detection sources
| Source | Description |
|---|---|
| Native SMS broadcast | Android SMS broadcast receiver |
| Telephony inbox read | Via the `telephony` plugin |
| Notification listener | Reads bank app push notifications — **no SMS permission needed** for this path |
| Pending flush | Queued items processed on app resume |
| SMS Detection Lab | Manual paste-and-test tool (dev) |

### Auto-add vs. pending verification
A transaction is auto-added with **no user action needed** when: (1) the UPI ID or merchant name matches a saved merchant rule, (2) it matches a learned ATM-withdrawal pattern, or (3) it's a duplicate of an existing transaction (same reference ID or same amount+date). Everything else is stored as "pending" and surfaces via the Home banner and a Detection Popup, where you can edit amount/merchant/category/purpose/account, optionally link it to an active trip or a friend repayment, and optionally save a merchant rule so it auto-detects next time.

### Background processing
WorkManager runs a sweep **every 15 minutes** to catch SMS/notifications that arrived while the app was fully closed, auto-adding known merchants even without the app open. On app backgrounding, an immediate one-off background task is also queued.

---

## 24. Privacy Modes

There are **two independent** privacy layers:

### Private Mode
Toggle in Settings. Masks all monetary amounts on Home and Accounts with `*****`. Individual purpose types (e.g. "Family") can be selectively masked. Automatically disabled while Outing Privacy is active (the two are mutually exclusive at the UI level).

### Outing Privacy Mode
Only togglable while a trip is active (Settings, or the trip's own settings). When on: Home replaces its entire dashboard with a trip-only view (no net worth, no other balances/transactions visible), Activity filters to trip-only transactions, and Analytics scopes to the trip only. Turning it **off** requires PIN or profile-name confirmation — designed so a shared/borrowed phone can't casually reveal your real balances by tapping one switch, and so the person you're on the trip with can't see your full net worth if they use your phone during the trip.

---

## 25. Data Models

### Transaction
`lib/models/transaction.dart`

| Field | Type | Description |
|---|---|---|
| `id` | String (UUID) | Unique identifier |
| `merchant` | String | Payee/merchant name |
| `category` | String | Spending category |
| `account` | String | Bank/Cash account name |
| `amount` | double | ₹ amount |
| `isExpense` | bool | true = debit |
| `isAutoDetected` | bool | Added via SMS pipeline |
| `isTransfer` | bool | Account-to-account move |
| `outingId` | String? | Linked trip |
| `isAutoLinked` | bool | Auto-linked by date range |
| `rawIdentifier` | String? | UPI ID for merchant learning |
| `purpose` | String? | Personal/Family/etc. |
| `bankName`, `accountLast4` | String | From SMS |
| `referenceId`, `upiId` | String | UTR / VPA from SMS |
| `rawMessage` | String | Original SMS text |
| `note` | String | Free-text |
| `isPendingVerification` | bool | Unknown merchant flag |
| `isMerchantMapped` | bool | Whether a rule existed at add time |

### Account
`lib/models/account_model.dart` — `name`, `type` (Cash/Bank), `last4`, `openingBalance`, `imagePath?`.

### Merchant Rule
`lib/core/models/merchant_rule.dart` — `key` (normalized UPI/payee), `displayName`, `category`, `purpose`, `transactionType` (debit/credit).

### Outing family
`Outing` (id, title, dates, members, expenses, isActive, autoAddMode) · `OutingMember` (name, upiId) · `OutingExpense` (amount, merchant, paidBy, splitType, transactionId, date) · `SettlementPayment` (fromMember, toMember, amount, date).

### Pending Transaction
`lib/models/pending_transaction.dart`, `lib/features/sms/detected/pending_model.dart` — the intermediate record for a detected-but-unverified SMS transaction.

---

## 26. Hive Local Storage

Everything lives on-device in Hive boxes — there is no server and no cloud sync.

| Hive Box | Contents |
|---|---|
| `settings` | Profile, PIN flags, auto_detection, privacy, debug flags, accounts, purposes |
| `transactions` | All ledger entries |
| `outings` | Trip/group data |
| `friends` | Friend directory |
| `budgets` | Category budget limits |
| `investments` | Investment holdings |
| `categories` | Custom categories |
| `merchant_aliases` | Merchant alias mappings |
| `merchant_rules_box` | Learned merchant→category rules |
| `detected_sms_box` | Pending SMS verifications |
| `pending_detections` | Queue of IDs awaiting the verify popup |
| `ignored_detections` | User-ignored SMS |
| `notification_history` | In-app notification log |
| `pending_verification_history` | History of what's been verified |
| `sms_template_rules_box` | Custom SMS parsing templates |
| `block_rules_box` | SMS patterns to ignore |
| `detection_rules_box` | Custom detection logic |
| `ignored_sms_box`, `processed_sms_box` | Dedup hash sets |

---

## 27. Riverpod Providers Reference

| Provider | Responsibility |
|---|---|
| `transactionProvider` | Ledger CRUD, net worth calc, outing sync, budget alerts, friend settlement |
| `userStateProvider` | Profile, accounts, purposes, first-time flag |
| `outingProvider` / `activeOutingProvider` | Trips, expenses, settlements, auto-expire |
| `budgetProvider` / `budgetSpendInfosProvider` | Budgets + spend-vs-limit calc |
| `merchantProvider` | Merchant rule CRUD |
| `investmentProvider` | Investment holdings |
| `friendsProvider` / `manualFriendsProvider` / `friendUpiProvider` | Friend directory + UPI mappings |
| `categoryProvider` | Custom categories |
| `privateModeProvider` / `outingPrivacyModeProvider` / `effectivePrivateModeProvider` | Privacy state |
| `detectionQueueProvider` | Pending SMS ID queue |
| `settlementFeedbackProvider` | Friend-settlement snackbar trigger |
| `contactsProvider` | Device contacts for friend import |
| `netWorthProvider` | Derived total balance |
| `hasUnreadNotificationsProvider` | Bell badge state |
| `isOutingPrivacyActiveProvider` | Whether trip privacy is currently live |

---

## 28. Complete Route Table

| Route | Screen | Notes |
|---|---|---|
| `/` | Splash | App launch |
| `/onboarding` | Marketing carousel | First launch only |
| `/pin-setup` | PIN Setup | Onboarding / Settings |
| `/lock` | Lock Screen | Cold start / resume |
| `/home` | Main Wrapper (bottom nav shell) | Post-auth |
| `/activity` | Activity/Transactions | Tab 1 |
| `/accounts` | Accounts list | No nav tab — contextual only |
| `/account-detail/:name` | Account Detail | From Accounts |
| `/transaction/:id` | Transaction Detail | From anywhere |
| `/outing-expense/:outingId/:expenseId` | Transaction Detail (trip variant) | From trip activity |
| `/budgets` | Budgets | Home quick action |
| `/wealth` | Wealth | Home quick action |
| `/investments` | Investments | From Wealth |
| `/outings` | Outings list | Home / Settings |
| `/outing-detail/:id` | Trip Detail | From Outings list |
| `/friends` | Friends | Settings |
| `/notifications` | Notification History | Bell icon / Settings / Budgets |
| `/merchant-names` | Merchant Mappings | Settings |
| `/app-guide` | App Guide | Settings |
| `/developer-options` | Developer Options | Settings |
| `/sms-rules-storage` | SMS Rules Storage | Settings / Dev |
| `/master-debug-log` | Master Debug Log | Dev Options |
| `/sms-detection-lab` | SMS Detection Lab | Dev Options |
| `/real-sms-test` | Real-Time SMS Test | Dev Options |
| `/detected-sms` | Detected SMS | Dev Options |
| `/sms-activity` | SMS Activity | No nav link found |
| `/recurring` | Recurring (mock) | No nav link found |
| `/calendar` | Calendar (mock) | No nav link found |
| `/search` | Search (mostly mock) | No nav link found |
| `/export` | Export (mock) | No nav link found |

---

## 29. Known Issues, Dead Code & Non-Functional UI

Documented explicitly since the goal is "nothing missing":

- **Dark Mode switch** (Settings) — hardcoded `value: true, onChanged: (v) {}`. Does nothing.
- **"Primary Account" switch** on the unused `AccountConfigScreen` — same pattern, also dead.
- **`AccountConfigScreen`** (`lib/features/settings/presentation/screens/account_config_screen.dart`) — not registered in the router and not instantiated anywhere; fully dead code. The live equivalent is `PremiumSettingsScreen` (§20).
- **PIN setup silently force-enables fingerprint** the moment you set a PIN, regardless of device support or explicit user intent.
- **"Skip for now" text** on Onboarding Modal Step 1 has no tap handler.
- **Calendar screen's month arrows and month label** are non-functional/static; expense-dot data and "Today" stats are hardcoded, not computed from real transactions.
- **Recurring screen's "+" FAB** does nothing; entire screen is 4+2 hardcoded fake bills.
- **Search screen's results are always the same 3 fake transactions** regardless of what you type — only the recent-search-vs-results UI toggle is real. Real search lives inside the Activity screen instead.
- **Export screen's 5 action tiles are all no-ops** — no CSV/JSON/PDF export or backup/restore logic exists anywhere in the codebase yet.
- **Wealth screen's Cash/Bank balances use hardcoded base offsets** and can disagree with the real figures on the Accounts screen; **Wealth Goals are in-memory only** and reset on navigation.
- **Settings screen contains dead helper widgets** (`_AccountManagementSheet`, `_PurposeManagementSheet`, `_showBankPicker`, `_showPurposePicker`) that are defined but never called from the visible UI — legacy leftovers superseded by `PremiumSettingsScreen`.
- **Developer Options → "Create Test Rule from SMS"** is a stub — shows a SnackBar but doesn't actually create a rule.
- **The full internal app-specification document** is embedded and copyable directly from Developer Options → "Full App Prompt / Specification" — worth being aware this is one tap away for anyone with the installed app.
- **`/recurring`, `/calendar`, `/search`, `/export`, `/sms-activity`** — no in-app menu item linking to any of these was found during this review; they exist only as raw routes.

---

## 30. Implementation Maturity Summary

| Feature Area | Status |
|---|---|
| SMS auto-detection + verification | ✅ Production-grade — full pipeline, background + notification + foreground paths |
| Transactions & ledger | ✅ Fully functional |
| Accounts & balances | ✅ Fully functional |
| Budgets & alerts | ✅ Fully functional |
| Outings / trip splitting | ✅ Fully functional |
| Friends & repayments | ✅ Fully functional, including UPI auto-matching |
| Analytics | ✅ Fully functional |
| Investments | ✅ Functional (manual holdings + SMS-assisted allocation) |
| Auth / PIN / biometrics | ✅ Fully functional |
| Notifications history | ✅ Functional |
| Merchant learning | ✅ Functional |
| Wealth screen | ⚠️ Partial — mock balance offsets, goals not persisted |
| Calendar | ❌ UI mock only |
| Recurring | ❌ UI mock only |
| Export / Backup | ❌ UI only, no logic |
| Standalone Search screen | ❌ Mostly mock (real search exists in Activity) |
| Dark mode toggle | ❌ Non-functional, always dark |
| Account Config screen | ❌ Dead code, unreachable |

---

*This document reflects the SpentX Flutter codebase as of version 1.0.0+1, generated from a full read of the source (`lib/`) — every screen file listed in §28 was read directly, not inferred.*
