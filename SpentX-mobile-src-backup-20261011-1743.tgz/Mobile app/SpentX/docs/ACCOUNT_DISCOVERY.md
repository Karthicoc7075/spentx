# SpentX Mobile — Account Discovery (Manual vs SMS)

**Status:** implemented (Moments 1–3, Dart + Kotlin) — see §10 for what shipped
**Related:** `APP_CONCEPT.md` §4 (onboarding), §5 (Account model) · `SMS_DETECTION.md` §4 (bank allowlist)

---

## 0. The decision

> **Users own the account list. SMS owns discovery. Confirm once, then automatic.**

Not "user types everything" (too much work, Axio feels better).
Not "SMS creates accounts silently" (breaks net worth and the *never guess* rule).

**Hybrid: seed → suggest → confirm.**

| | Manual only (today) | Auto-create (Axio) | **Hybrid (this doc)** |
|---|---|---|---|
| Setup effort | High | Zero | Almost zero |
| Missed cards | Yes — SMS dropped | No | No — suggested |
| Junk / forwarded SMS accounts | No | Yes | No — user ticks |
| Real opening balance | Yes | No (fake net worth) | Yes — asked at confirm |
| Nickname, purpose, cash | Yes | No | Yes |

SMS can see: **bank name, last-4, card vs account wording, wallet sender, sometimes available balance.**
SMS can never know: **opening balance, nickname, joint/closed account, cash, whose phone the SMS was forwarded from.**

So SMS is allowed to *propose* an account. Only the user is allowed to *create* one.
This is the exact same loop SpentX already uses for merchants: first time human, after that machine.

---

## 1. The bug underneath the doubt

Today (`BankAllowlistService.allows()` — `SMS_DETECTION.md` §4):

```
accounts saved  →  message must match a saved bank token or a saved last-4
                →  otherwise REJECT, silently
```

So a user who added HDFC savings but forgot their ICICI credit card **never sees those spends and is never told why**. That is a silent data loss, and it is why the app feels worse than Axio.

New rule — the allowlist gets **four** outcomes, not two:

| Message | Today | New |
|---|---|---|
| Known bank token / known last-4 | detect ✅ | detect ✅ |
| Bank-shaped SMS, unknown last-4, never seen | **drop ❌** | **discovery candidate 🔎** |
| Bank-shaped SMS, last-4 the user ignored | drop | drop (silent, by block) |
| Not a bank SMS (OTP, promo, personal) | drop | drop |

Nothing about the parsing engine changes. Only the gate changes: reject → *route to discovery*.

---

## 2. Three moments where an account can appear

### Moment 1 — Onboarding (light seed)

Current step 1 is a wall: *"how many accounts?"*. Remove that wall.

```
Cash            → always created automatically, never from SMS, not editable away
Add an account  → existing form (name, type, opening balance + date, last-4)
Detect from SMS → skip typing, go to Moment 2
Skip for now    → allowed; app still works, discovery still runs later
```

The last-4 typed here still feeds the allowlist — that part of the current design is correct and stays.

### Moment 2 — First `READ_SMS` grant: scan inbox, write **nothing**

On first permission grant, scan the last **60–90 days** of SMS through the *existing* parser (`BankSmsV4Parser` + `SmsRuleEngine`), but with the account write path disabled.

Group hits by `bankToken + last4 + inferredType`:

| SMS evidence | Suggested type |
|---|---|
| `credit card`, `CC`, `card ending`, `card XX4821` | Credit |
| `a/c XX0034 debited`, `A/c no. XX0034` | Bank |
| Sender is PhonePe / Paytm / Amazon Pay wallet itself | Wallet |
| No last-4 at all | **not a candidate** — never suggest a bank-name-only account |

Show one screen — **"Accounts we found"**:

```
☑  HDFC Bank · XX4821 · looks like Credit Card     · 34 messages
☑  SBI · XX0034 · looks like Bank                  · 61 messages
       last SMS balance ₹41,630  (from SMS — not your opening balance)
☐  Federal · XX9902 · looks like Bank              · 2 messages
✔  Cash (already added)
```

- Ticked → open the normal account form **pre-filled** (name, type, last-4). User sets nickname + opening balance. Then it becomes a real `Account`.
- Unticked → written to the **ignore list** for that `bank+last4`. Never suggested again, never nags.
- Balance parsed from SMS is shown as a *hint only*, clearly labelled, and is **not** silently used as `openingBalance`.

### Moment 3 — Live SMS, after onboarding

A bank-shaped SMS arrives with a last-4 matching no account and no ignore entry:

```
New account detected
HDFC · XX2190 · looks like Credit Card
Debited ₹1,240 · today 4:12 PM
[ Ignore ]        [ Add account & verify spend ]
```

Flow:

1. User taps **Add** → confirm type / name / opening balance (optional).
2. `Account` created → its last-4 joins `allowed_banks_json`.
3. The same SMS is re-run through the normal pipeline → merchant verify or auto-add.
4. Next SMS to `XX2190` attaches with no prompt.

Tap **Ignore** → `bank+last4` goes to the ignore list; that account never asks again.

Show this next to the existing pending-SMS nudge on Home and inside **Detected SMS**. It must not be a full-screen interrupt.

---

## 3. New model — `PendingAccount`

Same pattern as `PendingTransaction`. **Local-only. Never enters `SupabaseSchemaMap`, never enters `SyncQueue`.**

```dart
// lib/models/pending_account.dart   (Hive box: 'pending_accounts')
class PendingAccount {
  String  id;              // '${bankToken}_$last4'  — deterministic, dedupes itself
  String  bankToken;       // 'hdfc'  (from bankTokenForAccountName / kKnownBankKeywords)
  String  displayBank;     // 'HDFC Bank'  — for the UI only
  String  last4;           // '4821'
  AccountType suggestedType;      // bank | credit | wallet
  double? lastSeenBalance;        // parsed 'avl bal', hint only
  DateTime? lastSeenBalanceAt;
  String  sampleSmsId;     // link into detected_sms_box for "show me the SMS"
  int     hitCount;        // how many SMS matched — sort by this, 1-hit = weak
  DateTime firstSeen;
  DateTime lastSeen;
  PendingAccountStatus status;    // suggested | ignored | converted
}
```

Ignore list = rows with `status: ignored`. Keep them (do not delete) — that is what stops the nagging.

**Never synced** because: it holds raw SMS provenance, and a half-guessed account has no business existing on another device. Only the confirmed `Account` syncs, through the existing `accounts` mapping (`name` / lowercase `type` / `last4` / soft delete) in `SYNC_WIRING.md`.

---

## 4. How a transaction picks its account

First hit wins. Never invent an account here.

1. **last-4 in account context** (`a/c`, `card`, `XX`, `acct`) **+ bank token** → that account.
2. **Bank token only**, and the user has **exactly one** account at that bank → that account.
3. Bank token matches, but the user has **two+** accounts at that bank → *pending transaction, ask which account*. Never guess, never merge.
4. No account match, but SMS is bank-shaped with a last-4 → **`PendingAccount` + pending transaction**, shown together.
5. Otherwise → default payment account (manual entries only), or drop.

---

## 5. Special cases (where Axio clones go wrong)

| Case | Rule |
|---|---|
| Same bank, two last-4s | Two accounts. **Never merge by bank name.** |
| Credit card vs savings, same bank | Type from SMS words (`credit card`, `CC`, `card ending`), user confirms. |
| ATM / CDM | Transfer Bank ↔ Cash. Cash exists because onboarding always creates it. Never a new account. |
| UPI paid from a bank account | Belongs to the **bank** account, not a new "GPay account". Only a wallet's own SMS suggests a Wallet. |
| Salary / NEFT credit | Income on that account. Not a new account. |
| Friend-forwarded bank SMS | It has a last-4 → becomes a suggestion → user unticks → ignored forever. This is exactly the case silent-create gets wrong. |
| Old / closed account SMS | Low `hitCount`, old `lastSeen` → sort to bottom, or hide behind "show older". |
| **iOS** | No SMS. Discovery UI hidden entirely, manual accounts only. Same screens otherwise. |

---

## 6. Code changes (files that already exist)

| File | Change |
|---|---|
| `lib/core/services/bank_allowlist_service.dart` | `allows()` returns an enum `AllowResult { allowed, discovery, blocked, notBank }` instead of `bool`. Unknown last-4 + bank-shaped → `discovery`, not `false`. |
| `lib/core/utils/bank_keywords.dart` | Reuse `bankTokenForAccountName()` for the SMS side; add `bankTokenForMessage()` + last-4-with-context extraction (regex already exists in the allowlist). |
| `allowed_banks_json` (SharedPreferences → Kotlin) | Add `ignored4: [...]` and `discovery: true`. Native must **forward** unknown-bank messages to the queue instead of dropping them, so background detection can still create suggestions with the app killed. |
| `SpentXDetectionPrefs.isMessageFromAllowedBank` (Kotlin) | Same three-way result. Unknown → enqueue with a `discovery` flag; Dart decides. |
| `lib/features/sms/…` detection pipeline | On `discovery`: parse for bank+last4+type only, write/update `PendingAccount`, do **not** create a transaction yet. |
| `lib/features/onboarding/` | Remove the "how many accounts" wall; always seed Cash; add **Detect from SMS** path. |
| New: `account_discovery_screen.dart` | "Accounts we found" review list (Moment 2), also reachable from Settings → Accounts → **Scan SMS for accounts**. |
| New: `pending_account_card.dart` | The inline suggestion in Detected SMS / Home nudge (Moment 3). |
| `lib/core/providers/` | `pendingAccountProvider` — suggestions, ignore, convert-to-account. |
| `lib/models/pending_account.dart` + Hive adapter | New box `pending_accounts`, registered in `main.dart`. |

Deliberately **not** touched: `SupabaseSchemaMap`, `SyncQueue`, the parser templates, merchant learning.

---

## 7. Build order

1. `PendingAccount` model + box + provider (no UI). Safe, additive.
2. Allowlist three-way result + Dart discovery write. Detection behaviour unchanged for known accounts.
3. Inline suggestion card (Moment 3) — smallest UI, biggest fix for the silent-drop bug.
4. Inbox scan + "Accounts we found" screen (Moment 2).
5. Onboarding rework (Moment 1) — do last, it touches first-run flow.
6. Kotlin discovery forwarding, so it works app-killed.

Steps 1–3 alone already close the "forgot to add my credit card" hole.

---

## 8. Axio parity vs SpentX difference

**Copy from Axio (must feel familiar):** SMS → amount, payee, account · first new merchant → verify → remember · after that silent add + notification · manual add for cash · daily/monthly spend, categories, budgets · on-device parse, SMS body never uploaded.

**Do not copy:** silent account creation, loans/FD marketplace, balance-from-last-SMS as truth.

| Axio | SpentX extra |
|---|---|
| Category only | **Purpose** (Personal / Family / custom), orthogonal to category |
| Silent account create | **Pending account + pending merchant** — never guess |
| Balance from last SMS | **True net worth**: opening balance + ledger + investments |
| Individual tracker | **Outings, friend splits, UPI repayment matching** |
| Spend shown as spend | **ATM/CDM as transfer**, not fake spend |
| — | PIN / biometric, Private Mode, Outing Privacy, local-first Hive |

---

## 9. Verification checklist (device)

- [ ] Fresh install, SMS permission granted → scan finds real accounts; **zero `Account` rows written before the user ticks**.
- [ ] Unticked suggestion never appears again, even after 20 more SMS from it.
- [ ] Ticked suggestion → pre-filled form → account created → last-4 present in `allowed_banks_json`.
- [ ] User with HDFC only: ICICI card SMS now produces a suggestion (today it is silently dropped).
- [ ] Two HDFC accounts with different last-4 stay two accounts; a bank-token-only SMS asks which one.
- [ ] Forwarded friend's bank SMS → suggestion, ignorable, never auto-created.
- [ ] ATM withdrawal → Bank→Cash transfer, no new account, "spent this month" unchanged.
- [ ] App killed: discovery still records suggestions via the native queue.
- [ ] `pending_accounts` appears in **no** Supabase table and **no** sync queue entry (check network inspector).
- [ ] iOS build: discovery entry points hidden, manual account flow intact.
- [ ] Extend `test/bank_allowlist_test.dart` for the new three-way result.


---

## 10. As-built notes

Implemented. Where the build differs from the design above, and why:

| Design said | As built | Why |
|---|---|---|
| `AccountType suggestedType` | `String suggestedType` | There is no `AccountType` enum in the app — `AccountModel.type` is a `String` (`Bank`/`Cash`/`Wallet`/`Credit`). Introducing one would have touched the sync map and every `type ==` comparison. |
| `PendingAccount` + Hive adapter | Plain class + `toJson`/`fromJson`, untyped box | The project registers **no** Hive adapters; every box holds JSON maps. This now matches `PendingTransaction` exactly, as §3 intended. |
| `AllowResult { allowed, discovery, blocked, notBank }` | `AllowResult { allowed, discovery, blocked }` | `notBank` and `blocked` had the same consequence at every call site. `allows()` is kept as a bool wrapper so existing callers are untouched. |
| Onboarding lives in `lib/features/onboarding/` | Changed `lib/features/auth/presentation/` | `lib/features/onboarding/` is **dead code** — every `onTap` is empty and nothing imports `OnboardingStep1`. The live flow is `onboarding_screen.dart` + `widgets/onboarding/`. |
| "Always seed Cash" as new work | Already true | `account_form_card.dart` already prepends a Cash account in both `_submit()` and `_skipRemaining()`. |
| Native must stop dropping unknown-bank SMS | Only the **notification listener** needed it | `SmsReceiver.kt` never consulted the allowlist — it forwards everything to Dart already. Only `SmsNotificationListenerService` dropped, so only that path changed. |
| `card XX4821` → Credit | Bare "card" → **Bank** | Debit-card POS messages also say "card". Guessing Credit would invent a second, wrongly-typed account for a card the user already has — the exact error this feature exists to prevent. Only explicit credit wording (`credit card`, `total amount due`, `card ending`) promotes the guess. |

**Moment 1 is a lighter touch than "remove the wall."** The count picker stays; a
`Detect from my SMS instead` action was added beside it, which seeds Cash, skips
the manual form, and lands on the discovery screen after onboarding. Ripping out
the count step is a first-run change with no test coverage behind it, so it was
left as a deliberate follow-up.

### Files

New: `models/pending_account.dart` · `core/services/account_discovery_service.dart` ·
`core/providers/pending_account_provider.dart` ·
`features/accounts/data/account_discovery_scan_service.dart` ·
`features/accounts/presentation/account_discovery_screen.dart` ·
`features/accounts/presentation/widgets/{pending_account_card, add_discovered_account_sheet, account_discovery_banner}.dart` ·
`test/pending_account_test.dart`

Changed: `core/utils/bank_keywords.dart` · `core/services/{bank_allowlist_service, auto_detection_native_sync}.dart` ·
`features/sms/detected/{sms_detection_pipeline, auto_rule_engine, detected_sms_screen, sms_lab_simulator, sms_background_init}.dart` ·
`features/auth/presentation/onboarding_screen.dart` ·
`features/auth/presentation/widgets/onboarding/account_count_card.dart` ·
`features/accounts/presentation/accounts_screen.dart` · `core/router/app_router.dart` ·
`main.dart` · `test/bank_allowlist_test.dart` · `NotificationListenerService.kt` ·
`SpentXDetectionPrefs.kt` · root `package.json`

Untouched, as promised: `SupabaseSchemaMap`, `SyncQueue`, the parser templates,
merchant learning.

### Checklist status

Automated (`npm run test:mobile-bank-allowlist`, `test:mobile-pending-account`):
the forgotten-card case, ignore-forever, bank-added-without-last-4, telecom noise
rejection, type inference, balance-as-hint, key stability, ignore persistence.

Still needs a device: every row of §9 that involves the real inbox, the
notification listener, or an app-killed run. None of that is covered by the
pure-Dart suites.
