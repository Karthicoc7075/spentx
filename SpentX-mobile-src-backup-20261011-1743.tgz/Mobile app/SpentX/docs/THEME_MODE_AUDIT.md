# Theme mode & text-color audit (Flutter mobile)

**Date:** 2026-07-25  
**Scope:** `Mobile app/SpentX/lib` only

## 1. Scenario confirmed: **B** (theme was actually switchable)

### Evidence

| Location | What it did (before fix) |
|----------|--------------------------|
| `lib/core/providers/theme_mode_provider.dart` | `StateNotifier` defaulted to **`ThemeMode.light`**, loaded/saved `app_theme_mode` (`'light'`\|`'dark'`) via SharedPreferences (outside Hive). `setDark(bool)` wrote prefs and flipped state. |
| `lib/main.dart` | `MaterialApp.router(theme: AppTheme.lightTheme, darkTheme: AppTheme.darkTheme, themeMode: themeMode)` where `themeMode` came from the provider — **not** hardcoded `ThemeMode.dark`. Also set `AppSurface.isDark = themeMode == ThemeMode.dark`. |
| `lib/features/settings/presentation/settings_screen.dart` | **Two** Dark Mode rows: (1) working `_SettingsSwitchItem` bound to `themeModeProvider.setDark`, (2) leftover static “Always on — SpentX is a dark-only app”. |
| Product docs (`hello.md`, `fullappworkflow.md`, `DEBUG_FIX_REPORT.md`) | Claimed always-dark / non-functional toggle — **stale vs code**. |

This is **not** system-brightness (`ThemeMode.system`). It was a real app-level light/dark switch, defaulting to **light** on first launch when prefs were empty — the worst default for an app whose widgets mostly assume dark surfaces.

### Not Scenario A alone

Many screens already branch on `isDark` / `Brightness.dark`. The catastrophic failures (white text on light scaffolds, etc.) match **true light mode** being active, not only light cards inside a dark app. (Light pastel cards with wrong text remain a secondary concern.)

## 2. Recommendation: **lock to dark-only**

Product already declared always-dark in multiple docs and Settings copy. Building full dual-theme polish across ~90 presentation files is a redesign, not a bugfix.

**Applied:**

1. `MaterialApp.themeMode` hard-locked to `ThemeMode.dark`.
2. Provider always yields `ThemeMode.dark`; migrates any stored `'light'` → `'dark'`.
3. `AppSurface.isDark` defaults to `true` and is forced `true` in root build.
4. Settings: single static “Always on” row; working toggle removed.
5. `lightTheme` + full light `ColorScheme` kept so re-enable is possible later without inventing tokens from scratch.

## 3. Theme system status

| Piece | Status |
|-------|--------|
| `AppTheme.darkTheme` | Complete Material 3 `ColorScheme.dark` + text/app bar/card/sheet/dialog/snackbar/switch |
| `AppTheme.lightTheme` | Complete `ColorScheme.light` (exists; unused while locked) |
| `AppColors` | Semantic + dark/light surface/text tokens |
| `AppSurface` | Static brightness-aware getters (default dark) |
| `AppTheme.textPrimary` / helpers | Convenience accessors for theme-aware colors |

## 4. Full presentation sweep inventory

Every file under `lib/features/*/presentation/` plus `lib/core/widgets/` was enumerated (90 files).  
⚠ = still contains `Colors.white` / `Colors.black` and/or unconditional-looking `AppColors.dark*` (many are inside `isDark ? … : …` branches and are **correct under dark lock**).

### core/widgets (17)
- glass_card, premium_widgets, shimmer_loading, transaction_tile — white/black shadows or on-brand icons
- Most others use `isDark` or theme text styles

### accounts (2)
- account_detail_screen, accounts_screen — selected-chip white / dark* with isDark branches

### analytics (1)
- analytics_screen — dark* with isDark branches

### auth (17)
- Onboarding cards (`account_*_card`, `purpose_type_card`, `summary_card`, `onboarding_modal`) deliberately dark elevated surfaces + white text (dark-only UI)
- splash / lock / auth_widgets — brand white on green/dark chrome
- biometric_unlock_badge — `AppColors.darkCard` (dark-only chrome)

### budgets, calendar, cash_reminder, export, investments, loans, notifications, plan, wealth
- Largely isDark-branched; budgets “Category” label fixed to `colorScheme.onSurface`

### friends (2)
- friends_screen heavy white/black + dark* with mixed isDark branches; avatar white on colored circle (OK)

### groups (11)
- outing_banner — white text on green gradient (intentional)
- sheets/dialogs — many isDark ternaries; privacy_unlock fixed to AppSurface

### home (2)
- home_screen, main_wrapper — extensive isDark ternaries; Quick Add subtitle + privacy banner fixed

### recurring (1)
- isDark ternaries with Colors.white*

### settings (7)
- settings_screen — isDark ternaries + white avatar on primary (OK); Dark Mode toggle cleaned
- developer/premium/sms storage — some pure-white debug text on dark cards

### sms (13 + detected outside presentation/)
- sms_rule_list / training form / template_training — fixed white → AppSurface/theme where used as body text
- remaining white on selected primary chips is intentional

### transactions (4)
- add_transaction_sheet — largest Colors.white/black volume, mostly isDark ternaries
- edit_transaction_sheet / transaction_detail — chips/titles made theme-aware

### onboarding (4)
- Mostly theme text; no raw white/black issues

## 5. Fixes applied this pass

| File | Change |
|------|--------|
| `theme_mode_provider.dart` | Default dark; migrate prefs; `setDark` no-op → always dark |
| `main.dart` | `themeMode: ThemeMode.dark`; `AppSurface.isDark = true` |
| `app_colors.dart` | `AppSurface.isDark` default `true` |
| `app_theme.dart` | `textPrimary` / `scaffoldBg` helpers + docs |
| `settings_screen.dart` | Remove working switch + duplicate; single “Always on” row |
| `main_wrapper.dart` | Quick Add subtitle → `onSurface` opacity |
| `home_screen.dart` | Privacy banner light-mode text used light secondary (not dark) |
| `privacy_unlock_dialog.dart` | PIN field/cancel → `AppSurface` |
| `groups_screen.dart` | Section title + calendar/chevron → theme-aware |
| `edit_expense_sheet.dart` | Labels/icons → theme-aware |
| `budgets_screen.dart` | Category label → `onSurface` |
| `edit_transaction_sheet.dart` | Title + account/purpose chips → isDark tokens |
| `transaction_detail_screen.dart` | Choice buttons → isDark tokens |
| `sms_rule_list_screen.dart` | Empty state → `onSurface` opacity |
| `sms_training_form.dart` / `template_training_screen.dart` | Result values → `AppSurface.text` |
| `transfer_bottom_sheet.dart` | Confirm label → `AppColors.onPastel` on green gradient |

### Left intentionally hardcoded

- **Brand / semantic:** `AppColors.primary`, income/expense greens/corals, pastel tints + `onPastel` / `onTint*`
- **White on brand green / avatar / FAB / swipe-delete:** correct contrast on fixed-color surfaces
- **outing_banner white on gradient**
- **Auth onboarding dark-elevated chrome** (product is dark-only)
- **isDark ? Colors.white* : Colors.black* branches** — valid while dual theme data exists; under lock only dark branch runs
- **Shadows** `Colors.black.withOpacity(0.0x)` — not text/surface contrast

## 6. Verification

1. Cold start: app must open in dark (no light flash after first frame).
2. Settings → Preferences → Dark Mode shows static “Always on” only (no switch).
3. SharedPreferences: any prior `app_theme_mode=light` rewritten to `dark` on launch.
4. Walk main tabs: Home, Transactions, Wealth, Outings/Groups, Plan/Budgets, Settings — body text legible on cards/sheets.
5. Open Quick Add, Add/Edit transaction sheets, Privacy unlock PIN dialog, Transfer sheet, SMS rules empty state.
6. Optional regression: temporarily set `themeMode: ThemeMode.light` in `main.dart` and spot-check; expect remaining isDark ternaries to still work on theme-aware screens; onboarding dark chrome may stay dark-on-purpose.

## 7. If light mode is ever re-enabled

1. Restore `themeMode: ref.watch(themeModeProvider)` (and real `setDark`).
2. Reintroduce Settings switch.
3. Finish converting remaining ⚠ files’ unconditional dark tokens / bare `Colors.white` body text to `AppTheme.*` / `colorScheme` / `AppSurface`.
4. QA every presentation file under light + dark.
