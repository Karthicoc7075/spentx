# SpentX Mobile — Supabase Auth Setup (Required Sign-In)

Signup/login is now **required**: the app cannot be used until the user has a
Supabase account and is signed in. PIN remains as a second, local lock behind
the Supabase session.

## One-time setup before building

1. **Paste project keys** — `lib/core/config/supabase_config.dart`:
   set `url` and `anonKey` to the same values the SpentX web app uses
   (shared project). Until then the app boots to `/auth` with a
   configuration notice and cannot proceed.
2. **`flutter pub get`** — `supabase_flutter: ^2.8.0` was added to pubspec.
3. **Supabase Dashboard → Authentication → URL Configuration → Redirect URLs**:
   add `spentx://reset-password` (the password-reset deep link; the Android
   intent filter is already in the manifest).
4. Reuse the existing web reset-email template as-is — nothing mobile-specific
   is needed.

## Flow (as implemented)

```
Splash
  → no Supabase session → /auth  (Sign Up / Log In / Forgot password)
  → valid session       → has_seen_onboarding?
                            false → /onboarding → /pin-setup → /home
                            true  → /lock (if PIN) → /home
```

- Router-level guard: every route except `/` and `/auth/*` redirects to
  `/auth` while signed out (covers deep links, not just cold start).
- Signup success → onboarding carousel (welcome moment) → PIN setup.
- Login success on a device that already onboarded → skips the carousel,
  straight to PIN/lock/home.
- App resume prompts **PIN only** — never a Supabase re-login; the session
  refreshes silently.
- Password reset: email link → `spentx://reset-password` → in-app
  "Set new password" screen → back to `/auth/login`.
- Sign Out (Settings → Security): ends the session only, local data stays.
- Reset App Data: wipes everything **and** signs out → next open is `/auth`
  (fresh-install experience).
- Different account signs in over existing local data → explicit dialog:
  **Keep local data** (it now belongs to the new account) or
  **Erase & start fresh** (local wipe that preserves the new session).
  Never a silent merge or silent wipe.

## Update needed in `build_mobile_supabase_sync.md` (doc lives outside this repo)

That doc's **Step 2 (Auth)** described sign-in as *optional, only to enable
sync*. Replace it with:

> **Step 2 — Auth (REQUIRED)**: Signup/login via Supabase Auth is mandatory —
> the app is unusable without a signed-in session (see `docs/AUTH_SETUP.md` in
> the mobile repo). Sync no longer needs its own sign-in step; it can assume a
> session always exists. PIN remains a local second lock only.

## Verification checklist (device required — cannot be run in this sandbox)

- [ ] Signed-out user sees `/auth` first; no route (incl. deep links) reaches app screens.
- [ ] Signup creates the auth user; confirm the shared `handle_new_user` trigger seeds `public.users` + defaults for a mobile-originated signup (same trigger/project as web).
- [ ] Login with correct credentials → returning device skips carousel → PIN/lock.
- [ ] Wrong credentials shows Supabase's real error message inline.
- [ ] Reset email arrives → tapping link on the phone opens the in-app set-new-password screen → new password works on next login.
- [ ] Sign out → `/auth`, local Hive/PIN data intact; same account signs back in → everything still there.
- [ ] Different account signs in → keep/erase dialog appears and does what it says.
- [ ] Backgrounding/resume prompts PIN only; session survives.
- [ ] Reset App Data ends signed out; reopening starts at `/auth`.
