# SMS Detection — How It Works

How SpentX turns an incoming bank SMS into a transaction. Covers every entry
path (live broadcast, notification listener, WorkManager drain, SMS Lab), the
parsing layers, the merchant-learning loop, and the foreground/background split.

**Platform: Android only.** There is no SMS code under `ios/` — iOS gives apps
no access to the SMS inbox, so detection is silently unavailable there.

---

## 1. The short version

```
Bank SMS arrives
   ↓
Native Android catches it (SmsReceiver / NotificationListenerService)
   ↓
Gates:  signed in? · auto-detection on? · from a bank the user added?
   ↓
Parse:  hard filters → block rules → v4 bank templates → user templates → regex rules → fallback
   ↓
Direction:  credit / debit / transfer (ATM, CDM)
   ↓
Payee extraction → merchant DB lookup
   ↓
KNOWN payee  → auto-add transaction  + "Added successfully" notification
NEW payee    → pending verification  + "Verify" notification
   ↓
User verifies once → merchant is learned → next time it auto-adds
```

The whole system is built around one idea: **the app never invents a merchant.**
The first time a payee is seen the user confirms it, and that confirmation is
stored as a rule. From then on the same payee is added automatically.

---

## 2. Android side (runs even when the app is killed)

Declared in `android/app/src/main/AndroidManifest.xml`:

| Permission | Why |
|---|---|
| `RECEIVE_SMS` | Live SMS broadcast |
| `READ_SMS` | Reading the inbox (backlog scan, SMS Lab) |
| `POST_NOTIFICATIONS` | Detection notifications |
| `RECEIVE_BOOT_COMPLETED` | Re-arm after reboot |
| `SCHEDULE_EXACT_ALARM` / `USE_EXACT_ALARM` | SMS Lab scheduled replays |

### Components

**`SmsReceiver.kt`** — a `BroadcastReceiver` on
`android.provider.Telephony.SMS_RECEIVED`, guarded by
`android.permission.BROADCAST_SMS`.

1. Bails out immediately if `SpentXDetectionPrefs.isAutoDetectionEnabled()` is false.
2. Rebuilds each message from its PDUs (`sender`, `body`).
3. If the Flutter `EventChannel` sink is alive → pushes straight to Dart.
4. If not (app killed, engine not ready) → `SmsPendingQueue.enqueue(...)`.

**`SmsPendingQueue.kt`** — a bounded (max 50) JSON queue stored under
`FlutterSharedPreferences` key `flutter.native_sms_queue`. It deliberately uses
the `flutter.` prefix so the **WorkManager Dart isolate**, which has no
`MainActivity` MethodChannel, can drain it directly through `shared_preferences`.

**`SmsNotificationListenerService.kt`** — a `NotificationListenerService`, the
backup path for when the SMS broadcast is unavailable (dual-SIM quirks, OEM
restrictions, bank-app notifications). It:

- requires both `auto_detection` and `background_detection_enabled`,
- only accepts notifications from messaging apps
  (`com.google.android.apps.messaging`, `com.android.mms`) or packages whose
  name looks like a bank,
- requires a real **transaction verb** (`credited`, `debited`, `spent`,
  `withdrawn`, `sent to`, `paid to`, …). A currency amount alone is not enough —
  `"Bal has gone below minimum limit of INR 5,000.00"` and `"Rs899_90D_2GB"`
  both contain one and move no money,
- extracts amount / merchant / bank / type / mode natively,
- if the app is in the foreground → `LocalBroadcastManager` broadcast,
- otherwise → `TransactionPendingQueue.enqueue(...)` **and posts the system
  notification itself**, so the user sees the spend within seconds even with the
  app fully closed.

**`SpentXDetectionPrefs.kt`** — the native mirror of Dart state. Reads
`flutter.auto_detection`, `flutter.background_detection_enabled`,
`flutter.allowed_banks_json` and `flutter.known_merchants_json` out of
SharedPreferences, so native code can apply the same gates and even resolve a
saved merchant title for the notification before Dart ever wakes up.

**`MainActivity.kt`** — hosts the bridges:

| Channel | Kind | Purpose |
|---|---|---|
| `com.spentx.app/sms` | EventChannel | Live SMS stream → Dart |
| `com.spentx/notifications` | EventChannel + MethodChannel | Notification payloads, cold-start payload |
| `com.spentx.app/permissions` | MethodChannel | `getInboxSms`, `getPendingSms`, `getPendingTransactionPayloads` |
| `com.spentx.app/sms_lab` | MethodChannel | Scheduled SMS Lab replays |

---

## 3. Entry paths into Dart

Everything funnels into **one** function:
`SmsDetectionPipeline.processInbound(...)` (`lib/features/sms/detected/sms_detection_pipeline.dart`).

`SmsDetectionSource` records which door it came through:

| Source | Origin | File |
|---|---|---|
| `smsBroadcast` | Native `SmsReceiver` via EventChannel | `lib/features/sms/sms_service.dart` |
| `telephony` | `telephony` plugin listener (alternate/backup) | `lib/features/transactions/data/sms_receiver_service.dart` |
| `notification` | Notification listener payload | `SmsDetectionPipeline.processNotificationPayload` |
| `pendingFlush` | Native queue drained on app start / WorkManager | `SmsService.flushPendingQueue`, `BackgroundSmsProcessor` |
| `lab` | SMS Detection Lab manual replay | `sms_detection_lab_screen.dart` |
| `debug` | Developer options | — |

Having a single entry point is the point: every gate below is applied once and
applies to all sources, so the broadcast path can never detect something the
notification path would drop.

---

## 4. Gates — before anything is parsed

Applied in `processInbound`, in this order:

1. **Signed in.** `AuthService.isSignedIn` must be true. A detected spend has to
   belong to an account, and a signed-out device must never read SMS. Even
   `forceProcess` (SMS Lab replay) respects this.
2. **Auto-detection on.** Hive `settings.auto_detection` (default `true`,
   toggled in Settings, mirrored to native by `AutoDetectionNativeSync`).
3. **Non-empty body.**
4. **Duplicate guard.** In-memory key `bodyHash_sender_minute`, last 80 kept.
5. **User block rules.** `SmsRuleEngine.isBlocked` — regex, keyword-contains, or
   fuzzy similarity score against the user's saved block rules. Blocked messages
   are recorded in the `ignored_sms` box with a reason.
6. **Bank allowlist.** `BankAllowlistService.allows(body)`.

### The bank allowlist

*"Only detect SMS from banks the user actually added."*

`lib/core/utils/bank_keywords.dart` holds the single keyword list
(`kKnownBankKeywords` — hdfc, icici, sbi, axis, kotak, …). Each saved account is
resolved down to **one match token** plus a **last-4**:

- `bankTokenForAccountName()` prefers a known bank keyword, else falls back to
  the longest non-generic word in the account name (so "Slice", "Bandhan Salary"
  still match; "My Savings Account" contributes only its last-4).
- `messageMatchesAllowedBank()` tests the message for a whole-word token match,
  or a last-4 **in an account context** (`a/c`, `card`, `XX`, `acct` …) — a bare
  `0034` could be anything.

Dart writes `{tokens:[...], last4:[...]}` to `allowed_banks_json`, so the Kotlin
side (`SpentXDetectionPrefs.isMessageFromAllowedBank`) never has to duplicate the
keyword list.

Fail-safe behaviour, both directions:

| State | Result |
|---|---|
| Key never synced (fresh install) | **Allow** — new users still see detection |
| Settings box not open (early background isolate) | **Allow** — Dart filters still apply downstream |
| Accounts saved but all cash-type | **Reject** — no bank SMS can be theirs |
| Malformed payload | **Allow** — a bad write must not silently kill detection |

---

## 5. Parsing — `SmsRuleEngine.parse()`

`lib/features/sms/rules/engine/sms_rule_engine.dart`. Layers, first hit wins:

**Step 0 — hard filters** (`SmsTransactionFilters`)

- `isFailedTransaction` — "failed", "declined", "insufficient funds" *plus* a
  transaction cue, so "failed delivery" promos aren't dropped for the wrong reason.
- `isAdvertisement` — promo keywords with no debit/credit cue.
- `isNonTransaction` — balance inquiries ("avl bal", "subject to clearing"),
  plus everything `SmsClassifier` labels as `otp`, `bankingInfo`,
  `accountUpdate` or `promotional`.

`SmsClassifier` (`lib/features/sms_parser/sms_classifier.dart`) buckets a message
into `financialTransaction | accountUpdate | promotional | otp | bankingInfo`,
checked in that order, defaulting to `bankingInfo` (i.e. *ignore*) when unsure.

**Step 1 — user block rules** (again, since `parse` has callers other than the pipeline).

**Step 2 — bundled v4 bank templates.** `assets/sms/bank_sms_templates_v4.json`
is the production catalog: **45 banks, 505 templates**, loaded once by
`BankSmsTemplateCatalog` and cached in `BankSmsV4Parser`. Each template carries
a human-readable `template`, a `templatePattern` with `{AMOUNT}` / `{TITLE}` /
`{ACCOUNTLAST4}` slots, `keywords`, per-field `extractors` (regex or positional)
and a `similarityThreshold`. Types `advertisement` and `failed_transaction` are
skipped at load.

**Step 3 — user-trained template rules** (Hive `template_rules`, trained in-app
or pulled from the backend).

**Step 4 — regex / keyword rules** (Hive `regex_rules`; supports
`matchPattern`, `containsKeywords`, `excludeKeywords`, and per-field patterns).

**Step 5 — fallback parser** (`UniversalSmsParser`) plus
`BankTitleExtractor.enrich` for bank-specific title cleanup.

### How a template matches

`SmsTemplateEngine.tryMatchAgainstRules` scores every rule and keeps the best:

```
similarity = keywordScore * 0.4  +  structuralScore * 0.6
```

`structuralParts` are the literal fragments left after stripping `[Amount]`,
`[Title]`, `[Date]` … out of the template. A rule is considered when **any** of:

- `similarity >= rule.similarityThreshold` (default 0.65), or
- bank name matched **and** `similarity >= 0.35`, or
- every keyword present **and** `similarity >= 0.25`.

A bank-name match adds `+0.15` to the ranking score. Extraction then runs:
tagged/positional values first, field regex second, rule defaults last. **If no
amount is extracted, the match is discarded** — an amount is mandatory.

Date resolution order: parsed date + parsed time → parsed date + SMS time →
SMS received time → now.

Every parse result passes through `_finalizeParsed`, which re-derives direction
from the raw text and records `lastParseDebug` (detected title, type, matched
template/rule, source) for the SMS Lab.

---

## 6. Direction — credit vs debit vs transfer

`lib/features/sms_parser/sms_direction_helper.dart`. **Raw-message keywords
always beat the template's declared type**, so a mis-trained debit template can
never book a credit SMS as a spend.

- **Credit** — `credited`, `credit alert`, `received from`, `added to your account`, …
- **Transfer** — `withdrawn`, `atm w/d`, `atm` + `withdraw`/`cash`
- **Debit** — `debited`, `spent at`, `paid to`, `sent to`, `purchase`, …

Two subtleties worth knowing:

**Cash deposit at an ATM/CDM** is a *transfer* (Cash → Bank), not income. It only
fires when deposit-language **and** machine-language are both present
(`isCashDepositAtSelfMachineSms`) — a salary SMS also says "deposited" but never
mentions the machine.

**Third-party NEFT/IMPS.** Bundled templates type these as `transfer`, but they
are payments to someone else, not a self-transfer. So in
`SmsMerchantMatcher.resolve`, when the direction came from a template rather
than a raw-keyword match, it is only trusted as a transfer if the extracted
payee matches one of the user's **own registered accounts**
(`SelfAccountMatcher`). Otherwise it is downgraded to an expense.

ATM withdrawal (Bank → Cash) and cash deposit (Cash → Bank) share a direction but
move money the opposite way, so each gets its own rule-learning bucket
(`SmsAtmHelper.ruleIdentifier`) and its own from/to account pairing
(`bank_to_cash` vs `cash_to_bank`).

---

## 7. Payee extraction and merchant matching

**`PayeeExtractor`** (`lib/features/sms/v4/payee_extractor.dart`) runs an ordered
list of regexes — first match wins — covering:

- salary/payroll `for TPT-…-COMPANY NAME`
- HDFC UPI-app style `To NAME On DD-MM-YY` (multiline)
- `to VPA merchant@bank`
- `debited/paid/sent/transferred to NAME` (verb-anchored, so "subject to
  clearing" never becomes a payee)
- `credited/received from NAME`
- card POS `At MERCHANT On <date>`

The result is validated against a blocklist (`unknown`, `hdfc bank`, `clearing`,
`balance`, `ref`, `cheque`, …) and a 2–80 char length bound. It **never** returns
a training-sample placeholder — only text from the live message.

**`PayeeNormalizer`** lowercases, collapses whitespace and strips everything
outside `a-z0-9@._-` to produce the lookup key.

**`MerchantMatchResolver`** looks that normalized payee up in
`MerchantLearningService` (Hive `merchants_box`). A hit returns the saved title,
category and purpose. A miss returns the raw payee with category `Other`.

**`MerchantRuleService`** (Hive `merchant_rules_box`) is the identifier-keyed
layer: UPI IDs, phone numbers and account-like identifiers. Lookup **never** uses
display names — only stable identifiers — so renaming a merchant can't
accidentally match unrelated transactions. UPI/phone rules with
`transactionType: any` match both debits and credits.

Both stores serialize their writes behind a lock and expose `dedupe()`, because a
bulk backlog scan could otherwise double-insert the same merchant.

---

## 8. Foreground vs background

`AppForegroundDetector.isInForeground` is true only when the lifecycle state is
`resumed` **and** a live `WidgetRef` + mounted `BuildContext` are bound.

### Foreground — `AutoRuleEngine.handleForeground`

| Situation | Behaviour |
|---|---|
| Known merchant | Auto-add through Riverpod, ledger updates instantly |
| Active outing/trip running | Auto-add and attach to the trip — payee straight off the SMS, purpose `Outing`, `isMerchantMapped: false` so a later rename still teaches a rule |
| New payee | Verification popup (`PendingVerificationPresenter`) |

The trip case is worth calling out: a running trip adopts every spend it sees,
known merchant or not. Nothing about detection is loosened to get there — block
rules, the bank allowlist and the non-transaction filter have all already run,
and `ActiveOutingHelper.resolve` leaves `outingId` null for anything but a plain
expense, so income, ATM withdrawals and cash deposits still take the verify path.

### Background — `AutoRuleEngine.handleBackgroundSms`

| Payee state | Action | Notification |
|---|---|---|
| **New** | `PendingTransaction` saved to Hive. **Never auto-added.** | `💸 Spent ₹X` / `New merchant detected. • Verify` |
| **Known** | `Transaction` written to Hive + queued for sync | `💸 Spent ₹X` / `<Title> • Added successfully.` |
| **Active trip** | Auto-added to the trip | `🏖 <Trip>` / `Spent ₹X • Added to Outing` |

Copy lives in one place — `SmsNotificationCopy.build()` — and the Kotlin listener
mirrors it, so a natively-posted notification reads the same as a Dart one.

Because both the native listener and Dart can produce a notification for the same
SMS, ids are reused deliberately: same channel + same id means the "Verify"
notification is **replaced** by "Added successfully" rather than stacking a stale
prompt beside it.

### Duplicate protection

Four independent layers:

1. In-memory recent-hash set in the pipeline (`body_sender_minute`).
2. `_isDuplicate(refId, amount, date)` against saved transactions.
   A *pending* item is deliberately **not** treated as a duplicate — otherwise the
   verify popup could never open.
3. `_findExistingPendingId(...)` reuses an existing pending instead of creating a
   second one (and a second notification).
4. `_findPendingIdForRawMessage(rawMessage)` — a byte-for-byte fallback for when
   the native payload and the Dart parse produced different amounts/refs for the
   same message.

Verified reference ids are also written to `processed_sms_box`.

---

## 9. WorkManager — the killed-app path

`lib/features/sms/background/`

```
SmsReceiver          → SmsPendingQueue          (raw SMS body)
NotificationListener → TransactionPendingQueue  (parsed JSON) + system notification
                 ↓
WorkManager Dart isolate (no UI)
   BackgroundSmsProcessor.processAllQueued()
   ↓
App open / notification tap → verification popup
```

- `BackgroundSmsScheduler` registers two periodic tasks at Android's 15-minute
  minimum: `spentx.processSmsQueue` (no network required) and
  `spentx.syncDataQueue` (network required), plus one-off variants fired when the
  app pauses. `cancelAll()` runs on sign-out — a logged-out device never wakes an
  isolate.
- `BackgroundSmsProcessor` drains both queues. It tries the MethodChannel first
  (works when the UI engine is alive) and falls back to reading SharedPreferences
  directly — the only route available inside the isolate.
- `SmsBackgroundInit.ensureReady()` is the isolate's minimal bootstrap: Hive init,
  open every box, run migrations, load v4 templates, seed bundled rules, dedupe
  merchant stores.

---

## 10. Storage

| Hive box | Contents |
|---|---|
| `settings` | `auto_detection`, `onboardingAccounts`, notification tap target, rules-refresh timestamp |
| `transactions` | Saved transactions (auto-added and verified) |
| `detected_sms_box` | `PendingTransaction` records awaiting verification |
| `pending_detections` | Id-only queue driving the Detected SMS screen |
| `merchants_box` | Payee-keyed learned merchants (`MerchantLearningService`) |
| `merchant_rules_box` | Identifier-keyed rules (`MerchantRuleService`) |
| `template_rules` / `regex_rules` / `block_rules` | SMS rule sets |
| `processed_sms_box` / `ignored_sms` | Audit trail — what was parsed, what was dropped and why |
| `notification_history`, `pending_verification_history` | In-app notification + verification log |

SharedPreferences mirrors (for native): `auto_detection`,
`background_detection_enabled`, `allowed_banks_json`, `known_merchants_json`,
`native_sms_queue`, `native_tx_queue`.

---

## 11. The learning loop

1. New payee → pending + "Verify" notification.
2. User taps → `NotificationClickHandler` → `PendingVerificationPresenter` opens
   the exact item by id (the tap target survives a cold start via the `settings`
   box, since providers reset).
3. User confirms title, category, purpose and account.
4. `DetectionQueueNotifier.verify(...)`:
   - writes the `Transaction` (single write path, replace-by-id),
   - removes the pending record and marks history verified,
   - records the reference id in `processed_sms_box`,
   - **learns the merchant**: `MerchantLearningService.saveVerified` +
     `MerchantRuleService.learnRule`, or `learnAtmRule` for ATM/CDM transfers.
5. `AutoDetectionNativeSync.syncMerchantsToNative()` mirrors the rule to native,
   so the *notification itself* can show the saved title next time.
6. Next SMS from that payee → auto-added, no prompt.

`flushDeferredAutoAdds` handles the in-between case: known merchants detected in
the background are committed to the ledger when the app next comes to the
foreground.

---

## 12. Admin-managed rules (pull-only)

`SmsRulesRefreshService` fetches `sms_template_rules`, `sms_detection_rules` and
`sms_block_rules` from Supabase and re-caches them into Hive. Refresh runs at most
daily (`refreshIfStale`) or on demand from Developer Options.

This is **one-way**: those tables are admin-write-only (RLS lets authenticated
users read), and the app never writes to them. It is completely separate from the
bidirectional user-data sync queue. Merchant rules stay user-owned and local — the
refresh never touches them.

---

## 13. Testing and debugging

**Unit tests** (`test/`, plain `flutter test`):
`bank_allowlist_test.dart`, `sms_transfer_direction_test.dart`,
`sms_notification_copy_test.dart`.

**Scripts** (`tool/`, run with `dart run`):
`test_sms_classification.dart`, `test_hdfc_card_sms.dart`, `test_payee.dart`,
`test_background_pending_flow.dart`.

**SMS Detection Lab** (`lib/features/sms/detected/sms_detection_lab_screen.dart`)
— paste or replay a real SMS through the exact production pipeline
(`SmsDetectionSource.lab`) and watch every stage: which template matched, the
extracted fields, the direction decision, and the auto-add vs pending branch.
`SmsLabScheduler` / `SmsLabAlarmReceiver` can fire a replay on a delay to test the
killed-app path for real.

**Debug logs**: `SmsDetectionDebugLog` (per-SMS trace with level, source and raw
preview) and `MasterDebugLog` (cross-module timeline). Both are toggled in
Developer Options.

---

## 14. File map

```
android/app/src/main/kotlin/com/spentx/app/spentx/
  SmsReceiver.kt                      SMS broadcast → Dart or queue
  SmsPendingQueue.kt                  Raw SMS queue (SharedPreferences)
  NotificationListenerService.kt      Notification path + native notification
  TransactionPendingQueue.kt          Parsed payload queue
  SpentXDetectionPrefs.kt             Native mirror of gates + merchant titles
  MainActivity.kt                     Method/Event channels
  SmsLabScheduler.kt · SmsLabAlarmReceiver.kt · LabNotificationHelper.kt

lib/features/sms/
  sms_service.dart                    EventChannel listener + queue flush
  sms_notification.dart               Local notification plumbing
  sms_notification_copy.dart          Single source of notification copy
  core/
    sms_parser_service.dart           Parse + merchant match in one call
    sms_pending_service.dart          Pending store + tap target
    app_foreground_detector.dart      Foreground vs background
    sms_notification_handler.dart     Verify / Added notifications
    sms_verification_service.dart
  detected/
    sms_detection_pipeline.dart       ★ single entry point + gates
    auto_rule_engine.dart             ★ auto-add vs pending branch
    sms_merchant_matcher.dart         Direction + merchant resolution
    detection_queue.dart              Verify → save → learn
    pending_verification_presenter.dart · detection_popup.dart
    self_account_matcher.dart · sms_atm_helper.dart · active_outing_helper.dart
    detected_sms_storage.dart · sms_background_init.dart
    sms_detection_lab_screen.dart · sms_lab_simulator.dart
  rules/engine/
    sms_rule_engine.dart              ★ layered parse
    sms_template_engine.dart          Similarity match + extraction
  v4/
    bank_sms_v4_parser.dart · bank_sms_template_catalog.dart
    payee_extractor.dart · payee_normalizer.dart
    merchant_match_resolver.dart · merchant_learning_service.dart
  background/
    background_sms_processor.dart · background_sms_scheduler.dart
    workmanager_entrypoint.dart · background_sms_coordinator.dart

lib/features/sms_parser/
  sms_parser.dart                     Universal fallback parser
  sms_classifier.dart                 Transaction vs OTP/promo/info
  sms_transaction_filters.dart        Hard ignore filters
  sms_direction_helper.dart           Credit / debit / transfer
  bank_title_extractor.dart

lib/core/
  utils/bank_keywords.dart            Bank tokens + allowlist test
  services/bank_allowlist_service.dart
  services/auto_detection_native_sync.dart
  services/merchant_rule_service.dart · merchant_identifier_resolver.dart
  services/auth_gated_services.dart   Start/stop everything on auth change
  sync/sms_rules_refresh_service.dart Pull-only admin rules

assets/sms/bank_sms_templates_v4.json  45 banks · 505 templates
```

---

## 15. Privacy and safety properties

- **No session, no detection.** `SmsDetectionPipeline.isAutoDetectionEnabled`
  checks `AuthService.isSignedIn` first, and it is the single chokepoint every
  path funnels through. `AuthGatedServices` additionally refuses to even *request*
  SMS permission before sign-in, and stops every listener and WorkManager job on
  sign-out.
- **SMS bodies never leave the device.** Parsing is entirely local; only the
  resulting transaction syncs. Rule refresh is download-only.
- **Only the user's own banks.** Enforced identically in Dart and Kotlin from one
  shared token list.
- **Never auto-add an unknown payee in the background.** Only an explicit
  verification, or a merchant already learned from one, creates a transaction
  without the user looking at it.
