# SpentX Mobile — Supabase Sync Wiring (Local-First)

Wires Home, Transactions, Analysis, Outings, Friends, Settings to Supabase.
Hive remains the ONLY read layer the UI renders from; Supabase is the durable
source every local write eventually reaches.

## Architecture

```
UI  ──reads──►  Hive (always, offline-capable)
User write ──► Hive first ──► SyncQueue (Hive box 'sync_queue')
                                   │  pushPending() — drains when online
                                   ▼
                               Supabase  ──pullAll()──►  merged into Hive
```

- **`lib/core/sync/supabase_schema_map.dart`** — ✅ now built against the
  REAL web schema (web repo `docs/DATABASE_SCHEMA.md` + `init.sql`), not
  guesses. Key real-schema facts honored: transactions use
  `total_amount`/`type`/`payment_method`/`account_id` (uuid FK) with
  purpose+category on `transaction_splits` (name-keyed categories); accounts
  use lowercase `type`/`last4` with soft-delete; purposes are uuid rows
  resolved by name (`RemoteIdCache`); outings use `status`/`auto_add_mode`
  with member objects; expense `split_type` is text with a `splits` jsonb;
  settlements are outing-level from/to member rows (mobile per-expense
  payments carry `note: "exp:<id>"` to round-trip; web-created ones apply
  FIFO on pull); users share `private_mode` + `default_account_id`.
  SMS metadata (bank/last4/upi/transfer flags) rides in `tags`; raw SMS text
  is intentionally never uploaded. Account/friend deletes are SOFT deletes
  (`is_active=false`) matching web semantics and the transactions FK.
- **`sync_queue.dart`** — persisted queue; upserts coalesce per record;
  deletes supersede queued upserts; failed pushes stay queued for retry.
- **`sync_service.dart`** — push + pull orchestration:
  - Transactions pull: rolling window `transaction_date >= now - 35 days`
    (30 + buffer). Nothing already cached is pruned — the window governs
    what's actively pulled, not what may exist locally.
  - Accounts / outings (+expenses +settlements) / friends / users shared
    fields: full pull, no windowing (small datasets).
  - Pull merge NEVER overwrites a record with queued local edits.
  - `fetchTransactionRange(from, to)` — on-demand older-history fetch that
    progressively extends the offline cache.
  - Triggers: after login (AuthFlow), app start (if signed in), every
    resume (self-throttled to 2 min), periodic 15-min timer, and a
    fire-and-forget push after every enqueue.
- **`sms_rules_refresh_service.dart`** — PULL-ONLY admin data path.
  `sms_template_rules` / `sms_detection_rules` / `sms_block_rules` are
  fetched (never written), overwrite the local rule boxes (only after a
  successful non-empty fetch), then `SmsRuleEngine.init()` +
  `BankSmsV4Parser.ensureLoaded()` re-run so changes apply mid-session with
  no restart. Auto-refresh daily + manual "Refresh Detection Rules" in
  Developer Options. Merchant rules are user-owned and untouched by this.

## Write-path hooks (Hive-write-then-enqueue)

- Transactions: add / update / delete / outing-link / bulk clear
  (provider) + the background SMS auto-add path (`AutoRuleEngine`).
- Outings: every mutation funnels through `_putAndSync` (create, edit,
  end, expire, expenses, settlements); delete removes children remotely too,
  and upserts prune remote children removed locally.
- Friends: `addFriend` enqueues name+phone only.
- Accounts: add / update / delete / onboarding completion.
- Users row (shared subset): `private_mode` (via PrivateModeService) and
  `default_account` (pull-applied to settings). PIN, biometrics,
  SMS-detection toggle, and debug flags are local-only by construction —
  they have no schema-map entry and cannot enter the queue.

## Screen behavior

- **Home / Detail / Analysis**: render from Hive exactly as before — no
  spinners; sync keeps the boxes current underneath.
- **Activity**: "Load older transactions" footer fetches the next ~30-day
  slice older than the oldest cached row and caches it (offline → clear
  message instead of silence). Search results carry a note that search
  covers the cached window.
- **Analysis**: switching to Month/Year triggers `_ensureRangeCached` —
  fetch-then-compute rather than silently charting partial data; offline
  shows a message.
- **Friends**: contact rows now open a PRE-FILLED confirm form (no silent
  import); phone-number dedup runs before the form and again at save; only
  the explicitly-saved name+phone are synced — the contact list never
  leaves the device.

## Before running

1. Correct `supabase_schema_map.dart` against the real schema (10 minutes
   with the web app's SQL in hand).
2. Ensure RLS on the six user-data tables scopes rows by `user_id`, and the
   three rule tables keep admin-write / authenticated-read.
3. `flutter pub get` (no new deps — reuses supabase_flutter, flutter_contacts,
   permission_handler).

## Onboarding gate (server-side) — fix for the re-run/zero-show bug

Whether onboarding runs is now decided by `AuthService.accountHasExistingData()`
— count queries on transactions (>0), accounts (>1), purposes (>1), i.e.
"anything beyond the handle_new_user seed" — never by the local
`has_seen_onboarding` flag alone:

- **Fresh login/signup** (`AuthFlow`): always asks the server; a cached
  "false" is never trusted across devices. Existing account → local flag set,
  onboarding skipped, sync pull populates Hive.
- **Session restore** (Splash): a cached `true` (`settings.account_has_data`)
  short-circuits with no network call; an unresolved flag re-checks the
  server once.
- **Defensive layer**: `completeOnboarding` now MERGES accounts/purposes by
  name (never duplicates "Personal"/"Cash"), and all deterministic remote ids
  are (user, name)-scoped — even a double-run cannot create duplicate seed
  rows server-side (it upserts the same row).
- **Zero-display**: if transactions still show zero for an existing account
  AFTER confirming onboarding was skipped, that is a distinct sync-pull bug —
  trace `_pullTransactionsWindow` / column names in the schema map. Also
  remember the pull window is 35 days: an account whose newest transaction is
  older than that legitimately shows an empty recent view until "Load older"
  is used.

## Device verification checklist

- [ ] Airplane mode: Home/Activity/Detail/Analysis render cached data, no spinners.
- [ ] Fresh sync holds ~35 days of transactions (compare counts vs Supabase).
- [ ] "Load older" fetches + caches when online; clear offline message otherwise.
- [ ] Outings & Friends complete datasets match Supabase.
- [ ] Contact import: permission → picker → pre-filled confirm → real Friend in Hive and (post-sync) Supabase; duplicate phone blocked; no bulk contact upload (verify network inspector).
- [ ] private_mode/default_account round-trip with the web app.
- [ ] PIN/biometric/SMS-toggle/debug flags never appear in any Supabase table or queue entry.
- [ ] Admin rule edit on backend → visible on device after scheduled/manual refresh; detection uses it immediately (no restart); mobile never writes those tables.
