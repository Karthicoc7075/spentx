# SpentX Mobile — Full App Concept

What the app is, what it does, and how the pieces fit together. Mobile only
(`Mobile app/SpentX/`); the Next.js web app is a separate surface that shares the
same Supabase backend.

For the SMS engine specifically, see **[SMS_DETECTION.md](./SMS_DETECTION.md)**.

---

## 1. What SpentX is

An India-first personal finance tracker built around one bet: **most spending
already announces itself over SMS, so the user shouldn't have to type it in.**

Bank SMS and bank-app notifications are parsed on-device into transactions.
The first time a payee appears the user confirms it once; from then on it is
recognised and added automatically. Around that core sits everything needed to
make the resulting ledger useful — accounts, purposes, categories, budgets,
monthly plans, investments, net worth, and group-trip expense splitting with
friends.

Design constraints that shape almost every decision in the codebase:

| Principle | What it means in practice |
|---|---|
| **Local-first** | Hive is *always* the read layer. The UI never waits on the network. |
| **Offline-capable** | Writes land in Hive, queue up, and push when connectivity returns. |
| **Privacy-first** | SMS bodies are parsed on-device and never uploaded. Only the resulting transaction syncs. |
| **Never guess** | An unrecognised payee becomes a *pending verification*, never a silent transaction. |
| **Auth-gated** | No session → no SMS listening, no sync, no background jobs, not even a permission prompt. |
| **One design, two themes** | Light/dark change surface colours only — never layout, hierarchy or spacing. |

**Locale:** India — ₹, UPI, Indian bank SMS formats, 45 banks in the template
catalog.

**Platform:** Flutter, Android-primary. iOS builds, but SMS detection is
Android-only (iOS gives apps no SMS access).

---

## 2. Stack

```
Flutter 3.x / Dart 3.7+
├─ State      flutter_riverpod
├─ Routing    go_router                     lib/core/router/app_router.dart
├─ Local DB   hive_flutter                  ~25 boxes, see §10
├─ Secure     flutter_secure_storage        auth token, Hive encryption key
├─ Backend    supabase_flutter              auth + sync + realtime
├─ Auth       Supabase email/password  +  local PIN  +  local_auth biometrics
├─ SMS        telephony · native EventChannel · NotificationListenerService
├─ Background workmanager                   15-min periodic drain + sync
├─ Notifs     flutter_local_notifications
├─ Charts     fl_chart
└─ UI         google_fonts · lucide_icons · shimmer · custom design system
```

---

## 3. Navigation

### Launch sequence

```
/  Splash
 ├─ no Supabase session ────────────────→ /auth  (Welcome → login / signup)
 ├─ signup unconfirmed ─────────────────→ /auth/verify-email
 ├─ session + onboarding not done ──────→ /onboarding → /pin-setup → /home
 ├─ session + lock enabled ─────────────→ /lock  (PIN or biometric) → /home
 └─ session + no lock ──────────────────→ /home
```

The signed-out half of routing is encoded in `lib/core/utils/auth_routing_rules.dart`
rather than inline in the router, so it can be unit-tested — notably
`shouldHoldForEmailVerification`, where a *completed sign-in for the same address*
outranks a stale "pending verification" flag.

### Main shell — `MainWrapper`, 4 tabs + centre FAB

| Tab | Screen | Contents |
|---|---|---|
| Home | `home_screen.dart` | Balance hero, 4 shortcuts, spend-by-purpose, recent activity, trip banner, pending-SMS nudge |
| Activity | `transactions_screen.dart` | Full ledger, filters, outings collapsed to rollup rows |
| **+ FAB** | `add_transaction_sheet.dart` | Quick add expense / income |
| Analytics | `analytics_screen.dart` | Category & purpose breakdown, cash flow, savings rate |
| More | `settings_screen.dart` | Everything else |

### Full route list

```
/  /auth  /auth/signup  /auth/login  /auth/forgot-password
/auth/reset-password  /auth/verify-email  /onboarding  /pin-setup  /lock
/home  /activity  /investments  /wealth  /plan  /budgets  /recurring
/accounts  /account-detail/:name  /transaction/:id  /search  /calendar
/outings  /outing-detail/:id  /outing-expense/:outingId/:expenseId  /friends
/notifications  /notification-preferences  /export  /app-guide  /merchant-names
/developer-options  /sms-detection-lab  /real-sms-test  /detected-sms
/sms-activity  /sms-rules  /sms-rules-storage  /block-sms  /master-debug-log
```

---

## 4. Onboarding

1. **Step 1** — how many accounts?
2. **Step 2** — per-account form: name, type (Bank / Cash / Wallet / Credit),
   opening balance + its effective date, last-4 digits.
3. **Step 3** — purpose types (Personal, Family, or custom with colours).
4. Success screen → **PIN setup** (4 or 6 digits) → Home.

The last-4 and bank name entered here do double duty: they become the **bank
allowlist** that decides which SMS the app is even allowed to look at.

---

## 5. Core data model

### Transaction — `lib/models/transaction.dart`

The central record. Beyond the obvious fields (amount, merchant, category,
account, date, expense/income), it carries:

- `purposeType` — Personal / Family / custom
- `paymentMode` — UPI / Cash / Card / …
- `referenceId`, `upiId`, `bank` — SMS provenance, also used for dedupe
- `isAutoDetected`, `isPendingVerification`, `isMerchantMapped`
- `outingId` — link to a trip
- `transferType` — `bank_to_cash` (ATM) / `cash_to_bank` (CDM deposit)
- `splits[]` — `TransactionSplitRow`: **how** the amount is allocated across
  categories/purposes
- `items[]` — `TransactionItemRow`: **what** was bought
- `badgeKind` — `splitExpense · friendSplit · outing · settlement · friendReturn`,
  `none` for an ordinary row so the list stays scannable

### Account — `lib/models/account_model.dart`

`name`, `type` (Bank/Cash/Wallet/Credit), `last4Digits`, `openingBalance` +
`openingBalanceDate`, `isActive` (soft delete — net worth counts active only),
`isDefault` (default payment account).

### Supporting models

`Outing` / `OutingExpense` / `OutingMember` / `SettlementPayment`,
`FriendSplit` / `FriendSplitShare` / `FriendSettlementRecord`,
`InvestmentHolding`, `BudgetItem`, `PlanAllocation`, `Contributor`,
`MerchantRule`, `MerchantRecord`, `PendingTransaction`.

---

## 6. The money model

Four axes classify every transaction, and they're orthogonal:

- **Account** — which real pot the money left or entered.
- **Purpose** — Personal, Family, or a custom purpose. Analytics and Home's
  spend split key off this.
- **Category** — Food, Travel, … Budgets key off this.
- **Contributor** — who the income came from (default "Me", cannot be deleted).

**Transfers are not spending.** ATM withdrawal is Bank → Cash; a CDM deposit is
Cash → Bank. Both move money between the user's own accounts, so they change
account balances but must never inflate "spent this month". The SMS engine goes
to real trouble to keep third-party NEFT/IMPS from being misread as a
self-transfer (see SMS_DETECTION.md §6).

**Net worth** = active account balances (opening balance + ledger movement)
+ investment holdings. `DailySnapshotProvider` writes a dated snapshot to
`net_worth_history` / `account_balance_history` so the Wealth screen can chart a
trend rather than only showing today.

---

## 7. Feature map

### Transactions
Manual add (expense/income), edit, delete, detail view. Split Expense across
multiple categories/purposes. Line items. Search, calendar view, per-account
history. Saving a transaction with a UPI id or identifiable title also **trains a
merchant rule**, so the same payee is auto-categorised next time.

### Merchant learning
Two stores working together:

- `merchants_box` — payee-keyed (normalized SMS payee → title, category, purpose)
- `merchant_rules_box` — identifier-keyed (UPI id, phone, account identifier)

Lookup uses **stable identifiers only, never display names**, so renaming a
merchant can't accidentally capture unrelated transactions. Managed at
**/merchant-names** — that's where you fix `SWIGGY*FOOD` → *Swiggy · Food* once
and have it stick.

### Outings (group trips)
A trip has a title, date range, members (You + friends), an optional budget, and
an **auto-add mode**.

- While a trip is running, expenses inside its date window attach to it
  automatically — manual *and* SMS-detected.
- Expenses split `solo | equally | custom`; **who paid** drives who owes whom.
- Settlements support partial repayment across multiple payments and modes
  (`SettlementPayment` per member).
- `FriendRepaymentMatcher` watches for a credit SMS from a friend's saved UPI id
  and settles their share automatically.
- Statement view: per-person share, pending returns, settled amounts, trip total.
- Trips past their end date are auto-expired.

### Friends & splits
Friends with linked UPI ids. **Friend Splits** are standalone shared expenses —
a dinner bill, a cab fare — deliberately *not* trips: no outing, no outing
expense, no outing settlement, and their own `friend_settlements` records.
Open claims track what's still owed. Contacts import via `flutter_contacts`.

### Budgets
Per-category monthly limits. `BudgetAlertService` computes month-to-date spend
and fires notifications at 80% and 100%, throttled per category per month.

### Plan
Monthly plan: allocate expected income across categories, then track actual
against planned. Mirrors the web Plan page (`monthly_plans`).

### Investments & Wealth
Holdings across `liquid · mutualFund · fixedDeposit · stocks · bonds · crypto ·
gold · realEstate · other`. Add, invest more, withdraw, delete. The Wealth screen
aggregates net worth with a daily-snapshot trend chart and history sheet.

### Recurring
Two sources, no fabricated data: **detected patterns** (a merchant with 2+
expenses at roughly monthly cadence in the real ledger) and **manual bills** the
user defines.

### Analytics
Spend by category and purpose, cash flow, savings rate, top spending, month
navigation, purpose filters. Charts via `fl_chart` with a brightness-aware
palette.

### Export
CSV of the full ledger (spreadsheet-friendly) and JSON of transactions +
accounts + budgets (machine-readable backup). Written to a temp file and handed
to the system share sheet.

### Notifications
`notification_history` is the in-app log — separate from system notifications —
covering `sms_auto`, `sms_pending`, `budget_alert` and more, with read/unread
state and a Home bell badge. Per-type preferences at /notification-preferences.

### Loans
`/loans` currently renders **hardcoded sample data** (Home/Car/Education loan
cards). It's a UI placeholder, not a wired feature.

---

## 8. Privacy modes

**Private Mode** — masks money on Home and Accounts (net worth, Personal/Family
sections, account balances) as `*****`. A quick shoulder-surfing guard.

**Outing Privacy** — only togglable while a trip is actually running. When
active, Home and Activity show trip data *only*: net worth and non-trip balances
disappear entirely. Turning it **off** requires PIN or profile-name confirmation
(`PrivacyUnlockDialog`) — the friction is deliberate, since the point is that
someone holding your phone on a trip can't see the rest of your finances.

Outing Privacy suppresses Private Mode while it's live, so the two can't fight.

---

## 9. Security

| Layer | Detail |
|---|---|
| **Account** | Supabase email/password, email confirmation, password reset via `spentx://reset-password` deep link |
| **Token** | Stored in `flutter_secure_storage`, 1-year validity window, proactively refreshed at splash rather than trusting a stale cached session |
| **PIN** | 4 or 6 digits, salted hash in Hive. **Device-local — never synced.** Web Settings can write `users.app_pin_reset_at`, which clears the local hash so a forgotten PIN is recoverable |
| **Biometric** | `local_auth` fingerprint/face on the lock screen |
| **Lock screen** | Optional; requires PIN or biometric on every app open |
| **Account revoked** | If the signed-in account no longer exists server-side, `onAccountRevoked` triggers a full sign-out + local wipe |
| **Reset** | `AppResetService.resetAll()` clears every box + SharedPreferences + PIN, re-seeds onboarding flags. Requires PIN or profile-name confirmation |

`AuthGatedServices` is the single switch for everything that may only run for a
signed-in user: SMS detection, the notification listener, sync, realtime and
WorkManager jobs. It refuses to start without a session and stops everything on
sign-out — a logged-out device doesn't listen for SMS, hold a socket, or schedule
a job, and is never even *asked* for SMS permission.

---

## 10. Storage

### Hive boxes

| Box | Contents |
|---|---|
| `settings` | Profile, flags, PIN hash/salt, onboarding accounts, purposes, toggles, sync cursors |
| `transactions` | The ledger (key `list`) |
| `outings` | Trips: members, expenses, settlements |
| `friends`, `friend_splits` | Friends + standalone shared expenses |
| `budgets`, `categories`, `investments` | Budgets, custom categories, holdings |
| `merchants_box` | Payee-keyed learned merchants |
| `merchant_rules_box` | Identifier-keyed merchant rules |
| `merchant_aliases` | Display-name aliases |
| `detected_sms_box` | Full pending detection records |
| `pending_detections` | Id-only queue for the Detected SMS screen |
| `ignored_detections`, `ignored_sms` | Dropped detections, with reasons |
| `processed_sms_box` | Reference-id dedupe |
| `notification_history`, `pending_verification_history` | In-app logs |
| `sms_template_rules`, `regex_rules`, `block_rules` | SMS rule sets |
| `vault` | Encrypted box (`HiveService`) |

### SharedPreferences (native mirrors)
`auto_detection`, `background_detection_enabled`, `allowed_banks_json`,
`known_merchants_json`, `native_sms_queue`, `native_tx_queue`, permission-prompt
flags.

---

## 11. Sync architecture

`lib/core/sync/` — local-first, offline-capable, built against the real web schema.

```
UI  ──reads──▶  Hive  ──always──▶  instant, offline
                 │
   write ────────┤
                 ├──▶ SyncQueue ──▶ pushPending() ──▶ Supabase
                 │
   pull  ◀───────┴── rolling ~35-day window
```

Rules that matter:

- **Hive is always the read layer.** The UI never blocks on the network.
- Offline writes go to Hive first, then queue.
- On pull, the **server is source of truth for the rolling window**: server
  deletes remove local rows, and local rows older than the window are pruned to
  keep the device light. Stale rows the server no longer has are never kept.
- A pull **never overwrites a row with a queued local edit**.
- "Load older" extends the window via `tx_cache_extended_since`, so the next
  reconcile doesn't silently prune what the user just fetched.
- `firstSyncDone` gates a "preparing your data" state so a fresh login on a new
  device never flashes ₹0 before real data lands.

Components: `SyncService` (orchestrator), `SyncQueue` (offline write queue),
`RealtimeForegroundSync` (live updates while open), `ConnectivitySyncListener`
(push on reconnect), `BackgroundDataSync` (WorkManager push+pull),
`SupabaseSchemaMap` (field mapping for all ~22 tables).

Synced tables include `transactions`, `transaction_splits`, `transaction_items`,
`accounts`, `purposes`, `categories`, `contributors`, `outings`,
`outing_expenses`, `settlements`, `friends`, `friend_splits`,
`friend_settlements`, `user_merchants`, `monthly_plans`, `net_worth_history`,
`account_balance_history`.

**Pull-only:** `sms_template_rules`, `sms_detection_rules`, `sms_block_rules` are
admin-managed on the backend (admin-write RLS, authenticated read). The app
refreshes them at most daily and never writes back.

---

## 12. SMS auto-detection (summary)

The headline feature. Full detail in **[SMS_DETECTION.md](./SMS_DETECTION.md)**.

```
Bank SMS → native receiver / notification listener
   → gates: signed in? auto-detection on? one of the user's banks?
   → parse: filters → block rules → 505 templates / 45 banks → user rules → fallback
   → direction: credit / debit / transfer
   → payee extraction → merchant lookup
   → KNOWN: auto-add + "Added successfully"
     NEW:   pending + "Verify"
   → user verifies once → learned → auto from then on
```

Works with the app killed, via native queues drained by a WorkManager isolate.
Supporting tools: **SMS Detection Lab** (replay any SMS through the real
pipeline), **Detected SMS** (pending list, batch verify), **SMS Rules Manager**
(template / regex / block rules), and a live debug log.

---

## 13. State management

Riverpod throughout. Key providers in `lib/core/providers/`:

| Provider | Owns |
|---|---|
| `userStateProvider` | Accounts, purposes, profile, balances |
| `transactionProvider` | The ledger |
| `outingProvider` + `activeOutingProvider` | Trips |
| `friendsProvider`, `friendSplitProvider`, `friendUpiProvider` | Friends & splits |
| `merchantProvider`, `merchantAliasProvider` | Merchant rules |
| `budgetProvider`, `planProvider`, `categoryProvider` | Budgets, plan, categories |
| `investmentProvider`, `dailySnapshotProvider` | Wealth |
| `detectionQueueProvider` | Pending SMS verifications |
| `privateModeProvider`, `outingPrivacyProvider` | Privacy modes |
| `themeModeProvider`, `animationProvider` | Appearance & motion |
| `contributorProvider`, `settlementFeedbackProvider` | Income sources, settlement UX |

---

## 14. Design system

`lib/core/theme/spentx_tokens.dart` is the **single source of truth for colour**.
Components read `context.tokens` and must never hardcode a hex value or branch on
`isDark` themselves — that branching is exactly what makes a codebase drift into
two different-looking UIs.

> One design, two themes: only surface, border and text values change between
> modes — never the layout, the hierarchy, the spacing, or the accent.

`lib/core/design/` holds the primitives for the "Premium Minimal Fintech /
Modular Card UI" system: `SxCard` (structure from a hairline border, not
shadows), `SxMoney`, inputs, feedback. Accent colour is rationed — green means
something specific, so shortcut tiles stay monochrome rather than competing with
the balance figure. `theme_parity_test.dart` enforces that light and dark stay
structurally identical.

---

## 15. Developer tooling

Settings → **Developer Options** (`/developer-options`):

- **SMS Detection Rules** — train template rules, write regex rules, add block rules
- **Detected SMS** — pending + ignored list, batch verify, reprocess
- **SMS Detection Lab** — paste or schedule an SMS replay through the real pipeline
- **SMS Rules Storage** — inspect what's actually cached in Hive
- **Master Debug Log** — cross-module timeline (SMS, transactions, sync, auth)
- **SMS Detection Debug Log** — per-message trace with level and source
- **Manual rules refresh** — pull admin rules on demand
- **App settings** — lock rotation, system health check
- **Full app specification** — `SpentxMasterAppPrompt`, copyable to clipboard

### Tests

`test/` (run with `flutter test`) — 17 suites covering the rules that are easy to
break and hard to notice: `net_worth_balance`, `outing_link_rules`,
`outing_auto_split_and_returns`, `outing_return_netting`, `outing_unlink`,
`outing_split_to_friend_split`, `friend_open_claims`, `reimbursement`,
`activity_remaining`, `analysis_net_spending`, `bank_allowlist`,
`sms_transfer_direction`, `sms_notification_copy`, `auth_verification_routing`,
`local_data_handover`, `theme_parity`.

`tool/` (run with `dart run`) — SMS classification, HDFC card SMS, payee
extraction, background pending flow.

---

## 16. A typical journey

**Day 0** — Install → sign up → confirm email → onboarding (accounts + purposes)
→ set PIN → grant SMS + notification permission.

**Day 1** — Buy coffee. The bank SMS arrives; the app shows *"💸 Spent ₹180 · New
merchant detected · Verify"*. Tap, confirm it's *Third Wave Coffee · Food ·
Personal*. Saved — and learned.

**Day 2** — Same coffee shop. The SMS arrives and the transaction is added
silently: *"💸 Spent ₹180 · Third Wave Coffee · Added successfully."*

**Week 1** — Set a ₹6,000 Food budget. At ₹4,800 the app says so.

**Month 1** — Weekend trip to Goa with three friends. Start the trip, turn on
auto-add. Every spend during those dates attaches itself. Split the hotel
equally, mark yourself as payer. Friends repay over UPI; those credit SMS
auto-settle their shares. End the trip — the statement shows exactly who's square.

**Ongoing** — Analytics for where it goes, Plan for where it should go, Wealth
for the trend, CSV export when the accountant asks.

---

## 17. Repo map

```
Mobile app/SpentX/
├─ lib/
│  ├─ main.dart                     Hive init, bootstrap, lifecycle
│  ├─ core/
│  │  ├─ config/                    Supabase + developer config
│  │  ├─ router/app_router.dart     All routes + auth redirect
│  │  ├─ providers/                 Riverpod state (21 providers)
│  │  ├─ services/                  Auth, PIN, reset, merchants, budgets, contacts
│  │  ├─ sync/                      SyncService, queue, realtime, schema map
│  │  ├─ theme/ · design/ · widgets/  Design system
│  │  ├─ utils/                     Bank keywords, outing rules, reimbursement
│  │  └─ debug/                     Master debug log
│  ├─ models/                       Transaction, Account, FriendSplit, Merchant…
│  └─ features/
│     ├─ auth/ onboarding/          Signup, login, verify, PIN, lock, splash
│     ├─ home/ transactions/        Shell, Home, ledger, add/edit sheets
│     ├─ sms/ sms_parser/           Detection engine (see SMS_DETECTION.md)
│     ├─ background_detection/      Notification listener bridge
│     ├─ groups/ friends/           Outings, splits, settlements
│     ├─ analytics/ wealth/ investments/ plan/ budgets/ recurring/
│     ├─ accounts/ calendar/ export/ notifications/ loans/ cash_reminder/
│     └─ settings/                  Settings, dev options, app guide
├─ android/app/src/main/kotlin/…    SMS receiver, notification listener, queues
├─ assets/sms/                      bank_sms_templates_v4.json (45 banks, 505 templates)
├─ test/                            17 test suites
├─ tool/                            dart run scripts
└─ docs/
   ├─ APP_CONCEPT.md                ← this file
   ├─ SMS_DETECTION.md
   ├─ AUTH_SETUP.md
   ├─ SYNC_WIRING.md
   └─ THEME_MODE_AUDIT.md
```

---

## 18. Known gaps

- **Loans** (`/loans`) is a static mockup with hardcoded values.
- **iOS**: builds and runs, but SMS detection is unavailable by platform design —
  manual entry and sync work normally.
- `SpentxMasterAppPrompt` (Developer Options → full spec) is at v2.1 and predates
  Supabase auth/sync; it still describes the app as 100% local with no cloud sync.
  This document is the current one.
