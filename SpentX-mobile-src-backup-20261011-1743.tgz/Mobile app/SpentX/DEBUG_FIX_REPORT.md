# SpentX Mobile — Full-App Debug & Fix Pass Report

Date: 2026-07-19. Scope: every screen/feature per the pass plan (Steps 0–17), source-level audit of the real code (docs treated as a map, not ground truth).

Environment note: this pass ran in a sandbox where the Flutter SDK could not be installed (network allowlist), so `flutter analyze`, `flutter test`, and emulator/device runs were not possible. Every fix below was made by reading and tracing the real code; all 208 Dart files pass a full Dart-aware brace/string/interpolation balance scan after the edits. Run `flutter analyze` + `flutter test` + a device pass locally to close the loop (see §3).

---

## 1. Fixed

### Step 0 — Pre-flight / known dead code
- **Dark Mode no-op switch** (`settings_screen.dart`): was `value: true, onChanged: (v) {}`. Replaced with an honest static "Always on — SpentX is a dark-only app" row. Implementing a real light theme would be a visual redesign, which this pass explicitly excludes.
- **`AccountConfigScreen` deleted** (`screens/account_config_screen.dart`): zero references anywhere; `PremiumSettingsScreen` is the live equivalent and stays wired. The dead "Primary Account" switch died with the file.
- **PIN setup force-enabling fingerprint**: `PinService.setPin` unconditionally set `fingerprint_enabled=true`, and `pin_setup_screen.dart` called `enableFingerprint()` again. Added `PinService.enableFingerprintIfSupported()` (checks `canCheckBiometrics`/`isDeviceSupported`), used from `setPin`; removed the redundant screen-side call.
- **"Skip for now" (Onboarding Modal Step 1)**: had no tap handler. Now wired: completes onboarding with sane defaults (Cash account + Personal purpose) so the user lands in a usable app and can add banks later in Settings.
- **Dead Settings helpers removed**: `_showBankPicker`, `_showPurposePicker`, `_AccountManagementSheet`, `_PurposeManagementSheet`, `_AddFundSheet`, `_TypeChip` plus their now-unused imports.
- **"Create Test Rule from SMS" stub** (Developer Options): previously only showed a SnackBar. Now actually creates a template rule: parses the pasted SMS with `SmsRuleEngine`, auto-tags amount/UPI/reference/last-4 segments, builds via the same `TemplateBuilder` the Lab uses, and saves through `SmsTemplateEngine.saveRule` (rule takes effect immediately; falls back to advising the Lab when no amount is found).
- **Analyzer warnings**: removed remaining unused imports/locals (analytics `app_colors`, group_detail/outing_banner `glass_card`, edit_expense_sheet `outing_provider` + unused `isDark`, settings `premium_bottom_sheet`/`account_model` + unused `isDark`). Note: `analysis_output.txt` in the repo is stale — several listed warnings were already gone. The bulk of remaining analyzer output is info-level lints (`withOpacity` deprecation, curly-braces style) present across hundreds of sites; left untouched as pure style churn.

### Step 1 — SMS/notification auto-detection pipeline
- **Dual merchant-store split-brain (the confirmed real-world bug)**: the Merchant Names screen CRUDs only the legacy `merchant_rules_box`, while the v4 detection path (`MerchantMatchResolver`/`MerchantLearningService`, consulted *first* by `TransactionDetectionValidator.evaluateMerchant`) matches against `merchants_box`. Rules added/edited on that screen never reached the v4 matcher; rules deleted there kept auto-applying via the v4 store. Fixed with a bidirectional mirror:
  - `MerchantNotifier.saveRule/updateRule` now also write the v4 `merchants_box` record (via `MerchantLearningService.saveVerified`).
  - `MerchantNotifier.deleteRule` now also deletes matching v4 records.
  - `MerchantLearningService.delete` now also deletes the legacy mirror rule and re-syncs `known_merchants_json` to native.
- **`known_merchants_json` regeneration**: verified `MerchantRuleService._upsert` and `merchantProvider._loadFromBox` already call `AutoDetectionNativeSync.syncToNative()` on every write — plus the new delete-path sync above. Native Kotlin (`SpentXDetectionPrefs.findSavedMerchantName`) reads SharedPreferences fresh on every notification — no stale in-memory cache. Dart-side lookups read Hive fresh per call — no restart needed.
- **WorkManager 15-minute sweep was a silent no-op** (major): `BackgroundSmsProcessor` drains native queues via the `com.spentx.app/permissions` MethodChannel, which is registered **only in `MainActivity`**. Inside the WorkManager headless isolate the calls throw `MissingPluginException` and were swallowed by empty `catch` blocks — the background sweep never processed anything while the app was closed. Fixed:
  - `SmsPendingQueue.kt` / `TransactionPendingQueue.kt` now store their queues in `FlutterSharedPreferences` under `flutter.native_sms_queue` / `flutter.native_tx_queue` (Kotlin drain API unchanged, so the foreground MethodChannel path still works).
  - `BackgroundSmsProcessor` tries the channel first, then falls back to reading/clearing the queues directly via `shared_preferences` — which works in the background isolate.
- **Auto-added transactions were invisible to balances** (major, cross-cutting): all four auto-add paths wrote the merchant rule's *purpose type* ("Personal"/"Family") into the transaction `account` field and left `purpose` null — so SMS-auto-added spends never hit any real account balance, net worth, or Home's purpose totals (the manual verify flow did this correctly; auto-add did not). Added `AutoRuleEngine.resolveAccountName(bank, last4)` (same bank→account matching the verify flow uses: last-4 match → bank-name match → first bank account) and applied it to `_buildTransactionMap`, `handleForeground` known-merchant, `flushDeferredAutoAdds`, the friend-repayment auto-credit, and `pendingToTransaction`; `purpose` now carries the rule's purpose type.
- **Verified by trace (no code change needed)**: dedup (`processed_sms_box` by refId + amount/date ledger check), block rules applied in all three Dart paths (`processInbound`, `handleBackgroundSms`, `handleForeground`) and inside `SmsRuleEngine.parse`; `auto_detection` OFF gates all paths (native receiver, native listener, Dart stream listener, pipeline, background processor — plus queue discard on disable); ATM learned-pattern path (`findAtmRule`) wired; `SmsRuleEngine.parse` reads rules from Hive per call (order: failed/ad filter → block rules → v4 templates → trained templates → regex → fallback); `PendingVerificationPresenter` drains sequentially after each confirm/ignore, queue is Hive-backed with reconcile, nothing silently dropped (dismiss intentionally re-queues for next open).

### Steps 2–8 — Home / Quick Add / Activity / Detail / Accounts / Budgets / Analytics
- **Transfer pair second leg silently dropped**: `addTransaction`'s duplicate guard compared only merchant+amount+minute, so the credit leg of a Cash→Bank / Bank→Bank transfer (same merchant string, same minute) was treated as a duplicate of the debit leg and discarded — destination never credited. Guard now also compares `isExpense` and `account`.
- **Bank→Bank transfers inflated Cash by 2× the amount**: `getAccountBalance`'s Cash branch credited Cash for *every* `isTransfer` record. Added an explicit `transferTo` field to `Transaction` (json/copyWith included); the Transfer sheet now stamps it on every leg, and the Cash branch only credits Cash when the transfer actually targets Cash (legacy/ATM records with null `transferTo` keep the historical to-Cash assumption when they're bank debits).
- **Cash→Bank transfers counted as real spending + income**: the sheet created both legs with `isTransfer=false` (and the outgoing leg against a non-existent "Personal" account). Both legs now carry `isTransfer=true`, the outgoing leg is booked against `Cash`, so analytics/home totals exclude them; Home's monthly income filter also now excludes legacy `category == 'Transfer'` records.
- **Quick Add silent no-op**: invalid amount / missing account now shows a clear SnackBar in both Expense and Income forms instead of doing nothing.
- **8-account cap silent no-op**: `addAccount` now returns `bool`; `PremiumSettingsScreen` shows "Account limit reached — maximum 8 accounts…" instead of closing the sheet as if it saved.
- **Verified by trace**: Home cards/net worth derive from the same providers the Accounts screen uses; quick actions route correctly; pending banner is driven by `detectionQueueProvider`; Private Mode masking via `effectivePrivateModeProvider`; Activity search is real (`TransactionSearchDelegate`); edits/deletes propagate reactively (state-notifier + computed balances); budget alerts fire once per threshold per month via the persisted `budget_alert_{id}_{y}_{m}` fired-list; Cash/first-bank edit/delete restrictions enforced in `PremiumSettingsScreen`.

### Steps 9–11 — Outings / Friends / Investments
- **Repayment settlements re-applied on every app restart** (major): `TransactionNotifier._loadFromStorage` re-runs the whole ledger through `FriendRepaymentMatcher` on each load, and nothing recorded that a transaction's settlement was already applied — one ₹500 repayment could keep draining additional pending shares across restarts. Added a persisted applied-transaction guard (`friend_settled_tx_ids` in settings, capped at 1000) checked in `trySettleCredit`/`trySettleDebitToFriend` and stamped on success. "Sync past SMS repayments" still works (skips applied, applies unapplied).
- **Verified by trace**: single-active-outing invariant enforced in `createOuting`; split math (`perPersonShare`, partial `settlementPayments`, netting) correct by inspection; auto-link (date-range + friend-credit matching) wired in both `addTransaction` and the SMS engine; Outing Privacy on = instant, off = `PrivacyUnlockDialog` verification; trip-derived friends merge into a by-name map — no duplicates against manual friends; investments add/edit/delete + SMS allocation flow are real code paths.

### Steps 12–16 — Wealth / Notifications / Settings / Merchant Names / Dev tools
- **Wealth screen mock balances**: replaced the hardcoded ₹1L/₹4.5L base offsets with the exact Accounts-screen formula (per-account `openingBalance + getAccountBalance(name)`, split by account type). Wealth and Accounts can no longer disagree.
- **Wealth goals now persist**: stored in Hive `settings` under `wealth_goals` (load on init, save on add/update). The previous hardcoded demo goals are gone; goals survive navigation and restart, and are wiped by Reset App Data.
- **Reset App Data gaps**: added `master_debug_log_box` and the two remaining legacy migration boxes (`sms_rules_box`, `sms_template_box`) to the wipe list. SharedPreferences clear also covers the new native queue mirror keys.
- **System Health Check reported "healthy" for broken states**: Pending Queue now fails when queued ids are orphaned (missing from `detected_sms_box` — those popups would silently drop); Outing System now fails when >1 outing is active (invariant violation); Merchant Rules now reports both legacy and v4 store counts so split-brain drift is visible.
- **"Clear Pending Verification" cleared almost nothing**: it only removed ledger rows flagged pending, but real pendings live in `detected_sms_box` + `pending_detections`. It now clears those stores too (count shown in the confirm dialog includes them).
- **Verified by trace**: notification history logs all three types with accurate copy and `markAllRead` clears everything; profile rename persists; privacy-toggle mutual exclusivity + verification-to-disable; PIN set/change/reset (reset requires biometric, not old PIN — and correctly refuses on unsupported devices); Merchant Names search/add/edit/delete (delete warning is now *accurate* thanks to the Step 1 mirror fix); App Guide is static with no broken navigation.

### Step 17 — Mock screens (see §4 for the decisions)
- **Recurring** rewritten against real data.
- **Calendar** rewritten against real data.
- **Export** implemented for real (CSV + JSON via system share sheet, `share_plus` v12 API).
- **Standalone Search** removed; `/search` now redirects to `/activity`.
- All three surviving screens got real nav entry points in Settings (Recurring Bills + Spending Calendar under FEATURES, Export & Backup under PREFERENCES) — no more orphan routes.

---

## 2. Found but not fixed

- **Native notification-listener can show a "Verify" notification for an SMS that Dart later blocks**: block rules are Dart-side only; the Kotlin listener has its own crude keyword filter. The pending item is correctly discarded by the pipeline, but the transient system notification may still appear. Fix requires mirroring block rules to SharedPreferences for native evaluation — recommend a small focused follow-up.
- **Legacy Bank→Bank transfer records created before this pass** (with `isTransfer=true`, `transferTo=null`) still mis-credit Cash — old data is indistinguishable from ATM withdrawals. New records are correct. A one-time migration (pairing legacy transfer legs by merchant string `TR X to Y`) could clean historical data if it matters.
- **Restore-from-backup and PDF export**: intentionally not built — restore is a genuinely new feature (schema validation, merge policy, destructive-write safety), not a bug fix. The Export screen states both as planned. JSON export produces a restore-ready payload for when it's built.
- **Budget delete has no confirmation** (trash icon deletes instantly, per docs). Left as-is: documented behavior, no data-integrity impact; flagging as a UX decision for the owner.
- **`withOpacity` deprecation + style lints (~hundreds of info-level sites)**: mechanical churn across nearly every UI file; no functional impact; better done as a dedicated cleanup commit with the analyzer running.
- **Full-app spec is copyable from Developer Options** on shipped builds — worth gating behind a debug flag before any public release.

## 3. Could not verify (environment limits)

Flutter SDK installation was blocked by the sandbox network allowlist, so nothing could be compiled or run here. Needed locally:
1. `flutter analyze` (expect only pre-existing info-level lints) and `flutter test` (`test/sms_notification_copy_test.dart`).
2. Physical-device checks: real bank SMS through the broadcast receiver; notification-listener path with SMS permission denied; WorkManager cadence (`adb shell dumpsys jobscheduler | grep spentx`) and — specifically — that the new prefs-based queue drain processes SMS that arrived while the app was force-stopped; biometric flows on devices with and without fingerprint hardware; the share sheet on both export actions.
3. Parser accuracy across multiple real banks' current SMS formats (`assets/sms/bank_sms_templates_v4.json` fixtures cover the bundled set, but live formats drift — the Real-Time SMS Test screen is the right tool).
4. One migration behavior: existing installs with items in the *old* native queue prefs files (`spentx_sms_pending`/`spentx_tx_pending`) will orphan those few queued items on first update — transient data, deemed acceptable.

## 4. Decisions made (Step 17)

- **Recurring — FIXED (wired to real data)**: detects roughly-monthly merchants (≥2 occurrences, 20–40-day median gap) from the real ledger and computes real next-due dates; plus user-defined bills persisted in Hive (`recurring_bills`), FAB adds, long-press removes, "paid this month" derived from actual transactions. Rationale: real product value, and the detection input (a clean ledger) already exists.
- **Calendar — FIXED (wired to real data)**: real month navigation, correct month shapes with leading blanks, expense dots and tappable per-day Spent/Earned/Txns stats all computed from the ledger.
- **Export — FIXED (implemented)**: real CSV export (16 columns, signed amounts) and a JSON backup (transactions + accounts + purposes + budgets + investments) via the system share sheet; real "last export" timestamp replaces the fake "Last Backup: Today, 2:30 PM". Fake PDF/Backup/Restore tiles removed and stated as planned.
- **Standalone Search — REMOVED**: screen deleted, `/search` redirects to `/activity` where the real search lives. A second, fake search implementation had negative value.
- **Navigation**: all three surviving screens are now discoverable from Settings — the "unlinked route" state is gone.

## 5. Overall verdict

The documentation's "production-grade" claim was not true before this pass: the merchant-rule split-brain, the dead WorkManager sweep, auto-added transactions bypassing all account balances, dropped transfer legs, Cash inflation on bank-to-bank transfers, and restart-multiplied friend settlements were all real correctness bugs in the core money paths — several of them exactly contradicting the docs' ✅ rows. Those are now fixed at the source level, the four mock screens are resolved (three real, one removed), and the known dead code is gone.

What remains before it can be *trusted* as feature-complete: one local `flutter analyze`/`flutter test`/build cycle, and one physical-device pass over the SMS/notification/WorkManager/biometric paths listed in §3 — those runtime behaviors cannot be proven from a sandbox without a Flutter toolchain, only made correct by construction. Code-wise, the app now matches its own documentation, with the §2 items as the honest remaining gap list.
