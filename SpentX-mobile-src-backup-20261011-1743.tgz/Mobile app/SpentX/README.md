# SpentX Mobile — Complete Architecture, Features & Technical Reference

> **SpentX** is an offline-first, privacy-focused personal finance, wealth tracking, and automated spend-detection mobile application built with **Flutter**, **Riverpod**, **Hive (AES-encrypted)**, and **Supabase**. It provides automatic bank SMS transaction parsing, smart expense categorization, multi-account liquid cash tracking, daily net worth snapshots, shared group outings with split calculations, and two-way cloud synchronization with the SpentX Web platform.

---

## 📑 Table of Contents
1. [Core Design Philosophy](#-core-design-philosophy)
2. [Technology Stack & System Architecture](#-technology-stack--system-architecture)
3. [Design System, Typography & Themes](#-design-system-typography--themes)
4. [Complete Screen Inventory & Page-by-Page Features](#-complete-screen-inventory--page-by-page-features)
   - [4.1 Splash & Session Gateway](#41-splash--session-gateway)
   - [4.2 Authentication & Security Suite](#42-authentication--security-suite)
   - [4.3 Onboarding Flow](#43-onboarding-flow)
   - [4.4 Home Screen (Dashboard)](#44-home-screen-dashboard)
   - [4.5 Transactions & Activity Ledger](#45-transactions--activity-ledger)
   - [4.6 Wealth, Accounts & Net Worth Tracking](#46-wealth-accounts--net-worth-tracking)
   - [4.7 Outings & Friend Expense Splits](#47-outings--friend-expense-splits)
   - [4.8 Monthly Plans & Budgeting](#48-monthly-plans--budgeting)
   - [4.9 Automated SMS Detection Lab & Rules Engine](#49-automated-sms-detection-lab--rules-engine)
   - [4.10 Notifications Hub](#410-notifications-hub)
   - [4.11 Settings, Privacy & Diagnostics](#411-settings-privacy--diagnostics)
5. [Automated Bank SMS Detection Engine](#-automated-bank-sms-detection-engine)
6. [Offline-First Sync Engine & Cloud Architecture](#-offline-first-sync-engine--cloud-architecture)
7. [Security, Privacy & Data Protection](#-security-privacy--data-protection)
8. [Performance, Battery & Resource Optimization](#-performance-battery--resource-optimization)
9. [Local Storage (Hive Boxes Schema)](#-local-storage-hive-boxes-schema)
10. [Folder Structure & Code Organization](#-folder-structure--code-organization)

---

## 🏛️ Core Design Philosophy

* **Offline-First Resilience**: All reads and writes hit local Hive storage first with **0ms perceived latency**. You can add transactions, manage trips, and review budgets anywhere—even with zero connectivity or in airplane mode.
* **Privacy & Local Processing**: Bank SMS messages are processed **entirely on-device** using local Dart regex patterns and template rules. Raw SMS bodies are never uploaded to the cloud.
* **Point-in-Time Net Worth Tracking**: Unlike simple ledger trackers, daily wealth snapshots strictly track your balance journey starting from your **Account Creation Date**, preventing misleading historical distortions when old data is backfilled.
* **Seamless Cross-Platform Continuity**: Every transaction, budget template, account, and outing trip is synchronized symmetrically with the SpentX Web application using deterministic identifiers (`SyncIds`).
* **Calm, High-End Aesthetics**: A clean, distraction-free aesthetic with fluid micro-interactions, subtle glassmorphic surfaces, and curated emerald-toned palettes for both Dark and Light modes.

---

## 💻 Technology Stack & System Architecture

```
┌────────────────────────────────────────────────────────────────────────┐
│                          PRESENTATION LAYER                            │
│  Flutter 3.x • GoRouter • Riverpod StateNotifier • Custom SoftTheme    │
└────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                           BUSINESS LOGIC                               │
│  TransactionNotifier • DailySnapshotNotifier • SmsDetectionPipeline   │
│  OutingNotifier • PlanNotifier • BudgetAlertService • PinService       │
└────────────────────────────────────────────────────────────────────────┘
                                    │
                  ┌─────────────────┴─────────────────┐
                  ▼                                   ▼
┌──────────────────────────────────┐ ┌──────────────────────────────────┐
│      LOCAL STORAGE (OFFLINE)     │ │        CLOUD SYNC (SUPABASE)     │
│  Encrypted Hive (AES-256)        │ │  Supabase Auth (JWT Persistent)  │
│  FlutterSecureStorage (Keystore) │ │  PostgreSQL Tables & RPCs        │
│  SharedPreferences (Sync Flags)  │ │  Realtime Websocket (Foreground) │
│  WorkManager (Background Tasks)  │ │  SyncQueue (Deterministic UUIDs) │
└──────────────────────────────────┘ └──────────────────────────────────┘
```

| Component | Technology | Role |
| :--- | :--- | :--- |
| **Framework** | Flutter (Dart SDK `>=3.3.0`) | Cross-platform native mobile engine (Android & iOS). |
| **State Management** | Flutter Riverpod (`StateNotifierProvider`) | Reactive, testable, decoupled state management. |
| **Navigation** | GoRouter | Declarative routing with deep linking and auth redirects. |
| **Local Database** | Hive & Hive Flutter | High-speed NoSQL key-value database. |
| **Local Encryption** | AES-256 (`HiveAesCipher`) | Hardware Keystore/Keychain-backed encryption. |
| **Cloud Backend** | Supabase (PostgreSQL + Auth + Storage) | Scalable backend for user auth, data sync, and web parity. |
| **Background Tasks** | Android WorkManager | Headless isolate execution for SMS queue drains and sync. |
| **Biometrics** | `local_auth` | Fingerprint and Face Unlock security. |
| **Vector Icons** | `lucide_icons` | Ultra-clean, modern iconography. |

---

## 🎨 Design System, Typography & Themes

The app is built upon a custom tokenized theme system (`SoftPalette` and `AppTheme`) supporting full automatic and manual switching between Light and Dark modes.

### Color Tokens

| Token Name | Light Mode Hex | Dark Mode Hex | Usage |
| :--- | :--- | :--- | :--- |
| **Canvas / Background** | `#F8FAFC` (Slate Tint) | `#09090B` (Deep Onyx) | Primary screen backdrop. |
| **Card Surface** | `#FFFFFF` (Pure White) | `#18181B` (Zinc Dark) | Container and card background. |
| **Card Elevated** | `#F1F5F9` (Soft Slate) | `#27272A` (Charcoal Zinc)| Modals, dropdowns, and elevated chips. |
| **Primary Emerald** | `#059669` (Forest Mint) | `#10B981` (Bright Emerald) | Primary buttons, active tabs, hero accents. |
| **Deep Emerald** | `#064E3B` | `#065F46` | High-contrast headers and hero cards. |
| **Mint Tint** | `#ECFDF5` | `#062E22` | Positive balance chips, tag backgrounds. |
| **Ink (Text Primary)** | `#0F172A` (Deep Slate) | `#F8FAFC` (Ghost White) | Primary titles and numbers. |
| **Slate (Text Muted)** | `#64748B` | `#94A3B8` | Subtitles, labels, and metadata. |
| **Border / Divider** | `#E2E8F0` | `#27272A` | Subtle card borders and list dividers. |
| **Income Accent** | `#10B981` (Emerald) | `#34D399` | Inbound cash flow and credit amounts. |
| **Expense Accent** | `#EF4444` (Rose Red) | `#F87171` | Outbound spends and debt amounts. |
| **Transfer Accent** | `#8B5CF6` (Violet) | `#A78BFA` | Account-to-account transfer transactions. |
| **Outing Accent** | `#F59E0B` (Warm Amber) | `#FBBF24` | Group travel and friend split tags. |

### Typography & Formatting
* **Indian Currency Notation**: Quantities are formatted dynamically using the standard Indian comma grouping system via `_formatIndian`:
  * *Example*: `₹1,50,000` (instead of Western `₹150,000`), formatted with the `₹` Rupee symbol.
* **Orientation Lock**: Fixed to **Portrait Mode** across Android and iOS to prevent layout distortion on one-handed mobile financial operations.

---

## 📱 Complete Screen Inventory & Page-by-Page Features

### 4.1 Splash & Session Gateway
* **Location**: `lib/features/auth/presentation/splash_screen.dart`
* **Route**: `/splash`
* **Features**:
  * **Zero-Flash Transition**: Hooks into `flutter_native_splash` to keep the native OS splash screen visible until the first Flutter frame is drawn.
  * **Branded Visuals**: Displays the official metallic SpentX shield emblem with smooth entry micro-animations.
  * **Dynamic Status Bar Adaptation**: Uses `AnnotatedRegion<SystemUiOverlayStyle>` to dynamically ensure status bar clock and battery icons are crisp dark in Light mode and bright white in Dark mode.
  * **Intelligent Routing Gateway**:
    * If unauthenticated $\rightarrow$ Routes to `/auth`.
    * If authenticated but setup incomplete $\rightarrow$ Routes to `/onboarding`.
    * If authenticated and PIN lock enabled $\rightarrow$ Prompts `/lock`.
    * If authenticated and unlocked $\rightarrow$ Routes to `/home`.

---

### 4.2 Authentication & Security Suite
* **Locations**:
  * `lib/features/auth/presentation/login_screen.dart` (`/auth/login`)
  * `lib/features/auth/presentation/signup_screen.dart` (`/auth/signup`)
  * `lib/features/auth/presentation/forgot_password_screen.dart` (`/auth/forgot-password`)
  * `lib/features/auth/presentation/lock_screen.dart` (`/lock`)
* **Features**:
  * **Supabase Email/Password Auth**: Secure credential verification with JWT tokens persisted safely in device Keystore.
  * **Deep-Link Password Recovery**: Listens for recovery tokens via URL deep-links (`spentx://auth/reset-password`) to open the password reset dialog.
  * **Device Account-Switch Safeguard**: Detects when an account signs in on a phone containing data from an older/different account. Displays an explicit **"Keep or Erase"** modal so financial history is never accidentally merged.
  * **4-Digit Local PIN Lock**: Fast 4-digit security code stored locally as a SHA-256 hash.
  * **Biometric Authentication**: Fingerprint and FaceID integration via `local_auth` with automatic prompt on app launch and resume.
  * **Unlock Grace Period**: 5-second anti-loop grace window preventing double-prompts when quickly switching between apps.

---

### 4.3 Onboarding Flow
* **Location**: `lib/features/auth/presentation/onboarding_screen.dart`
* **Route**: `/onboarding`
* **Steps**:
  1. **Welcome Screen**: Introduction to SpentX's personal wealth & cashflow tracking.
  2. **Account Count Selection**: Select how many bank/cash accounts you hold.
  3. **Account Form**: Add initial accounts (e.g., *Cash*, *HDFC Bank*, *SBI*, *Paytm Wallet*, *Credit Card*).
  4. **Purpose Setup**: Choose default financial purposes (*Personal*, *Family*, *Business*).
  5. **PIN & Biometrics**: Create your 4-digit lock code and enable fingerprint unlock.
  6. **Setup Summary & Baseline**: Saves the user's initial accounts and sets the **Account Baseline Date** (`account_created_at_date`).
  7. **Permissions Onboarding**: Contextual, respectful permission requests for Notifications, Android SMS read, and Background Detection.

---

### 4.4 Home Screen (Dashboard)
* **Location**: `lib/features/home/presentation/home_screen.dart`
* **Route**: `/home`
* **Features**:
  * **Personalized Header**: Dynamic greeting with user's first name, unread notification indicator badge, and direct shortcut to Settings.
  * **Bento Hero Carousel Card**:
    * **Slide 1 (Liquid Balance)**: Real-time sum of liquid funds (Cash + Bank Accounts + Wallets minus Credit Card debt).
    * **Slide 2 (Total Wealth)**: Liquid balance + Investments + Saved Goals.
    * **Slide 3 (Monthly Cashflow)**: Month-to-date Income vs. Expense vs. Net Saved.
    * **Privacy Eye Toggle**: Instantly masks sensitive monetary values with `••••••` for safe public viewing.
  * **Unverified SMS Banner**: Displays pending detected transactions waiting for confirmation (e.g., *"3 new bank spends detected"*), with 1-tap navigation to the review screen.
  * **Active Outing Trip Banner**: When a group trip is active (e.g., *"Goa Vacation"*), displays a live banner with current gross trip spend.
  * **Outing Privacy Mode**: One-tap toggle that hides all personal transactions and only displays transactions belonging to the active trip.
  * **Monthly Plan / Budget Progress Card**:
    * Visual meter displaying total spent vs. monthly planned budget.
    * Percentage tracker with color shifting (Green $\le$ 70%, Amber 71–90%, Red $>$ 90%).
    * Purpose-aware categorization (tracks spends under *Personal*, *Family*, or custom purposes).
  * **Quick Actions Floating Dock**:
    * ➕ Add Expense / Add Income
    * 🔁 Transfer Funds between accounts
    * 📱 SMS Scan / Parse
    * ✈️ Start New Outing
  * **Recent Transactions Feed**: Shows the latest ledger items with category icons, account tags, and quick-tap transaction detail bottom sheet.

---

### 4.5 Transactions & Activity Ledger
* **Location**: `lib/features/transactions/presentation/transactions_screen.dart`
* **Route**: `/activity` (or `/transactions`)
* **Features**:
  * **Segmented Date Scopes**:
    * *This Month* (default MTD ledger view)
    * *Last Month*
    * *Custom Date Range* (custom date picker)
    * *All Time*
  * **Multi-Dimensional Filter Bar**:
    * **Purpose Filter**: Filter by *All*, *Personal*, *Family*, etc.
    * **Category Filter**: Filter by *Food & Dining*, *Groceries*, *Transport*, *Shopping*, *Bills*, *Entertainment*, *Investments*, etc.
    * **Account Filter (Multi-Select)**: Filter by specific accounts (e.g., show only *HDFC* and *Cash*).
    * **Contributor Filter**: Filter income by source contributor.
    * **Friend Filter**: Show only transactions linked to splits with a specific friend.
  * **Real-Time Search Bar**: Instant search across merchants, notes, categories, and account names.
  * **Day-Grouped Ledger**: Transactions are neatly grouped by calendar day with daily net totals.
  * **Interactive Transaction Tile**:
    * Category color-coded badge.
    * Payee/Merchant name with fallback to note.
    * Account name tag and payment mode badge (UPI, Card, Cash, NetBanking).
    * Amount colored green (income), red (expense), or purple (transfer).
    * Badges for Outing membership and Friend Split status.
  * **Add / Edit Transaction Sheet**:
    * Full support for Expense, Income, and Transfer.
    * Account selection and transfer destination account.
    * Date and time picker.
    * Category picker with custom category creation.
    * Outing linking (optionally attach expense to an active trip).
    * Split with Friends modal (equal, exact, or percentage splits).

---

### 4.6 Wealth, Accounts & Net Worth Tracking
* **Location**: `lib/features/wealth/presentation/wealth_screen.dart` & `accounts_screen.dart`
* **Route**: `/wealth` (or `/accounts`)
* **Sub-Views**:
  * **1. Accounts Overview**:
    * Total liquid balance card with historical trend sparkline.
    * Account groupings: **Cash**, **Bank Accounts**, **Digital Wallets**, **Credit Cards**.
    * Account card details: current balance, account number hint, active/archived status.
    * "Add Account" modal: create new custom accounts with initial seed balances.
  * **2. Daily Snapshot Card & Net Worth History**:
    * **Daily Closing Balance**: Automatically captures end-of-day balances for Cash, Bank, Wallet, and Investments.
    * **Account Creation Gate**: Strictly displays snapshots recorded **from your Account Creation Date onward**. Historical backfilled transactions will never pollute or distort past snapshot history.
    * **Snapshot History Sheet**: Full drawer showing daily wealth records, day-over-day net worth delta pills (+₹1,200 / -₹450), and individual account closing amounts.
  * **3. Emergency Fund Health Analyzer**:
    * Calculates your emergency fund runway: $\text{Runway} = \frac{\text{Liquid Balance}}{\text{Average Monthly Burn Rate}}$.
    * Health Status Badges:
      * 🟢 **Healthy** ($\ge 6\text{ months}$ coverage)
      * 🟡 **Moderate** ($3 - 6\text{ months}$ coverage)
      * 🔴 **Low** ($< 3\text{ months}$ coverage)
  * **4. Investments Portfolio**:
    * Track Mutual Funds, Stocks, Gold, Provident Fund, and Crypto.
    * Current valuation vs. invested amount with total P&L.
  * **5. Savings Goals**:
    * Create goal targets (e.g., *"Emergency Reserve"*, *"New Laptop"*, *"Car Downpayment"*).
    * Visual progress bars and one-tap "Add Funds" deposit action.
  * **6. Wealth Projector / FIRE Simulation**:
    * Simulates compound growth over 5, 10, 20, and 30 years based on monthly contributions, expected annual returns, and inflation.

---

### 4.7 Outings & Friend Expense Splits
* **Location**: `lib/features/outings/presentation/outings_screen.dart`
* **Route**: `/outings`
* **Features**:
  * **Trip Management**: Group vacations, weekend dinners, flatmate expenses.
  * **Trip States**: *Active*, *Settled*, *Cancelled*.
  * **Auto-Link Mode**: Automatically links expenses paid during trip dates to the trip.
  * **Settlement Engine (Who Owes Whom)**:
    * Simplifies multi-person debt into minimal settlement transactions.
    * Member balances (e.g., *"Rahul owes you ₹850"*, *"You owe Priya ₹320"*).
  * **Friend Split Manager (`/friends`)**:
    * Directory of friends with aggregate net balance owed/owing.
    * Direct UPI deep-link generation (`upi://pay?pa=...`) to settle debts instantly.
    * Automatic payment reconciliation when a friend repays via bank transfer.

---

### 4.8 Monthly Plans & Budgeting
* **Location**: `lib/features/plan/presentation/plan_screen.dart`
* **Route**: `/plan`
* **Features**:
  * **Plan Wizard**: Set monthly budget caps globally and per category.
  * **Budget Health Visualizer**: Circular gauges showing percentage used.
  * **Smart Overspending Alerts**: In-app notifications when approaching 80% or 100% of category limits.
  * **Savings Target Meter**: Set a monthly savings target and track real-time net surplus.

---

### 4.9 Automated SMS Detection Lab & Rules Engine
* **Location**: `lib/features/sms/detected/detected_sms_screen.dart` & `sms_activity_screen.dart`
* **Route**: `/sms/detected` and `/sms/rules`
* **Features**:
  * **Pending Verification Queue**: Cards displaying automatically parsed incoming transactions from bank SMS.
  * **One-Tap Actions**:
    * ✅ **Confirm & Add**: Saves to ledger immediately.
    * ✏️ **Edit & Save**: Tweak category, merchant, or account before saving.
    * ❌ **Ignore / Delete**: Discards the message and adds pattern to ignore list if desired.
  * **SMS Rules Management**:
    * **Merchant Alias Rules**: Maps raw SMS codes (*"SWIGGY-BLR-04"* $\rightarrow$ *"Swiggy"*).
    * **Category Rules**: Maps merchants to default categories.
    * **Block / Spam Rules**: Ignores promotional SMS, balance alerts, and OTPs.
  * **Merchant Learning Engine**: Remembers manual edits to auto-categorize future visits to the same merchant.

---

### 4.10 Notifications Hub
* **Location**: `lib/features/notifications/presentation/notifications_screen.dart`
* **Route**: `/notifications`
* **Features**:
  * Chronological log of transaction alerts, budget threshold warnings, and sync updates.
  * Unread counter badge synchronized with the Home dashboard header.
  * One-tap "Mark all as read" and "Clear history".

---

### 4.11 Settings, Privacy & Diagnostics
* **Location**: `lib/features/settings/presentation/settings_screen.dart`
* **Route**: `/settings`
* **Features**:
  * **Account Section**: User profile name, email, last sign-in timestamp, and sign-out.
  * **Security**: PIN setup/change, Biometric toggle, Auto-lock duration.
  * **Appearance**: System Default, Light Mode, or Dark Mode.
  * **Auto-Detection Controls**: Toggle background SMS detection, view Android permission statuses.
  * **Data Management**:
    * Force Cloud Sync now.
    * Backup / Export financial data.
    * **Reset App Data**: Wipes local Hive cache, resets PIN, and clears session.
  * **Master Debug Log Console**:
    * Filter logs by module (`AUTH`, `SYNC`, `SMS`, `WEALTH`, `OUTINGS`).
    * Toggle floating debug toasts.
    * Set retention limits (last 100, 500, or 1000 events).

---

## 🤖 Automated Bank SMS Detection Engine

SpentX features a sophisticated 4-tier pipeline that converts messy bank SMS messages into structured ledger entries without sending text to any external server:

```
[ Incoming SMS Message / Android Notification ]
                       │
                       ▼
┌────────────────────────────────────────────────────────┐
│  TIER 1: Non-Transaction & Spam Filter                 │
│  Drops OTPs, marketing, balance inquiries, reminders.  │
└────────────────────────────────────────────────────────┘
                       │ (Valid Bank Alert)
                       ▼
┌────────────────────────────────────────────────────────┐
│  TIER 2: Block & User Exclusion Rules                  │
│  Checks custom sender and keyword blocklists.          │
└────────────────────────────────────────────────────────┘
                       │ (Allowed)
                       ▼
┌────────────────────────────────────────────────────────┐
│  TIER 3: V4 Regex & Multi-Bank Template Engine         │
│  Extracts Amount, Date, Payee, Account, Type.          │
│  Supports SBI, HDFC, ICICI, Axis, Kotak, PNB, etc.     │
└────────────────────────────────────────────────────────┘
                       │ (Parsed Components)
                       ▼
┌────────────────────────────────────────────────────────┐
│  TIER 4: Merchant Learning & Confidence Scoring        │
│  Resolves aliases and predicts categories.             │
└────────────────────────────────────────────────────────┘
         │                                      │
(High Confidence)                       (Low / Medium Confidence)
         ▼                                      ▼
[ Auto-Add to Ledger ]                  [ Send to Review Queue ]
```

---

## 🔄 Offline-First Sync Engine & Cloud Architecture

### Synchronization Mechanics
* **Deterministic Unique IDs (`SyncIds`)**: Uses UUIDv5 derived from user ID, account names, and timestamps to guarantee that records generated offline produce identical IDs across devices, preventing duplication.
* **SyncQueue**: Any offline mutation (Insert, Update, Delete) is appended to the local `sync_queue` Hive box.
* **Two-Way Reconciliation (`SyncService.fullSync`)**:
  1. **Push Phase**: Flushes all pending mutations from `sync_queue` to Supabase via bulk RPCs.
  2. **Pull Phase**: Fetches rows updated since the last sync cursor. Server-side deletes remove local Hive entries.
  3. **Window Pruning**: Reconciles the active 1-month working ledger, pruning older local rows to keep storage lean.
* **Realtime Websocket (`RealtimeForegroundSync`)**:
  * Listens to Postgres change events on `transactions:{userId}` and `outings:{userId}` while the app is active.
  * Automatically **disconnects on app background/pause** to conserve battery and mobile data.
* **Headless Background Sync**:
  * Android WorkManager triggers a periodic 15-minute background sync when online to keep data up to date even if the app hasn't been opened.

---

## 🔒 Security, Privacy & Data Protection

1. **Hardware-Backed AES-256 Storage**:
   * All local Hive boxes (`transactions`, `accounts`, `outings`, `wealth_snapshots`) are encrypted using `HiveAesCipher`.
   * Encryption keys are generated dynamically per device installation and stored in Android Keystore / iOS Keychain via `FlutterSecureStorage`.
2. **Local SMS Isolation**:
   * SMS processing is strictly sandboxed. The application never sends SMS content or sender phone numbers to Supabase or any third party.
3. **Session Revocation Guard**:
   * Every sync checks session validity against the server. If an account is deleted remotely, the local database is immediately wiped for security.
4. **App Privacy Shield**:
   * Screen contents are masked in the recent apps switcher when PIN lock is enabled.

---

## ⚡ Performance, Battery & Resource Optimization

* **Zero Polling**: Background SMS detection is 100% event-driven via native Android `EventChannel` and broadcast receivers (0% CPU when idle).
* **Battery-Aware Scheduling**: WorkManager tasks enforce `requiresBatteryNotLow: true` to prevent wake-locks when the battery is depleted.
* **Optimized Image & Bitmap Cache**: Image decoding caches are capped at 50MB, preventing low-memory kills on 2GB–4GB RAM Android devices.
* **Single-Pass Balances & Selective Rebuilds**: Computation of account balances and ledger indices are memoized via `LedgerMonthIndex` to sustain smooth 60/120 FPS scrolling.

---

## 🗄️ Local Storage (Hive Boxes Schema)

| Box Name | Description |
| :--- | :--- |
| `transactions` | Complete offline ledger entries (Income, Expense, Transfer). |
| `accounts` / `user_state` | User accounts (Cash, Bank, Wallets, Cards) and profile metadata. |
| `wealth_snapshots` | Daily closing net worth records and per-account balances. |
| `outings` | Group travel trips, participant lists, and outing expenses. |
| `friend_splits` | Split bills, individual shares, and payment repayment tracking. |
| `monthly_plans` | Monthly budgets, category caps, and savings goals. |
| `detected_sms_box` | Unverified SMS transaction queue awaiting user review. |
| `merchant_aliases` | Learned merchant naming rules and alias associations. |
| `settings` | User preferences, theme settings, PIN hashes, and feature flags. |
| `sync_queue` | Outbound mutation queue waiting to sync to Supabase. |

---

## 📁 Folder Structure & Code Organization

```
SpentX/lib/
├── core/                           # Foundation & Shared Services
│   ├── config/                     # Supabase & app configuration
│   ├── debug/                      # MasterDebugLog & diagnostics
│   ├── design/                     # Reusable design components & feedback
│   ├── providers/                  # Global Riverpod providers
│   ├── router/                     # GoRouter route declarations & guards
│   ├── services/                   # Auth, PIN, notifications & reset services
│   ├── sync/                       # Two-way sync engine, queue & realtime
│   ├── theme/                      # SoftPalette, AppTheme & token system
│   └── utils/                      # Ledger indexing & financial math utilities
│
├── features/                       # Modular Feature Modules
│   ├── accounts/                   # Accounts overview, cards & balance seeds
│   ├── auth/                       # Splash, login, signup, onboarding & lock
│   ├── home/                       # Dashboard, Bento hero, active trip banner
│   ├── notifications/              # In-app notifications center
│   ├── outings/                    # Trip manager, split bills & settlements
│   ├── plan/                       # Monthly budget wizard, caps & progress
│   ├── settings/                   # Profile, security, themes & debug console
│   ├── sms/                        # V4 regex engine, rules lab & background processor
│   ├── transactions/               # Activity ledger, filters, search & edit
│   └── wealth/                     # Daily snapshots, emergency runway & projector
│
├── models/                         # Domain models (Transaction, Account, Outing)
└── main.dart                       # Entry point, orientation & lifecycle handlers
```

---

## 🚀 Running & Building

### Prerequisites
* Flutter SDK: `>=3.3.0`
* Android Studio / Xcode with Dart & Flutter plugins
* Supabase project with SpentX schema

### Development Setup
```bash
# 1. Navigate to Mobile App directory
cd "Mobile app/SpentX"

# 2. Get dependencies
flutter pub get

# 3. Analyze code quality (0 errors, 0 warnings)
flutter analyze lib/

# 4. Run on connected Android / iOS device
flutter run
```

### Production Build
```bash
# Build Android APK
flutter build apk --release

# Build Android App Bundle (Play Store)
flutter build appbundle --release

# Build iOS IPA (App Store)
flutter build ipa --release
```

---
*Maintained with ❤️ by the SpentX Team. Secure, Private, and Offline-First Financial Intelligence.*
