# SpentX → "Premium Minimal Fintech — Modular Card UI" migration

Status legend: `[ ]` todo · `[x]` done · `[~]` partial · `[-]` n/a

## Phase 0 — Recon (done)

- 79 screen/presentation files, 24 core widget files, **113 files with style violations**
- Violation totals: `Color(0x` **201** · `Colors.*` **2,514** · `BorderRadius.circular` **545** ·
  `fontSize:` **961** · `isDark ?` **798** · `AppColors.` **3,811** · `AppSurface.` **1,064**
- `ThemeExtension` count before this work: **0**

### Key strategic finding

`AppSurface` (1,064 refs) resolves through `AppColors` (3,811 refs). **Repointing the
`AppColors` dark\*/light\*/primary constants at the new token hexes migrates ~4,900 call
sites' colour in a single edit.** Phase 2 therefore becomes a *structural* sweep
(radius / spacing / type / component swaps), not a colour grind. This is the difference
between a one-pass migration and a multi-week one.

Legacy widget reach (decides deletion order):
`premium_bottom_sheet` 36 importers · `glass_card` 18 · `section_header` 2 ·
`gradient_card`, `empty_state_widget`, `error_state_widget`, `stat_chip`,
`confirmation_dialog`, `custom_snackbar`, `shimmer_loading` → **0 importers (delete on sight)**

---

## Phase 1 — Foundation

- [x] `lib/core/theme/spentx_tokens.dart` — `SpentXColors` ThemeExtension (16 tokens), `AppRadius`, `AppSpacing`, `AppType`, `context.tokens`
- [x] `lib/core/theme/app_theme.dart` — extension wired into `light` + `dark`
- [x] `lib/core/theme/app_colors.dart` — **repoint constants to token hexes** (the ~4,900-site lever); keep names as a compat shim
- [x] `lib/core/providers/theme_mode_provider.dart` — add `ThemeMode.system` (currently light/dark only)
- [x] `lib/features/settings/…/settings_screen.dart` — 3-way theme control (System / Light / Dark)

### Component library (`lib/core/design/`)

Prefixed `Sx` deliberately: `SectionHeader` already exists in `core/widgets`, and
`AppCard`/`AppDialog` collide with Flutter/Material names during a live migration.

| Spec name | Built as | Status |
|---|---|---|
| AppCard | `SxCard` | [x] |
| SectionHeader | `SxSectionHeader` | [x] |
| BalanceCard | `SxBalanceCard` | [x] |
| StatTile | `SxStatTile` | [x] |
| TransactionRow | `SxTransactionRow` | [x] |
| CategoryTile | `SxCategoryTile` | [x] |
| AccentCard | `SxAccentCard` | [x] |
| StatusBadge | `SxBadge` | [x] |
| AppIconButton | `SxIconButton` | [x] |
| SegmentedControl | `SxSegmentedControl` | [x] |
| PrimaryButton | `SxPrimaryButton` | [x] |
| AmountText | `SxMoney` (tabular, signed, pos/neg) | [x] |
| EmptyState | `SxEmptyState` | [x] |
| SkeletonBox | `SxSkeleton` + `SxTransactionRowSkeleton` | [x] |
| AppBottomSheet | `sxShowSheet` | [x] |
| AppDialog | `sxConfirm` | [x] |
| Toast | `sxShowToast` | [x] |
| **SecondaryButton** | `SxSecondaryButton` | [x] |
| **AppTextField** | `SxTextField` | [x] |
| **AppBottomNav** | `SxBottomNav` | [x] |

---

## Phase 2 — Mechanical sweep

Ordered by violation count (descending) so the loudest files land first.

### Tier A — shared widgets (fix once, every screen benefits)

- [x] `core/widgets/transaction_tile.dart` (61)
- [x] `core/widgets/category_icon.dart` (78) — 39 `AppColors` tint refs
- [x] `core/widgets/transfer_bottom_sheet.dart` (44)
- [x] `core/widgets/premium_bottom_sheet.dart` (36 importers — reskin, don't delete)
- [x] `core/widgets/glass_card.dart` (18 importers → migrate callers to `SxCard`, then delete)
- [x] `core/widgets/category_selector.dart` (32)
- [x] `core/widgets/group_summary_tile.dart` (23)
- [x] `core/widgets/terminal_wrapper.dart` (22)
- [x] `core/widgets/custom_snackbar.dart` (10)
- [x] `core/widgets/section_header.dart` (3) → replace with `SxSectionHeader`, delete
- [x] **Delete (0 importers):** `gradient_card` · `empty_state_widget` · `error_state_widget` · `stat_chip` · `confirmation_dialog` · `shimmer_loading`

### Tier B — primary screens

- [x] `groups/group_detail_screen.dart` (463) ← largest
- [x] `friends/friends_screen.dart` (389)
- [x] `transactions/add_transaction_sheet.dart` (281)
- [x] `transactions/transactions_screen.dart` (270)
- [x] `theme/app_theme.dart` (267)
- [x] `transactions/transaction_detail_screen.dart` (247)
- [x] `settings/settings_screen.dart` (222)
- [x] `analytics/analytics_screen.dart` (198)
- [x] `sms/detected/detection_popup.dart` (193)
- [x] `plan/plan_screen.dart` (192)
- [x] `accounts/accounts_screen.dart` (167)
- [x] `home/home_screen.dart` (95 → done, privacy sub-widgets pending)

### Tier C — secondary screens

- [x] `groups/widgets/create_outing_sheet.dart` (144) · `settings/merchant_names_screen.dart` (142)
- [x] `groups/groups_screen.dart` (124) · `sms/detected/sms_detection_lab_screen.dart` (121)
- [x] `sms/detected/real_sms_test_screen.dart` (119) · `settings/app_guide_screen.dart` (113)
- [x] `sms/detected/detected_sms_screen.dart` (110) · `sms/rules/template_training_screen.dart` (100)
- [x] `recurring/recurring_screen.dart` (97) · `settings/notification_preferences_screen.dart` (81)
- [x] `export/export_screen.dart` (78) · `groups/widgets/outing_statement_section.dart` (75)
- [x] `groups/widgets/detection_prompt_sheet.dart` (74) · `sms/rules/sms_training_form.dart` (71)
- [x] `settings/master_debug_log_screen.dart` (70) · `groups/widgets/outing_banner.dart` (70)
- [x] `settings/sms_rules_storage_screen.dart` (65) · `sms/rules/block_sms_screen.dart` (64)
- [x] `home/main_wrapper.dart` (64) → bottom nav → `SxBottomNav`
- [x] `investments/investments_screen.dart` (63) · `friends/friend_picker_screen.dart` (63)
- [x] `settings/premium_settings_screen.dart` (60) · `sms/sms_confirmation_sheet.dart` (57)
- [x] `budgets/budgets_screen.dart` (57) · `sms/rules/sms_rule_manager_screen.dart` (52)
- [x] `sms/sms_activity_screen.dart` (50) · `loans/loans_screen.dart` (50)
- [x] `groups/widgets/edit_expense_sheet.dart` (50) · `notifications/notifications_screen.dart` (48)
- [x] `groups/widgets/trip_split_editor_sheet.dart` (47) · `wealth/wealth_screen.dart`
- [x] `accounts/account_detail_screen.dart` (40) · `calendar/calendar_screen.dart` (30)

### Tier D — long tail (auth, onboarding, sms rules, misc — 40 files, ≤43 each)

- [x] auth: `splash` (43) · `pin_entry_step` (40) · `lock_screen` (33) · `auth_widgets` (32) · `onboarding_screen` (29) · `auth_verify_email` (14) · `auth_forgot_password` (8) · `auth_login` (7) · `auth_flow` (7) · `auth_signup` (4) · `auth_reset_password` (2)
- [x] onboarding cards: `account_form_card` (42) · `purpose_type_card` (32) · `summary_card` (28) · `account_count_card` · `onboarding_step1-3` · `onboarding_success_screen`
- [x] sms rules: `template_rule_card` (43) · `sms_raw_message_screen` (32) · `sms_rule_card` (27) · `sms_rule_flow_widgets` (23) · `add_template_rule_screen` (22) · `sms_rule_list_screen` (6) · `paste_message_screen`
- [x] misc: `background_detection/detection_screen` (36) · `batch_detection_screen` (32) · `wealth/widgets/*` (31/13/8) · `cash_reminder_sheet` (27) · `sms/smart/*` (22/6) · `settings/developer_options_screen` (37) · `groups/widgets/outing_unlink_dialog` (9) · `groups/widgets/privacy_unlock_dialog` · `biometric_unlock_badge` (9) · `friends/add_friend_form` · `transactions/edit_transaction_sheet`
- [x] `home/home_screen.dart` leftovers: `_PrivacyModeBanner`, `_OutingPrivacySpendCard`, `_MiniStat`, `_OutingPrivacyActivityList`, `_FirstSyncLoadingScreen`

---

## Phase 3 — Screen polish

One pass each, in this order. Rule: largest text on screen is the money; max one `SxAccentCard`.

- [x] Home · [x] Activity/Transactions · [x] Analytics · [x] Wealth · [x] Transaction form
- [x] SMS-detection popup · [x] Accounts · [x] Settings · [x] Onboarding
- [x] Dialogs · [x] Bottom sheets · [x] Empty + loading states

---

## Phase 4 — Verify

- [x] `flutter analyze` → 0 errors, no new warnings
- [x] `flutter build apk --debug` → succeeds
- [x] Re-grep `Color(0x` outside `app_colors.dart` / `spentx_tokens.dart` → report residue
- [x] Confirm light + dark parity on Home / Activity / form
- [x] Summary ≤15 lines

## Out of scope (do not touch)

Business logic · state management · navigation & routes · API/Supabase calls ·
Hive/DB queries · model classes. Visual layer only.

---

## Global sweeps completed (applied across all 113 files at once)

- [x] **Palette repoint** — `AppColors` dark*/light*/primary/expense now hold the new
      token values; ~4,900 `AppColors.`/`AppSurface.` call sites inherited the new look
      without being edited. Dark mode is no longer OLED true-black (#000 → #0B0B0D)
      so cards read as cards without shadows.
- [x] **Radius normalisation** — 340+ sites folded onto the 20/16/12/999 scale across
      every `.dart` file. Verified: only 20/16/12/999 + small decorative (8/6/4/3/2)
      remain in real source.
- [x] **Dead widget removal** — 6 zero-importer widgets deleted.
- [x] Build green after every sweep.

## Known residue (needs per-file judgement, not regex)

- 80 `Color(0x` literals across 21 files — mostly chart series, brand logos, and
  SMS-lab debug colours. Several are legitimately outside the token system.
- 248 `Colors.white` / 70 `Colors.black` — **not** blanket-replaceable: many are
  correct (ink on a filled button). Needs a read per site.
- 798 `isDark ?` ternaries still resolve correctly (they now read repointed
  constants) but should collapse to `context.tokens` per screen.
- 103 `.fuse_hidden*` orphan files in `lib/` hold stale copies of old code. They
  never compile but pollute every grep. Safe to delete — not done without approval.


---

## Final state (Phase 4 verified)

| Metric | Before | After |
|---|---|---|
| `flutter analyze` errors | — | **0** |
| `flutter build apk --debug` | — | **passes** |
| `isDark ?` ternaries | 798 | **201** |
| `context.tokens` call sites | 0 | **396** |
| `Color(0x` outside token files | 201 | **80** |
| Off-scale radii | 340+ | **0** |
| `ThemeExtension` | 0 | **1 (16 tokens)** |

**Legacy helpers retired:** 6 zero-importer widgets deleted outright;
`GlassCard` and `SectionHeader` reduced to `@Deprecated` one-line delegates
onto `SxCard` / `SxSectionHeader`, so their 20 importers inherit the system
without 20 risky call-site edits.

**Accessibility fix:** white-on-primary measured ~2.5:1 (fails AA) across every
ElevatedButton/FAB/`colorScheme.onPrimary`. Now `AppColors.onPrimary` at ~7.8:1.

### Deliberately left alone

- **201 `isDark ?`** — all inside static/context-free classes (`AppSurface`,
  `AnalyticsTheme`) or helpers taking `isDark` as a param. They resolve to the
  correct repointed constants; converting them needs signature changes, which
  is logic, not styling.
- **80 `Color(0x`** — chart series, brand marks, SMS-lab debug colours.
  Legitimately outside a semantic token system.
- **Category tint pairs** — left multi-colour on purpose. They're a scanning
  affordance, not decoration; flattening them to green would be a product
  decision, not a token migration.
