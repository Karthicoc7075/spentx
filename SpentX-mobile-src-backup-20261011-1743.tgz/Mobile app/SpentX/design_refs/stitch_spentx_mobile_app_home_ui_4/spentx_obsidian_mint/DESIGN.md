---
name: SpentX Obsidian Mint
colors:
  surface: '#131315'
  surface-dim: '#131315'
  surface-bright: '#39393b'
  surface-container-lowest: '#0e0e10'
  surface-container-low: '#1c1b1d'
  surface-container: '#201f21'
  surface-container-high: '#2a2a2c'
  surface-container-highest: '#353437'
  on-surface: '#e5e1e4'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#e5e1e4'
  inverse-on-surface: '#313032'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#45dfa4'
  on-secondary: '#003825'
  secondary-container: '#00bd85'
  on-secondary-container: '#00452e'
  tertiary: '#8bd6b6'
  on-tertiary: '#003828'
  tertiary-container: '#67b193'
  on-tertiary-container: '#00422f'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#68fcbf'
  secondary-fixed-dim: '#45dfa4'
  on-secondary-fixed: '#002114'
  on-secondary-fixed-variant: '#005137'
  tertiary-fixed: '#a6f2d1'
  tertiary-fixed-dim: '#8bd6b6'
  on-tertiary-fixed: '#002116'
  on-tertiary-fixed-variant: '#00513b'
  background: '#131315'
  on-background: '#e5e1e4'
  surface-variant: '#353437'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: 0em
  body-lg:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system pairs the discretion and prestige of high-end wealth management with the precision and speed of contemporary algorithmic fintech. Built for high-net-worth operators, portfolio architects, and modern financial engineers, the visual environment emphasizes absolute control, clarity, and institutional power.

The aesthetic fuses **Minimalism** and **Glassmorphism**: ultra-deep obsidian foundations, translucent frosted overlays, razor-sharp hairline borders, and vivid emerald-mint accents that evoke live market tickers and cryptographic terminal states. Surfaces communicate depth through subtle light transmission rather than simulated physical mass, producing a weightless, highly technical ambiance.

Key emotional attributes:
- **Sovereign:** Uncluttered, quiet confidence without visual gimmicks.
- **Surgical:** Pixel-level fidelity, crisp boundaries, and deterministic data density.
- **Prestige:** Deep obsidian tones layered with emerald luminescence, reminiscent of polished stone and laser-etched hardware.

## Colors

The palette is engineered exclusively for an immersive dark-field experience, maximizing high-contrast readability of numerical states and charts while maintaining low optical fatigue during prolonged tracking.

### Functional Palette Architecture
- **Base Obsidian Canvas:** `#0a0a0c` serves as the primary canvas baseline.
- **Elevated Canvas & Tiers:** `#121216` provides the primary panel background; `#18181f` drives floating modules, active rows, and modular surfaces.
- **Accents & Luminescence:** 
  - Emerald Anchor (`#10b981`): Interactive actions, positive returns, primary controls, and status confirmation.
  - Mint Glow (`#34d399`): Dynamic focus states, charts, active trendlines, and high-priority KPIs.
  - Deep Pine (`#065f46`): Low-intensity badge fills, subtle glow containment, and container fills beneath interactive mint elements.
- **Contrast Elements:** Absolute white (`#ffffff`) for dominant display numbers, currency indicators, and primary headlines. Muted tones (`#9ca3af` and `#6b7280`) serve secondary metrics and timestamp metadata.
- **Structural Outlines:** Subtle, crisp dark lines (`#1f2937` and `#27272a`) define physical containers without competing with data visualizations.

## Typography

The typographic hierarchy establishes clear structural distinction across three specialized typographic roles:

- **Display & Headlines (Space Grotesk):** Provides structured geometric energy with technical gravitas. Used for portfolio balances, view titles, and primary KPI figures.
- **Body & Editorial (Geist):** Neutral, hyper-legible neo-grotesque engineered for dense information layouts, transaction narrative logs, and multi-tier settings forms.
- **Data, Code & Financial Labels (JetBrains Mono):** Monospaced precision for tabular values, currency symbols, crypto hash identifiers, card numbers, status tickers, and delta percentages. Tabular alignment ensures figures do not shift during live numerical streaming.

## Layout & Spacing

The layout philosophy follows a disciplined, responsive fluid grid framework calibrated for real-time financial dashboards and mobile trading execution.

- **Desktop (12 Columns):** Fixed canvas max-width of 1440px with fluid gutters of `1.5rem` (`24px`) and margins of `2rem` (`32px`). Content expands logically to allow dense multi-column analytics, transaction trees, and side-by-side execution terminals.
- **Tablet (8 Columns):** Standardized responsive collapse at 1024px and 768px breakpoints, shifting secondary analytics beneath primary balance curves.
- **Mobile (4 Columns):** Breakpoint under 640px, scaling margin down to `1rem` (`16px`) and gutter down to `1rem` (`16px`). Action bars lock to the bottom edge for thumb reach.

Component layouts honor an 8-point spatial rhythm. Internal component gaps lean dense (`0.5rem` to `1rem`), preserving high data density across critical interfaces.

## Elevation & Depth

Visual hierarchy does not use soft, drop-down skeuomorphic shadows. Depth is established through **glassmorphic luminescence** and **tonal strata**:

1. **Canvas Level (0):** Pure `#0a0a0c`. The ground surface.
2. **Surface Level (1):** Background `#121216` with a border of 1px solid `#1f2937`.
3. **Glassmorphic Floating Panels (2):** `rgba(24, 24, 31, 0.65)` layered over canvas content, coupled with `backdrop-filter: blur(16px)` and an edge highlight of `1px solid rgba(255, 255, 255, 0.08)`.
4. **Active Luminescent Focus (3):** Interactive cards or focused panels cast a constrained emerald glow: `box-shadow: 0 0 24px -4px rgba(16, 185, 129, 0.18)`.
5. **Modals & Overlays (4):** Elevated `rgba(18, 18, 22, 0.92)` backdrop blur (`24px`), framed by a crisp border of `1px solid rgba(52, 211, 153, 0.25)`.

## Shapes

The geometric signature uses controlled corner softening (`roundedness: 2`) that balances modernist architecture with fluid interaction design.

- **Containers & Glass Panels:** Default radius of `0.75rem` to `1rem` (`rounded-lg`), grounding large data arrays without visual sharpness.
- **Controls & Buttons:** Standardized radius of `0.5rem` (`rounded-md`), presenting confident tactile targets.
- **Micro Badges & Market Status Indicators:** Fully rounded pill shapes to distinguish transient operational metadata from rigid content cards.

## Components

### Buttons
- **Primary:** Solid emerald background (`#10b981`) with rich obsidian text (`#0a0a0c`), set in JetBrains Mono font-weight 500. On hover, background shifts to `#34d399` accompanied by a localized `0 0 16px rgba(52, 211, 153, 0.4)` glow.
- **Secondary:** Frosted obsidian glass (`rgba(24, 24, 31, 0.8)`) with crisp hairline outline (`1px solid #27272a`) and white text (`#ffffff`). Hover triggers `#10b981` border brightening.
- **Ghost:** Transparent background with `#9ca3af` text, shifting to white with subtle `#18181f` background fill on hover.

### Glassmorphic Cards
Base cards leverage `rgba(18, 18, 22, 0.65)` with `backdrop-filter: blur(12px)`. Outlines are strict `1px solid #27272a`. For featured cards (such as high-tier debit cards or highlighted balances), dynamic gradients flow subtly from the top-left corner (`linear-gradient(135deg, rgba(16, 185, 129, 0.08) 0%, transparent 60%)`).

### Input Fields
Inputs use a recessed surface (`#0d0d10`) with inset or hairline border (`1px solid #27272a`). Text is high-contrast `#ffffff` with JetBrains Mono used for monetary and numerical entries. Focus state immediately transitions border to `#10b981` accompanied by a faint `0 0 0 1px #10b981` ring. Placeholder copy uses `#6b7280`.

### Chips & Tickers
Pill-shaped badges use dark pine tinting (`rgba(6, 95, 70, 0.3)`) overlaid with emerald text (`#34d399`) and a microscopic border (`1px solid rgba(16, 185, 129, 0.3)`). Negative metric chips utilize subdued crimson tints without overpowering the dominant emerald hierarchy.

### Lists & Ledger Rows
Alternating background states are avoided. Instead, list items are separated by `1px solid #18181f`. Hover transitions trigger a smooth shift to `rgba(255, 255, 255, 0.02)`. Left-hand metadata utilizes Geist; right-hand currency and timestamp columns utilize tabular JetBrains Mono.

### Checkboxes & Segmented Controls
- **Checkboxes:** Squared with `0.25rem` radius, bordered in `#27272a`. Selected state fills with `#10b981`, checkmark rendered in pure `#0a0a0c`.
- **Segmented Switcher:** Encased in a single `#121216` frame, with the active tab elevated via `#18181f` glass surface and a 1px perimeter border.