---
name: SpentX Precision Mint
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#3c4a42'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#6c7a71'
  outline-variant: '#bbcabf'
  surface-tint: '#006c49'
  primary: '#006c49'
  on-primary: '#ffffff'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#4edea3'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#006d3e'
  on-tertiary: '#ffffff'
  tertiary-container: '#00ba6e'
  on-tertiary-container: '#004223'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#62fea6'
  tertiary-fixed-dim: '#3ee18d'
  on-tertiary-fixed: '#00210f'
  on-tertiary-fixed-variant: '#00522d'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Manrope
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Manrope
    fontSize: 28px
    fontWeight: '800'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Manrope
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  body-sm:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  label-lg:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Manrope
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.25rem
  space-xl: 1.5rem
---

## Brand & Style
The design system establishes a high-trust, modern consumer fintech aesthetic centered around clarity, financial vitality, and effortless daily interaction. Designed primarily for mobile-first personal finance tracking, it instills a sense of calm competence and momentum. The style blends refined modern minimalism with soft tactile dimensionality—pairing clean off-white surfaces, crisp typography, and luminous emerald accents to denote growth and liquidity. 

Visual interactions avoid visual noise; financial complexity is reduced into bite-sized, card-contained insights. Micro-interactions should feel snappy, elastic, and deliberate, reinforcing user confidence in sensitive financial movements.

## Colors
The palette uses color with semantic precision to give instant financial context at a glance:

- **Primary & Vitality Brand Colors (`#10B981` / `#00C675`):** Reserved for positive values, cash inflows, savings targets, primary CTA fills, active navigation states, and progress bars.
- **Deep Navy Base (`#0F172A`):** Anchors the interface. Applied to major currency balances, primary headlines, active icons, and high-emphasis data points.
- **Slate Secondary (`#64748B`):** Provides low-strain readability for metadata, timestamps, input placeholders, category subheads, and inactive tab states.
- **Canvas & Containers:** App-level canvas sits on `#F8FAFC`, while interactive surfaces, sheets, and elevated cards utilize pure `#FFFFFF`.
- **Semantic Category Palette:**
  - **Expense / Outflow:** `#EF4444` (Strictly negative deltas, debt alerts, and outgoing transfers).
  - **Food & Dining:** `#F59E0B` (Warm amber).
  - **Groceries & Commute:** `#3B82F6` (Electric cobalt).
  - **Shopping & Lifestyle:** `#8B5CF6` (Vivid purple).

## Typography
Manrope powers the entire typographic system, leveraging its geometric balance and optimized tabular numerals for financial legibility. 

- Use **tabular figures** (`font-variant-numeric: tabular-nums`) across all balance displays, transaction ledgers, and metrics to maintain column alignment.
- Financial total balances employ tight tracking (`-0.02em` to `-0.03em`) to anchor visual mass.
- Metadata and category micro-tags rely on uppercase or semibold `label-sm` tracking to maximize legibility at compact mobile scale.

## Layout & Spacing
The layout model is optimized around handheld mobile ergonomics, transitioning gracefully to constrained desktop dashboard widths:

- **Mobile (<640px):** Single-column layout with fixed `1rem` (16px) side canvas margins. Vertical pacing uses `space-md` (16px) between card stacks and `space-xl` (24px) between distinct category clusters.
- **Tablet (640px–1024px):** 6-column fluid grid, `1.5rem` margins, allowing analytical charts and transaction logs to sit in dual-pane configuration.
- **Desktop (>1024px):** Max container width of 1200px, 12-column layout with `1.5rem` gutters, centering financial overviews and multi-account panes.
- **Safe Areas & Chrome:** Always account for native device notches and provide a bottom clearance of at least `88px` on mobile viewports to prevent interference with the fixed bottom navigation bar and floating action button.

## Elevation & Depth
Elevation in this system avoids harsh drop-shadows, using multi-layered, tinted ambient diffusion paired with subtle structural hairline borders:

- **Level 0 (Canvas):** Pure flat `#F8FAFC`.
- **Level 1 (Standard Card / Row Surfaces):** Pure white background (`#FFFFFF`), bounded by a `1px` border of `#E2E8F0` at 60% opacity (`rgba(226, 232, 240, 0.6)`), supported by an ambient drop shadow: `0px 2px 8px -2px rgba(15, 23, 42, 0.04), 0px 6px 16px -4px rgba(15, 23, 42, 0.03)`.
- **Level 2 (Interactive Flyouts, Quick Modals):** Pure white background, `rgba(226, 232, 240, 0.8)` border, with an elevated soft projection: `0px 10px 25px -5px rgba(15, 23, 42, 0.08), 0px 8px 10px -6px rgba(15, 23, 42, 0.04)`.
- **Level 3 (Primary Floating Action Button):** Dual-layer directional emerald glow: `0px 8px 20px -4px rgba(16, 185, 129, 0.45), 0px 4px 8px -2px rgba(0, 198, 117, 0.25)`.
- **Bottom Navigation Dock:** Translucent white surface (`rgba(255, 255, 255, 0.92)` with `backdrop-filter: blur(16px)`), elevated by a top hairline `rgba(226, 232, 240, 0.8)` and subtle upward lift: `0px -4px 20px rgba(15, 23, 42, 0.04)`.

## Shapes
A consistent radius language establishes approachable softness while maintaining structural discipline:

- **Cards & Data Panels:** Styled with an explicit `1.25rem` (20px) corner radius, producing a signature pebble-card silhouette.
- **Category Icon Badges:** Shaped with a `0.875rem` (14px) squircle-styled radius.
- **Input Fields & Action Controls:** Standardized at `0.75rem` (12px) to `1rem` (16px) corner rounding.
- **Pills & Floating Indicators:** Fully rounded (`rounded-full` / 9999px) for status badges, tab triggers, and the primary center floating action button.

## Components

### Buttons
- **Primary:** Full fill of `#10B981` (hovering to `#00C675`), white semibold text, soft emerald shadow. Padding: `12px 24px`, height `48px`, border radius `14px`.
- **Secondary / Soft:** Faint mint background (`rgba(16, 185, 129, 0.1)`), deep emerald label (`#059669`). Zero outline.
- **Tertiary / Neutral:** Pure white background, `1px` subtle outline (`#E2E8F0`), slate navy text (`#0F172A`).

### Floating Action Button (FAB)
- Prominent `56px × 56px` circular button positioned in the center cut-out of the mobile bottom bar.
- Solid `#00C675` background with an inverted white plus icon.
- Elevated with Level 3 vibrant shadow to remain the focal visual anchor of the mobile screen.

### Navigation Dock (Mobile Bottom Bar)
- Height: `68px` plus safe-area-inset bottom.
- Background: High-blur translucent white.
- Features 4 destination tab items flanking the central elevated FAB. Active state uses `#10B981` glyph with a miniature 4px mint dot below; inactive tabs use `#64748B`.

### Category Icon Frames & Lists
- Transaction list items sit inside white card modules or clean dividers.
- **Icon Frame:** `44px × 44px` with a 14px rounded corner, filled with a 10% opacity tint of the respective category color (e.g., `#F59E0B1A` for Food/Dining).
- **Icon Style:** Duotone or sharp 2px line iconography tinted in the full-saturation category hue.
- **Value Layout:** Left-aligned category name with subordinate date/time; right-aligned tabular currency value colored `#0F172A` (or `#EF4444` prefixed with `−` for spending, `#10B981` prefixed with `+` for deposits).

### Cards & Progress Trackers
- Encased in Level 1 elevation with `20px` border radius.
- Budget progress tracks feature a `8px` tall background trough of `#F1F5F9` supporting a continuous, smooth `#10B981` bar fill that shifts dynamically to `#EF4444` if the category exceeds 100%.

### Form Inputs
- Height: `48px`. Surface fill of `#F8FAFC`, transitioning to `#FFFFFF` upon `:focus`.
- Border: `1px solid #E2E8F0`, transforming to a crisp `2px solid #10B981` ring on focus.